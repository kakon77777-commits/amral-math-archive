# CSM Paper 02 Package

This package contains the canonical UTF-8 source for:

**CSM Paper 02 — Typed Closure Graphs and Obstruction Propagation**

It extends CSM Paper 00 and Paper 01 with the first graph-operational core:

- typed directed hypergraph;
- obstruction propagation;
- conditional closure;
- bridge closure;
- quotient closure;
- reopening;
- frontier contraction;
- route-completeness and branch-decomposition certificates;
- NS compilation rules.

Files:
- canonical Markdown;
- machine-readable YAML schema;
- validation scenarios JSON;
- validation evidence JSON.

This package does not yet build the NS Relative-Global Closure Graph dataset. That is a downstream instantiation.
