# CSM Paper 03 Package

Contains the canonical UTF-8 source for:

**CSM Paper 03 — Frontier Geometry, Cut Sets, and Relative Exhaustion**

This paper extends CSM Papers 00–02 with:
- quotient frontier geometry;
- frontier mass and components;
- typed cut sets;
- obstruction covers;
- route-completeness / cut-completeness separation;
- exhaustion ladder EXH0–EXH5;
- relative exhaustion certificates;
- parent closure gates;
- reopening and stale exhaustion handling;
- Navier–Stokes frontier instantiation rules.

This package does not yet construct the full NS closure graph dataset.
