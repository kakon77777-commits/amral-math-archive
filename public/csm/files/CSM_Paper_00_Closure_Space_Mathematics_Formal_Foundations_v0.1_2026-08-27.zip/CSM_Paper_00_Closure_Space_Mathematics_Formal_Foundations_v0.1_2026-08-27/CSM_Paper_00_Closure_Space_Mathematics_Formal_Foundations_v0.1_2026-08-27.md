# CSM Paper 00
# 閉包空間數學論的形式基礎
## Closure-Space Mathematics: Formal Foundations for Relative-Global Mathematical Closure

**版本：** v0.1  
**日期：** 2026-08-27  
**系列：** Closure-Space Mathematics / CSM  
**文件地位：** 母理論奠基論文 / Formal Foundations  
**Canonical source：** UTF-8 Markdown  
**Canonical math delimiters：** `$...$` 與 `$$...$$`  
**研究狀態：** 理論框架、定義系統、形式命題與後續證明計畫；不是對任何未解數學問題的完成證明。

---

# 摘要

本文提出 **閉包空間數學論**（Closure-Space Mathematics, CSM）的第一版形式基礎。CSM 的核心問題不是「如何再生成一條證明路徑」，而是：當一個長程數學研究計畫已累積大量命題、假設、證明嘗試、反例、障礙、橋接、表示、局部成功與失敗後，能否把這些研究狀態組成一個可驗證、可重放、可更新的相對全域數學空間，並對其中哪些區域已閉合、哪些仍開放、哪些只是局部受阻，給出明確的型別化判定。

CSM 吸收但不等同於兩條既有內部理論線。第一條是 Logic-Space Integration and Proof-Space Dynamics（LSI-PSD），其已建立 semantic quotient、route graph、proof basin、obstruction confluence、theorem-strength preorder 與 Proof-Space Observatory。第二條是 UGC/CUR / Unified Closure Theory（UCT），其建立 typed non-collapse、generative closure、reachability、transformation closure、bridge certificate、debt 與 ledger。本文將兩者提升為一個新的數學研究對象：**closure space 本身**。

本文的第一個核心原則是：

$$
\boxed{
\text{Observed Proof Space}
\neq
\text{Admissible Proof Space}
\neq
\text{Mathematical Reality}.
}
$$

因此本文只首先定義 **相對全域閉包**（relative-global closure），而不把有限 corpus、有限搜尋制度或有限圖結構冒充成全部可能數學路徑。

第二個核心原則是：

$$
\boxed{
\text{Route Closure}
\neq
\text{Theorem Proof}.
}
$$

若研究者希望把「所有候選路徑都被封住」升格成定理，必須額外提供 route-completeness / decomposition-completeness 類證書，證明被列舉並商化後的路徑族對目標命題的指定 admissible mechanism class 是完備的。

第三個核心原則是 **Globality Typing Principle**：任何「全域」都必須說明它在哪一個軸上全域。以 Navier--Stokes 為第一個大型實驗場，本文區分 Clay/formal mathematical NS、physical realization NS，以及 generalized NS-like equation family，並主張：

$$
\boxed{
\text{Global-in-time}
\neq
\text{Global-across-equation-family}
\neq
\text{Global-across-physical-realizations}.
}
$$

本文最後定義 typed closure-space object、節點與超邊、closure actions、frontier、closure debt、reopening、relative-global closure grade、route-completeness certificate，以及 NS Relative-Global Closure Space 的第一版資料模型。後續 CSM 系列將把既有 NS C1--C6、X72、DCRP、MORP、RFP、FCBP 與 Proof Asset Map 中的正結果、NO-GO、survivor、OPEN、conditional bridge 逐步投影進同一個閉包空間，真正把「研究過的路徑」轉化成可被再次運算的數學資產。

---

# 0. 研究地位與非主張

本文不主張：

1. 已建立所有數學問題唯一自然的 proof space；
2. 任意數學命題的所有證明路徑都可被有限列舉；
3. graph / hypergraph representation 與數學本體相同；
4. semantic quotient 可由 embedding 或 LLM 相似度自動完成；
5. 多條路徑撞上同一 obstruction 即可證明命題為假或不可證；
6. 某個 basin 被封閉即代表整個 proof space 被封閉；
7. relative-global closure 自動等於 absolute mathematical closure；
8. closure operator 在所有 CSM 層上都自動滿足傳統 closure algebra 的 extensivity、monotonicity 與 idempotence；
9. Clay Navier--Stokes 的 global regularity proof 等同於物理世界中所有流體現象的全域證明；
10. generalized NS-like family 已有唯一 canonical 定義；
11. CSM 可以取代 theorem-level verification；
12. CSM 已解決 Navier--Stokes existence and smoothness。

本文只主張：

- 長程研究狀態可以被整理成 typed multilayer mathematical graph；
- 不同 closure type 必須保持型別差異；
- 「已觀察」「已封路」「已證明」「已反證」「相對全域已閉」必須分開；
- closure promotion 必須攜帶 certificate；
- globality 必須型別化；
- relative-global closure 可以成為可操作、可稽核、可逐步逼近的研究對象。

---

# 1. 從證明路徑到閉包空間

傳統數學論文通常將研究過程壓縮成：

$$
A_0
\Rightarrow
A_1
\Rightarrow
\cdots
\Rightarrow
Q.
$$

失敗的嘗試通常只以敘述方式留下，甚至完全消失。

但長程 AI 數學研究會產生大量：

- theorem candidate；
- lemma；
- assumption；
- proof route；
- representation；
- counterexample；
- obstruction；
- NO-GO；
- survivor；
- conditional theorem；
- bridge；
- failed bridge；
- reopened route；
- repaired theorem；
- descendant problem。

CSM 的第一個轉換是：

$$
\boxed{
\text{Research History}
\longrightarrow
\text{Mathematical State Space}.
}
$$

這個 state space 不只保存答案，而保存「哪些路徑為什麼被打開、被封閉、被條件化、被修復、被商化或被重新開啟」。

---

# 2. 三種空間不得塌縮

對目標命題 $Q$，定義三個層次。

## 2.1 數學可能空間

以：

$$
\Omega^{\rm math}(Q)
$$

表示與 $Q$ 有關的全部數學上可能 proof / counterexample / reduction / representation / mechanism space。

本文不假設它可被有效列舉，也不假設它天然具有唯一圖表示。

## 2.2 可接受路徑空間

在宣告形式域 $D$、證明制度 $\Theta$、語言與 admissibility rule $\mathcal A$ 下：

$$
\Omega^{\rm adm}_{D,\Theta,\mathcal A}(Q)
\subseteq
\Omega^{\rm math}(Q).
$$

它代表在目前問題設定下被認為合法的 proof objects、transformations、reductions 與 certificates。

## 2.3 已觀察研究空間

在搜尋制度 $R$、資源上限 $N$、歷史 $H$ 下：

$$
\Omega^{\rm obs}_{R,N,H}(Q).
$$

它是實際被研究、抓取、生成、驗證或記錄到的部分。

通常只能假設：

$$
\Omega^{\rm obs}_{R,N,H}(Q)
\subseteq
\Omega^{\rm adm}_{D,\Theta,\mathcal A}(Q),
$$

而不能反向假設兩者相等。

因此 CSM 的基礎非塌縮是：

$$
\boxed{
\Omega^{\rm obs}
\neq
\Omega^{\rm adm}
\neq
\Omega^{\rm math}
}
$$

除非另有獨立證書建立等價。

---

# 3. 相對全域，而不是絕對全域

CSM 使用「相對全域」是刻意的。

定義：

$$
\mathfrak C^{\rm rel}_{D,\Theta,\mathcal A,R,N,H}(Q)
$$

為在指定 domain、proof regime、admissibility rule、搜尋制度、資源與歷史下，經過 audited quotient 與 certified closure actions 所得到的 closure-space state。

其中「global」表示：

> 對**宣告作用域內目前可接受且被閉包程序覆蓋的全部結構**做全域化整合。

它不表示：

$$
\mathfrak C^{\rm rel}
=
\Omega^{\rm math}(Q).
$$

因此：

$$
\boxed{
\text{Relative Globality}
\neq
\text{Absolute Completeness}.
}
$$

---

# 4. Globality Typing Principle

「global」不是單一布林值。

對任何 claim $Q$，定義 scope / globality vector：

$$
\mathsf{GScope}(Q)
=
\left\langle
G_t,
G_x,
G_{\rm eq},
G_{\rm sol},
G_{\rm data},
G_{\rm bdry},
G_{\rm force},
G_{\rm reg},
G_{\rm rep},
G_{\rm phys},
G_{\rm proof}
\right\rangle.
$$

各軸至少表示：

- $G_t$：時間範圍；
- $G_x$：空間域；
- $G_{\rm eq}$：方程／模型族；
- $G_{\rm sol}$：solution notion；
- $G_{\rm data}$：initial / boundary data class；
- $G_{\rm bdry}$：boundary family；
- $G_{\rm force}$：forcing family；
- $G_{\rm reg}$：regularity class；
- $G_{\rm rep}$：representation family；
- $G_{\rm phys}$：physical realization / interpretation domain；
- $G_{\rm proof}$：proof system / admissibility regime。

因此：

$$
\boxed{
\text{Global-in-time}
\not\Rightarrow
\text{Global-across-equations}.
}
$$

$$
\boxed{
\text{Global-across-equations}
\not\Rightarrow
\text{Global-across-physical-realizations}.
}
$$

任何未標記 scope vector 的「全域」主張，在 CSM 中至少屬於：

$$
\mathsf{ILL\_SCOPED}.
$$

---

# 5. CSM 的基本物件

第一版 closure space 定義為：

$$
\boxed{
\mathfrak C
=
\left\langle
D,
V,
E,
\tau_V,
\tau_E,
\sim,
\preceq,
\sigma,
\mathfrak O,
\partial\mathfrak C,
\mathsf{Cert},
\mathsf{Debt},
\mathsf{Ledger}
\right\rangle.
}
$$

其中：

- $D$：declared mathematical domain；
- $V$：typed nodes；
- $E$：typed edges / hyperedges；
- $\tau_V$：node type；
- $\tau_E$：edge type；
- $\sim$：audited equivalence / quotient family；
- $\preceq$：strength / refinement preorder；
- $\sigma$：epistemic / closure status；
- $\mathfrak O$：closure action family；
- $\partial\mathfrak C$：active frontier；
- $\mathsf{Cert}$：proof / bridge / closure certificates；
- $\mathsf{Debt}$：尚未支付的 proof obligations；
- $\mathsf{Ledger}$：versioned research history。

---

# 6. 為什麼使用 typed hypergraph

普通 graph 的 edge 通常只有一個 source 和一個 target。

但數學推導常是：

$$
A_1\land A_2\land A_3
\Rightarrow
Q.
$$

因此 canonical edge 應允許：

$$
e:
\{v_1,\ldots,v_k\}
\longrightarrow
v'.
$$

同時不同 edge 具有不同語義。

第一版 edge type：

$$
\tau_E(e)
\in
\{
\mathsf{IMPLIES},
\mathsf{DEPENDS},
\mathsf{CONTRADICTS},
\mathsf{GENERALIZES},
\mathsf{SPECIALIZES},
\mathsf{REFINES},
\mathsf{WEAKENS},
\mathsf{REPRESENTS},
\mathsf{BRIDGES},
\mathsf{BLOCKS},
\mathsf{REOPENS},
\mathsf{INHERITS},
\mathsf{REPAIRS},
\mathsf{WITNESSES},
\mathsf{FALSIFIES},
\mathsf{TRANSFERS}
\}.
$$

不同 edge 不得因為圖上都畫成箭頭就被當成同一種 implication。

---

# 7. Node Type System

第一版節點至少包含：

$$
\tau_V(v)
\in
\{
\mathsf{Problem},
\mathsf{Claim},
\mathsf{Assumption},
\mathsf{Lemma},
\mathsf{Construction},
\mathsf{Counterexample},
\mathsf{Representation},
\mathsf{RouteState},
\mathsf{Obstruction},
\mathsf{Basin},
\mathsf{Bridge},
\mathsf{Domain},
\mathsf{Certificate},
\mathsf{Debt},
\mathsf{Boundary}
\}.
$$

CSM 不把 paper file 當作基本數學節點。

artifact 是 provenance container；真正運算的單位是其中的 typed mathematical objects。

---

# 8. Closure status type system

定義：

$$
\sigma(v)
\in
\{
\mathsf{OPEN},
\mathsf{CLOSED}^{+},
\mathsf{CLOSED}^{-},
\mathsf{BLOCKED},
\mathsf{CONDITIONAL},
\mathsf{UNKNOWN},
\mathsf{INDEPENDENT}_{\mathcal T}
\}.
$$

## 8.1 Positive closure

$$
\mathsf{CLOSED}^{+}
$$

表示指定 claim 已有作用域內有效證明證書。

## 8.2 Negative closure

$$
\mathsf{CLOSED}^{-}
$$

表示 claim 已被反例、矛盾證明或 theorem-level no-go 排除。

## 8.3 Blocked

$$
\mathsf{BLOCKED}
$$

是 route-level / mechanism-level 狀態：

> 在目前 assumptions、representation、bridge 與 theorem set 下，這條路無法完成指定升格。

它不等於：

$$
\mathsf{CLOSED}^{-}.
$$

## 8.4 Conditional

$$
\mathsf{CONDITIONAL}
$$

表示：

$$
A_1\land\cdots\land A_k
\Rightarrow
Q
$$

已證，但至少一個 $A_i$ 仍未閉合。

## 8.5 Relative independence

$$
\mathsf{INDEPENDENT}_{\mathcal T}
$$

只可用於已明確指定 formal theory $\mathcal T$ 且有獨立性證明的情況。

「AI 一直失敗」不是 independence certificate。

---

# 9. Closure 不只一種

CSM 將 closure 拆成多個 typed action，而不是預設只有一個 $\operatorname{Cl}$。

第一版：

$$
\mathfrak O
=
\{
\mathsf{Cl}_{\rm imp},
\mathsf{Cl}_{\rm dep},
\mathsf{Cl}_{\rm quot},
\mathsf{Cl}_{\rm obs},
\mathsf{Cl}_{\rm bridge},
\mathsf{Cl}_{\rm gen},
\mathsf{Cl}_{\rm cert}
\}.
$$

這些 action 可以互相作用，但不預設同型。

---

# 10. Implication Closure

給定節點集合 $S$，若存在已驗證 implication hyperedge：

$$
\{v_1,\ldots,v_k\}
\Rightarrow
v',
$$

且：

$$
\{v_1,\ldots,v_k\}
\subseteq
S,
$$

則：

$$
v'
\in
\mathsf{Cl}_{\rm imp}(S).
$$

但 implication closure 只傳播已證 implication。

它不得把：

- semantic similarity；
- empirical correlation；
- heuristic plausibility；
- representation proximity；

當成 implication edge。

---

# 11. Dependency Closure

若 claim $Q$ 依賴：

$$
A_1,\ldots,A_k,
$$

則 dependency closure 保存：

$$
\operatorname{Dep}(Q)
=
\{A_1,\ldots,A_k\}
$$

及其遞歸祖先。

如果上游 assumption 被反證，descendant claim 不應被自動刪除，而應進入：

$$
\mathsf{REQUIRES\_DESCENDANT\_AUDIT}.
$$

因為某些 descendant 可能存在獨立重證或更弱的 surviving formulation。

---

# 12. Quotient Closure

LSI-PSD 已指出 raw artifact count 不等於 route count。

CSM 定義多種 equivalence relation：

$$
\sim_{\rm prop},
\qquad
\sim_{\rm route},
\qquad
\sim_{\rm obs},
\qquad
\sim_{\rm evid},
\qquad
\sim_{\rm rep}.
$$

因此：

$$
\mathsf{Cl}_{\rm quot}
$$

不是「刪掉重複」，而是建立 quotient classes 同時保留原始 provenance。

核心規則：

$$
\boxed{
\text{Mathematical Redundancy}
\not\Rightarrow
\text{Search-Dynamical Redundancy}.
}
$$

---

# 13. Obstruction Closure

設 $O$ 是某 route family 上已證 obstruction。

最危險的錯誤是：

$$
O(R_1)
\Rightarrow
O(R_2)
$$

只因兩者「看起來類似」。

CSM 要求 obstruction transfer certificate：

$$
\mathsf{ObsTransferCert}
(O,R_1\to R_2).
$$

證書至少說明：

- target statement 是否一致；
- assumptions 是否包含；
- obstruction mechanism 是否 invariant；
- representation change 是否保真；
- domain 是否相容；
- bridge 是否 sound；
- counterexample 是否被排除。

只有如此，$\mathsf{Cl}_{\rm obs}$ 才能把 barrier 合法地傳播到 descendant route。

---

# 14. Bridge Closure

跨 domain、representation、proof system 或 model class 的升格必須透過 bridge。

一般形式：

$$
X
\xrightarrow{\mathsf{BridgeCert}}
Y.
$$

CSM 不固定 bridge backend。

它可以由：

- equivalence theorem；
- reduction；
- interpretation；
- conservative extension；
- functor / morphism；
- lifting theorem；
- model correspondence；
- asymptotic limit theorem；

實現。

但沒有 bridge certificate 時：

$$
\boxed{
\text{Similarity}
\not\Rightarrow
\text{Transfer Permission}.
}
$$

---

# 15. Generative Closure of Research States

受到 UCT generative closure 啟發，CSM 定義 proof-state generative closure：

$$
\operatorname{GenCl}^{\rm proof}_{D,T}
(S\mid\Theta).
$$

它表示：

> 從目前 state $S$，在指定 operators、admissibility rules、resources 與 proof regime 下，可合法生成的研究／證明狀態族。

它包含：

- theorem descendants；
- refined assumptions；
- alternative representations；
- counterexample targets；
- bridge candidates；
- obstruction descendants；
- reopened routes。

但：

$$
\boxed{
\operatorname{GenCl}^{\rm proof}
\neq
\Omega^{\rm math}(Q).
}
$$

生成能力不是數學可能性的完備證明。

---

# 16. Closure-on-Closure Dynamics

研究空間會因新證明、新反例、新 bridge、新 representation 而改變。

定義：

$$
\mathfrak C_{t+1}
=
\mathfrak U_t
\left(
\mathfrak C_t,
 e_t
\right),
$$

其中 $e_t$ 可以是：

- theorem certification；
- counterexample；
- obstruction proof；
- assumption revision；
- quotient merge / split；
- bridge creation / invalidation；
- domain refinement；
- route reopen；
- target rewrite。

因此 CSM 的 closure 是**動態版本化閉包**，不是永遠不可改的塗黑節點。

---

# 17. Reopening Principle

一條 route 在 $t$ 時刻可能：

$$
\sigma_t(R)=\mathsf{BLOCKED}.
$$

但若之後：

- assumption 改變；
- representation 改變；
- 新 theorem 出現；
- obstruction 的適用條件被削弱；
- 新 bridge 建立；

則可存在：

$$
\sigma_{t+1}(R)=\mathsf{OPEN}.
$$

因此：

$$
\boxed{
\text{Research-Route Blockage is not generally monotone.}
}
$$

這和 theorem truth status 必須分開。

---

# 18. Theorem Closure 與 Search Closure 的不同單調性

若 $Q$ 已在固定 formal system 中有有效證明，且後續只是 conservative extension，則其 proof certificate 可以保持有效。

但 search closure 可能被重新打開。

所以 CSM 區分：

$$
\mathsf{LogicalClosure}
$$

與：

$$
\mathsf{SearchClosure}.
$$

前者處理 theorem validity；後者處理目前 route family 是否仍有研究價值與可達性。

兩者不得塌縮。

---

# 19. Frontier

定義 active frontier：

$$
\partial\mathfrak C(Q)
$$

為目前與目標 $Q$ 有關，且至少滿足下列一項的節點／route classes：

- 尚未被正閉包；
- 尚未被負閉包；
- 有合法 incoming / outgoing proof transition；
- conditional premise 尚未解決；
- obstruction 尚未 transferable；
- bridge debt 尚未支付；
- representation completeness 未建立。

但 raw frontier size 沒有意義。

因此定義 quotient frontier：

$$
\boxed{
\partial^{\ast}\mathfrak C(Q)
=
\partial\mathfrak C(Q)
/\sim_{\rm route,obs}.
}
$$

真正需要縮小的是 audited frontier classes，而不是文件數量。

---

# 20. Closure Debt

任何 closure claim 都可以帶有 debt vector：

$$
\mathsf{Debt}(Q)
=
\left
\langle
\delta_{\rm assumption},
\delta_{\rm bridge},
\delta_{\rm quotient},
\delta_{\rm witness},
\delta_{\rm obstruction},
\delta_{\rm representation},
\delta_{\rm completeness},
\delta_{\rm domain},
\delta_{\rm verification}
\right\rangle.
$$

其中最重要的是：

$$
\delta_{\rm completeness}.
$$

只要 route completeness 尚未建立，就不能把 relative-global route closure 升成 absolute theorem closure。

---

# 21. Route-Completeness Certificate

定義：

$$
\boxed{
\mathsf{RCCert}
(Q;D,\Theta,\mathcal A)
}
$$

為 route-completeness certificate。

最低 obligation：

1. 明確定義 admissible route grammar；
2. 證明所有指定 mechanism class 都可被 grammar 表示；
3. 證明 quotient 不會合併非等價 route；
4. 證明 representation family 的 completeness 或給出作用域限制；
5. bridge family 完備或明確限制；
6. obstruction transfer soundness；
7. target fidelity；
8. formal verification / independent proof witness；
9. 對未覆蓋 route class 明確記 debt。

沒有 $\mathsf{RCCert}$，禁止：

$$
\text{all observed routes blocked}
\Rightarrow
\text{all mathematical routes blocked}.
$$

---

# 22. Relative-Global Closure Grade

第一版定義：

### RGC-0 — Ill-Typed

scope、target 或 node/edge typing 不完整。

### RGC-1 — Local Closure

單一 lemma、route segment 或 local mechanism 已閉。

### RGC-2 — Basin Closure

某 quotient-aware proof basin 內的 active frontier 已閉，但 basin 外仍未知。

### RGC-3 — Observed Relative-Global Closure

在宣告 corpus / regime 的 audited quotient space 中，所有已觀察 frontier 已閉。

### RGC-4 — Admissible Relative-Global Closure Candidate

存在 route/decomposition completeness certificate，使指定 admissible mechanism space 被覆蓋並閉合。

即使 RGC-4，也只相對：

$$
(D,\Theta,\mathcal A).
$$

因此：

$$
\boxed{
\mathsf{RGC4}
\not\Rightarrow
\text{absolute mathematical completeness}.
}
$$

---

# 23. Closure Proof Principle

CSM 不否定傳統一條成功 proof path 的證明形式。

如果有：

$$
P:
A_0\Rightarrow\cdots\Rightarrow Q
$$

且 proof verifier 接受，則 $Q$ 可以正閉包。

CSM 新增的是另一類研究結構：

> 若 target 的失敗／反例／奇點形成機制能被證明具有一個完備 decomposition，而 decomposition 的每一個 branch 都被 theorem-level obstruction 封閉，則可以由 closure-space exhaustion 形成一個新的 proof route。

但關鍵仍是：

$$
\boxed{
\text{Exhaustion Proof}
=
\text{Complete Decomposition}
+
\text{Certified Branch Closures}.
}
$$

只有「我們想到的 branch 都死了」不夠。

---

# 24. No-Premature-Closure Principle

任何 node 不得因下列理由被提升成 $\mathsf{CLOSED}^{-}$：

- 搜尋不到新路；
- 多模型都失敗；
- novelty 很低；
- basin recurrence 很高；
- 文章數很多；
- obstruction confluence 很高；
- 某 representation 長期失敗。

正確狀態最多是：

$$
\mathsf{BLOCKED},
\quad
\mathsf{SATURATED}_{\rm rel},
\quad
\mathsf{UNKNOWN}.
$$

這是 CSM 的 epistemic firewall。

---

# 25. No-Premature-Quotient Principle

兩個 route 只有在足夠條件下才能 quotient。

若：

$$
R_1
\sim_{\rm semantic}
R_2
$$

但 representation 對 prover / theorem backend 的成功率不同，則：

$$
[R_1]_{\rm math}
=
[R_2]_{\rm math}
$$

仍可以同時有：

$$
[R_1]_{\rm search}
\neq
[R_2]_{\rm search}.
$$

所以 CSM 維持多層 quotient。

---

# 26. Theorem-Strength and Route-Refinement Order

若：

$$
Q_1\Rightarrow Q_2,
$$

但：

$$
Q_2\not\Rightarrow Q_1,
$$

定義：

$$
Q_1\succeq Q_2.
$$

同理，若 route $R_2$ 包含 $R_1$ 的全部合法步驟並額外處理更一般條件，可寫：

$$
R_1\preceq R_2.
$$

因此 closure space 同時包含 quotient classes 與 partial/refinement order。

它不是單純 cluster graph。

---

# 27. Obstruction Confluence in CSM

如果多條真正不同的 route：

$$
[R_i]_{\rm route}
\neq
[R_j]_{\rm route}
$$

但都被歸約到同一 audited obstruction class：

$$
[O(R_i)]_{\rm obs}
=
[O^{\star}]_{\rm obs},
$$

則形成 obstruction confluence。

但：

$$
\boxed{
\text{High Confluence}
\not\Rightarrow
\text{Absolute Barrier}.
}
$$

它只是提高該 obstruction 成為下一個研究對象的優先度。

---

# 28. Closure-Space Ledger

每一次狀態改變必須寫入：

$$
\mathsf{Ledger}_t.
$$

最低事件欄位：

$$
\mathsf{Event}
=
\left\langle
\mathsf{id},
\mathsf{time},
\mathsf{source},
\mathsf{target},
\mathsf{operation},
\mathsf{assumptions},
\mathsf{before},
\mathsf{after},
\mathsf{certificate},
\mathsf{debt},
\mathsf{version}
\right\rangle.
$$

所以：

- theorem repair；
- obstruction invalidation；
- route reopen；
- quotient split；
- target rewrite；

都可追溯。

---

# 29. CSM 與 Proof-Space Observatory 的差異

Proof-Space Observatory 的角色是：

$$
\boxed{
\text{Observe, measure, replay, and route research space}.
}
$$

CSM 的角色是：

$$
\boxed{
\text{Define closure-space objects and the mathematics of their legal evolution}.
}
$$

因此：

$$
\text{PSO}
\subseteq
\text{possible CSM instrumentation backends},
$$

但：

$$
\text{CSM}
\neq
\text{PSO software specification}.
$$

---

# 30. CSM 與 UCT 的關係

UCT 建立：

$$
\operatorname{GenCl},
\qquad
\mathsf{Reach},
\qquad
\operatorname{TransCl},
\qquad
\mathsf{BridgeCert},
\qquad
\mathsf{Debt},
\qquad
\mathsf{Ledger}.
$$

CSM 將這些概念投影到數學研究域，但不宣稱它們完全同構。

主要對照：

$$
\operatorname{GenCl}
\rightsquigarrow
\operatorname{GenCl}^{\rm proof},
$$

$$
\mathsf{Reach}
\rightsquigarrow
\text{proof-state / theorem-state reachability},
$$

$$
\operatorname{TransCl}
\rightsquigarrow
\text{legal proof-state transformations},
$$

$$
\mathsf{BridgeCert}
\rightsquigarrow
\text{cross-domain / cross-representation transfer certificates}.
$$

CSM 保持：

$$
\boxed{
\text{Analogy}
\neq
\text{Identity}.
}
$$

---

# 31. Navier--Stokes 的三域分離

CSM 的第一個大型實驗場是 Navier--Stokes。

定義三個不同 target domain。

## 31.1 Formal Clay / Mathematical NS

記為：

$$
\mathfrak N_{\rm C}.
$$

它代表固定 mathematical formulation 下的 Navier--Stokes existence / smoothness 類 target。

重點是：

$$
\text{equation},
\quad
\text{dimension},
\quad
\text{domain},
\quad
\text{data class},
\quad
\text{solution notion},
\quad
\text{regularity target}
$$

都被型別化。

## 31.2 Physical NS Realization Domain

記為：

$$
\mathfrak N_{\rm P}.
$$

它處理數學模型與實際物理流體、近似、尺度、可測量量、constitutive assumptions、有效理論範圍之間的 correspondence。

因此：

$$
\boxed{
\operatorname{Prove}(\mathfrak N_{\rm C})
\not\Rightarrow
\operatorname{Prove}(\mathfrak N_{\rm P}).
}
$$

這不是否定 mathematical NS，而是拒絕把 formal theorem 自動升格成全部物理現實。

## 31.3 Generalized NS-Like Equation Family

記為：

$$
\mathfrak N_{\rm G}^{\Sigma}.
$$

其中 $\Sigma$ 是 family signature。

第一版只要求 $\Sigma$ 可以宣告：

- transport / advection operator；
- incompressibility 或 generalized constraint；
- diffusion / dissipation operator；
- pressure / projection / nonlocal coupling；
- nonlinear interaction order；
- forcing；
- domain / boundary；
- scale-transfer structure；
- solution / regularity class。

形式上可寫：

$$
\mathcal E
\in
\mathfrak N_{\rm G}^{\Sigma}
$$

若 $\mathcal E$ 滿足 signature predicate：

$$
\Sigma(\mathcal E)=1.
$$

這仍是**相對 generalized family**，不是「所有流體方程」或「所有物理 PDE」。

---

# 32. NS Globality Non-Collapse

因此：

$$
\boxed{
\operatorname{Prove}(\mathfrak N_{\rm C})
\not\Rightarrow
\operatorname{Prove}(\mathfrak N_{\rm G}^{\Sigma}).
}
$$

同樣：

$$
\boxed{
\operatorname{Prove}(\mathfrak N_{\rm G}^{\Sigma})
\not\Rightarrow
\operatorname{Prove}(\mathfrak N_{\rm P}).
}
$$

除非有額外 bridge。

所以 NS 領域圖應寫成 typed graph，而不是簡單集合包含：

$$
\mathfrak N_{\rm C}
\xrightarrow{\mathsf{GeneralizationBridge}}
\mathfrak N_{\rm G}^{\Sigma},
$$

以及：

$$
\mathfrak N_{\rm C}
\xleftrightarrow[\mathsf{Idealization}]
{\mathsf{Interpretation}}
\mathfrak N_{\rm P}.
$$

每條 edge 需要獨立 certificate。

---

# 33. 為什麼 Clay NS 看似全域卻仍是限縮的

Clay-type global regularity 中的「global」主要針對固定 formulation 的時間延拓與 solution regularity。

其 scope 很大，但仍然固定了：

- equation family；
- dimension；
- incompressibility；
- viscosity regime；
- domain / boundary alternatives；
- solution notion；
- data assumptions。

因此：

$$
\boxed{
\text{Large Scope}
\neq
\text{Unbounded Scope}.
}
$$

更重要的是：

$$
\boxed{
\text{Global in one scope axis}
\neq
\text{Global in every scope axis}.
}
$$

這是 CSM 對「全域」一詞的第一個形式化修正。

---

# 34. NS Relative-Global Closure Space

定義：

$$
\boxed{
\mathfrak C_{\rm NS}^{\rm rel}
}
$$

為 Navier--Stokes 研究的相對全域閉包空間。

第一版資料來源可包含：

- ETN--X Integration；
- C1 / C2；
- C3--C6；
- X72；
- DCRP；
- RFP；
- MORP；
- FCBP；
- Proof Asset Map；
- theorem-check scripts；
- external theorem anchors；
- later corrections and supersessions。

但這些 artifact 必須先拆成 typed objects 後才能進圖。

---

# 35. NS 中「封路」的新含義

假設一篇研究得到：

$$
\text{scalar additive budget}
\not\Rightarrow
\text{blow-up exclusion}.
$$

CSM 不把整個 Navier--Stokes target 標成失敗。

它只在對應 route class 上建立：

$$
O_{\rm scalar-budget}.
$$

並將：

$$
\sigma(R_{\rm scalar})
=
\mathsf{BLOCKED}
$$

或在 theorem-level counterexample 足夠時：

$$
\sigma(Q_{\rm scalar-sufficiency})
=
\mathsf{CLOSED}^{-}.
$$

其他 route 不受影響，除非 obstruction-transfer certificate 成立。

---

# 36. Survivor 不是失敗，而是 frontier compression

NS C3--C6、X72、DCRP 中大量結果最後不是 theorem completion，而是：

$$
R_1\vee R_2\vee\cdots\vee R_k
\longrightarrow
S_1\vee\cdots\vee S_m,
\qquad
m<k.
$$

CSM 將這種結果定義為：

$$
\boxed{
\text{Frontier Compression}.
}
$$

若 compression 有 theorem-level proof，則它本身是正的數學資產。

即使最終 target 尚 OPEN，frontier volume / complexity 已被縮小。

---

# 37. Closure Volume 不等於節點數

令 raw frontier 有：

$$
N
$$

個節點。

若 quotient 後只有：

$$
N_{\rm eff}
$$

個獨立 route / obstruction classes，則真正 closure-space size 應基於：

$$
N_{\rm eff},
$$

而不是 $N$。

未來可研究：

$$
\operatorname{Vol}_{\rm CSM}
\left(
\partial^{\ast}\mathfrak C
\right),
$$

但本文不預設存在唯一自然測度。

---

# 38. Closure Density 與 Saturation

局部 basin $B$ 可以具有高 closure density：

$$
\rho_{\rm cl}(B)
=
\frac{
\text{audited closed classes}
}{
\text{audited reachable classes}
}.
$$

但：

$$
\boxed{
\rho_{\rm cl}(B)\to1
\not\Rightarrow
\Omega^{\rm math}(Q)=B.
}
$$

因此 saturation 仍只能是 relative observational state，除非 completeness certificate 介入。

---

# 39. Closure Boundary as Research Target

在 CSM 中，研究下一步不再單純選「最新 paper 的 TODO」。

可以對：

$$
\partial^{\ast}\mathfrak C(Q)
$$

做 priority ranking。

候選 priority function：

$$
\mathsf{Priority}(v)
=
F
\left(
\mathsf{Centrality},
\mathsf{Confluence},
\mathsf{DependencyMass},
\mathsf{BridgePotential},
\mathsf{DebtReduction},
\mathsf{ReopenGain}
\right).
$$

這樣 AI 可以選擇：

> 哪一個 boundary node 一旦閉合，會封掉最多 descendant space 或打開最多新的合法 route。

---

# 40. Closure as a Search Strategy

CSM 的研究策略可以從：

$$
\text{find one promising path}
$$

升級成：

$$
\boxed{
\text{maximize certified closure gain per unit research cost}.
}
$$

但 cost / gain 仍是研究制度參數，不是數學真理本身。

---

# 41. Minimum Closure Certificate

任何 closure event 至少攜帶：

```yaml
closure_id:
target_id:
closure_type:
domain:
scope_vector:
assumptions:
source_nodes:
source_edges:
proof_or_counterexample:
bridge_dependencies:
quotient_policy:
status_before:
status_after:
remaining_debt:
provenance:
version:
```

若 closure type 是 `BLOCKED`，必須額外標：

```yaml
block_scope:
reopen_conditions:
transferability:
```

避免把暫時 blockage 偽裝成 permanent no-go。

---

# 42. Minimum Route Record

```yaml
route_id:
problem_id:
domain:
start_state:
target_state:
assumptions:
representation:
method_family:
steps:
bridge_ids:
obstruction_ids:
survivor_ids:
status:
refinement_parent:
quotient_class:
certificates:
debt:
provenance:
```

---

# 43. Minimum Domain Record

```yaml
domain_id:
name:
equation_or_target_family:
space_dimension:
spatial_domain:
time_scope:
data_class:
solution_class:
regularity_target:
boundary_conditions:
forcing_class:
representation_scope:
physical_interpretation_scope:
admissibility_rules:
proof_regime:
parent_domains:
bridge_ids:
```

---

# 44. CSM 核心公理 / 規範 v0.1

## CSM-A1 — Typed Node Principle

不同數學角色不得只因都出現在研究文本中而被視為同型節點。

## CSM-A2 — Typed Edge Principle

implication、dependency、representation、bridge、block 與 contradiction 不得塌縮。

## CSM-A3 — Relative Globality Principle

任何 global closure 都相對 declared scope，除非另有 absolute-completeness proof。

## CSM-A4 — No Premature Promotion

observational evidence 不得無證升格為 theorem closure。

## CSM-A5 — No Premature Quotient

semantic similarity 不得無證升格為 mathematical equivalence。

## CSM-A6 — Provenance Preservation

任何 quotient / closure / repair 後都必須可追溯回原始 evidence。

## CSM-A7 — Blockage Non-Finality

route blockage 不是 proposition falsehood，且可被合法 reopen。

## CSM-A8 — Bridge Explicitness

跨 domain / representation / model 的 transfer 必須有 bridge certificate。

## CSM-A9 — Completeness Debt Preservation

未建立 route / decomposition completeness 時，relative closure 不得冒充 absolute closure。

## CSM-A10 — Globality Typing

任何 global claim 必須附 scope vector 或等價的 domain declaration。

## CSM-A11 — Closure Non-Collapse

不同 closure action 不預設互推或同構。

## CSM-A12 — Ledgered Dynamics

closure-space state change 必須 versioned and auditable。

---

# 45. 第一批可證命題

以下為 CSM v0.1 的結構性命題，並非深層新數學定理。

## Proposition 45.1 — Observed Closure Non-Completeness

若：

$$
\Omega^{\rm obs}
\subsetneq
\Omega^{\rm adm},
$$

則：

$$
\mathsf{Closed}(\Omega^{\rm obs})
\not\Rightarrow
\mathsf{Closed}(\Omega^{\rm adm}).
$$

這是集合包含直接導出的 epistemic firewall。

## Proposition 45.2 — Quotient Preservation Requirement

若 quotient map：

$$
q:\Omega\to\Omega/\sim
$$

不保留 target-relevant assumptions 或 theorem strength，則 quotient closure 不能作為 target closure 的 sound certificate。

## Proposition 45.3 — Bridge-Soundness Requirement

若 $X$ 到 $Y$ 的 closure claim 使用 bridge $B$，但 $B$ 未證 sound，則 $Y$ 的 closure status 至少保留 bridge debt。

## Proposition 45.4 — Blockage Reopening Possibility

若 blockage proof 依賴 assumption set $A$，而新的 route $R'$ 不滿足 $A$，則舊 blockage 不能無證 transfer 到 $R'$。

## Proposition 45.5 — Relative-Global Closure Bound

任何：

$$
\mathfrak C^{\rm rel}_{D,\Theta,\mathcal A,R,N,H}(Q)
$$

的 claim strength 不得超過其 domain、bridge、completeness 與 verification certificates 的共同強度。

---

# 46. NS 的第一個 Closure-Space Research Program

第一版 NS 實驗不直接追求「把 203 篇全部畫成圖」。

應依序：

1. 固定 $\mathfrak N_{\rm C}$ formal target；
2. 建 $\mathfrak N_{\rm P}$ 與 $\mathfrak N_{\rm G}^{\Sigma}$ 的 domain records；
3. 對既有 corpus 抽取 Claim / Assumption / Lemma / Route / Obstruction / Survivor；
4. 建 $\sim_{\rm prop}$、$\sim_{\rm route}$、$\sim_{\rm obs}$；
5. 建 implication DAG；
6. 建 route hypergraph；
7. 建 obstruction transfer edges；
8. 對 C1--C6、X72、DCRP 等建立 lineage；
9. 標記 CLOSED+, CLOSED-, BLOCKED, CONDITIONAL, OPEN；
10. 計算 quotient frontier；
11. 找 closure-central nodes；
12. 逐一研究高 closure-gain targets；
13. 每次閉合後重新計算整個相對全域圖。

這就是：

$$
\boxed{
\text{Solve by iterative certified closure of a relative-global proof space.}
}
$$

---

# 47. 與傳統「找證明」的互補關係

CSM 不主張未來數學都要用 closure-space exhaustion。

某些問題仍可能因一個漂亮 lemma 直接完成。

CSM 的價值主要出現在：

- proof space 極大；
- 研究歷史很長；
- failure / obstruction 很多；
- 多 representation 並存；
- 多 agent / 多工具並行；
- route 重訪頻繁；
- no-go 與 survivor 可重用；
- target 本身存在多 domain / scope interpretation。

NS 正是這類實驗場。

---

# 48. CSM 的真正長期問題

CSM 最終不是只問：

> 哪些 route 已經走過？

而是問：

1. closure-space 是否存在穩定的 quotient geometry？
2. obstruction 是否有可組合的 transfer algebra？
3. frontier 是否存在可證的壓縮率？
4. completeness certificate 在哪些數學領域可能實現？
5. 某些 theorem 是否可以被重寫成 finite / transfinite closure problem？
6. closure actions 是否在特定子類形成 lattice / category / fixed-point structure？
7. closure-space dynamics 是否存在 invariant、attractor 或 recurrent basin？
8. 是否能證明某些 proof domains 的 route grammar 完備？
9. 是否存在「閉包本身的閉包」與 meta-closure hierarchy？
10. CSM 是否能從研究方法論進一步形成可重用的形式數學工具？

這些都是後續 Paper 01+ 的主題。

---

# 49. 建議系列結構

CSM 第一輪建議：

- **Paper 00**：Formal Foundations；
- **Paper 01**：Globality Typing and Domain Stratification；
- **Paper 02**：Typed Route Hypergraphs and Quotient Geometry；
- **Paper 03**：Obstruction Closure, Transfer and Reopening；
- **Paper 04**：Frontier Mathematics and Relative-Global Closure Grades；
- **Paper 05**：Route-Completeness Certificates and Closure Proofs；
- **Paper 06**：Closure-Space Dynamics, Fixed Points and Meta-Closure；
- **NS Application 00**：NS Relative-Global Closure Graph v0.1；
- **NS Application 01**：C1--C6 / X72 / DCRP Closure Reconstruction；
- **Runtime 00**：CSM Graph Builder / Closure Verifier MVP。

Paper numbering can be changed later; this is a proposed research route, not canonical commitment beyond Paper 00.

---

# 50. 結論

CSM 的核心不是把數學研究「畫成圖」。

它要做的是把：

$$
\text{Claim},
\quad
\text{Route},
\quad
\text{Obstruction},
\quad
\text{Bridge},
\quad
\text{Survivor},
\quad
\text{Frontier},
\quad
\text{Closure}
$$

變成可以被數學化操作的 typed objects。

最終研究狀態不是：

$$
\text{we tried many things}.
$$

而是：

$$
\boxed{
\mathfrak C_t
=
\text{the current audited relative-global closure state of the problem}.
}
$$

研究下一步也不再只是「再想一條路」，而是：

$$
\boxed{
\text{select the frontier operation with the highest certified closure value}.
}
$$

但整個框架始終保留最後一道防火牆：

$$
\boxed{
\text{Relative-Global Closure}
\neq
\text{Absolute Mathematical Completeness}.
}
$$

只有當 route / decomposition completeness 本身成為可證定理，closure-space exhaustion 才能被提升為真正的 exhaustive proof mechanism。

對 Navier--Stokes 而言，這意味著過去所有被封住的路線、NO-GO、survivor 與 OPEN 不再是研究廢料，而是第一個大型 closure space 的結構材料。

---

# 附錄 A：核心符號

| Symbol | Meaning |
|---|---|
| $Q$ | target problem / theorem |
| $D$ | declared mathematical domain |
| $\Theta$ | proof / reasoning regime |
| $\mathcal A$ | admissibility rules |
| $R$ | search regime |
| $N$ | resource / sampling bound |
| $H$ | research history |
| $\Omega^{\rm math}$ | mathematical possibility space |
| $\Omega^{\rm adm}$ | admissible route space |
| $\Omega^{\rm obs}$ | observed research space |
| $\mathfrak C^{\rm rel}$ | relative-global closure space |
| $V$ | typed node set |
| $E$ | typed edge / hyperedge set |
| $\tau_V$ | node typing function |
| $\tau_E$ | edge typing function |
| $\sim$ | quotient relations |
| $\preceq$ | theorem / route refinement order |
| $\sigma$ | closure / epistemic status |
| $\mathfrak O$ | closure action family |
| $\partial\mathfrak C$ | active frontier |
| $\partial^{\ast}\mathfrak C$ | quotient frontier |
| $\mathsf{Debt}$ | outstanding proof obligations |
| $\mathsf{Ledger}$ | versioned closure history |
| $\mathsf{RCCert}$ | route-completeness certificate |
| $\mathsf{GScope}$ | typed globality / scope vector |
| $\mathfrak N_{\rm C}$ | formal Clay / mathematical NS domain |
| $\mathfrak N_{\rm P}$ | physical NS realization domain |
| $\mathfrak N_{\rm G}^{\Sigma}$ | generalized NS-like family under signature $\Sigma$ |

---

# 附錄 B：內部理論血統

本篇形式設計主要承接下列既有內部研究資產：

1. **LSI-PSD / Logic-Space Integration and Proof-Space Dynamics**：semantic quotient、route graph、proof basin、obstruction confluence、theorem-strength preorder、Proof-Space Observatory、epistemic firewall。
2. **UGC/CUR / Unified Closure Theory**：typed non-collapse、generative closure、reachability、transformation closure、bridge certificate、debt、ledger、relative-global promotion discipline。
3. **NS ETN--X Integration**：將 Navier--Stokes 研究重寫成 multiscale legality / UV-chain / obstruction program，並保持 formal NS target 與研究語言的分層。
4. **NS C1--C6 / X72 / DCRP**：提供大量已閉、受阻、條件化、survivor 與 reopened proof-state 實例，作為 CSM 第一個大型 closure-space corpus。
5. **Productive Mis-Specification / Descendant Survival line**：parent formulation、model 或 assumption 即使被修正，也不能自動刪除所有 descendant mathematical assets；需要 lineage-aware audit。

這些來源是 CSM 的理論血統，不代表它們彼此完全等價，也不代表 CSM 已完成與外部 graph theory、proof theory、category theory 或 closure algebra 的學術對照。

---

# 附錄 C：下一步

Paper 00 完成後，下一個最重要的理論任務不是立即建立完整 NS 圖，而是先寫：

$$
\boxed{
\textbf{CSM Paper 01 — Globality Typing and Domain Stratification}.
}
$$

因為若不先把「哪一種 global、哪一個 domain、哪些 bridge 可合法跨域」說清楚，後面的 NS Closure Graph 會再次把 Clay mathematical NS、physical realization 與 generalized NS-like family 混在一起。

**END OF CSM PAPER 00 v0.1**
