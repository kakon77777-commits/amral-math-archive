# CSM Paper 00 v0.1

Closure-Space Mathematics formal-foundations package.

Contents:
- `CSM_Paper_00_Closure_Space_Mathematics_Formal_Foundations_v0.1_2026-08-27.md` — canonical paper.
- `CSM_CORE_SCHEMA_v0.1.yaml` — machine-readable core schema.
- `VALIDATION.json` — source validation evidence.

The paper defines relative-global closure, typed globality, typed route/obstruction/bridge spaces, closure debt, reopening, route-completeness certificates, and the three-domain Navier--Stokes separation used by the future NS Relative-Global Closure Graph.
