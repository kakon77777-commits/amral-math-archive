# NS_GSM / CSM Paper 09 Package

This package defines **NS_GSM v0.1**, the first concrete large-domain instantiation of Closure-Space Mathematics.

Contents:
- CSM Paper 09 canonical Markdown;
- NS_GSM domain/schema YAML;
- seed manifest;
- ingestion plan;
- source-basis manifest;
- validation evidence.

`NS_GSM` is kept as the canonical code without inventing an expansion for `GSM`.

The next implementation artifact should be **NS_GSM Seed Dataset v0.1**.
