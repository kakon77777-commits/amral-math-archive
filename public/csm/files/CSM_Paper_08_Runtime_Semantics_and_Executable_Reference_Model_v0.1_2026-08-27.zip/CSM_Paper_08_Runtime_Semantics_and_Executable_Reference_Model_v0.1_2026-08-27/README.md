# CSM Paper 08 Package

Formal specification handoff for **CSM Reference Runtime v0.1**.

Contains:
- canonical Paper 08 Markdown;
- runtime schema;
- conformance vectors;
- validation evidence.

Paper 08 defines runtime state, registries, transaction semantics, replay, query authority, candidate/native separation, and the Navier–Stokes safe-ingestion profile.
