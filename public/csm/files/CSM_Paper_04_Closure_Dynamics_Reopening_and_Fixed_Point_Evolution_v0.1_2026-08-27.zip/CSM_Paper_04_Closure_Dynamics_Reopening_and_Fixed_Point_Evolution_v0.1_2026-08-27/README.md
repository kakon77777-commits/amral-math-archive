# CSM Paper 04 Package

Contains the canonical UTF-8 source for:

**CSM Paper 04 — Closure Dynamics, Reopening, and Fixed-Point Evolution**

This paper extends CSM Papers 00–03 with:
- time-indexed closure states;
- event-sourced update rules;
- schedule dependence and event commutation;
- closure hysteresis;
- reopening waves;
- debt discharge;
- frontier drift;
- relative closure fixed points;
- metastability and closure shocks;
- dynamic exhaustion upgrades/downgrades;
- replay and restoration.

This package remains theory-level. It does not yet instantiate the full NS runtime.
