# CSM Paper 01 Package

This package contains the canonical UTF-8 Markdown source for **CSM Paper 01 — Globality Typing and Domain Stratification**, a machine-readable globality schema, dependency lock, and validation evidence.

The paper extends CSM Paper 00 by turning “globality” into typed quantifier/domain metadata and by separating formal/Clay mathematical Navier–Stokes, physical realization, and signature-parameterized generalized NS-like equation families.

It does **not** claim a proof of Navier–Stokes global regularity or a universal theorem for all NS-like systems.
