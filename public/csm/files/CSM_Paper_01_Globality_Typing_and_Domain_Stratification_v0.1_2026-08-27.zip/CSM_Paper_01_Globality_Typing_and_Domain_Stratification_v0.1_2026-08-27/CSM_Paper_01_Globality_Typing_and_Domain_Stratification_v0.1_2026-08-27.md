# CSM Paper 01
# 全域性型別與命題域分層
## Globality Typing and Domain Stratification in Closure-Space Mathematics

**版本：** v0.1  
**日期：** 2026-08-27  
**系列：** Closure-Space Mathematics / CSM  
**文件地位：** 全域性型別論文 / Domain and Quantifier-Scope Paper  
**Canonical source：** UTF-8 Markdown  
**Canonical math delimiters：** `$...$` 與 `$$...$$`  
**研究狀態：** CSM Paper 00 的直接延伸；建立 globality typing、domain stratification、scope promotion 與 cross-domain proof-transfer 規則。本文不是任何 Navier--Stokes 未解問題的完成證明。

---

# 摘要

「全域」在數學與科學敘述中經常被當成單一強度詞使用，但不同全域主張實際上可能量化於完全不同的軸：時間、空間、初始資料類、邊界條件、forcing、參數、solution notion、regularity class、方程族、表示族、形式證明制度，或物理實現域。若忽略這些差異，就容易把「對固定方程全時間成立」錯誤升格為「對整個方程族成立」，或把「形式 PDE 定理」錯誤升格為「所有物理實現都被證明」。

本文建立 Closure-Space Mathematics（CSM）的 **Globality Typing Principle**。其核心主張是：globality 不是單一布林值，也不是無條件可排序的強度，而是一個帶有量詞作用域、domain signature、solution semantics、representation 與 interpretation metadata 的 typed profile。

本文定義：

$$
\boxed{
\mathsf{ScopeContract}(Q)
=
\left\langle
\mathsf{DomSig}(Q),
\mathsf{Quant}(Q),
\mathsf{Sem}(Q),
\mathsf{Rep}(Q),
\mathsf{ProofReg}(Q)
\right\rangle.
}
$$

並以：

$$
\boxed{
\mathsf{GProf}(Q)
=
\left
\langle
G_t,
G_x,
G_{\rm data},
G_{\rm sol},
G_{\rm bdry},
G_{\rm force},
G_{\rm par},
G_{\rm reg},
G_{\rm eq},
G_{\rm rep},
G_{\rm phys},
G_{\rm proof}
\right
angle
}
$$

表示命題的 globality profile。

本文的第一個非塌縮原則是：

$$
\boxed{
\text{Global-in-time}
\neq
\text{Global-across-data}
\neq
\text{Global-across-equations}
\neq
\text{Global-across-physical-realizations}.
}
$$

第二個原則是：

$$
\boxed{
\text{Theorem Strengthening}
\neq
\text{Scope Expansion}
\neq
\text{Model Extension}.
}
$$

第三個原則是：任何從作用域 $D_1$ 向更廣作用域 $D_2$ 的 theorem promotion，都必須攜帶一個 scope/globality promotion certificate，而不能只因兩個問題具有相似方程、相同名稱或共享局部形式就自動升格。

Navier--Stokes 被用作第一個大型 domain-stratification 實例。本文將 formal/Clay mathematical NS、physical NS realization domain 與 generalized NS-like equation family 分離，並指出 Clay 題目的「global」主要是固定形式問題中的時間全域延拓與指定資料類上的全稱量化；這仍不等於 equation-family globality，也不等於 physical-realization globality。 generalized NS-like family 則必須以明確 signature 參數化，不能把所有「看起來像 NS」的系統混成單一集合。

最後，本文將 globality typing 接回 CSM 的 closure-space frontier：未閉合 frontier 不只要問「哪個命題還 OPEN」，還要問「哪一個 globality axis 尚未被閉合」。因此後續 NS Relative-Global Closure Graph 不再只有 proof-route 邊界，而會包含 **scope frontier**、**family-extension frontier** 與 **interpretation frontier**。

---

# 0. 研究地位與非主張

本文不主張：

1. 「global」存在唯一自然的數值強度；
2. 所有 globality axis 可形成單一 total order；
3. 不同 PDE、不同 solution notion 或不同 physical model 可以只靠名稱相似建立 inclusion；
4. formal mathematical theorem 自動等同 physical truth；
5. generalized NS-like equation family 已有唯一 canonical boundary；
6. Clay Navier--Stokes 題目被重新定義；
7. 本文已證明 Clay Navier--Stokes global regularity；
8. 本文已證明任何 generalized NS-like family 的 universal regularity；
9. physical NS realization 可以被一個單一形式模型完整覆蓋；
10. domain stratification 本身可以取代 theorem-level proof；
11. scope expansion certificate 一定存在；
12. relative-global closure 等於 absolute mathematical completeness。

本文只建立：

- globality 的 typed quantifier semantics；
- domain signature；
- scope contract；
- globality profile；
- scope comparability 與 non-comparability；
- scope restriction / expansion / model extension 的分離；
- cross-domain theorem transfer 的證書條件；
- NS 的第一版三域分層與 generalized family signature；
- scope frontier 與 closure-space 的耦合。

---

# 1. 為什麼「全域」不是一個詞就夠了

考慮兩個敘述：

1. 對固定 PDE，解對所有有限時間存在；
2. 對一整族 PDE，所有成員都具有相同性質。

兩者都可能被自然語言稱為「global」，但其量詞結構完全不同。

第一種更接近：

$$
\forall t\in T,
\qquad
P(u,t),
$$

第二種則是：

$$
\forall E\in\mathcal E,
\qquad
P(E).
$$

如果再加入初始資料：

$$
\forall u_0\in\mathcal D,
\quad
\forall t\in T,
\qquad
P(E,u_0,t),
$$

其作用域又再次改變。

因此 CSM 將「global」從形容詞改造成 **quantifier-scope object**。

---

# 2. Scope Contract

對命題 $Q$，定義：

$$
\boxed{
\mathsf{ScopeContract}(Q)
=
\left\langle
\mathsf{DomSig}(Q),
\mathsf{Quant}(Q),
\mathsf{Sem}(Q),
\mathsf{Rep}(Q),
\mathsf{ProofReg}(Q)
\right\rangle.
}
$$

其中：

- $\mathsf{DomSig}$：方程、空間、時間、資料、邊界、forcing、參數等 domain signature；
- $\mathsf{Quant}$：各軸量詞與 uniformity 要求；
- $\mathsf{Sem}$：solution notion、equality / equivalence、regularity target；
- $\mathsf{Rep}$：使用的表示與 projection；
- $\mathsf{ProofReg}$：形式系統、admissibility、外部 theorem set 與 proof verification regime。

若一個 theorem claim 缺失足以決定作用域的欄位，CSM 記為：

$$
\boxed{
\mathsf{ILL\_SCOPED}.
}
$$

---

# 3. Domain Signature

第一版：

$$
\boxed{
\mathsf{DomSig}(Q)
=
\left\langle
\mathcal E,
\mathcal X,
\mathcal T,
\mathcal D,
\mathcal S,
\mathcal B,
\mathcal F,
\mathcal P,
\mathcal R,
\mathcal I
\right\rangle.
}
$$

其中：

- $\mathcal E$：equation / operator domain；
- $\mathcal X$：spatial domain / geometry；
- $\mathcal T$：time domain；
- $\mathcal D$：initial / admissible data class；
- $\mathcal S$：solution notion；
- $\mathcal B$：boundary family；
- $\mathcal F$：forcing family；
- $\mathcal P$：parameter / coefficient domain；
- $\mathcal R$：regularity / topology / norm target；
- $\mathcal I$：interpretation / realization context。

CSM 不要求所有問題都使用全部欄位，但任何未宣告欄位不能被默認成「對所有可能情形」。

---

# 4. Quantifier Envelope

對每一個 axis $a$，定義：

$$
\mathsf{Quant}_a(Q)
=
\left\langle
\mathsf{Mode}_a,
\mathsf{Set}_a,
\mathsf{Uniformity}_a
\right\rangle.
$$

$\mathsf{Mode}_a$ 可包含：

- `all`；
- `exists`；
- `generic`；
- `almost-everywhere`；
- `conditional`；
- `asymptotic`；
- `unknown`。

因此兩篇 theorem 即使都出現「global」一詞，只要 quantifier envelope 不同，就不能直接視為相同 claim。

---

# 5. Globality Profile

定義：

$$
\boxed{
\mathsf{GProf}(Q)
=
\left\langle
G_t,
G_x,
G_{\rm data},
G_{\rm sol},
G_{\rm bdry},
G_{\rm force},
G_{\rm par},
G_{\rm reg},
G_{\rm eq},
G_{\rm rep},
G_{\rm phys},
G_{\rm proof}
\right\rangle.
}
$$

每個 component 不是單純的 $0/1$，而是相對宣告 domain 的 scope descriptor。

第一版 descriptor：

$$
G_a
\in
\{
\mathsf{LOCAL},
\mathsf{PARTIAL},
\mathsf{FULL}_{D_a},
\mathsf{FAMILY}_{\Sigma},
\mathsf{OPEN},
\mathsf{UNKNOWN}
\}.
$$

其中：

$$
\mathsf{FULL}_{D_a}
$$

只表示對**已宣告的** $D_a$ 全稱成立，不表示對所有可能 domain 全稱成立。

這是本文最重要的語義限制之一。

---

# 6. Globality Typing Principle

CSM 定義：

$$
\boxed{
\textbf{Globality Typing Principle}
}
$$

任何 global claim 必須能被還原成一個有效的 $\mathsf{ScopeContract}$ 與 $\mathsf{GProf}$。

因此：

$$
\boxed{
\text{Global-in-time}
\not\Rightarrow
\text{Global-across-data}.
}
$$

$$
\boxed{
\text{Global-across-data}
\not\Rightarrow
\text{Global-across-equations}.
}
$$

$$
\boxed{
\text{Global-across-equations}
\not\Rightarrow
\text{Global-across-physical-realizations}.
}
$$

除非有額外的 typed promotion certificate。

---

# 7. 時間全域性

對固定 formal problem：

$$
Q(E,u_0):
\qquad
\forall t\in\mathcal T,
\quad
P(E,u_0,t).
$$

若：

$$
\mathcal T=[0,\infty),
$$

可稱為該 formal scope 下的 global-in-time claim。

但這不會自動改變：

- equation $E$；
- data class；
- solution notion；
- boundary / forcing；
- physical interpretation。

所以時間全域性只提升 $G_t$。

---

# 8. 空間全域性

「whole-space problem」與「所有可能 geometry」不是同一件事。

若固定：

$$
\mathcal X=\mathbb R^d,
$$

那麼 theorem 對 $\mathbb R^d$ 的整個 spatial domain 成立，只能寫成：

$$
G_x=\mathsf{FULL}_{\mathbb R^d}.
$$

它不推出：

$$
G_x=\mathsf{FULL}_{\text{all manifolds / domains}}.
$$

因此 whole-space 是一種 spatial-domain choice，不是 geometry-family universal quantifier。

---

# 9. 資料類全域性

若 theorem 對：

$$
u_0\in\mathcal D_0
$$

全部成立，則：

$$
G_{\rm data}=\mathsf{FULL}_{\mathcal D_0}.
$$

但若：

$$
\mathcal D_0\subsetneq\mathcal D_1,
$$

不能直接得到：

$$
\mathsf{FULL}_{\mathcal D_1}.
$$

這是典型的 scope expansion，而不是普通 theorem restatement。

---

# 10. Solution-Notion Globality

同一 PDE 可能具有不同 solution notion：

$$
\mathcal S
=
\{
\text{classical},
\text{strong},
\text{mild},
\text{weak},
\text{suitable},
\ldots
\}.
$$

本文不宣稱這些 notion 在所有 PDE 上具有固定 implication hierarchy。

任何：

$$
Q_{\mathcal S_1}
\Rightarrow
Q_{\mathcal S_2}
$$

必須由指定問題中的已知 theorem 或證書建立。

因此：

$$
\boxed{
\text{same equation}
\neq
\text{same theorem domain}.
}
$$

---

# 11. Boundary 與 Forcing Globality

一個 unforced theorem：

$$
F=0
$$

不自動升格成 forced theorem。

同樣：

$$
\mathcal B=\text{periodic}
$$

與：

$$
\mathcal B=\text{no-slip bounded domain}
$$

是不同 domain signatures。

因此：

$$
G_{\rm force}
$$

與：

$$
G_{\rm bdry}
$$

必須獨立紀錄。

---

# 12. Parameter Globality

對參數：

$$
\lambda\in\Lambda,
$$

若 theorem 是：

$$
\forall\lambda\in\Lambda,
\quad
P(\lambda),
$$

且 proof constant 對 $\lambda$ uniform，則可以記錄更強的 parameter-globality。

但若只是逐點：

$$
\forall\lambda,
\quad
\exists C_\lambda,
$$

與存在 uniform constant：

$$
\exists C,
\quad
\forall\lambda
$$

不同。

因此 CSM 把 **quantifier order** 視為 globality metadata 的一部分。

---

# 13. Equation-Family Globality

這是本文新增的主要層。

固定單一 equation：

$$
E_0
$$

的 theorem，不等於對 equation family：

$$
\mathcal E_{\Sigma}
$$

的 theorem。

方程族必須由 signature $\Sigma$ 定義，例如：

$$
\Sigma
=
\left\langle
\text{dimension},
\text{transport},
\text{constraint},
\text{dissipation},
\text{projection},
\text{forcing},
\text{boundary},
\text{constitutive class}
\right\rangle.
$$

只有在 $\Sigma$ 已明確宣告後，

$$
\mathsf{FAMILY}_{\Sigma}
$$

才是一個有意義的 globality descriptor。

---

# 14. Representation Globality

一個 proof 在 representation $\rho_1$ 中成功，不代表所有 representation 都能重建相同 proof object。

反過來，某 representation 下搜尋失敗，也不能推出所有語義等價表示皆失敗。

因此：

$$
G_{\rm rep}
$$

主要描述：

- theorem 是否 representation-independent；
- proof certificate 是否可以跨 representation 重建；
- search failure 是否只是 representation-local。

本文保留：

$$
\boxed{
\text{Mathematical Identity}
\neq
\text{Search Representation Identity}.
}
$$

---

# 15. Proof-Regime Globality

形式證明制度也是 scope。

設：

$$
\Theta_1,
\Theta_2
$$

是不同 theorem/proof regimes。

在：

$$
\Theta_1\vdash Q
$$

成立，不等於：

$$
\Theta_2\vdash Q.
$$

但若 $\Theta_2$ 是 conservative extension 或已有 formal embedding theorem，才可建立對應 bridge。

CSM 不自行假設這種 bridge。

---

# 16. Physical-Realization Globality

這一軸不是單純集合 inclusion。

形式模型：

$$
M
$$

與物理 realization：

$$
R
$$

之間需要 interpretation / idealization relation：

$$
M
\xleftrightarrow[
\mathsf{Idealize}
]{
\mathsf{Interpret}
}
R.
$$

這些 relation 可以是 partial、scale-dependent、regime-dependent，也可以有 model discrepancy。

因此：

$$
\boxed{
\operatorname{Prove}(M)
\not\Rightarrow
\operatorname{Prove}(R).
}
$$

除非另外定義「Prove$(R)$」的操作意義並證明 interpretation bridge 足以承載該推論。

---

# 17. 三種「更強」不能混在一起

考慮 theorem $Q_0$。

## 17.1 Theorem strengthening

同一 scope 中，結論變強：

$$
Q_1\Rightarrow Q_0,
$$

但 scope 不變。

## 17.2 Scope expansion

結論形式大致相同，但量化域變廣：

$$
D_0\subsetneq D_1.
$$

## 17.3 Model extension

模型本身被改寫：

$$
E_0
\mapsto
E_1.
$$

三者必須分開：

$$
\boxed{
\text{Theorem Strengthening}
\neq
\text{Scope Expansion}
\neq
\text{Model Extension}.
}
$$

---

# 18. Scope Restriction

如果：

$$
D_1\subseteq D_2,
$$

且 theorem：

$$
\forall x\in D_2,
\quad
Q(x)
$$

已證，則在相同 semantics 下可限制到：

$$
\forall x\in D_1,
\quad
Q(x).
$$

這種方向稱：

$$
\mathsf{ScopeRestrict}.
$$

它通常比 scope expansion 安全，但仍要求 theorem target 與 semantics 未在限制過程中改變。

---

# 19. Scope Expansion

反方向：

$$
D_1\subsetneq D_2
$$

時：

$$
\forall x\in D_1,
Q(x)
$$

不能自動推出：

$$
\forall x\in D_2,
Q(x).
$$

CSM 將這種非法升格稱為：

$$
\boxed{
\mathsf{ScopeLeak}.
}
$$

---

# 20. Globality Promotion Certificate

若要從 $D_1$ 推進到 $D_2$，定義：

$$
\boxed{
\mathsf{GPCert}_{D_1\to D_2}(Q)
}
$$

第一版欄位：

$$
\left\langle
\mathsf{DomainMap},
\mathsf{TargetFidelity},
\mathsf{QuantifierLift},
\mathsf{PremisePreservation},
\mathsf{SolutionCompatibility},
\mathsf{BoundaryCompatibility},
\mathsf{ParameterUniformity},
\mathsf{RepresentationFidelity},
\mathsf{InterpretationStatus},
\mathsf{CounterexampleReflection},
\mathsf{Debt},
\mathsf{ProofRef}
\right\rangle.
$$

並非每一種 bridge 都需要所有欄位，但任何缺失欄位必須被標為不適用或 debt，而不能靜默忽略。

---

# 21. Globality Debt

定義：

$$
\boxed{
\mathsf{GDebt}
=
\mathsf{Debt}_{\rm domain}
\uplus
\mathsf{Debt}_{\rm quant}
\uplus
\mathsf{Debt}_{\rm uniform}
\uplus
\mathsf{Debt}_{\rm sem}
\uplus
\mathsf{Debt}_{\rm rep}
\uplus
\mathsf{Debt}_{\rm phys}
\uplus
\mathsf{Debt}_{\rm proof}.
}
$$

當某 claim 已在較窄 domain 證明，但更廣 domain 尚未完成 promotion obligations 時，它可以標記為：

$$
\mathsf{CLOSED}^{+}_{D_1}
\quad+
\quad
\mathsf{OPEN}_{D_2\setminus D_1}.
$$

這比單純寫「partially proven」更精確。

---

# 22. Globality 不是 total order

若兩個 theorem：

$$
Q_A,
\qquad
Q_B,
$$

其中 $Q_A$ 在時間軸更廣，但 $Q_B$ 在資料類或 equation family 更廣，則未必存在：

$$
Q_A\succeq Q_B
$$

或：

$$
Q_B\succeq Q_A.
$$

因此 CSM 使用 **partial comparability**。

定義：

$$
Q_A\preceq_G Q_B
$$

只在所有比較軸都已對齊且 $Q_B$ 的 scope 至少包含 $Q_A$ 時成立。

否則標記：

$$
\boxed{
\mathsf{GLOBALLY\_INCOMPARABLE}.
}
$$

---

# 23. Domain Embedding 也不等於 Theorem Transfer

即使有：

$$
\iota:D_1\hookrightarrow D_2,
$$

也只證明 domain embedding。

還需要：

- equation compatibility；
- solution semantics compatibility；
- target preservation；
- assumptions preservation；
- relevant estimates / invariants preservation。

所以：

$$
\boxed{
\text{Domain Embedding}
\not\Rightarrow
\text{Theorem Transfer}.
}
$$

---

# 24. Counterexample 的跨域傳遞

Counterexample transfer 比 theorem promotion 方向不同。

若目標是 universal claim：

$$
\forall x\in D_2,
\quad
Q(x),
$$

且：

$$
x_\star\in D_1\subseteq D_2
$$

在**相同 target semantics** 下構成真正反例，則：

$$
\neg Q(x_\star)
$$

可反駁較廣 universal claim。

但若 $D_1$ 與 $D_2$ 之間還跨越 model interpretation、solution notion 或 modified equation，則必須重新檢查 counterexample fidelity。

因此：

$$
\boxed{
\text{Counterexample Transfer}
\text{ is typed, not name-based.}
}
$$

---

# 25. Obstruction 的跨域傳遞

一個 obstruction：

$$
O_{D_1}
$$

能否傳到 $D_2$，取決於 obstruction 所使用的 assumptions 是否在 $D_2$ 保存。

定義：

$$
\mathsf{ObsTransferCert}_{D_1\to D_2}(O).
$$

若 obstruction 依賴：

$$
A_1,\ldots,A_k,
$$

則至少需要：

$$
\forall i,
\quad
\mathsf{Preserve}_{D_1\to D_2}(A_i).
$$

否則 obstruction 只能停留在原 domain。

---

# 26. Scope Frontier

Paper 00 定義 closure frontier：

$$
\partial\mathfrak C(Q).
$$

本文進一步定義：

$$
\boxed{
\partial_G\mathfrak C(Q)
}
$$

作為 **globality / scope frontier**。

其成員不是單純 OPEN theorem，而是：

- 已在部分 axis 閉合；
- 其他 axis 尚未閉合；
- promotion bridge 尚有 debt；
- domain extension 尚未被覆蓋；
- interpretation 尚未建立。

因此完整 frontier 可寫成：

$$
\partial\mathfrak C
=
\partial_{\rm proof}\mathfrak C
\cup
\partial_G\mathfrak C
\cup
\partial_{\rm bridge}\mathfrak C
\cup
\partial_{\rm interp}\mathfrak C.
$$

---

# 27. Relative-Global Closure 的新解讀

Paper 00 的 RGC-4 是：對宣告 admissible mechanism space 有 completeness certificate 且 frontier 閉合。

本文補充：RGC grade 必須綁定 globality profile。

因此不能只寫：

$$
\mathsf{RGC4}(Q).
$$

而應寫：

$$
\boxed{
\mathsf{RGC4}(Q\mid\mathsf{GProf},D,\Theta,\mathcal A).
}
$$

同一命題在不同 globality profile 下可以具有不同 closure grade。

---

# 28. Domain Stratification

CSM 不把所有 domain 只排成一條 inclusion chain。

定義 domain graph：

$$
\boxed{
\mathcal G_D
=
(V_D,E_D,\tau_D).
}
$$

edge type 可包含：

$$
\tau_D(e)
\in
\{
\mathsf{RESTRICTS},
\mathsf{EXTENDS},
\mathsf{GENERALIZES},
\mathsf{SPECIALIZES},
\mathsf{INTERPRETS},
\mathsf{IDEALIZES},
\mathsf{APPROXIMATES},
\mathsf{EMBEDS},
\mathsf{REPRESENTS}
\}.
$$

只有 `RESTRICTS / EXTENDS` 等少數 edge 在附帶條件下與 set inclusion 直接相關。

`INTERPRETS` 與 `IDEALIZES` 不應被畫成普通 subset arrow。

---

# 29. Navier--Stokes：formal / Clay mathematical domain

定義：

$$
\boxed{
\mathfrak N_{\rm C}
}
$$

為 Clay / formal mathematical Navier--Stokes target domain。

更精確地，因正式問題可以包含不同 formal clauses / spatial settings，本文允許：

$$
\mathfrak N_{\rm C}
=
\{
\mathfrak N_{\rm C}^{(c)}
:\
c\in\mathcal C_{\rm formal}
\}.
$$

每個 clause 必須記錄自己的：

- equation；
- dimension；
- spatial domain；
- data class；
- solution notion；
- regularity target；
- forcing / boundary convention。

本文不將不同 clause 靜默壓成同一 statement。

---

# 30. Clay NS 的「global」到底在哪裡

在固定 formal clause 下，其典型 global regularity / existence target 至少包含：

$$
G_t
=
\mathsf{FULL}_{[0,\infty)}
$$

或等價的全有限時間延拓要求，以及對宣告 admissible data class 的 universal quantification。

但這仍然不代表：

$$
G_{\rm eq}
=
\mathsf{FAMILY}_{\text{all NS-like equations}}.
$$

也不代表：

$$
G_{\rm phys}
=
\mathsf{FULL}_{\text{all physical fluids}}.
$$

因此：

$$
\boxed{
\text{Clay-global}
=
\text{strong globality inside a restricted formal scope}.
}
$$

「restricted」在這裡不代表問題小，而是代表其 quantifier contract 有明確邊界。

---

# 31. Physical Navier--Stokes realization domain

定義：

$$
\boxed{
\mathfrak N_{\rm P}
}
$$

為 physical NS realization domain。

它不是：

$$
\mathfrak N_{\rm C}
\subseteq
\mathfrak N_{\rm P}
$$

這種單純 set relation。

更合理的是：

$$
\mathfrak N_{\rm C}
\xleftrightarrow[
\mathsf{Idealize}
]{
\mathsf{Interpret}
}
\mathfrak N_{\rm P}.
$$

其 bridge 可能依賴：

- continuum approximation；
- constitutive regime；
- Reynolds / Mach / Knudsen-like regime；
- measurement scale；
- neglected physics；
- boundary realization；
- material properties。

本文不宣告任何單一 bridge 在所有 physical regimes 完整成立。

---

# 32. Generalized NS-like family

定義：

$$
\boxed{
\mathfrak N_{\rm G}^{\Sigma}
}
$$

為由 signature $\Sigma$ 宣告的 generalized NS-like equation family。

第一版 signature：

$$
\boxed{
\Sigma_{\rm NSL}
=
\left\langle
 d,
\mathcal X,
\mathcal C,
\mathcal B_{\rm nl},
\mathcal A_{\rm diss},
\mathcal P_{\rm proj},
\mathcal F,
\mathcal B_{\rm bdry},
\mathcal K_{\rm const},
\mathcal S
\right\rangle.
}
$$

其中：

- $d$：dimension family；
- $\mathcal X$：geometry / manifold class；
- $\mathcal C$：constraint class，例如 divergence-free 或其 generalized analogue；
- $\mathcal B_{\rm nl}$：nonlinear transport / interaction class；
- $\mathcal A_{\rm diss}$：dissipation operator class；
- $\mathcal P_{\rm proj}$：pressure / projection / constraint enforcement；
- $\mathcal F$：forcing class；
- $\mathcal B_{\rm bdry}$：boundary class；
- $\mathcal K_{\rm const}$：constitutive / coefficient class；
- $\mathcal S$：solution semantics。

只有 $\Sigma_{\rm NSL}$ 明確後，「對所有 NS-like system」才是可解析的 theorem target。

---

# 33. Formal NS 不等於 Generalized NS-like family

即使：

$$
\mathfrak N_{\rm C}^{(c)}
\in
\mathfrak N_{\rm G}^{\Sigma}
$$

在某一 signature 下成立，也只有 membership / embedding 意義。

它不推出：

$$
\operatorname{Prove}(
\mathfrak N_{\rm C}^{(c)}
)
\Rightarrow
\operatorname{Prove}(
\mathfrak N_{\rm G}^{\Sigma}
).
$$

因此：

$$
\boxed{
\operatorname{Prove}(\mathfrak N_{\rm C})
\not\Rightarrow
\operatorname{Prove}(\mathfrak N_{\rm G}^{\Sigma}).
}
$$

這是 **Equation-Family Non-Collapse Principle**。

---

# 34. Formal NS 不等於 Physical NS

同理：

$$
\boxed{
\operatorname{Prove}(\mathfrak N_{\rm C})
\not\Rightarrow
\operatorname{Prove}(\mathfrak N_{\rm P}).
}
$$

這不是否定 formal PDE theorem 的物理價值，而是要求：

$$
\text{formal theorem}
\rightarrow
\text{physical claim}
$$

必須經過 interpretation bridge。

如果物理 claim 比 formal model 的 validity regime 更廣，還需要額外 scope expansion。

---

# 35. 三域不應排成簡單階層

禁止無證寫成：

$$
\mathfrak N_{\rm C}
\subset
\mathfrak N_{\rm P}
\subset
\mathfrak N_{\rm G}.
$$

更正確的是 typed graph：

$$
\boxed{
\mathfrak N_{\rm C}
\xrightarrow{
\mathsf{Generalize}
}
\mathfrak N_{\rm G}^{\Sigma}
}
$$

以及：

$$
\boxed{
\mathfrak N_{\rm C}
\xleftrightarrow[
\mathsf{Idealize}
]{
\mathsf{Interpret}
}
\mathfrak N_{\rm P}.
}
$$

必要時 generalized model family 也可以與 physical domain 建立自己的 model correspondence edge。

---

# 36. NS Closure Graph 將變成多域圖

未來：

$$
\mathfrak C_{\rm NS}^{\rm rel}
$$

不應只有一張 route graph。

至少包含：

$$
\boxed{
\mathcal G_{\rm NS}
=
\mathcal G_{\rm claim}
\cup
\mathcal G_{\rm route}
\cup
\mathcal G_{\rm obs}
\cup
\mathcal G_{\rm bridge}
\cup
\mathcal G_{\rm domain}
\cup
\mathcal G_{\rm scope}.
}
$$

其中 $\mathcal G_{\rm scope}$ 專門追蹤 theorem 在哪些 globality axis 已閉合。

---

# 37. Scope-State Node

為了在圖中操作 globality，定義：

$$
\boxed{
\mathsf{ScopeState}(Q,a,D_a)
}
$$

表示命題 $Q$ 在 axis $a$、domain $D_a$ 上的 closure state。

例如：

$$
\mathsf{ScopeState}(Q,\text{time},[0,\infty))
=
\mathsf{CLOSED}^{+}
$$

並不要求：

$$
\mathsf{ScopeState}(Q,\text{equation-family},\Sigma)
=
\mathsf{CLOSED}^{+}.
$$

因此同一 theorem 可以沿不同 axis 具有不同 closure status。

---

# 38. Scope Hyperedge

有些 globality promotion 需要多個前提同時成立：

$$
\{
Q_{D_1},
B_1,
B_2,
U
\}
\Longrightarrow
Q_{D_2}.
$$

其中：

- $B_i$：bridge theorem；
- $U$：uniform estimate / compactness / preservation condition。

因此 scope promotion 是 hyperedge，而不是簡單箭頭。

---

# 39. Globality Closure Action

在 Paper 00 的 closure family 上新增：

$$
\boxed{
\mathsf{Cl}_{\rm globality}.
}
$$

它只允許以下操作：

1. 已證 universal claim 向合法 restriction 傳播；
2. 有 $\mathsf{GPCert}$ 時向 broader scope promotion；
3. 有 counterexample-transfer certificate 時向 broader universal claim 傳播 refutation；
4. 依 axis 分離更新 scope states；
5. 所有 promotion debt 寫入 ledger。

它禁止 name-based generalization。

---

# 40. Scope Reopening

若某 scope-level NO-GO 後來被發現依賴一個只在窄 regime 成立的 assumption，則 broader domain 可以重新 OPEN。

即：

$$
\boxed{
\mathsf{BLOCKED}_{D_2}
\longrightarrow
\mathsf{OPEN}_{D_2}
}
$$

若 obstruction transfer certificate 被撤銷或降格。

這是 Paper 00 Reopening Principle 在 globality axis 上的版本。

---

# 41. Scope Ledger

每一次 globality upgrade / downgrade 必須記錄：

$$
\mathsf{ScopeLedgerEvent}
=
\left\langle
Q,
D_{\rm from},
D_{\rm to},
\mathsf{Axis},
\mathsf{Action},
\mathsf{CertRef},
\mathsf{DebtDelta},
\mathsf{Version}
\right\rangle.
$$

避免後續研究者只看到「global theorem」而不知道它最初只在哪個 domain 成立。

---

# 42. 第一批 Globality Axioms / Protocol Invariants

## G-1 — Scope Explicitness

任何 global claim 必須綁定 scope contract。

## G-2 — Axis Non-Collapse

不同 globality axis 不得無證合併。

## G-3 — Declared-Full Relativity

$$
\mathsf{FULL}_{D}
$$

只對 $D$ 有效。

## G-4 — No Upward Scope Promotion

窄 domain theorem 不自動推出廣 domain theorem。

## G-5 — Typed Counterexample Transfer

counterexample 只能沿 target-preserving inclusion / bridge 傳遞。

## G-6 — Interpretation Non-Identity

formal model 與 physical realization 不因名稱相同而同一。

## G-7 — Equation-Family Declaration

所有 equation-family globality 必須先宣告 family signature。

## G-8 — Quantifier-Order Preservation

交換量詞順序視為 theorem change，除非另證等價。

## G-9 — Representation Firewall

representation-local success/failure 不自動升格為 semantic-global result。

## G-10 — Proof-Regime Firewall

proof in one formal/admissibility regime 不自動等於 proof in another。

## G-11 — Scope Debt Visibility

所有未支付 promotion obligations 必須可見。

## G-12 — Relative-Global Firewall

relative-global closure 不得冒充 absolute mathematical completeness。

---

# 43. 第一批 Derived Propositions

## Proposition 1 — Restriction Preservation

若 $D_1\subseteq D_2$，且 $Q$ 是在相同 semantics 下對 $D_2$ 的 universal claim，則：

$$
\mathsf{CLOSED}^{+}_{D_2}(Q)
\Rightarrow
\mathsf{CLOSED}^{+}_{D_1}(Q).
$$

### 條件

不允許 target、solution notion 或 equation 在 restriction 過程中改變。

## Proposition 2 — Expansion Non-Entailment

一般而言：

$$
\mathsf{CLOSED}^{+}_{D_1}(Q)
\not\Rightarrow
\mathsf{CLOSED}^{+}_{D_2}(Q)
$$

對 $D_1\subsetneq D_2$。

## Proposition 3 — Globality Incomparability

若 $Q_A$ 與 $Q_B$ 在不同 axis 各自較廣，且沒有全部 axis 對齊，則 $Q_A,Q_B$ 可為 $\preceq_G$ 不可比較。

## Proposition 4 — Counterexample Lift under Inclusion

若 universal target semantics 不變，且 $x_\star\in D_1\subseteq D_2$ 為 $Q$ 的真 counterexample，則 $x_\star$ 同時反駁 $D_2$ 上的 universal claim。

## Proposition 5 — Physical Non-Transfer

formal theorem 的 closure status 不經 interpretation certificate 不能直接更新 physical-realization scope state。

## Proposition 6 — Family Non-Transfer

單一 equation member 的 theorem 不經 family-uniform proof 不能直接更新 equation-family scope state為正閉合。

---

# 44. Globality Proof-Obligation Matrix

| Promotion | 最低 obligation |
|---|---|
| local time $\to$ global time | continuation / blow-up exclusion / appropriate extension theorem |
| one datum $\to$ data class | uniform or pointwise-all proof over declared class |
| one parameter $\to$ parameter family | quantifier order + parameter-uniformity audit |
| one boundary $\to$ boundary family | boundary compatibility theorem |
| unforced $\to$ forced | forcing-dependent estimates / theorem |
| one equation $\to$ equation family | family signature + uniform structural theorem |
| one solution notion $\to$ another | solution-compatibility theorem |
| representation-local $\to$ semantic-global | representation fidelity / reconstruction theorem |
| formal model $\to$ physical realization | interpretation / validation bridge |
| observed proof space $\to$ admissible proof space | route/decomposition completeness certificate |

---

# 45. NS Domain Record v0.1

```yaml
ns_domains:
  clay_formal:
    id: N_C
    relation_kind: formal_problem_family
    globality_focus:
      - time
      - declared_data_class
      - declared_regularities
    non_implications:
      - physical_realization_globality
      - generalized_equation_family_globality

  physical_realization:
    id: N_P
    relation_kind: interpreted_realization_domain
    relation_to_N_C:
      - INTERPRETS
      - IDEALIZES
    not_a_simple_subset: true

  generalized_ns_like:
    id: N_G_Sigma
    relation_kind: signature_parameterized_equation_family
    signature_required: true
    relation_to_N_C:
      - GENERALIZES
      - EMBEDS_when_certified
```

---

# 46. Globality Record v0.1

```yaml
globality_record:
  claim_id: Q-...
  scope_contract:
    equation_domain: ...
    spatial_domain: ...
    time_domain: ...
    data_class: ...
    solution_notion: ...
    boundary_family: ...
    forcing_family: ...
    parameter_domain: ...
    regularity_target: ...
    interpretation_domain: ...
    proof_regime: ...
  axes:
    time: FULL_D | PARTIAL | LOCAL | OPEN | UNKNOWN
    space: FULL_D | PARTIAL | LOCAL | OPEN | UNKNOWN
    data: FULL_D | PARTIAL | LOCAL | OPEN | UNKNOWN
    equation_family: FAMILY_Sigma | PARTIAL | OPEN | UNKNOWN
    physical: PARTIAL | OPEN | UNKNOWN
    proof: FULL_D | PARTIAL | OPEN | UNKNOWN
  promotion_certificates: []
  promotion_debt: []
  ledger_ref: ...
```

---

# 47. CSM 與 NS Proof-Space 的第一次真正結合

過去 NS proof-space 主要追蹤：

$$
\text{Route}
\rightarrow
\text{Obstruction}
\rightarrow
\text{Survivor}.
$$

加入 Paper 01 後，每個 survivor 還必須問：

> 它在哪一個 globality profile 中存活？

例如一個 mechanism 可能：

- 在固定 equation 下存活；
- 在固定 data class 下存活；
- 只在 vanishing-parameter asymptotic 中存活；
- 不知道是否能進入 broader equation family；
- 完全沒有 physical interpretation claim。

所以 survivor record 應擴成：

$$
\boxed{
\mathsf{SurvivorState}
=
\left\langle
\mathsf{Mechanism},
\mathsf{ScopeContract},
\mathsf{GProf},
\mathsf{ObstructionHistory},
\mathsf{Debt}
\right\rangle.
}
$$

這會直接防止「局部 survivor 被誤讀成全域反例候選」。

---

# 48. Closure 的目標也要分層

未來說：

> 「NS closure space 已經封到 90%」

在 CSM 中是不合法的，除非說明 metric 與 globality profile。

更正確的是：

$$
\mathsf{ClosureCoverage}
(
Q;
\mathsf{GProf},
\sim,
\Theta,
\mathcal A
).
$$

例如可以有：

- observed-route closure coverage；
- basin closure coverage；
- obstruction-certified coverage；
- admissible-mechanism coverage；
- scope-axis coverage。

不同 coverage 不能合併成一個無條件百分比。

---

# 49. Scope-Frontier Vector

定義：

$$
\boxed{
\mathbf F_G(Q)
=
(
F_t,
F_x,
F_{\rm data},
F_{\rm sol},
F_{\rm bdry},
F_{\rm force},
F_{\rm par},
F_{\rm reg},
F_{\rm eq},
F_{\rm rep},
F_{\rm phys},
F_{\rm proof}
).
}
$$

每個 $F_a$ 表示該 axis 上未閉的 quotient-aware frontier mass / class set。

本文不預設 frontier mass 必須是實數測度。

第一版可以先使用：

- class count；
- weighted class count；
- theorem-strength-weighted count；
- obstruction-independence-adjusted count。

---

# 50. Globality Closure Dynamics

隨研究前進：

$$
\mathsf{GProf}_{t+1}(Q)
=
\mathfrak U_G(
\mathsf{GProf}_t(Q),
\mathsf{NewCert}_t,
\mathsf{NewObs}_t,
\mathsf{NewDomain}_t,
\mathsf{Revision}_t
).
$$

但 globality 不必單調增加。

一個 theorem 可能因 statement correction 被縮小 scope：

$$
\mathsf{FULL}_{D_2}
\longrightarrow
\mathsf{FULL}_{D_1},
\qquad
D_1\subsetneq D_2.
$$

這不是研究倒退，而是 scope fidelity 提高。

---

# 51. Domain Revision 與 Descendant Survival

若 parent domain $D$ 被修訂成 $D'$，不能把所有 descendants 全刪。

每個 descendant $Q_i$ 需重新問：

1. 其 proof 是否實際使用被刪除 assumption？
2. 其 theorem target 是否仍有意義？
3. 能否 restriction 到 $D'$？
4. 是否存在 independent re-proof？
5. obstruction 是否仍有效？
6. representation / tool 是否仍可重用？

因此：

$$
\boxed{
\text{Parent Domain Revision}
\not\Rightarrow
\text{Descendant Annihilation}.
}
$$

這使 CSM 可以安全處理「問題 framing 被改寫」而不丟掉整個歷史研究空間。

---

# 52. 對 NS 研究工程的立即影響

當 C1--C6、X72、DCRP、MORP、RFP、FCBP 與其他 NS assets 投影到 closure graph 時，每個 claim 至少要附：

- claim type；
- formal target；
- domain signature；
- globality profile；
- assumptions；
- proof / no-go / obstruction status；
- route family；
- quotient class；
- bridge dependencies；
- promotion debt；
- provenance。

因此不能只抽：

$$
A,C,L,O,S.
$$

下一版 NS closure dataset 應擴成：

$$
\boxed{
A,C,L,O,S,G,D,B,P
}
$$

其中：

- $G$：globality profile；
- $D$：domain signature；
- $B$：bridge set；
- $P$：promotion / proof debt。

---

# 53. Machine-Readable Minimum Schema

```yaml
csm_scope_state:
  schema_version: csm-globality/v0.1
  claim_id: string
  domain_signature:
    equation_domain: object
    spatial_domain: object
    time_domain: object
    data_class: object
    solution_notion: object
    boundary_family: object
    forcing_family: object
    parameter_domain: object
    regularity_target: object
    interpretation_domain: object
  globality_profile:
    time: object
    space: object
    data: object
    solution: object
    boundary: object
    forcing: object
    parameter: object
    regularity: object
    equation_family: object
    representation: object
    physical: object
    proof_regime: object
  status: OPEN | CLOSED_POS | CLOSED_NEG | BLOCKED | CONDITIONAL | UNKNOWN
  promotion_certificates: []
  debt: []
  provenance: []
  ledger_ref: string
```

---

# 54. Validation Scenarios

## Scenario A — Global time, one equation

已證固定 PDE 對全部時間成立。

正確：

$$
G_t=\mathsf{FULL}_{\mathcal T}.
$$

錯誤：

$$
G_{\rm eq}=\mathsf{FAMILY}_{\Sigma}
$$

無證自動升格。

## Scenario B — One parameter value

已證：

$$
P(\lambda_0).
$$

不得寫成：

$$
\forall\lambda\in\Lambda,
P(\lambda).
$$

## Scenario C — Physical agreement in one regime

formal model 在某 operating regime 與實驗吻合。

不得寫成所有 physical realization 已被證明。

## Scenario D — Counterexample in a true subdomain

如果 target semantics 完全相同，subdomain counterexample 可以 refute broader universal claim。

## Scenario E — Representation failure

proof search 在 $\rho_1$ 失敗，不得更新 semantic-global status 為 BLOCKED，除非 representation robustness audit 成立。

## Scenario F — Generalized NS-like family

若未宣告 $\Sigma_{\rm NSL}$，則「所有 NS-like equation」為：

$$
\mathsf{ILL\_SCOPED}.
$$

---

# 55. CSM Paper 01 的核心 No-Collapse Family

$$
\boxed{
\text{Local}
\neq
\text{Partial}
\neq
\mathsf{FULL}_{D}.
}
$$

$$
\boxed{
\mathsf{FULL}_{D_1}
\neq
\mathsf{FULL}_{D_2}
\quad
(D_1\neq D_2).
}
$$

$$
\boxed{
\text{Global-in-time}
\neq
\text{Global-across-equations}.
}
$$

$$
\boxed{
\text{Equation-family globality}
\neq
\text{Physical-realization globality}.
}
$$

$$
\boxed{
\text{Domain embedding}
\neq
\text{theorem transfer}.
}
$$

$$
\boxed{
\text{Formal theorem}
\neq
\text{physical proof}.
}
$$

$$
\boxed{
\text{Scope expansion}
\neq
\text{theorem strengthening}.
}
$$

$$
\boxed{
\text{Relative-global closure}
\neq
\text{absolute mathematical completeness}.
}
$$

---

# 56. 下一篇的直接問題

Paper 00 定義 closure space。

Paper 01 定義 closure space 的 domain / globality typing。

下一個自然問題是：

> 在已經有 typed domain 的情況下，如何把「命題、路徑、障礙、survivor、NO-GO、bridge」真正組合成可運算的 closure graph，並定義 closure propagation、frontier reduction 與 reopening？

因此下一篇建議為：

$$
\boxed{
\textbf{CSM Paper 02 — Typed Closure Graphs and Obstruction Propagation}
}
$$

其任務是建立：

- typed claim hypergraph；
- proof-route quotient graph；
- obstruction transfer；
- survivor propagation；
- scope-state graph；
- closure event algebra；
- frontier update rules；
- NS closure graph 的 canonical node / edge schema。

---

# 57. 結論

CSM Paper 01 的核心不是把「global」拆成更多名詞，而是把 globality 變成可運算的 theorem metadata。

一個命題不再只記：

> global / local。

而是記：

$$
\boxed{
\mathsf{ScopeContract}(Q)
+
\mathsf{GProf}(Q)
+
\mathsf{GPCert}
+
\mathsf{GDebt}.
}
$$

這使我們能精確區分：

- 哪些 axis 已閉；
- 哪些 axis 尚開；
- 哪些 theorem 只是窄 scope 正確；
- 哪些 generalization 真正有證書；
- 哪些 physical interpretation 尚未建立；
- 哪些 generalized equation-family claim 仍是未定義的自然語言擴張。

對 Navier--Stokes 而言，這一步建立了一個必要的三域防火牆：

$$
\boxed{
\mathfrak N_{\rm C}
\neq
\mathfrak N_{\rm P}
\neq
\mathfrak N_{\rm G}^{\Sigma}.
}
$$

Clay NS 可以在其 formal scope 中具有非常強的 globality，但這種 globality仍然是 typed、bounded-by-definition 的 globality，而不是所有 NS-like equations 或所有 physical fluids 的無界全域性。

因此 CSM 的研究方向不是削弱「global」的力量，而是讓每一種 globality 都獲得它真正的量詞、作用域、bridge 與 closure status。

當這些欄位被投影進 NS closure graph 後，過去數百條 proof route 的「成功、失敗、封路與 survivor」才第一次能被放入同一個相對全域空間中，而且不會因 scope 偷換而產生假閉包。

---

# 附錄 A：核心符號

| Symbol | Meaning |
|---|---|
| $\mathsf{ScopeContract}(Q)$ | 命題作用域契約 |
| $\mathsf{DomSig}(Q)$ | domain signature |
| $\mathsf{Quant}(Q)$ | quantifier envelope |
| $\mathsf{GProf}(Q)$ | globality profile |
| $G_t$ | time globality |
| $G_x$ | spatial globality |
| $G_{\rm data}$ | data-class globality |
| $G_{\rm eq}$ | equation-family globality |
| $G_{\rm phys}$ | physical-realization globality |
| $G_{\rm proof}$ | proof-regime globality |
| $\mathsf{GPCert}$ | globality promotion certificate |
| $\mathsf{GDebt}$ | globality promotion debt |
| $\partial_G\mathfrak C$ | scope/globality frontier |
| $\preceq_G$ | partial globality preorder |
| $\mathcal G_D$ | domain graph |
| $\mathfrak N_{\rm C}$ | formal / Clay mathematical NS domain |
| $\mathfrak N_{\rm P}$ | physical NS realization domain |
| $\mathfrak N_{\rm G}^{\Sigma}$ | signature-parameterized generalized NS-like family |

---

# 附錄 B：與 CSM Paper 00 的關係

Paper 00 已建立：

- $\Omega^{\rm obs}\neq\Omega^{\rm adm}\neq\Omega^{\rm math}$；
- relative-global closure；
- typed closure-space object；
- closure status；
- implication / dependency / quotient / obstruction / bridge / generative closure；
- route-completeness certificate；
- RGC-0 至 RGC-4；
- NS formal / physical / generalized 三域的初步區分。

Paper 01 不取代上述定義，而是把 `Globality Typing Principle` 展開成完整 domain / quantifier system，並規定 RGC status 必須綁定 $\mathsf{GProf}$。

---

# 附錄 C：內部理論血統

本文主要承接：

1. **CSM Paper 00** — closure space、relative-global closure、RGC、closure debt、frontier；
2. **LSI-PSD** — semantic quotient、route graph、proof basin、obstruction confluence、theorem-strength preorder、Proof-Space Observatory；
3. **UCT / UGC-CUR** — typed non-collapse、bridge certificate、debt、ledger、local-to-absolute gate；
4. **既有 NS 研究線** — formal NS 與 physical interpretation 不可直接塌縮、NS-203 proof-space instrumentation；
5. **NS C1--C6 / X72 / DCRP** — 作為後續 closure graph 的實際資料來源，而不是本篇的 theorem content。

---

# 附錄 D：下一步

下一步不應立刻繼續某一條 NS 局部 proof route。

應先完成：

$$
\boxed{
\text{CSM Paper 02 — Typed Closure Graphs and Obstruction Propagation}
}
$$

然後才開始第一個真正的：

$$
\boxed{
\text{NS Relative-Global Closure Graph v0.1}.
}
$$

其第一批 ingest source 應優先包含：

- ETN--X Integration；
- C1 / C2；
- C3--C6；
- X72；
- DCRP；
- Proof Asset Map；
- 已整理的 LSI-PSD NS-203 route / obstruction metadata。

**END OF CSM PAPER 01 v0.1**
