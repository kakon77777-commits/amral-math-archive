# CSM Paper 05 Package

Contains the canonical UTF-8 source for:

**CSM Paper 05 — Closure Invariants, Projection, and Static/Dynamic Compilation**

This paper extends CSM Papers 00–04 with:
- Native Closure State vs Projected Closure View;
- closure-critical invariant families;
- projection contracts and projection debt;
- projection–closure commutation;
- static batched projection;
- certified dynamic incremental materialization;
- attention projection and closure-complete boundaries;
- projection authority levels;
- multi-layer visualization / audit / execution views;
- NS closure graph projection rules.

This remains a theory package. It does not yet construct the full NS visual graph or runtime.
