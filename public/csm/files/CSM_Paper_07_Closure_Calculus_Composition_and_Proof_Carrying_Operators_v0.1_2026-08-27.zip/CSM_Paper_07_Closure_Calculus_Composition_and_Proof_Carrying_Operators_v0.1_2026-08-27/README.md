# CSM Paper 07 Package

Contains the canonical UTF-8 source for:

**CSM Paper 07 — Closure Calculus, Composition Rules, and Proof-Carrying Operators**

This paper consolidates CSM Papers 00–06 into an executable calculus:
- typed closure judgments;
- proof-carrying closure operators (PCOs);
- operator signatures and preconditions;
- certificate and debt behavior;
- composition safety;
- authority noninflation;
- fail-closed theorem mutation;
- closure normal form;
- closure transactions;
- candidate-to-native validation firewall;
- NS document/compiler ingestion profile;
- runtime interface foundations.

This package is the theoretical handoff point toward CSM Reference Runtime v0.1.
