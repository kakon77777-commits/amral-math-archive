# AMRR M1 — Mathematical State Adapter

**Release:** `ACR-AMRR-MVP-v0.1-M1`  
**Phase:** M1 — Mathematical State Adapter

M1 is an additive runtime layer over the frozen AMRR M0 schema contracts and the existing ACR Phase 0–2 baseline.

## Implemented Baseline

- ACR Phase 0: 10 frozen canonical schemas.
- ACR Phase 1: 64-object SPRC/CIO addressable cognition registry.
- ACR Phase 2: deterministic public `Observation -> SemanticState` encoder.
- AMRR M0: 19 canonical mathematical schemas.
- AMRR M1: deterministic public `extensions.math -> MathematicalStateExtension` adapter integrated into `SemanticState.extensions.math`.

## M1 identity policy

When no `extensions.math` observation exists, the original Phase-2 SemanticState identity algorithm and reference fingerprints remain unchanged.

When `extensions.math` is explicitly present:

```text
Public Observation
+ strict extensions.math observation
-> canonical MathematicalStateExtension
-> SemanticState.extensions.math
-> math-aware SemanticState content identity
-> canonical outer fingerprint
```

Non-math input extension metadata remains non-semantic and is not copied into the canonical state.

## Public math observation fields

```text
problem_refs
active_problem_ref
theory_refs
active_theory_ref
definition_refs
assumption_refs
method_refs
claim_refs
gap_map_ref
open_obligation_refs
verification_refs
bridge_refs
novelty_state
research_phase
```

Unknown math fields fail closed. Set-like reference arrays are sorted and deduplicated. Active problem/theory references must be members of their respective reference sets.

## Historical release boundary

`AMRR_M0_MANIFEST.json` and `AMRR_M0_CHECKSUMS.sha256` are historical M0 anchors and remain byte-for-byte unchanged. Their whole-tree checksum validator is not expected to validate the modified M1 tree. M1 instead verifies M0's frozen compatibility anchors: Phase-0 schema hashes, M0 math-schema hashes, Phase-1 registry fingerprint, and original Phase-2 no-math state fingerprints.

## Not Implemented Yet

- AMRR M2 Problem / Theory Stores
- AMRR M3 Gap Diagnosis Engine
- AMRR M4 Problem Identity / Theory Extension runtime
- AMRR M5 Obligation Engine
- AMRR M6 Math Cognitive Registry runtime
- AMRR M7 Verifier Router
- AMRR M8 CMDC Repair Engine
- AMRR M9 Theory Bridge / Prior Art runtime
- AMRR M10 CTCL / Receipt Adapter
- AMRR M11 Persistent Research Loop
