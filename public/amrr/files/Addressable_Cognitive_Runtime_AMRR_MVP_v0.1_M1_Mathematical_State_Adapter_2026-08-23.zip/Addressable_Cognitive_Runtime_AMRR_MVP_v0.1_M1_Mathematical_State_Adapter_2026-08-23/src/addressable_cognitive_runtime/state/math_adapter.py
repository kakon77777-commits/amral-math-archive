from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

from ..canonical import fingerprint_object
from ..validation import validate_object
from .errors import fail

MATH_ADAPTER_PROFILE = "amrr.math-state-adapter/v0.1"

MATH_OBSERVATION_FIELDS = {
    "problem_refs",
    "active_problem_ref",
    "theory_refs",
    "active_theory_ref",
    "definition_refs",
    "assumption_refs",
    "method_refs",
    "claim_refs",
    "gap_map_ref",
    "open_obligation_refs",
    "verification_refs",
    "bridge_refs",
    "novelty_state",
    "research_phase",
}

REF_PREFIXES = {
    "problem_refs": ("problem:",),
    "theory_refs": ("theory:",),
    "definition_refs": ("definition:",),
    "assumption_refs": ("assumption:",),
    "method_refs": ("method:",),
    "claim_refs": ("claim:",),
    "open_obligation_refs": ("obligation:",),
    "verification_refs": ("verification:",),
    "bridge_refs": ("theory-bridge:",),
}

NOVELTY_STATES = {
    "unknown",
    "search_incomplete",
    "known_prior_art",
    "rediscovered",
    "novel_candidate",
    "human_review_required",
}
RESEARCH_PHASES = {
    "interpretation",
    "diagnosis",
    "repair",
    "verification",
    "bridge",
    "packaging",
    "idle",
    "complete",
}


def _clean_string(value: Any, *, field: str) -> str:
    if not isinstance(value, str):
        fail("invalid_math_reference", f"{field} must be a string")
    cleaned = value.strip()
    if not cleaned:
        fail("invalid_math_reference", f"{field} must be non-empty")
    return cleaned


def _normalize_ref_list(value: Any, *, field: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        fail("invalid_math_reference", f"{field} must be an array of references")
    prefixes = REF_PREFIXES[field]
    cleaned: list[str] = []
    for item in value:
        ref = _clean_string(item, field=field)
        if not ref.startswith(prefixes):
            fail("invalid_math_reference", f"{field} contains invalid reference: {ref}")
        cleaned.append(ref)
    return sorted(set(cleaned))


def _normalize_nullable_ref(value: Any, *, field: str, prefixes: tuple[str, ...]) -> str | None:
    if value is None:
        return None
    ref = _clean_string(value, field=field)
    if not ref.startswith(prefixes):
        fail("invalid_math_reference", f"{field} contains invalid reference: {ref}")
    return ref


def normalize_math_observation(value: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        fail("invalid_math_observation", "extensions.math must be an object")

    unknown = sorted(set(value) - MATH_OBSERVATION_FIELDS)
    if unknown:
        fail(
            "unknown_math_observation_field",
            f"extensions.math contains unknown fields: {', '.join(unknown)}",
        )

    normalized: dict[str, Any] = {
        field: _normalize_ref_list(value.get(field), field=field)
        for field in REF_PREFIXES
    }
    normalized["active_problem_ref"] = _normalize_nullable_ref(
        value.get("active_problem_ref"), field="active_problem_ref", prefixes=("problem:",)
    )
    normalized["active_theory_ref"] = _normalize_nullable_ref(
        value.get("active_theory_ref"), field="active_theory_ref", prefixes=("theory:",)
    )
    normalized["gap_map_ref"] = _normalize_nullable_ref(
        value.get("gap_map_ref"), field="gap_map_ref", prefixes=("gap-map:",)
    )

    if (
        normalized["active_problem_ref"] is not None
        and normalized["active_problem_ref"] not in normalized["problem_refs"]
    ):
        fail("active_problem_not_listed", "active_problem_ref must appear in problem_refs")
    if (
        normalized["active_theory_ref"] is not None
        and normalized["active_theory_ref"] not in normalized["theory_refs"]
    ):
        fail("active_theory_not_listed", "active_theory_ref must appear in theory_refs")

    novelty = value.get("novelty_state", "unknown")
    if not isinstance(novelty, str) or novelty not in NOVELTY_STATES:
        fail("invalid_novelty_state", f"novelty_state has unsupported value: {novelty}")
    normalized["novelty_state"] = novelty

    phase = value.get("research_phase", "diagnosis")
    if not isinstance(phase, str) or phase not in RESEARCH_PHASES:
        fail("invalid_research_phase", f"research_phase has unsupported value: {phase}")
    normalized["research_phase"] = phase

    # Preserve the schema's field order for human readability. Canonical serialization is sorted separately.
    return {
        "problem_refs": normalized["problem_refs"],
        "active_problem_ref": normalized["active_problem_ref"],
        "theory_refs": normalized["theory_refs"],
        "active_theory_ref": normalized["active_theory_ref"],
        "definition_refs": normalized["definition_refs"],
        "assumption_refs": normalized["assumption_refs"],
        "method_refs": normalized["method_refs"],
        "claim_refs": normalized["claim_refs"],
        "gap_map_ref": normalized["gap_map_ref"],
        "open_obligation_refs": normalized["open_obligation_refs"],
        "verification_refs": normalized["verification_refs"],
        "bridge_refs": normalized["bridge_refs"],
        "novelty_state": normalized["novelty_state"],
        "research_phase": normalized["research_phase"],
    }


def _core_digest(core: Mapping[str, Any]) -> str:
    raw = json.dumps(
        dict(core), sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def encode_mathematical_state_extension(value: Mapping[str, Any]) -> dict[str, Any]:
    core = normalize_math_observation(value)
    result: dict[str, Any] = {
        "schema": "amrr.mathematical-state-extension/v0.1",
        "id": f"math-state:sha256:{_core_digest(core)}",
        "version": 1,
        "fingerprint": "sha256:" + "0" * 64,
        "extensions": {"state_adapter": {"profile": MATH_ADAPTER_PROFILE}},
        **core,
    }
    result["fingerprint"] = fingerprint_object(result)
    validation = validate_object(result, schema_name="mathematical-state-extension")
    if not validation.valid:
        message = "; ".join(f"{issue.code}: {issue.message}" for issue in validation.issues)
        fail("encoded_math_state_invalid", message)
    return result
