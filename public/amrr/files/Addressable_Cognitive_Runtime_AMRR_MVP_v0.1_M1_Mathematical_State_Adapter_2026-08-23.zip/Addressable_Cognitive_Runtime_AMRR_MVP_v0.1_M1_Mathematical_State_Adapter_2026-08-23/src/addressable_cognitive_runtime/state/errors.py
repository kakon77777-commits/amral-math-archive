from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ObservationError(ValueError):
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


def fail(code: str, message: str) -> None:
    raise ObservationError(code=code, message=message)
