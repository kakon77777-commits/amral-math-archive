import json
import os
import subprocess
import sys
from pathlib import Path

from addressable_cognitive_runtime.adapters.sprc import build_sprc_registry

ROOT = Path(__file__).resolve().parents[1]


def test_phase1_registry_artifact_matches_deterministic_builder():
    path = ROOT / "registry" / "ACR1-SPRC-CIO-v1.json"
    assert path.exists()
    assert json.loads(path.read_text(encoding="utf-8")) == build_sprc_registry()


def test_release_manifest_preserves_phase1_sprc_adapter():
    manifest = json.loads((ROOT / "MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["sprc"]["registry_id"] == "ACR1-SPRC-CIO-v1"
    assert manifest["sprc"]["object_count"] == 64
    assert manifest["sprc"]["source_package"] == "Semantic_Persona_Runtime_v2.2.0"


def test_release_validator_reports_phase1_adapter_evidence():
    script = ROOT / "scripts" / "validate_release.py"
    result = subprocess.run(
        [sys.executable, str(script), "--root", str(ROOT), "--compatibility-only"],
        cwd=ROOT,
        env=dict(os.environ, PYTHONPATH=str(ROOT / "src")),
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["sprc_source_verified"] is True
    assert payload["sprc_object_count"] == 64
    assert payload["sprc_registry_matches_builder"] is True
