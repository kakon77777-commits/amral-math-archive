from __future__ import annotations

from addressable_cognitive_runtime.canonical import canonical_bytes, fingerprint_object
from addressable_cognitive_runtime.state import ObservationError, encode_semantic_state
from addressable_cognitive_runtime.validation import validate_object


def obs(**overrides) -> dict:
    value = {
        "authority_ref": "contract:v12",
        "goal_refs": ["goal:research"],
        "environment_refs": ["artifact:paper"],
    }
    value.update(overrides)
    return value


def test_explicit_math_observation_is_embedded_as_canonical_extension():
    state = encode_semantic_state(obs(extensions={
        "source": "ignored-nonsemantic",
        "math": {
            "problem_refs": ["problem:main"],
            "active_problem_ref": "problem:main",
            "theory_refs": ["theory:base"],
            "active_theory_ref": "theory:base",
            "research_phase": "diagnosis",
        },
    }))
    assert set(state["extensions"]) == {"state_encoder", "math"}
    math_state = state["extensions"]["math"]
    assert math_state["schema"] == "amrr.mathematical-state-extension/v0.1"
    assert math_state["active_problem_ref"] == "problem:main"
    assert math_state["active_theory_ref"] == "theory:base"
    assert validate_object(math_state).valid
    assert validate_object(state).valid
    assert state["fingerprint"] == fingerprint_object(state)


def test_math_state_changes_outer_state_identity_and_fingerprint():
    base = obs(status="running")
    a = encode_semantic_state({**base, "extensions": {"math": {
        "problem_refs": ["problem:a"], "active_problem_ref": "problem:a"
    }}})
    b = encode_semantic_state({**base, "extensions": {"math": {
        "problem_refs": ["problem:b"], "active_problem_ref": "problem:b"
    }}})
    plain = encode_semantic_state(base)
    assert a["id"] != b["id"]
    assert a["fingerprint"] != b["fingerprint"]
    assert a["id"] != plain["id"]
    assert a["fingerprint"] != plain["fingerprint"]


def test_equivalent_math_observation_order_is_byte_identical():
    a = encode_semantic_state(obs(
        goal_refs=["goal:b", "goal:a"],
        extensions={"math": {
            "problem_refs": ["problem:z", "problem:a", "problem:z"],
            "active_problem_ref": "problem:a",
            "definition_refs": ["definition:z", "definition:a"],
            "open_obligation_refs": ["obligation:2", "obligation:1"],
        }},
    ))
    b = encode_semantic_state(obs(
        goal_refs=["goal:a", "goal:b", "goal:a"],
        extensions={"math": {
            "open_obligation_refs": ["obligation:1", "obligation:2", "obligation:1"],
            "definition_refs": ["definition:a", "definition:z"],
            "active_problem_ref": "problem:a",
            "problem_refs": ["problem:a", "problem:z"],
        }},
    ))
    assert a == b
    assert canonical_bytes(a) == canonical_bytes(b)
    assert a["extensions"]["math"]["fingerprint"] == b["extensions"]["math"]["fingerprint"]


def test_non_math_input_extensions_remain_nonsemantic_and_ignored():
    a = encode_semantic_state(obs(status="pending", extensions={"source": "A"}))
    b = encode_semantic_state(obs(status="pending", extensions={"source": "B", "debug": {"x": 1}}))
    assert a == b
    assert set(a["extensions"]) == {"state_encoder"}


def test_invalid_math_observation_fails_through_main_encoder():
    try:
        encode_semantic_state(obs(extensions={"math": {
            "problem_refs": ["problem:a"],
            "active_problem_ref": "problem:b",
        }}))
    except ObservationError as exc:
        assert exc.code == "active_problem_not_listed"
    else:
        raise AssertionError("invalid math observation must fail closed")
