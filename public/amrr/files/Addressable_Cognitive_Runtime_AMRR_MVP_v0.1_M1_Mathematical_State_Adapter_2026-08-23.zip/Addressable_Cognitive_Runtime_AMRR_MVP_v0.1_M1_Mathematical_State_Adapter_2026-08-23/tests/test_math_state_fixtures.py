from __future__ import annotations

from pathlib import Path

import pytest

from addressable_cognitive_runtime.canonical import canonical_bytes
from addressable_cognitive_runtime.state import ObservationError, encode_semantic_state_file
from addressable_cognitive_runtime.validation import validate_object

ROOT = Path(__file__).resolve().parents[1]
VALID = ROOT / "examples" / "math-state-observations" / "valid"
INVALID = ROOT / "examples" / "math-state-observations" / "invalid"


def test_m1_valid_math_observation_fixtures_encode_and_validate():
    encoded = {path.name: encode_semantic_state_file(path) for path in sorted(VALID.glob("*.json"))}
    assert len(encoded) == 4
    minimal = encoded["minimal.json"]["extensions"]["math"]
    assert minimal["problem_refs"] == []
    assert minimal["novelty_state"] == "unknown"
    assert minimal["research_phase"] == "diagnosis"
    active = encoded["research-active.json"]["extensions"]["math"]
    assert active["active_problem_ref"] == "problem:riemann-demo"
    assert active["active_theory_ref"] == "theory:analytic-number-theory"
    assert active["research_phase"] == "verification"
    assert all(validate_object(state).valid for state in encoded.values())
    assert all(validate_object(state["extensions"]["math"]).valid for state in encoded.values())


def test_m1_equivalent_math_observation_fixtures_are_byte_identical():
    a = encode_semantic_state_file(VALID / "equivalent-order-a.json")
    b = encode_semantic_state_file(VALID / "equivalent-order-b.json")
    assert a == b
    assert canonical_bytes(a) == canonical_bytes(b)


def test_m1_invalid_math_observation_fixtures_fail_closed_with_expected_codes():
    expected = {
        "unknown-math-field.json": "unknown_math_observation_field",
        "bad-active-problem.json": "active_problem_not_listed",
        "bad-problem-ref.json": "invalid_math_reference",
        "bad-novelty-state.json": "invalid_novelty_state",
        "bad-research-phase.json": "invalid_research_phase",
    }
    assert {path.name for path in INVALID.glob("*.json")} == set(expected)
    for name, code in expected.items():
        with pytest.raises(ObservationError) as exc:
            encode_semantic_state_file(INVALID / name)
        assert exc.value.code == code
