from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

from addressable_cognitive_runtime import __version__
from addressable_cognitive_runtime.state import MATH_ADAPTER_PROFILE, encode_semantic_state_file

ROOT = Path(__file__).resolve().parents[1]
M0_MANIFEST_SHA256 = "eb8461cc9b0f9ee78315a55657e7a1adcccbe70e8417226c407b8113010ac081"
M0_CHECKSUMS_SHA256 = "01e1633b6b9ef13ca012c1868c3cd28610ba211dbd1b31602f3c315836b9af34"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_m1_preserves_core_package_version_and_historical_m0_anchors():
    assert __version__ == "0.1.2"
    assert MATH_ADAPTER_PROFILE == "amrr.math-state-adapter/v0.1"
    assert digest(ROOT / "AMRR_M0_MANIFEST.json") == M0_MANIFEST_SHA256
    assert digest(ROOT / "AMRR_M0_CHECKSUMS.sha256") == M0_CHECKSUMS_SHA256


def test_m1_manifest_records_additive_adapter_release_boundary():
    manifest = json.loads((ROOT / "AMRR_M1_MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["release"] == "ACR-AMRR-MVP-v0.1-M1"
    assert manifest["version"] == "0.1.1"
    assert manifest["phase"] == "AMRR M1 - Mathematical State Adapter"
    assert manifest["base_amrr_release"] == "ACR-AMRR-MVP-v0.1-M0"
    assert manifest["math_state_adapter_profile"] == MATH_ADAPTER_PROFILE
    assert manifest["math_state_valid_observation_count"] == 4
    assert manifest["math_state_invalid_observation_count"] == 5
    assert manifest["m0_manifest_sha256"] == M0_MANIFEST_SHA256
    assert manifest["m0_checksums_sha256"] == M0_CHECKSUMS_SHA256
    assert manifest["implementation_boundary"]["implemented"][-1] == "AMRR M1 deterministic Mathematical State Adapter"
    assert manifest["implementation_boundary"]["not_implemented"] == ["AMRR M2-M11 runtime capabilities"]


def test_m1_manifest_reference_fingerprints_match_current_math_observation_fixtures():
    manifest = json.loads((ROOT / "AMRR_M1_MANIFEST.json").read_text(encoding="utf-8"))
    valid_root = ROOT / "examples" / "math-state-observations" / "valid"
    expected_state = {}
    expected_math = {}
    for path in sorted(valid_root.glob("*.json")):
        state = encode_semantic_state_file(path)
        expected_state[path.name] = state["fingerprint"]
        expected_math[path.name] = state["extensions"]["math"]["fingerprint"]
    assert manifest["reference_state_fingerprints"] == expected_state
    assert manifest["reference_math_fingerprints"] == expected_math
    assert expected_state["equivalent-order-a.json"] == expected_state["equivalent-order-b.json"]
    assert expected_math["equivalent-order-a.json"] == expected_math["equivalent-order-b.json"]


def test_m1_release_validator_reports_ok():
    script = ROOT / "scripts" / "validate_amrr_m1.py"
    result = subprocess.run(
        [sys.executable, str(script), "--root", str(ROOT)],
        cwd=ROOT,
        env=dict(os.environ, PYTHONPATH=str(ROOT / "src")),
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["math_state_valid_observations"] == 4
    assert payload["math_state_invalid_observations"] == 5
    assert payload["m0_anchor_failures"] == 0
    assert payload["checksum_failures"] == 0
