# AMRR M1 Mathematical State Adapter Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Extend the deterministic ACR Phase-2 public-state encoder so an explicit public `extensions.math` observation is normalized into a validated, content-addressed `amrr.mathematical-state-extension/v0.1` object embedded at `SemanticState.extensions.math`, while preserving the existing generic ACR state behavior when no math observation is present.

**Architecture:** Keep all 10 frozen ACR Phase-0 schemas and all 19 AMRR M0 schemas unchanged. Add an isolated math-state adapter module that normalizes only public structured math observation fields, validates reference prefixes and active-ref membership, emits a canonical `MathematicalStateExtension`, and lets the existing Semantic State encoder include that object in its identity/fingerprint only when math input is explicit. Non-math observation extensions remain non-semantic and continue to be ignored by the output state.

**Tech Stack:** Python 3.11+, `jsonschema` Draft 2020-12, `pytest`, existing ACR canonical JSON/fingerprint utilities.

**Spec:** `docs/amrr/04_自主數學研究Runtime_從可定址認知到自主理論建構_v0.1.md` and `AMRR_M0_MANIFEST.json`.

## Global Constraints

- Do not modify any Phase-0 schema file or any AMRR M0 math schema file.
- Preserve `SCHEMA_SPECS == 10`, `MATH_SCHEMA_SPECS == 19`, and the Phase-1 registry fingerprint.
- Preserve the existing Phase-2 encoder profile `acr.semantic-state-encoder/v0.1`.
- Use public structured state only; reject explicit private-reasoning fields.
- Non-math input extensions must not change the generic SemanticState output.
- An explicit `extensions.math` object must be strict: unknown math observation fields fail closed.
- Set-like math reference arrays are sorted and deduplicated.
- `active_problem_ref`, when non-null, must appear in `problem_refs`; `active_theory_ref`, when non-null, must appear in `theory_refs`.
- Canonical math state uses `amrr.mathematical-state-extension/v0.1`, version `1`, profile `amrr.math-state-adapter/v0.1`, and deterministic content-addressed IDs/fingerprints.
- M1 is additive; M2–M11 remain explicitly unimplemented.

---

### Task 1: Math Observation Contract and Adapter

**Files:**
- Create: `src/addressable_cognitive_runtime/state/errors.py`
- Create: `src/addressable_cognitive_runtime/state/math_adapter.py`
- Modify: `src/addressable_cognitive_runtime/state/encoder.py`
- Modify: `src/addressable_cognitive_runtime/state/__init__.py`
- Test: `tests/test_math_state_adapter.py`

**Interfaces:**
- Consumes: `fingerprint_object(obj) -> str`; `validate_object(obj, schema_name=None) -> ValidationResult`.
- Produces: `MATH_ADAPTER_PROFILE: str`; `normalize_math_observation(value: Mapping[str, Any]) -> dict[str, Any]`; `encode_mathematical_state_extension(value: Mapping[str, Any]) -> dict[str, Any]`; shared `ObservationError`.

- [ ] **Step 1: Write failing tests for strict normalization, deterministic ordering, defaults, reference-prefix validation, active-ref membership, and canonical math-state validation.**
- [ ] **Step 2: Run `PYTHONPATH=src pytest -q tests/test_math_state_adapter.py` and confirm failure because the adapter module/functions do not exist.**
- [ ] **Step 3: Move `ObservationError` / `_fail` to `state/errors.py` without behavior change and implement the minimal adapter.**
- [ ] **Step 4: Run the adapter tests and existing `tests/test_state_encoder.py`; confirm both pass.**
- [ ] **Step 5: Commit `feat: add deterministic AMRR math state adapter`.**

### Task 2: Integrate `extensions.math` into Semantic State Identity

**Files:**
- Modify: `src/addressable_cognitive_runtime/state/encoder.py`
- Test: `tests/test_math_state_encoder_integration.py`
- Test: `tests/test_state_encoder.py`

**Interfaces:**
- Consumes: `encode_mathematical_state_extension(...)`.
- Produces: unchanged `encode_semantic_state(observation) -> dict[str, Any]`, now optionally embedding `extensions.math`.

- [ ] **Step 1: Write failing tests proving explicit math input changes state identity/fingerprint, equivalent math ordering produces byte-identical states, and non-math input extensions remain ignored.**
- [ ] **Step 2: Run the integration test and confirm failure because the encoder currently discards all input extensions.**
- [ ] **Step 3: Include the canonical math extension in the semantic identity payload and output extensions only when `extensions.math` is present.**
- [ ] **Step 4: Run `tests/test_math_state_encoder_integration.py tests/test_state_encoder.py tests/test_state_observation.py`; confirm all pass.**
- [ ] **Step 5: Commit `feat: integrate mathematical state into semantic identity`.**

### Task 3: M1 Observation Fixtures and CLI Regression

**Files:**
- Create: `examples/math-state-observations/valid/minimal.json`
- Create: `examples/math-state-observations/valid/research-active.json`
- Create: `examples/math-state-observations/valid/equivalent-order-a.json`
- Create: `examples/math-state-observations/valid/equivalent-order-b.json`
- Create: `examples/math-state-observations/invalid/unknown-math-field.json`
- Create: `examples/math-state-observations/invalid/bad-active-problem.json`
- Create: `examples/math-state-observations/invalid/bad-problem-ref.json`
- Create: `examples/math-state-observations/invalid/bad-novelty-state.json`
- Create: `examples/math-state-observations/invalid/bad-research-phase.json`
- Create: `tests/test_math_state_fixtures.py`
- Modify: `tests/test_state_cli.py`

**Interfaces:**
- Consumes: existing `acr-schema state-encode` command.
- Produces: deterministic fixture corpus for M1 release validation.

- [ ] **Step 1: Add fixture tests first, including byte-identity between equivalent-order fixtures and exact expected error codes for invalid fixtures.**
- [ ] **Step 2: Run the fixture/CLI tests and confirm fixture files are missing or unsupported.**
- [ ] **Step 3: Add the fixture files only; do not add new runtime behavior in this task.**
- [ ] **Step 4: Run fixture and CLI tests; confirm pass.**
- [ ] **Step 5: Commit `test: add AMRR M1 mathematical observation fixtures`.**

### Task 4: M1 Release Metadata and Validator

**Files:**
- Create: `scripts/build_amrr_m1_metadata.py`
- Create: `scripts/validate_amrr_m1.py`
- Create: `tests/test_amrr_m1_release.py`
- Create/Generate: `AMRR_M1_MANIFEST.json`
- Create/Generate: `AMRR_M1_CHECKSUMS.sha256`
- Create: `AMRR_M1_VALIDATION.md`
- Create: `AMRR_M1_README.md`

**Interfaces:**
- Consumes: M0 manifest/checksums, M1 adapter profile, M1 fixtures.
- Produces: additive M1 release evidence while preserving M0 and base ACR metadata.

- [ ] **Step 1: Write failing release tests requiring M1 manifest fields, adapter profile, fixture counts/fingerprints, unchanged M0 boundary, and validator `ok=true`.**
- [ ] **Step 2: Run `tests/test_amrr_m1_release.py`; confirm failure because M1 release artifacts do not exist.**
- [ ] **Step 3: Implement metadata builder/validator and add `AMRR_M1_README.md` to mark M1 implemented and M2–M11 unimplemented. Preserve the historical M0 manifest/checksum files byte-for-byte.**
- [ ] **Step 4: Generate metadata, run the M1 validator and explicit frozen-baseline compatibility tests. Do not require historical snapshot validators to pass on the intentionally modified M1 tree; instead verify their frozen anchors inside the M1 validator.**
- [ ] **Step 5: Commit `chore: add AMRR M1 release validation`.**

### Task 5: Full Regression and Clean Package Verification

**Files:**
- No source changes unless a failing test exposes a defect.
- Generate clean ZIP outside the source tree.

**Interfaces:**
- Produces: `Addressable_Cognitive_Runtime_AMRR_MVP_v0.1_M1_Mathematical_State_Adapter_2026-08-23.zip`.

- [ ] **Step 1: Run the full collected test suite; if one batch exceeds the environment timeout, split it by test file while preserving complete collection coverage and record every result.**
- [ ] **Step 2: Run `python -m compileall -q src`.**
- [ ] **Step 3: Run `validate_amrr_m1.py`; require `ok=true` and zero M1 checksum failures. Separately verify the historical M0 manifest/checksum files themselves are unchanged from the imported baseline commit.**
- [ ] **Step 4: Remove `.git`, caches, bytecode, and build artifacts from the delivery copy; create ZIP with Python `zipfile` to preserve UTF-8 filenames.**
- [ ] **Step 5: Extract the produced ZIP with Python `zipfile`, rerun M1 validator and targeted M1 tests from the extracted package, and record ZIP SHA-256.**
