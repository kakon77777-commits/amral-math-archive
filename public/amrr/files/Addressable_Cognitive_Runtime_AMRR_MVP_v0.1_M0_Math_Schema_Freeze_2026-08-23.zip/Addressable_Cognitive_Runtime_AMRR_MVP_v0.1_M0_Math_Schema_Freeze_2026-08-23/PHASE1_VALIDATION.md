# ACR MVP v0.1 — Phase 1 Validation

**Phase:** Existing SPRC / CIO Adapter  
**Package version:** `0.1.1`

Phase 1 adapts the existing SES1 / CIO-Deck-v1.0 source into 64 deterministic, Phase-0-valid ACR CognitiveObjects. It does not rewrite the source operator meanings and does not modify the ten frozen Phase 0 schemas.

## Semantic source boundary

- Source package: `Semantic_Persona_Runtime_v2.2.0`
- Semantic regression reference: `Semantic_Persona_Runtime_v2.1.0`
- v2.1.0 and v2.2.0 canonical CIO deck and SES1 registry were verified byte/semantically equivalent for the adapter inputs.
- CIO canonical deck hash: `b436ad318e8fc0d8e8ab98939d275d25b690d1d59031a39c01f81a0af5d0d54e`
- SES1 canonical registry hash: `4b33ac3b60407db3641c7ea5f3220c5cb4764578143c1fa15bc5198a2481a33d`
- Source deck: `CIO-Deck-v1.0`
- Source runtime: `SPR-SA-v2.0`
- Source corpus: `SPRC-Corpus-1.1.0`

A previous transcribed SES1 hash containing `...8143b1fa...` was rejected during TDD. The source loaders and release validation consistently produce `...8143c1fa...`; Phase 1 records the latter and fails closed on drift.

## Mapping boundary

- 64/64 cards map to `cog://sprc/cio/<source-id-lower>@1`.
- Source deck order is preserved explicitly (`R01 ... M08`).
- Affinity remains source metadata, not a hard ACR precondition.
- Source risks remain provenance; ACR `risk_class` stays `unknown` because Phase 1 does not infer a categorical risk class.
- ACR `cost_class` stays `unknown` unless a future source provides an explicit equivalent.
- All imported operators use `authority_class = cognition_only`.
- Direct zh-Hant trigger and English corpus reference gloss are preserved as renderer views when present.
- SES wire renderer `provocative` remains unchanged; the v2.2 corpus clause alias `skeptical` is recorded explicitly.

## Canonical registry

- Registry ID: `ACR1-SPRC-CIO-v1`
- Registry schema: `acr.sprc-cio-registry/v0.1`
- Object count: `64`
- Registry fingerprint: `sha256:435cdfe0fc962e15ffd83e489274a0da4c6b6fa756c8bc20c0939fe6e395d9bd`
- Every object validates against the frozen Phase 0 CognitiveObject schema and semantic validator.
- Registry export is deterministic; repeated exports are byte-identical.

## CLI evidence

Available commands:

```text
sprc-info
sprc-list
sprc-resolve <source-id-or-address>
sprc-export <output.json>
```

Reference resolution:

```text
R01 -> cog://sprc/cio/r01@1
```

Reference R01 fingerprint in this release:

```text
sha256:1e04d0f067df694cb57225b98570c40413426c7bfa5b57512e0d1ed27bded0ab
```

## Fresh source-tree completion gate

- pytest: `41 passed`
- compileall: PASS
- Phase 0 valid fixtures: `10/10`
- Phase 0 deliberate invalid fixtures rejected: `6/6`
- SPRC source verification: PASS
- SPRC object count: `64`
- bundled registry equals fresh deterministic rebuild: PASS
- release validator: `ok=true`

The distributable ZIP is additionally extracted into a clean directory and revalidated before release; those packaging results are reported in the delivery message.
