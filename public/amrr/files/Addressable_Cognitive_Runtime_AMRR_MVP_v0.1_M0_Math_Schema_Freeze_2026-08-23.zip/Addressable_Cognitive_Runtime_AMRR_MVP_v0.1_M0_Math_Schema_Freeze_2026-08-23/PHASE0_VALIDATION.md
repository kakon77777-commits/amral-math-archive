# ACR MVP v0.1 — Phase 0 Validation Record

## Scope

This release freezes the first ten ACR top-level persisted schemas and the validation boundary around them. No claim is made that Cognitive Routing, Self-Dialogue Runtime, Governance inference, CTCL-ITR transport, Agenda generation, or Persistent Autonomous Loop are implemented yet.

## Fresh validation evidence

The source working tree passed the following release gates on 2026-08-21:

- `python -m pip install --no-deps --no-build-isolation -e .` — passed.
- `pytest -q` — **23 passed**.
- `python -m compileall -q src` — passed.
- `acr-schema list` — exactly **10** frozen top-level schemas.
- `acr-schema validate-fixtures examples/valid` — **10/10 valid**.
- `acr-schema validate-fixtures examples/invalid` — **6/6 rejected**, expected CLI exit code `1`.
- `scripts/validate_release.py` — `ok=true`, **0 checksum failures**, 10 schemas, 10 valid fixtures, 6 invalid fixtures.

A final clean extracted-ZIP verification is performed after packaging; its result is recorded in the release completion message rather than pre-claimed here.

## Architectural decisions frozen in Phase 0

- `Authority` is embedded, not a top-level persisted schema in v0.1.
- `Goal` remains an external stable reference until Goal Store implementation.
- Unknown top-level fields are rejected; `extensions` is the controlled expansion surface.
- Single-object validation checks syntax/semantics but does not prove referenced objects exist; referential integrity belongs to later Store/Ledger phases.
- `CognitiveObject` address versions must match object versions.
- `EXECUTE` is invalid unless `authority.class == ALLOW`.
- Decision Receipt selected actions must come from declared candidates.
- Cognitive programs cannot exceed declared `max_steps`.
- Canonical SHA-256 fingerprints exclude only the top-level `fingerprint` field.

## Evidence boundary

Phase 0 validates **representation contracts**, not autonomous cognition. Foundation-model self-constraint experiments remain supporting motivation, not proof that the future ACR stack is complete.

## Packaging boundary

Phase 0 is validated for source-tree / editable-install use. The release includes root-level `schemas/` as the canonical schema surface, matching the project whitepaper. A standalone wheel layout is not claimed as a verified distribution mode in this phase.
