from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from jsonschema import Draft202012Validator

PHASE0_SCHEMA_HASHES = {
    "cognitive-object": "2d38d9be37bb6425f4fde6ee2a40d593f95ad52ef94ef3bfd698b8b485541d29",
    "semantic-state": "e406aa9206f187c5b97ff5ac4e60db74f277a67b719b14123c1c1f6918f4d5a6",
    "cognitive-program": "62b40fac768028cd4a986604c90771b45a2a40183eef12c89bd95a59fe717932",
    "agenda-candidate": "acac33cb02e5deb65f663d37270b94a081d9000419b43bbaf2318c28557dd8df",
    "contract": "5f804c70e87d89bace3107815fd5b94c320393dcbb3b8b4623433b5f6b9c9e96",
    "governance-decision": "b4e3727b4813abb6b2e3a0e7b70b081a6968678f62c3e0cf7e315401c3ce50df",
    "decision-receipt": "ca24d7e73b8245796d8254e4e6530278cb125312409ab88b70dc14fcd40d0a61",
    "knowledge-boundary": "816702db685779a3e2f17b4cffd0a00e605c3883f184c8b57caec651f9295ee6",
    "commitment": "7922eec5a5a97c5c83184e06404f597875228801c8ba47dd7f390e38576813fc",
    "context-compression-event": "53d732bffa00a7690aba415b09fc57ddc77e6bae29b8707fa774561ad843d467",
}
PHASE1_REGISTRY_FINGERPRINT = "sha256:435cdfe0fc962e15ffd83e489274a0da4c6b6fa756c8bc20c0939fe6e395d9bd"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    from addressable_cognitive_runtime.adapters.sprc import build_sprc_registry, load_sprc_source, verify_sprc_source
    from addressable_cognitive_runtime.canonical import fingerprint_object
    from addressable_cognitive_runtime.schema_catalog import MATH_SCHEMA_SPECS, SCHEMA_SPECS, schema_path
    from addressable_cognitive_runtime.state.encoder import ENCODER_PROFILE, ObservationError, encode_semantic_state_file
    from addressable_cognitive_runtime.validation import validate_object

    failures: list[str] = []

    # Frozen ACR Phase 0 boundary.
    if len(SCHEMA_SPECS) != 10:
        failures.append(f"phase0_schema_count:{len(SCHEMA_SPECS)}")
    for name in SCHEMA_SPECS:
        try:
            schema = json.loads(schema_path(name).read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(schema)
        except Exception as exc:
            failures.append(f"phase0_schema:{name}:{exc}")
        if digest(schema_path(name)) != PHASE0_SCHEMA_HASHES.get(name):
            failures.append(f"phase0_schema_drift:{name}")

    # Frozen ACR Phase 1 registry semantics.
    try:
        source = load_sprc_source()
        verify_sprc_source(source)
        rebuilt = build_sprc_registry(source)
        if rebuilt.get("fingerprint") != PHASE1_REGISTRY_FINGERPRINT:
            failures.append("phase1_registry_drift")
        if rebuilt.get("object_count") != 64:
            failures.append("phase1_registry_count")
    except Exception as exc:
        failures.append(f"phase1_registry:{exc}")

    # Phase 2 deterministic public-state regression.
    state_valid = 0
    state_invalid = 0
    for path in sorted((root / "examples" / "state-observations" / "valid").glob("*.json")):
        try:
            first = encode_semantic_state_file(path)
            second = encode_semantic_state_file(path)
        except Exception as exc:
            failures.append(f"phase2_state_valid:{path.name}:{exc}")
            continue
        if first != second or not validate_object(first).valid:
            failures.append(f"phase2_state_determinism:{path.name}")
        else:
            state_valid += 1
    for path in sorted((root / "examples" / "state-observations" / "invalid").glob("*.json")):
        try:
            encode_semantic_state_file(path)
        except ObservationError:
            state_invalid += 1
        except Exception as exc:
            failures.append(f"phase2_state_invalid_unexpected:{path.name}:{exc}")
        else:
            failures.append(f"phase2_state_invalid_accepted:{path.name}")

    if ENCODER_PROFILE != "acr.semantic-state-encoder/v0.1":
        failures.append("phase2_encoder_profile")

    # AMRR M0 schema and fixture layer.
    if len(MATH_SCHEMA_SPECS) != 19:
        failures.append(f"math_schema_count:{len(MATH_SCHEMA_SPECS)}")
    for name in MATH_SCHEMA_SPECS:
        try:
            schema = json.loads(schema_path(name).read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(schema)
        except Exception as exc:
            failures.append(f"math_schema:{name}:{exc}")

    math_valid = 0
    math_invalid = 0
    for path in sorted((root / "examples" / "math" / "valid").glob("*.json")):
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            failures.append(f"math_valid_json:{path.name}:{exc}")
            continue
        result = validate_object(obj)
        if not result.valid:
            failures.append(f"math_valid_rejected:{path.name}")
            continue
        if obj.get("fingerprint") != fingerprint_object(obj):
            failures.append(f"math_valid_fingerprint:{path.name}")
            continue
        math_valid += 1
    for path in sorted((root / "examples" / "math" / "invalid").glob("*.json")):
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            failures.append(f"math_invalid_json:{path.name}:{exc}")
            continue
        if validate_object(obj).valid:
            failures.append(f"math_invalid_accepted:{path.name}")
        else:
            math_invalid += 1

    manifest_path = root / "AMRR_M0_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    if not manifest:
        failures.append("missing_amrr_m0_manifest")
    else:
        if manifest.get("release") != "ACR-AMRR-MVP-v0.1-M0":
            failures.append("manifest_release")
        if manifest.get("version") != "0.1.0":
            failures.append("manifest_version")
        if manifest.get("phase0_schema_count") != 10:
            failures.append("manifest_phase0_schema_count")
        if manifest.get("math_schema_count") != 19:
            failures.append("manifest_math_schema_count")
        if manifest.get("phase1_registry_fingerprint") != PHASE1_REGISTRY_FINGERPRINT:
            failures.append("manifest_phase1_registry_fingerprint")
        if manifest.get("phase2_state_encoder_profile") != ENCODER_PROFILE:
            failures.append("manifest_phase2_profile")
        expected_math_hashes = {name: digest(schema_path(name)) for name in MATH_SCHEMA_SPECS}
        if manifest.get("math_schema_sha256") != expected_math_hashes:
            failures.append("manifest_math_schema_hashes")
        if manifest.get("phase0_schema_sha256") != PHASE0_SCHEMA_HASHES:
            failures.append("manifest_phase0_schema_hashes")

    checksum_failures = 0
    checksums_path = root / "AMRR_M0_CHECKSUMS.sha256"
    if not checksums_path.exists():
        failures.append("missing_amrr_m0_checksums")
        checksum_failures += 1
    else:
        for lineno, line in enumerate(checksums_path.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            try:
                expected, rel = line.split("  ", 1)
            except ValueError:
                failures.append(f"bad_amrr_checksum_line:{lineno}")
                checksum_failures += 1
                continue
            path = root / rel
            if not path.exists() or digest(path) != expected:
                failures.append(f"amrr_checksum:{rel}")
                checksum_failures += 1

    payload = {
        "ok": not failures,
        "phase0_schema_count": len(SCHEMA_SPECS),
        "phase1_registry_fingerprint": PHASE1_REGISTRY_FINGERPRINT,
        "phase2_state_valid_observations": state_valid,
        "phase2_state_invalid_observations": state_invalid,
        "math_schema_count": len(MATH_SCHEMA_SPECS),
        "math_valid_fixtures": math_valid,
        "math_invalid_fixtures": math_invalid,
        "checksum_failures": checksum_failures,
        "failures": failures,
    }
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
