from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

EXCLUDED_FILES = {"AMRR_M0_CHECKSUMS.sha256"}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def payload_files(root: Path):
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if path.name in EXCLUDED_FILES:
            continue
        parts = rel.parts
        if ".git" in parts or ".pytest_cache" in parts or "__pycache__" in parts or ".worktrees" in parts:
            continue
        if any(part.endswith(".egg-info") for part in parts):
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        yield path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    from addressable_cognitive_runtime.canonical import fingerprint_object
    from addressable_cognitive_runtime.schema_catalog import MATH_SCHEMA_SPECS, SCHEMA_SPECS, schema_path

    base_manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    valid_root = root / "examples" / "math" / "valid"
    invalid_root = root / "examples" / "math" / "invalid"
    valid_files = sorted(valid_root.glob("*.json"))
    invalid_files = sorted(invalid_root.glob("*.json"))
    valid_fingerprints = {}
    for path in valid_files:
        obj = json.loads(path.read_text(encoding="utf-8"))
        valid_fingerprints[path.name] = fingerprint_object(obj)

    manifest = {
        "release": "ACR-AMRR-MVP-v0.1-M0",
        "version": "0.1.0",
        "phase": "AMRR M0 - Math Schema Freeze",
        "base_acr_release": base_manifest.get("release"),
        "base_acr_version": base_manifest.get("version"),
        "phase0_schema_count": len(SCHEMA_SPECS),
        "phase0_schema_sha256": {name: digest(schema_path(name)) for name in SCHEMA_SPECS},
        "phase1_registry_fingerprint": base_manifest.get("sprc", {}).get("registry_fingerprint"),
        "phase2_state_encoder_profile": base_manifest.get("state_encoder", {}).get("profile"),
        "math_schema_count": len(MATH_SCHEMA_SPECS),
        "math_schema_tokens": {name: spec.token for name, spec in MATH_SCHEMA_SPECS.items()},
        "math_schema_sha256": {name: digest(schema_path(name)) for name in MATH_SCHEMA_SPECS},
        "math_common_sha256": digest(root / "schemas" / "math" / "common.schema.json"),
        "math_valid_fixture_count": len(valid_files),
        "math_invalid_fixture_count": len(invalid_files),
        "math_valid_fixture_fingerprints": valid_fingerprints,
        "implementation_boundary": {
            "implemented": [
                "ACR Phase 0 canonical schemas",
                "ACR Phase 1 SPRC/CIO adapter",
                "ACR Phase 2 Semantic State Encoder",
                "AMRR M0 canonical mathematical schemas",
            ],
            "not_implemented": ["AMRR M1-M11 runtime capabilities"],
        },
    }
    (root / "AMRR_M0_MANIFEST.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    lines = []
    for path in payload_files(root):
        rel = path.relative_to(root).as_posix()
        lines.append(f"{digest(path)}  {rel}")
    (root / "AMRR_M0_CHECKSUMS.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({
        "release": manifest["release"],
        "phase0_schema_count": len(SCHEMA_SPECS),
        "math_schema_count": len(MATH_SCHEMA_SPECS),
        "math_valid_fixtures": len(valid_files),
        "math_invalid_fixtures": len(invalid_files),
        "checksum_files": len(lines),
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
