from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

EXCLUDED_FILES = {"CHECKSUMS.sha256"}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def payload_files(root: Path):
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if path.name in EXCLUDED_FILES:
            continue
        parts = rel.parts
        if ".git" in parts or ".pytest_cache" in parts or "__pycache__" in parts or ".worktrees" in parts:
            continue
        if any(part.endswith(".egg-info") for part in parts):
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        yield path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    from addressable_cognitive_runtime.adapters.sprc import build_sprc_registry
    from addressable_cognitive_runtime.schema_catalog import SCHEMA_SPECS, schema_path
    from addressable_cognitive_runtime.state.encoder import ENCODER_PROFILE, encode_semantic_state_file

    theory_docs = sorted(str(p.relative_to(root)) for p in (root / "docs" / "theory").glob("*.md"))
    sprc = build_sprc_registry()
    registry_path = root / "registry" / "ACR1-SPRC-CIO-v1.json"

    state_valid_root = root / "examples" / "state-observations" / "valid"
    state_invalid_root = root / "examples" / "state-observations" / "invalid"
    state_valid_files = sorted(state_valid_root.glob("*.json"))
    state_invalid_files = sorted(state_invalid_root.glob("*.json"))
    state_fingerprints = {
        path.name: encode_semantic_state_file(path)["fingerprint"]
        for path in state_valid_files
    }

    manifest = {
        "release": "ACR-MVP-v0.1-Phase2",
        "version": "0.1.2",
        "phase": "Phase 2 - Semantic State Encoder",
        "schema_count": len(SCHEMA_SPECS),
        "schema_tokens": {name: spec.token for name, spec in SCHEMA_SPECS.items()},
        "schema_sha256": {name: digest(schema_path(name)) for name in SCHEMA_SPECS},
        "theory_docs": theory_docs,
        "theory_doc_count": len(theory_docs),
        "sprc": {
            "registry_id": sprc["registry_id"],
            "registry_path": str(registry_path.relative_to(root)),
            "registry_fingerprint": sprc["fingerprint"],
            "registry_file_sha256": digest(registry_path),
            "object_count": sprc["object_count"],
            "source_package": sprc["source"]["source_package"],
            "semantic_compatibility": sprc["source"]["semantic_compatibility"],
            "operator_deck": sprc["source"]["operator_deck"],
            "deck_hash": sprc["source"]["deck_hash"],
            "wire_registry": sprc["source"]["wire_registry"],
            "registry_hash": sprc["source"]["registry_hash"],
            "corpus_release": sprc["source"]["corpus_release"],
        },
        "state_encoder": {
            "profile": ENCODER_PROFILE,
            "valid_observation_count": len(state_valid_files),
            "invalid_observation_count": len(state_invalid_files),
            "reference_state_fingerprints": state_fingerprints,
        },
    }
    (root / "MANIFEST.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    lines = []
    for path in payload_files(root):
        rel = path.relative_to(root).as_posix()
        lines.append(f"{digest(path)}  {rel}")
    (root / "CHECKSUMS.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({
        "files": len(lines),
        "schema_count": len(SCHEMA_SPECS),
        "sprc_object_count": sprc["object_count"],
        "state_valid_observations": len(state_valid_files),
        "state_invalid_observations": len(state_invalid_files),
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
