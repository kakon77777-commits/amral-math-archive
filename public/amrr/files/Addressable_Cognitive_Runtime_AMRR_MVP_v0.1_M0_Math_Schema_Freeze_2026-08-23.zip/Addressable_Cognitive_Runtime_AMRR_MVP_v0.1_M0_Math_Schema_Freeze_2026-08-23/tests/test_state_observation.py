from __future__ import annotations

from copy import deepcopy

import pytest

from addressable_cognitive_runtime.state.encoder import ObservationError, normalize_observation


def base_observation() -> dict:
    return {
        "authority_ref": "contract:v12",
        "goal_refs": ["goal:z", "goal:a", "goal:z"],
        "active_commitments": ["commitment:2", "commitment:1", "commitment:2"],
        "failures": ["tool_timeout", "parse_error", "tool_timeout"],
        "missing": ["evidence:b", "evidence:a"],
        "risks": ["risk:z", "risk:a", "risk:z"],
        "environment_refs": ["artifact:z", "artifact:a", "artifact:z"],
        "memory_refs": ["memory:2", "memory:1", "memory:2"],
        "budget": {
            "tokens_remaining": 100,
            "calls_remaining": 3,
            "money_remaining_usd": 0.5,
            "wall_time_remaining_ms": 5000,
            "depth_remaining": 2,
        },
        "extensions": {"source": "test"},
    }


def test_normalize_requires_authority_ref():
    obs = base_observation()
    obs.pop("authority_ref")
    with pytest.raises(ObservationError) as exc:
        normalize_observation(obs)
    assert exc.value.code == "missing_authority_ref"


def test_normalize_rejects_unknown_top_level_key():
    obs = base_observation()
    obs["surprise"] = 1
    with pytest.raises(ObservationError) as exc:
        normalize_observation(obs)
    assert exc.value.code == "unknown_observation_field"


@pytest.mark.parametrize("key", ["hidden_chain_of_thought", "private_chain_of_thought", "reasoning_tokens"])
def test_normalize_rejects_private_reasoning_fields(key: str):
    obs = base_observation()
    obs[key] = "do not ingest"
    with pytest.raises(ObservationError) as exc:
        normalize_observation(obs)
    assert exc.value.code == "private_reasoning_forbidden"


def test_normalize_sorts_and_deduplicates_set_like_lists_without_mutating_input():
    obs = base_observation()
    before = deepcopy(obs)
    normalized = normalize_observation(obs)

    assert obs == before
    assert normalized["goal_refs"] == ["goal:a", "goal:z"]
    assert normalized["active_commitments"] == ["commitment:1", "commitment:2"]
    assert normalized["failures"] == ["parse_error", "tool_timeout"]
    assert normalized["missing"] == ["evidence:a", "evidence:b"]
    assert normalized["risks"] == ["risk:a", "risk:z"]
    assert normalized["environment_refs"] == ["artifact:a", "artifact:z"]
    assert normalized["memory_refs"] == ["memory:1", "memory:2"]
    assert normalized["extensions"] == {"source": "test"}


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("tokens_remaining", -1),
        ("calls_remaining", True),
        ("wall_time_remaining_ms", 1.2),
        ("depth_remaining", -2),
        ("money_remaining_usd", -0.01),
    ],
)
def test_normalize_rejects_invalid_budget_values(field: str, value):
    obs = base_observation()
    obs["budget"][field] = value
    with pytest.raises(ObservationError) as exc:
        normalize_observation(obs)
    assert exc.value.code == "invalid_budget"


def test_normalize_rejects_invalid_authority_prefix():
    obs = base_observation()
    obs["authority_ref"] = "user:neo"
    with pytest.raises(ObservationError) as exc:
        normalize_observation(obs)
    assert exc.value.code == "invalid_authority_ref"


def test_normalize_defaults_optional_collections_and_budget():
    normalized = normalize_observation({"authority_ref": "authority:local"})
    assert normalized["goal_refs"] == []
    assert normalized["active_commitments"] == []
    assert normalized["failures"] == []
    assert normalized["missing"] == []
    assert normalized["risks"] == []
    assert normalized["environment_refs"] == []
    assert normalized["memory_refs"] == []
    assert normalized["budget"] == {}
    assert normalized["extensions"] == {}
