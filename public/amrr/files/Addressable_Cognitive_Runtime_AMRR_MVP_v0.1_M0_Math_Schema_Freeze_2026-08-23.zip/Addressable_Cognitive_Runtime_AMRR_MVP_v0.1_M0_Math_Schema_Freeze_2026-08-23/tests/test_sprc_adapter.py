import json
from pathlib import Path

import pytest

from addressable_cognitive_runtime.adapters.sprc import (
    build_cognitive_object,
    build_cognitive_objects,
    source_id_to_address,
)
from addressable_cognitive_runtime.validation import validate_object


SCHEMA_HASH = "sha256:2d38d9be37bb6425f4fde6ee2a40d593f95ad52ef94ef3bfd698b8b485541d29"


def test_source_id_to_address_is_source_preserving_and_versioned():
    assert source_id_to_address("R01") == "cog://sprc/cio/r01@1"
    assert source_id_to_address("M08") == "cog://sprc/cio/m08@1"
    with pytest.raises(ValueError, match="unknown SPRC operator ID"):
        source_id_to_address("Z99")


def test_r01_maps_without_promoting_affinity_to_hard_precondition():
    obj = build_cognitive_object("R01")
    assert obj["schema"] == "acr.cognitive-object/v0.1"
    assert obj["id"] == "cog://sprc/cio/r01@1"
    assert obj["version"] == 1
    assert obj["name"] == "Reverse"
    assert obj["type"] == "cognitive_operator"
    assert obj["preconditions"] == []
    assert obj["inputs"] == []
    assert obj["outputs"] == []
    assert obj["effects"] == []
    assert obj["cost_class"] == "unknown"
    assert obj["risk_class"] == "unknown"
    assert obj["compatible_with"] == []
    assert obj["conflicts_with"] == []
    assert obj["authority_class"] == "cognition_only"
    assert obj["termination"] == []
    assert obj["vector_ref"] is None
    assert obj["schema_hash"] == SCHEMA_HASH
    assert obj["renderers"]["zh-Hant"] == "不要從起點推；假設答案已經出現，往回問必須先有哪些條件？"
    assert obj["renderers"]["en"] == (
        "Trace backward from a candidate conclusion or endpoint to the premises and conditions "
        "that would make it possible."
    )
    sprc = obj["extensions"]["sprc"]
    assert sprc["source_operator_id"] == "R01"
    assert sprc["family"] == "R"
    assert sprc["definition"] == "從候選結論或終點向前提回推。"
    assert sprc["affinity"] == {"counterexample_found": 1.6}
    assert sprc["risks"] == ["必要條件可能被誤當充分條件。"]
    assert sprc["source_deck"] == "CIO-Deck-v1.0"
    assert sprc["source_registry"] == "SES1"
    assert sprc["source_corpus"] == "SPRC-Corpus-1.1.0"
    assert sprc["source_order_index"] == 0
    assert validate_object(obj).valid


def test_all_64_cards_convert_in_source_order_and_validate():
    objects = build_cognitive_objects()
    assert len(objects) == 64
    assert objects[0]["extensions"]["sprc"]["source_operator_id"] == "R01"
    assert objects[-1]["extensions"]["sprc"]["source_operator_id"] == "M08"
    assert len({obj["id"] for obj in objects}) == 64
    assert all(validate_object(obj).valid for obj in objects)


def test_conversion_is_deterministic_including_fingerprint():
    left = build_cognitive_objects()
    right = build_cognitive_objects()
    assert left == right
    assert all(obj["fingerprint"].startswith("sha256:") for obj in left)
    assert len({obj["fingerprint"] for obj in left}) == 64
