from collections import Counter

import pytest

from addressable_cognitive_runtime.adapters.sprc import (
    EXPECTED_DECK_HASH,
    EXPECTED_REGISTRY_HASH,
    load_sprc_source,
    verify_sprc_source,
)


def test_sprc_source_profile_is_frozen_v22():
    source = load_sprc_source()
    assert source.profile["source_package"] == "Semantic_Persona_Runtime_v2.2.0"
    assert source.profile["semantic_compatibility"] == ["2.1.0", "2.2.0"]
    assert source.profile["operator_deck"] == "CIO-Deck-v1.0"
    assert source.profile["wire_registry"] == "SES1"


def test_sprc_source_hashes_and_shape_match_canonical_source():
    source = load_sprc_source()
    result = verify_sprc_source(source)
    assert result.deck_hash == EXPECTED_DECK_HASH
    assert result.registry_hash == EXPECTED_REGISTRY_HASH
    assert result.operator_count == 64
    assert Counter(card["family"] for card in source.deck["cards"]) == {
        "R": 8, "S": 8, "X": 8, "C": 8,
        "D": 8, "A": 8, "T": 8, "M": 8,
    }


def test_sprc_source_fails_closed_on_deck_hash_mismatch():
    source = load_sprc_source()
    source.deck["cards"][0]["definition"] += " tampered"
    with pytest.raises(ValueError, match="deck hash mismatch"):
        verify_sprc_source(source)
