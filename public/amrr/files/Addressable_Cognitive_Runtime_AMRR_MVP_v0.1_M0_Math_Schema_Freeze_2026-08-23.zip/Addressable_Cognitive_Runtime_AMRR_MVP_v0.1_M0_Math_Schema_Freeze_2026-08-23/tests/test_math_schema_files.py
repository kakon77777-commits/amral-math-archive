import json
from pathlib import Path

from jsonschema import Draft202012Validator

from addressable_cognitive_runtime.schema_catalog import MATH_SCHEMA_SPECS, schema_path, schema_root


def test_math_common_schema_is_well_formed_and_has_required_defs():
    path = schema_root() / "math" / "common.schema.json"
    schema = json.loads(path.read_text(encoding="utf-8"))
    assert schema["$schema"] == "https://json-schema.org/draft/2020-12/schema"
    assert schema["$id"] == "urn:amrr:schema:common:v0.1"
    Draft202012Validator.check_schema(schema)
    required_defs = {
        "problem_relation",
        "math_domain",
        "theory_extension_class",
        "obligation_status",
        "verifier_class",
        "verification_result",
        "bridge_relation",
        "bridge_strength",
        "novelty_status",
    }
    assert required_defs <= set(schema["$defs"])


def test_all_nineteen_math_schemas_are_draft_2020_12_and_well_formed():
    assert len(MATH_SCHEMA_SPECS) == 19
    for name in MATH_SCHEMA_SPECS:
        schema = json.loads(schema_path(name).read_text(encoding="utf-8"))
        assert schema["$schema"] == "https://json-schema.org/draft/2020-12/schema", name
        Draft202012Validator.check_schema(schema)


def test_math_identity_boundary_is_explicit_and_top_level_is_closed():
    required_identity = {"schema", "id", "version", "fingerprint"}
    for name in MATH_SCHEMA_SPECS:
        schema = json.loads(schema_path(name).read_text(encoding="utf-8"))
        assert required_identity <= set(schema["required"]), name
        assert schema["additionalProperties"] is False, name
        assert "extensions" in schema["properties"], name
        assert schema["properties"]["extensions"].get("$ref") == "urn:acr:schema:common:v0.1#/$defs/extensions", name


def test_math_schema_tokens_are_frozen_in_schema_field():
    for name, spec in MATH_SCHEMA_SPECS.items():
        schema = json.loads(schema_path(name).read_text(encoding="utf-8"))
        assert schema["properties"]["schema"]["const"] == spec.token, name


def test_math_schema_paths_are_stable_and_exist():
    for name, spec in MATH_SCHEMA_SPECS.items():
        path = schema_path(name)
        assert isinstance(path, Path)
        assert path.as_posix().endswith(f"schemas/math/{name}.schema.json")
        assert path.exists(), name
