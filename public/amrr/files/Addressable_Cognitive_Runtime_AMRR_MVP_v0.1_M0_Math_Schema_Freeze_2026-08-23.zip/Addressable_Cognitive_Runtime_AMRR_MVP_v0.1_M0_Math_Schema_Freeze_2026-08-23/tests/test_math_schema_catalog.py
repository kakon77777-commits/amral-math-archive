from addressable_cognitive_runtime.schema_catalog import (
    ALL_SCHEMA_SPECS,
    MATH_SCHEMA_SPECS,
    SCHEMA_SPECS,
    schema_name_for_token,
    schema_path,
)

EXPECTED_MATH = {
    "mathematical-state-extension": "amrr.mathematical-state-extension/v0.1",
    "problem-record": "amrr.problem-record/v0.1",
    "problem-relation": "amrr.problem-relation/v0.1",
    "problem-mutation": "amrr.problem-mutation/v0.1",
    "assumption-envelope": "amrr.assumption-envelope/v0.1",
    "theory-record": "amrr.theory-record/v0.1",
    "theory-extension": "amrr.theory-extension/v0.1",
    "math-change-set": "amrr.math-change-set/v0.1",
    "gap": "amrr.gap/v0.1",
    "gap-map": "amrr.gap-map/v0.1",
    "repair-candidate": "amrr.repair-candidate/v0.1",
    "mathematical-obligation": "amrr.mathematical-obligation/v0.1",
    "obligation-graph": "amrr.obligation-graph/v0.1",
    "verification-request": "amrr.verification-request/v0.1",
    "verification-receipt": "amrr.verification-receipt/v0.1",
    "theory-bridge": "amrr.theory-bridge/v0.1",
    "discovery-receipt": "amrr.discovery-receipt/v0.1",
    "research-receipt": "amrr.research-receipt/v0.1",
    "claim-record": "amrr.claim-record/v0.1",
}


def test_phase0_catalog_stays_frozen_at_ten():
    assert len(SCHEMA_SPECS) == 10


def test_math_catalog_is_exactly_m0_nineteen():
    assert {name: spec.token for name, spec in MATH_SCHEMA_SPECS.items()} == EXPECTED_MATH
    assert len(ALL_SCHEMA_SPECS) == 29


def test_math_paths_live_under_math_subdirectory():
    for name in EXPECTED_MATH:
        assert schema_path(name).parent.name == "math"


def test_math_tokens_reverse_resolve():
    for name, token in EXPECTED_MATH.items():
        assert schema_name_for_token(token) == name
