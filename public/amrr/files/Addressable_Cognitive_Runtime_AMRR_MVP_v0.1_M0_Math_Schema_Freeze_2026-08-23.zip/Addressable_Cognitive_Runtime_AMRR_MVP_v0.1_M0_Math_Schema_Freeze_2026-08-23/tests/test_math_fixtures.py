from __future__ import annotations

import json
from pathlib import Path

from addressable_cognitive_runtime.canonical import fingerprint_object
from addressable_cognitive_runtime.schema_catalog import MATH_SCHEMA_SPECS
from addressable_cognitive_runtime.validation import validate_object

ROOT = Path(__file__).resolve().parents[1]


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def test_math_fixture_counts_are_frozen_for_m0():
    valid_files = sorted((ROOT / "examples" / "math" / "valid").glob("*.json"))
    invalid_files = sorted((ROOT / "examples" / "math" / "invalid").glob("*.json"))
    assert len(valid_files) == 19
    assert len(invalid_files) >= 8


def test_all_valid_math_fixtures_validate_and_have_canonical_fingerprints():
    valid_files = sorted((ROOT / "examples" / "math" / "valid").glob("*.json"))
    assert valid_files
    seen = set()
    for path in valid_files:
        obj = load(path)
        result = validate_object(obj)
        assert result.valid, (path.name, result.issues)
        assert result.schema_name in MATH_SCHEMA_SPECS
        assert obj["fingerprint"] == fingerprint_object(obj), path.name
        seen.add(result.schema_name)
    assert seen == set(MATH_SCHEMA_SPECS)


def test_all_deliberate_invalid_math_fixtures_are_rejected():
    invalid_files = sorted((ROOT / "examples" / "math" / "invalid").glob("*.json"))
    assert invalid_files
    for path in invalid_files:
        result = validate_object(load(path))
        assert not result.valid, path.name
