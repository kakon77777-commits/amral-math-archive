from __future__ import annotations

from pathlib import Path

import pytest

from addressable_cognitive_runtime.state.encoder import ObservationError, encode_semantic_state_file
from addressable_cognitive_runtime.validation import validate_object

ROOT = Path(__file__).resolve().parents[1]
VALID = ROOT / "examples" / "state-observations" / "valid"
INVALID = ROOT / "examples" / "state-observations" / "invalid"


def test_valid_state_observation_fixtures_encode_and_validate():
    encoded = {path.name: encode_semantic_state_file(path) for path in sorted(VALID.glob("*.json"))}
    assert len(encoded) == 3
    assert encoded["repo-failing.json"]["progress"] == "stalled"
    assert encoded["repo-failing.json"]["uncertainty"] == "high"
    assert encoded["repo-clean.json"]["progress"] == "completed"
    assert encoded["repo-clean.json"]["uncertainty"] == "low"
    assert encoded["pending.json"]["progress"] == "not_started"
    assert encoded["pending.json"]["uncertainty"] == "unknown"
    assert all(validate_object(state).valid for state in encoded.values())


def test_invalid_state_observation_fixtures_fail_closed_with_expected_codes():
    expected = {
        "unknown-field.json": "unknown_observation_field",
        "private-reasoning.json": "private_reasoning_forbidden",
        "bad-budget.json": "invalid_budget",
        "missing-authority.json": "missing_authority_ref",
    }
    for name, code in expected.items():
        with pytest.raises(ObservationError) as exc:
            encode_semantic_state_file(INVALID / name)
        assert exc.value.code == code


def test_reencoding_same_fixture_is_exactly_deterministic():
    path = VALID / "repo-failing.json"
    assert encode_semantic_state_file(path) == encode_semantic_state_file(path)
