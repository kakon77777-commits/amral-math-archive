from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from addressable_cognitive_runtime import __version__
from addressable_cognitive_runtime.schema_catalog import MATH_SCHEMA_SPECS, SCHEMA_SPECS

ROOT = Path(__file__).resolve().parents[1]
PHASE1_REGISTRY_FINGERPRINT = "sha256:435cdfe0fc962e15ffd83e489274a0da4c6b6fa756c8bc20c0939fe6e395d9bd"


def test_m0_keeps_core_version_and_catalog_boundaries_separate():
    assert __version__ == "0.1.2"
    assert len(SCHEMA_SPECS) == 10
    assert len(MATH_SCHEMA_SPECS) == 19


def test_m0_manifest_records_additive_release_boundary():
    manifest = json.loads((ROOT / "AMRR_M0_MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["release"] == "ACR-AMRR-MVP-v0.1-M0"
    assert manifest["version"] == "0.1.0"
    assert manifest["phase"] == "AMRR M0 - Math Schema Freeze"
    assert manifest["phase0_schema_count"] == 10
    assert manifest["math_schema_count"] == 19
    assert manifest["phase1_registry_fingerprint"] == PHASE1_REGISTRY_FINGERPRINT
    assert manifest["implementation_boundary"]["implemented"] == [
        "ACR Phase 0 canonical schemas",
        "ACR Phase 1 SPRC/CIO adapter",
        "ACR Phase 2 Semantic State Encoder",
        "AMRR M0 canonical mathematical schemas",
    ]
    assert manifest["implementation_boundary"]["not_implemented"] == ["AMRR M1-M11 runtime capabilities"]


def test_m0_release_validator_reports_ok():
    script = ROOT / "scripts" / "validate_amrr_m0.py"
    result = subprocess.run(
        [sys.executable, str(script), "--root", str(ROOT)],
        cwd=ROOT,
        env=dict(os.environ, PYTHONPATH=str(ROOT / "src")),
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["phase0_schema_count"] == 10
    assert payload["math_schema_count"] == 19
    assert payload["math_valid_fixtures"] == 19
    assert payload["math_invalid_fixtures"] >= 8
