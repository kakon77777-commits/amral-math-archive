from addressable_cognitive_runtime.canonical import canonical_bytes, fingerprint_object


def test_canonical_bytes_are_stable_and_omit_only_top_level_fingerprint():
    left = {"b": 2, "a": 1, "fingerprint": "sha256:" + "0" * 64, "nested": {"fingerprint": "keep"}}
    right = {"nested": {"fingerprint": "keep"}, "a": 1, "b": 2, "fingerprint": "sha256:" + "f" * 64}
    assert canonical_bytes(left) == canonical_bytes(right)
    assert b'"fingerprint":"keep"' in canonical_bytes(left)
    assert b'"fingerprint":"sha256:' not in canonical_bytes(left)


def test_fingerprint_is_deterministic_and_content_sensitive():
    obj = {"schema": "x", "id": "y", "version": 1, "fingerprint": "ignored", "value": 3}
    first = fingerprint_object(obj)
    second = fingerprint_object(dict(reversed(list(obj.items()))))
    assert first == second
    assert first.startswith("sha256:") and len(first) == 71
    changed = dict(obj, value=4)
    assert fingerprint_object(changed) != first
