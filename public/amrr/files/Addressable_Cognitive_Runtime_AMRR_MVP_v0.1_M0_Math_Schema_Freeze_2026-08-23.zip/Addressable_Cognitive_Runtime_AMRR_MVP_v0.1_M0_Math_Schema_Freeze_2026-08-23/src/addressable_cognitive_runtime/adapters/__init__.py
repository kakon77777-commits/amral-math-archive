"""Adapters for existing cognitive runtimes and registries."""
