from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from typing import Any, Mapping


def canonical_bytes(obj: Mapping[str, Any]) -> bytes:
    """Return canonical UTF-8 JSON bytes, omitting only top-level fingerprint."""
    payload = deepcopy(dict(obj))
    payload.pop("fingerprint", None)
    text = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )
    return text.encode("utf-8")


def fingerprint_object(obj: Mapping[str, Any]) -> str:
    return "sha256:" + hashlib.sha256(canonical_bytes(obj)).hexdigest()
