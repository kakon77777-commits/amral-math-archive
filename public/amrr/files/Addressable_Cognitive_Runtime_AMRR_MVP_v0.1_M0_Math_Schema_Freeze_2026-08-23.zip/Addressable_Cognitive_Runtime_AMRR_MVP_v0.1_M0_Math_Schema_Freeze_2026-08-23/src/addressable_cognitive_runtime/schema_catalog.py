from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class SchemaSpec:
    name: str
    token: str
    filename: str


_PHASE0_SCHEMA_ROWS = (
    ("cognitive-object", "acr.cognitive-object/v0.1"),
    ("semantic-state", "acr.semantic-state/v0.1"),
    ("cognitive-program", "acr.cognitive-program/v0.1"),
    ("agenda-candidate", "acr.agenda-candidate/v0.1"),
    ("contract", "acr.contract/v0.1"),
    ("governance-decision", "acr.governance-decision/v0.1"),
    ("decision-receipt", "acr.decision-receipt/v0.1"),
    ("knowledge-boundary", "acr.knowledge-boundary/v0.1"),
    ("commitment", "acr.commitment/v0.1"),
    ("context-compression-event", "acr.context-compression-event/v0.1"),
)

_MATH_SCHEMA_ROWS = (
    ("mathematical-state-extension", "amrr.mathematical-state-extension/v0.1"),
    ("problem-record", "amrr.problem-record/v0.1"),
    ("problem-relation", "amrr.problem-relation/v0.1"),
    ("problem-mutation", "amrr.problem-mutation/v0.1"),
    ("assumption-envelope", "amrr.assumption-envelope/v0.1"),
    ("theory-record", "amrr.theory-record/v0.1"),
    ("theory-extension", "amrr.theory-extension/v0.1"),
    ("math-change-set", "amrr.math-change-set/v0.1"),
    ("gap", "amrr.gap/v0.1"),
    ("gap-map", "amrr.gap-map/v0.1"),
    ("repair-candidate", "amrr.repair-candidate/v0.1"),
    ("mathematical-obligation", "amrr.mathematical-obligation/v0.1"),
    ("obligation-graph", "amrr.obligation-graph/v0.1"),
    ("verification-request", "amrr.verification-request/v0.1"),
    ("verification-receipt", "amrr.verification-receipt/v0.1"),
    ("theory-bridge", "amrr.theory-bridge/v0.1"),
    ("discovery-receipt", "amrr.discovery-receipt/v0.1"),
    ("research-receipt", "amrr.research-receipt/v0.1"),
    ("claim-record", "amrr.claim-record/v0.1"),
)

# Frozen ACR Phase-0 catalog. Existing release validators intentionally depend on
# this containing exactly the original ten schemas.
SCHEMA_SPECS = {
    name: SchemaSpec(name=name, token=token, filename=f"{name}.schema.json")
    for name, token in _PHASE0_SCHEMA_ROWS
}

# AMRR M0 is an additive domain catalog; it must not mutate the Phase-0 freeze.
MATH_SCHEMA_SPECS = {
    name: SchemaSpec(name=name, token=token, filename=f"math/{name}.schema.json")
    for name, token in _MATH_SCHEMA_ROWS
}

ALL_SCHEMA_SPECS = {**SCHEMA_SPECS, **MATH_SCHEMA_SPECS}
_TOKEN_TO_NAME = {spec.token: name for name, spec in ALL_SCHEMA_SPECS.items()}


def schema_root() -> Path:
    return Path(__file__).resolve().parents[2] / "schemas"


def schema_path(name: str) -> Path:
    try:
        spec = ALL_SCHEMA_SPECS[name]
    except KeyError as exc:
        raise KeyError(f"unknown schema name: {name}") from exc
    return schema_root() / spec.filename


def schema_name_for_token(token: str) -> str | None:
    return _TOKEN_TO_NAME.get(token)
