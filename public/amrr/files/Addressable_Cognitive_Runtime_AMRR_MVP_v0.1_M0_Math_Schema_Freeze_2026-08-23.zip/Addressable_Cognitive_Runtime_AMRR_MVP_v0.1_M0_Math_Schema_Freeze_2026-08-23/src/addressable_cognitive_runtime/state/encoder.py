from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any, Mapping

from ..canonical import fingerprint_object
from ..validation import validate_object


PRIVATE_REASONING_FIELDS = {
    "hidden_chain_of_thought",
    "private_chain_of_thought",
    "reasoning_tokens",
}

ALLOWED_FIELDS = {
    "goal_refs",
    "active_commitments",
    "progress",
    "status",
    "started",
    "completed",
    "blocked",
    "stalled",
    "repeated_failure_count",
    "uncertainty",
    "confidence",
    "verification_status",
    "failures",
    "missing",
    "risks",
    "budget",
    "authority_ref",
    "environment_refs",
    "memory_refs",
    "extensions",
}

LIST_FIELDS = {
    "goal_refs",
    "active_commitments",
    "failures",
    "missing",
    "risks",
    "environment_refs",
    "memory_refs",
}

BUDGET_INTEGER_FIELDS = {
    "tokens_remaining",
    "calls_remaining",
    "wall_time_remaining_ms",
    "depth_remaining",
}
BUDGET_NUMBER_FIELDS = {"money_remaining_usd"}
BUDGET_FIELDS = BUDGET_INTEGER_FIELDS | BUDGET_NUMBER_FIELDS | {"extensions"}

PROGRESS_VALUES = {"not_started", "in_progress", "stalled", "blocked", "completed", "unknown"}
STATUS_VALUES = {
    "completed", "succeeded", "done",
    "blocked", "waiting_external", "waiting_approval",
    "stalled",
    "running", "in_progress", "active",
    "not_started", "pending", "new",
    "unknown",
}
UNCERTAINTY_VALUES = {"low", "medium", "high", "unknown"}
VERIFICATION_VALUES = {"verified", "partial", "unverified", "failed", "contradicted", "unknown"}
ENCODER_PROFILE = "acr.semantic-state-encoder/v0.1"


@dataclass(frozen=True)
class ObservationError(ValueError):
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


def _fail(code: str, message: str) -> None:
    raise ObservationError(code=code, message=message)


def _clean_nonempty_string(value: Any, *, code: str, field: str) -> str:
    if not isinstance(value, str):
        _fail(code, f"{field} must be a string")
    cleaned = value.strip()
    if not cleaned:
        _fail(code, f"{field} must be non-empty")
    return cleaned


def _normalize_string_list(value: Any, *, field: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        _fail("invalid_observation_list", f"{field} must be an array of strings")
    cleaned: list[str] = []
    for item in value:
        cleaned.append(_clean_nonempty_string(item, code="invalid_observation_list", field=field))
    return sorted(set(cleaned))


def _validate_prefixed_refs(values: list[str], prefixes: tuple[str, ...], *, field: str) -> None:
    for value in values:
        if not value.startswith(prefixes):
            _fail("invalid_reference", f"{field} contains invalid reference: {value}")


def _normalize_budget(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        _fail("invalid_budget", "budget must be an object")
    unknown = sorted(set(value) - BUDGET_FIELDS)
    if unknown:
        _fail("invalid_budget", f"budget contains unknown fields: {', '.join(unknown)}")

    result: dict[str, Any] = {}
    for field in sorted(BUDGET_INTEGER_FIELDS):
        if field not in value:
            continue
        item = value[field]
        if isinstance(item, bool) or not isinstance(item, int) or item < 0:
            _fail("invalid_budget", f"{field} must be a non-negative integer")
        result[field] = item

    for field in sorted(BUDGET_NUMBER_FIELDS):
        if field not in value:
            continue
        item = value[field]
        if isinstance(item, bool) or not isinstance(item, (int, float)) or item < 0:
            _fail("invalid_budget", f"{field} must be a non-negative number")
        result[field] = item

    if "extensions" in value:
        ext = value["extensions"]
        if not isinstance(ext, Mapping):
            _fail("invalid_budget", "budget.extensions must be an object")
        result["extensions"] = deepcopy(dict(ext))

    return result


def normalize_observation(observation: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(observation, Mapping):
        _fail("not_observation_object", "observation must be an object")

    private = sorted(set(observation) & PRIVATE_REASONING_FIELDS)
    if private:
        _fail("private_reasoning_forbidden", f"private reasoning fields are forbidden: {', '.join(private)}")

    unknown = sorted(set(observation) - ALLOWED_FIELDS)
    if unknown:
        _fail("unknown_observation_field", f"unknown observation fields: {', '.join(unknown)}")

    if "authority_ref" not in observation:
        _fail("missing_authority_ref", "authority_ref is required")
    authority_ref = _clean_nonempty_string(
        observation["authority_ref"], code="invalid_authority_ref", field="authority_ref"
    )
    if not authority_ref.startswith(("authority:", "contract:")):
        _fail("invalid_authority_ref", "authority_ref must start with authority: or contract:")

    normalized: dict[str, Any] = {
        "goal_refs": _normalize_string_list(observation.get("goal_refs"), field="goal_refs"),
        "active_commitments": _normalize_string_list(
            observation.get("active_commitments"), field="active_commitments"
        ),
        "failures": _normalize_string_list(observation.get("failures"), field="failures"),
        "missing": _normalize_string_list(observation.get("missing"), field="missing"),
        "risks": _normalize_string_list(observation.get("risks"), field="risks"),
        "budget": _normalize_budget(observation.get("budget")),
        "authority_ref": authority_ref,
        "environment_refs": _normalize_string_list(
            observation.get("environment_refs"), field="environment_refs"
        ),
        "memory_refs": _normalize_string_list(observation.get("memory_refs"), field="memory_refs"),
    }

    _validate_prefixed_refs(normalized["goal_refs"], ("goal:",), field="goal_refs")
    _validate_prefixed_refs(
        normalized["active_commitments"], ("commitment:",), field="active_commitments"
    )
    _validate_prefixed_refs(
        normalized["environment_refs"],
        ("artifact:", "environment:", "env:", "tool:", "file:", "state:", "repo:", "test:"),
        field="environment_refs",
    )
    _validate_prefixed_refs(
        normalized["memory_refs"], ("memory:", "artifact:", "state:", "kb:", "decision:"), field="memory_refs"
    )

    extensions = observation.get("extensions", {})
    if not isinstance(extensions, Mapping):
        _fail("invalid_extensions", "extensions must be an object")
    normalized["extensions"] = deepcopy(dict(extensions))

    enum_fields = {
        "progress": PROGRESS_VALUES,
        "status": STATUS_VALUES,
        "uncertainty": UNCERTAINTY_VALUES,
        "verification_status": VERIFICATION_VALUES,
    }
    for field, allowed in enum_fields.items():
        if field in observation:
            cleaned = _clean_nonempty_string(
                observation[field], code=f"invalid_{field}", field=field
            )
            if cleaned not in allowed:
                _fail(f"invalid_{field}", f"{field} has unsupported value: {cleaned}")
            normalized[field] = cleaned

    for field in ("started", "completed", "blocked", "stalled"):
        if field in observation:
            value = observation[field]
            if not isinstance(value, bool):
                _fail("invalid_observation_flag", f"{field} must be boolean")
            normalized[field] = value

    if "repeated_failure_count" in observation:
        value = observation["repeated_failure_count"]
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            _fail("invalid_repeated_failure_count", "repeated_failure_count must be a non-negative integer")
        normalized["repeated_failure_count"] = value

    if "confidence" in observation:
        value = observation["confidence"]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= value <= 1:
            _fail("invalid_confidence", "confidence must be a number in [0,1]")
        normalized["confidence"] = value

    return normalized


def derive_progress(observation: Mapping[str, Any]) -> str:
    explicit = observation.get("progress")
    if isinstance(explicit, str):
        return explicit

    status = observation.get("status")
    if observation.get("completed") is True or status in {"completed", "succeeded", "done"}:
        return "completed"
    if observation.get("blocked") is True or status in {"blocked", "waiting_external", "waiting_approval"}:
        return "blocked"
    repeated_failure_count = observation.get("repeated_failure_count", 0)
    if observation.get("stalled") is True or status == "stalled" or repeated_failure_count >= 2:
        return "stalled"
    if observation.get("started") is True or status in {"running", "in_progress", "active"}:
        return "in_progress"
    if status in {"not_started", "pending", "new"}:
        return "not_started"
    return "unknown"


def derive_uncertainty(observation: Mapping[str, Any]) -> str:
    explicit = observation.get("uncertainty")
    if isinstance(explicit, str):
        return explicit

    levels: list[str] = []
    confidence = observation.get("confidence")
    if isinstance(confidence, (int, float)) and not isinstance(confidence, bool):
        if confidence >= 0.85:
            levels.append("low")
        elif confidence >= 0.60:
            levels.append("medium")
        else:
            levels.append("high")

    verification = observation.get("verification_status")
    if verification == "verified":
        levels.append("low")
    elif verification == "partial":
        levels.append("medium")
    elif verification in {"unverified", "failed", "contradicted"}:
        levels.append("high")

    if not levels:
        return "unknown"
    severity = {"low": 1, "medium": 2, "high": 3}
    return max(levels, key=severity.__getitem__)


def _semantic_core(normalized: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "goal_refs": list(normalized["goal_refs"]),
        "active_commitments": list(normalized["active_commitments"]),
        "progress": derive_progress(normalized),
        "uncertainty": derive_uncertainty(normalized),
        "failures": list(normalized["failures"]),
        "missing": list(normalized["missing"]),
        "risks": list(normalized["risks"]),
        "budget": deepcopy(dict(normalized["budget"])),
        "authority_ref": normalized["authority_ref"],
        "environment_refs": list(normalized["environment_refs"]),
        "memory_refs": list(normalized["memory_refs"]),
    }


def _semantic_core_digest(core: Mapping[str, Any]) -> str:
    raw = json.dumps(
        dict(core), sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def encode_semantic_state(observation: Mapping[str, Any]) -> dict[str, Any]:
    normalized = normalize_observation(observation)
    core = _semantic_core(normalized)
    state: dict[str, Any] = {
        "schema": "acr.semantic-state/v0.1",
        "id": f"state:sha256:{_semantic_core_digest(core)}",
        "version": 1,
        "fingerprint": "sha256:" + "0" * 64,
        "extensions": {"state_encoder": {"profile": ENCODER_PROFILE}},
        **core,
    }
    state["fingerprint"] = fingerprint_object(state)
    result = validate_object(state, schema_name="semantic-state")
    if not result.valid:
        message = "; ".join(f"{issue.code}: {issue.message}" for issue in result.issues)
        _fail("encoded_state_invalid", message)
    return state


def encode_semantic_state_file(path: str | Path) -> dict[str, Any]:
    source = Path(path)
    try:
        value = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _fail("invalid_observation_json", str(exc))
    if not isinstance(value, Mapping):
        _fail("not_observation_object", "observation JSON root must be an object")
    return encode_semantic_state(value)
