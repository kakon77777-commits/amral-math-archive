# Addressable Cognitive Runtime (ACR) MVP v0.1

**Phase 2 — Semantic State Encoder**

ACR is the implementation line for a bounded persistent AI runtime that can address cognition, normalize public runtime state, later retrieve state-matched cognitive affordances, separate cognition from governance, and preserve temporal-causal evidence through CTCL-ITR adapters.

Phase 0 froze the persistence/interchange schemas. Phase 1 adapted the existing SES1 / CIO-Deck-v1.0 semantic source into 64 addressable CognitiveObjects. Phase 2 now adds a deterministic **public-state encoder** that maps structured observations into the frozen `SemanticState` boundary.

## Frozen invariants

- `Prompt != Cognition`
- `Cognition != Governance != WorldCommit`
- `CurrentMemory != HistoricalLedger`
- `Can != Should != Authorized`
- `DecisionReceipt != CommitReceipt`
- Phase 0 schema hashes remain unchanged.
- Phase 1 SPRC/CIO registry fingerprint remains unchanged.
- Phase 2 consumes public structured facts only; private/hidden chain-of-thought is not an input contract.

## Phase 2 state flow

```text
Public Observation
→ strict normalization
→ deterministic progress / uncertainty derivation
→ content-addressed SemanticState ID
→ canonical Phase 0 fingerprint
→ frozen SemanticState validation
```

The encoder does **not** perform Phase 3 operator retrieval and does not call a model, embedding service, CTCL server, or external network.

## Public Observation boundary

Accepted facts include:

- `goal_refs`
- `active_commitments`
- explicit `progress` or public status/flags
- explicit `uncertainty`, public `confidence`, `verification_status`
- `failures`, `missing`, `risks`
- remaining budget
- `authority_ref`
- `environment_refs`, `memory_refs`

Unknown top-level fields fail closed. Explicit private-reasoning fields such as `hidden_chain_of_thought`, `private_chain_of_thought`, and `reasoning_tokens` are rejected with a dedicated boundary error.

Set-like arrays are sorted and deduplicated, so order-only input differences produce the same semantic state.

## Progress derivation

When explicit `progress` is absent, Phase 2 uses only deterministic public rules:

```text
completed
> blocked
> stalled / repeated_failure_count >= 2
> in_progress
> not_started
> unknown
```

## Uncertainty derivation

Explicit `uncertainty` wins. Otherwise public confidence and verification status are combined conservatively by maximum severity:

```text
confidence >= 0.85  -> low
confidence >= 0.60  -> medium
confidence < 0.60   -> high

verified             -> low
partial              -> medium
unverified/failed/
contradicted          -> high
```

## Stable identity

`SemanticState.id` is content-addressed from the normalized semantic core:

```text
state:sha256:<64 lowercase hex>
```

The complete object then receives the existing Phase 0 canonical fingerprint. Equivalent normalized public observations are byte-identical.

## Phase 1 cognition remains intact

- Registry: `registry/ACR1-SPRC-CIO-v1.json`
- Object count: `64`
- Registry fingerprint: `sha256:435cdfe0fc962e15ffd83e489274a0da4c6b6fa756c8bc20c0939fe6e395d9bd`
- Source deck: `CIO-Deck-v1.0`
- SES1 registry hash: `4b33ac3b60407db3641c7ea5f3220c5cb4764578143c1fa15bc5198a2481a33d`

## CLI

```bash
acr-schema list
acr-schema validate examples/valid/cognitive-object.json
acr-schema sprc-info
acr-schema sprc-resolve R01
acr-schema state-encode examples/state-observations/valid/repo-failing.json
acr-schema state-encode examples/state-observations/valid/repo-clean.json --output state.json
```

## Project layout

```text
schemas/                         frozen Phase 0 JSON Schemas
registry/                        Phase 1 ACR SPRC/CIO registry
vendor/sprc/v2.2.0/              frozen Phase 1 semantic source snapshot
src/addressable_cognitive_runtime/state/
                                 Phase 2 public-state encoder
examples/state-observations/     Phase 2 valid/invalid observation fixtures
tests/                           Phase 0 + 1 + 2 regression suite
docs/theory/                     six-paper theory/whitepaper series
docs/superpowers/                design + implementation plans
scripts/                         release metadata / validator
```

## Release validation

```bash
python -m pip install --no-deps --no-build-isolation -e .
python -m pytest -q
python -m compileall -q src
PYTHONPATH=src python scripts/build_release_metadata.py --root .
PYTHONPATH=src python scripts/validate_release.py --root .
```

## Next phase

**Phase 3 — Cognitive Affordance Retriever** will consume the normalized `SemanticState` and the 64-object Phase 1 registry to produce a state-matched candidate cognition set. It must begin with deterministic precondition/filter/rule scoring before any learned routing is introduced.

## AMRR M0 additive extension

This source tree now includes the **AMRR M0 — Math Schema Freeze** as an additive domain layer over the existing ACR Phase 0–2 baseline.

Implemented Baseline:

- ACR Phase 0 canonical schemas (original 10 schemas unchanged)
- ACR Phase 1 SPRC/CIO adapter and 64-object registry
- ACR Phase 2 deterministic public Semantic State Encoder
- AMRR M0 canonical mathematical schemas (19 schemas under `schemas/math/`)
- AMRR M0 valid/invalid reference fixtures and additive release validator

Not Implemented Yet:

- AMRR M1–M11 runtime capabilities
- mathematical state adapter execution
- gap diagnosis execution
- problem/theory store runtime
- obligation engine execution
- `cog://math/*` runtime registry execution
- verifier routing/execution
- CMDC repair execution
- theory-bridge/prior-art runtime
- CTCL math event emission
- persistent autonomous mathematical research loop

The implementation-status boundary is deliberate: M0 freezes the data contracts that later phases depend on; it does not claim those later runtime capabilities already exist.
