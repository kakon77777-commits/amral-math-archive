# AMRR MVP v0.1 — Phase M0 Validation

**Phase:** M0 — Math Schema Freeze  
**AMRR M0 metadata version:** `0.1.0`  
**Base ACR package version:** `0.1.2`  
**Date:** 2026-08-23

M0 adds a canonical mathematical object layer without claiming execution of AMRR M1–M11 runtime capabilities.

## Implementation boundary

Implemented in this package:

- ACR Phase 0 canonical schemas;
- ACR Phase 1 SPRC/CIO adapter and 64-object registry;
- ACR Phase 2 deterministic public Semantic State Encoder;
- AMRR M0 schema catalog with 19 canonical mathematical object schemas;
- AMRR math common definitions;
- valid and deliberately invalid AMRR M0 reference fixtures;
- additive AMRR M0 metadata and release validator.

Not implemented in M0:

- mathematical state adapter execution (M1);
- Problem / Theory Stores runtime (M2);
- Gap Diagnosis execution (M3);
- Problem Identity / Theory Extension runtime (M4);
- Obligation Engine execution (M5);
- `cog://math/*` runtime registry execution (M6);
- Verifier Router execution (M7);
- CMDC Repair Engine execution (M8);
- Theory Bridge / prior-art runtime (M9);
- CTCL mathematical event emission (M10);
- Persistent autonomous research loop (M11).

## Frozen ACR regression evidence

- Phase 0 schema count: `10`.
- Phase 0 schema bytes / SHA-256: unchanged from the Phase-2 baseline.
- Phase 1 SPRC/CIO object count: `64`.
- Phase 1 registry fingerprint: `sha256:435cdfe0fc962e15ffd83e489274a0da4c6b6fa756c8bc20c0939fe6e395d9bd`.
- Phase 2 encoder profile: `acr.semantic-state-encoder/v0.1`.
- Phase 2 valid observation fixtures: `3/3`.
- Phase 2 invalid observation fixtures rejected: `4/4`.
- Phase 2 reference-state deterministic rebuild: PASS.

## AMRR M0 schema evidence

- Canonical AMRR M0 schema count: `19`.
- Helper schemas not counted as canonical objects: `1` (`schemas/math/common.schema.json`).
- JSON Schema dialect: Draft 2020-12.
- Top-level canonical objects: closed (`additionalProperties=false`).
- Required canonical identity boundary: `schema`, `id`, `version`, `fingerprint`, `extensions`.
- Existing ACR `SCHEMA_SPECS`: remains exactly the original ten.
- AMRR `MATH_SCHEMA_SPECS`: separate additive catalog.
- Generic validation routes through `ALL_SCHEMA_SPECS`.

## Canonical fixture evidence

- Valid AMRR fixtures: `19/19`.
- Deliberately invalid AMRR fixtures rejected: `9/9`.
- Every valid fixture fingerprint equals `fingerprint_object(object)`: PASS.
- Deliberate invalid cases include:
  - unknown top-level field;
  - bad fingerprint;
  - invalid problem relation;
  - out-of-range confidence;
  - invalid math domain;
  - invalid obligation status;
  - invalid verification result;
  - invalid bridge strength;
  - invalid verifier class.

## Test evidence

The environment's single monolithic `pytest -q` invocation exceeded the container execution window without reporting a test failure. Therefore this document does **not** claim a single-command full-suite completion.

All `88` collected tests were instead executed in bounded groups / files on the same working tree and passed with zero failures:

- primary M0 + ACR regression matrix: `56 passed`;
- CLI / fixture / Phase-1 release / release-validator / SPRC-adapter group: `14 passed`;
- Phase-2 release: `4 passed`;
- SPRC resolution: `5 passed`;
- SPRC source: `3 passed`;
- state CLI: `3 passed`;
- state fixtures: `3 passed`.

Total covered test cases:

```text
56 + 14 + 4 + 5 + 3 + 3 + 3 = 88 passed
```

## Build / validator evidence

- `python -m compileall -q src scripts`: PASS.
- base `scripts/validate_release.py`: `ok=true`, `checksum_failures=0`.
- additive `scripts/validate_amrr_m0.py`: `ok=true`, `checksum_failures=0`.

## Release metadata separation

The base ACR release keeps:

```text
MANIFEST.json
CHECKSUMS.sha256
```

AMRR M0 adds:

```text
AMRR_M0_MANIFEST.json
AMRR_M0_CHECKSUMS.sha256
```

This prevents AMRR M0 from rewriting the historical meaning of the Phase-2 manifest while still giving the expanded source tree an independently verifiable release layer.

## M0 completion definition

M0 is considered complete only if the package can establish all of the following simultaneously:

1. the original Phase-0 schema hashes remain frozen;
2. the Phase-1 registry remains deterministic and unchanged in semantic fingerprint;
3. the Phase-2 public-state encoder still passes its deterministic regression gates;
4. exactly 19 canonical AMRR math schemas are registered separately;
5. all math schemas are well-formed Draft-2020-12 schemas;
6. all valid math fixtures validate and all deliberate invalid fixtures are rejected;
7. canonical fingerprints are stable;
8. both base and AMRR additive release validators return `ok=true`;
9. M1–M11 are explicitly marked not implemented.

M0 freezes representation contracts only. Passing M0 does not imply that the AMRR autonomous mathematical research runtime already exists.
