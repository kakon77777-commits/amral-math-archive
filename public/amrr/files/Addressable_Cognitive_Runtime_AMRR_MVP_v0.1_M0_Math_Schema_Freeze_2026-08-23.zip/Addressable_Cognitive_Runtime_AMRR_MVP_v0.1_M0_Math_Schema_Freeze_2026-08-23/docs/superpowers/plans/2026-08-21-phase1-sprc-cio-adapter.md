# Phase 1 SPRC / CIO Adapter Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Convert the frozen SES1/CIO-Deck-v1.0 source assets into 64 deterministic, Phase-0-valid ACR CognitiveObjects and expose them through an inspectable adapter/CLI.

**Architecture:** Vendor only the source data required to establish semantics and provenance. A pure Python adapter validates source hashes, maps each CIO card to a source-preserving ACR address, optionally enriches the direct English renderer from the corpus reference gloss, then emits a deterministic registry artifact. Phase 0 schemas remain unchanged.

**Tech Stack:** Python 3.11+, stdlib, existing `jsonschema` dependency, pytest.

**Spec:** `docs/superpowers/specs/2026-08-21-phase1-sprc-cio-adapter-design.md`

## Global Constraints

- Preserve Phase 0 schemas byte-for-byte.
- Source semantic hashes must match the frozen CIO/SES values before conversion.
- Do not convert affinity into preconditions.
- Do not infer non-source operator compatibility/conflicts.
- ACR address namespace is `cog://sprc/cio/<source-id-lower>@1`.
- Every generated CognitiveObject must validate with the existing Phase 0 validator.

---

### Task 1: Vendor source profile and verify hashes

**Files:**
- Create: `vendor/sprc/v2.2.0/operator_deck_v1.0.json`
- Create: `vendor/sprc/v2.2.0/ses_registry_SES1.json`
- Create: `vendor/sprc/v2.2.0/corpus_operators.json`
- Create: `vendor/sprc/v2.2.0/discourse_profiles.json`
- Create: `vendor/sprc/v2.2.0/source_profile.json`
- Create: `tests/test_sprc_source.py`

**Interfaces:**
- Produces `load_sprc_source_profile()` and `verify_sprc_source()` in Task 2.

- [x] Write failing tests asserting expected canonical source hashes, 64 cards, 8×8 family balance, and v2.2.0 source profile metadata.
- [x] Run the tests and confirm failure because the adapter/source API does not exist.
- [x] Vendor exact source data and implement minimal source loader/hash verification.
- [x] Run tests to green and commit.

### Task 2: Convert CIO cards into CognitiveObjects

**Files:**
- Create: `src/addressable_cognitive_runtime/adapters/__init__.py`
- Create: `src/addressable_cognitive_runtime/adapters/sprc.py`
- Create: `tests/test_sprc_conversion.py`

**Interfaces:**
- Produces `source_id_to_address()`, `convert_card()`, `convert_all()`, `build_registry()`.

- [x] Write failing tests for R01 exact preservation, no affinity→precondition promotion, all 64 Phase-0-valid objects, deterministic fingerprints, and fail-closed bad source hashes.
- [x] Run RED.
- [x] Implement minimal adapter mapping and registry assembly.
- [x] Run GREEN and commit.

### Task 3: Address resolution and CLI

**Files:**
- Modify: `src/addressable_cognitive_runtime/cli.py`
- Modify: `pyproject.toml`
- Create: `tests/test_sprc_cli.py`

**Interfaces:**
- Produces CLI commands `sprc-info`, `sprc-list`, `sprc-resolve`, `sprc-export`.

- [x] Write failing CLI tests.
- [x] Run RED.
- [x] Implement commands using adapter API only.
- [x] Run GREEN and commit.

### Task 4: Canonical registry artifact and release validation

**Files:**
- Create: `registry/ACR1-SPRC-CIO-v1.json`
- Create: `PHASE1_VALIDATION.md`
- Modify: `README.md`
- Modify: `scripts/build_release_metadata.py`
- Modify: `scripts/validate_release.py`
- Create/modify tests for release validation as required.

**Interfaces:**
- Produces the distributable Phase 1 source bundle.

- [x] Write failing tests/validator assertions for 64 exported objects, source hashes, deterministic export, and all-object validation.
- [x] Run RED.
- [x] Generate registry artifact and extend release validator/docs.
- [x] Run full suite, compileall, CLI checks, release validator, package checksums, then verify again from extracted ZIP.
- [x] Commit release state.
