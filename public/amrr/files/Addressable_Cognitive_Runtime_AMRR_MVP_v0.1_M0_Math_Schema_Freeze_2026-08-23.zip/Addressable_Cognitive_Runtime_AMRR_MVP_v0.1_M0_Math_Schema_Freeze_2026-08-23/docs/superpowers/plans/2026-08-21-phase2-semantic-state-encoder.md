# Phase 2 Semantic State Encoder Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a deterministic public-state encoder that emits Phase-0-valid `SemanticState` objects from strict structured observations.

**Architecture:** A pure Python state module validates and normalizes public observation facts, derives only the two Phase-2 semantic fields that need rules (`progress`, `uncertainty`), then content-addresses and fingerprints the frozen Phase-0 object. The CLI is a thin file adapter. Release validation proves Phase 0/1 artifacts remain unchanged and that Phase 2 reference fixtures reproduce deterministically.

**Tech Stack:** Python 3.11+, stdlib, existing jsonschema/pytest dependencies.

**Spec:** `docs/superpowers/specs/2026-08-21-phase2-semantic-state-encoder-design.md`

## Global Constraints

- Do not modify Phase 0 JSON Schema contracts.
- Do not modify the Phase 1 SPRC/CIO registry or vendored source.
- Accept public structured facts only; reject hidden/private reasoning fields.
- Equivalent set/list ordering must normalize to identical output.
- No model/provider/embedding/CTCL network dependency.
- Do not implement Phase 3 operator retrieval.

---

### Task 1: Observation contract and normalization

**Files:**
- Create: `src/addressable_cognitive_runtime/state/__init__.py`
- Create: `src/addressable_cognitive_runtime/state/encoder.py`
- Create: `tests/test_state_observation.py`

**Interfaces:**
- Produces: `ObservationError`, `normalize_observation(observation)`.

- [x] Write tests for required authority ref, allowed/unknown keys, private-reasoning rejection, list normalization, numeric budget validation, and no input mutation.
- [x] Run `pytest -q tests/test_state_observation.py` and verify RED because the module/API does not exist.
- [x] Implement the minimal observation validator/normalizer exactly as specified.
- [x] Run the targeted test and verify GREEN.
- [x] Commit.

### Task 2: Deterministic semantic derivation and identity

**Files:**
- Modify: `src/addressable_cognitive_runtime/state/encoder.py`
- Create: `tests/test_state_encoder.py`

**Interfaces:**
- Produces: `derive_progress()`, `derive_uncertainty()`, `encode_semantic_state()`.

- [x] Write tests for progress precedence, uncertainty precedence/conservative combination, content-addressed state ID, deterministic fingerprint, equivalent-order byte identity, and Phase-0 validation.
- [x] Run targeted tests and verify RED because derivation/encoding APIs do not exist.
- [x] Implement only the specified deterministic rules and reuse Phase 0 canonical/validation APIs.
- [x] Run targeted tests and verify GREEN.
- [x] Commit.

### Task 3: File adapter, fixtures, and CLI

**Files:**
- Modify: `src/addressable_cognitive_runtime/state/encoder.py`
- Modify: `src/addressable_cognitive_runtime/cli.py`
- Create: `examples/state-observations/valid/*.json`
- Create: `examples/state-observations/invalid/*.json`
- Create: `tests/test_state_cli.py`
- Create: `tests/test_state_fixtures.py`

**Interfaces:**
- Produces: `encode_semantic_state_file(path)` and CLI `state-encode`.

- [x] Write failing tests for valid/invalid fixtures, stdout output, `--output`, deterministic re-encode, and nonzero structured errors.
- [x] Run targeted tests and verify RED.
- [x] Implement the file adapter/CLI and reference fixtures.
- [x] Run targeted tests and verify GREEN.
- [x] Commit.

### Task 4: Phase 2 release validation and packaging contract

**Files:**
- Create: `PHASE2_VALIDATION.md`
- Modify: `README.md`
- Modify: `MANIFEST.json` via release metadata builder.
- Modify: `CHECKSUMS.sha256` via release metadata builder.
- Modify: `scripts/build_release_metadata.py`
- Modify: `scripts/validate_release.py`
- Create: `tests/test_phase2_release.py`

**Interfaces:**
- Release validator reports Phase 2 fixture counts, deterministic state fingerprints, unchanged Phase 0 schema hashes, unchanged Phase 1 registry fingerprint, and overall `ok`.

- [x] Write failing release tests requiring Phase 2 metadata and deterministic fixture rebuilds.
- [x] Run targeted tests and verify RED.
- [x] Extend release metadata/validator without weakening Phase 0/1 checks.
- [x] Run targeted and full regression suites to GREEN.
- [x] Run `compileall`, CLI smoke tests, fixture validation, and release validator.
- [x] Update `PHASE2_VALIDATION.md`, rebuild checksums/manifest, and commit.
