# CSM Reference Runtime v0.2

A deterministic local reference runtime for **Closure-Space Mathematics (CSM)** with staged **NS_GSM corpus ingestion**.

v0.2 preserves every v0.1 authority invariant while adding manifest-driven source discovery, duplicate identity, deterministic Markdown extraction, series profiles, a persistent Candidate Layer, resumable ingestion checkpoints, cross-series review proposals, corpus queries, and replayable multi-series evidence.

## What v0.2 proves about itself

It proves runtime and ingestion conformance only: source artifacts can be inventoried and parsed deterministically; natural-language status labels remain candidate-level; batches are atomic and idempotent; native state replays exactly; and cross-series matches do not auto-quotient.

It does **not** prove Navier–Stokes global regularity, route completeness, representation completeness, full historical corpus coverage, generalized NS-like closure, or physical-model adequacy.

## Core invariant

```text
No certificate path => no native theorem mutation.
```

Additional ingestion invariants:

- `artifact label != native theorem status`
- `NO-GO` parses to an obstruction candidate, not root refutation
- `STOP-*` parses to a frontier candidate, not failure
- `SURVIVOR` is a role on an OPEN route, not a proof
- `CLOSED AS A RESEARCH CYCLE` is process metadata, not mathematical closure
- cross-series exact statement matches are `NEEDS_REVIEW` proposals with `auto_quotient=false`
- unchanged batches are idempotent no-ops
- changed source hashes produce revisions rather than overwriting history
- all corpus views remain `observed-relative`

## v0.2 content-ingested checkpoint

The packaged v0.2 corpus contains **46 Markdown artifacts** with explicit coverage boundaries:

| Series | Content status | Artifacts |
|---|---|---:|
| C | PARTIAL | 2 |
| RFP | COMPLETE_SERIES | 15 |
| MORP | COMPLETE_SERIES | 7 |
| X72 | SELECTED_MILESTONES | 4 |
| DCRP | SELECTED_MILESTONES | 10 |
| FCBP | COMPLETE_SERIES | 7 |
| PAM | COMPLETE_INDEX_ARTIFACT | 1 |

`COMPLETE_SERIES` here means complete for the declared cycle/checkpoint represented in v0.2 (RFP Cycle I, MORP Cycle VII package, FCBP Cycle VI package). It does **not** mean the entire historical NS research archive has been content-ingested.

The X72 cumulative checkpoint is deliberately treated as a milestone source; cumulative text is not counted as hundreds of independent proof objects.

## v0.2 frozen evidence

The release evidence is under `evidence/v0.2/` and includes:

- `corpus_inventory.json`
- `content_coverage.json`
- `candidate_summary.json`
- `series_checkpoints.json`
- `cross_series_proposals.json`
- `ns_gsm_v02_ledger.jsonl`
- `ns_gsm_v02_native_snapshot.json`
- `replay_report.json`
- `run_summary.json`
- `conformance_report.json`

Frozen run summary:

- content artifacts: 46
- candidates: 1,460
- ledger events: 1,602
- series checkpoints: 7
- cross-series exact-statement proposals: 219
- automatic cross-series quotients: 0
- root formal NS status: `OPEN`
- scope: `observed-relative`
- replay: exact hash match

## Run tests

```bash
pytest -q
```

## Run the v0.1 seed closure

```bash
PYTHONPATH=src python -m csm_runtime.cli seed-run \
  --seed <NS_GSM_SEED_PATH> \
  --evidence evidence
```

## Corpus query examples

With a v0.2 native snapshot:

```bash
PYTHONPATH=src python -m csm_runtime.cli corpus-summary \
  --snapshot evidence/v0.2/ns_gsm_v02_native_snapshot.json

PYTHONPATH=src python -m csm_runtime.cli series-summary \
  --snapshot evidence/v0.2/ns_gsm_v02_native_snapshot.json RFP

PYTHONPATH=src python -m csm_runtime.cli candidates \
  --snapshot evidence/v0.2/ns_gsm_v02_native_snapshot.json --series DCRP
```

## Replay verification

The v0.2 release stores the canonical ledger and native snapshot separately. The release conformance report records an exact deterministic replay hash match.

## Architecture

```text
Corpus Inventory
→ Source Manifest
→ Artifact/Series Registration
→ Deterministic Series Parser
→ Candidate Layer
→ Validation / Promotion Gate
→ Series Checkpoint Transaction
→ Frontier / Query Views
→ Cross-Series Proposal Audit
→ Snapshot / Replay
```

The Candidate Layer is intentionally large. Candidate growth is not theorem growth.
