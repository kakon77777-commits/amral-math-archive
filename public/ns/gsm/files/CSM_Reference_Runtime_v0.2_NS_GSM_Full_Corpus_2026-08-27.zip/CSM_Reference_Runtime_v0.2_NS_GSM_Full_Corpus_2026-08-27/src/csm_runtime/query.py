from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .errors import UnknownObjectError
from .frontier import rebuild_frontier
from .model import NativeState


@dataclass(frozen=True)
class QueryResult:
    answer: Any
    authority: str
    scope: str
    certificate_refs: list[str]
    debt_refs: list[str]
    version: str
    source_layer: str = "native"


class QueryEngine:
    def __init__(self, state: NativeState):
        self.state = state

    def _object(self, object_id: str):
        try:
            return self.state.objects[object_id]
        except KeyError as exc:
            raise UnknownObjectError(object_id) from exc

    def status(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        return QueryResult(
            answer=obj.status.value,
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )

    def why_blocked(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        events = [
            event for event in self.state.status_history
            if event.get("object_id") == object_id
        ]
        return QueryResult(
            answer={"status": obj.status.value, "events": events},
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )

    def frontier(self) -> QueryResult:
        frontier = rebuild_frontier(self.state)
        certs: set[str] = set()
        debts: set[str] = set()
        for object_id in frontier.object_ids:
            obj = self.state.objects[object_id]
            certs.update(obj.certificate_refs)
            debts.update(obj.debt_refs)
        return QueryResult(
            answer=frontier.object_ids,
            authority="AUDIT",
            scope=frontier.scope,
            certificate_refs=sorted(certs),
            debt_refs=sorted(debts),
            version=frontier.version,
        )

    def debt(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        records = [self.state.debts[d].to_dict() for d in obj.debt_refs if d in self.state.debts]
        return QueryResult(
            answer=records,
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )

    def history(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        events = [event for event in self.state.status_history if event.get("object_id") == object_id]
        return QueryResult(
            answer=events,
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )


def _artifact_series(obj) -> str | None:
    value = obj.metadata.get("series")
    return str(value) if value is not None else None


def _candidate_series(candidate) -> str | None:
    proposed = candidate.proposed_object or {}
    meta = proposed.get("metadata") or {}
    value = meta.get("series")
    return str(value) if value is not None else None


def _source_id_from_artifact(obj) -> str | None:
    value = obj.metadata.get("source_id")
    return str(value) if value is not None else None


# Keep corpus queries on QueryEngine without changing the v0.1 object-query surface.
def _corpus_summary(self: QueryEngine) -> QueryResult:
    artifacts = [o for o in self.state.objects.values() if o.object_type == "ARTIFACT"]
    return QueryResult(
        answer={
            "artifact_count": len(artifacts),
            "candidate_count": len(self.state.candidates),
            "checkpoint_count": len(self.state.ingestion_checkpoints),
            "series": sorted({s for s in (_artifact_series(o) for o in artifacts) if s}),
        },
        authority="RESEARCH",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="native+candidate",
    )


def _series_summary(self: QueryEngine, series: str) -> QueryResult:
    artifacts = [o for o in self.state.objects.values() if o.object_type == "ARTIFACT" and _artifact_series(o) == series]
    candidates = [c for c in self.state.candidates.values() if _candidate_series(c) == series]
    by_type: dict[str, int] = {}
    for candidate in candidates:
        by_type[candidate.candidate_type] = by_type.get(candidate.candidate_type, 0) + 1
    return QueryResult(
        answer={
            "series": series,
            "artifact_count": len(artifacts),
            "candidate_count": len(candidates),
            "candidate_types": dict(sorted(by_type.items())),
        },
        authority="RESEARCH",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="native+candidate",
    )


def _candidates(self: QueryEngine, series: str | None = None) -> QueryResult:
    values = list(self.state.candidates.values())
    if series is not None:
        values = [c for c in values if _candidate_series(c) == series]
    return QueryResult(
        answer=[c.to_dict() for c in sorted(values, key=lambda c: c.candidate_id)],
        authority="RESEARCH",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="candidate",
    )


def _source_history(self: QueryEngine, source_id: str) -> QueryResult:
    artifacts = [o.to_dict() for o in self.state.objects.values() if o.object_type == "ARTIFACT" and _source_id_from_artifact(o) == source_id]
    candidates = [c.to_dict() for c in self.state.candidates.values() if (c.proposed_object or {}).get("source_id") == source_id]
    checkpoints = [p for p in self.state.ingestion_checkpoints.values() if source_id in (p.get("source_ids") or [])]
    return QueryResult(
        answer={"source_id": source_id, "artifacts": artifacts, "candidates": candidates, "checkpoints": checkpoints},
        authority="RESEARCH",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="native+candidate",
    )


def _duplicates(self: QueryEngine) -> QueryResult:
    artifacts = [o.to_dict() for o in self.state.objects.values() if o.object_type == "ARTIFACT" and o.metadata.get("canonicality") == "DUPLICATE"]
    return QueryResult(
        answer=artifacts,
        authority="DISPLAY",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="native",
    )


def _ingestion_checkpoint(self: QueryEngine, checkpoint_id: str) -> QueryResult:
    if checkpoint_id not in self.state.ingestion_checkpoints:
        raise UnknownObjectError(checkpoint_id)
    return QueryResult(
        answer=dict(self.state.ingestion_checkpoints[checkpoint_id]),
        authority="AUDIT",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="native",
    )


QueryEngine.corpus_summary = _corpus_summary
QueryEngine.series_summary = _series_summary
QueryEngine.candidates = _candidates
QueryEngine.source_history = _source_history
QueryEngine.duplicates = _duplicates
QueryEngine.ingestion_checkpoint = _ingestion_checkpoint
