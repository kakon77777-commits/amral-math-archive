# CSM Reference Runtime v0.1

A deterministic local reference runtime for **Closure-Space Mathematics (CSM)**, validated against **NS_GSM Seed Dataset v0.1**.

## What v0.1 proves about itself

It proves only runtime conformance: typed records can be loaded, mutations are authority-gated, transactions are atomic, the event ledger replays deterministically, and the observed-relative NS_GSM frontier is reproducible.

It does **not** prove Navier–Stokes global regularity, route completeness, representation completeness, generalized NS-like closure, or physical-model adequacy.

## Core invariant

```text
No certificate path => no native theorem mutation.
```

Other invariants:

- `BLOCKED != CLOSED_NEGATIVE`
- candidate extraction cannot directly create native theorem status
- debt cannot disappear without discharge
- D104's narrow fixed-positive-viscosity no-go is preserved while D105 blocks silent uniform epsilon->0 promotion
- `SURVIVOR` is a role tag on an OPEN route
- all v0.1 frontiers are labeled `observed-relative`

## Run tests

```bash
pytest -q
```

## Run the NS_GSM seed closure

```bash
python -m csm_runtime.cli seed-run \
  --seed fixtures/NS_GSM_Seed_Dataset_v0.1 \
  --evidence evidence
```

When running from the repository without installing the package:

```bash
PYTHONPATH=src python -m csm_runtime.cli seed-run \
  --seed fixtures/NS_GSM_Seed_Dataset_v0.1 \
  --evidence evidence
```

## Replay verification

```bash
PYTHONPATH=src python -m csm_runtime.cli replay-check \
  --ledger evidence/ns_gsm_genesis_ledger.jsonl \
  --snapshot evidence/ns_gsm_native_snapshot.json
```

## Query examples

```bash
PYTHONPATH=src python -m csm_runtime.cli status \
  --snapshot evidence/ns_gsm_native_snapshot.json \
  claim:formal-root-regularity

PYTHONPATH=src python -m csm_runtime.cli frontier \
  --snapshot evidence/ns_gsm_native_snapshot.json

PYTHONPATH=src python -m csm_runtime.cli state-hash \
  --snapshot evidence/ns_gsm_native_snapshot.json
```

## Seed lineage

The seed contains **7 logical seed units from 5 physical source artifacts**. C1 and C2 are canonical proof-obligation targets extracted from ETN-X; they are not fabricated as independent source documents.
