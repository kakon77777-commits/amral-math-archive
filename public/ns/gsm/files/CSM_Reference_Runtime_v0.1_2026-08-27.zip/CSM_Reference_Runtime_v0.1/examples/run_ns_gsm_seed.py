from pathlib import Path

from csm_runtime.canonical import state_hash
from csm_runtime.ns_gsm_adapter import materialize_seed_state


seed = Path(__file__).parents[1] / "fixtures" / "NS_GSM_Seed_Dataset_v0.1"
result = materialize_seed_state(seed)
state = result.state
print("state_hash", state_hash(state))
print("root", state.objects["claim:formal-root-regularity"].status.value)
print("d105_survivor", state.objects["survivor:d105-vm-shear-pol"].status.value)
print("frontier", state.frontier_ids)
