class CSMRuntimeError(Exception):
    """Base runtime error."""


class ValidationError(CSMRuntimeError):
    pass


class AuthorityError(CSMRuntimeError):
    pass


class IllegalTransitionError(CSMRuntimeError):
    pass


class StaleTransactionError(CSMRuntimeError):
    pass


class RuntimeInconsistentError(CSMRuntimeError):
    pass


class UnknownObjectError(CSMRuntimeError):
    pass
