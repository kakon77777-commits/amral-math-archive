from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass

from .canonical import state_hash
from .errors import StaleTransactionError
from .ledger import EventLedger, LedgerEvent
from .model import NativeState
from .state import apply_event


@dataclass
class TransactionResult:
    commit_status: str
    state: NativeState
    input_state_hash: str
    output_state_hash: str


class ClosureTransaction:
    def __init__(self, state: NativeState, ledger: EventLedger):
        self._source_state = state
        self._ledger = ledger
        self._input_hash = state_hash(state)
        self._staged: list[LedgerEvent] = []

    def stage(self, event: LedgerEvent) -> None:
        self._staged.append(event)

    def commit(self) -> TransactionResult:
        if state_hash(self._source_state) != self._input_hash:
            raise StaleTransactionError("input state changed before commit")
        self._ledger.validate_batch(self._staged)
        working = deepcopy(self._source_state)
        for event in self._staged:
            apply_event(working, event)
        # Append only after every event applies cleanly.
        self._ledger.append_batch(self._staged)
        return TransactionResult(
            commit_status="COMMITTED",
            state=working,
            input_state_hash=self._input_hash,
            output_state_hash=state_hash(working),
        )
