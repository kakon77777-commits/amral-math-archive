from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .errors import UnknownObjectError
from .frontier import rebuild_frontier
from .model import NativeState


@dataclass(frozen=True)
class QueryResult:
    answer: Any
    authority: str
    scope: str
    certificate_refs: list[str]
    debt_refs: list[str]
    version: str
    source_layer: str = "native"


class QueryEngine:
    def __init__(self, state: NativeState):
        self.state = state

    def _object(self, object_id: str):
        try:
            return self.state.objects[object_id]
        except KeyError as exc:
            raise UnknownObjectError(object_id) from exc

    def status(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        return QueryResult(
            answer=obj.status.value,
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )

    def why_blocked(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        events = [
            event for event in self.state.status_history
            if event.get("object_id") == object_id
        ]
        return QueryResult(
            answer={"status": obj.status.value, "events": events},
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )

    def frontier(self) -> QueryResult:
        frontier = rebuild_frontier(self.state)
        certs: set[str] = set()
        debts: set[str] = set()
        for object_id in frontier.object_ids:
            obj = self.state.objects[object_id]
            certs.update(obj.certificate_refs)
            debts.update(obj.debt_refs)
        return QueryResult(
            answer=frontier.object_ids,
            authority="AUDIT",
            scope=frontier.scope,
            certificate_refs=sorted(certs),
            debt_refs=sorted(debts),
            version=frontier.version,
        )

    def debt(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        records = [self.state.debts[d].to_dict() for d in obj.debt_refs if d in self.state.debts]
        return QueryResult(
            answer=records,
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )

    def history(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        events = [event for event in self.state.status_history if event.get("object_id") == object_id]
        return QueryResult(
            answer=events,
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )
