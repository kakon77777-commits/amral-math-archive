from __future__ import annotations

from .canonical import state_hash
from .errors import RuntimeInconsistentError
from .ledger import EventLedger, LedgerEvent
from .model import NativeState
from .state import apply_event


def replay_ledger(events: list[LedgerEvent], policy_version: str = "v0.1") -> NativeState:
    ledger = EventLedger(events)
    state = NativeState(policy_version=policy_version)
    for event in ledger.events:
        apply_event(state, event)
    return state


def verify_replay(expected_state: NativeState, events: list[LedgerEvent]) -> bool:
    replayed = replay_ledger(events, policy_version=expected_state.policy_version)
    if state_hash(replayed) != state_hash(expected_state):
        raise RuntimeInconsistentError("replay hash mismatch")
    return True
