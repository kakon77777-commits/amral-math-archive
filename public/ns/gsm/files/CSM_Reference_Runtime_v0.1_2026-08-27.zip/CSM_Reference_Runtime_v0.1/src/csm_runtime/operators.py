from __future__ import annotations

from .enums import Authority, ClosureStatus
from .errors import AuthorityError, IllegalTransitionError, UnknownObjectError
from .model import CandidateRecord, DebtRecord, EdgeRecord, NativeState, ObjectRecord

_ACCEPTED_CERT_STATUSES = {"VALID", "VALID_SOURCE_ASSERTION"}

_BLOCK_CERT_TYPES = {"OPCERT", "DIAGNOSTIC_OBSTRUCTION", "CONDITIONAL_NO_GO", "FORMAL_NO_GO", "SOURCE_INTERNAL_NO_GO"}
_POSITIVE_CERT_TYPES = {
    "PROOF", "THEOREM", "SOURCE_INTERNAL_PROOF", "SOURCE_INTERNAL_EXACT_IDENTITY",
    "SOURCE_INTERNAL_ANALYTIC_RESULT", "SOURCE_INTERNAL_LOCAL_ALGEBRA",
    "SOURCE_INTERNAL_ASYMPTOTIC_RESULT",
}
_NEGATIVE_CERT_TYPES = {"COUNTEREXAMPLE", "NO_GO", "FORMAL_NO_GO", "SOURCE_INTERNAL_NO_GO"}


def _require_object(state: NativeState, object_id: str):
    try:
        return state.objects[object_id]
    except KeyError as exc:
        raise UnknownObjectError(object_id) from exc


def _require_cert(state: NativeState, certificate_id: str, subject_id: str | None = None):
    cert = state.certificates.get(certificate_id)
    if cert is None or cert.status not in _ACCEPTED_CERT_STATUSES:
        raise AuthorityError(f"valid certificate required: {certificate_id}")
    if subject_id is not None and cert.subject_ids and subject_id not in cert.subject_ids:
        raise AuthorityError(f"certificate {certificate_id} does not cover {subject_id}")
    return cert



def _require_cert_type(cert, allowed: set[str], operation: str) -> None:
    if cert.certificate_type not in allowed:
        raise AuthorityError(
            f"certificate type {cert.certificate_type} is not authorized for {operation}"
        )


def _record_status(state: NativeState, object_id: str, old: ClosureStatus, new: ClosureStatus, cause: str):
    state.status_history.append({
        "object_id": object_id,
        "old_status": old.value,
        "new_status": new.value,
        "cause": cause,
        "version": state.version,
    })



def _ensure_native_mutable(obj) -> None:
    if obj.object_type == "VIEW" or obj.metadata.get("source_layer") == "projected":
        raise AuthorityError("projected/display view cannot mutate native theorem authority")


def promote_candidate_directly_to_status(
    state: NativeState, candidate: CandidateRecord, status: ClosureStatus
) -> None:
    raise AuthorityError("candidate records cannot directly mutate native theorem status")


def block_route(state: NativeState, route_id: str, certificate_id: str) -> None:
    obj = _require_object(state, route_id)
    cert = _require_cert(state, certificate_id, route_id)
    _require_cert_type(cert, _BLOCK_CERT_TYPES, "BlockRoute")
    if obj.object_type != "ROUTE":
        raise IllegalTransitionError("BlockRoute requires ROUTE object")
    if obj.status not in {ClosureStatus.OPEN, ClosureStatus.REOPENED}:
        raise IllegalTransitionError(f"cannot block {obj.status.value}")
    old = obj.status
    obj.status = ClosureStatus.BLOCKED
    if certificate_id not in obj.certificate_refs:
        obj.certificate_refs.append(certificate_id)
    _record_status(state, route_id, old, obj.status, f"block:{certificate_id}")


def close_negative(state: NativeState, object_id: str, certificate_id: str) -> None:
    obj = _require_object(state, object_id)
    _ensure_native_mutable(obj)
    cert = _require_cert(state, certificate_id, object_id)
    _require_cert_type(cert, _NEGATIVE_CERT_TYPES, "CloseNegative")
    if obj.status is ClosureStatus.BLOCKED:
        # A block certificate is not itself a refutation; caller must supply a distinct valid cert.
        pass
    old = obj.status
    obj.status = ClosureStatus.CLOSED_NEGATIVE
    if certificate_id not in obj.certificate_refs:
        obj.certificate_refs.append(certificate_id)
    _record_status(state, object_id, old, obj.status, f"close_negative:{certificate_id}")


def close_positive(state: NativeState, object_id: str, certificate_id: str) -> None:
    obj = _require_object(state, object_id)
    _ensure_native_mutable(obj)
    cert = _require_cert(state, certificate_id, object_id)
    _require_cert_type(cert, _POSITIVE_CERT_TYPES, "ClosePositive")
    old = obj.status
    obj.status = ClosureStatus.CLOSED_POSITIVE
    if certificate_id not in obj.certificate_refs:
        obj.certificate_refs.append(certificate_id)
    _record_status(state, object_id, old, obj.status, f"close_positive:{certificate_id}")


def mark_stale(state: NativeState, object_id: str, cause: str) -> None:
    obj = _require_object(state, object_id)
    old = obj.status
    obj.status = ClosureStatus.STALE
    _record_status(state, object_id, old, obj.status, cause)


def reopen_route(state: NativeState, route_id: str, cause: str) -> None:
    obj = _require_object(state, route_id)
    if obj.object_type not in {"ROUTE", "SURVIVOR", "FRONTIER"}:
        raise IllegalTransitionError("ReopenRoute requires route/frontier object")
    if obj.status not in {ClosureStatus.BLOCKED, ClosureStatus.STALE, ClosureStatus.CLOSED_NEGATIVE}:
        raise IllegalTransitionError(f"cannot reopen {obj.status.value}")
    old = obj.status
    obj.status = ClosureStatus.REOPENED
    _record_status(state, route_id, old, obj.status, cause)


def add_debt(state: NativeState, debt: DebtRecord) -> None:
    if debt.debt_id in state.debts:
        raise IllegalTransitionError(f"duplicate debt id: {debt.debt_id}")
    state.debts[debt.debt_id] = debt
    obj = state.objects.get(debt.subject_id)
    if obj is not None and debt.debt_id not in obj.debt_refs:
        obj.debt_refs.append(debt.debt_id)


def discharge_debt(state: NativeState, debt_id: str, certificate_id: str) -> None:
    debt = state.debts.get(debt_id)
    if debt is None:
        raise UnknownObjectError(debt_id)
    _require_cert(state, certificate_id, debt.subject_id)
    if debt.status == "DISCHARGED":
        return
    debt.status = "DISCHARGED"


def add_edge(state: NativeState, edge: EdgeRecord) -> None:
    if edge.edge_id in state.edges:
        raise IllegalTransitionError(f"duplicate edge id: {edge.edge_id}")
    for object_id in edge.source_ids + edge.target_ids:
        if object_id not in state.objects:
            raise UnknownObjectError(object_id)
    state.edges[edge.edge_id] = edge


def condition_claim(state: NativeState, object_id: str, certificate_id: str, debt_ids: list[str]) -> None:
    obj = _require_object(state, object_id)
    _ensure_native_mutable(obj)
    cert = _require_cert(state, certificate_id, object_id)
    _require_cert_type(cert, _POSITIVE_CERT_TYPES, "ConditionClaim")
    missing = [debt_id for debt_id in debt_ids if debt_id not in state.debts]
    if missing:
        raise UnknownObjectError(missing[0])
    old = obj.status
    obj.status = ClosureStatus.CONDITIONAL
    for debt_id in debt_ids:
        if debt_id not in obj.debt_refs:
            obj.debt_refs.append(debt_id)
    if certificate_id not in obj.certificate_refs:
        obj.certificate_refs.append(certificate_id)
    _record_status(state, object_id, old, obj.status, f"conditional:{certificate_id}")


def lossy_transfer(
    state: NativeState, source_id: str, target_id: str, target_domain: str, debt_id: str
) -> ObjectRecord:
    source = _require_object(state, source_id)
    if target_id in state.objects:
        raise IllegalTransitionError(f"duplicate target id: {target_id}")
    target = ObjectRecord(
        target_id,
        source.object_type,
        target_domain,
        state.version,
        ClosureStatus.OPEN,
        role_tags=list(source.role_tags),
        source_refs=[source_id],
        authority=Authority.RESEARCH,
        metadata={"transfer_type": "LOSSY", "source_object_id": source_id},
    )
    state.objects[target_id] = target
    add_debt(state, DebtRecord(debt_id, "TRANSFER", target_id, cause=f"lossy transfer from {source_id}"))
    return target


def reopen_dependents(state: NativeState, invalidated_id: str, cause: str) -> list[str]:
    _require_object(state, invalidated_id)
    affected: set[str] = set()
    for edge in state.edges.values():
        if edge.edge_type == "DEPENDS_ON" and invalidated_id in edge.target_ids:
            affected.update(edge.source_ids)
    changed: list[str] = []
    for object_id in sorted(affected):
        obj = _require_object(state, object_id)
        if obj.status is ClosureStatus.BLOCKED and obj.object_type in {"ROUTE", "SURVIVOR", "FRONTIER"}:
            reopen_route(state, object_id, cause)
            changed.append(object_id)
        elif obj.status in {ClosureStatus.CLOSED_POSITIVE, ClosureStatus.CLOSED_NEGATIVE, ClosureStatus.CONDITIONAL}:
            mark_stale(state, object_id, cause)
            changed.append(object_id)
    return changed


def split_quotient(
    state: NativeState, quotient_id: str, restored_objects: list[ObjectRecord], reason: str
) -> None:
    quotient = _require_object(state, quotient_id)
    for obj in restored_objects:
        if obj.object_id in state.objects:
            raise IllegalTransitionError(f"duplicate restored id: {obj.object_id}")
    old = quotient.status
    quotient.status = ClosureStatus.SUPERSEDED
    _record_status(state, quotient_id, old, quotient.status, f"quotient_split:{reason}")
    for obj in restored_objects:
        state.objects[obj.object_id] = obj
