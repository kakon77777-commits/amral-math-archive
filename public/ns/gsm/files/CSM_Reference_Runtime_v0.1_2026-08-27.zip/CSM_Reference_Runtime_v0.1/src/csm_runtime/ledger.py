from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

from .errors import ValidationError


@dataclass(frozen=True)
class LedgerEvent:
    event_id: str
    event_type: str
    payload: dict[str, Any]
    sequence: int
    certificate_refs: tuple[str, ...] = ()
    debt_delta: dict[str, Any] = field(default_factory=dict)
    provenance: dict[str, Any] = field(default_factory=dict)
    operator_version: str = "v0.1"
    policy_version: str = "v0.1"

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type,
            "payload": self.payload,
            "sequence": self.sequence,
            "certificate_refs": list(self.certificate_refs),
            "debt_delta": self.debt_delta,
            "provenance": self.provenance,
            "operator_version": self.operator_version,
            "policy_version": self.policy_version,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "LedgerEvent":
        return cls(
            event_id=data["event_id"],
            event_type=data["event_type"],
            payload=dict(data.get("payload") or {}),
            sequence=int(data["sequence"]),
            certificate_refs=tuple(data.get("certificate_refs") or []),
            debt_delta=dict(data.get("debt_delta") or {}),
            provenance=dict(data.get("provenance") or {}),
            operator_version=data.get("operator_version", "v0.1"),
            policy_version=data.get("policy_version", "v0.1"),
        )


class EventLedger:
    def __init__(self, events: Iterable[LedgerEvent] | None = None):
        self.events: list[LedgerEvent] = list(events or [])
        self._validate_full(self.events)

    @staticmethod
    def _validate_full(events: list[LedgerEvent]) -> None:
        ids: set[str] = set()
        expected = 1
        for event in events:
            if event.event_id in ids:
                raise ValidationError(f"duplicate event id: {event.event_id}")
            if event.sequence != expected:
                raise ValidationError(
                    f"invalid event sequence {event.sequence}; expected {expected}"
                )
            ids.add(event.event_id)
            expected += 1

    def validate_batch(self, batch: list[LedgerEvent]) -> None:
        existing_ids = {e.event_id for e in self.events}
        batch_ids: set[str] = set()
        expected = len(self.events) + 1
        for event in batch:
            if event.event_id in existing_ids or event.event_id in batch_ids:
                raise ValidationError(f"duplicate event id: {event.event_id}")
            if event.sequence != expected:
                raise ValidationError(
                    f"invalid event sequence {event.sequence}; expected {expected}"
                )
            batch_ids.add(event.event_id)
            expected += 1

    def append_batch(self, batch: list[LedgerEvent]) -> None:
        self.validate_batch(batch)
        self.events.extend(batch)
