from __future__ import annotations

from dataclasses import dataclass
import hashlib
from pathlib import Path
from typing import Any

import json
import yaml

from .enums import Authority, ClosureStatus
from .errors import ValidationError
from .frontier import rebuild_frontier
from .ledger import EventLedger, LedgerEvent
from .model import CandidateRecord, NativeState
from .transaction import ClosureTransaction, TransactionResult


@dataclass
class SeedMaterialization:
    state: NativeState
    ledger: EventLedger
    transaction: TransactionResult
    seed: dict[str, Any]


_SOURCE_LABEL_MAP = {
    "CLOSED": "StatusCandidate",
    "OPEN": "OpenCandidate",
    "NO-GO": "ObstructionCandidate",
    "NO_GO": "ObstructionCandidate",
    "SURVIVOR": "SurvivorCandidate",
    "STOP": "FrontierCandidate",
    "CONDITIONAL": "ConditionalCandidate",
    "PROVED": "ProofClaimCandidate",
}


def candidate_from_source_label(label: str, source_ref: str, text_span: str) -> CandidateRecord:
    normalized = label.strip().upper()
    if normalized.startswith("STOP-"):
        key = "STOP"
    else:
        key = normalized
    candidate_type = _SOURCE_LABEL_MAP.get(key, "StatusCandidate")
    digest = hashlib.sha256(f"{source_ref}|{text_span}|{normalized}".encode("utf-8")).hexdigest()[:16]
    return CandidateRecord(
        candidate_id=f"candidate:{digest}",
        source_ref=source_ref,
        candidate_type=candidate_type,
        proposed_object={"source_label": label, "text_span": text_span},
        parser_version="v0.1",
        confidence=None,
        validation_state="UNVERIFIED",
    )


def _load_yaml(path: Path):
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def _load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_ns_gsm_seed(path: str | Path) -> dict[str, Any]:
    root = Path(path)
    required = {
        "dataset": "dataset.yaml",
        "domains": "domains.yaml",
        "series": "series.yaml",
        "artifacts": "artifacts.yaml",
        "claims": "claims.yaml",
        "routes": "routes.yaml",
        "obstructions": "obstructions.yaml",
        "survivors": "survivors.yaml",
        "frontiers": "frontiers.yaml",
        "bridges": "bridges.yaml",
        "debts": "debts.yaml",
        "certificates": "certificates.yaml",
        "nonclaims": "nonclaims.yaml",
    }
    seed: dict[str, Any] = {}
    for key, filename in required.items():
        file_path = root / filename
        if not file_path.exists():
            raise ValidationError(f"missing seed file: {filename}")
        seed[key] = _load_yaml(file_path)
    for key, filename in {
        "graph_snapshot": "graph_snapshot_v0.1.json",
        "source_manifest": "source_manifest_v0.1.json",
        "seed_assertions": "seed_assertions_v0.1.json",
    }.items():
        file_path = root / filename
        if not file_path.exists():
            raise ValidationError(f"missing seed file: {filename}")
        seed[key] = _load_json(file_path)
    _validate_seed(seed)
    return seed


def _validate_seed(seed: dict[str, Any]) -> None:
    if seed["dataset"].get("canonical_code") != "NS_GSM":
        raise ValidationError("seed canonical_code must be NS_GSM")
    if seed["dataset"].get("scope") != "observed-relative":
        raise ValidationError("v0.1 seed must be observed-relative")
    manifest = seed["source_manifest"]
    if manifest.get("physical_artifact_count") != len(seed["artifacts"]):
        raise ValidationError("physical artifact count mismatch")
    if manifest.get("logical_seed_unit_count") != 7:
        raise ValidationError("logical seed unit count must be seven")

    certs = {c["id"]: c for c in seed["certificates"]}
    all_ids: set[str] = set()
    for key in [
        "domains", "series", "artifacts", "claims", "routes", "obstructions",
        "survivors", "frontiers", "bridges", "debts", "certificates", "nonclaims",
    ]:
        for record in seed[key]:
            record_id = record["id"]
            if record_id in all_ids:
                raise ValidationError(f"duplicate seed id: {record_id}")
            all_ids.add(record_id)

    for claim in seed["claims"]:
        if claim.get("status") in {"CLOSED_POSITIVE", "CLOSED_NEGATIVE"}:
            refs = list(claim.get("certificates") or [])
            if not refs:
                raise ValidationError(f"closed claim lacks certificate: {claim['id']}")
            for ref in refs:
                cert = certs.get(ref)
                if cert is None or cert.get("status") not in {"VALID", "VALID_SOURCE_ASSERTION"}:
                    raise ValidationError(f"closed claim has invalid certificate: {claim['id']} -> {ref}")


def _authority_for(record: dict[str, Any], object_type: str) -> Authority:
    source = str(record.get("authority", ""))
    if source.startswith("SOURCE_INTERNAL") or source == "EXTERNAL_PROBLEM_STATEMENT":
        return Authority.AUDIT
    if source == "PROOF_OBLIGATION":
        return Authority.RESEARCH
    if object_type in {"CLAIM", "TARGET", "ROUTE", "OBSTRUCTION", "SURVIVOR", "FRONTIER", "BRIDGE"}:
        return Authority.RESEARCH
    return Authority.DISPLAY


def _status_for(record: dict[str, Any], object_type: str) -> ClosureStatus:
    raw = record.get("status")
    if raw in {status.value for status in ClosureStatus}:
        return ClosureStatus(raw)
    # Source-specific status strings are metadata, never native closure commands.
    if object_type == "BRIDGE" and raw == "CONDITIONAL":
        return ClosureStatus.CONDITIONAL
    return ClosureStatus.UNVERIFIED


def _object_payload(record: dict[str, Any], object_type: str, default_domain: str = "formal") -> dict[str, Any]:
    known = {
        "id", "status", "authority", "role_tags", "source_artifacts", "debts",
        "certificates", "domain", "version",
    }
    metadata = {k: v for k, v in record.items() if k not in known}
    if "status" in record and record["status"] not in {status.value for status in ClosureStatus}:
        metadata["source_status"] = record["status"]
    domain = record.get("domain", default_domain)
    return {
        "object_id": record["id"],
        "object_type": object_type,
        "domain_id": domain,
        "version": record.get("version", "v0.1"),
        "status": _status_for(record, object_type).value,
        "role_tags": list(record.get("role_tags") or []),
        "source_refs": list(record.get("source_artifacts") or []),
        "certificate_refs": list(record.get("certificates") or []),
        "debt_refs": list(record.get("debts") or record.get("debt_ids") or []),
        "authority": _authority_for(record, object_type).value,
        "metadata": metadata,
    }


def build_genesis_events(seed: dict[str, Any]) -> list[LedgerEvent]:
    events: list[LedgerEvent] = []

    def emit(event_type: str, payload: dict[str, Any], label: str) -> None:
        sequence = len(events) + 1
        events.append(LedgerEvent(
            event_id=f"genesis:{sequence:04d}:{label}",
            event_type=event_type,
            payload=payload,
            sequence=sequence,
            provenance={"dataset": seed["dataset"]["dataset_id"]},
        ))

    for record in seed["domains"]:
        emit("REGISTER_OBJECT", _object_payload(record, "DOMAIN", record["id"]), f"domain:{record['id']}")
    for record in seed["series"]:
        emit("REGISTER_OBJECT", _object_payload(record, "SERIES"), f"series:{record['id']}")
    for record in seed["artifacts"]:
        emit("REGISTER_OBJECT", _object_payload(record, "ARTIFACT"), f"artifact:{record['id']}")
    for record in seed["claims"]:
        emit("REGISTER_OBJECT", _object_payload(record, record.get("kind", "CLAIM")), f"claim:{record['id']}")
    for record in seed["routes"]:
        emit("REGISTER_OBJECT", _object_payload(record, "ROUTE"), f"route:{record['id']}")
    for record in seed["obstructions"]:
        payload = _object_payload(record, "OBSTRUCTION")
        payload["status"] = "OPEN"
        emit("REGISTER_OBJECT", payload, f"obstruction:{record['id']}")
    for record in seed["survivors"]:
        payload = _object_payload(record, "SURVIVOR")
        tags = set(payload["role_tags"])
        tags.add("SURVIVOR")
        payload["role_tags"] = sorted(tags)
        emit("REGISTER_OBJECT", payload, f"survivor:{record['id']}")
    for record in seed["frontiers"]:
        emit("REGISTER_OBJECT", _object_payload(record, "FRONTIER"), f"frontier:{record['id']}")
    for record in seed["bridges"]:
        emit("REGISTER_OBJECT", _object_payload(record, "BRIDGE"), f"bridge:{record['id']}")
    for record in seed["nonclaims"]:
        emit("REGISTER_OBJECT", _object_payload(record, "NONCLAIM"), f"nonclaim:{record['id']}")

    for record in seed["certificates"]:
        subject = record.get("subject")
        emit("REGISTER_CERTIFICATE", {
            "certificate_id": record["id"],
            "certificate_type": record["type"],
            "subject_ids": [subject] if isinstance(subject, str) else list(subject or []),
            "status": record.get("status", "PENDING"),
            "scope": record.get("scope"),
            "evidence_refs": list(record.get("evidence_refs") or record.get("source_artifact") and [record["source_artifact"]] or []),
            "version": record.get("version", "v0.1"),
        }, f"cert:{record['id']}")

    for record in seed["debts"]:
        emit("REGISTER_DEBT", {
            "debt_id": record["id"],
            "debt_type": record["type"],
            "subject_id": record["subject"],
            "status": record.get("status", "OPEN"),
            "cause": record.get("cause"),
            "discharge_requirements": list(record.get("discharge_requirements") or []),
            "dependencies": list(record.get("dependencies") or []),
            "version": record.get("version", "v0.1"),
        }, f"debt:{record['id']}")

    for edge in seed["graph_snapshot"].get("edges", []):
        sources = edge.get("from")
        targets = edge.get("to")
        if not isinstance(sources, list):
            sources = [sources]
        if not isinstance(targets, list):
            targets = [targets]
        emit("ADD_EDGE", {
            "edge_id": edge["id"],
            "edge_type": edge["type"],
            "source_ids": sources,
            "target_ids": targets,
            "version": "v0.1",
        }, f"edge:{edge['id']}")

    emit("SCOPE_REVISION", {
        "source_object_id": "claim:d104-positive-viscosity-frozen-kernel-empty",
        "target_object_id": "claim:d105-no-go-nonuniform",
        "preserves_source_status": True,
        "invalidates_promotion": "uniform vanishing-viscosity extension of the D104 fixed-positive-viscosity no-go",
        "cause": "D105 establishes nonuniformity as viscosity vanishes",
    }, "scope-revision:d104-d105")

    frontier_ids = sorted(record["id"] for record in seed["frontiers"] if record.get("status") in {"OPEN", "CONDITIONAL", "REOPENED"})
    emit("SET_FRONTIER", {"frontier_ids": frontier_ids}, "frontier:set")
    return events


def build_genesis_transaction(seed: dict[str, Any]) -> tuple[NativeState, EventLedger, ClosureTransaction]:
    state = NativeState(scope=seed["dataset"].get("scope", "observed-relative"), version=seed["dataset"].get("version", "v0.1"))
    ledger = EventLedger()
    txn = ClosureTransaction(state, ledger)
    for event in build_genesis_events(seed):
        txn.stage(event)
    return state, ledger, txn


def materialize_seed_state(path: str | Path) -> SeedMaterialization:
    seed = load_ns_gsm_seed(path)
    _base, ledger, txn = build_genesis_transaction(seed)
    result = txn.commit()
    rebuild_frontier(result.state)
    return SeedMaterialization(result.state, ledger, result, seed)
