from dataclasses import dataclass

from .enums import ClosureStatus
from .model import NativeState


@dataclass(frozen=True)
class FrontierResult:
    object_ids: list[str]
    scope: str
    version: str


def rebuild_frontier(state: NativeState) -> FrontierResult:
    active = {
        ClosureStatus.OPEN,
        ClosureStatus.CONDITIONAL,
        ClosureStatus.REOPENED,
    }
    ids = sorted(
        object_id
        for object_id, obj in state.objects.items()
        if obj.object_type == "FRONTIER" and obj.status in active
    )
    state.frontier_ids = ids
    return FrontierResult(ids, state.scope, state.version)
