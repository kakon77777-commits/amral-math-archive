from enum import Enum


class ClosureStatus(str, Enum):
    UNVERIFIED = "UNVERIFIED"
    UNKNOWN = "UNKNOWN"
    OPEN = "OPEN"
    CONDITIONAL = "CONDITIONAL"
    BLOCKED = "BLOCKED"
    CLOSED_POSITIVE = "CLOSED_POSITIVE"
    CLOSED_NEGATIVE = "CLOSED_NEGATIVE"
    STALE = "STALE"
    REOPENED = "REOPENED"
    SUPERSEDED = "SUPERSEDED"


class Authority(str, Enum):
    NONE = "NONE"
    DISPLAY = "DISPLAY"
    RESEARCH = "RESEARCH"
    AUDIT = "AUDIT"
    PROOF = "PROOF"


class ExecResult(str, Enum):
    PASS = "PASS"
    REFUSE = "REFUSE"
    DEFER = "DEFER"
    UNKNOWN = "UNKNOWN"
    ERROR = "ERROR"
