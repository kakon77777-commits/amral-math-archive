import hashlib
import json
from typing import Any

from .model import NativeState


def canonical_json_bytes(value: Any) -> bytes:
    if hasattr(value, "to_dict"):
        value = value.to_dict()
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def state_hash(state: NativeState) -> str:
    return hashlib.sha256(canonical_json_bytes(state)).hexdigest()
