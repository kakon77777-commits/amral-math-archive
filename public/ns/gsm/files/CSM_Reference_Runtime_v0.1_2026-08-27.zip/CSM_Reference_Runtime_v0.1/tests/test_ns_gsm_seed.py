from pathlib import Path

from csm_runtime.enums import ClosureStatus
from csm_runtime.ns_gsm_adapter import load_ns_gsm_seed, materialize_seed_state


SEED = Path(__file__).parents[1] / "fixtures" / "NS_GSM_Seed_Dataset_v0.1"


def test_seed_preserves_five_physical_artifacts_and_seven_logical_units():
    seed = load_ns_gsm_seed(SEED)
    assert len(seed["artifacts"]) == 5
    assert seed["source_manifest"]["physical_artifact_count"] == 5
    assert seed["source_manifest"]["logical_seed_unit_count"] == 7


def test_seed_materializes_required_ns_gsm_semantics():
    result = materialize_seed_state(SEED)
    state = result.state

    assert state.scope == "observed-relative"
    assert state.objects["claim:formal-root-regularity"].status is ClosureStatus.OPEN
    assert state.objects["claim:c1-chain-necessity"].status is ClosureStatus.OPEN
    assert state.objects["claim:c2-finite-obstruction"].status is ClosureStatus.OPEN

    assert state.objects["claim:d104-frozen-coaxial-no-go"].status is ClosureStatus.CLOSED_NEGATIVE
    assert state.objects["survivor:d104-simple-shear"].status is ClosureStatus.OPEN
    assert "SURVIVOR" in state.objects["survivor:d104-simple-shear"].role_tags
    assert state.objects["survivor:d104-axisymmetric-polarization"].status is ClosureStatus.OPEN
    assert "SURVIVOR" in state.objects["survivor:d104-axisymmetric-polarization"].role_tags

    assert state.objects["survivor:d105-vm-shear-pol"].status is ClosureStatus.OPEN
    assert "SURVIVOR" in state.objects["survivor:d105-vm-shear-pol"].role_tags
    assert state.objects["frontier:d105-first-order"].status is ClosureStatus.OPEN
    assert "frontier:d105-first-order" in state.frontier_ids


def test_seed_nonclaims_prevent_d105_global_regularization_promotion():
    result = materialize_seed_state(SEED)
    state = result.state
    forbidden = [
        obj.metadata.get("forbidden_promotion", "")
        for obj in state.objects.values()
        if obj.object_type == "NONCLAIM"
    ]
    assert any("global NS regularity" in item for item in forbidden)


def test_d104_to_d105_scope_revision_preserves_narrow_result_and_records_history():
    result = materialize_seed_state(SEED)
    state = result.state
    assert state.objects["claim:d104-positive-viscosity-frozen-kernel-empty"].status is ClosureStatus.CLOSED_NEGATIVE
    assert state.objects["claim:d105-no-go-nonuniform"].status is ClosureStatus.CLOSED_POSITIVE
    assert state.objects["claim:formal-root-regularity"].status is ClosureStatus.OPEN
    assert state.objects["survivor:d105-vm-shear-pol"].status is ClosureStatus.OPEN
    assert state.objects["frontier:d105-first-order"].status is ClosureStatus.OPEN
    revisions = [
        event for event in state.status_history
        if event.get("event_type") == "SCOPE_REVISION"
    ]
    assert len(revisions) == 1
    assert revisions[0]["source_object_id"] == "claim:d104-positive-viscosity-frozen-kernel-empty"
    assert revisions[0]["target_object_id"] == "claim:d105-no-go-nonuniform"
    assert revisions[0]["preserves_source_status"] is True
