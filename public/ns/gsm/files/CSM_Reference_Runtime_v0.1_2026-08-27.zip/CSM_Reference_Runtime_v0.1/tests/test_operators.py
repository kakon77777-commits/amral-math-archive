import pytest

from csm_runtime.enums import ClosureStatus
from csm_runtime.errors import AuthorityError
from csm_runtime.model import CertificateRecord, NativeState, ObjectRecord, DebtRecord
from csm_runtime.operators import block_route, close_negative, discharge_debt


def make_state():
    state = NativeState()
    state.objects["claim:parent"] = ObjectRecord(
        "claim:parent", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN
    )
    state.objects["route:r1"] = ObjectRecord(
        "route:r1", "ROUTE", "formal", "v0.1", ClosureStatus.OPEN,
        metadata={"parent_claim_id": "claim:parent"},
    )
    state.certificates["cert:block"] = CertificateRecord(
        "cert:block", "OPCERT", ["route:r1"], "VALID", version="v0.1"
    )
    return state


def test_block_route_does_not_refute_parent_claim():
    state = make_state()
    block_route(state, "route:r1", "cert:block")
    assert state.objects["route:r1"].status is ClosureStatus.BLOCKED
    assert state.objects["claim:parent"].status is ClosureStatus.OPEN


def test_close_negative_requires_valid_certificate():
    state = make_state()
    with pytest.raises(AuthorityError):
        close_negative(state, "claim:parent", "cert:missing")


def test_debt_cannot_disappear_without_discharge_certificate():
    state = make_state()
    state.debts["debt:1"] = DebtRecord("debt:1", "BRIDGE", "claim:parent")
    with pytest.raises(AuthorityError):
        discharge_debt(state, "debt:1", "cert:missing")
    assert state.debts["debt:1"].status == "OPEN"


def test_opcert_cannot_be_reused_as_refutation_certificate():
    state = make_state()
    block_route(state, "route:r1", "cert:block")
    with pytest.raises(AuthorityError):
        close_negative(state, "route:r1", "cert:block")
    assert state.objects["route:r1"].status is ClosureStatus.BLOCKED


def test_proof_certificate_cannot_be_used_as_block_certificate():
    state = make_state()
    state.certificates["cert:proof-route"] = CertificateRecord(
        "cert:proof-route", "PROOF", ["route:r1"], "VALID"
    )
    with pytest.raises(AuthorityError):
        block_route(state, "route:r1", "cert:proof-route")
    assert state.objects["route:r1"].status is ClosureStatus.OPEN


def test_opcert_cannot_be_used_as_positive_proof_certificate():
    state = make_state()
    with pytest.raises(AuthorityError):
        from csm_runtime.operators import close_positive
        close_positive(state, "route:r1", "cert:block")
    assert state.objects["route:r1"].status is ClosureStatus.OPEN
