import pytest

from csm_runtime.canonical import state_hash
from csm_runtime.errors import StaleTransactionError, UnknownObjectError, ValidationError
from csm_runtime.ledger import EventLedger, LedgerEvent
from csm_runtime.model import NativeState, ObjectRecord
from csm_runtime.enums import ClosureStatus
from csm_runtime.transaction import ClosureTransaction


def register_event(event_id="e1", object_id="claim:1", sequence=1):
    return LedgerEvent(
        event_id=event_id,
        event_type="REGISTER_OBJECT",
        payload={
            "object_id": object_id,
            "object_type": "CLAIM",
            "domain_id": "formal",
            "version": "v0.1",
            "status": "OPEN",
        },
        sequence=sequence,
    )


def test_commit_appends_events_and_returns_mutated_state():
    state = NativeState()
    ledger = EventLedger()
    txn = ClosureTransaction(state, ledger)
    txn.stage(register_event())
    result = txn.commit()
    assert result.commit_status == "COMMITTED"
    assert result.state.objects["claim:1"].status is ClosureStatus.OPEN
    assert len(ledger.events) == 1
    assert state.objects == {}


def test_failed_transaction_has_no_partial_native_or_ledger_mutation():
    state = NativeState()
    ledger = EventLedger()
    txn = ClosureTransaction(state, ledger)
    txn.stage(register_event())
    txn.stage(LedgerEvent(
        event_id="e2",
        event_type="ADD_EDGE",
        payload={
            "edge_id": "edge:bad",
            "edge_type": "IMPLIES",
            "source_ids": ["claim:1"],
            "target_ids": ["claim:missing"],
            "version": "v0.1",
        },
        sequence=2,
    ))
    with pytest.raises(UnknownObjectError):
        txn.commit()
    assert state.objects == {}
    assert ledger.events == []


def test_stale_input_hash_rejects_commit():
    state = NativeState()
    ledger = EventLedger()
    txn = ClosureTransaction(state, ledger)
    txn.stage(register_event())
    state.objects["external:change"] = ObjectRecord(
        "external:change", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN
    )
    with pytest.raises(StaleTransactionError):
        txn.commit()
    assert ledger.events == []


def test_duplicate_event_id_is_rejected_before_commit():
    state = NativeState()
    ledger = EventLedger()
    txn = ClosureTransaction(state, ledger)
    txn.stage(register_event("same", "claim:1", 1))
    txn.stage(register_event("same", "claim:2", 2))
    with pytest.raises(ValidationError):
        txn.commit()
    assert ledger.events == []
