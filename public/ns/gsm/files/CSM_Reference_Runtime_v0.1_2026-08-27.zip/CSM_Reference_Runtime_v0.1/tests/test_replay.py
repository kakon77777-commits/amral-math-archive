import pytest

from csm_runtime.canonical import state_hash
from csm_runtime.errors import RuntimeInconsistentError, ValidationError
from csm_runtime.ledger import LedgerEvent
from csm_runtime.model import NativeState, ObjectRecord
from csm_runtime.enums import ClosureStatus
from csm_runtime.replay import replay_ledger, verify_replay


def events():
    return [
        LedgerEvent(
            event_id="e1",
            event_type="REGISTER_OBJECT",
            payload={
                "object_id": "claim:1",
                "object_type": "CLAIM",
                "domain_id": "formal",
                "version": "v0.1",
                "status": "OPEN",
            },
            sequence=1,
        ),
        LedgerEvent(
            event_id="e2",
            event_type="SET_STATUS",
            payload={
                "object_id": "claim:1",
                "status": "CONDITIONAL",
                "cause": "test",
            },
            sequence=2,
        ),
    ]


def test_same_ledger_replays_to_same_hash():
    s1 = replay_ledger(events())
    s2 = replay_ledger(events())
    assert state_hash(s1) == state_hash(s2)
    assert s1.objects["claim:1"].status is ClosureStatus.CONDITIONAL


def test_verify_replay_accepts_matching_state():
    expected = replay_ledger(events())
    assert verify_replay(expected, events()) is True


def test_verify_replay_rejects_mismatching_state():
    expected = replay_ledger(events())
    expected.objects["other"] = ObjectRecord(
        "other", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN
    )
    with pytest.raises(RuntimeInconsistentError):
        verify_replay(expected, events())


def test_unknown_event_type_fails_closed():
    bad = [LedgerEvent("x", "MAGIC_MUTATION", {}, 1)]
    with pytest.raises(ValidationError):
        replay_ledger(bad)
