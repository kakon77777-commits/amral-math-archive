from csm_runtime.model import NativeState, ObjectRecord
from csm_runtime.enums import ClosureStatus
from csm_runtime.canonical import state_hash


def test_state_hash_is_order_independent_for_registry_keys():
    a = NativeState()
    a.objects["b"] = ObjectRecord("b", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)
    a.objects["a"] = ObjectRecord("a", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)

    b = NativeState()
    b.objects["a"] = ObjectRecord("a", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)
    b.objects["b"] = ObjectRecord("b", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)

    assert state_hash(a) == state_hash(b)
