from csm_runtime.enums import Authority, ClosureStatus
from csm_runtime.model import DebtRecord, NativeState, ObjectRecord
from csm_runtime.query import QueryEngine


def make_state():
    state = NativeState(scope="observed-relative", version="v0.1")
    state.objects["route:r1"] = ObjectRecord(
        "route:r1", "ROUTE", "formal", "v0.1", ClosureStatus.BLOCKED,
        certificate_refs=["cert:block"], debt_refs=["debt:1"], authority=Authority.AUDIT
    )
    state.debts["debt:1"] = DebtRecord("debt:1", "BRIDGE", "route:r1")
    state.status_history.append({
        "object_id":"route:r1",
        "old_status":"OPEN",
        "new_status":"BLOCKED",
        "cause":"block:cert:block",
        "version":"v0.1",
    })
    return state


def test_status_query_carries_authority_and_evidence_metadata():
    result = QueryEngine(make_state()).status("route:r1")
    assert result.answer == "BLOCKED"
    assert result.authority == "AUDIT"
    assert result.certificate_refs == ["cert:block"]
    assert result.debt_refs == ["debt:1"]
    assert result.version == "v0.1"
    assert result.source_layer == "native"


def test_why_blocked_returns_history_reason_not_boolean_only():
    result = QueryEngine(make_state()).why_blocked("route:r1")
    assert result.answer["status"] == "BLOCKED"
    assert result.answer["events"][0]["cause"] == "block:cert:block"
    assert result.scope == "observed-relative"
