import pytest

from csm_runtime.enums import ClosureStatus
from csm_runtime.errors import AuthorityError
from csm_runtime.model import CandidateRecord, NativeState
from csm_runtime.operators import promote_candidate_directly_to_status


def test_candidate_cannot_directly_create_closed_native_claim():
    state = NativeState()
    candidate = CandidateRecord(
        candidate_id="candidate:1",
        source_ref="artifact:1",
        candidate_type="StatusCandidate",
        proposed_object={"object_id": "claim:1"},
        parser_version="v0.1",
        confidence=1.0,
    )
    with pytest.raises(AuthorityError):
        promote_candidate_directly_to_status(state, candidate, ClosureStatus.CLOSED_POSITIVE)
