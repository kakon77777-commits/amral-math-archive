import json
import os
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).parents[1]
SEED = ROOT / "fixtures" / "NS_GSM_Seed_Dataset_v0.1"
ENV = dict(os.environ, PYTHONPATH=str(ROOT / "src"))


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "csm_runtime.cli", *map(str, args)],
        cwd=ROOT,
        env=ENV,
        capture_output=True,
        text=True,
    )


def test_cli_seed_run_writes_replayable_evidence(tmp_path):
    evidence = tmp_path / "evidence"
    result = run_cli("seed-run", "--seed", SEED, "--evidence", evidence)
    assert result.returncode == 0, result.stderr
    expected = {
        "ns_gsm_genesis_ledger.jsonl",
        "ns_gsm_native_snapshot.json",
        "ns_gsm_query_demo.json",
        "conformance_report.json",
        "replay_report.json",
    }
    assert expected.issubset({p.name for p in evidence.iterdir()})
    replay = json.loads((evidence / "replay_report.json").read_text())
    assert replay["match"] is True
    assert replay["event_count"] > 0


def test_cli_replay_check_accepts_generated_evidence(tmp_path):
    evidence = tmp_path / "evidence"
    seed_run = run_cli("seed-run", "--seed", SEED, "--evidence", evidence)
    assert seed_run.returncode == 0, seed_run.stderr
    result = run_cli(
        "replay-check",
        "--ledger", evidence / "ns_gsm_genesis_ledger.jsonl",
        "--snapshot", evidence / "ns_gsm_native_snapshot.json",
    )
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    assert data["match"] is True


def test_cli_status_and_frontier_queries_use_snapshot(tmp_path):
    evidence = tmp_path / "evidence"
    seed_run = run_cli("seed-run", "--seed", SEED, "--evidence", evidence)
    assert seed_run.returncode == 0, seed_run.stderr
    snapshot = evidence / "ns_gsm_native_snapshot.json"

    status = run_cli("status", "--snapshot", snapshot, "claim:formal-root-regularity")
    assert status.returncode == 0, status.stderr
    assert json.loads(status.stdout)["answer"] == "OPEN"

    frontier = run_cli("frontier", "--snapshot", snapshot)
    assert frontier.returncode == 0, frontier.stderr
    ids = json.loads(frontier.stdout)["answer"]
    assert "frontier:d105-first-order" in ids


def test_cli_state_hash_verifies_snapshot_hash(tmp_path):
    evidence = tmp_path / "evidence"
    assert run_cli("seed-run", "--seed", SEED, "--evidence", evidence).returncode == 0
    result = run_cli("state-hash", "--snapshot", evidence / "ns_gsm_native_snapshot.json")
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    assert data["stored_hash"] == data["computed_hash"]


def test_cli_why_blocked_returns_structured_status_for_object(tmp_path):
    evidence = tmp_path / "evidence"
    assert run_cli("seed-run", "--seed", SEED, "--evidence", evidence).returncode == 0
    result = run_cli(
        "why-blocked",
        "--snapshot", evidence / "ns_gsm_native_snapshot.json",
        "survivor:d105-vm-shear-pol",
    )
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    assert data["answer"]["status"] == "OPEN"
    assert data["source_layer"] == "native"
