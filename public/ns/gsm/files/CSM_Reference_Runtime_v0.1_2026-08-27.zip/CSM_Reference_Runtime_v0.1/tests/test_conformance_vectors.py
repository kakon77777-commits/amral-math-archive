from pathlib import Path

import pytest

from csm_runtime.canonical import state_hash
from csm_runtime.enums import Authority, ClosureStatus
from csm_runtime.errors import AuthorityError, StaleTransactionError
from csm_runtime.frontier import rebuild_frontier
from csm_runtime.ledger import EventLedger, LedgerEvent
from csm_runtime.model import CertificateRecord, DebtRecord, EdgeRecord, NativeState, ObjectRecord
from csm_runtime.ns_gsm_adapter import (
    candidate_from_source_label,
    materialize_seed_state,
)
from csm_runtime.operators import (
    block_route,
    close_negative,
    close_positive,
    condition_claim,
    lossy_transfer,
    reopen_dependents,
    split_quotient,
)
from csm_runtime.replay import replay_ledger
from csm_runtime.transaction import ClosureTransaction


SEED = Path(__file__).parents[1] / "fixtures" / "NS_GSM_Seed_Dataset_v0.1"


def valid_cert(cert_id, subject, cert_type="PROOF"):
    return CertificateRecord(cert_id, cert_type, [subject], "VALID")


def test_cv01_diagnostic_obstruction_blocks_route_not_parent():
    state = NativeState()
    state.objects["claim:p"] = ObjectRecord("claim:p", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)
    state.objects["route:r"] = ObjectRecord("route:r", "ROUTE", "formal", "v0.1", ClosureStatus.OPEN)
    state.certificates["cert:o"] = valid_cert("cert:o", "route:r", "OPCERT")
    block_route(state, "route:r", "cert:o")
    assert state.objects["route:r"].status is ClosureStatus.BLOCKED
    assert state.objects["claim:p"].status is ClosureStatus.OPEN


def test_cv02_valid_counterexample_closes_claim_negative():
    state = NativeState()
    state.objects["claim:q"] = ObjectRecord("claim:q", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)
    state.certificates["cert:ce"] = valid_cert("cert:ce", "claim:q", "COUNTEREXAMPLE")
    close_negative(state, "claim:q", "cert:ce")
    assert state.objects["claim:q"].status is ClosureStatus.CLOSED_NEGATIVE


def test_cv03_proof_with_unmet_assumption_is_conditional():
    state = NativeState()
    state.objects["claim:q"] = ObjectRecord("claim:q", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)
    state.certificates["cert:p"] = valid_cert("cert:p", "claim:q")
    state.debts["debt:a"] = DebtRecord("debt:a", "ASSUMPTION", "claim:q")
    condition_claim(state, "claim:q", "cert:p", ["debt:a"])
    assert state.objects["claim:q"].status is ClosureStatus.CONDITIONAL
    assert "debt:a" in state.objects["claim:q"].debt_refs


def test_cv04_debt_discharge_then_proof_can_close_positive():
    from csm_runtime.operators import discharge_debt
    state = NativeState()
    state.objects["claim:q"] = ObjectRecord("claim:q", "CLAIM", "formal", "v0.1", ClosureStatus.CONDITIONAL, debt_refs=["debt:a"])
    state.debts["debt:a"] = DebtRecord("debt:a", "ASSUMPTION", "claim:q")
    state.certificates["cert:discharge"] = valid_cert("cert:discharge", "claim:q", "DISCHARGE")
    state.certificates["cert:p"] = valid_cert("cert:p", "claim:q")
    discharge_debt(state, "debt:a", "cert:discharge")
    close_positive(state, "claim:q", "cert:p")
    assert state.debts["debt:a"].status == "DISCHARGED"
    assert state.objects["claim:q"].status is ClosureStatus.CLOSED_POSITIVE


def test_cv05_visual_only_view_cannot_receive_theorem_mutation():
    state = NativeState()
    state.objects["view:q"] = ObjectRecord(
        "view:q", "VIEW", "formal", "v0.1", ClosureStatus.OPEN, authority=Authority.DISPLAY,
        metadata={"source_layer":"projected"},
    )
    state.certificates["cert:p"] = valid_cert("cert:p", "view:q")
    with pytest.raises(AuthorityError):
        close_positive(state, "view:q", "cert:p")


def test_cv06_lossy_transfer_downgrades_authority_and_adds_debt():
    state = NativeState()
    state.objects["claim:source"] = ObjectRecord(
        "claim:source", "CLAIM", "formal", "v0.1", ClosureStatus.CLOSED_POSITIVE, authority=Authority.PROOF
    )
    target = lossy_transfer(state, "claim:source", "claim:target", "generalized", "debt:transfer")
    assert target.status is ClosureStatus.OPEN
    assert target.authority is Authority.RESEARCH
    assert state.debts["debt:transfer"].status == "OPEN"


def test_cv07_reopening_wave_marks_dependent_closed_object_stale_and_blocked_route_reopened():
    state = NativeState()
    state.objects["premise:a"] = ObjectRecord("premise:a", "ASSUMPTION", "formal", "v0.1", ClosureStatus.CLOSED_POSITIVE)
    state.objects["claim:b"] = ObjectRecord("claim:b", "CLAIM", "formal", "v0.1", ClosureStatus.CLOSED_POSITIVE)
    state.objects["route:c"] = ObjectRecord("route:c", "ROUTE", "formal", "v0.1", ClosureStatus.BLOCKED)
    state.edges["edge:b-a"] = EdgeRecord("edge:b-a", "DEPENDS_ON", ["claim:b"], ["premise:a"])
    state.edges["edge:c-a"] = EdgeRecord("edge:c-a", "DEPENDS_ON", ["route:c"], ["premise:a"])
    changed = reopen_dependents(state, "premise:a", "premise invalidated")
    assert changed == ["claim:b", "route:c"]
    assert state.objects["claim:b"].status is ClosureStatus.STALE
    assert state.objects["route:c"].status is ClosureStatus.REOPENED


def test_cv08_false_quotient_split_preserves_history_and_restores_objects():
    state = NativeState()
    state.objects["quotient:q"] = ObjectRecord("quotient:q", "ROUTE", "formal", "v0.1", ClosureStatus.OPEN)
    restored = [
        ObjectRecord("route:a", "ROUTE", "formal", "v0.1", ClosureStatus.OPEN),
        ObjectRecord("route:b", "ROUTE", "formal", "v0.1", ClosureStatus.OPEN),
    ]
    split_quotient(state, "quotient:q", restored, "assumption divergence")
    assert state.objects["quotient:q"].status is ClosureStatus.SUPERSEDED
    assert "route:a" in state.objects and "route:b" in state.objects
    assert any(e.get("cause") == "quotient_split:assumption divergence" for e in state.status_history)


def test_cv09_same_ledger_replay_same_hash():
    events = [LedgerEvent("e1", "REGISTER_OBJECT", {
        "object_id":"claim:q", "object_type":"CLAIM", "domain_id":"formal", "version":"v0.1", "status":"OPEN"
    }, 1)]
    assert state_hash(replay_ledger(events)) == state_hash(replay_ledger(events))


def test_cv10_stale_transaction_rejected():
    state = NativeState()
    ledger = EventLedger()
    txn = ClosureTransaction(state, ledger)
    txn.stage(LedgerEvent("e1", "REGISTER_OBJECT", {
        "object_id":"claim:q", "object_type":"CLAIM", "domain_id":"formal", "version":"v0.1", "status":"OPEN"
    }, 1))
    state.objects["claim:external"] = ObjectRecord("claim:external", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)
    with pytest.raises(StaleTransactionError):
        txn.commit()


def test_cv11_ns_no_go_label_is_obstruction_candidate_only():
    candidate = candidate_from_source_label("NO-GO", "artifact:x", "span")
    assert candidate.candidate_type == "ObstructionCandidate"
    assert candidate.validation_state == "UNVERIFIED"


def test_cv12_ns_closed_without_cert_is_unverified_status_candidate():
    candidate = candidate_from_source_label("CLOSED", "artifact:x", "span")
    assert candidate.candidate_type == "StatusCandidate"
    assert candidate.validation_state == "UNVERIFIED"


@pytest.mark.parametrize("assertion_id", [f"A{i:02d}" for i in range(1, 13)])
def test_ns_gsm_seed_assertions(assertion_id):
    result = materialize_seed_state(SEED)
    state = result.state
    checks = {
        "A01": state.objects["claim:formal-root-regularity"].status is ClosureStatus.OPEN,
        "A02": state.objects["claim:c1-chain-necessity"].status is ClosureStatus.OPEN,
        "A03": state.objects["claim:c2-finite-obstruction"].status is ClosureStatus.OPEN,
        "A04": state.objects["claim:formal-root-regularity"].status is ClosureStatus.OPEN,
        "A05": state.objects["claim:d104-frozen-coaxial-no-go"].status is ClosureStatus.CLOSED_NEGATIVE,
        "A06": state.objects["survivor:d104-simple-shear"].status is ClosureStatus.OPEN,
        "A07": any(e.get("event_type") == "SCOPE_REVISION" for e in state.status_history),
        "A08": any("global NS regularity" in obj.metadata.get("forbidden_promotion", "") for obj in state.objects.values() if obj.object_type == "NONCLAIM"),
        "A09": state.objects["frontier:d105-first-order"].status is ClosureStatus.OPEN,
        "A10": state.objects["claim:formal-root-regularity"].status is ClosureStatus.OPEN,
        "A11": "obstruction:c6q-projected-tail-not-intrinsic-growth-carrier" in state.objects,
        "A12": state.scope == "observed-relative",
    }
    assert checks[assertion_id]
