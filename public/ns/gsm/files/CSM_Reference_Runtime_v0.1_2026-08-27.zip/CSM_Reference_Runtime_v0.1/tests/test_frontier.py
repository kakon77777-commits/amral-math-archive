from csm_runtime.enums import ClosureStatus
from csm_runtime.frontier import rebuild_frontier
from csm_runtime.model import NativeState, ObjectRecord


def test_frontier_is_observed_relative_and_excludes_closed_frontiers():
    state = NativeState(scope="observed-relative")
    state.objects["frontier:open"] = ObjectRecord(
        "frontier:open", "FRONTIER", "formal", "v0.1", ClosureStatus.OPEN
    )
    state.objects["frontier:conditional"] = ObjectRecord(
        "frontier:conditional", "FRONTIER", "formal", "v0.1", ClosureStatus.CONDITIONAL
    )
    state.objects["frontier:closed"] = ObjectRecord(
        "frontier:closed", "FRONTIER", "formal", "v0.1", ClosureStatus.CLOSED_POSITIVE
    )
    result = rebuild_frontier(state)
    assert result.scope == "observed-relative"
    assert result.object_ids == ["frontier:conditional", "frontier:open"]
    assert state.frontier_ids == result.object_ids
