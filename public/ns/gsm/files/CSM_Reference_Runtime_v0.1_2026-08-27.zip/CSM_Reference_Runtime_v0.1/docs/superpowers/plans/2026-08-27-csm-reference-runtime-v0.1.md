# CSM Reference Runtime v0.1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a deterministic Python reference runtime that loads the NS_GSM Seed Dataset v0.1, validates proof-carrying closure mutations, commits atomic ledger-backed transactions, replays to the same state hash, rebuilds an observed-relative frontier, and passes runtime + seed conformance.

**Architecture:** Use a dependency-light Python core with typed dataclasses, canonical JSON hashing, an append-only JSONL ledger, copy-on-write transactions, deterministic replay, and an NS_GSM YAML/JSON adapter. Candidate data and source labels remain outside native theorem authority; all native status changes flow through explicit operators and certificates.

**Tech Stack:** Python 3.11+, standard library, PyYAML, pytest.

**Spec:** `docs/superpowers/specs/2026-08-27-csm-reference-runtime-v0.1-design.md`

## Global Constraints

- Runtime is deterministic and local.
- Canonical ledger is append-only JSONL.
- No theorem-level mutation without a valid certificate path.
- Candidate records cannot directly mutate native theorem status.
- Debt cannot disappear without a discharge event.
- `BLOCKED != CLOSED_NEGATIVE`.
- `SURVIVOR` is a role tag, not a base closure status.
- Root NS target remains observed-relative and OPEN.
- D104 narrow no-go remains valid in declared scope while silent epsilon-to-zero promotion is invalidated by D105.
- No SQLite, graph database, GUI, LLM, theorem prover, web API, or DCRP106 research in v0.1.

---

## File Structure

```text
CSM_Reference_Runtime_v0.1/
  pyproject.toml
  README.md
  src/csm_runtime/
    __init__.py
    enums.py
    errors.py
    model.py
    canonical.py
    ledger.py
    state.py
    operators.py
    transaction.py
    replay.py
    frontier.py
    query.py
    ns_gsm_adapter.py
    cli.py
  tests/
    test_canonical.py
    test_candidate_firewall.py
    test_operators.py
    test_transactions.py
    test_replay.py
    test_frontier.py
    test_queries.py
    test_ns_gsm_seed.py
    test_conformance_vectors.py
  examples/
    run_ns_gsm_seed.py
  docs/
    superpowers/specs/...
    superpowers/plans/...
```

### Task 1: Canonical model and hashing

**Files:**
- Create: `pyproject.toml`
- Create: `src/csm_runtime/enums.py`
- Create: `src/csm_runtime/errors.py`
- Create: `src/csm_runtime/model.py`
- Create: `src/csm_runtime/canonical.py`
- Test: `tests/test_canonical.py`

**Interfaces:**
- Produces: `ClosureStatus`, `Authority`, `ExecResult`, `ObjectRecord`, `CertificateRecord`, `DebtRecord`, `EdgeRecord`, `NativeState`, `canonical_json_bytes()`, `state_hash()`.

- [ ] **Step 1: Write failing canonical hash test**

```python
from csm_runtime.model import NativeState, ObjectRecord
from csm_runtime.enums import ClosureStatus
from csm_runtime.canonical import state_hash

def test_state_hash_is_order_independent_for_registry_keys():
    a = NativeState()
    a.objects["b"] = ObjectRecord("b", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)
    a.objects["a"] = ObjectRecord("a", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)

    b = NativeState()
    b.objects["a"] = ObjectRecord("a", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)
    b.objects["b"] = ObjectRecord("b", "CLAIM", "formal", "v0.1", ClosureStatus.OPEN)

    assert state_hash(a) == state_hash(b)
```

- [ ] **Step 2: Run and verify failure**

Run: `pytest tests/test_canonical.py -q`  
Expected: import/module failure.

- [ ] **Step 3: Implement minimal typed model + canonical serializer**

Implement enums and dataclasses with `to_dict()` methods. Canonical JSON uses `json.dumps(..., sort_keys=True, separators=(",", ":"), ensure_ascii=False)` and SHA-256.

- [ ] **Step 4: Run canonical tests**

Run: `pytest tests/test_canonical.py -q`  
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml src/csm_runtime tests/test_canonical.py
git commit -m "feat: add canonical CSM runtime model"
```

### Task 2: Candidate firewall and proof-carrying operators

**Files:**
- Create: `src/csm_runtime/operators.py`
- Test: `tests/test_candidate_firewall.py`
- Test: `tests/test_operators.py`

**Interfaces:**
- Consumes: `NativeState`, record types.
- Produces: `register_object()`, `block_route()`, `close_positive()`, `close_negative()`, `mark_stale()`, `reopen_route()`, `add_debt()`, `discharge_debt()`, `add_edge()`.

- [ ] **Step 1: Write failing firewall and Block != Refute tests**

```python
def test_candidate_cannot_directly_create_closed_native_claim():
    with pytest.raises(AuthorityError):
        promote_candidate_directly_to_status(...)

def test_block_route_does_not_refute_parent_claim():
    block_route(state, route_id, obstruction_cert_id)
    assert state.objects[route_id].status is ClosureStatus.BLOCKED
    assert state.objects[parent_id].status is ClosureStatus.OPEN
```

- [ ] **Step 2: Run focused tests and verify failure**

Run: `pytest tests/test_candidate_firewall.py tests/test_operators.py -q`

- [ ] **Step 3: Implement legal status transition table**

Allow only transitions explicitly supported by an operator. `close_negative()` requires a valid negative certificate. `block_route()` only changes the route.

- [ ] **Step 4: Run focused tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/operators.py tests/test_candidate_firewall.py tests/test_operators.py
git commit -m "feat: enforce proof-carrying closure operators"
```

### Task 3: Append-only ledger and atomic transactions

**Files:**
- Create: `src/csm_runtime/ledger.py`
- Create: `src/csm_runtime/transaction.py`
- Test: `tests/test_transactions.py`

**Interfaces:**
- Produces: `EventLedger`, `ClosureTransaction`, `TransactionResult`, `StaleTransactionError`.

- [ ] **Step 1: Write failing transaction tests**

Test:
- commit appends events;
- abort leaves state unchanged;
- stale input hash rejects commit;
- duplicate event ID rejected;
- no partial native mutation on failure.

- [ ] **Step 2: Run focused test**

Run: `pytest tests/test_transactions.py -q`  
Expected: FAIL.

- [ ] **Step 3: Implement copy-on-write transaction**

The transaction clones input state, runs operators against the clone, validates output, then appends events and returns the committed state only if all steps pass.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/ledger.py src/csm_runtime/transaction.py tests/test_transactions.py
git commit -m "feat: add atomic ledger-backed transactions"
```

### Task 4: Deterministic replay

**Files:**
- Create: `src/csm_runtime/replay.py`
- Test: `tests/test_replay.py`

**Interfaces:**
- Produces: `replay_ledger(events, policy_version="v0.1") -> NativeState`, `verify_replay(expected_state, events)`.

- [ ] **Step 1: Write failing replay tests**

```python
def test_same_ledger_replays_to_same_hash():
    s1 = replay_ledger(events)
    s2 = replay_ledger(events)
    assert state_hash(s1) == state_hash(s2)

def test_tampered_event_changes_or_invalidates_replay():
    ...
```

- [ ] **Step 2: Run focused tests and verify failure**

- [ ] **Step 3: Implement deterministic event reducer**

Replay supports the v0.1 event set only and refuses unknown mutation event types.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/replay.py tests/test_replay.py
git commit -m "feat: add deterministic closure replay"
```

### Task 5: Frontier and authority-carrying queries

**Files:**
- Create: `src/csm_runtime/frontier.py`
- Create: `src/csm_runtime/query.py`
- Test: `tests/test_frontier.py`
- Test: `tests/test_queries.py`

**Interfaces:**
- Produces: `rebuild_frontier(state)`, `QueryEngine.status()`, `why_blocked()`, `frontier()`, `debt()`, `history()`, `replay_check()`.

- [ ] **Step 1: Write failing frontier test**

Active frontier includes OPEN/CONDITIONAL/REOPENED frontier-relevant objects, excludes closed branch objects, and always returns `scope="observed-relative"`.

- [ ] **Step 2: Write failing query authority test**

Every result contains answer, authority, certificate refs, debt refs, version, source layer.

- [ ] **Step 3: Run focused tests**

- [ ] **Step 4: Implement conservative frontier/query engines**

No route-completeness claim is made.

- [ ] **Step 5: Run tests and commit**

```bash
git add src/csm_runtime/frontier.py src/csm_runtime/query.py tests/test_frontier.py tests/test_queries.py
git commit -m "feat: add observed-relative frontier and queries"
```

### Task 6: NS_GSM seed adapter and genesis transaction

**Files:**
- Create: `src/csm_runtime/ns_gsm_adapter.py`
- Test: `tests/test_ns_gsm_seed.py`
- Create: `examples/run_ns_gsm_seed.py`

**Interfaces:**
- Produces: `load_ns_gsm_seed(path)`, `build_genesis_transaction(seed)`, `materialize_seed_state(seed_path)`.

- [ ] **Step 1: Write failing seed tests**

Tests must assert:
- five physical artifacts / seven logical seed units;
- root formal NS OPEN;
- C1 OPEN;
- C2 OPEN;
- D104 coaxial claim CLOSED_NEGATIVE only in narrow object;
- D104 shear survivor OPEN + `SURVIVOR`;
- D104 axisymmetric survivor OPEN + `SURVIVOR`;
- D105 vm shear/pol OPEN + `SURVIVOR`;
- D105 first-order frontier OPEN;
- D105 nonclaim forbids global regularity promotion;
- observed-relative scope.

- [ ] **Step 2: Run and verify failure**

Set `NS_GSM_SEED_PATH` or copy the supplied seed package into test fixtures.

- [ ] **Step 3: Implement adapter**

Convert source YAML/JSON to deterministic genesis records/events. Preserve source assertions but do not derive stronger statuses.

- [ ] **Step 4: Run seed tests**

Expected: PASS.

- [ ] **Step 5: Add example script**

Script prints state hash, root status, survivor statuses, and active frontier.

- [ ] **Step 6: Commit**

```bash
git add src/csm_runtime/ns_gsm_adapter.py tests/test_ns_gsm_seed.py examples/run_ns_gsm_seed.py
git commit -m "feat: ingest NS_GSM seed dataset"
```

### Task 7: D104 -> D105 scope-revision behavior

**Files:**
- Modify: `src/csm_runtime/ns_gsm_adapter.py`
- Modify: `src/csm_runtime/operators.py`
- Test: `tests/test_ns_gsm_seed.py`

**Interfaces:**
- Produces runtime history where the narrow D104 result remains valid while broader silent promotion is represented as stale/forbidden and D105 survivor/frontier remains active.

- [ ] **Step 1: Write failing history test**

Assert:
- D104 fixed-positive-viscosity claim remains CLOSED_NEGATIVE in its own scope;
- no root/global negative closure is created;
- D105 nonuniformity claim is CLOSED_POSITIVE;
- D105 survivor is OPEN;
- D105 frontier is OPEN;
- history includes a scope-revision event.

- [ ] **Step 2: Run focused test and verify failure**

- [ ] **Step 3: Implement explicit `SCOPE_REVISION` event handling**

It must invalidate only broader inherited transfer, never erase the narrow source certificate.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/ns_gsm_adapter.py src/csm_runtime/operators.py tests/test_ns_gsm_seed.py
git commit -m "feat: preserve D104-D105 scope revision lineage"
```

### Task 8: Runtime conformance vectors, CLI, and closure package

**Files:**
- Create: `tests/test_conformance_vectors.py`
- Create: `src/csm_runtime/cli.py`
- Create: `README.md`
- Create generated artifacts under `evidence/`

**Interfaces:**
- CLI commands: `seed-run`, `state-hash`, `frontier`, `status`, `why-blocked`, `replay-check`.

- [ ] **Step 1: Encode 12 Paper 08 conformance vectors + 12 seed assertions as tests**

- [ ] **Step 2: Run full test suite**

Run: `pytest -q`  
Expected: all PASS.

- [ ] **Step 3: Implement CLI and example evidence output**

Generate:
- `evidence/ns_gsm_genesis_ledger.jsonl`
- `evidence/ns_gsm_native_snapshot.json`
- `evidence/ns_gsm_query_demo.json`
- `evidence/conformance_report.json`
- `evidence/replay_report.json`

- [ ] **Step 4: Run CLI seed closure**

Run:

```bash
python -m csm_runtime.cli seed-run --seed <NS_GSM_SEED_PATH> --evidence evidence
python -m csm_runtime.cli replay-check --ledger evidence/ns_gsm_genesis_ledger.jsonl --snapshot evidence/ns_gsm_native_snapshot.json
```

Expected: replay hash exact match.

- [ ] **Step 5: Run full regression again**

Run: `pytest -q`  
Expected: PASS.

- [ ] **Step 6: Package and commit**

```bash
git add .
git commit -m "release: CSM Reference Runtime v0.1 seed closure"
```

Create ZIP containing source, tests, docs, and evidence.

---

## Plan Self-Review

- Spec coverage: model, hashing, candidate firewall, proof-carrying mutation, ledger, atomic transaction, replay, frontier, queries, NS_GSM adapter, D104/D105 revision, conformance, CLI, evidence, and packaging are covered.
- Explicit non-goals remain excluded.
- No unresolved placeholders are required for implementation.
- Interfaces use the same canonical names across tasks.
- The plan yields a working testable runtime at every task boundary.
