# CSM Reference Runtime v0.1 — Design Specification

**Date:** 2026-08-27  
**Status:** Design for user review  
**Canonical dataset:** `NS_GSM Seed Dataset v0.1`  
**Primary theory basis:** CSM Papers 00–09  
**Implementation language:** Python 3.11+  
**Runtime mode:** deterministic, local, dependency-light

---

## 1. Purpose

CSM Reference Runtime v0.1 is the first executable implementation of the Closure-Space Mathematics runtime semantics.

Its job is **not** to prove Navier–Stokes. Its job is to make closure-state mutations mechanically auditable.

The v0.1 success criterion is:

> Load the NS_GSM seed dataset, reconstruct a canonical native state, validate proof-carrying mutations, execute atomic transactions, deterministically replay the ledger, rebuild the observed-relative frontier, answer authority-carrying queries, and pass all seed/conformance assertions.

---

## 2. Chosen Architecture

### Recommended approach — Pure Python deterministic core

The runtime will use:

- Python dataclasses / typed records for native objects;
- YAML/JSON loaders for seed ingestion;
- append-only JSONL as the canonical event ledger;
- canonical JSON serialization for deterministic hashing;
- in-memory native state rebuilt from the ledger;
- JSON snapshot export as a replaceable materialization;
- no database dependency in v0.1;
- no web server;
- no GUI;
- no LLM dependency;
- no theorem-prover dependency.

### Why this approach

The hardest thing in v0.1 is semantic correctness, not storage throughput.

A pure deterministic core makes these invariants directly testable:

1. same ledger + same policy => same state hash;
2. candidate records cannot directly mutate theorem status;
3. debt cannot disappear without discharge;
4. `BLOCKED != CLOSED_NEGATIVE`;
5. D104 narrow no-go survives while silent vanishing-viscosity promotion is invalidated;
6. D105 survivor/frontier can be rebuilt without deleting D104 history;
7. projection/query authority never exceeds source authority.

### Deferred alternatives

**SQLite-first** is postponed until the state transition model is stable. It gives stronger storage transactions but prematurely couples semantics to persistence.

**Graph-database-first** is postponed because graph adjacency must never become a substitute for typed proof authority.

---

## 3. Runtime Layers

The implementation has three authority layers:

```text
L0 Canonical Event Ledger
        |
        v
L1 Native Materialized State
        |
        v
L2 Purpose-Specific Views / Queries
```

`L0` is append-only committed history.

`L1` is fully reconstructable and replaceable.

`L2` is authority-bounded and cannot perform native theorem mutation.

---

## 4. Package Layout

```text
csm_reference_runtime/
  pyproject.toml
  README.md
  src/
    csm_runtime/
      __init__.py
      model.py
      enums.py
      canonical.py
      errors.py
      registry.py
      ledger.py
      state.py
      operators.py
      transaction.py
      replay.py
      frontier.py
      query.py
      ns_gsm_adapter.py
      cli.py
  tests/
    test_canonical.py
    test_ledger.py
    test_candidate_firewall.py
    test_operators.py
    test_transactions.py
    test_replay.py
    test_frontier.py
    test_queries.py
    test_ns_gsm_seed.py
    test_conformance_vectors.py
  examples/
    run_ns_gsm_seed.py
  docs/
    runtime_contract.md
    ns_gsm_seed_handoff.md
```

---

## 5. Canonical Record Model

### ObjectRecord

Required fields:

- `object_id`
- `object_type`
- `domain_id`
- `version`
- `source_refs`
- `status`
- `role_tags`
- `certificate_refs`
- `debt_refs`
- `metadata`

### CandidateRecord

Candidate records are explicitly outside theorem authority.

Required fields:

- `candidate_id`
- `source_ref`
- `candidate_type`
- `proposed_object`
- `parser_version`
- `confidence`
- `validation_state`

A CandidateRecord may be validated and promoted, but cannot directly set native theorem status.

### CertificateRecord

Required fields:

- `certificate_id`
- `certificate_type`
- `subject_ids`
- `status`
- `scope`
- `evidence_refs`
- `verifier_results`
- `version`

### DebtRecord

Required fields:

- `debt_id`
- `debt_type`
- `subject_id`
- `status`
- `cause`
- `discharge_requirements`
- `dependencies`
- `version`

---

## 6. Canonical Serialization

The runtime must produce stable bytes for equivalent native states.

Rules:

1. JSON UTF-8;
2. sorted object keys;
3. deterministic list ordering where semantic order is irrelevant;
4. no implicit null omission;
5. enums serialized as canonical strings;
6. floating-point values are prohibited from authority-critical hashes unless explicitly normalized;
7. state hash uses SHA-256 over canonical serialized state.

The hash is a consistency identifier, not a truth score.

---

## 7. Event Ledger

The ledger is JSONL.

Each event contains:

```json
{
  "event_id": "...",
  "event_type": "...",
  "payload": {},
  "certificate_refs": [],
  "debt_delta": {},
  "provenance": {},
  "operator_version": "...",
  "policy_version": "...",
  "sequence": 1
}
```

Properties:

- append-only;
- strict sequence;
- duplicate event IDs rejected;
- correction uses new events;
- no in-place mutation;
- replay can start from genesis for v0.1.

---

## 8. Native State

Native state contains:

- object registry;
- certificate registry;
- debt registry;
- status history;
- typed edges;
- active frontier;
- policy metadata;
- ledger head;
- state hash.

The seed dataset itself is **not** treated as already-committed theorem history. The adapter turns seed records into a deterministic genesis transaction.

---

## 9. Proof-Carrying Operators Implemented in v0.1

v0.1 implements a minimal subset sufficient for the seed:

### `RegisterObject`
Creates native identity without theorem promotion.

### `SetStatus`
Allowed only when a status-transition certificate policy is satisfied.

### `BlockRoute`
Transitions `OPEN -> BLOCKED`.

It must not mutate the parent claim to `CLOSED_NEGATIVE`.

### `ClosePositive`
Requires an accepted positive proof certificate.

### `CloseNegative`
Requires an accepted counterexample / no-go certificate with matching scope.

### `MarkStale`
Preserves previous valid history and marks current authority stale.

### `ReopenRoute`
Requires an invalidation / scope-revision cause.

### `AddDebt`
Adds unresolved proof obligation.

### `DischargeDebt`
Requires discharge evidence and cannot silently remove unrelated debt.

### `AddEdge`
Requires a typed edge kind.

### `RebuildFrontier`
Derived operation only; it does not itself create theorem authority.

No `PromoteGlobal`, `ExhaustAbsolute`, or cross-domain theorem promotion is implemented in v0.1.

---

## 10. Status Semantics

Base statuses:

```text
UNVERIFIED
UNKNOWN
OPEN
CONDITIONAL
BLOCKED
CLOSED_POSITIVE
CLOSED_NEGATIVE
STALE
REOPENED
SUPERSEDED
```

`SURVIVOR` is a role tag, not a base status.

Critical illegal transition:

```text
BLOCKED -> CLOSED_NEGATIVE
```

unless a new negative-closure certificate is independently supplied.

---

## 11. Transaction Semantics

A transaction goes through:

```text
PLANNED
  -> PREFLIGHT
  -> EXECUTING
  -> COMMITTING
  -> COMMITTED
```

or:

```text
-> ABORTED
```

Preflight checks:

- input state hash matches head;
- every referenced object exists or is created earlier in the same transaction;
- every certificate exists and is valid under policy;
- debt transitions are legal;
- status transition is legal;
- typed edges resolve;
- duplicate IDs are rejected.

Execution uses an isolated copy-on-write state.

Only a successful commit appends events and replaces the materialized state.

---

## 12. Deterministic Replay

Replay starts from an empty genesis state and applies committed ledger events in sequence.

Required invariant:

```text
replay(ledger).state_hash == stored_state.state_hash
```

Two replay runs must yield the same hash.

Any mismatch raises `RuntimeInconsistentError` and blocks native mutation.

---

## 13. NS_GSM Adapter

The adapter loads:

- `dataset.yaml`
- `domains.yaml`
- `series.yaml`
- `artifacts.yaml`
- `claims.yaml`
- `routes.yaml`
- `obstructions.yaml`
- `survivors.yaml`
- `frontiers.yaml`
- `bridges.yaml`
- `debts.yaml`
- `certificates.yaml`
- `nonclaims.yaml`
- `graph_snapshot_v0.1.json`

The adapter performs four phases:

1. parse;
2. schema/integrity validation;
3. deterministic conversion to candidate/native genesis records;
4. genesis transaction generation.

Important rule:

> Source labels are data, not authority commands.

`NO-GO`, `STOP`, `SURVIVOR`, and `CLOSED` never bypass the operator layer.

---

## 14. Seed Runtime Expectations

The committed seed state must satisfy:

### Root target

```text
formal NS root = OPEN
```

with route-completeness and representation-completeness debt.

### C1 / C2

```text
C1 = OPEN
C2 = OPEN
```

### D103

Five-ray classification is a local positive asset / classification branch.

It does not close the root target.

### D104

The narrow frozen coaxial branch can be `CLOSED_NEGATIVE` in its declared scope.

Simple shear and axisymmetric families remain:

```text
status = OPEN
role_tag = SURVIVOR
```

### D105

The runtime must preserve both facts:

1. D104 narrow fixed-positive-viscosity no-go remains in history;
2. silent uniform promotion to vanishing viscosity is invalid.

The D105 viscosity-matched shear/polarization branch remains:

```text
OPEN + SURVIVOR
```

and the active frontier includes first-order solvability / spectral drift.

---

## 15. Frontier Rebuild v0.1

The frontier engine is intentionally conservative.

It includes objects that are:

- `OPEN`;
- `CONDITIONAL`;
- `REOPENED`;

and tagged / typed as frontier-relevant.

It excludes closed branch objects from the active frontier but keeps them addressable in history.

It does **not** claim route completeness.

The resulting frontier is always labeled:

```text
observed-relative
```

---

## 16. Query API

v0.1 provides programmatic methods and a tiny CLI.

Queries:

- `status <id>`
- `why-blocked <id>`
- `frontier`
- `debt <id>`
- `history <id>`
- `state-hash`
- `replay-check`

Every result includes:

- answer;
- source layer;
- authority;
- version;
- certificate refs;
- debt refs.

---

## 17. Error Model

### `ValidationError`
Malformed seed/runtime input.

### `AuthorityError`
Attempt to mutate beyond available certificate authority.

### `IllegalTransitionError`
Invalid status transition.

### `StaleTransactionError`
Input head changed before commit.

### `RuntimeInconsistentError`
Replay hash mismatch.

### `UnknownObjectError`
Reference cannot resolve.

All authority-critical failures are fail-closed.

---

## 18. Testing Strategy

Implementation is test-driven.

### Unit tests

- canonical serialization;
- stable hash;
- ID uniqueness;
- candidate/native firewall;
- debt persistence;
- status transitions;
- typed edges;
- ledger append rules.

### Transaction tests

- commit;
- abort;
- stale input hash;
- no partial mutation;
- deterministic event ordering.

### Replay tests

- same ledger => same hash;
- committed seed replay equals materialized seed state;
- tampered ledger => mismatch.

### NS_GSM semantic tests

- root remains OPEN;
- C1/C2 remain OPEN;
- D104 narrow no-go remains narrow;
- D104 survivors remain OPEN;
- D105 scope correction preserves history;
- D105 survivor/frontier remains OPEN;
- `NO-GO` is not equivalent to root refutation;
- observed-relative guard is always present.

### Conformance vectors

The 12 Paper 08 runtime vectors plus the 12 seed assertions are executable tests.

---

## 19. Output Artifacts

A successful v0.1 implementation package will include:

- source package;
- tests;
- seed adapter;
- generated genesis ledger;
- generated native snapshot;
- query demonstration output;
- conformance report;
- replay report;
- ZIP bundle.

---

## 20. Definition of Done

The runtime is complete for v0.1 when:

1. all unit tests pass;
2. all transaction/replay tests pass;
3. all 12 runtime conformance vectors pass;
4. all 12 NS_GSM seed assertions pass;
5. replay of the committed genesis ledger reproduces the exact state hash;
6. root NS target remains OPEN;
7. D104 -> D105 scope-revision history is reconstructable;
8. D105 survivor and frontier are queryable;
9. no CandidateRecord can directly mutate theorem status;
10. package ZIP integrity passes.

---

## 21. Explicit Non-Goals

v0.1 does not implement:

- theorem proving;
- LLM extraction;
- automatic full-corpus ingestion;
- route-completeness proof;
- GUI;
- web API;
- graph database;
- SQLite persistence;
- multi-user concurrency;
- generalized/physical NS theorem transfer;
- DCRP106 research.

Those belong after the seed runtime closes correctly.

---

## 22. Next Phase After v0.1

Once the seed runtime passes, the next engineering phase is:

```text
Full NS_GSM Corpus Ingestion v0.2
```

Expansion order:

1. C3–C6 full;
2. RFP;
3. MORP;
4. X72 selected checkpoints;
5. DCRP full;
6. FCBP;
7. Proof Asset Map;
8. validation/check scripts.

The runtime semantics remain unchanged unless a failing conformance test proves the model insufficient.
