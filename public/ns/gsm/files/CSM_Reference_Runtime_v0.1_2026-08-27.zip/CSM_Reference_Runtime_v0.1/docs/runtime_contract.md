# Runtime Contract v0.1

The canonical committed history is an append-only JSONL ledger. Native state is a replaceable materialization reconstructed by replay. Views and queries are authority-bounded projections.

The runtime refuses authority-critical operations on invalid certificates, stale transactions, unresolved object references, unsupported event types, or projected display objects.

The native status set is: `UNVERIFIED`, `UNKNOWN`, `OPEN`, `CONDITIONAL`, `BLOCKED`, `CLOSED_POSITIVE`, `CLOSED_NEGATIVE`, `STALE`, `REOPENED`, `SUPERSEDED`.

`SURVIVOR` is a role tag and `NO-GO` is represented as an obstruction object.
