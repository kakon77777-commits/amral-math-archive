# CSM Reference Runtime v0.3

A deterministic local reference runtime for **Closure-Space Mathematics (CSM)** with staged **NS_GSM corpus ingestion, candidate review, and proof-carrying promotion gates**.

v0.3 preserves the v0.2 authority firewall and adds a replayable review layer. Every corpus candidate now receives an explicit review decision; only structurally safe classes are automatically promoted, while theorem/NO-GO candidates remain deferred unless a matching certificate and scope audit authorize native mutation.

## What v0.3 proves about itself

It proves runtime/review conformance only: corpus candidates can be reviewed deterministically; review batches are atomic and idempotent; promotion receipts are replayable; safe structural objects can be promoted without closing parent claims; cross-series matches never auto-quotient; and the final native state replays to the exact stored hash.

It does **not** prove Navier–Stokes global regularity, route completeness, representation completeness, generalized NS-like closure, physical-model adequacy, or that all deferred candidates are true/false.

## Core authority invariants

```text
No certificate path => no native theorem mutation.
Candidate != Review != Promotion != Theorem.
Obstruction object creation != parent refutation.
SURVIVOR => OPEN + SURVIVOR role tag.
STOP/Next => OPEN frontier object.
Cross-series exact match => NEEDS_REVIEW; auto_quotient=false.
```

## v0.3 frozen checkpoint

- baseline v0.2 content artifacts: 46
- v0.3 source-backed expansion artifacts: 15
- total content artifacts: 61
- candidates: 1,726
- review records: 1,726
- structural promotions: 727
- pending/deferred reviews: 999
- cross-series proposals: 252
- automatic quotients: 0
- ledger events: 5,066
- root formal NS: `OPEN`
- scope: `observed-relative`
- native/replay state SHA-256: `be70fd6236051454bda1e0e1a46fbb943b1d53729713cf79a5d3b09f3498bd7b`
- conformance: 11/11 PASS

### Structural promotion classes

| Class | Count | Native meaning |
|---|---:|---|
| FRONTIER | 498 | OPEN frontier object |
| NONCLAIM | 159 | explicit authority boundary |
| SURVIVOR | 70 | OPEN route with SURVIVOR role |

Tier-0 intentionally performs **zero automatic PROOF_ASSET and zero automatic OBSTRUCTION promotion**. Those remain for certificate/scope-aware review.

## v0.3 coverage expansion

The original v0.2 46-artifact corpus remains unchanged. v0.3 adds a separate `corpus_v03_expansion/` with 15 source-backed files:

- C-series: C4, C5, C6 (3)
- DCRP milestones: 11, 13, 18, 29, 64, 65, 66, 67, 69, 77, 98, 100 (12)

This is **coverage expansion**, not theorem progress by itself.

## Run tests

```bash
pytest -q
```

## Run full v0.3 structural review

```bash
PYTHONPATH=src python -m csm_runtime.cli run-structural-review \
  --seed <NS_GSM_SEED_PATH> \
  --corpus corpus \
  --expansion corpus_v03_expansion \
  --evidence evidence/v0.3
```

## Review audit queries

```bash
PYTHONPATH=src python -m csm_runtime.cli review-summary \
  --snapshot evidence/v0.3/native_snapshot_v03.json

PYTHONPATH=src python -m csm_runtime.cli pending-review \
  --snapshot evidence/v0.3/native_snapshot_v03.json

PYTHONPATH=src python -m csm_runtime.cli promotion-summary \
  --snapshot evidence/v0.3/native_snapshot_v03.json
```

## Architecture

```text
Corpus / Expansion
-> Manifest + deterministic parser
-> Candidate Layer
-> ReviewRecord / ReviewDecision
-> PromotionGate
-> existing atomic ClosureTransaction
-> Native structural object / status
-> PromotionReceipt
-> Ledger / Snapshot / Replay
```

The review layer is auditable state, not an external spreadsheet. Review decisions and promotion receipts are part of the canonical replay path.

## v0.4 — Proof-Authority Review

Runtime 0.4.0 adds curated source-hash/scope/certificate authority audits. The first batch audits 20 ETN-X / DCRP103-105 / RFP subjects, creates 12 bounded AUDIT-level proof assets and one AUDIT-level obstruction asset, defers three unresolved closure obligations, and keeps the formal Navier-Stokes root OPEN. Source-internal results are not independent proof verification.

## v0.5 — Independent Verification and Authority Upgrade

v0.5 separates source-internal authority from independent verification. Bounded v0.4 assets are checked by exact symbolic, exact-witness, analytic-schema, graph-theorem, or corpus-audit verifiers. Only a full `VALID` result from a proof-eligible verifier, with no narrowing limitation, may upgrade an existing asset from `AUDIT` to `PROOF` authority. No verification automatically propagates to the formal NS root, C1, or C2.
