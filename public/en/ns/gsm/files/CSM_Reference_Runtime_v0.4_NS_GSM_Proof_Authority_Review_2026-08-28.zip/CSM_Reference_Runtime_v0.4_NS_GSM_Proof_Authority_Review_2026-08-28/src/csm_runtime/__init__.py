"""CSM Reference Runtime v0.4."""

__version__ = "0.4.0"
