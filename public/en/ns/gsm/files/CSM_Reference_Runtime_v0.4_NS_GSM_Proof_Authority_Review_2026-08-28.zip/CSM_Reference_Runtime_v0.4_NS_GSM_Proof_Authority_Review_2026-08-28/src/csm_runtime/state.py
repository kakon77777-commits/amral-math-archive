from __future__ import annotations

from typing import Any

from .enums import Authority, ClosureStatus
from .errors import IllegalTransitionError, UnknownObjectError, ValidationError
from .ledger import LedgerEvent
from .model import AuthorityAuditRecord, CandidateRecord, CertificateRecord, DebtRecord, EdgeRecord, NativeState, ObjectRecord, PromotionReceipt, ReviewRecord


def _object_from_payload(p: dict[str, Any]) -> ObjectRecord:
    return ObjectRecord(
        object_id=p["object_id"],
        object_type=p["object_type"],
        domain_id=p.get("domain_id", "formal"),
        version=p.get("version", "v0.1"),
        status=ClosureStatus(p.get("status", "UNVERIFIED")),
        role_tags=list(p.get("role_tags") or []),
        source_refs=list(p.get("source_refs") or []),
        certificate_refs=list(p.get("certificate_refs") or []),
        debt_refs=list(p.get("debt_refs") or []),
        authority=Authority(p.get("authority", "NONE")),
        metadata=dict(p.get("metadata") or {}),
    )


def _candidate_from_payload(p: dict[str, Any]) -> CandidateRecord:
    return CandidateRecord(
        candidate_id=p["candidate_id"],
        source_ref=p["source_ref"],
        candidate_type=p["candidate_type"],
        proposed_object=dict(p.get("proposed_object") or {}),
        parser_version=p.get("parser_version", "v0.2"),
        confidence=p.get("confidence"),
        validation_state=p.get("validation_state", "UNVERIFIED"),
    )


def _edge_from_payload(p: dict[str, Any]) -> EdgeRecord:
    return EdgeRecord(
        edge_id=p["edge_id"],
        edge_type=p["edge_type"],
        source_ids=list(p.get("source_ids") or []),
        target_ids=list(p.get("target_ids") or []),
        version=p.get("version", "v0.1"),
        metadata=dict(p.get("metadata") or {}),
    )


def _cert_from_payload(p: dict[str, Any]) -> CertificateRecord:
    return CertificateRecord(
        certificate_id=p["certificate_id"],
        certificate_type=p["certificate_type"],
        subject_ids=list(p.get("subject_ids") or []),
        status=p.get("status", "PENDING"),
        scope=p.get("scope"),
        evidence_refs=list(p.get("evidence_refs") or []),
        verifier_results=list(p.get("verifier_results") or []),
        version=p.get("version", "v0.1"),
    )


def _debt_from_payload(p: dict[str, Any]) -> DebtRecord:
    return DebtRecord(
        debt_id=p["debt_id"],
        debt_type=p["debt_type"],
        subject_id=p["subject_id"],
        status=p.get("status", "OPEN"),
        cause=p.get("cause"),
        discharge_requirements=list(p.get("discharge_requirements") or []),
        dependencies=list(p.get("dependencies") or []),
        version=p.get("version", "v0.1"),
    )


def _review_from_payload(p: dict[str, Any]) -> ReviewRecord:
    return ReviewRecord(
        review_id=p["review_id"],
        candidate_id=p["candidate_id"],
        decision=p["decision"],
        reviewer_type=p["reviewer_type"],
        reason=p.get("reason", ""),
        scope=p.get("scope"),
        evidence_refs=list(p.get("evidence_refs") or []),
        certificate_refs=list(p.get("certificate_refs") or []),
        target_native_id=p.get("target_native_id"),
        review_version=p.get("review_version", "v0.3"),
        status=p.get("status", "PENDING"),
    )


def _promotion_receipt_from_payload(p: dict[str, Any]) -> PromotionReceipt:
    return PromotionReceipt(
        promotion_id=p["promotion_id"],
        review_id=p["review_id"],
        candidate_id=p["candidate_id"],
        native_object_id=p["native_object_id"],
        promotion_class=p["promotion_class"],
        certificate_refs=list(p.get("certificate_refs") or []),
        debt_refs=list(p.get("debt_refs") or []),
        event_ids=list(p.get("event_ids") or []),
        state_hash_before=p.get("state_hash_before", ""),
        state_hash_after=p.get("state_hash_after", ""),
    )


def _authority_audit_from_payload(p: dict[str, Any]) -> AuthorityAuditRecord:
    return AuthorityAuditRecord(
        audit_id=p["audit_id"],
        subject_id=p["subject_id"],
        subject_kind=p["subject_kind"],
        source_ref=p["source_ref"],
        source_sha256=p["source_sha256"],
        statement=p["statement"],
        scope=p.get("scope", ""),
        assumptions=list(p.get("assumptions") or []),
        certificate_refs=list(p.get("certificate_refs") or []),
        nonclaim_refs=list(p.get("nonclaim_refs") or []),
        verdict=p.get("verdict", "DEFER_OPEN_OBLIGATION"),
        authority_cap=p.get("authority_cap", "AUDIT"),
        reason=p.get("reason", ""),
        reviewer_type=p.get("reviewer_type", "CURATED_V0_4"),
        audit_version=p.get("audit_version", "v0.4"),
        status=p.get("status", "PENDING"),
    )


def apply_event(state: NativeState, event: LedgerEvent) -> None:
    p = event.payload
    if event.event_type == "REGISTER_OBJECT":
        obj = _object_from_payload(p)
        if obj.object_id in state.objects:
            raise ValidationError(f"duplicate object id: {obj.object_id}")
        state.objects[obj.object_id] = obj
    elif event.event_type == "REGISTER_CANDIDATE":
        candidate = _candidate_from_payload(p)
        if candidate.candidate_id in state.candidates:
            raise ValidationError(f"duplicate candidate id: {candidate.candidate_id}")
        state.candidates[candidate.candidate_id] = candidate
    elif event.event_type == "REGISTER_REVIEW":
        review = _review_from_payload(p)
        if review.review_id in state.reviews:
            raise ValidationError(f"duplicate review id: {review.review_id}")
        state.reviews[review.review_id] = review
    elif event.event_type == "UPDATE_REVIEW_STATUS":
        review_id = p["review_id"]
        if review_id not in state.reviews:
            raise UnknownObjectError(review_id)
        state.reviews[review_id].status = p["status"]
    elif event.event_type == "REGISTER_PROMOTION_RECEIPT":
        receipt = _promotion_receipt_from_payload(p)
        if receipt.promotion_id in state.promotion_receipts:
            raise ValidationError(f"duplicate promotion id: {receipt.promotion_id}")
        state.promotion_receipts[receipt.promotion_id] = receipt
    elif event.event_type == "REGISTER_AUTHORITY_AUDIT":
        audit = _authority_audit_from_payload(p)
        if audit.audit_id in state.authority_audits:
            raise ValidationError(f"duplicate authority audit id: {audit.audit_id}")
        state.authority_audits[audit.audit_id] = audit
    elif event.event_type == "REGISTER_CERTIFICATE":
        cert = _cert_from_payload(p)
        if cert.certificate_id in state.certificates:
            raise ValidationError(f"duplicate certificate id: {cert.certificate_id}")
        state.certificates[cert.certificate_id] = cert
    elif event.event_type == "REGISTER_DEBT":
        debt = _debt_from_payload(p)
        if debt.debt_id in state.debts:
            raise ValidationError(f"duplicate debt id: {debt.debt_id}")
        state.debts[debt.debt_id] = debt
        if debt.subject_id in state.objects:
            obj = state.objects[debt.subject_id]
            if debt.debt_id not in obj.debt_refs:
                obj.debt_refs.append(debt.debt_id)
    elif event.event_type == "ADD_EDGE":
        edge = _edge_from_payload(p)
        if edge.edge_id in state.edges:
            raise ValidationError(f"duplicate edge id: {edge.edge_id}")
        for object_id in edge.source_ids + edge.target_ids:
            if object_id not in state.objects:
                raise UnknownObjectError(object_id)
        state.edges[edge.edge_id] = edge
    elif event.event_type == "SET_STATUS":
        object_id = p["object_id"]
        if object_id not in state.objects:
            raise UnknownObjectError(object_id)
        old = state.objects[object_id].status
        new = ClosureStatus(p["status"])
        state.objects[object_id].status = new
        state.status_history.append({
            "object_id": object_id,
            "old_status": old.value,
            "new_status": new.value,
            "cause": p.get("cause"),
            "event_id": event.event_id,
            "version": state.version,
        })
    elif event.event_type == "DISCHARGE_DEBT":
        debt_id = p["debt_id"]
        if debt_id not in state.debts:
            raise UnknownObjectError(debt_id)
        state.debts[debt_id].status = "DISCHARGED"
    elif event.event_type == "SET_FRONTIER":
        ids = list(p.get("frontier_ids") or [])
        for object_id in ids:
            if object_id not in state.objects:
                raise UnknownObjectError(object_id)
        state.frontier_ids = ids
    elif event.event_type == "SCOPE_REVISION":
        source_id = p["source_object_id"]
        target_id = p["target_object_id"]
        if source_id not in state.objects:
            raise UnknownObjectError(source_id)
        if target_id not in state.objects:
            raise UnknownObjectError(target_id)
        state.status_history.append({
            "event_type": "SCOPE_REVISION",
            "source_object_id": source_id,
            "target_object_id": target_id,
            "preserves_source_status": bool(p.get("preserves_source_status", True)),
            "invalidates_promotion": p.get("invalidates_promotion"),
            "cause": p.get("cause"),
            "event_id": event.event_id,
            "version": state.version,
        })
    elif event.event_type == "CORPUS_CHECKPOINT":
        checkpoint_id = p["checkpoint_id"]
        state.ingestion_checkpoints[checkpoint_id] = dict(p)
    elif event.event_type == "NOTE":
        pass
    else:
        raise ValidationError(f"unsupported event type: {event.event_type}")
    state.ledger_head = event.sequence
