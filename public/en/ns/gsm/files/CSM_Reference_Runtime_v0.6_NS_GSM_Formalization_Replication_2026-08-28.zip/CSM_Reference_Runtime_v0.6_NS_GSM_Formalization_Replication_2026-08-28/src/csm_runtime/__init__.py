"""CSM Reference Runtime v0.6."""

__version__ = "0.6.0"
