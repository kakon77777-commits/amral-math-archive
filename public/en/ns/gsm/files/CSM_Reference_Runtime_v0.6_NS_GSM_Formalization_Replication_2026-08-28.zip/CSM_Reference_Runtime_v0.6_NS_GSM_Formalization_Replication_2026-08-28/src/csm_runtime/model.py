from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .enums import Authority, ClosureStatus


@dataclass
class ObjectRecord:
    object_id: str
    object_type: str
    domain_id: str
    version: str
    status: ClosureStatus = ClosureStatus.UNVERIFIED
    role_tags: list[str] = field(default_factory=list)
    source_refs: list[str] = field(default_factory=list)
    certificate_refs: list[str] = field(default_factory=list)
    debt_refs: list[str] = field(default_factory=list)
    authority: Authority = Authority.NONE
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "object_id": self.object_id,
            "object_type": self.object_type,
            "domain_id": self.domain_id,
            "version": self.version,
            "status": self.status.value,
            "role_tags": sorted(self.role_tags),
            "source_refs": sorted(self.source_refs),
            "certificate_refs": sorted(self.certificate_refs),
            "debt_refs": sorted(self.debt_refs),
            "authority": self.authority.value,
            "metadata": self.metadata,
        }


@dataclass
class CandidateRecord:
    candidate_id: str
    source_ref: str
    candidate_type: str
    proposed_object: dict[str, Any]
    parser_version: str
    confidence: float | None = None
    validation_state: str = "UNVERIFIED"

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "source_ref": self.source_ref,
            "candidate_type": self.candidate_type,
            "proposed_object": self.proposed_object,
            "parser_version": self.parser_version,
            "confidence": self.confidence,
            "validation_state": self.validation_state,
        }


@dataclass
class ReviewRecord:
    review_id: str
    candidate_id: str
    decision: str
    reviewer_type: str
    reason: str
    scope: str | None = None
    evidence_refs: list[str] = field(default_factory=list)
    certificate_refs: list[str] = field(default_factory=list)
    target_native_id: str | None = None
    review_version: str = "v0.3"
    status: str = "PENDING"

    def to_dict(self) -> dict[str, Any]:
        return {
            "review_id": self.review_id,
            "candidate_id": self.candidate_id,
            "decision": self.decision,
            "reviewer_type": self.reviewer_type,
            "reason": self.reason,
            "scope": self.scope,
            "evidence_refs": sorted(self.evidence_refs),
            "certificate_refs": sorted(self.certificate_refs),
            "target_native_id": self.target_native_id,
            "review_version": self.review_version,
            "status": self.status,
        }


@dataclass
class PromotionReceipt:
    promotion_id: str
    review_id: str
    candidate_id: str
    native_object_id: str
    promotion_class: str
    certificate_refs: list[str] = field(default_factory=list)
    debt_refs: list[str] = field(default_factory=list)
    event_ids: list[str] = field(default_factory=list)
    state_hash_before: str = ""
    state_hash_after: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "promotion_id": self.promotion_id,
            "review_id": self.review_id,
            "candidate_id": self.candidate_id,
            "native_object_id": self.native_object_id,
            "promotion_class": self.promotion_class,
            "certificate_refs": sorted(self.certificate_refs),
            "debt_refs": sorted(self.debt_refs),
            "event_ids": list(self.event_ids),
            "state_hash_before": self.state_hash_before,
            "state_hash_after": self.state_hash_after,
        }


@dataclass
class AuthorityAuditRecord:
    audit_id: str
    subject_id: str
    subject_kind: str
    source_ref: str
    source_sha256: str
    statement: str
    scope: str
    assumptions: list[str] = field(default_factory=list)
    certificate_refs: list[str] = field(default_factory=list)
    nonclaim_refs: list[str] = field(default_factory=list)
    verdict: str = "DEFER_OPEN_OBLIGATION"
    authority_cap: str = "AUDIT"
    reason: str = ""
    reviewer_type: str = "CURATED_V0_4"
    audit_version: str = "v0.4"
    status: str = "PENDING"

    def to_dict(self) -> dict[str, Any]:
        return {
            "audit_id": self.audit_id,
            "subject_id": self.subject_id,
            "subject_kind": self.subject_kind,
            "source_ref": self.source_ref,
            "source_sha256": self.source_sha256,
            "statement": self.statement,
            "scope": self.scope,
            "assumptions": sorted(self.assumptions),
            "certificate_refs": sorted(self.certificate_refs),
            "nonclaim_refs": sorted(self.nonclaim_refs),
            "verdict": self.verdict,
            "authority_cap": self.authority_cap,
            "reason": self.reason,
            "reviewer_type": self.reviewer_type,
            "audit_version": self.audit_version,
            "status": self.status,
        }


@dataclass
class IndependentVerificationRecord:
    verification_id: str
    subject_id: str
    verifier_id: str
    verifier_kind: str
    verifier_version: str
    statement: str
    scope: str
    input_sha256: str
    proof_artifact_sha256: str
    result: str
    limitations: list[str] = field(default_factory=list)
    evidence_refs: list[str] = field(default_factory=list)
    verified_at_version: str = "v0.5"

    def to_dict(self) -> dict[str, Any]:
        return {
            "verification_id": self.verification_id,
            "subject_id": self.subject_id,
            "verifier_id": self.verifier_id,
            "verifier_kind": self.verifier_kind,
            "verifier_version": self.verifier_version,
            "statement": self.statement,
            "scope": self.scope,
            "input_sha256": self.input_sha256,
            "proof_artifact_sha256": self.proof_artifact_sha256,
            "result": self.result,
            "limitations": sorted(self.limitations),
            "evidence_refs": sorted(self.evidence_refs),
            "verified_at_version": self.verified_at_version,
        }


@dataclass
class AuthorityUpgradeReceipt:
    upgrade_id: str
    verification_id: str
    subject_id: str
    old_authority: str
    new_authority: str
    certificate_id: str
    event_ids: list[str] = field(default_factory=list)
    state_hash_before: str = ""
    state_hash_after: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "upgrade_id": self.upgrade_id,
            "verification_id": self.verification_id,
            "subject_id": self.subject_id,
            "old_authority": self.old_authority,
            "new_authority": self.new_authority,
            "certificate_id": self.certificate_id,
            "event_ids": list(self.event_ids),
            "state_hash_before": self.state_hash_before,
            "state_hash_after": self.state_hash_after,
        }


@dataclass
class FormalizationRecord:
    formalization_id: str
    subject_id: str
    language: str
    formalization_kind: str
    status: str
    statement: str
    scope: str
    assumptions: list[str] = field(default_factory=list)
    goals: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    bundle_sha256: str = ""
    limitations: list[str] = field(default_factory=list)
    evidence_refs: list[str] = field(default_factory=list)
    formalized_at_version: str = "v0.6"

    def to_dict(self) -> dict[str, Any]:
        return {
            "formalization_id": self.formalization_id, "subject_id": self.subject_id,
            "language": self.language, "formalization_kind": self.formalization_kind,
            "status": self.status, "statement": self.statement, "scope": self.scope,
            "assumptions": sorted(self.assumptions), "goals": list(self.goals),
            "dependencies": sorted(self.dependencies), "bundle_sha256": self.bundle_sha256,
            "limitations": sorted(self.limitations), "evidence_refs": sorted(self.evidence_refs),
            "formalized_at_version": self.formalized_at_version,
        }


@dataclass
class ReplicationRecord:
    replication_id: str
    subject_id: str
    replicator_id: str
    replicator_kind: str
    replicator_version: str
    implementation_sha256: str
    formalization_id: str
    input_bundle_sha256: str
    output_artifact_sha256: str
    result: str
    limitations: list[str] = field(default_factory=list)
    evidence_refs: list[str] = field(default_factory=list)
    replicated_at_version: str = "v0.6"

    def to_dict(self) -> dict[str, Any]:
        return {
            "replication_id": self.replication_id, "subject_id": self.subject_id,
            "replicator_id": self.replicator_id, "replicator_kind": self.replicator_kind,
            "replicator_version": self.replicator_version,
            "implementation_sha256": self.implementation_sha256,
            "formalization_id": self.formalization_id,
            "input_bundle_sha256": self.input_bundle_sha256,
            "output_artifact_sha256": self.output_artifact_sha256, "result": self.result,
            "limitations": sorted(self.limitations), "evidence_refs": sorted(self.evidence_refs),
            "replicated_at_version": self.replicated_at_version,
        }


@dataclass
class ExternalTheoremAnchorRecord:
    anchor_id: str
    subject_id: str
    citation_key: str
    title: str
    authors: list[str]
    year: int
    doi: str
    imported_statement: str
    ns_gsm_use: str
    scope: str
    source_refs: list[str] = field(default_factory=list)
    status: str = "PENDING"
    limitations: list[str] = field(default_factory=list)
    anchored_at_version: str = "v0.6"

    def to_dict(self) -> dict[str, Any]:
        return {
            "anchor_id": self.anchor_id, "subject_id": self.subject_id,
            "citation_key": self.citation_key, "title": self.title,
            "authors": list(self.authors), "year": self.year, "doi": self.doi,
            "imported_statement": self.imported_statement, "ns_gsm_use": self.ns_gsm_use,
            "scope": self.scope, "source_refs": sorted(self.source_refs), "status": self.status,
            "limitations": sorted(self.limitations), "anchored_at_version": self.anchored_at_version,
        }


@dataclass
class AuthorityTierReceipt:
    tier_receipt_id: str
    subject_id: str
    tier_type: str
    source_record_id: str
    certificate_id: str
    event_ids: list[str] = field(default_factory=list)
    state_hash_before: str = ""
    state_hash_after: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "tier_receipt_id": self.tier_receipt_id, "subject_id": self.subject_id,
            "tier_type": self.tier_type, "source_record_id": self.source_record_id,
            "certificate_id": self.certificate_id, "event_ids": list(self.event_ids),
            "state_hash_before": self.state_hash_before, "state_hash_after": self.state_hash_after,
        }


@dataclass
class CertificateRecord:
    certificate_id: str
    certificate_type: str
    subject_ids: list[str]
    status: str
    scope: str | None = None
    evidence_refs: list[str] = field(default_factory=list)
    verifier_results: list[dict[str, Any]] = field(default_factory=list)
    version: str = "v0.1"

    def to_dict(self) -> dict[str, Any]:
        return {
            "certificate_id": self.certificate_id,
            "certificate_type": self.certificate_type,
            "subject_ids": sorted(self.subject_ids),
            "status": self.status,
            "scope": self.scope,
            "evidence_refs": sorted(self.evidence_refs),
            "verifier_results": self.verifier_results,
            "version": self.version,
        }


@dataclass
class DebtRecord:
    debt_id: str
    debt_type: str
    subject_id: str
    status: str = "OPEN"
    cause: str | None = None
    discharge_requirements: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    version: str = "v0.1"

    def to_dict(self) -> dict[str, Any]:
        return {
            "debt_id": self.debt_id,
            "debt_type": self.debt_type,
            "subject_id": self.subject_id,
            "status": self.status,
            "cause": self.cause,
            "discharge_requirements": sorted(self.discharge_requirements),
            "dependencies": sorted(self.dependencies),
            "version": self.version,
        }


@dataclass
class EdgeRecord:
    edge_id: str
    edge_type: str
    source_ids: list[str]
    target_ids: list[str]
    version: str = "v0.1"
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "edge_id": self.edge_id,
            "edge_type": self.edge_type,
            "source_ids": sorted(self.source_ids),
            "target_ids": sorted(self.target_ids),
            "version": self.version,
            "metadata": self.metadata,
        }


@dataclass
class NativeState:
    objects: dict[str, ObjectRecord] = field(default_factory=dict)
    candidates: dict[str, CandidateRecord] = field(default_factory=dict)
    reviews: dict[str, ReviewRecord] = field(default_factory=dict)
    promotion_receipts: dict[str, PromotionReceipt] = field(default_factory=dict)
    authority_audits: dict[str, AuthorityAuditRecord] = field(default_factory=dict)
    independent_verifications: dict[str, IndependentVerificationRecord] = field(default_factory=dict)
    authority_upgrade_receipts: dict[str, AuthorityUpgradeReceipt] = field(default_factory=dict)
    formalizations: dict[str, FormalizationRecord] = field(default_factory=dict)
    replications: dict[str, ReplicationRecord] = field(default_factory=dict)
    external_theorem_anchors: dict[str, ExternalTheoremAnchorRecord] = field(default_factory=dict)
    authority_tier_receipts: dict[str, AuthorityTierReceipt] = field(default_factory=dict)
    certificates: dict[str, CertificateRecord] = field(default_factory=dict)
    debts: dict[str, DebtRecord] = field(default_factory=dict)
    edges: dict[str, EdgeRecord] = field(default_factory=dict)
    status_history: list[dict[str, Any]] = field(default_factory=list)
    frontier_ids: list[str] = field(default_factory=list)
    ingestion_checkpoints: dict[str, dict[str, Any]] = field(default_factory=dict)
    policy_version: str = "v0.1"
    version: str = "v0.1"
    ledger_head: int = 0
    scope: str = "observed-relative"

    def to_dict(self) -> dict[str, Any]:
        return {
            "objects": {k: v.to_dict() for k, v in sorted(self.objects.items())},
            "candidates": {k: v.to_dict() for k, v in sorted(self.candidates.items())},
            "reviews": {k: v.to_dict() for k, v in sorted(self.reviews.items())},
            "promotion_receipts": {k: v.to_dict() for k, v in sorted(self.promotion_receipts.items())},
            "authority_audits": {k: v.to_dict() for k, v in sorted(self.authority_audits.items())},
            "independent_verifications": {k: v.to_dict() for k, v in sorted(self.independent_verifications.items())},
            "authority_upgrade_receipts": {k: v.to_dict() for k, v in sorted(self.authority_upgrade_receipts.items())},
            "formalizations": {k: v.to_dict() for k, v in sorted(self.formalizations.items())},
            "replications": {k: v.to_dict() for k, v in sorted(self.replications.items())},
            "external_theorem_anchors": {k: v.to_dict() for k, v in sorted(self.external_theorem_anchors.items())},
            "authority_tier_receipts": {k: v.to_dict() for k, v in sorted(self.authority_tier_receipts.items())},
            "certificates": {k: v.to_dict() for k, v in sorted(self.certificates.items())},
            "debts": {k: v.to_dict() for k, v in sorted(self.debts.items())},
            "edges": {k: v.to_dict() for k, v in sorted(self.edges.items())},
            "status_history": self.status_history,
            "frontier_ids": sorted(self.frontier_ids),
            "ingestion_checkpoints": {k: v for k, v in sorted(self.ingestion_checkpoints.items())},
            "policy_version": self.policy_version,
            "version": self.version,
            "ledger_head": self.ledger_head,
            "scope": self.scope,
        }



def native_state_from_dict(data: dict[str, Any]) -> NativeState:
    state = NativeState(
        policy_version=data.get("policy_version", "v0.1"),
        version=data.get("version", "v0.1"),
        ledger_head=int(data.get("ledger_head", 0)),
        scope=data.get("scope", "observed-relative"),
    )
    for object_id, record in (data.get("objects") or {}).items():
        state.objects[object_id] = ObjectRecord(
            object_id=record["object_id"],
            object_type=record["object_type"],
            domain_id=record["domain_id"],
            version=record["version"],
            status=ClosureStatus(record["status"]),
            role_tags=list(record.get("role_tags") or []),
            source_refs=list(record.get("source_refs") or []),
            certificate_refs=list(record.get("certificate_refs") or []),
            debt_refs=list(record.get("debt_refs") or []),
            authority=Authority(record.get("authority", "NONE")),
            metadata=dict(record.get("metadata") or {}),
        )
    for candidate_id, record in (data.get("candidates") or {}).items():
        state.candidates[candidate_id] = CandidateRecord(
            candidate_id=record["candidate_id"],
            source_ref=record["source_ref"],
            candidate_type=record["candidate_type"],
            proposed_object=dict(record.get("proposed_object") or {}),
            parser_version=record.get("parser_version", "v0.1"),
            confidence=record.get("confidence"),
            validation_state=record.get("validation_state", "UNVERIFIED"),
        )
    for review_id, record in (data.get("reviews") or {}).items():
        state.reviews[review_id] = ReviewRecord(
            review_id=record["review_id"],
            candidate_id=record["candidate_id"],
            decision=record["decision"],
            reviewer_type=record["reviewer_type"],
            reason=record.get("reason", ""),
            scope=record.get("scope"),
            evidence_refs=list(record.get("evidence_refs") or []),
            certificate_refs=list(record.get("certificate_refs") or []),
            target_native_id=record.get("target_native_id"),
            review_version=record.get("review_version", "v0.3"),
            status=record.get("status", "PENDING"),
        )
    for promotion_id, record in (data.get("promotion_receipts") or {}).items():
        state.promotion_receipts[promotion_id] = PromotionReceipt(
            promotion_id=record["promotion_id"],
            review_id=record["review_id"],
            candidate_id=record["candidate_id"],
            native_object_id=record["native_object_id"],
            promotion_class=record["promotion_class"],
            certificate_refs=list(record.get("certificate_refs") or []),
            debt_refs=list(record.get("debt_refs") or []),
            event_ids=list(record.get("event_ids") or []),
            state_hash_before=record.get("state_hash_before", ""),
            state_hash_after=record.get("state_hash_after", ""),
        )
    for audit_id, record in (data.get("authority_audits") or {}).items():
        state.authority_audits[audit_id] = AuthorityAuditRecord(
            audit_id=record["audit_id"],
            subject_id=record["subject_id"],
            subject_kind=record["subject_kind"],
            source_ref=record["source_ref"],
            source_sha256=record["source_sha256"],
            statement=record["statement"],
            scope=record.get("scope", ""),
            assumptions=list(record.get("assumptions") or []),
            certificate_refs=list(record.get("certificate_refs") or []),
            nonclaim_refs=list(record.get("nonclaim_refs") or []),
            verdict=record.get("verdict", "DEFER_OPEN_OBLIGATION"),
            authority_cap=record.get("authority_cap", "AUDIT"),
            reason=record.get("reason", ""),
            reviewer_type=record.get("reviewer_type", "CURATED_V0_4"),
            audit_version=record.get("audit_version", "v0.4"),
            status=record.get("status", "PENDING"),
        )
    for verification_id, record in (data.get("independent_verifications") or {}).items():
        state.independent_verifications[verification_id] = IndependentVerificationRecord(
            verification_id=record["verification_id"], subject_id=record["subject_id"],
            verifier_id=record["verifier_id"], verifier_kind=record["verifier_kind"],
            verifier_version=record["verifier_version"], statement=record["statement"],
            scope=record["scope"], input_sha256=record["input_sha256"],
            proof_artifact_sha256=record["proof_artifact_sha256"], result=record["result"],
            limitations=list(record.get("limitations") or []), evidence_refs=list(record.get("evidence_refs") or []),
            verified_at_version=record.get("verified_at_version", "v0.5"),
        )
    for upgrade_id, record in (data.get("authority_upgrade_receipts") or {}).items():
        state.authority_upgrade_receipts[upgrade_id] = AuthorityUpgradeReceipt(
            upgrade_id=record["upgrade_id"], verification_id=record["verification_id"],
            subject_id=record["subject_id"], old_authority=record["old_authority"],
            new_authority=record["new_authority"], certificate_id=record["certificate_id"],
            event_ids=list(record.get("event_ids") or []), state_hash_before=record.get("state_hash_before", ""),
            state_hash_after=record.get("state_hash_after", ""),
        )
    for formalization_id, record in (data.get("formalizations") or {}).items():
        state.formalizations[formalization_id] = FormalizationRecord(
            formalization_id=record["formalization_id"], subject_id=record["subject_id"],
            language=record["language"], formalization_kind=record["formalization_kind"],
            status=record["status"], statement=record["statement"], scope=record["scope"],
            assumptions=list(record.get("assumptions") or []), goals=list(record.get("goals") or []),
            dependencies=list(record.get("dependencies") or []), bundle_sha256=record.get("bundle_sha256", ""),
            limitations=list(record.get("limitations") or []), evidence_refs=list(record.get("evidence_refs") or []),
            formalized_at_version=record.get("formalized_at_version", "v0.6"),
        )
    for replication_id, record in (data.get("replications") or {}).items():
        state.replications[replication_id] = ReplicationRecord(
            replication_id=record["replication_id"], subject_id=record["subject_id"],
            replicator_id=record["replicator_id"], replicator_kind=record["replicator_kind"],
            replicator_version=record["replicator_version"], implementation_sha256=record["implementation_sha256"],
            formalization_id=record["formalization_id"], input_bundle_sha256=record["input_bundle_sha256"],
            output_artifact_sha256=record["output_artifact_sha256"], result=record["result"],
            limitations=list(record.get("limitations") or []), evidence_refs=list(record.get("evidence_refs") or []),
            replicated_at_version=record.get("replicated_at_version", "v0.6"),
        )
    for anchor_id, record in (data.get("external_theorem_anchors") or {}).items():
        state.external_theorem_anchors[anchor_id] = ExternalTheoremAnchorRecord(
            anchor_id=record["anchor_id"], subject_id=record["subject_id"], citation_key=record["citation_key"],
            title=record["title"], authors=list(record.get("authors") or []), year=int(record["year"]), doi=record["doi"],
            imported_statement=record["imported_statement"], ns_gsm_use=record["ns_gsm_use"], scope=record["scope"],
            source_refs=list(record.get("source_refs") or []), status=record.get("status", "PENDING"),
            limitations=list(record.get("limitations") or []), anchored_at_version=record.get("anchored_at_version", "v0.6"),
        )
    for tier_id, record in (data.get("authority_tier_receipts") or {}).items():
        state.authority_tier_receipts[tier_id] = AuthorityTierReceipt(
            tier_receipt_id=record["tier_receipt_id"], subject_id=record["subject_id"], tier_type=record["tier_type"],
            source_record_id=record["source_record_id"], certificate_id=record["certificate_id"],
            event_ids=list(record.get("event_ids") or []), state_hash_before=record.get("state_hash_before", ""),
            state_hash_after=record.get("state_hash_after", ""),
        )
    for cert_id, record in (data.get("certificates") or {}).items():
        state.certificates[cert_id] = CertificateRecord(
            certificate_id=record["certificate_id"],
            certificate_type=record["certificate_type"],
            subject_ids=list(record.get("subject_ids") or []),
            status=record["status"],
            scope=record.get("scope"),
            evidence_refs=list(record.get("evidence_refs") or []),
            verifier_results=list(record.get("verifier_results") or []),
            version=record.get("version", "v0.1"),
        )
    for debt_id, record in (data.get("debts") or {}).items():
        state.debts[debt_id] = DebtRecord(
            debt_id=record["debt_id"],
            debt_type=record["debt_type"],
            subject_id=record["subject_id"],
            status=record.get("status", "OPEN"),
            cause=record.get("cause"),
            discharge_requirements=list(record.get("discharge_requirements") or []),
            dependencies=list(record.get("dependencies") or []),
            version=record.get("version", "v0.1"),
        )
    for edge_id, record in (data.get("edges") or {}).items():
        state.edges[edge_id] = EdgeRecord(
            edge_id=record["edge_id"],
            edge_type=record["edge_type"],
            source_ids=list(record.get("source_ids") or []),
            target_ids=list(record.get("target_ids") or []),
            version=record.get("version", "v0.1"),
            metadata=dict(record.get("metadata") or {}),
        )
    state.status_history = list(data.get("status_history") or [])
    state.frontier_ids = list(data.get("frontier_ids") or [])
    state.ingestion_checkpoints = dict(data.get("ingestion_checkpoints") or {})
    return state
