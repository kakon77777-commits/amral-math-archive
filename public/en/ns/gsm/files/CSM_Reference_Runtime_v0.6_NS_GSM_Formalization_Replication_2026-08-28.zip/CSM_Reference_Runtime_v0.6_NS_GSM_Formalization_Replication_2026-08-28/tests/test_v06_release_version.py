from pathlib import Path
import tomllib

import csm_runtime


def test_v06_runtime_and_project_versions_match():
    root = Path(__file__).resolve().parents[1]
    data = tomllib.loads((root / 'pyproject.toml').read_text(encoding='utf-8'))
    assert csm_runtime.__version__ == '0.6.0'
    assert data['project']['version'] == '0.6.0'
