from pathlib import Path

from csm_runtime.cli import build_parser
from csm_runtime.formalization_run import run_v06_formalization_replication
from csm_runtime.query import QueryEngine
from csm_runtime.v06_evidence import write_v06_evidence

ROOT=Path(__file__).resolve().parents[1]


def test_v06_query_and_cli_surface(tmp_path):
    run=run_v06_formalization_replication(ROOT,tmp_path/'run')
    q=QueryEngine(run.state)
    assert len(q.formalizations().answer)==12
    assert len(q.replications().answer)==12
    assert len(q.external_theorem_anchors().answer)==1
    assert len(q.replicated_assets().answer)==12
    assert q.formal_proof_assets().answer==[]
    tiers=q.authority_tiers().answer
    assert sum('CROSS_IMPLEMENTATION_REPLICATED' in x['tiers'] for x in tiers)==12
    parser=build_parser()
    args=parser.parse_args(['run-formalization-replication','--root',str(ROOT),'--evidence',str(tmp_path/'cli')])
    assert args.command=='run-formalization-replication'


def test_v06_evidence_writer_freezes_tier_counts_and_replay(tmp_path):
    run=run_v06_formalization_replication(ROOT,tmp_path/'run')
    summary=write_v06_evidence(run,tmp_path/'evidence')
    assert summary['formalization_count']==12
    assert summary['replication_count']==12
    assert summary['replication_match_count']==12
    assert summary['formal_proof_count']==0
    assert summary['external_anchor_count']==1
    assert summary['root_status']=='OPEN'
    assert summary['replay_match'] is True
    for name in [
        'formalizations_v06.json','replications_v06.json','external_anchors_v06.json',
        'authority_tiers_v06.json','formal_proof_assets_v06.json','replicated_assets_v06.json',
        'native_snapshot_v06.json','ns_gsm_v06_ledger.jsonl','replay_report_v06.json',
        'conformance_report_v06.json','run_summary_v06.json',
    ]:
        assert (tmp_path/'evidence'/name).exists()
