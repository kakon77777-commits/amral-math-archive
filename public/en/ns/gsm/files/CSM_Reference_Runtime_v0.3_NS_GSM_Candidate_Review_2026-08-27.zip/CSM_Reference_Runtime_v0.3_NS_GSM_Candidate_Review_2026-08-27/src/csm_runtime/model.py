from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .enums import Authority, ClosureStatus


@dataclass
class ObjectRecord:
    object_id: str
    object_type: str
    domain_id: str
    version: str
    status: ClosureStatus = ClosureStatus.UNVERIFIED
    role_tags: list[str] = field(default_factory=list)
    source_refs: list[str] = field(default_factory=list)
    certificate_refs: list[str] = field(default_factory=list)
    debt_refs: list[str] = field(default_factory=list)
    authority: Authority = Authority.NONE
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "object_id": self.object_id,
            "object_type": self.object_type,
            "domain_id": self.domain_id,
            "version": self.version,
            "status": self.status.value,
            "role_tags": sorted(self.role_tags),
            "source_refs": sorted(self.source_refs),
            "certificate_refs": sorted(self.certificate_refs),
            "debt_refs": sorted(self.debt_refs),
            "authority": self.authority.value,
            "metadata": self.metadata,
        }


@dataclass
class CandidateRecord:
    candidate_id: str
    source_ref: str
    candidate_type: str
    proposed_object: dict[str, Any]
    parser_version: str
    confidence: float | None = None
    validation_state: str = "UNVERIFIED"

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "source_ref": self.source_ref,
            "candidate_type": self.candidate_type,
            "proposed_object": self.proposed_object,
            "parser_version": self.parser_version,
            "confidence": self.confidence,
            "validation_state": self.validation_state,
        }


@dataclass
class ReviewRecord:
    review_id: str
    candidate_id: str
    decision: str
    reviewer_type: str
    reason: str
    scope: str | None = None
    evidence_refs: list[str] = field(default_factory=list)
    certificate_refs: list[str] = field(default_factory=list)
    target_native_id: str | None = None
    review_version: str = "v0.3"
    status: str = "PENDING"

    def to_dict(self) -> dict[str, Any]:
        return {
            "review_id": self.review_id,
            "candidate_id": self.candidate_id,
            "decision": self.decision,
            "reviewer_type": self.reviewer_type,
            "reason": self.reason,
            "scope": self.scope,
            "evidence_refs": sorted(self.evidence_refs),
            "certificate_refs": sorted(self.certificate_refs),
            "target_native_id": self.target_native_id,
            "review_version": self.review_version,
            "status": self.status,
        }


@dataclass
class PromotionReceipt:
    promotion_id: str
    review_id: str
    candidate_id: str
    native_object_id: str
    promotion_class: str
    certificate_refs: list[str] = field(default_factory=list)
    debt_refs: list[str] = field(default_factory=list)
    event_ids: list[str] = field(default_factory=list)
    state_hash_before: str = ""
    state_hash_after: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "promotion_id": self.promotion_id,
            "review_id": self.review_id,
            "candidate_id": self.candidate_id,
            "native_object_id": self.native_object_id,
            "promotion_class": self.promotion_class,
            "certificate_refs": sorted(self.certificate_refs),
            "debt_refs": sorted(self.debt_refs),
            "event_ids": list(self.event_ids),
            "state_hash_before": self.state_hash_before,
            "state_hash_after": self.state_hash_after,
        }


@dataclass
class CertificateRecord:
    certificate_id: str
    certificate_type: str
    subject_ids: list[str]
    status: str
    scope: str | None = None
    evidence_refs: list[str] = field(default_factory=list)
    verifier_results: list[dict[str, Any]] = field(default_factory=list)
    version: str = "v0.1"

    def to_dict(self) -> dict[str, Any]:
        return {
            "certificate_id": self.certificate_id,
            "certificate_type": self.certificate_type,
            "subject_ids": sorted(self.subject_ids),
            "status": self.status,
            "scope": self.scope,
            "evidence_refs": sorted(self.evidence_refs),
            "verifier_results": self.verifier_results,
            "version": self.version,
        }


@dataclass
class DebtRecord:
    debt_id: str
    debt_type: str
    subject_id: str
    status: str = "OPEN"
    cause: str | None = None
    discharge_requirements: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    version: str = "v0.1"

    def to_dict(self) -> dict[str, Any]:
        return {
            "debt_id": self.debt_id,
            "debt_type": self.debt_type,
            "subject_id": self.subject_id,
            "status": self.status,
            "cause": self.cause,
            "discharge_requirements": sorted(self.discharge_requirements),
            "dependencies": sorted(self.dependencies),
            "version": self.version,
        }


@dataclass
class EdgeRecord:
    edge_id: str
    edge_type: str
    source_ids: list[str]
    target_ids: list[str]
    version: str = "v0.1"
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "edge_id": self.edge_id,
            "edge_type": self.edge_type,
            "source_ids": sorted(self.source_ids),
            "target_ids": sorted(self.target_ids),
            "version": self.version,
            "metadata": self.metadata,
        }


@dataclass
class NativeState:
    objects: dict[str, ObjectRecord] = field(default_factory=dict)
    candidates: dict[str, CandidateRecord] = field(default_factory=dict)
    reviews: dict[str, ReviewRecord] = field(default_factory=dict)
    promotion_receipts: dict[str, PromotionReceipt] = field(default_factory=dict)
    certificates: dict[str, CertificateRecord] = field(default_factory=dict)
    debts: dict[str, DebtRecord] = field(default_factory=dict)
    edges: dict[str, EdgeRecord] = field(default_factory=dict)
    status_history: list[dict[str, Any]] = field(default_factory=list)
    frontier_ids: list[str] = field(default_factory=list)
    ingestion_checkpoints: dict[str, dict[str, Any]] = field(default_factory=dict)
    policy_version: str = "v0.1"
    version: str = "v0.1"
    ledger_head: int = 0
    scope: str = "observed-relative"

    def to_dict(self) -> dict[str, Any]:
        return {
            "objects": {k: v.to_dict() for k, v in sorted(self.objects.items())},
            "candidates": {k: v.to_dict() for k, v in sorted(self.candidates.items())},
            "reviews": {k: v.to_dict() for k, v in sorted(self.reviews.items())},
            "promotion_receipts": {k: v.to_dict() for k, v in sorted(self.promotion_receipts.items())},
            "certificates": {k: v.to_dict() for k, v in sorted(self.certificates.items())},
            "debts": {k: v.to_dict() for k, v in sorted(self.debts.items())},
            "edges": {k: v.to_dict() for k, v in sorted(self.edges.items())},
            "status_history": self.status_history,
            "frontier_ids": sorted(self.frontier_ids),
            "ingestion_checkpoints": {k: v for k, v in sorted(self.ingestion_checkpoints.items())},
            "policy_version": self.policy_version,
            "version": self.version,
            "ledger_head": self.ledger_head,
            "scope": self.scope,
        }



def native_state_from_dict(data: dict[str, Any]) -> NativeState:
    state = NativeState(
        policy_version=data.get("policy_version", "v0.1"),
        version=data.get("version", "v0.1"),
        ledger_head=int(data.get("ledger_head", 0)),
        scope=data.get("scope", "observed-relative"),
    )
    for object_id, record in (data.get("objects") or {}).items():
        state.objects[object_id] = ObjectRecord(
            object_id=record["object_id"],
            object_type=record["object_type"],
            domain_id=record["domain_id"],
            version=record["version"],
            status=ClosureStatus(record["status"]),
            role_tags=list(record.get("role_tags") or []),
            source_refs=list(record.get("source_refs") or []),
            certificate_refs=list(record.get("certificate_refs") or []),
            debt_refs=list(record.get("debt_refs") or []),
            authority=Authority(record.get("authority", "NONE")),
            metadata=dict(record.get("metadata") or {}),
        )
    for candidate_id, record in (data.get("candidates") or {}).items():
        state.candidates[candidate_id] = CandidateRecord(
            candidate_id=record["candidate_id"],
            source_ref=record["source_ref"],
            candidate_type=record["candidate_type"],
            proposed_object=dict(record.get("proposed_object") or {}),
            parser_version=record.get("parser_version", "v0.1"),
            confidence=record.get("confidence"),
            validation_state=record.get("validation_state", "UNVERIFIED"),
        )
    for review_id, record in (data.get("reviews") or {}).items():
        state.reviews[review_id] = ReviewRecord(
            review_id=record["review_id"],
            candidate_id=record["candidate_id"],
            decision=record["decision"],
            reviewer_type=record["reviewer_type"],
            reason=record.get("reason", ""),
            scope=record.get("scope"),
            evidence_refs=list(record.get("evidence_refs") or []),
            certificate_refs=list(record.get("certificate_refs") or []),
            target_native_id=record.get("target_native_id"),
            review_version=record.get("review_version", "v0.3"),
            status=record.get("status", "PENDING"),
        )
    for promotion_id, record in (data.get("promotion_receipts") or {}).items():
        state.promotion_receipts[promotion_id] = PromotionReceipt(
            promotion_id=record["promotion_id"],
            review_id=record["review_id"],
            candidate_id=record["candidate_id"],
            native_object_id=record["native_object_id"],
            promotion_class=record["promotion_class"],
            certificate_refs=list(record.get("certificate_refs") or []),
            debt_refs=list(record.get("debt_refs") or []),
            event_ids=list(record.get("event_ids") or []),
            state_hash_before=record.get("state_hash_before", ""),
            state_hash_after=record.get("state_hash_after", ""),
        )
    for cert_id, record in (data.get("certificates") or {}).items():
        state.certificates[cert_id] = CertificateRecord(
            certificate_id=record["certificate_id"],
            certificate_type=record["certificate_type"],
            subject_ids=list(record.get("subject_ids") or []),
            status=record["status"],
            scope=record.get("scope"),
            evidence_refs=list(record.get("evidence_refs") or []),
            verifier_results=list(record.get("verifier_results") or []),
            version=record.get("version", "v0.1"),
        )
    for debt_id, record in (data.get("debts") or {}).items():
        state.debts[debt_id] = DebtRecord(
            debt_id=record["debt_id"],
            debt_type=record["debt_type"],
            subject_id=record["subject_id"],
            status=record.get("status", "OPEN"),
            cause=record.get("cause"),
            discharge_requirements=list(record.get("discharge_requirements") or []),
            dependencies=list(record.get("dependencies") or []),
            version=record.get("version", "v0.1"),
        )
    for edge_id, record in (data.get("edges") or {}).items():
        state.edges[edge_id] = EdgeRecord(
            edge_id=record["edge_id"],
            edge_type=record["edge_type"],
            source_ids=list(record.get("source_ids") or []),
            target_ids=list(record.get("target_ids") or []),
            version=record.get("version", "v0.1"),
            metadata=dict(record.get("metadata") or {}),
        )
    state.status_history = list(data.get("status_history") or [])
    state.frontier_ids = list(data.get("frontier_ids") or [])
    state.ingestion_checkpoints = dict(data.get("ingestion_checkpoints") or {})
    return state
