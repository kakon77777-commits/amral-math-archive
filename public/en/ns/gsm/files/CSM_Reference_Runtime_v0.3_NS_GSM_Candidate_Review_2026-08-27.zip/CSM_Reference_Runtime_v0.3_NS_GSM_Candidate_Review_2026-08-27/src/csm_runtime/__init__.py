"""CSM Reference Runtime v0.3."""

__version__ = "0.3.0"
