import Mathlib

noncomputable section
namespace NSGSM

abbrev M3 := Matrix (Fin 3) (Fin 3) ℝ

def comm (A B : M3) : M3 := A * B - B * A

theorem NSGSM_d103_3 (s2 s3 beta : ℝ)
    (h12 : beta = -s3) (h13 : beta = -s2) :
    s2 = s3 :=
by
  exact NSGSM_PROOF_BODY_REQUIRED

#print axioms NSGSM_d103_3

end NSGSM
