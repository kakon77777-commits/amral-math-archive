import Mathlib

noncomputable section
namespace NSGSM

abbrev M3 := Matrix (Fin 3) (Fin 3) ℝ

def comm (A B : M3) : M3 := A * B - B * A

theorem NSGSM_d103_2 (si sj beta phi : ℝ)
    (hComponent : (si^2 - sj^2) * phi = beta * (si - sj) * phi) :
    (si - sj) * (si + sj - beta) * phi = 0 :=
by
  exact NSGSM_PROOF_BODY_REQUIRED

#print axioms NSGSM_d103_2

end NSGSM
