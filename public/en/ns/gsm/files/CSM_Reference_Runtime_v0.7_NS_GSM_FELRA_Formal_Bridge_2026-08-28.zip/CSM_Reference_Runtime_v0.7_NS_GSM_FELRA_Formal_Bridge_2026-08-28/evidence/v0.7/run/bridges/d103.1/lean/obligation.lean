import Mathlib

noncomputable section
namespace NSGSM

abbrev M3 := Matrix (Fin 3) (Fin 3) ℝ

def comm (A B : M3) : M3 := A * B - B * A

theorem NSGSM_d103_1 (S Phi : M3) (beta r : ℝ)
    (hEigen : S * Phi + Phi * S + (2*r) • S = beta • Phi) :
    comm (S*S) Phi = beta • comm S Phi :=
by
  exact NSGSM_PROOF_BODY_REQUIRED

#print axioms NSGSM_d103_1

end NSGSM
