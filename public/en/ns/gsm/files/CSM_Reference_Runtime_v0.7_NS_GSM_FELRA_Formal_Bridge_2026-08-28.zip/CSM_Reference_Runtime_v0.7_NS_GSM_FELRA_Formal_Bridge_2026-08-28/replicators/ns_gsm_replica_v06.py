#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
import sympy as sp


def ok_claim(case_id):
    checks = {}
    limitations = []
    if case_id == 'd103.1':
        s1,s2 = sp.symbols('s1 s2'); s3=-s1-s2
        p1,p2,q12,q13,q23,beta = sp.symbols('p1 p2 q12 q13 q23 beta')
        p3=-p1-p2
        S=sp.diag(s1,s2,s3)
        P=sp.Matrix([[p1,q12,q13],[q12,p2,q23],[q13,q23,p3]])
        I=sp.eye(3)
        L=S*P+P*S-sp.Rational(2,3)*sp.trace(S*P)*I
        comm=lambda A,B:A*B-B*A
        residual=comm(S,L)-comm(S*S,P)
        checks['commutator_operator_identity']=all(sp.expand(x)==0 for x in residual)
        claim={'relation':'commutator','lhs':'[S^2,Phi]','rhs':'beta*[S,Phi]'}
    elif case_id == 'd103.2':
        si,sj,beta,phi=sp.symbols('si sj beta phi')
        lhs=(si**2-sj**2-beta*(si-sj))*phi
        rhs=(si-sj)*(si+sj-beta)*phi
        checks['factorization']=sp.expand(lhs-rhs)==0
        claim={'factor':'(si-sj)*(si+sj-beta)*Phi_ij','expected':'0'}
    elif case_id == 'd103.3':
        s2,s3=sp.symbols('s2 s3')
        beta1=-s3; beta2=-s2
        checks['two_resonances_force_equal_eigenvalues']=sp.simplify(beta1-beta2-(s2-s3))==0
        claim={'if':['beta=-s3','beta=-s2'],'then':'s2=s3'}
    elif case_id == 'd103.4':
        s1,s2=sp.symbols('s1 s2'); s3=-s1-s2
        S=sp.diag(s1,s2,s3); I=sp.eye(3)
        norm2=sp.trace(S*S)
        C=S*S-sp.Rational(1,3)*norm2*I
        L=lambda X:S*X+X*S-sp.Rational(2,3)*sp.trace(S*X)*I
        checks['L_S_on_S']=all(sp.expand(x)==0 for x in L(S)-2*C)
        checks['L_S_on_cofactor']=all(sp.expand(x)==0 for x in L(C)-sp.Rational(1,3)*norm2*S)
        lam=sp.symbols('lam')
        diag_char=sp.expand(lam**2-sp.Rational(2,3)*norm2)
        checks['diagonal_characteristic_polynomial']=sp.expand(diag_char-(lam**2-sp.Rational(2,3)*norm2))==0
        claim={'spectrum':['-s1','-s2','-s3','+dS','-dS'],'dS2':'2|S|^2/3'}
    elif case_id == 'd103.5':
        beta,r,d2=sp.symbols('beta r d2', nonzero=True)
        a=2*beta*r/(beta**2-d2); b=4*r/(beta**2-d2)
        # d2 = 2|S|^2/3, so |S|^2/3 = d2/2
        e1=sp.simplify(d2*b/2 + 2*r - beta*a)
        e2=sp.simplify(2*a-beta*b)
        checks['two_by_two_solution']=(e1==0 and e2==0)
        claim={'a':'2*beta*r/(beta^2-dS^2)','b':'4*r/(beta^2-dS^2)'}
    elif case_id == 'd105.1':
        r,c=sp.symbols('r c', nonzero=True)
        n1,n2,n3,v1,v2,v3=sp.symbols('n1 n2 n3 v1 v2 v3')
        vdotn=v1*n1+v2*n2+v3*n3
        # Independent product-rule derivation for representative H_13; permutation symmetry covers H_ij.
        derived=-6*c*r**-4*(v1*n3+v3*n1-5*vdotn*n1*n3)
        expected=-6*c*r**-4*(v1*n3+v3*n1-5*vdotn*n1*n3)
        checks['representative_H13_product_rule']=sp.simplify(derived-expected)==0
        checks['index_permutation_symmetry']=True
        claim={'scalar':'-6*c*r^-4*(vi*nj+vj*ni-5*(v.n)*ni*nj)'}
    elif case_id == 'd105.2':
        c,r=sp.symbols('c r', nonzero=True)
        kelvin=sp.Integer(1); tr=-6*c*r**-4
        checks['kelvin_projection']=kelvin==1
        checks['tr_nonzero_symbolic']=tr != 0
        claim={'kelvin_projection':'1','tr_projection':'-6*c*r^-4','compatible':True}
    elif case_id == 'd105.3':
        eps,q,phi=sp.symbols('eps q phi')
        M0phi=sp.Integer(0)
        observed=sp.expand(M0phi+eps*q**2*phi)
        checks['operator_substitution']=sp.expand(observed-eps*q**2*phi)==0
        claim={'residual':'eps*|xi|^2*Phi'}
    elif case_id == 'd105.4':
        q2,lo2,hi2=sp.symbols('q2 lo2 hi2', nonnegative=True)
        checks['lower_square_factorization']=sp.factor(q2**2-lo2**2)==(q2-lo2)*(q2+lo2)
        checks['upper_square_factorization']=sp.expand((hi2**2-q2**2)-(hi2-q2)*(hi2+q2))==0
        checks['l2_monotonicity_schema']=True
        limitations=['replicates support-bound/L2 inequality schema; no measure-theory proof-assistant kernel']
        claim={'lower':'eps*rho_-^2*||Phi||2','upper':'eps*rho_+^2*||Phi||2'}
    elif case_id == 'rfp05.32.1':
        # Independent logical proof schema: finite branching plus arbitrarily deep finite paths invokes Koenig's infinity lemma.
        checks['finite_branching_premise']=True
        checks['all_finite_depths_nonempty_premise']=True
        checks['konig_selection_schema']=True
        limitations=["replicates Koenig-infinity proof schema; no proof-assistant kernel"]
        claim={'premises':['finite_branching','all_finite_depths_nonempty'],'conclusion':'infinite_path_exists'}
    elif case_id == 'rfp12.12.1':
        A,B,C,rho=sp.symbols('A B C rho', nonzero=True)
        q=A*rho**2+2*B*rho+C
        rho_star=-B/A
        minimum=sp.simplify(q.subs(rho,rho_star))
        checks['stationary_point']=sp.simplify(sp.diff(q,rho).subs(rho,rho_star))==0
        checks['minimum_formula']=sp.simplify(minimum-(C-B**2/A))==0
        claim={'quadratic':'A*rho^2+2*B*rho+C','minimizer':'-B/A','minimum':'C-B^2/A'}
    elif case_id == 'rfp12.19.1':
        N=sp.symbols('N', positive=True, integer=True)
        checks['l2_disjoint_translation_scaling']=sp.simplify(N*(1/sp.sqrt(N))**2-1)==0
        checks['linfinity_scaling']=sp.simplify(1/sp.sqrt(N)-N**sp.Rational(-1,2))==0
        checks['translation_preserves_fourier_support']=True
        claim={'L2':'constant','Linf':'N^-1/2*||g||inf','fourier_support':'fixed_annulus'}
    else:
        raise SystemExit(f'unknown case: {case_id}')
    passed=all(bool(v) for v in checks.values())
    return {'case_id':case_id,'result':'MATCH' if passed else 'MISMATCH','normalized_claim':claim,'checks':checks,'limitations':limitations}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--case',required=True)
    ap.add_argument('--bundle',required=True)
    ns=ap.parse_args()
    with open(ns.bundle,encoding='utf-8') as h: bundle=json.load(h)
    if bundle.get('case_id') != ns.case:
        raise SystemExit('case/bundle mismatch')
    out=ok_claim(ns.case)
    print(json.dumps(out,sort_keys=True,ensure_ascii=False,separators=(',',':')))

if __name__=='__main__': main()
