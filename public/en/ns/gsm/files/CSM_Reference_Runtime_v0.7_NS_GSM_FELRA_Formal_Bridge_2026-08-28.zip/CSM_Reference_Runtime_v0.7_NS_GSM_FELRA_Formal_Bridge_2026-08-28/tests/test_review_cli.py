import json
import os
from pathlib import Path
import subprocess
import sys

from csm_runtime.canonical import state_hash
from csm_runtime.model import CandidateRecord, NativeState, PromotionReceipt, ReviewRecord

ROOT = Path(__file__).parents[1]
ENV = dict(os.environ, PYTHONPATH=str(ROOT / "src"))


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "csm_runtime.cli", *map(str, args)],
        cwd=ROOT, env=ENV, capture_output=True, text=True,
    )


def snapshot(tmp_path):
    state = NativeState(version="v0.3")
    state.candidates["c1"] = CandidateRecord(
        "c1", "source:c1", "NonclaimCandidate",
        {"statement": "not proved", "metadata": {"series": "RFP"}}, "v0.2"
    )
    state.candidates["c2"] = CandidateRecord(
        "c2", "source:c2", "TheoremCandidate",
        {"statement": "Theorem T", "metadata": {"series": "RFP"}}, "v0.2"
    )
    state.reviews["r1"] = ReviewRecord(
        "r1", "c1", "PROMOTE_NONCLAIM", "STRUCTURAL_TIER0", "explicit nonclaim",
        scope="formal", status="APPROVED", target_native_id="nonclaim:1"
    )
    state.promotion_receipts["p1"] = PromotionReceipt(
        "p1", "r1", "c1", "nonclaim:1", "NONCLAIM",
        state_hash_before="a", state_hash_after="b"
    )
    p = tmp_path / "snap.json"
    p.write_text(json.dumps({"state_hash": state_hash(state), "state": state.to_dict()}), encoding="utf-8")
    return p


def test_cli_review_and_promotion_summaries(tmp_path):
    snap = snapshot(tmp_path)
    review = run_cli("review-summary", "--snapshot", snap)
    assert review.returncode == 0, review.stderr
    assert json.loads(review.stdout)["answer"]["review_count"] == 1

    pending = run_cli("pending-review", "--snapshot", snap)
    assert pending.returncode == 0, pending.stderr
    assert [x["candidate_id"] for x in json.loads(pending.stdout)["answer"]] == ["c2"]

    promo = run_cli("promotion-summary", "--snapshot", snap)
    assert promo.returncode == 0, promo.stderr
    assert json.loads(promo.stdout)["answer"]["promotion_count"] == 1


def test_cli_review_candidate_returns_existing_review(tmp_path):
    snap = snapshot(tmp_path)
    result = run_cli("review-candidate", "--snapshot", snap, "c1")
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    assert data["answer"][0]["decision"] == "PROMOTE_NONCLAIM"
