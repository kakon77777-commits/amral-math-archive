from csm_runtime.canonical import state_hash
from csm_runtime.ledger import LedgerEvent
from csm_runtime.model import AuthorityAuditRecord, NativeState, native_state_from_dict
from csm_runtime.replay import replay_ledger


def _audit():
    return AuthorityAuditRecord(
        audit_id="audit:test:001",
        subject_id="claim:test",
        subject_kind="NATIVE_OBJECT",
        source_ref="artifact:test.md",
        source_sha256="abc123",
        statement="bounded statement",
        scope="formal/local",
        assumptions=["A1"],
        certificate_refs=["cert:test"],
        nonclaim_refs=["nonclaim:test"],
        verdict="KEEP_EXISTING_AUDIT",
        authority_cap="AUDIT",
        reason="source-grounded bounded audit",
        reviewer_type="CURATED_V0_4",
        audit_version="v0.4",
        status="APPROVED",
    )


def test_authority_audit_round_trips_through_native_state_dict():
    state = NativeState(version="v0.4")
    audit = _audit()
    state.authority_audits[audit.audit_id] = audit

    restored = native_state_from_dict(state.to_dict())

    assert restored.authority_audits[audit.audit_id].to_dict() == audit.to_dict()
    assert state_hash(restored) == state_hash(state)


def test_register_authority_audit_event_replays_deterministically():
    audit = _audit()
    event = LedgerEvent(
        event_id="audit-event:1",
        event_type="REGISTER_AUTHORITY_AUDIT",
        payload=audit.to_dict(),
        sequence=1,
        operator_version="v0.4",
        policy_version="v0.4",
    )

    first = replay_ledger([event], policy_version="v0.4")
    second = replay_ledger([event], policy_version="v0.4")

    assert first.authority_audits[audit.audit_id].statement == "bounded statement"
    assert state_hash(first) == state_hash(second)
