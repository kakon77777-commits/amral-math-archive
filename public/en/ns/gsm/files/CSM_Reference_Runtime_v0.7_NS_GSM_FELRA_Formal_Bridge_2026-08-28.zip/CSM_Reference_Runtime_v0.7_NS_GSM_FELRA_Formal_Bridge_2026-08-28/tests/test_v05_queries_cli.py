from csm_runtime.model import IndependentVerificationRecord, NativeState
from csm_runtime.query import QueryEngine
from csm_runtime.cli import build_parser


def test_verification_query_surface_summarizes_results():
    state=NativeState(version='v0.5')
    state.independent_verifications['v1']=IndependentVerificationRecord('v1','a','s','SYMBOLIC_EXACT','v0.5','x','q','a'*64,'b'*64,'VALID')
    state.independent_verifications['v2']=IndependentVerificationRecord('v2','b','c','CORPUS_AUDIT','v0.5','y','q','c'*64,'d'*64,'VALID',['corpus only'])
    engine=QueryEngine(state)
    summary=engine.verification_summary().answer
    assert summary['verification_count']==2
    assert summary['valid_count']==2
    assert summary['upgrade_receipt_count']==0
    assert engine.verification('v1').answer['verifier_kind']=='SYMBOLIC_EXACT'
    assert len(engine.verification_deferred().answer)==1


def test_cli_exposes_independent_verification_commands():
    parser=build_parser()
    args=parser.parse_args(['run-independent-verification','--seed','s','--corpus','c','--expansion','x','--manifest','m','--evidence','e'])
    assert args.command=='run-independent-verification'
