import json
from pathlib import Path

from csm_runtime.felra_bridge_run import run_v07_felra_bridge
from csm_runtime.replay import replay_ledger
from csm_runtime.canonical import state_hash

ROOT=Path(__file__).resolve().parents[1]


def test_v07_bridge_ready_exports_five_without_fake_formal_proof(tmp_path):
    run=run_v07_felra_bridge(ROOT,tmp_path/'evidence')
    assert run.release_mode=='BRIDGE_READY'
    assert len(run.exports)==5
    assert len(run.state.translation_certificates)==5
    assert len(run.state.formal_obligations)==5
    assert len(run.state.kernel_formal_proof_receipts)==0
    assert all(t.status=='VALID' for t in run.state.translation_certificates.values())
    assert run.state.objects['claim:formal-root-regularity'].status.value=='OPEN'
    assert run.state.objects['claim:c1-chain-necessity'].status.value=='OPEN'
    assert run.state.objects['claim:c2-finite-obstruction'].status.value=='OPEN'
    assert state_hash(replay_ledger(run.ledger.events))==state_hash(run.state)
    again=run.reapply()
    assert again=='IDEMPOTENT_NOOP'


def test_verified_fixture_promotes_exactly_one_child(tmp_path):
    initial=run_v07_felra_bridge(ROOT,tmp_path/'pre')
    exp=initial.exports[0]
    theorem=exp.bridge_manifest['theorem_names'][0]
    payload={
      'kind':'formal_check','success':True,'warnings':[],
      'metrics':{
        'formal_status':'verified','expected_formal_status':'verified','expectation_met':True,
        'checker':{'backend':'lean','available':True,'version_string':'Lean 4.33.0','executable_sha256':'f'*64},
        'obligation':{'path':'/local/x.lean','sha256':exp.bridge_manifest['obligation_sha256'],'bytes':123},
        'exit_code':0,'detail':'ok','stdout_tail':f"'{theorem}' does not depend on any axioms",
        'assumptions':exp.bridge_manifest['assumptions'],'limitations':exp.bridge_manifest['limitations'],
        'theorems_audited':1,'axioms_seen':None,'derives_from':exp.bridge_manifest['derives_from'],
      }
    }
    run=run_v07_felra_bridge(ROOT,tmp_path/'post',felra_results={exp.subject_id:payload})
    assert run.release_mode=='FORMAL_PROOF_ACTIVE'
    assert len(run.state.kernel_formal_proof_receipts)==1
    promoted=[o for o in run.state.objects.values() if 'FORMAL_PROOF' in (o.metadata.get('authority_tiers') or [])]
    assert len(promoted)==1 and promoted[0].object_id==exp.subject_id
    assert run.state.objects['claim:formal-root-regularity'].status.value=='OPEN'
