import pytest

from csm_runtime.canonical import state_hash
from csm_runtime.corpus_checkpoint import commit_corpus_batch
from csm_runtime.corpus_manifest import CorpusManifest, CorpusSource
from csm_runtime.ledger import EventLedger
from csm_runtime.model import NativeState


def manifest(source_hash="h1"):
    return CorpusManifest([
        CorpusSource(
            source_id="src:one",
            file_name="NS_RFP_01_Test.md",
            series="RFP",
            series_index=1,
            source_hash=source_hash,
            source_ref="library:one",
        )
    ])


def test_unchanged_batch_is_idempotent_noop_on_second_commit():
    state = NativeState()
    ledger = EventLedger()
    first = commit_corpus_batch(state, ledger, manifest(), {"src:one": "# T\n## Theorem T1\n"})
    first_count = len(ledger.events)
    first_hash = state_hash(first.state)

    second = commit_corpus_batch(first.state, ledger, manifest(), {"src:one": "# T\n## Theorem T1\n"})
    assert second.status == "IDEMPOTENT_NOOP"
    assert len(ledger.events) == first_count
    assert state_hash(second.state) == first_hash
    assert second.checkpoint_id == first.checkpoint_id


def test_changed_source_hash_creates_new_revision_batch_without_overwriting_old_artifact():
    state = NativeState()
    ledger = EventLedger()
    first = commit_corpus_batch(state, ledger, manifest("h1"), {"src:one": "# T\n## Theorem T1\n"})
    old_artifacts = {k for k, v in first.state.objects.items() if v.object_type == "ARTIFACT"}

    second = commit_corpus_batch(first.state, ledger, manifest("h2"), {"src:one": "# T changed\n## Theorem T2\n"})
    new_artifacts = {k for k, v in second.state.objects.items() if v.object_type == "ARTIFACT"}
    assert second.status == "COMMITTED"
    assert len(new_artifacts) == len(old_artifacts) + 1
    assert old_artifacts < new_artifacts
    assert second.checkpoint_id != first.checkpoint_id


def test_failed_batch_does_not_mutate_state_or_ledger():
    state = NativeState()
    ledger = EventLedger()
    before_hash = state_hash(state)
    with pytest.raises(KeyError):
        commit_corpus_batch(state, ledger, manifest(), {})
    assert state_hash(state) == before_hash
    assert ledger.events == []
