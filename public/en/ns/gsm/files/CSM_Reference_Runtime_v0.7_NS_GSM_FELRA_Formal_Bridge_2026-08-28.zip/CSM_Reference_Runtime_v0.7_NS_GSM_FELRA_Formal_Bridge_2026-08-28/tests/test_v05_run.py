from pathlib import Path
from csm_runtime.enums import Authority
from csm_runtime.verification_run import run_v05_independent_verification
from csm_runtime.canonical import state_hash
from csm_runtime.replay import replay_ledger

ROOT=Path(__file__).resolve().parents[1]


def test_v05_real_run_upgrades_only_independently_verified_bounded_assets(tmp_path):
    run=run_v05_independent_verification(
        ROOT/'fixtures/NS_GSM_Seed_Dataset_v0.1', ROOT/'corpus', expansion_root=ROOT/'corpus_v03_expansion',
        authority_manifest=ROOT/'authority_review_manifest_v0.4.yaml', evidence_dir=tmp_path/'verifiers')
    assert run.batch.verification_count == 14
    assert run.batch.upgrade_count == 12
    assert run.batch.deferred_count == 2
    assert run.state.objects['claim:formal-root-regularity'].status.value == 'OPEN'
    assert run.state.objects['claim:c1-chain-necessity'].status.value == 'OPEN'
    assert run.state.objects['claim:c2-finite-obstruction'].status.value == 'OPEN'
    assert run.state.objects['claim:uv-escape-necessity'].authority is Authority.AUDIT
    proof_assets=[o for o in run.state.objects.values() if o.version=='v0.4' and o.object_type=='PROOF_ASSET']
    assert sum(o.authority is Authority.PROOF for o in proof_assets) == 11
    obstruction=[o for o in run.state.objects.values() if o.version=='v0.4' and o.object_type=='OBSTRUCTION' and o.metadata.get('statement')=='Theorem 19.1'][0]
    assert obstruction.authority is Authority.PROOF
    assert obstruction.status.value == 'OPEN'
    replayed=replay_ledger(run.ledger.events,policy_version=run.state.policy_version)
    assert state_hash(replayed)==state_hash(run.state)
    again=run.reapply(tmp_path/'verifiers')
    assert again.status=='IDEMPOTENT_NOOP'


def test_v05_evidence_writer_freezes_verification_and_replay(tmp_path):
    from csm_runtime.verification_run import write_v05_evidence
    run=run_v05_independent_verification(
        ROOT/'fixtures/NS_GSM_Seed_Dataset_v0.1', ROOT/'corpus', expansion_root=ROOT/'corpus_v03_expansion',
        authority_manifest=ROOT/'authority_review_manifest_v0.4.yaml', evidence_dir=tmp_path/'evidence'/'verifiers')
    summary=write_v05_evidence(run,tmp_path/'evidence')
    assert summary['verification_count']==14
    assert summary['authority_upgrade_count']==12
    assert summary['root_status']=='OPEN'
    assert summary['replay_match'] is True
    for name in ['independent_verifications_v05.json','authority_upgrades_v05.json','verified_assets_v05.json','partial_or_deferred_v05.json','verifier_manifest_v05.json','replay_report_v05.json','conformance_report_v05.json']:
        assert (tmp_path/'evidence'/name).exists()
