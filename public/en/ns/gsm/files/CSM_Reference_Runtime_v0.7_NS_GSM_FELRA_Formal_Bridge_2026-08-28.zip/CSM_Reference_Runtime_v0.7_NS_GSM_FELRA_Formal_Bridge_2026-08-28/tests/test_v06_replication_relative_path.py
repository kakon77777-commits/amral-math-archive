from pathlib import Path

from csm_runtime.formalization import formalization_bundle_sha256
from csm_runtime.model import FormalizationRecord
from csm_runtime.replication import run_replication


def test_replication_resolves_relative_script_before_temp_cwd(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    script = Path('replica.py')
    script.write_text(
        """import argparse,json\np=argparse.ArgumentParser(); p.add_argument('--case'); p.add_argument('--bundle'); a=p.parse_args()\nb=json.load(open(a.bundle,encoding='utf-8'))\nprint(json.dumps({'case_id':a.case,'result':'MATCH','normalized_claim':b['normalized_claim'],'checks':{}}))\n""",
        encoding='utf-8',
    )
    bundle = {
        'language': 'NSGSM-FIR/0.1',
        'case_id': 'test.relative',
        'subject_id': 'asset:test',
        'normalized_claim': {'x': 'x'},
        'limitations': [],
    }
    formalization = FormalizationRecord(
        formalization_id='formalization:test',
        subject_id='asset:test',
        language='NSGSM-FIR/0.1',
        formalization_kind='ALGEBRAIC_CORE',
        status='CORE_COMPLETE',
        statement='x=x',
        scope='test',
        bundle_sha256=formalization_bundle_sha256(bundle),
    )
    result = run_replication(bundle, formalization, script, tmp_path/'evidence')
    assert result.result == 'MATCH'
