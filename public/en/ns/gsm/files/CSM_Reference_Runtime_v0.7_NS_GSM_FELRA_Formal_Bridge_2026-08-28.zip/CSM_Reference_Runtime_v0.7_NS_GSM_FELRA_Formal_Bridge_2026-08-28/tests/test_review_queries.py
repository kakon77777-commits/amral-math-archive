from csm_runtime.model import CandidateRecord, NativeState, PromotionReceipt, ReviewRecord
from csm_runtime.query import QueryEngine


def make_state():
    state = NativeState(version="v0.3")
    state.candidates["c1"] = CandidateRecord(
        "c1", "source:c1", "NonclaimCandidate",
        {"statement": "not proved", "metadata": {"series": "RFP"}}, "v0.2"
    )
    state.candidates["c2"] = CandidateRecord(
        "c2", "source:c2", "TheoremCandidate",
        {"statement": "Theorem T", "metadata": {"series": "RFP"}}, "v0.2"
    )
    state.candidates["c3"] = CandidateRecord(
        "c3", "source:c3", "FrontierCandidate",
        {"statement": "STOP-D79", "metadata": {"series": "DCRP"}}, "v0.2"
    )
    state.reviews["r1"] = ReviewRecord(
        "r1", "c1", "PROMOTE_NONCLAIM", "STRUCTURAL_TIER0", "explicit nonclaim",
        scope="formal", status="APPROVED", target_native_id="nonclaim:1"
    )
    state.reviews["r2"] = ReviewRecord(
        "r2", "c2", "DEFER", "STRUCTURAL_TIER0", "needs proof review",
        scope="formal", status="DEFERRED"
    )
    state.promotion_receipts["p1"] = PromotionReceipt(
        "p1", "r1", "c1", "nonclaim:1", "NONCLAIM",
        state_hash_before="a", state_hash_after="b"
    )
    return state


def test_review_query_returns_candidate_reviews_with_review_layer_authority():
    result = QueryEngine(make_state()).review("c1")
    assert result.source_layer == "review"
    assert result.authority == "AUDIT"
    assert result.answer[0]["decision"] == "PROMOTE_NONCLAIM"


def test_review_summary_counts_decisions_and_statuses():
    result = QueryEngine(make_state()).review_summary()
    assert result.answer["review_count"] == 2
    assert result.answer["by_decision"]["DEFER"] == 1
    assert result.answer["by_status"]["APPROVED"] == 1


def test_pending_review_includes_deferred_and_unreviewed_candidates():
    result = QueryEngine(make_state()).pending_review()
    ids = [row["candidate_id"] for row in result.answer]
    assert ids == ["c2", "c3"]
    assert result.source_layer == "candidate+review"


def test_promotion_query_and_summary():
    engine = QueryEngine(make_state())
    result = engine.promotion("nonclaim:1")
    assert result.answer[0]["promotion_id"] == "p1"
    summary = engine.promotion_summary()
    assert summary.answer["promotion_count"] == 1
    assert summary.answer["by_class"]["NONCLAIM"] == 1
