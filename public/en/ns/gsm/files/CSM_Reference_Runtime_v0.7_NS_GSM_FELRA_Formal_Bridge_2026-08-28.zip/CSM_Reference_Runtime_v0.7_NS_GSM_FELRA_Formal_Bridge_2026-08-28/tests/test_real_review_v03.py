from pathlib import Path

import pytest

from csm_runtime.canonical import state_hash
from csm_runtime.cross_series_audit import exact_statement_proposals
from csm_runtime.query import QueryEngine
from csm_runtime.replay import replay_ledger
from csm_runtime.review_run import run_v03_review

ROOT = Path(__file__).parents[1]
SEED = ROOT / "fixtures" / "NS_GSM_Seed_Dataset_v0.1"
CORPUS = ROOT / "corpus"


@pytest.fixture(scope="module")
def v03_run():
    return run_v03_review(SEED, CORPUS)


def test_v03_reviews_full_v02_candidate_layer_without_closing_root(v03_run):
    run = v03_run
    state = run.state
    engine = QueryEngine(state)

    assert len(state.candidates) == 1460
    assert len(state.reviews) == 1460
    assert len(state.promotion_receipts) == 655
    assert state.objects["claim:formal-root-regularity"].status.value == "OPEN"

    review = engine.review_summary().answer
    assert review["by_decision"]["PROMOTE_FRONTIER"] == 472
    assert review["by_decision"]["PROMOTE_NONCLAIM"] == 128
    assert review["by_decision"]["PROMOTE_SURVIVOR"] == 55
    assert review["by_decision"]["DEFER"] == 805

    promo = engine.promotion_summary().answer
    assert promo["by_class"] == {"FRONTIER": 472, "NONCLAIM": 128, "SURVIVOR": 55}
    assert len(engine.pending_review().answer) == 805


def test_v03_full_ledger_replays_exactly_and_cross_series_auto_quotient_stays_zero(v03_run):
    run = v03_run
    replayed = replay_ledger(run.ledger.events, policy_version=run.state.policy_version)
    assert state_hash(replayed) == state_hash(run.state)
    proposals = exact_statement_proposals(run.state)
    assert len(proposals) == 219
    assert sum(1 for p in proposals if p.auto_quotient) == 0


def test_v03_review_batch_is_idempotent_on_second_application(v03_run):
    run = v03_run
    second = run.reapply_structural_review()
    assert second.status == "IDEMPOTENT_NOOP"
    assert second.event_count == 0
