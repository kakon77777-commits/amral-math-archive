import pytest

from csm_runtime.enums import ClosureStatus
from csm_runtime.errors import AuthorityError
from csm_runtime.model import CandidateRecord, NativeState, ObjectRecord, ReviewRecord
from csm_runtime.promotion import (
    GateOutcome,
    PromotionGate,
    promote_frontier,
    promote_nonclaim,
    promote_obstruction,
    promote_survivor,
)


def candidate(cid: str, typ: str, statement: str) -> CandidateRecord:
    return CandidateRecord(
        candidate_id=cid,
        source_ref=f"source:{cid}",
        candidate_type=typ,
        proposed_object={"statement": statement, "metadata": {"series": "DCRP"}},
        parser_version="v0.2",
    )


def review(cid: str, decision: str) -> ReviewRecord:
    return ReviewRecord(
        review_id=f"review:{cid}",
        candidate_id=cid,
        decision=decision,
        reviewer_type="STRUCTURAL_TIER0",
        reason="source-explicit structural class",
        scope="formal",
        evidence_refs=[f"source:{cid}"],
        status="APPROVED",
    )


def base_state() -> NativeState:
    state = NativeState(version="v0.3")
    state.objects["claim:root"] = ObjectRecord(
        "claim:root", "TARGET", "formal", "v0.3", status=ClosureStatus.OPEN
    )
    return state


def test_gate_allows_matching_structural_review_and_refuses_mismatch():
    state = base_state()
    c = candidate("f", "FrontierCandidate", "STOP-D79")
    good = review("f", "PROMOTE_FRONTIER")
    bad = review("f", "PROMOTE_SURVIVOR")
    assert PromotionGate().evaluate(state, c, good).outcome is GateOutcome.ALLOW_STRUCTURAL
    assert PromotionGate().evaluate(state, c, bad).outcome is GateOutcome.REFUSE


def test_promote_frontier_creates_open_frontier_without_closing_root():
    state = base_state()
    obj = promote_frontier(state, candidate("f", "FrontierCandidate", "STOP-D79"), review("f", "PROMOTE_FRONTIER"))
    assert obj.object_type == "FRONTIER"
    assert obj.status is ClosureStatus.OPEN
    assert state.objects["claim:root"].status is ClosureStatus.OPEN


def test_promote_survivor_is_open_with_survivor_role():
    state = base_state()
    obj = promote_survivor(state, candidate("s", "SurvivorCandidate", "SURVIVOR shear"), review("s", "PROMOTE_SURVIVOR"))
    assert obj.object_type == "SURVIVOR"
    assert obj.status is ClosureStatus.OPEN
    assert "SURVIVOR" in obj.role_tags


def test_promote_nonclaim_creates_authority_boundary_only():
    state = base_state()
    obj = promote_nonclaim(state, candidate("n", "NonclaimCandidate", "global NS regularity is NOT proved"), review("n", "PROMOTE_NONCLAIM"))
    assert obj.object_type == "NONCLAIM"
    assert "AUTHORITY_BOUNDARY" in obj.role_tags
    assert state.objects["claim:root"].status is ClosureStatus.OPEN


def test_promote_obstruction_does_not_refute_parent_claim():
    state = base_state()
    c = candidate("o", "ObstructionCandidate", "NO-GO for compact branch")
    r = review("o", "PROMOTE_OBSTRUCTION")
    obj = promote_obstruction(state, c, r)
    assert obj.object_type == "OBSTRUCTION"
    assert obj.status is ClosureStatus.OPEN
    assert state.objects["claim:root"].status is ClosureStatus.OPEN


def test_structural_promotion_rejects_unapproved_review():
    state = base_state()
    c = candidate("f", "FrontierCandidate", "STOP-D79")
    r = review("f", "PROMOTE_FRONTIER")
    r.status = "PENDING"
    with pytest.raises(AuthorityError):
        promote_frontier(state, c, r)
