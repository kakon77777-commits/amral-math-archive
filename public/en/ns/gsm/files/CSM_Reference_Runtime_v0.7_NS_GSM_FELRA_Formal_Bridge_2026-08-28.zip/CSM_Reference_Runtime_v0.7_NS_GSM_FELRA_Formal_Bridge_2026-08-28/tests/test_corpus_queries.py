from csm_runtime.corpus_checkpoint import commit_corpus_batch
from csm_runtime.corpus_manifest import CorpusManifest, CorpusSource
from csm_runtime.ledger import EventLedger
from csm_runtime.model import NativeState
from csm_runtime.query import QueryEngine


def make_manifest(canonicality="CANONICAL"):
    return CorpusManifest([
        CorpusSource(
            source_id="src:rfp",
            file_name="NS_RFP_Test.md",
            series="RFP",
            series_index=1,
            source_hash="h1",
            source_ref="library:rfp",
            canonicality=canonicality,
        )
    ])


def materialized():
    state = NativeState()
    ledger = EventLedger()
    result = commit_corpus_batch(
        state,
        ledger,
        make_manifest(),
        {"src:rfp": '# Test\n## Theorem T1\n## STOP-RFP99\nNext: RFP-100\n'},
    )
    return result.state, ledger, result


def test_corpus_summary_counts_artifacts_candidates_and_checkpoints():
    state, _ledger, _result = materialized()
    q = QueryEngine(state).corpus_summary()
    assert q.source_layer == "native+candidate"
    assert q.answer["artifact_count"] == 1
    assert q.answer["candidate_count"] >= 3
    assert q.answer["checkpoint_count"] == 1


def test_series_summary_and_candidates_are_authority_carrying():
    state, _ledger, _result = materialized()
    engine = QueryEngine(state)
    summary = engine.series_summary("RFP")
    assert summary.answer["artifact_count"] == 1
    assert summary.answer["candidate_count"] >= 3
    candidates = engine.candidates("RFP")
    assert candidates.authority == "RESEARCH"
    assert candidates.source_layer == "candidate"
    assert any(x["candidate_type"] == "FrontierCandidate" for x in candidates.answer)


def test_source_history_returns_artifact_and_candidates():
    state, _ledger, _result = materialized()
    result = QueryEngine(state).source_history("src:rfp")
    assert result.answer["artifacts"]
    assert result.answer["candidates"]


def test_ingestion_checkpoint_query_returns_checkpoint_payload():
    state, _ledger, checkpoint = materialized()
    result = QueryEngine(state).ingestion_checkpoint(checkpoint.checkpoint_id)
    assert result.answer["checkpoint_id"] == checkpoint.checkpoint_id
    assert result.answer["parser_version"] == "v0.2"
