from pathlib import Path

from csm_runtime.canonical import state_hash
from csm_runtime.corpus_checkpoint import commit_corpus_batch
from csm_runtime.corpus_manifest import manifest_from_directory
from csm_runtime.enums import ClosureStatus
from csm_runtime.ns_gsm_adapter import materialize_seed_state
from csm_runtime.query import QueryEngine
from csm_runtime.replay import replay_ledger

ROOT = Path(__file__).resolve().parents[1]
SEED = ROOT / "fixtures" / "NS_GSM_Seed_Dataset_v0.1"
RFP = ROOT / "corpus" / "RFP"


def test_manifest_from_directory_covers_complete_rfp_cycle_i_and_is_deterministic():
    first = manifest_from_directory(RFP, source_namespace="library-rfp-v0.2")
    second = manifest_from_directory(RFP, source_namespace="library-rfp-v0.2")
    names = [source.file_name for source in first.ordered_sources()]

    for index in range(1, 13):
        assert any(name.startswith(f"NS_RFP_{index:02d}_") for name in names), index
    assert "NS_RFP_SERIES_ROADMAP_v1.1.md" in names
    assert "NS_RFP_CYCLE_I_HANDOFF_v1.0.md" in names
    assert "NS_RFP_CYCLE_I_STANDARD_PDE_RECOMPILATION_v1.0.md" in names
    assert first.to_dict() == second.to_dict()
    assert all(source.series == "RFP" for source in first.sources)
    assert all(source.source_hash for source in first.sources)


def test_complete_rfp_ingestion_preserves_root_authority_and_replays_exactly():
    seed = materialize_seed_state(SEED)
    initial_root = seed.state.objects["claim:formal-root-regularity"]
    assert initial_root.status is ClosureStatus.OPEN

    manifest = manifest_from_directory(RFP, source_namespace="library-rfp-v0.2")
    texts = {source.source_id: Path(source.materialized_path).read_text(encoding="utf-8") for source in manifest.sources}

    first = commit_corpus_batch(seed.state, seed.ledger, manifest, texts)
    assert first.status == "COMMITTED"
    assert first.state.objects["claim:formal-root-regularity"].status is ClosureStatus.OPEN

    rfp_summary = QueryEngine(first.state).series_summary("RFP").answer
    assert rfp_summary["artifact_count"] >= 15
    assert rfp_summary["candidate_count"] > 30

    rfp_candidates = QueryEngine(first.state).candidates("RFP").answer
    assert any(
        c["candidate_type"] == "StatusCandidate"
        and "CLOSED AS A RESEARCH CYCLE" in str(c["proposed_object"].get("statement", "")).upper()
        for c in rfp_candidates
    )
    assert any(c["candidate_type"] == "NonclaimCandidate" for c in rfp_candidates)

    second = commit_corpus_batch(first.state, seed.ledger, manifest, texts)
    assert second.status == "IDEMPOTENT_NOOP"
    assert state_hash(second.state) == state_hash(first.state)

    replayed = replay_ledger(seed.ledger.events, policy_version=first.state.policy_version)
    assert state_hash(replayed) == state_hash(first.state)
    assert replayed.objects["claim:formal-root-regularity"].status is ClosureStatus.OPEN


def test_multi_series_corpus_run_reports_content_coverage_without_overclaiming():
    from csm_runtime.full_corpus import ingest_corpus_tree

    result = ingest_corpus_tree(SEED, ROOT / "corpus")
    assert result.state.objects["claim:formal-root-regularity"].status is ClosureStatus.OPEN

    by_series = {entry.series: entry for entry in result.coverage}
    assert by_series["RFP"].content_status == "COMPLETE_SERIES"
    assert by_series["MORP"].content_status == "COMPLETE_SERIES"
    assert by_series["FCBP"].content_status == "COMPLETE_SERIES"
    assert by_series["C"].content_status == "PARTIAL"
    assert by_series["X72"].content_status == "SELECTED_MILESTONES"
    assert by_series["DCRP"].content_status == "SELECTED_MILESTONES"
    assert by_series["PAM"].content_status == "COMPLETE_INDEX_ARTIFACT"

    assert len(result.checkpoints) == 7
    assert all(cp.status == "COMMITTED" for cp in result.checkpoints)
    assert state_hash(replay_ledger(result.ledger.events, policy_version=result.state.policy_version)) == state_hash(result.state)

    summaries = {series: QueryEngine(result.state).series_summary(series).answer for series in by_series}
    assert summaries["C"]["artifact_count"] >= 2
    assert summaries["RFP"]["artifact_count"] >= 15
    assert summaries["MORP"]["artifact_count"] >= 7
    assert summaries["FCBP"]["artifact_count"] >= 7
    assert summaries["X72"]["artifact_count"] >= 4
    assert summaries["DCRP"]["artifact_count"] >= 10
    assert summaries["PAM"]["artifact_count"] >= 1

    # Corpus growth must not mutate theorem authority by itself.
    assert all(c.validation_state == "UNVERIFIED" for c in result.state.candidates.values())


def test_multi_series_corpus_rerun_is_checkpoint_idempotent():
    from csm_runtime.full_corpus import ingest_corpus_tree, ingest_corpus_tree_into

    first = ingest_corpus_tree(SEED, ROOT / "corpus")
    original_hash = state_hash(first.state)
    event_count = len(first.ledger.events)
    second = ingest_corpus_tree_into(first.state, first.ledger, ROOT / "corpus")

    assert all(cp.status == "IDEMPOTENT_NOOP" for cp in second.checkpoints)
    assert len(first.ledger.events) == event_count
    assert state_hash(second.state) == original_hash


def test_full_corpus_evidence_writer_emits_replayable_authority_bounded_reports(tmp_path):
    from csm_runtime.full_corpus import ingest_corpus_tree, write_corpus_evidence

    result = ingest_corpus_tree(SEED, ROOT / "corpus")
    report = write_corpus_evidence(result, tmp_path)

    expected = {
        "corpus_inventory.json",
        "content_coverage.json",
        "candidate_summary.json",
        "series_checkpoints.json",
        "cross_series_proposals.json",
        "ns_gsm_v02_ledger.jsonl",
        "ns_gsm_v02_native_snapshot.json",
        "replay_report.json",
    }
    assert expected <= {p.name for p in tmp_path.iterdir()}
    assert report["root_status"] == "OPEN"
    assert report["scope"] == "observed-relative"
    assert report["replay_match"] is True
    assert report["content_artifact_count"] >= 46
    assert report["candidate_count"] > 100
    assert report["cross_series_auto_quotient_count"] == 0
