import json
import os
from pathlib import Path
import subprocess
import sys

from csm_runtime.canonical import state_hash
from csm_runtime.corpus_checkpoint import commit_corpus_batch
from csm_runtime.corpus_manifest import CorpusManifest, CorpusSource
from csm_runtime.ledger import EventLedger
from csm_runtime.model import NativeState

ROOT = Path(__file__).parents[1]
ENV = dict(os.environ, PYTHONPATH=str(ROOT / "src"))


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "csm_runtime.cli", *map(str, args)],
        cwd=ROOT,
        env=ENV,
        capture_output=True,
        text=True,
    )


def make_snapshot(tmp_path):
    source = CorpusSource(
        source_id="src:rfp",
        file_name="NS_RFP_Test.md",
        series="RFP",
        series_index=1,
        source_hash="h1",
        source_ref="library:rfp",
    )
    ledger = EventLedger()
    cp = commit_corpus_batch(
        NativeState(), ledger, CorpusManifest([source]),
        {"src:rfp": "# Test\n## Theorem T1\n## STOP-RFP99\nNext: RFP-100\n"},
    )
    path = tmp_path / "snapshot.json"
    path.write_text(json.dumps({"state_hash": state_hash(cp.state), "state": cp.state.to_dict()}), encoding="utf-8")
    return path, cp


def test_cli_corpus_summary_series_and_candidates(tmp_path):
    snapshot, _cp = make_snapshot(tmp_path)
    summary = run_cli("corpus-summary", "--snapshot", snapshot)
    assert summary.returncode == 0, summary.stderr
    assert json.loads(summary.stdout)["answer"]["artifact_count"] == 1

    series = run_cli("series-summary", "--snapshot", snapshot, "RFP")
    assert series.returncode == 0, series.stderr
    assert json.loads(series.stdout)["answer"]["candidate_count"] >= 3

    candidates = run_cli("candidates", "--snapshot", snapshot, "--series", "RFP")
    assert candidates.returncode == 0, candidates.stderr
    assert any(x["candidate_type"] == "FrontierCandidate" for x in json.loads(candidates.stdout)["answer"])


def test_cli_source_history_and_checkpoint(tmp_path):
    snapshot, cp = make_snapshot(tmp_path)
    history = run_cli("source-history", "--snapshot", snapshot, "src:rfp")
    assert history.returncode == 0, history.stderr
    assert json.loads(history.stdout)["answer"]["artifacts"]

    check = run_cli("ingestion-checkpoint", "--snapshot", snapshot, cp.checkpoint_id)
    assert check.returncode == 0, check.stderr
    assert json.loads(check.stdout)["answer"]["checkpoint_id"] == cp.checkpoint_id
