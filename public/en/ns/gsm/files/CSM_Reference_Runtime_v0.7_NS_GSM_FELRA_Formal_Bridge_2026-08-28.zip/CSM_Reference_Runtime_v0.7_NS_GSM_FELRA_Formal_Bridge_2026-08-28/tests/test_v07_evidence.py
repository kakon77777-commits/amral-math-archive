import json
from pathlib import Path
from csm_runtime.felra_bridge_run import run_v07_felra_bridge
from csm_runtime.v07_evidence import write_v07_evidence

ROOT=Path(__file__).resolve().parents[1]

def test_v07_evidence_bridge_ready(tmp_path):
    run=run_v07_felra_bridge(ROOT,tmp_path/'raw')
    summary=write_v07_evidence(run,tmp_path/'evidence')
    assert summary['release_mode']=='BRIDGE_READY'
    assert summary['bridge_count']==5
    assert summary['formal_proof_count']==0
    assert summary['replay_match'] is True
    assert summary['conformance_all_passed'] is True
    expected=['bridge_manifest.json','translations.json','formal_obligations.json','felra_formal_runs.json','kernel_formal_proof_receipts.json','formal_proof_assets.json','formal_proof_deferred.json','kernel_revalidation.json','replay_report.json','conformance_report.json','run_summary.json','native_snapshot.json','ns_gsm_v07_ledger.jsonl']
    for name in expected: assert (tmp_path/'evidence'/name).exists(), name
    con=json.loads((tmp_path/'evidence/conformance_report.json').read_text())
    assert con['checks']['formal_proof_count_explicit'] is True
