import json
from pathlib import Path

from csm_runtime.felra_bridge import export_felra_bridge
from csm_runtime.felra_import import import_felra_formal_result
from csm_runtime.formalization import v06_proof_assets
from csm_runtime.model import native_state_from_dict

ROOT = Path(__file__).resolve().parents[1]


def _state():
    p=json.loads((ROOT/'evidence/v0.6/native_snapshot_v06.json').read_text())
    return native_state_from_dict(p['state'])


def _export(tmp_path):
    state=_state(); asset=next(a for a in v06_proof_assets(state) if 'D103.2' in str(a.metadata.get('statement')))
    return export_felra_bridge(state, asset.object_id, tmp_path/'bridge')


def _payload(exp, *, status='verified', checker=True, audited=1, axioms=None, exit_code=0, warning=None, obligation_sha=None):
    theorem=exp.bridge_manifest['theorem_names'][0]
    if axioms is None: axioms=[]
    if audited:
        axiom_line = f"'{theorem}' does not depend on any axioms" if not axioms else f"'{theorem}' depends on axioms: [{', '.join(axioms)}]"
    else:
        axiom_line = ''
    metrics={
        'formal_status':status,
        'checker': {'backend':'lean','available':True,'version_string':'Lean 4.33.0','executable_sha256':'f'*64} if checker else {'backend':'lean'},
        'obligation': {'path':'/machine/local/path.lean','sha256': obligation_sha or exp.bridge_manifest['obligation_sha256'],'bytes':1234},
        'exit_code': exit_code,
        'duration_seconds': 2.5,
        'detail': 'Lean elaborated the obligation with no error' if status=='verified' else status,
        'stdout_tail': axiom_line,
        'assumptions': exp.bridge_manifest['assumptions'],
        'limitations': exp.bridge_manifest['limitations'],
        'theorems_audited': audited,
        'axioms_seen': axioms or None,
        'expected_formal_status':'verified',
        'expectation_met': status=='verified',
        'derives_from': exp.bridge_manifest['derives_from'],
    }
    return {'analysis_id':'formal-x','kind':'formal_check','success':status=='verified','metrics':metrics,'warnings':[warning] if warning else []}


def test_verified_felra_result_imports_to_canonical_record(tmp_path):
    exp=_export(tmp_path)
    decision=import_felra_formal_result(exp.bridge_manifest, exp.translation, _payload(exp))
    assert decision.decision == 'VALID'
    assert decision.proof_eligible is True
    rec=decision.formal_run
    assert rec.formal_status=='verified'
    assert rec.obligation_sha256==exp.bridge_manifest['obligation_sha256']
    assert rec.theorems_audited==1
    d=rec.to_dict()
    assert 'duration_seconds' not in d and 'command' not in d and '/machine/local' not in json.dumps(d)


def test_importer_fails_closed_on_unknown_unavailable_refuted_axiom_and_hash_cases(tmp_path):
    exp=_export(tmp_path)
    cases=[
        _payload(exp,status='unknown',warning='sorry'),
        _payload(exp,status='unavailable'),
        _payload(exp,status='refuted',exit_code=1),
        _payload(exp,audited=1,axioms=['Unsafe.magic']),
        _payload(exp,audited=0),
        _payload(exp,obligation_sha='0'*64),
        _payload(exp,checker=False),
    ]
    for payload in cases:
        decision=import_felra_formal_result(exp.bridge_manifest, exp.translation, payload)
        assert decision.proof_eligible is False
        assert decision.decision in {'DEFER','REFUSE'}


def test_stored_certificate_integrity_is_checked_but_not_sufficient_by_itself(tmp_path):
    exp=_export(tmp_path)
    payload=_payload(exp,status='unknown')
    cert={'kind':'external_formal','subject':'x','issuer':'lean','data':{'checker':{'backend':'lean','version_string':'Lean 4.33.0','executable_sha256':'f'*64},'obligation_sha256':exp.bridge_manifest['obligation_sha256'],'theorems_audited':1,'axioms_seen':[]}}
    import hashlib
    canonical=json.dumps({'kind':cert['kind'],'subject':cert['subject'],'data':cert['data'],'issuer':cert['issuer']},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
    cert['certificate_sha256']=hashlib.sha256(canonical).hexdigest()
    decision=import_felra_formal_result(exp.bridge_manifest, exp.translation, payload, certificate=cert)
    assert decision.certificate_integrity_valid is True
    assert decision.proof_eligible is False
