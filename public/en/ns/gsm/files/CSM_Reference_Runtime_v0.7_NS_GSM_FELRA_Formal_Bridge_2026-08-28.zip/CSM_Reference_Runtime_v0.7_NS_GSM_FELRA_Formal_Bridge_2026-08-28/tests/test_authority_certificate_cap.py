from csm_runtime.authority_audit import certificate_authority_cap
from csm_runtime.enums import Authority
from csm_runtime.model import CertificateRecord, NativeState


def test_source_internal_certificate_caps_at_audit_without_independent_verifier():
    state = NativeState(version="v0.4")
    state.certificates["cert:src"] = CertificateRecord(
        certificate_id="cert:src",
        certificate_type="SOURCE_INTERNAL_PROOF",
        subject_ids=["claim:x"],
        status="VALID_SOURCE_ASSERTION",
    )

    assert certificate_authority_cap(state, "cert:src") is Authority.AUDIT


def test_independent_valid_verifier_can_raise_certificate_cap_to_proof():
    state = NativeState(version="v0.4")
    state.certificates["cert:checked"] = CertificateRecord(
        certificate_id="cert:checked",
        certificate_type="PROOF",
        subject_ids=["claim:x"],
        status="VALID",
        verifier_results=[{"verifier_id": "independent:v1", "result": "VALID", "independent": True}],
    )

    assert certificate_authority_cap(state, "cert:checked") is Authority.PROOF


def test_non_independent_valid_result_does_not_raise_cap():
    state = NativeState(version="v0.4")
    state.certificates["cert:self"] = CertificateRecord(
        certificate_id="cert:self",
        certificate_type="PROOF",
        subject_ids=["claim:x"],
        status="VALID",
        verifier_results=[{"verifier_id": "source:self", "result": "VALID", "independent": False}],
    )

    assert certificate_authority_cap(state, "cert:self") is Authority.AUDIT
