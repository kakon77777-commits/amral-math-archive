from pathlib import Path

from csm_runtime.source_parser import parse_markdown_source

FIX = Path(__file__).parent / "fixtures" / "real_corpus_sources"


def read(name):
    return (FIX / name).read_text(encoding="utf-8")


def test_rfp_roadmap_cycle_closed_is_extracted_as_source_status_not_theorem_closure():
    parsed = parse_markdown_source(
        read("NS_RFP_SERIES_ROADMAP_v1.1.md"),
        "src:rfp-roadmap",
        "RFP",
    )
    assert parsed.metadata["status"] == "Cycle-I closed / Cycle-II frontier"
    labels = [c.statement for c in parsed.status_candidates]
    assert any("CLOSED AS A RESEARCH CYCLE" in x for x in labels)
    assert all(c.candidate_type != "NativeClosure" for c in parsed.status_candidates)


def test_morp_epistemic_status_yields_nonclaim_for_ns_regularity():
    parsed = parse_markdown_source(
        read("NS_MORP_03_Transition_Profile_RigidityEntry_v0.1.md"),
        "src:morp03",
        "MORP",
    )
    assert any("Navier-Stokes regularity" in c.statement or "Navier–Stokes regularity" in c.statement
               for c in parsed.nonclaim_candidates)


def test_x72_checkpoint_extracts_stop_frontiers_and_next_candidates():
    parsed = parse_markdown_source(
        read("NS_X72_PureContinuous_Checkpoint_v63_2026-08-18.md"),
        "src:x72v63",
        "X72",
    )
    stop_names = {c.metadata.get("stop_id") for c in parsed.frontier_candidates}
    assert "STOP-C01" in stop_names
    assert "STOP-C05" in stop_names
    assert parsed.next_candidates


def test_dcrp79_extracts_nonclaims_stop_and_next():
    parsed = parse_markdown_source(
        read("NS_DCRP79_X72R62_SecularCompactChainNoGo_NoncompactCatalogue_2026-08-18.md"),
        "src:d79",
        "DCRP",
    )
    assert any(c.metadata.get("stop_id") == "STOP-D79" for c in parsed.frontier_candidates)
    assert any("global Navier" in c.statement for c in parsed.nonclaim_candidates)
    assert any("DCRP80" in c.statement for c in parsed.next_candidates)


def test_candidate_ids_are_deterministic_for_same_source_text():
    text = read("NS_RFP_SERIES_ROADMAP_v1.1.md")
    a = parse_markdown_source(text, "src:same", "RFP")
    b = parse_markdown_source(text, "src:same", "RFP")
    assert [x.candidate_id for x in a.all_candidates()] == [x.candidate_id for x in b.all_candidates()]
