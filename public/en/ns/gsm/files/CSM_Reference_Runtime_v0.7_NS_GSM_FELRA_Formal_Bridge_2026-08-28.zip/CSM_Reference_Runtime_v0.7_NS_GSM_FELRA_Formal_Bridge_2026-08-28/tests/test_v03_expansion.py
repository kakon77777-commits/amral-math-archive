from pathlib import Path

from csm_runtime.canonical import state_hash
from csm_runtime.replay import replay_ledger
from csm_runtime.review_run import run_v03_review

ROOT = Path(__file__).parents[1]
SEED = ROOT / "fixtures" / "NS_GSM_Seed_Dataset_v0.1"
BASE = ROOT / "corpus"
EXPANSION = ROOT / "corpus_v03_expansion"


def test_v03_expansion_ingests_source_backed_c_and_dcrp_without_closing_root():
    run = run_v03_review(SEED, BASE, expansion_root=EXPANSION)
    assert run.expansion_run is not None
    expansion_count = sum(len(m.sources) for m in run.expansion_run.manifests)
    assert expansion_count == 15
    assert len(run.state.candidates) > 1460
    assert len(run.state.reviews) == len(run.state.candidates)
    assert run.state.objects["claim:formal-root-regularity"].status.value == "OPEN"
    replayed = replay_ledger(run.ledger.events, policy_version=run.state.policy_version)
    assert state_hash(replayed) == state_hash(run.state)
