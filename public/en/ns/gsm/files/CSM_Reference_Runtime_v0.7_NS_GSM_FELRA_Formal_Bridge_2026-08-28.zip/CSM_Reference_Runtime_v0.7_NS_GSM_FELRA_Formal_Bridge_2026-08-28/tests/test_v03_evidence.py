import json
from pathlib import Path

from csm_runtime.review_run import run_v03_review, write_v03_evidence

ROOT = Path(__file__).parents[1]
SEED = ROOT / "fixtures" / "NS_GSM_Seed_Dataset_v0.1"
BASE = ROOT / "corpus"
EXPANSION = ROOT / "corpus_v03_expansion"


def test_v03_evidence_writes_review_promotion_coverage_and_replay_reports(tmp_path):
    run = run_v03_review(SEED, BASE, expansion_root=EXPANSION)
    summary = write_v03_evidence(run, tmp_path)
    expected = {
        "review_summary.json",
        "promotion_summary.json",
        "pending_review.json",
        "review_ledger.jsonl",
        "promotion_receipts.json",
        "cross_series_review.json",
        "content_coverage_v03.json",
        "native_snapshot_v03.json",
        "ns_gsm_v03_ledger.jsonl",
        "replay_report_v03.json",
        "conformance_report_v03.json",
        "run_summary_v03.json",
    }
    assert expected.issubset({p.name for p in tmp_path.iterdir()})
    assert summary["version"] == "v0.3"
    assert summary["root_status"] == "OPEN"
    assert summary["replay_match"] is True
    assert summary["expansion_artifact_count"] == 15
    assert summary["content_artifact_count"] == 61
    assert summary["review_count"] == summary["candidate_count"]
    cross = json.loads((tmp_path / "cross_series_review.json").read_text())
    assert cross["auto_quotient_count"] == 0
    conf = json.loads((tmp_path / "conformance_report_v03.json").read_text())
    assert conf["all_passed"] is True
