from csm_runtime.corpus_manifest import CorpusSource, CorpusManifest, deduplicate_manifest, manifest_hash


def make(source_id: str, name: str, source_hash: str, *, series="RFP", order=1):
    return CorpusSource(
        source_id=source_id,
        file_name=name,
        series=series,
        series_index=order,
        source_hash=source_hash,
        source_ref=f"library:{source_id}",
    )


def test_manifest_hash_is_order_independent():
    a = make("s:a", "A.md", "aaa", order=1)
    b = make("s:b", "B.md", "bbb", order=2)
    m1 = CorpusManifest([b, a])
    m2 = CorpusManifest([a, b])
    assert manifest_hash(m1) == manifest_hash(m2)


def test_exact_hash_duplicate_points_to_first_canonical_source():
    a = make("s:a", "A.md", "same", order=1)
    b = make("s:b", "A(1).md", "same", order=2)
    result = deduplicate_manifest(CorpusManifest([b, a]))
    by_id = {x.source_id: x for x in result.sources}
    assert by_id["s:a"].canonicality == "CANONICAL"
    assert by_id["s:a"].duplicate_of is None
    assert by_id["s:b"].canonicality == "DUPLICATE"
    assert by_id["s:b"].duplicate_of == "s:a"


def test_manifest_serialization_uses_deterministic_source_order():
    a = make("s:a", "A.md", "aaa", order=1)
    b = make("s:b", "B.md", "bbb", order=2)
    manifest = CorpusManifest([b, a])
    assert [x["source_id"] for x in manifest.to_dict()["sources"]] == ["s:a", "s:b"]
