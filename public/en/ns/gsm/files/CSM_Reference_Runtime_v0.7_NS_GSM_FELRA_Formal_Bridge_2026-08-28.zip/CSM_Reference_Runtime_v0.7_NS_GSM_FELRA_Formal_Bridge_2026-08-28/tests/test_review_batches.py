from dataclasses import replace

import pytest

from csm_runtime.canonical import state_hash
from csm_runtime.ledger import EventLedger
from csm_runtime.model import CandidateRecord, NativeState
from csm_runtime.replay import replay_ledger
from csm_runtime.review import ReviewAction, ReviewBatch, ReviewDecision, build_structural_review_batch
from csm_runtime.review_batch import commit_review_batch


def candidate(cid, typ, statement, series="DCRP"):
    return CandidateRecord(
        candidate_id=cid,
        source_ref=f"source:{cid}",
        candidate_type=typ,
        proposed_object={"statement": statement, "metadata": {"series": series}},
        parser_version="v0.2",
    )


def test_review_batch_commits_reviews_promotions_and_receipts_atomically():
    state = NativeState(version="v0.3")
    ledger = EventLedger()
    candidates = [
        candidate("n", "NonclaimCandidate", "global NS regularity is NOT proved"),
        candidate("f", "FrontierCandidate", "STOP-D79"),
    ]
    for c in candidates:
        state.candidates[c.candidate_id] = c
    batch = build_structural_review_batch(candidates)
    result = commit_review_batch(state, ledger, batch)

    assert result.status == "COMMITTED"
    assert len(result.state.reviews) == 2
    assert len(result.state.promotion_receipts) == 2
    assert result.promotion_count == 2
    assert result.input_state_hash != result.output_state_hash
    assert all(r.state_hash_before == result.input_state_hash for r in result.state.promotion_receipts.values())
    assert all(r.state_hash_after for r in result.state.promotion_receipts.values())

    replayed = replay_ledger(ledger.events, policy_version=result.state.policy_version)
    # Candidates were pre-existing state, so replay the batch prefix on an equivalent genesis.
    genesis = NativeState(version="v0.3")
    for c in candidates:
        genesis.candidates[c.candidate_id] = c
    # Batch-only ledger cannot reconstruct pre-existing candidates; deterministic batch state is checked by rerunning from identical genesis.
    rerun_ledger = EventLedger()
    rerun = commit_review_batch(genesis, rerun_ledger, batch)
    assert state_hash(rerun.state) == state_hash(result.state)


def test_same_review_batch_is_idempotent_noop():
    state = NativeState(version="v0.3")
    ledger = EventLedger()
    c = candidate("n", "NonclaimCandidate", "not proved")
    state.candidates[c.candidate_id] = c
    batch = build_structural_review_batch([c])
    first = commit_review_batch(state, ledger, batch)
    event_count = len(ledger.events)
    second = commit_review_batch(first.state, ledger, batch)
    assert second.status == "IDEMPOTENT_NOOP"
    assert len(ledger.events) == event_count
    assert state_hash(second.state) == state_hash(first.state)


def test_invalid_review_batch_does_not_partially_mutate_state_or_ledger():
    state = NativeState(version="v0.3")
    ledger = EventLedger()
    c = candidate("f", "FrontierCandidate", "STOP-D79")
    state.candidates[c.candidate_id] = c
    original_hash = state_hash(state)
    bad = ReviewBatch(
        batch_id="review-batch:bad",
        review_policy_version="v0.3",
        candidate_ids=("f",),
        decisions=(ReviewDecision("f", ReviewAction.PROMOTE_SURVIVOR, "wrong action"),),
    )
    with pytest.raises(Exception):
        commit_review_batch(state, ledger, bad)
    assert len(ledger.events) == 0
    assert state_hash(state) == original_hash
    assert state.reviews == {}
    assert state.promotion_receipts == {}
