from csm_runtime.authority_batch import commit_authority_review_batch
from csm_runtime.canonical import state_hash
from csm_runtime.replay import replay_ledger


def test_curated_core_authority_batch_is_bounded_replayable_and_idempotent(v04_authority_run):
    run = v04_authority_run
    result = run.core_result
    state = result.state

    assert result.status == 'COMMITTED'
    assert result.audit_count == 15
    assert result.promotion_count == 9
    assert result.deferred_count == 2
    assert state.objects['claim:formal-root-regularity'].status.value == 'OPEN'
    assert state.objects['claim:c1-chain-necessity'].status.value == 'OPEN'
    assert state.objects['claim:c2-finite-obstruction'].status.value == 'OPEN'
    assert state.authority_audits['audit:etnx:c1'].status == 'DEFER'
    assert state.authority_audits['audit:etnx:c2'].status == 'DEFER'

    proof_assets = [o for o in state.objects.values() if o.object_type == 'PROOF_ASSET' and o.version == 'v0.4']
    assert len(proof_assets) == 9
    assert all(o.authority.value == 'AUDIT' for o in proof_assets)
    assert all(o.status.value == 'CLOSED_POSITIVE' for o in proof_assets)

    assert state.objects['claim:d104-frozen-coaxial-no-go'].status.value == 'CLOSED_NEGATIVE'
    assert state.objects['claim:d104-positive-viscosity-frozen-kernel-empty'].status.value == 'CLOSED_NEGATIVE'
    assert 'Must not be promoted uniformly' in state.objects['claim:d104-positive-viscosity-frozen-kernel-empty'].metadata['scope_note']
    assert state.objects['survivor:d105-vm-shear-pol'].status.value == 'OPEN'
    assert state.objects['frontier:d105-first-order'].status.value == 'OPEN'

    replayed = replay_ledger(run.ledger.events, policy_version=run.state.policy_version)
    assert state_hash(replayed) == state_hash(run.state)

    core = [e for e in run.manifest.entries if not e.audit_id.startswith('audit:rfp:')]
    second = commit_authority_review_batch(
        run.state, run.ledger, core, source_root=run.source_root, batch_id='v0.4-core-authority'
    )
    assert second.status == 'IDEMPOTENT_NOOP'
    assert second.event_count == 0
