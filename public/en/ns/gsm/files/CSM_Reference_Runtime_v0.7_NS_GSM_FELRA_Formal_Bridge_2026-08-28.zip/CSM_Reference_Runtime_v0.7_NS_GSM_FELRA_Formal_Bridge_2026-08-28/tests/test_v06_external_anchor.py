import json
from pathlib import Path

from csm_runtime.enums import Authority, ClosureStatus
from csm_runtime.external_anchor import commit_external_anchor, load_external_anchor_manifest, verify_external_anchor_record
from csm_runtime.ledger import EventLedger, LedgerEvent
from csm_runtime.model import native_state_from_dict

ROOT=Path(__file__).resolve().parents[1]


def _v05():
    snap=json.loads((ROOT/'evidence/v0.5/native_snapshot_v05.json').read_text())
    state=native_state_from_dict(snap['state'])
    events=[LedgerEvent.from_dict(json.loads(line)) for line in (ROOT/'evidence/v0.5/ns_gsm_v05_ledger.jsonl').read_text().splitlines() if line.strip()]
    return state,EventLedger(events)


def test_external_anchor_manifest_has_exact_ess_2003_identity():
    records=load_external_anchor_manifest(ROOT/'external_theorem_anchors_v0.6.yaml')
    assert len(records)==1
    r=records[0]
    assert r.subject_id=='claim:uv-escape-necessity'
    assert r.year==2003
    assert r.doi=='10.1070/RM2003v058n02ABEH000609'
    assert any('Escauriaza' in a for a in r.authors)
    assert any('Seregin' in a for a in r.authors)
    assert any('Šverák' in a or 'Sverak' in a for a in r.authors)
    assert r.status=='BIBLIOGRAPHICALLY_VERIFIED'
    assert any('does not re-prove' in x for x in r.limitations)
    verify_external_anchor_record(r)


def test_external_anchor_attaches_tier_without_authority_or_status_upgrade():
    state,ledger=_v05(); r=load_external_anchor_manifest(ROOT/'external_theorem_anchors_v0.6.yaml')[0]
    before_root=state.objects['claim:formal-root-regularity'].status
    out=commit_external_anchor(state,ledger,r,batch_id='v06-ess-anchor')
    uv=out.state.objects['claim:uv-escape-necessity']
    assert uv.authority is Authority.AUDIT
    assert 'EXTERNAL_THEOREM_ANCHORED' in uv.metadata['authority_tiers']
    assert out.state.objects['claim:c1-chain-necessity'].status is ClosureStatus.OPEN
    assert out.state.objects['claim:c2-finite-obstruction'].status is ClosureStatus.OPEN
    assert out.state.objects['claim:formal-root-regularity'].status is before_root is ClosureStatus.OPEN
    again=commit_external_anchor(out.state,ledger,r,batch_id='v06-ess-anchor')
    assert again.status=='IDEMPOTENT_NOOP'
