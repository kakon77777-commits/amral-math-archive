from pathlib import Path
import json
import tomllib

import csm_runtime


def _version_tuple(value: str) -> tuple[int, ...]:
    return tuple(int(part) for part in value.split('.'))


def test_v06_runtime_and_project_versions_match():
    root = Path(__file__).resolve().parents[1]
    data = tomllib.loads((root / 'pyproject.toml').read_text(encoding='utf-8'))

    # Historical regression tests must not pin the *current* package forever to
    # v0.6.0. They protect two distinct invariants instead:
    #   1) the current runtime/package metadata stay synchronized and never
    #      regress below the v0.6 lineage;
    #   2) the frozen v0.6 release evidence remains v0.6.0.
    assert csm_runtime.__version__ == data['project']['version']
    assert _version_tuple(csm_runtime.__version__) >= (0, 6, 0)

    frozen = json.loads(
        (root / 'evidence' / 'v0.6' / 'run_summary_v06.json').read_text(encoding='utf-8')
    )
    assert frozen['runtime_version'] == '0.6.0'
    assert frozen['version'] == 'v0.6'
