import json
from pathlib import Path

import yaml

from csm_runtime.felra_bridge import export_felra_bridge
from csm_runtime.formalization import v06_proof_assets
from csm_runtime.model import native_state_from_dict

ROOT = Path(__file__).resolve().parents[1]


def _state():
    payload = json.loads((ROOT / "evidence/v0.6/native_snapshot_v06.json").read_text())
    return native_state_from_dict(payload["state"])


def _d103_1(state):
    return next(a for a in v06_proof_assets(state) if "D103.1" in str(a.metadata.get("statement")))


def test_bridge_export_is_location_independent_and_has_felra_contract(tmp_path):
    state = _state(); asset = _d103_1(state)
    a = export_felra_bridge(state, asset.object_id, tmp_path / "a")
    b = export_felra_bridge(state, asset.object_id, tmp_path / "elsewhere" / "b")
    assert a.bridge_manifest == b.bridge_manifest
    assert a.bridge_manifest_sha256 == b.bridge_manifest_sha256
    assert a.obligation_record.to_dict() == b.obligation_record.to_dict()
    assert a.translation.to_dict() == b.translation.to_dict()
    manifest = json.loads((tmp_path / "a/ns_gsm_bridge_manifest.json").read_text())
    assert manifest["protocol"] == "NSGSM-FELRA/0.1"
    assert manifest["backend"] == "lean"
    assert not any(str(v).startswith(str(tmp_path)) for v in manifest.values())
    project = yaml.safe_load((tmp_path / "a/felra/project.yaml").read_text())
    formal = project["analyses"][0]
    assert formal["type"] == "formal_check"
    assert formal["backend"] == "lean"
    assert formal["expect"] == "verified"
    assert formal["axioms_within"] == ["propext", "Classical.choice", "Quot.sound"]
    assert any(x.startswith("ns_gsm_translation:") for x in formal["derives_from"])


def test_bridge_export_rejects_unknown_backend(tmp_path):
    state = _state(); asset = _d103_1(state)
    try:
        export_felra_bridge(state, asset.object_id, tmp_path / "bad", backend="shell")
    except ValueError as exc:
        assert "known backend" in str(exc)
    else:
        raise AssertionError("unknown backend was accepted")
