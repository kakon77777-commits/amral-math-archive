from csm_runtime.canonical import state_hash
from csm_runtime.enums import Authority, ClosureStatus
from csm_runtime.ledger import LedgerEvent
from csm_runtime.model import (
    AuthorityTierReceipt,
    ExternalTheoremAnchorRecord,
    FormalizationRecord,
    NativeState,
    ObjectRecord,
    ReplicationRecord,
    native_state_from_dict,
)
from csm_runtime.replay import replay_ledger
from csm_runtime.state import apply_event


def _event(seq, event_type, payload):
    return LedgerEvent(f"v06:{seq}:{event_type}", event_type, payload, seq)


def test_v06_tier_records_round_trip_and_replay():
    base = ObjectRecord(
        "asset:test", "PROOF_ASSET", "formal", "v0.5",
        status=ClosureStatus.CLOSED_POSITIVE, authority=Authority.PROOF,
        metadata={"statement": "bounded theorem", "reviewed_scope": "local scope"},
    )
    formal = FormalizationRecord(
        formalization_id="formalization:test", subject_id=base.object_id,
        language="NSGSM-FIR/0.1", formalization_kind="ALGEBRAIC_CORE",
        status="CORE_COMPLETE", statement="bounded theorem", scope="local scope",
        assumptions=["A"], goals=["G"], dependencies=[], bundle_sha256="a"*64,
        limitations=[], evidence_refs=["formalization:sha256:" + "a"*64],
    )
    repl = ReplicationRecord(
        replication_id="replication:test", subject_id=base.object_id,
        replicator_id="replica:v06", replicator_kind="CROSS_IMPLEMENTATION",
        replicator_version="v0.6", implementation_sha256="b"*64,
        formalization_id=formal.formalization_id, input_bundle_sha256=formal.bundle_sha256,
        output_artifact_sha256="c"*64, result="MATCH", limitations=[],
        evidence_refs=["replication:sha256:" + "c"*64],
    )
    anchor = ExternalTheoremAnchorRecord(
        anchor_id="anchor:test", subject_id="claim:uv-escape-necessity",
        citation_key="ESS2003", title="L3-infinity solutions", authors=["A", "B", "C"],
        year=2003, doi="10.1070/RM2003v058n02ABEH000609",
        imported_statement="critical endpoint regularity anchor", ns_gsm_use="dependency",
        scope="3D NS", source_refs=["doi:10.1070/RM2003v058n02ABEH000609"],
        status="BIBLIOGRAPHICALLY_VERIFIED", limitations=["does not re-prove theorem"],
    )
    receipt = AuthorityTierReceipt(
        tier_receipt_id="tier:test", subject_id=base.object_id,
        tier_type="CROSS_IMPLEMENTATION_REPLICATED", source_record_id=repl.replication_id,
        certificate_id="cert:tier:test", event_ids=["x"],
        state_hash_before="d"*64, state_hash_after="e"*64,
    )

    events = [
        _event(1, "REGISTER_OBJECT", base.to_dict()),
        _event(2, "REGISTER_FORMALIZATION", formal.to_dict()),
        _event(3, "REGISTER_REPLICATION", repl.to_dict()),
        _event(4, "REGISTER_EXTERNAL_THEOREM_ANCHOR", anchor.to_dict()),
        _event(5, "ADD_AUTHORITY_TIER", {
            "object_id": base.object_id,
            "tier_type": "FORMALIZED_CORE_ONLY",
            "certificate_id": "cert:tier:formal",
        }),
        _event(6, "REGISTER_AUTHORITY_TIER_RECEIPT", receipt.to_dict()),
    ]
    state = NativeState()
    for event in events:
        apply_event(state, event)

    assert state.objects[base.object_id].authority is Authority.PROOF
    assert state.objects[base.object_id].status is ClosureStatus.CLOSED_POSITIVE
    assert state.objects[base.object_id].metadata["authority_tiers"] == ["FORMALIZED_CORE_ONLY"]
    assert state.objects[base.object_id].certificate_refs == ["cert:tier:formal"]

    restored = native_state_from_dict(state.to_dict())
    replayed = replay_ledger(events)
    assert restored.to_dict() == state.to_dict()
    assert state_hash(restored) == state_hash(replayed) == state_hash(state)
