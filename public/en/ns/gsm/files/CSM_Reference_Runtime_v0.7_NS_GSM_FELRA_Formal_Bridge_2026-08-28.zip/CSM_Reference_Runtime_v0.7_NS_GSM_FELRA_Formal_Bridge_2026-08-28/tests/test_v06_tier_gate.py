from copy import deepcopy

import pytest

from csm_runtime.canonical import state_hash
from csm_runtime.enums import Authority, ClosureStatus
from csm_runtime.errors import AuthorityError
from csm_runtime.ledger import EventLedger, LedgerEvent
from csm_runtime.model import CertificateRecord, FormalizationRecord, NativeState, ObjectRecord, ReplicationRecord
from csm_runtime.state import apply_event
from csm_runtime.tier_batch import attach_formal_proof_tier, commit_formalization_replication_tiers


def _base():
    state=NativeState()
    obj=ObjectRecord('asset:x','PROOF_ASSET','formal','v0.5',status=ClosureStatus.CLOSED_POSITIVE,authority=Authority.PROOF,metadata={'statement':'X','reviewed_scope':'local'})
    e=LedgerEvent('genesis:1','REGISTER_OBJECT',obj.to_dict(),1)
    apply_event(state,e)
    return state, EventLedger([e])


def _records():
    f=FormalizationRecord('formalization:x','asset:x','NSGSM-FIR/0.1','ALGEBRAIC_CORE','CORE_COMPLETE','X','local',bundle_sha256='a'*64,evidence_refs=['formalization:sha256:'+'a'*64])
    r=ReplicationRecord('replication:x','asset:x','standalone','CROSS_IMPLEMENTATION','v0.6','b'*64,'formalization:x','a'*64,'c'*64,'MATCH',evidence_refs=['replication:sha256:'+'c'*64])
    return f,r


def test_formalization_and_replication_tiers_do_not_change_base_authority_or_status():
    state,ledger=_base(); f,r=_records()
    result=commit_formalization_replication_tiers(state,ledger,[f],[r],batch_id='b1')
    obj=result.state.objects['asset:x']
    assert obj.authority is Authority.PROOF
    assert obj.status is ClosureStatus.CLOSED_POSITIVE
    assert obj.metadata['authority_tiers'] == ['CROSS_IMPLEMENTATION_REPLICATED','FORMALIZED_CORE_ONLY']
    assert len(result.state.formalizations)==1 and len(result.state.replications)==1
    assert len(result.state.authority_tier_receipts)==2
    again=commit_formalization_replication_tiers(result.state,ledger,[f],[r],batch_id='b1')
    assert again.status=='IDEMPOTENT_NOOP'


def test_mismatch_replication_is_recorded_but_gets_no_replication_tier():
    state,ledger=_base(); f,r=_records(); r.result='MISMATCH'
    result=commit_formalization_replication_tiers(state,ledger,[f],[r],batch_id='b2')
    assert result.state.replications[r.replication_id].result=='MISMATCH'
    assert result.state.objects['asset:x'].metadata['authority_tiers']==['FORMALIZED_CORE_ONLY']


def test_formal_proof_tier_fails_closed_without_kernel_checked_certificate():
    state,ledger=_base()
    cert=CertificateRecord('cert:fake','KERNEL_FORMAL_PROOF',['asset:x'],'VALID',scope='local',verifier_results=[{'kernel_checked':False,'tool':'Lean','proof_object_sha256':'d'*64}])
    e=LedgerEvent('cert:1','REGISTER_CERTIFICATE',cert.to_dict(),2)
    apply_event(state,e); ledger.append_batch([e])
    before=state_hash(state); n=len(ledger.events)
    with pytest.raises(AuthorityError):
        attach_formal_proof_tier(state,ledger,'asset:x','cert:fake',batch_id='formal-bad')
    assert state_hash(state)==before and len(ledger.events)==n


def test_formal_proof_tier_requires_named_kernel_and_checked_object():
    state,ledger=_base()
    cert=CertificateRecord('cert:formal','KERNEL_FORMAL_PROOF',['asset:x'],'VALID',scope='local',verifier_results=[{'kernel_checked':True,'tool':'Lean4','proof_object_sha256':'d'*64}])
    e=LedgerEvent('cert:1','REGISTER_CERTIFICATE',cert.to_dict(),2)
    apply_event(state,e); ledger.append_batch([e])
    out=attach_formal_proof_tier(state,ledger,'asset:x','cert:formal',batch_id='formal-good')
    assert 'FORMAL_PROOF' in out.state.objects['asset:x'].metadata['authority_tiers']
    assert out.state.objects['asset:x'].authority is Authority.PROOF
    assert out.state.objects['asset:x'].status is ClosureStatus.CLOSED_POSITIVE
