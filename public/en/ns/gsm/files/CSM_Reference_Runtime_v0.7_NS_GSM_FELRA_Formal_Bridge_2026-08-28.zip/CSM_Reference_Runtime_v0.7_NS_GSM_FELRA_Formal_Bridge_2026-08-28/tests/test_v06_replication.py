import json
from pathlib import Path

from csm_runtime.formalization import build_formalization_bundle, formalization_record_for_asset, v06_proof_assets
from csm_runtime.model import native_state_from_dict
from csm_runtime.replication import run_replication

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "replicators/ns_gsm_replica_v06.py"


def _state():
    payload = json.loads((ROOT / "evidence/v0.5/native_snapshot_v05.json").read_text())
    return native_state_from_dict(payload["state"])


def test_replicator_is_source_isolated_and_location_independent(tmp_path):
    source = SCRIPT.read_text(encoding="utf-8")
    assert "import csm_runtime" not in source
    assert "from csm_runtime" not in source
    state = _state()
    obj = v06_proof_assets(state)[0]
    bundle = build_formalization_bundle(state, obj.object_id)
    formal = formalization_record_for_asset(state, obj.object_id)
    r1 = run_replication(bundle, formal, SCRIPT, tmp_path / "a")
    r2 = run_replication(bundle, formal, SCRIPT, tmp_path / "b")
    assert r1.to_dict() == r2.to_dict()
    assert r1.replicator_kind == "CROSS_IMPLEMENTATION"
    assert r1.result == "MATCH"
    assert len(r1.implementation_sha256) == 64
    assert r1.evidence_refs == [f"replication:sha256:{r1.output_artifact_sha256}"]


def test_all_twelve_fir_cases_match_cross_implementation_replica(tmp_path):
    state = _state()
    records = []
    for obj in v06_proof_assets(state):
        bundle = build_formalization_bundle(state, obj.object_id)
        formal = formalization_record_for_asset(state, obj.object_id)
        record = run_replication(bundle, formal, SCRIPT, tmp_path / bundle["case_id"])
        records.append((bundle["case_id"], record))
    assert len(records) == 12
    assert all(record.result == "MATCH" for _, record in records)
    assert {case for case, _ in records} == {
        "d103.1", "d103.2", "d103.3", "d103.4", "d103.5",
        "d105.1", "d105.2", "d105.3", "d105.4",
        "rfp05.32.1", "rfp12.12.1", "rfp12.19.1",
    }
    limited = {case for case, record in records if record.limitations}
    assert "d105.4" in limited
    assert "rfp05.32.1" in limited
