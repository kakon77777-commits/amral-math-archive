from pathlib import Path
import hashlib

import yaml

from csm_runtime.authority_audit import AuditOutcome, AuthorityAuditVerifier
from csm_runtime.authority_manifest import load_authority_manifest
from csm_runtime.enums import Authority, ClosureStatus
from csm_runtime.model import NativeState, ObjectRecord


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_manifest(tmp_path: Path, source: Path, **overrides) -> Path:
    entry = {
        "audit_id": "audit:test:manifest",
        "source_path": source.name,
        "source_sha256": _sha(source),
        "subject_id": "claim:test",
        "subject_kind": "NATIVE_OBJECT",
        "statement": "bounded theorem statement",
        "scope": "formal/local",
        "assumptions": ["A1"],
        "certificate_refs": [],
        "nonclaim_refs": [],
        "verdict": "KEEP_EXISTING_AUDIT",
        "authority_cap": "AUDIT",
        "reason": "bounded source audit",
        "source_anchor": "bounded theorem statement",
        "canonical_restatement": False,
    }
    entry.update(overrides)
    path = tmp_path / "manifest.yaml"
    path.write_text(yaml.safe_dump({"version": "v0.4", "entries": [entry]}, sort_keys=False), encoding="utf-8")
    return path


def _state() -> NativeState:
    state = NativeState(version="v0.4")
    state.objects["claim:test"] = ObjectRecord(
        object_id="claim:test",
        object_type="CLAIM",
        domain_id="formal",
        version="v0.4",
        status=ClosureStatus.CLOSED_POSITIVE,
        authority=Authority.AUDIT,
        metadata={"statement": "bounded theorem statement"},
    )
    state.objects["claim:c1-chain-necessity"] = ObjectRecord(
        object_id="claim:c1-chain-necessity",
        object_type="TARGET",
        domain_id="formal",
        version="v0.4",
        status=ClosureStatus.OPEN,
        authority=Authority.RESEARCH,
        metadata={"statement": "C1"},
    )
    return state


def test_manifest_hash_is_deterministic(tmp_path):
    source = tmp_path / "source.md"
    source.write_text("bounded theorem statement\n", encoding="utf-8")
    path = _write_manifest(tmp_path, source)

    first = load_authority_manifest(path)
    second = load_authority_manifest(path)

    assert first.manifest_hash == second.manifest_hash
    assert first.entries[0].source_sha256 == _sha(source)


def test_source_hash_mismatch_is_refused(tmp_path):
    source = tmp_path / "source.md"
    source.write_text("bounded theorem statement\n", encoding="utf-8")
    path = _write_manifest(tmp_path, source, source_sha256="0" * 64)
    manifest = load_authority_manifest(path)

    result = AuthorityAuditVerifier(tmp_path).verify_entry(_state(), manifest.entries[0])

    assert result.outcome is AuditOutcome.REFUSE
    assert "sha" in result.reason.lower()


def test_missing_scope_defers_theorem_promotion(tmp_path):
    source = tmp_path / "source.md"
    source.write_text("bounded theorem statement\n", encoding="utf-8")
    path = _write_manifest(tmp_path, source, scope="", verdict="PROMOTE_AUDIT_ASSET")
    manifest = load_authority_manifest(path)

    result = AuthorityAuditVerifier(tmp_path).verify_entry(_state(), manifest.entries[0])

    assert result.outcome is AuditOutcome.DEFER
    assert "scope" in result.reason.lower()


def test_c1_cannot_be_promoted_by_v04_manifest(tmp_path):
    source = tmp_path / "source.md"
    source.write_text("C1\n", encoding="utf-8")
    path = _write_manifest(
        tmp_path,
        source,
        subject_id="claim:c1-chain-necessity",
        statement="C1",
        source_anchor="C1",
        verdict="PROMOTE_AUDIT_ASSET",
    )
    manifest = load_authority_manifest(path)

    result = AuthorityAuditVerifier(tmp_path).verify_entry(_state(), manifest.entries[0])

    assert result.outcome is AuditOutcome.DEFER
    assert "open proof obligation" in result.reason.lower()
