from csm_runtime.canonical import state_hash
from csm_runtime.ledger import LedgerEvent
from csm_runtime.model import AuthorityUpgradeReceipt, IndependentVerificationRecord, NativeState, native_state_from_dict
from csm_runtime.replay import replay_ledger
from csm_runtime.state import apply_event


def test_verification_and_upgrade_records_round_trip():
    state = NativeState(version="v0.5")
    verification = IndependentVerificationRecord(
        verification_id="verify:d103:1",
        subject_id="authority:proof_asset:x",
        verifier_id="sympy:d103.1",
        verifier_kind="SYMBOLIC_EXACT",
        verifier_version="v0.5",
        statement="Theorem D103.1 — Eigen-lock commutator equation",
        scope="local tensor algebra",
        input_sha256="a" * 64,
        proof_artifact_sha256="b" * 64,
        result="VALID",
        limitations=[],
        evidence_refs=["evidence/v0.5/verifiers/d103_1.json"],
        verified_at_version="v0.5",
    )
    receipt = AuthorityUpgradeReceipt(
        upgrade_id="upgrade:d103:1",
        verification_id=verification.verification_id,
        subject_id=verification.subject_id,
        old_authority="AUDIT",
        new_authority="PROOF",
        certificate_id="cert:independent:d103:1",
        event_ids=["e1", "e2"],
        state_hash_before="c" * 64,
        state_hash_after="d" * 64,
    )
    state.independent_verifications[verification.verification_id] = verification
    state.authority_upgrade_receipts[receipt.upgrade_id] = receipt
    rebuilt = native_state_from_dict(state.to_dict())
    assert rebuilt.to_dict() == state.to_dict()
    assert state_hash(rebuilt) == state_hash(state)


def test_verification_events_replay_deterministically():
    verification = IndependentVerificationRecord(
        verification_id="verify:d103:1", subject_id="asset:1", verifier_id="sympy:d103.1",
        verifier_kind="SYMBOLIC_EXACT", verifier_version="v0.5", statement="s", scope="q",
        input_sha256="a" * 64, proof_artifact_sha256="b" * 64, result="VALID",
    )
    receipt = AuthorityUpgradeReceipt(
        upgrade_id="upgrade:d103:1", verification_id="verify:d103:1", subject_id="asset:1",
        old_authority="AUDIT", new_authority="PROOF", certificate_id="cert:1",
        state_hash_before="c"*64, state_hash_after="d"*64,
    )
    events = [
        LedgerEvent("e1", "REGISTER_INDEPENDENT_VERIFICATION", verification.to_dict(), 1),
        LedgerEvent("e2", "REGISTER_AUTHORITY_UPGRADE", receipt.to_dict(), 2),
    ]
    state = NativeState()
    for e in events: apply_event(state, e)
    replayed = replay_ledger(events)
    assert replayed.to_dict() == state.to_dict()
