from csm_runtime.canonical import state_hash
from csm_runtime.ledger import LedgerEvent
from csm_runtime.model import NativeState, PromotionReceipt, ReviewRecord, native_state_from_dict
from csm_runtime.replay import replay_ledger


def test_review_and_promotion_round_trip_preserves_state_hash():
    state = NativeState(version="v0.3")
    state.reviews["review:1"] = ReviewRecord(
        review_id="review:1",
        candidate_id="candidate:1",
        decision="PROMOTE_FRONTIER",
        reviewer_type="STRUCTURAL_TIER0",
        reason="explicit STOP marker",
        scope="formal",
        evidence_refs=["source:1"],
        certificate_refs=[],
        target_native_id="frontier:1",
        review_version="v0.3",
        status="APPROVED",
    )
    state.promotion_receipts["promotion:1"] = PromotionReceipt(
        promotion_id="promotion:1",
        review_id="review:1",
        candidate_id="candidate:1",
        native_object_id="frontier:1",
        promotion_class="FRONTIER",
        certificate_refs=[],
        debt_refs=[],
        event_ids=["event:1"],
        state_hash_before="before",
        state_hash_after="after",
    )

    restored = native_state_from_dict(state.to_dict())
    assert restored.to_dict() == state.to_dict()
    assert state_hash(restored) == state_hash(state)


def test_replay_reconstructs_review_and_promotion_receipt():
    events = [
        LedgerEvent(
            event_id="review:event:1",
            event_type="REGISTER_REVIEW",
            payload={
                "review_id": "review:1",
                "candidate_id": "candidate:1",
                "decision": "PROMOTE_NONCLAIM",
                "reviewer_type": "STRUCTURAL_TIER0",
                "reason": "explicit nonclaim",
                "scope": "formal",
                "evidence_refs": ["source:1"],
                "certificate_refs": [],
                "target_native_id": "nonclaim:1",
                "review_version": "v0.3",
                "status": "APPROVED",
            },
            sequence=1,
        ),
        LedgerEvent(
            event_id="promotion:event:1",
            event_type="REGISTER_PROMOTION_RECEIPT",
            payload={
                "promotion_id": "promotion:1",
                "review_id": "review:1",
                "candidate_id": "candidate:1",
                "native_object_id": "nonclaim:1",
                "promotion_class": "NONCLAIM",
                "certificate_refs": [],
                "debt_refs": [],
                "event_ids": ["review:event:1"],
                "state_hash_before": "before",
                "state_hash_after": "after",
            },
            sequence=2,
        ),
    ]
    state = replay_ledger(events)
    assert state.reviews["review:1"].decision == "PROMOTE_NONCLAIM"
    assert state.promotion_receipts["promotion:1"].native_object_id == "nonclaim:1"
    assert state.ledger_head == 2
