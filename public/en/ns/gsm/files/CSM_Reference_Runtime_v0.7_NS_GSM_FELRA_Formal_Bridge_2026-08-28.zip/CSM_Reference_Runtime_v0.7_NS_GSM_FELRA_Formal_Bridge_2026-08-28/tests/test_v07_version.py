from pathlib import Path
import re
import csm_runtime

def test_v07_version_contract():
    root=Path(__file__).resolve().parents[1]
    text=(root/'pyproject.toml').read_text()
    m=re.search(r'^version\s*=\s*"([^"]+)"',text,re.M)
    assert csm_runtime.__version__=='0.7.0'
    assert m and m.group(1)=='0.7.0'
