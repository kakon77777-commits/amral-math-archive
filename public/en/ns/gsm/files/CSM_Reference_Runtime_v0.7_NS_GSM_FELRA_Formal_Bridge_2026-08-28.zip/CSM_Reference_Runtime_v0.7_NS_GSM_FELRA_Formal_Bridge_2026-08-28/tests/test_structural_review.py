from csm_runtime.model import CandidateRecord
from csm_runtime.review import ReviewAction, build_structural_review_batch, classify_structural_candidate
from csm_runtime.series_profiles import profile_for_code


def cand(cid, typ, statement, series="RFP"):
    return CandidateRecord(
        candidate_id=cid,
        source_ref=f"source:{cid}",
        candidate_type=typ,
        proposed_object={"statement": statement, "metadata": {"series": series}},
        parser_version="v0.2",
    )


def test_structural_types_route_to_safe_review_actions():
    assert classify_structural_candidate(cand("n", "NonclaimCandidate", "Navier-Stokes regularity is NOT proved."), profile_for_code("RFP")).action is ReviewAction.PROMOTE_NONCLAIM
    assert classify_structural_candidate(cand("f", "FrontierCandidate", "STOP-D79: remaining noncompact modes"), profile_for_code("DCRP")).action is ReviewAction.PROMOTE_FRONTIER
    assert classify_structural_candidate(cand("x", "NextFrontierCandidate", "Next DCRP80"), profile_for_code("DCRP")).action is ReviewAction.PROMOTE_FRONTIER
    assert classify_structural_candidate(cand("s", "SurvivorCandidate", "SURVIVOR: shear branch"), profile_for_code("DCRP")).action is ReviewAction.PROMOTE_SURVIVOR


def test_rfp_research_cycle_closed_is_process_review_not_theorem():
    decision = classify_structural_candidate(
        cand("p", "StatusCandidate", "CLOSED AS A RESEARCH CYCLE", "RFP"),
        profile_for_code("RFP"),
    )
    assert decision.action is ReviewAction.DEFER
    assert decision.theorem_promotion_allowed is False
    assert "process" in decision.reason.lower()


def test_theorem_candidate_remains_deferred_in_tier0():
    decision = classify_structural_candidate(
        cand("t", "TheoremCandidate", "Theorem: bounded taxes imply selector"),
        profile_for_code("RFP"),
    )
    assert decision.action is ReviewAction.DEFER
    assert decision.theorem_promotion_allowed is False


def test_structural_review_batch_id_is_deterministic_and_order_independent():
    values = [
        cand("b", "FrontierCandidate", "STOP-D79", "DCRP"),
        cand("a", "NonclaimCandidate", "global regularity not proved", "DCRP"),
    ]
    b1 = build_structural_review_batch(values, review_policy_version="v0.3")
    b2 = build_structural_review_batch(list(reversed(values)), review_policy_version="v0.3")
    assert b1.batch_id == b2.batch_id
    assert [d.candidate_id for d in b1.decisions] == ["a", "b"]
