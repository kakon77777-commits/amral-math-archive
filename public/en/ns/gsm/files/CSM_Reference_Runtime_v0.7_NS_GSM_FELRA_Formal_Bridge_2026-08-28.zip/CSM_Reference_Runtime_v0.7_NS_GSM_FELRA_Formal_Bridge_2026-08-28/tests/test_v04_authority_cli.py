import json, os, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).parents[1]


def test_run_proof_authority_review_cli_writes_replayable_evidence(tmp_path):
    env=os.environ.copy(); env['PYTHONPATH']=str(ROOT/'src')
    cmd=[sys.executable,'-m','csm_runtime.cli','run-proof-authority-review',
         '--seed',str(ROOT/'fixtures'/'NS_GSM_Seed_Dataset_v0.1'),
         '--corpus',str(ROOT/'corpus'),
         '--expansion',str(ROOT/'corpus_v03_expansion'),
         '--manifest',str(ROOT/'authority_review_manifest_v0.4.yaml'),
         '--evidence',str(tmp_path)]
    cp=subprocess.run(cmd,cwd=ROOT,env=env,text=True,capture_output=True,timeout=120)
    assert cp.returncode==0, cp.stderr
    summary=json.loads(cp.stdout)
    assert summary['version']=='v0.4'
    assert summary['root_status']=='OPEN'
    assert summary['authority_audit_count']==20
    assert summary['proof_asset_count']==12
    assert summary['obstruction_asset_count']==1
    assert summary['deferred_authority_count']==3
    assert summary['replay_match'] is True
    assert (tmp_path/'authority_audits_v04.json').exists()
    assert (tmp_path/'proof_assets_v04.json').exists()
    assert (tmp_path/'obstruction_assets_v04.json').exists()
    assert (tmp_path/'deferred_authority_v04.json').exists()
    assert (tmp_path/'replay_report_v04.json').exists()
