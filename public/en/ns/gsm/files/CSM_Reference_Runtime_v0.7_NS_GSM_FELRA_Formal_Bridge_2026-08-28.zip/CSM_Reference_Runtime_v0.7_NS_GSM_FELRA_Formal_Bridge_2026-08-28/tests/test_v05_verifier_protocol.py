import json
from pathlib import Path
from csm_runtime.independent_verification import VerificationResult, proof_artifact_bytes, proof_artifact_sha256, proof_eligible


def test_proof_artifact_hash_is_canonical_order_independent():
    a = {"kind":"SYMBOLIC_EXACT","checks":{"b":2,"a":1}}
    b = {"checks":{"a":1,"b":2},"kind":"SYMBOLIC_EXACT"}
    assert proof_artifact_bytes(a) == proof_artifact_bytes(b)
    assert proof_artifact_sha256(a) == proof_artifact_sha256(b)


def test_only_full_valid_proof_eligible_kinds_can_upgrade():
    valid = VerificationResult("VALID", "SYMBOLIC_EXACT", {}, [])
    partial = VerificationResult("PARTIAL", "SYMBOLIC_EXACT", {}, ["scope narrower"])
    corpus = VerificationResult("VALID", "CORPUS_AUDIT", {}, [])
    assert proof_eligible(valid)
    assert not proof_eligible(partial)
    assert not proof_eligible(corpus)
