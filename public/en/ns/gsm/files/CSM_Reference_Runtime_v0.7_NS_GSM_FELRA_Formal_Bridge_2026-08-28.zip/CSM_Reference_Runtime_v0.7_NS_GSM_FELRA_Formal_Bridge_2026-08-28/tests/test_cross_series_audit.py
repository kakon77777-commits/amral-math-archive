from csm_runtime.cross_series_audit import exact_statement_proposals
from csm_runtime.model import CandidateRecord, NativeState


def candidate(cid, series, statement):
    return CandidateRecord(
        candidate_id=cid,
        source_ref=cid,
        candidate_type="ObstructionCandidate",
        proposed_object={"statement": statement, "metadata": {"series": series}},
        parser_version="v0.2",
        validation_state="UNVERIFIED",
    )


def test_exact_cross_series_statement_match_is_proposal_only():
    state = NativeState()
    state.candidates["a"] = candidate("a", "RFP", "carrier escape")
    state.candidates["b"] = candidate("b", "DCRP", "carrier escape")
    proposals = exact_statement_proposals(state)
    assert len(proposals) == 1
    proposal = proposals[0]
    assert proposal.left_candidate_id == "a"
    assert proposal.right_candidate_id == "b"
    assert proposal.validation_class.value == "NEEDS_REVIEW"
    assert proposal.auto_quotient is False


def test_same_series_duplicates_are_not_cross_series_proposals():
    state = NativeState()
    state.candidates["a"] = candidate("a", "RFP", "same")
    state.candidates["b"] = candidate("b", "RFP", "same")
    assert exact_statement_proposals(state) == []
