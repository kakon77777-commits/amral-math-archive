from csm_runtime.query import QueryEngine


def test_authority_queries_expose_audits_assets_obstructions_and_deferred(v04_authority_run):
    e = QueryEngine(v04_authority_run.state)
    summary = e.authority_summary().answer
    assert summary['audit_count'] == 20
    assert summary['proof_asset_count'] == 12
    assert summary['obstruction_asset_count'] == 1
    assert summary['deferred_count'] == 3
    assert len(e.proof_assets().answer) == 12
    assert len(e.obstruction_assets().answer) == 1
    assert len(e.deferred_authority().answer) == 3
    assert e.authority_audit('audit:etnx:c1').answer['status'] == 'DEFER'
