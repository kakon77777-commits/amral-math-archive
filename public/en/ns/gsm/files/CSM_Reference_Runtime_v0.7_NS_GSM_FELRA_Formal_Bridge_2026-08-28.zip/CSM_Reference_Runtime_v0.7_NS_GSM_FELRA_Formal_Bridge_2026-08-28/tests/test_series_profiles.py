from csm_runtime.series_profiles import profile_for_filename


def test_profile_routes_known_series_filenames():
    assert profile_for_filename("NS_RFP_10_GuardConsolidation_TaxBoundary_FiniteObstructionAudit_v0.1.md").code == "RFP"
    assert profile_for_filename("NS_MORP_03_Transition_Profile_RigidityEntry_v0.1.md").code == "MORP"
    assert profile_for_filename("NS_X72_Round37_PureContinuous_PressureResponse_DefectEnergy_v0.1_2026-08-17.md").code == "X72"
    assert profile_for_filename("NS_DCRP104_X72R87_RieszSelfConsistency_ShearPolarization_2026-08-20.md").code == "DCRP"
    assert profile_for_filename("NS_C6Q_AncientDefect_LocalGrowth_PstTail_Satellite_v0.1.md").code == "C"


def test_rfp_cycle_closed_is_process_only():
    p = profile_for_filename("NS_RFP_SERIES_ROADMAP_v1.1.md")
    assert p.code == "RFP"
    assert p.research_cycle_closed_is_process_only is True


def test_x72_and_dcrp_stop_markers_are_frontier_semantics():
    assert profile_for_filename("NS_X72_PureContinuous_Checkpoint_v63_2026-08-18.md").stop_semantics == "FRONTIER_CANDIDATE"
    assert profile_for_filename("NS_DCRP79_X72R62_SecularCompactChainNoGo_NoncompactCatalogue_2026-08-18.md").stop_semantics == "FRONTIER_CANDIDATE"


def test_unknown_ns_source_gets_generic_profile_without_theorem_authority():
    p = profile_for_filename("NS_Unknown_Experiment.md")
    assert p.code == "GENERIC_NS"
    assert p.auto_theorem_promotion is False
