from csm_runtime.canonical import state_hash
from csm_runtime.enums import Authority, ClosureStatus
from csm_runtime.ledger import LedgerEvent
from csm_runtime.model import (
    FELRAFormalRunRecord,
    FormalObligationRecord,
    KernelFormalProofReceipt,
    NativeState,
    ObjectRecord,
    TranslationCertificateRecord,
    native_state_from_dict,
)
from csm_runtime.replay import replay_ledger
from csm_runtime.state import apply_event


def _event(seq, event_type, payload):
    return LedgerEvent(f"v07:{seq}:{event_type}", event_type, payload, seq)


def test_v07_bridge_records_round_trip_and_replay():
    subject = ObjectRecord(
        "asset:d103.1", "PROOF_ASSET", "formal", "v0.7",
        status=ClosureStatus.CLOSED_POSITIVE, authority=Authority.PROOF,
        metadata={"statement": "D103.1", "authority_tiers": ["FORMALIZED_CORE_ONLY"]},
    )
    translation = TranslationCertificateRecord(
        translation_id="translation:d103.1", subject_id=subject.object_id,
        formalization_id="formalization:d103.1", fir_sha256="a"*64,
        backend="lean", backend_profile_version="lean-v0.1",
        obligation_sha256="b"*64, project_digest_sha256="c"*64,
        theorem_names=["NSGSM.D103_1"], variable_map={"S":"S"},
        assumption_map={"A":"hA"}, goal_map={"G":"goal"}, status="VALID",
        limitations=[], translation_checker_version="v0.7",
        translation_checker_sha256="d"*64,
        evidence_refs=["translation:sha256:" + "d"*64],
    )
    obligation = FormalObligationRecord(
        obligation_id="obligation:d103.1", subject_id=subject.object_id,
        formalization_id=translation.formalization_id,
        translation_id=translation.translation_id, backend="lean",
        obligation_sha256=translation.obligation_sha256,
        project_digest_sha256=translation.project_digest_sha256,
        theorem_names=list(translation.theorem_names),
        axiom_policy={"mode":"allowlist","allowed":["propext"]},
        assumptions=["A"], limitations=[], bridge_manifest_sha256="e"*64,
        status="READY", evidence_refs=["obligation:sha256:" + "b"*64],
    )
    run = FELRAFormalRunRecord(
        formal_run_id="felra-run:d103.1", subject_id=subject.object_id,
        bridge_id="bridge:d103.1", felra_version="1.8.1", backend="lean",
        formal_status="verified", obligation_sha256="b"*64,
        checker_version="Lean 4.33.0", checker_executable_sha256="f"*64,
        exit_code=0, theorems_audited=1, axioms_seen=["propext"],
        assumptions=["A"], limitations=[], felra_result_sha256="1"*64,
        felra_certificate_sha256="2"*64, status="VALID",
        evidence_refs=["felra-result:sha256:" + "1"*64],
    )
    receipt = KernelFormalProofReceipt(
        formal_proof_receipt_id="formal-proof:d103.1", subject_id=subject.object_id,
        backend="lean", translation_id=translation.translation_id,
        formal_run_id=run.formal_run_id, certificate_id="cert:formal:d103.1",
        obligation_sha256="b"*64, checker_executable_sha256="f"*64,
        axiom_policy_digest="3"*64, event_ids=["evt"],
        state_hash_before="4"*64, state_hash_after="5"*64,
    )
    events = [
        _event(1, "REGISTER_OBJECT", subject.to_dict()),
        _event(2, "REGISTER_TRANSLATION_CERTIFICATE", translation.to_dict()),
        _event(3, "REGISTER_FORMAL_OBLIGATION", obligation.to_dict()),
        _event(4, "REGISTER_FELRA_FORMAL_RUN", run.to_dict()),
        _event(5, "REGISTER_KERNEL_FORMAL_PROOF_RECEIPT", receipt.to_dict()),
    ]
    state = NativeState()
    for event in events:
        apply_event(state, event)

    restored = native_state_from_dict(state.to_dict())
    replayed = replay_ledger(events)
    assert restored.to_dict() == state.to_dict()
    assert state_hash(restored) == state_hash(replayed) == state_hash(state)
    assert "command" not in state.felra_formal_runs[run.formal_run_id].to_dict()
    assert "duration_seconds" not in state.felra_formal_runs[run.formal_run_id].to_dict()
