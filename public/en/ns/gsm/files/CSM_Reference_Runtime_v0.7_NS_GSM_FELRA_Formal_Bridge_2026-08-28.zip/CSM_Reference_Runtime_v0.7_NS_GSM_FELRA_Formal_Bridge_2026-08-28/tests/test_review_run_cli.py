import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).parents[1]
ENV = dict(os.environ, PYTHONPATH=str(ROOT / "src"))


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "csm_runtime.cli", *map(str, args)],
        cwd=ROOT, env=ENV, capture_output=True, text=True,
    )


def test_cli_run_structural_review_writes_v03_evidence(tmp_path):
    out = tmp_path / "evidence"
    result = run_cli(
        "run-structural-review",
        "--seed", ROOT / "fixtures" / "NS_GSM_Seed_Dataset_v0.1",
        "--corpus", ROOT / "corpus",
        "--expansion", ROOT / "corpus_v03_expansion",
        "--evidence", out,
    )
    assert result.returncode == 0, result.stderr
    data = json.loads(result.stdout)
    assert data["version"] == "v0.3"
    assert data["root_status"] == "OPEN"
    assert (out / "native_snapshot_v03.json").exists()
