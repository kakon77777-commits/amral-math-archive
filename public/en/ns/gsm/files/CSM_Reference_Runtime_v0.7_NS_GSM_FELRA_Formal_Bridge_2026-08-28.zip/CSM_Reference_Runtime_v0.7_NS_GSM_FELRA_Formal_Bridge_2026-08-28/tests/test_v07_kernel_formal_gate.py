from csm_runtime.enums import Authority, ClosureStatus
from csm_runtime.errors import AuthorityError
from csm_runtime.kernel_formal_batch import commit_kernel_formal_proof
from csm_runtime.ledger import EventLedger
from csm_runtime.model import (
    FELRAFormalRunRecord, FormalObligationRecord, NativeState, ObjectRecord, TranslationCertificateRecord,
)


def _fixture():
    state=NativeState()
    subject=ObjectRecord('asset:d103.2','PROOF_ASSET','formal','v0.7',ClosureStatus.CLOSED_POSITIVE,authority=Authority.PROOF,metadata={'authority_tiers':['FORMALIZED_CORE_ONLY'],'statement':'D103.2'})
    root=ObjectRecord('claim:formal-root-regularity','TARGET','formal','v0.7',ClosureStatus.OPEN,authority=Authority.NONE)
    c1=ObjectRecord('claim:c1-chain-necessity','TARGET','formal','v0.7',ClosureStatus.OPEN)
    c2=ObjectRecord('claim:c2-finite-obstruction','TARGET','formal','v0.7',ClosureStatus.OPEN)
    state.objects={x.object_id:x for x in (subject,root,c1,c2)}
    t=TranslationCertificateRecord('translation:x',subject.object_id,'formalization:x','a'*64,'lean','lean-v0.1','b'*64,'c'*64,['NSGSM_d103_2'],{}, {}, {},'VALID',[], 'v0.7','d'*64,[])
    o=FormalObligationRecord('obligation:x',subject.object_id,'formalization:x',t.translation_id,'lean','b'*64,'c'*64,['NSGSM_d103_2'],{'mode':'allowlist','allowed':['propext']},[],[],'e'*64,'READY',[])
    r=FELRAFormalRunRecord('run:x',subject.object_id,'bridge:x','1.8.1','lean','verified','b'*64,'Lean 4.33','f'*64,0,1,['propext'],[],[],'1'*64,'2'*64,'VALID',[])
    return state, EventLedger(), subject, t, o, r


def test_valid_kernel_formal_proof_attaches_only_bounded_tier():
    state,ledger,subject,t,o,r=_fixture()
    result=commit_kernel_formal_proof(state,ledger,t,o,r,batch_id='d103.2')
    out=result.state
    assert result.status=='COMMITTED'
    assert 'FORMAL_PROOF' in out.objects[subject.object_id].metadata['authority_tiers']
    assert out.objects[subject.object_id].authority is Authority.PROOF
    assert out.objects[subject.object_id].status is ClosureStatus.CLOSED_POSITIVE
    assert out.objects['claim:formal-root-regularity'].status is ClosureStatus.OPEN
    assert out.objects['claim:c1-chain-necessity'].status is ClosureStatus.OPEN
    assert out.objects['claim:c2-finite-obstruction'].status is ClosureStatus.OPEN
    certs=[c for c in out.certificates.values() if c.certificate_type=='KERNEL_FORMAL_PROOF']
    assert len(certs)==1 and certs[0].status=='VALID'
    assert len(out.kernel_formal_proof_receipts)==1
    again=commit_kernel_formal_proof(out,ledger,t,o,r,batch_id='d103.2')
    assert again.status=='IDEMPOTENT_NOOP'


def test_gate_refuses_mismatch_or_vacuous_audit():
    state,ledger,subject,t,o,r=_fixture()
    bad=FELRAFormalRunRecord(**{**r.to_dict(),'obligation_sha256':'0'*64})
    try:
        commit_kernel_formal_proof(state,ledger,t,o,bad,batch_id='bad')
    except AuthorityError: pass
    else: raise AssertionError('hash mismatch accepted')
    vac=FELRAFormalRunRecord(**{**r.to_dict(),'theorems_audited':0})
    try:
        commit_kernel_formal_proof(state,ledger,t,o,vac,batch_id='vac')
    except AuthorityError: pass
    else: raise AssertionError('vacuous axiom audit accepted')
