from pathlib import Path
import pytest

from csm_runtime.authority_run import run_v04_authority_review

ROOT = Path(__file__).parents[1]


@pytest.fixture(scope='session')
def v04_authority_run():
    return run_v04_authority_review(
        ROOT / 'fixtures' / 'NS_GSM_Seed_Dataset_v0.1',
        ROOT / 'corpus',
        expansion_root=ROOT / 'corpus_v03_expansion',
        manifest_path=ROOT / 'authority_review_manifest_v0.4.yaml',
    )
