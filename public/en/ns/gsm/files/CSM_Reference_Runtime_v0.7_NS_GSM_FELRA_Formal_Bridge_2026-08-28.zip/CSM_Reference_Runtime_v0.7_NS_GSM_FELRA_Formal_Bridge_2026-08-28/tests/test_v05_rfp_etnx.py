from csm_runtime.independent_verification import proof_eligible
from csm_runtime.verifiers.rfp import verify_rfp05_32_1, verify_rfp10_42_1, verify_rfp12_12_1, verify_rfp12_19_1
from csm_runtime.verifiers.etnx import verify_etnx_prop8_1


def test_rfp_verifier_authority_classes():
    r = verify_rfp05_32_1()
    assert r.result == "VALID" and r.verifier_kind == "GRAPH_THEOREM_REDUCTION" and proof_eligible(r)
    assert r.artifact["finite_branching_infinity_principle"] is True

    r = verify_rfp10_42_1()
    assert r.result == "VALID" and r.verifier_kind == "CORPUS_AUDIT" and not proof_eligible(r)

    r = verify_rfp12_12_1()
    assert r.result == "VALID" and r.verifier_kind == "ANALYTIC_SCHEMA" and proof_eligible(r)
    assert r.artifact["quadratic_minimum_match"] is True

    r = verify_rfp12_19_1()
    assert r.result == "VALID" and r.verifier_kind == "ANALYTIC_SCHEMA" and proof_eligible(r)
    assert r.artifact["counterexample_family_closes"] is True


def test_etnx_uv_necessity_reduction_is_independently_checked_but_relative_to_external_l3_criterion():
    r = verify_etnx_prop8_1()
    assert r.result == "VALID" and r.verifier_kind == "ANALYTIC_SCHEMA"
    assert r.artifact["bounded_low_frequency_plus_unbounded_total_implies_unbounded_tail"] is True
    assert r.artifact["uses_external_l3_blowup_criterion"] is True
