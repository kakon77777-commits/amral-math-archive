from pathlib import Path
import hashlib

from csm_runtime.authority_audit import AuditOutcome, AuditVerification, AuthorityAuditVerifier
from csm_runtime.authority_manifest import AuthorityManifestEntry
from csm_runtime.authority_batch import commit_authority_review_batch
from csm_runtime.enums import Authority, ClosureStatus
from csm_runtime.ledger import EventLedger
from csm_runtime.model import CandidateRecord, NativeState, ObjectRecord


def _entry(source: Path, subject_id: str, kind: str, verdict: str, statement: str):
    return AuthorityManifestEntry(
        audit_id=f"audit:{subject_id}",
        source_path=source.name,
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        subject_id=subject_id,
        subject_kind=kind,
        statement=statement,
        scope="formal/local",
        assumptions=(),
        certificate_refs=(),
        nonclaim_refs=(),
        verdict=verdict,
        authority_cap="AUDIT",
        reason="curated bounded review",
        source_anchor=statement,
        canonical_restatement=False,
    )


def test_audit_proof_asset_is_closed_positive_but_only_audit_authority(tmp_path):
    source = tmp_path / "src.md"
    source.write_text("Theorem X", encoding="utf-8")
    state = NativeState(version="v0.4", policy_version="v0.4")
    candidate = CandidateRecord("cand:x", source.name, "TheoremCandidate", {"statement": "Theorem X", "metadata": {"series":"DCRP"}}, "v0.2")
    state.candidates[candidate.candidate_id] = candidate
    ledger = EventLedger()
    entry = _entry(source, "cand:x", "CANDIDATE", "PROMOTE_AUDIT_ASSET", "Theorem X")

    result = commit_authority_review_batch(state, ledger, [entry], source_root=tmp_path, batch_id="batch:proof")

    assets = [o for o in result.state.objects.values() if o.object_type == "PROOF_ASSET"]
    assert len(assets) == 1
    assert assets[0].status is ClosureStatus.CLOSED_POSITIVE
    assert assets[0].authority is Authority.AUDIT
    assert len(assets[0].certificate_refs) == 1


def test_audit_obstruction_does_not_refute_parent(tmp_path):
    source = tmp_path / "src.md"
    source.write_text("NO-GO local branch", encoding="utf-8")
    state = NativeState(version="v0.4", policy_version="v0.4")
    state.objects["claim:parent"] = ObjectRecord("claim:parent", "CLAIM", "formal", "v0.4", ClosureStatus.OPEN, authority=Authority.RESEARCH)
    candidate = CandidateRecord("cand:no-go", source.name, "ObstructionCandidate", {"statement": "NO-GO local branch", "metadata": {"series":"DCRP"}}, "v0.2")
    state.candidates[candidate.candidate_id] = candidate
    ledger = EventLedger()
    entry = _entry(source, "cand:no-go", "CANDIDATE", "PROMOTE_AUDIT_OBSTRUCTION", "NO-GO local branch")

    result = commit_authority_review_batch(state, ledger, [entry], source_root=tmp_path, batch_id="batch:obs")

    obs = [o for o in result.state.objects.values() if o.object_type == "OBSTRUCTION"]
    assert len(obs) == 1
    assert obs[0].status is ClosureStatus.OPEN
    assert obs[0].authority is Authority.AUDIT
    assert result.state.objects["claim:parent"].status is ClosureStatus.OPEN


def test_existing_seed_claim_audit_preserves_status_and_authority(tmp_path):
    source = tmp_path / "src.md"
    source.write_text("bounded statement", encoding="utf-8")
    state = NativeState(version="v0.4", policy_version="v0.4")
    state.objects["claim:seed"] = ObjectRecord(
        "claim:seed", "CLAIM", "formal", "v0.4", ClosureStatus.CLOSED_POSITIVE,
        authority=Authority.AUDIT, metadata={"statement":"bounded statement"}
    )
    ledger = EventLedger()
    entry = _entry(source, "claim:seed", "NATIVE_OBJECT", "KEEP_EXISTING_AUDIT", "bounded statement")

    result = commit_authority_review_batch(state, ledger, [entry], source_root=tmp_path, batch_id="batch:keep")

    kept = result.state.objects["claim:seed"]
    assert kept.status is ClosureStatus.CLOSED_POSITIVE
    assert kept.authority is Authority.AUDIT
    assert not [o for o in result.state.objects.values() if o.object_type == "PROOF_ASSET"]
    assert len(result.state.authority_audits) == 1


def test_authority_batch_is_idempotent(tmp_path):
    source = tmp_path / "src.md"
    source.write_text("Theorem X", encoding="utf-8")
    state = NativeState(version="v0.4", policy_version="v0.4")
    state.candidates["cand:x"] = CandidateRecord("cand:x", source.name, "TheoremCandidate", {"statement":"Theorem X"}, "v0.2")
    ledger = EventLedger()
    entry = _entry(source, "cand:x", "CANDIDATE", "PROMOTE_AUDIT_ASSET", "Theorem X")

    first = commit_authority_review_batch(state, ledger, [entry], source_root=tmp_path, batch_id="batch:same")
    second = commit_authority_review_batch(first.state, ledger, [entry], source_root=tmp_path, batch_id="batch:same")

    assert first.status == "COMMITTED"
    assert second.status == "IDEMPOTENT_NOOP"
    assert second.event_count == 0
