from pathlib import Path

from csm_runtime.canonical import state_hash
from csm_runtime.formalization_run import run_v06_formalization_replication
from csm_runtime.replay import replay_ledger

ROOT=Path(__file__).resolve().parents[1]


def test_v06_real_run_adds_formalization_replication_tiers_without_parent_closure(tmp_path):
    run=run_v06_formalization_replication(ROOT,tmp_path/'evidence')
    assert len(run.state.formalizations)==12
    assert len(run.state.replications)==12
    assert all(r.result=='MATCH' for r in run.state.replications.values())
    assets=[o for o in run.state.objects.values() if o.version=='v0.4' and o.authority.value=='PROOF' and o.object_type in {'PROOF_ASSET','OBSTRUCTION'}]
    assert len(assets)==12
    assert all('FORMALIZED_CORE_ONLY' in o.metadata.get('authority_tiers',[]) for o in assets)
    assert all('CROSS_IMPLEMENTATION_REPLICATED' in o.metadata.get('authority_tiers',[]) for o in assets)
    assert sum('FORMAL_PROOF' in o.metadata.get('authority_tiers',[]) for o in run.state.objects.values())==0
    uv=run.state.objects['claim:uv-escape-necessity']
    assert 'EXTERNAL_THEOREM_ANCHORED' in uv.metadata.get('authority_tiers',[])
    assert uv.authority.value=='AUDIT'
    assert run.state.objects['claim:formal-root-regularity'].status.value=='OPEN'
    assert run.state.objects['claim:c1-chain-necessity'].status.value=='OPEN'
    assert run.state.objects['claim:c2-finite-obstruction'].status.value=='OPEN'
    replayed=replay_ledger(run.ledger.events,policy_version=run.state.policy_version)
    assert state_hash(replayed)==state_hash(run.state)
    tier_again,anchor_again=run.reapply(tmp_path/'evidence-reapply')
    assert tier_again.status=='IDEMPOTENT_NOOP'
    assert anchor_again.status=='IDEMPOTENT_NOOP'
