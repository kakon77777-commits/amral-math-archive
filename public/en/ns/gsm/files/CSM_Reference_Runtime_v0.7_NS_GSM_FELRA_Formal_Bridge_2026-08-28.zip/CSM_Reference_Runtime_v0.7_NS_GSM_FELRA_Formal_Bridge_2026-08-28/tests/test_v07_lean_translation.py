import json
from pathlib import Path

from csm_runtime.formalization import build_formalization_bundle, formalization_bundle_sha256, v06_proof_assets
from csm_runtime.lean_translation import translate_fir_to_lean, validate_lean_translation
from csm_runtime.model import native_state_from_dict

ROOT = Path(__file__).resolve().parents[1]


def _state():
    payload = json.loads((ROOT / "evidence/v0.6/native_snapshot_v06.json").read_text())
    return native_state_from_dict(payload["state"])


def test_d103_five_translations_are_deterministic_and_valid():
    state = _state()
    assets = [a for a in v06_proof_assets(state) if "D103." in str(a.metadata.get("statement"))]
    assert len(assets) == 5
    for asset in assets:
        bundle = build_formalization_bundle(state, asset.object_id)
        a = translate_fir_to_lean(bundle, subject_id=asset.object_id)
        b = translate_fir_to_lean(bundle, subject_id=asset.object_id)
        assert a.to_dict() == b.to_dict()
        assert a.status == "READY"
        assert "NSGSM_PROOF_BODY_REQUIRED" in a.source
        cert = validate_lean_translation(bundle, a)
        assert cert.status == "VALID"
        assert cert.fir_sha256 == formalization_bundle_sha256(bundle)
        assert cert.obligation_sha256 == a.obligation_sha256
        assert cert.theorem_names == [a.theorem_name]


def test_unsupported_fir_defers_instead_of_guessing():
    bundle = {
        "language": "NSGSM-FIR/0.1", "case_id": "unknown.case", "subject_id": "asset:x",
        "statement": "Unknown", "scope": "x", "assumptions": [], "variables": [], "goals": ["G"],
        "derivation_kind": "unknown", "normalized_claim": {"x": 1}, "dependencies": [], "limitations": [],
    }
    result = translate_fir_to_lean(bundle, subject_id="asset:x")
    assert result.status == "DEFER"
    assert validate_lean_translation(bundle, result).status == "DEFER"


def test_statement_mutation_invalidates_translation_but_body_edit_changes_only_obligation_hash():
    state = _state()
    asset = next(a for a in v06_proof_assets(state) if "D103.2" in str(a.metadata.get("statement")))
    bundle = build_formalization_bundle(state, asset.object_id)
    result = translate_fir_to_lean(bundle, subject_id=asset.object_id)
    mutated_bundle = dict(bundle); mutated_bundle["goals"] = ["different goal"]
    assert validate_lean_translation(mutated_bundle, result).status == "INVALID"
    edited = result.with_source(result.source.replace("NSGSM_PROOF_BODY_REQUIRED", "NSGSM_LOCAL_PROOF_BODY"))
    assert edited.signature_sha256 == result.signature_sha256
    assert edited.obligation_sha256 != result.obligation_sha256
