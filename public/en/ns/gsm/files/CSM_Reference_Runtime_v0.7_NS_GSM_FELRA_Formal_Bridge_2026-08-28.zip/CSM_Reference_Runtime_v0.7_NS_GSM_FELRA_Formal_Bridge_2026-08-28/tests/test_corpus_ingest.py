from csm_runtime.corpus_ingest import build_corpus_batch
from csm_runtime.corpus_manifest import CorpusManifest, CorpusSource
from csm_runtime.enums import ClosureStatus
from csm_runtime.ledger import EventLedger
from csm_runtime.model import NativeState, ObjectRecord
from csm_runtime.transaction import ClosureTransaction


def source(text_hash="abc"):
    return CorpusSource(
        source_id="src:test",
        file_name="NS_RFP_Test.md",
        series="RFP",
        source_hash=text_hash,
        source_ref="library:test",
    )


def test_source_proved_and_closed_labels_register_candidates_without_closing_root():
    text = '''---
status: "PROVED / CLOSED"
---
# NS-RFP Test
## Theorem T1 — Local test theorem
## Cycle X — CLOSED AS A RESEARCH CYCLE
'''
    state = NativeState()
    state.objects["claim:root"] = ObjectRecord(
        "claim:root", "TARGET", "formal", "v0.1", ClosureStatus.OPEN
    )
    ledger = EventLedger()
    batch = build_corpus_batch(state, ledger, CorpusManifest([source()]), {"src:test": text})
    txn = ClosureTransaction(state, ledger)
    for event in batch.events:
        txn.stage(event)
    result = txn.commit()

    assert result.state.objects["claim:root"].status is ClosureStatus.OPEN
    assert result.state.candidates
    assert any(c.candidate_type == "TheoremCandidate" for c in result.state.candidates.values())
    assert any(c.candidate_type == "StatusCandidate" for c in result.state.candidates.values())
    assert all(e.event_type != "SET_STATUS" for e in batch.events)


def test_stop_marker_becomes_frontier_candidate_not_native_frontier_object():
    text = "# Test\n## STOP-D999\nNext: DCRP1000\n"
    state = NativeState()
    ledger = EventLedger()
    batch = build_corpus_batch(state, ledger, CorpusManifest([source()]), {"src:test": text})
    txn = ClosureTransaction(state, ledger)
    for event in batch.events:
        txn.stage(event)
    result = txn.commit()
    assert any(c.candidate_type == "FrontierCandidate" for c in result.state.candidates.values())
    assert not any(o.object_type == "FRONTIER" for o in result.state.objects.values())


def test_candidate_ids_are_stable_across_batch_rebuilds():
    text = "# NS-RFP Test\n## Theorem T — Result\n"
    manifest = CorpusManifest([source()])
    a = build_corpus_batch(NativeState(), EventLedger(), manifest, {"src:test": text})
    b = build_corpus_batch(NativeState(), EventLedger(), manifest, {"src:test": text})
    a_ids = [e.payload["candidate_id"] for e in a.events if e.event_type == "REGISTER_CANDIDATE"]
    b_ids = [e.payload["candidate_id"] for e in b.events if e.event_type == "REGISTER_CANDIDATE"]
    assert a_ids == b_ids
