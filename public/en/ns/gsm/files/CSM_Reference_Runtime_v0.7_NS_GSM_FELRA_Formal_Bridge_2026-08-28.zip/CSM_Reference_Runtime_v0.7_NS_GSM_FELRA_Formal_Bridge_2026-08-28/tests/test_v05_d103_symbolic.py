from csm_runtime.independent_verification import proof_artifact_sha256
from csm_runtime.verifiers.d103 import verify_d103_1, verify_d103_2, verify_d103_3, verify_d103_4, verify_d103_5


def test_d103_exact_symbolic_verifiers_all_close():
    for verifier in [verify_d103_1, verify_d103_2, verify_d103_3, verify_d103_4, verify_d103_5]:
        result = verifier()
        assert result.result == "VALID"
        assert result.verifier_kind == "SYMBOLIC_EXACT"
        assert result.limitations == []
        assert len(proof_artifact_sha256(result.artifact)) == 64
        assert result.artifact["verified"] is True


def test_d103_five_ray_verifier_checks_characteristic_factorization():
    result = verify_d103_4()
    assert result.artifact["off_diagonal_eigenvalues"] == ["-s3", "-s2", "-s1"]
    assert result.artifact["diagonal_charpoly_match"] is True
