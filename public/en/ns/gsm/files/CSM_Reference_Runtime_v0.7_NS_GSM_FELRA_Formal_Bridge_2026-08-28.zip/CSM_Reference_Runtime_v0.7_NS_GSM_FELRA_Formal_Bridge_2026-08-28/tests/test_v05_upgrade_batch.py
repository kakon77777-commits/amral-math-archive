from pathlib import Path
from csm_runtime.enums import Authority, ClosureStatus
from csm_runtime.independent_verification import VerificationResult
from csm_runtime.ledger import EventLedger, LedgerEvent
from csm_runtime.model import NativeState, ObjectRecord
from csm_runtime.state import apply_event
from csm_runtime.verification_batch import VerificationTarget, commit_independent_verification_batch


def _seed_state():
    state=NativeState(version='v0.5')
    ledger=EventLedger()
    for i,(oid,otype) in enumerate([('asset:proof','PROOF_ASSET'),('asset:partial','PROOF_ASSET'),('asset:corpus','PROOF_ASSET'),('asset:obstruction','OBSTRUCTION')],1):
        obj=ObjectRecord(oid,otype,'formal','v0.4',ClosureStatus.CLOSED_POSITIVE if otype=='PROOF_ASSET' else ClosureStatus.OPEN,
                         certificate_refs=[f'cert:source:{i}'],authority=Authority.AUDIT,
                         metadata={'statement':oid,'reviewed_scope':'bounded'})
        ev=LedgerEvent(f'g{i}','REGISTER_OBJECT',obj.to_dict(),i)
        apply_event(state,ev); ledger.append_batch([ev])
    return state,ledger


def test_valid_independent_verification_upgrades_only_subject_and_preserves_source_cert(tmp_path):
    state,ledger=_seed_state()
    targets=[
        VerificationTarget('asset:proof','v:proof','v0.5',lambda: VerificationResult('VALID','SYMBOLIC_EXACT',{'verified':True},[])),
        VerificationTarget('asset:partial','v:partial','v0.5',lambda: VerificationResult('PARTIAL','SYMBOLIC_EXACT',{'verified':False},['narrower'])),
        VerificationTarget('asset:corpus','v:corpus','v0.5',lambda: VerificationResult('VALID','CORPUS_AUDIT',{'verified':True},[])),
        VerificationTarget('asset:obstruction','v:obs','v0.5',lambda: VerificationResult('VALID','ANALYTIC_SCHEMA',{'verified':True},[])),
    ]
    result=commit_independent_verification_batch(state,ledger,targets,evidence_dir=tmp_path,batch_id='b1')
    assert result.state.objects['asset:proof'].authority is Authority.PROOF
    assert result.state.objects['asset:obstruction'].authority is Authority.PROOF
    assert result.state.objects['asset:obstruction'].status is ClosureStatus.OPEN
    assert result.state.objects['asset:partial'].authority is Authority.AUDIT
    assert result.state.objects['asset:corpus'].authority is Authority.AUDIT
    assert 'cert:source:1' in result.state.objects['asset:proof'].certificate_refs
    assert any(c.startswith('cert:independent:') for c in result.state.objects['asset:proof'].certificate_refs)
    assert len(result.state.authority_upgrade_receipts)==2
    again=commit_independent_verification_batch(result.state,ledger,targets,evidence_dir=tmp_path,batch_id='b1')
    assert again.status=='IDEMPOTENT_NOOP'


def test_verification_state_hash_is_independent_of_evidence_export_directory(tmp_path):
    from csm_runtime.canonical import state_hash
    target=VerificationTarget('asset:proof','v:stable','v0.5',lambda: VerificationResult('VALID','SYMBOLIC_EXACT',{'verified':True,'x':1},[]))
    state1,ledger1=_seed_state()
    state2,ledger2=_seed_state()
    r1=commit_independent_verification_batch(state1,ledger1,[target],evidence_dir=tmp_path/'a',batch_id='stable')
    r2=commit_independent_verification_batch(state2,ledger2,[target],evidence_dir=tmp_path/'b',batch_id='stable')
    assert state_hash(r1.state)==state_hash(r2.state)
