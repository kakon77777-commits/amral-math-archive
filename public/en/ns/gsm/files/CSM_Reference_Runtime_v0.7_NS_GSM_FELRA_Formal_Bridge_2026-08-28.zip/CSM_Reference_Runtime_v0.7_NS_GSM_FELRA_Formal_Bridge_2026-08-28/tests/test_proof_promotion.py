import pytest

from csm_runtime.enums import Authority, ClosureStatus
from csm_runtime.errors import AuthorityError
from csm_runtime.model import CandidateRecord, CertificateRecord, NativeState, ObjectRecord, ReviewRecord
from csm_runtime.promotion import GateOutcome, PromotionGate, promote_proof_asset
from csm_runtime.operators import close_negative


def candidate(cid="t", typ="TheoremCandidate", statement="Theorem: local identity holds"):
    return CandidateRecord(
        candidate_id=cid,
        source_ref=f"source:{cid}",
        candidate_type=typ,
        proposed_object={"statement": statement, "metadata": {"series": "DCRP"}},
        parser_version="v0.2",
    )


def review(cid="t", decision="PROMOTE_PROOF_ASSET", target="proof:t"):
    return ReviewRecord(
        review_id=f"review:{cid}",
        candidate_id=cid,
        decision=decision,
        reviewer_type="PROOF_TIER2",
        reason="source theorem with bounded scope",
        scope="formal-local",
        evidence_refs=[f"source:{cid}"],
        target_native_id=target,
        status="APPROVED",
    )


def test_source_proved_label_alone_does_not_get_proof_authority():
    state = NativeState(version="v0.3")
    c = candidate("status", "StatusCandidate", "PROVED")
    r = review("status", decision="DEFER", target="proof:status")
    decision = PromotionGate().evaluate_proof(state, c, r, certificate_id=None)
    assert decision.outcome is GateOutcome.DEFER


def test_approved_theorem_without_certificate_is_deferred():
    state = NativeState(version="v0.3")
    decision = PromotionGate().evaluate_proof(state, candidate(), review(), certificate_id=None)
    assert decision.outcome is GateOutcome.DEFER


def test_source_internal_proof_certificate_can_promote_bounded_proof_asset_at_audit_authority():
    state = NativeState(version="v0.3")
    state.certificates["cert:t"] = CertificateRecord(
        certificate_id="cert:t",
        certificate_type="SOURCE_INTERNAL_PROOF",
        subject_ids=["proof:t"],
        status="VALID_SOURCE_ASSERTION",
        scope="formal-local",
    )
    obj = promote_proof_asset(state, candidate(), review(), "cert:t")
    assert obj.object_type == "PROOF_ASSET"
    assert obj.status is ClosureStatus.CLOSED_POSITIVE
    assert obj.authority is Authority.AUDIT
    assert obj.certificate_refs == ["cert:t"]


def test_independently_valid_proof_certificate_can_promote_proof_authority():
    state = NativeState(version="v0.3")
    state.certificates["cert:t"] = CertificateRecord(
        certificate_id="cert:t",
        certificate_type="PROOF",
        subject_ids=["proof:t"],
        status="VALID",
        scope="formal-local",
    )
    obj = promote_proof_asset(state, candidate(), review(), "cert:t")
    assert obj.authority is Authority.PROOF


def test_explicit_nonclaim_blocks_requested_proof_promotion():
    state = NativeState(version="v0.3")
    state.certificates["cert:t"] = CertificateRecord(
        certificate_id="cert:t",
        certificate_type="SOURCE_INTERNAL_PROOF",
        subject_ids=["proof:t"],
        status="VALID_SOURCE_ASSERTION",
        scope="formal-local",
    )
    with pytest.raises(AuthorityError):
        promote_proof_asset(
            state,
            candidate(statement="global Navier Stokes regularity"),
            review(),
            "cert:t",
            nonclaim_statements=["global Navier Stokes regularity is NOT proved"],
        )


def test_obstruction_without_negative_certificate_cannot_close_parent_claim():
    state = NativeState(version="v0.3")
    state.objects["claim:root"] = ObjectRecord(
        "claim:root", "TARGET", "formal", "v0.3", status=ClosureStatus.OPEN
    )
    with pytest.raises(AuthorityError):
        close_negative(state, "claim:root", "cert:missing")
    assert state.objects["claim:root"].status is ClosureStatus.OPEN
