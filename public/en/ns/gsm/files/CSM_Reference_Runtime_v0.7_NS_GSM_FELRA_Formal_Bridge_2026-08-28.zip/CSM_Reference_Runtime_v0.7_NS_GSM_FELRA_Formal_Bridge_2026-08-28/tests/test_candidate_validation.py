from csm_runtime.candidate_validation import (
    ValidationClass,
    classify_candidate,
    validate_promotion_against_nonclaims,
    propose_cross_series_match,
)
from csm_runtime.series_profiles import profile_for_filename
from csm_runtime.source_parser import ParsedCandidate


def cand(kind, statement, cid="candidate:x", series="RFP"):
    return ParsedCandidate(cid, kind, f"src:{series}", statement, 1, 1, {"series": series})


def test_rfp_research_cycle_closed_needs_review_not_theorem_promotion():
    candidate = cand("StatusCandidate", "Cycle I — CLOSED AS A RESEARCH CYCLE")
    decision = classify_candidate(candidate, profile_for_filename("NS_RFP_SERIES_ROADMAP_v1.1.md"))
    assert decision.validation_class is ValidationClass.NEEDS_REVIEW
    assert decision.theorem_promotion_allowed is False
    assert "research cycle" in decision.reason.lower()


def test_nonclaim_rejects_incompatible_subject_promotion():
    result = validate_promotion_against_nonclaims(
        "Navier-Stokes regularity",
        ["Navier-Stokes regularity is NOT proved."],
    )
    assert result.validation_class is ValidationClass.REJECTED
    assert result.theorem_promotion_allowed is False


def test_frontier_candidate_can_be_promotable_only_as_non_theorem_structure():
    candidate = cand("FrontierCandidate", "STOP-D79", series="DCRP")
    decision = classify_candidate(candidate, profile_for_filename("NS_DCRP79_Test.md"))
    assert decision.validation_class is ValidationClass.PROMOTABLE
    assert decision.theorem_promotion_allowed is False


def test_same_terminology_cross_series_proposal_never_auto_quotients():
    left = cand("ObstructionCandidate", "carrier escape", "candidate:left", "RFP")
    right = cand("ObstructionCandidate", "carrier escape", "candidate:right", "DCRP")
    proposal = propose_cross_series_match(left, right, "same normalized terminology")
    assert proposal.validation_class is ValidationClass.NEEDS_REVIEW
    assert proposal.auto_quotient is False
