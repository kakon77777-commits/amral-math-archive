from pathlib import Path
from csm_runtime.cli import main
from csm_runtime.felra_bridge_run import run_v07_felra_bridge
from csm_runtime.query import QueryEngine

ROOT=Path(__file__).resolve().parents[1]

def test_v07_query_surface(tmp_path):
    run=run_v07_felra_bridge(ROOT,tmp_path/'run')
    q=QueryEngine(run.state)
    assert len(q.formalization_bridges().answer)==5
    assert len(q.translation_certificates().answer)==5
    assert len(q.formal_obligations().answer)==5
    assert q.felra_formal_runs().answer==[]
    assert q.kernel_formal_proofs().answer==[]
    assert len(q.formal_proof_deferred().answer)==5

def test_run_felra_bridge_cli_writes_evidence(tmp_path):
    out=tmp_path/'evidence'
    rc=main(['run-felra-bridge','--root',str(ROOT),'--evidence',str(out)])
    assert rc==0
    assert (out/'run_summary.json').exists()
    assert (out/'conformance_report.json').exists()
