import json
from pathlib import Path

from csm_runtime.formalization import (
    build_formalization_bundle,
    formalization_bundle_sha256,
    formalization_record_for_asset,
    v06_proof_assets,
)
from csm_runtime.model import native_state_from_dict

ROOT = Path(__file__).resolve().parents[1]


def _state():
    payload = json.loads((ROOT / "evidence/v0.5/native_snapshot_v05.json").read_text())
    return native_state_from_dict(payload["state"])


def test_all_twelve_v05_proof_assets_compile_to_fir():
    state = _state()
    assets = v06_proof_assets(state)
    assert len(assets) == 12
    records = []
    for obj in assets:
        bundle = build_formalization_bundle(state, obj.object_id)
        record = formalization_record_for_asset(state, obj.object_id)
        assert bundle["language"] == "NSGSM-FIR/0.1"
        assert bundle["subject_id"] == obj.object_id
        assert bundle["statement"] == obj.metadata["statement"]
        assert bundle["scope"] == obj.metadata["reviewed_scope"]
        assert bundle["assumptions"] == sorted(obj.metadata.get("assumptions") or [])
        assert bundle["case_id"]
        assert record.bundle_sha256 == formalization_bundle_sha256(bundle)
        assert record.evidence_refs == [f"formalization:sha256:{record.bundle_sha256}"]
        records.append(record)
    statuses = {r.formalization_kind + ":" + r.status for r in records}
    assert "ALGEBRAIC_CORE:CORE_COMPLETE" in statuses
    assert "ANALYTIC_SCHEMA:SCHEMA_COMPLETE" in statuses
    assert "GRAPH_SCHEMA:SCHEMA_COMPLETE" in statuses
    assert "COUNTEREXAMPLE_WITNESS:WITNESS_COMPLETE" in statuses


def test_formalization_hash_is_location_independent(tmp_path):
    state = _state()
    obj = v06_proof_assets(state)[0]
    bundle = build_formalization_bundle(state, obj.object_id)
    p1 = tmp_path / "a" / "bundle.json"
    p2 = tmp_path / "b" / "different-name.json"
    p1.parent.mkdir(); p2.parent.mkdir()
    text = json.dumps(bundle, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    p1.write_text(text); p2.write_text(text)
    assert formalization_bundle_sha256(bundle) == formalization_bundle_sha256(json.loads(p2.read_text()))
