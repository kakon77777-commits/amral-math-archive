from csm_runtime.authority_batch import commit_authority_review_batch
from csm_runtime.canonical import state_hash
from csm_runtime.replay import replay_ledger


def test_selected_rfp_authority_batch_promotes_bounded_assets_and_defers_closure(v04_authority_run):
    run = v04_authority_run
    result = run.rfp_result
    state = run.state

    assert result.status == 'COMMITTED'
    assert result.audit_count == 5
    assert result.promotion_count == 4
    assert result.deferred_count == 1
    assert state.authority_audits['audit:rfp:c10:conditional-cover'].status == 'DEFER'
    assert state.objects['claim:formal-root-regularity'].status.value == 'OPEN'
    assert state.objects['claim:c1-chain-necessity'].status.value == 'OPEN'
    assert state.objects['claim:c2-finite-obstruction'].status.value == 'OPEN'

    rfp_assets = [o for o in state.objects.values() if o.version == 'v0.4' and o.metadata.get('series') == 'RFP']
    assert sum(o.object_type == 'PROOF_ASSET' for o in rfp_assets) == 3
    assert sum(o.object_type == 'OBSTRUCTION' for o in rfp_assets) == 1
    assert all(o.authority.value == 'AUDIT' for o in rfp_assets)
    assert all(o.status.value == 'OPEN' for o in rfp_assets if o.object_type == 'OBSTRUCTION')

    replayed = replay_ledger(run.ledger.events, policy_version=state.policy_version)
    assert state_hash(replayed) == state_hash(state)

    rfp = [e for e in run.manifest.entries if e.audit_id.startswith('audit:rfp:')]
    second = commit_authority_review_batch(state, run.ledger, rfp, source_root=run.source_root, batch_id='v0.4-rfp-authority')
    assert second.status == 'IDEMPOTENT_NOOP'
