from csm_runtime.verifiers.d105 import verify_d105_1, verify_d105_2, verify_d105_3, verify_d105_4


def test_d105_verifier_result_classes():
    r1 = verify_d105_1()
    assert r1.result in {"VALID", "PARTIAL"}
    assert r1.verifier_kind == "SYMBOLIC_EXACT"
    assert r1.artifact["kernel_derivative_checked"] is True

    r2 = verify_d105_2()
    assert r2.result == "VALID" and r2.verifier_kind == "EXACT_WITNESS"
    assert r2.artifact["kelvin_projection"] == "1"
    assert r2.artifact["tr_projection_nonzero"] is True

    r3 = verify_d105_3()
    assert r3.result == "VALID" and r3.verifier_kind == "SYMBOLIC_EXACT"
    assert r3.artifact["residual_identity"] is True

    r4 = verify_d105_4()
    assert r4.result == "VALID" and r4.verifier_kind == "ANALYTIC_SCHEMA"
    assert r4.artifact["pointwise_support_bound"] is True
    assert r4.artifact["l2_monotonicity_step"] is True
