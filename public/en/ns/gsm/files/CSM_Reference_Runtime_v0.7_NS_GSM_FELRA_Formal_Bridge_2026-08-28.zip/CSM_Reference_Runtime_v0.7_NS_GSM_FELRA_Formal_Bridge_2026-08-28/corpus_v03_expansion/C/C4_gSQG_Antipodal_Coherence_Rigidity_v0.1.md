# C4 — gSQG Antipodal Correlation and Signed-Coherence Rigidity

Version: v0.1  
Date: 2026-08-17  
Status: internally proved under stated hypotheses; publication-level novelty audit open

## Abstract

This note continues the transfer campaign from Navier--Stokes proof assets to the supercritical generalized surface quasi-geostrophic equation. C3 established a symmetrized high--high-to-low symbol with the remote suppression exponent

$$
\rho_{\mathrm{mic}}=s_c+3=4+\beta-2\alpha,
$$

and showed that natural output-scale Fourier tiles have bounded antipodal partner degree, while degree alone does not force a microlocal parent atom. The surviving obstruction was identified as signed antipodal coherence.

C4 introduces a deterministic spacetime coherence factorization for the remote high--high flux. Each natural-tile edge has a complex integrated trilinear amplitude $Z_e$ and a rigorous absolute envelope $A_e$. We define a temporal survival coefficient $\mathcal T$, a signed cross-edge coherence coefficient $\mathcal C_{\mathrm{sgn}}$, a phase coherence coefficient $\mathcal C_{\mathrm{ph}}$, and an effective pair rank $\mathcal R_{\mathrm{eff}}$.

The main conclusions are:

1. positive remote payment obeys a coherence--occupancy product inequality;
2. near-minimal dissipation cost forces both temporal persistence and signed antipodal coherence;
3. under the absence of a Fourier-tile atom, positive payment forces a large effective pair rank;
4. high signed coherence admits an exact weighted phase-concentration identity;
5. coherence alone does not force atomicity: the diffuse perfect matching from C3 survives exactly as a high-rank coherent ensemble;
6. no universal improvement beyond the C3 exponent $s_c+3$ follows from coherence alone, because a single generic-angle coherent pair already saturates the C3 symbol scale.

Thus the remote obstruction is refined from an unsigned collection of antipodal pairs to the trichotomy

$$
\boxed{
\text{critical-dissipation defect}
\;\vee\;
\text{microlocal parent atom}
\;\vee\;
\text{high-rank signed-coherent ensemble}.
}
$$

This is not a global regularity theorem for gSQG.

---

# 1. Equation and critical scaling

We consider

$$
\partial_t\theta
+\Lambda^{2\alpha}\theta
+u_\theta\cdot\nabla\theta
=0,
$$

with

$$
u_\theta
=
\nabla^\perp\Lambda^{\beta-2}\theta,
$$

in the fully nonlinear supercritical regime

$$
0<\alpha<\frac12,
\qquad
2\alpha+1\le\beta<2.
$$

The scaling-critical Sobolev exponent is

$$
\boxed{
s_c=1+\beta-2\alpha.
}
$$

Let

$$
K\sim\lambda_q
$$

be a low output scale and

$$
N\sim\lambda_p,
\qquad
p\ge q+M,
$$

be a remote high parent scale. Write

$$
\varepsilon=\frac KN\sim2^{-M}.
$$

The C3 symmetrized symbol is

$$
\boxed{
m_{\mathrm{sym}}(\xi,\eta)
=
-\frac12
(\xi^\perp\cdot\eta)
\left(
|\xi|^{\beta-2}-|\eta|^{\beta-2}
\right).
}
$$

On the high--high-to-low region,

$$
|\xi|\sim|\eta|\sim N,
\qquad
|\xi+\eta|\sim K,
$$

C3 proved

$$
\boxed{
|m_{\mathrm{sym}}(\xi,\eta)|
\lesssim_\beta
K^2N^{\beta-2}.
}
$$

The resulting remote critical-dissipation exponent is

$$
\boxed{
\rho_{\mathrm{mic}}
=
s_c+3
=
4+\beta-2\alpha
\ge5.
}
$$

---

# 2. Natural antipodal Fourier tiles

Partition the parent annulus $|\xi|\sim N$ into bounded-overlap Fourier tiles $\tau$ of side length

$$
h\asymp K.
$$

Let

$$
\theta_{p,\tau}
$$

be the corresponding localized component and define

$$
e_\tau(t)
:=
\|\theta_{p,\tau}(t)\|_2^2.
$$

Let

$$
E_p(t)
:=
\sum_\tau e_\tau(t).
$$

Up to the fixed bounded-overlap constant,

$$
E_p(t)
\asymp
\|\theta_p(t)\|_2^2.
$$

Two natural tiles $\tau$ and $\sigma$ are joined by an edge when their sum can produce output frequency $K$:

$$
(\tau+\sigma)
\cap
\{\zeta:|\zeta|\sim K\}
\ne\varnothing.
$$

C3 gives a fixed degree bound

$$
\boxed{
\deg(\tau)\le\Delta_*
}
$$

with $\Delta_*$ independent of the remote gap $M$.

The number of natural tiles in the parent annulus obeys

$$
\#\{\tau\}
\lesssim
\left(\frac NK\right)^2,
$$

and hence the number of natural antipodal edges obeys

$$
\boxed{
\#\mathcal E_{p,q}
\lesssim
\left(\frac NK\right)^2
\sim
2^{2M}.
}
$$

This count is used only at the canonical resolution $h\asymp K$.

---

# 3. Edge trilinear amplitudes

For an antipodal edge

$$
e=(\tau,\sigma),
$$

let $\mathfrak z_e(t)$ denote the complex trilinear amplitude obtained by restricting the symmetrized high--high interaction to the pair $(\tau,\sigma)$ and testing the output against $\theta_q$ with the critical weight $K^{2s_c}$.

The physical shell-energy transfer contributed by this edge is

$$
\operatorname{Re}\mathfrak z_e(t).
$$

C3-T1 and the natural-tile convolution estimate give

$$
\boxed{
|\mathfrak z_e(t)|
\le
C_\beta
\Gamma_{p,q}(t)
\sqrt{e_\tau(t)e_\sigma(t)},
}
\tag{3.1}
$$

where

$$
\boxed{
\Gamma_{p,q}(t)
:=
K^{2s_c+3}
N^{\beta-2}
\|\theta_q(t)\|_2.
}
\tag{3.2}
$$

For an interval $I$, define the integrated complex edge amplitude

$$
\boxed{
Z_e[I]
:=
\int_I
\mathfrak z_e(t)\,dt
}
\tag{3.3}
$$

and the rigorous edge envelope

$$
\boxed{
A_e[I]
:=
C_\beta
\int_I
\Gamma_{p,q}(t)
\sqrt{e_\tau(t)e_\sigma(t)}
\,dt.
}
\tag{3.4}
$$

Then

$$
\boxed{
|Z_e[I]|
\le
A_e[I].
}
\tag{3.5}
$$

Define

$$
A_{p,q}[I]
:=
\sum_{e\in\mathcal E_{p,q}}A_e[I],
$$

and

$$
U_{p,q}[I]
:=
\sum_{e\in\mathcal E_{p,q}}|Z_e[I]|.
$$

The signed integrated payment of this parent class is

$$
\boxed{
F_{p,q}[I]
:=
\operatorname{Re}
\sum_{e\in\mathcal E_{p,q}}
Z_e[I].
}
\tag{3.6}
$$

We will apply the theory only when

$$
F_{p,q}[I]>0.
$$

---

# 4. Temporal survival and signed coherence

Define the temporal survival coefficient

$$
\boxed{
\mathcal T_{p,q}[I]
:=
\frac{U_{p,q}[I]}
{A_{p,q}[I]}
}
\tag{4.1}
$$

when $A_{p,q}[I]>0$, with value $0$ when the denominator vanishes.

By construction,

$$
0\le\mathcal T_{p,q}[I]\le1.
$$

It measures how much of the rigorous edge envelope survives cancellation inside each spacetime edge before different edges are summed together.

For positive payment define the signed cross-edge coherence

$$
\boxed{
\mathcal C_{\mathrm{sgn},p,q}[I]
:=
\frac{F_{p,q}[I]}
{U_{p,q}[I]}.
}
\tag{4.2}
$$

Since

$$
F_{p,q}[I]
\le
\left|
\sum_e Z_e[I]
\right|
\le
\sum_e|Z_e[I]|,
$$

we have

$$
0<\mathcal C_{\mathrm{sgn},p,q}[I]\le1.
$$

The combined flux coherence is

$$
\boxed{
\mathcal Q_{p,q}[I]
:=
\mathcal T_{p,q}[I]
\mathcal C_{\mathrm{sgn},p,q}[I].
}
\tag{4.3}
$$

The definitions give the exact factorization

$$
\boxed{
F_{p,q}[I]
=
\mathcal Q_{p,q}[I]
A_{p,q}[I].
}
\tag{4.4}
$$

Thus $\mathcal Q$ is not a descriptive statistic. It is the exact fraction of the absolute microlocal envelope that survives both temporal cancellation and cross-edge sign/phase cancellation in the direction of positive physical flux.

---

# 5. Envelope reduction to the critical-dissipation budget

Using

$$
2ab\le a^2+b^2
$$

and the bounded natural-tile degree,

$$
\sum_{e=(\tau,\sigma)}
\sqrt{e_\tau e_\sigma}
\lesssim
\Delta_*E_p.
$$

Therefore

$$
\boxed{
A_{p,q}[I]
\lesssim_\beta
\int_I
\Gamma_{p,q}(t)E_p(t)\,dt.
}
\tag{5.1}
$$

Define the parent-envelope budget

$$
\boxed{
\mathcal B_{p,q}[I]
:=
\int_I
\Gamma_{p,q}(t)E_p(t)\,dt.
}
\tag{5.2}
$$

Suppose $I$ lies inside a critical-shell first crossing with

$$
E_q(t)
=
K^{2s_c}\|\theta_q(t)\|_2^2
<b.
$$

Then

$$
\|\theta_q(t)\|_2
\le
b^{1/2}K^{-s_c}.
$$

Consequently,

$$
\mathcal B_{p,q}[I]
\le
b^{1/2}
K^{s_c+3}
N^{\beta-2}
\int_I E_p(t)\,dt.
$$

Using

$$
2(s_c+\alpha)-(\beta-2)
=
s_c+3
=
\rho_{\mathrm{mic}},
$$

we obtain

$$
\boxed{
\mathcal B_{p,q}[I]
\le
b^{1/2}
\left(\frac KN\right)^{\rho_{\mathrm{mic}}}
\mathfrak W_p[I],
}
\tag{5.3}
$$

where

$$
\boxed{
\mathfrak W_p[I]
:=
\int_I
N^{2(s_c+\alpha)}E_p(t)\,dt.
}
\tag{5.4}
$$

For $p=q+M+O(1)$,

$$
\boxed{
\mathcal B_{p,q}[I]
\lesssim
b^{1/2}
2^{-\rho_{\mathrm{mic}}M}
\mathfrak W_p[I].
}
\tag{5.5}
$$

---

# 6. C4-T1 — Coherence--occupancy product rigidity

## Theorem C4-T1

Assume a remote parent class pays

$$
\boxed{
F_{p,q}[I]
\ge
\eta>0.
}
\tag{6.1}
$$

Then

$$
\boxed{
\mathcal Q_{p,q}[I]
\mathfrak W_p[I]
\gtrsim_\beta
\eta
b^{-1/2}
2^{\rho_{\mathrm{mic}}M}.
}
\tag{6.2}
$$

Equivalently,

$$
\boxed{
\mathcal T_{p,q}[I]
\mathcal C_{\mathrm{sgn},p,q}[I]
\mathfrak W_p[I]
\gtrsim_\beta
\eta
b^{-1/2}
2^{\rho_{\mathrm{mic}}M}.
}
\tag{6.3}
$$

### Proof

From (4.4),

$$
F_{p,q}[I]
=
\mathcal Q_{p,q}[I]A_{p,q}[I].
$$

By (5.1) and (5.5),

$$
A_{p,q}[I]
\lesssim_\beta
b^{1/2}
2^{-\rho_{\mathrm{mic}}M}
\mathfrak W_p[I].
$$

Combining with (6.1) gives (6.2).

---

## Corollary C4-C1 — Near-minimal-cost coherence

If

$$
\mathfrak W_p[I]
\le R,
$$

then

$$
\boxed{
\mathcal Q_{p,q}[I]
\gtrsim_\beta
\frac{\eta}
{b^{1/2}R}
2^{\rho_{\mathrm{mic}}M}.
}
\tag{6.4}
$$

Since both factors in

$$
\mathcal Q
=
\mathcal T\mathcal C_{\mathrm{sgn}}
$$

belong to $[0,1]$, each factor separately satisfies

$$
\boxed{
\mathcal T_{p,q}[I]
\gtrsim_\beta
\frac{\eta}
{b^{1/2}R}
2^{\rho_{\mathrm{mic}}M},
}
\tag{6.5}
$$

and

$$
\boxed{
\mathcal C_{\mathrm{sgn},p,q}[I]
\gtrsim_\beta
\frac{\eta}
{b^{1/2}R}
2^{\rho_{\mathrm{mic}}M}.
}
\tag{6.6}
$$

If the right-hand side exceeds the reciprocal implicit constant, the assumed payment and occupancy cap are incompatible.

### Interpretation

C3 says a remote parent must pay an exponentially large dissipation cost. C4 adds a rigidity statement for configurations that come close to paying at that cost: they cannot simultaneously exhibit strong temporal cancellation and strong antipodal sign cancellation.

---

# 7. Coherence deficiency as an additional tax

For any threshold

$$
0<\chi\le1,
$$

if either

$$
\mathcal T_{p,q}[I]\le\chi
$$

or

$$
\mathcal C_{\mathrm{sgn},p,q}[I]\le\chi,
$$

then

$$
\mathcal Q_{p,q}[I]\le\chi.
$$

Therefore C4-T1 yields

$$
\boxed{
\mathfrak W_p[I]
\gtrsim_\beta
\eta
b^{-1/2}
\chi^{-1}
2^{\rho_{\mathrm{mic}}M}.
}
\tag{7.1}
$$

Thus poor temporal survival or poor signed coherence does not eliminate the branch for free. It increases the required critical-dissipation occupancy by the reciprocal coherence factor.

---

# 8. Complex phase coherence

Define the complex phase coherence

$$
\boxed{
\mathcal C_{\mathrm{ph}}
:=
\frac{
\left|\sum_e Z_e\right|
}{
\sum_e|Z_e|
}.
}
\tag{8.1}
$$

Then

$$
\boxed{
\mathcal C_{\mathrm{sgn}}
\le
\mathcal C_{\mathrm{ph}}
\le1.
}
\tag{8.2}
$$

Let

$$
p_e
:=
\frac{|Z_e|}{U},
\qquad
Z_e=|Z_e|e^{i\phi_e}.
$$

If

$$
\sum_e p_e e^{i\phi_e}
\ne0,
$$

write

$$
\phi_*
:=
\arg
\sum_e p_e e^{i\phi_e}.
$$

---

# 9. C4-T2 — Exact weighted phase-concentration identity

## Theorem C4-T2

With the notation above,

$$
\boxed{
\sum_e
p_e
\left|
e^{i\phi_e}-e^{i\phi_*}
\right|^2
=
2\left(1-\mathcal C_{\mathrm{ph}}\right).
}
\tag{9.1}
$$

### Proof

Expand the square:

$$
\left|
e^{i\phi_e}-e^{i\phi_*}
\right|^2
=
2-2\operatorname{Re}
\left(
e^{i(\phi_e-\phi_*)}
\right).
$$

Weight by $p_e$ and sum. By the definition of $\phi_*$,

$$
\operatorname{Re}
\left(
e^{-i\phi_*}
\sum_e p_e e^{i\phi_e}
\right)
=
\mathcal C_{\mathrm{ph}}.
$$

This gives (9.1).

---

## Corollary C4-C2 — Phase-mass concentration

For any

$$
0<\delta\le\pi,
$$

the total $p_e$-mass of edges satisfying

$$
|\phi_e-\phi_*|
\ge\delta
\pmod{2\pi}
$$

obeys

$$
\boxed{
\sum_{|\phi_e-\phi_*|\ge\delta}
p_e
\le
\frac{
1-\mathcal C_{\mathrm{ph}}
}{
2\sin^2(\delta/2)
}.
}
\tag{9.2}
$$

If

$$
\mathcal C_{\mathrm{sgn}}
\ge
1-\varepsilon,
$$

then

$$
\mathcal C_{\mathrm{ph}}
\ge
1-\varepsilon
$$

and the resultant direction also satisfies

$$
\boxed{
\cos\phi_*
=
\frac{
\mathcal C_{\mathrm{sgn}}
}{
\mathcal C_{\mathrm{ph}}
}
\ge
1-\varepsilon.
}
\tag{9.3}
$$

Thus near-perfect signed coherence forces both phase concentration and alignment of the common resultant phase with the positive physical-flux direction.

---

# 10. Effective pair rank

Define the actual integrated edge masses

$$
u_e
:=
|Z_e[I]|,
$$

and

$$
U
:=
\sum_e u_e.
$$

The effective pair rank is the inverse participation ratio

$$
\boxed{
\mathcal R_{\mathrm{eff}}
:=
\frac{U^2}
{\sum_e u_e^2}.
}
\tag{10.1}
$$

Whenever $U>0$,

$$
1
\le
\mathcal R_{\mathrm{eff}}
\le
\#\{e:u_e>0\}.
$$

At the canonical natural-tile resolution,

$$
\boxed{
\mathcal R_{\mathrm{eff}}
\lesssim
2^{2M}.
}
\tag{10.2}
$$

## Proposition C4-M1 — Canonical-resolution rank ceiling

At natural output-scale resolution $h\asymp K$,

$$
\boxed{
1\le\mathcal R_{\mathrm{eff}}
\lesssim
\left(\frac NK\right)^2
\sim2^{2M}.
}
\tag{10.3}
$$

Indeed,

$$
\mathcal R_{\mathrm{eff}}
\le
\#\{e:u_e>0\},
$$

and the C3 natural-tile count plus bounded antipodal partner degree gives

$$
\#\mathcal E_{p,q}
\lesssim
\left(\frac NK\right)^2.
$$

The quantity is used only after fixing the natural resolution $h\asymp K$; it is not claimed to be invariant under arbitrary artificial refinements.

---

# 11. Microlocal tile atoms

For

$$
0<\delta\le1,
$$

say that a $\delta$-tile atom occurs on $I$ if there exist $t\in I$ and a natural parent tile $\tau$ such that

$$
\boxed{
\frac{e_\tau(t)}{E_p(t)}
\ge
\delta.
}
\tag{11.1}
$$

If no $\delta$-tile atom occurs, then for every tile and every time,

$$
e_\tau(t)
<
\delta E_p(t).
$$

Hence for every partner edge,

$$
\sqrt{e_\tau(t)e_\sigma(t)}
\le
\delta E_p(t).
$$

Using (3.4),

$$
\boxed{
A_e[I]
\lesssim_\beta
\delta
\mathcal B_{p,q}[I].
}
\tag{11.2}
$$

Therefore

$$
\boxed{
|Z_e[I]|
\lesssim_\beta
\delta
\mathcal B_{p,q}[I].
}
\tag{11.3}
$$

---

# 12. C4-T3 — Atom--effective-rank rigidity

## Theorem C4-T3

Assume

$$
F_{p,q}[I]
\ge
\eta>0.
$$

If no $\delta$-tile atom occurs on $I$, then

$$
\boxed{
\mathcal R_{\mathrm{eff}}
\mathcal B_{p,q}[I]
\gtrsim_\beta
\frac{\eta}{\delta}.
}
\tag{12.1}
$$

Consequently,

$$
\boxed{
\mathcal R_{\mathrm{eff}}
\mathfrak W_p[I]
\gtrsim_\beta
\eta
\delta^{-1}
 b^{-1/2}
2^{\rho_{\mathrm{mic}}M}.
}
\tag{12.2}
$$

### Proof

By (11.3),

$$
\max_e u_e
\lesssim_\beta
\delta
\mathcal B_{p,q}[I].
$$

Also

$$
U
\ge
\left|\sum_e Z_e\right|
\ge
F_{p,q}[I]
\ge
\eta.
$$

Since

$$
\sum_e u_e^2
\le
\left(\max_e u_e\right)
\sum_e u_e,
$$

we get

$$
\mathcal R_{\mathrm{eff}}
=
\frac{U^2}{\sum_e u_e^2}
\ge
\frac{U}{\max_e u_e}
\gtrsim_\beta
\frac{\eta}
{\delta\mathcal B_{p,q}[I]}.
$$

This proves (12.1). Equation (12.2) follows from (5.5).

---

## Corollary C4-C3 — Bounded occupancy and bounded rank force an atom

Suppose

$$
\mathfrak W_p[I]
\le R
$$

and

$$
\mathcal R_{\mathrm{eff}}
\le R_*.
$$

Then a paying parent class with

$$
F_{p,q}[I]\ge\eta
$$

must contain a natural Fourier tile satisfying

$$
\boxed{
\frac{e_\tau(t_*)}{E_p(t_*)}
\gtrsim_\beta
\frac{
\eta
}{
b^{1/2}RR_*
}
2^{\rho_{\mathrm{mic}}M}
}
\tag{12.3}
$$

for some $t_*\in I$, unless the right-hand side exceeds $1$, in which case the assumed payment/budget/rank combination is impossible.

Thus the symmetric $L^2$ edge law does admit an atomicity theorem once bounded raw degree is replaced by bounded **effective paying-pair rank**.

---

# 13. C4-T4 — Coherent-rank ancestry refinement

Fix a critical-dissipation budget cap

$$
\mathfrak W_p[I]
\le R.
$$

A remote parent class paying

$$
F_{p,q}[I]\ge\eta
$$

then satisfies

$$
\boxed{
\mathcal T_{p,q}[I]
\gtrsim_\beta
\chi_*,
\qquad
\mathcal C_{\mathrm{sgn},p,q}[I]
\gtrsim_\beta
\chi_*,
}
\tag{13.1}
$$

where

$$
\boxed{
\chi_*
:=
\frac{\eta}
{b^{1/2}R}
2^{\rho_{\mathrm{mic}}M}
}
\tag{13.2}
$$

up to the fixed structural constant.

For any atom threshold $\delta$, one also has

$$
\boxed{
\text{$\delta$-tile atom}
\quad\vee\quad
\mathcal R_{\mathrm{eff}}
\gtrsim_\beta
\frac{\chi_*}{\delta}.
}
\tag{13.3}
$$

Thus, after excluding a critical-dissipation defect, the surviving remote ancestry has the form

$$
\boxed{
\text{temporally persistent}
\;\wedge\;
\text{signed coherent}
\;\wedge\;
\left(
\text{parent atom}
\;\vee\;
\text{large effective pair rank}
\right).
}
\tag{13.4}
$$

This is the central C4 classification.

---

# 14. C4-N1 — Coherence-only atomicity no-go

High coherence alone still does not force a tile atom.

Take $n$ disjoint antipodal partner edges. Give every endpoint tile equal normalized energy

$$
e_i=f_i=\frac1n.
$$

Assign equal, perfectly aligned positive integrated edge amplitudes

$$
Z_i=\frac1n.
$$

Choose the envelopes to be saturated:

$$
A_i=\frac1n.
$$

Then

$$
\boxed{
\mathcal T=1,
\qquad
\mathcal C_{\mathrm{sgn}}=1,
\qquad
\mathcal C_{\mathrm{ph}}=1,
}
$$

while

$$
\boxed{
\mathcal R_{\mathrm{eff}}=n
}
$$

and

$$
\boxed{
\max_i e_i
=\frac1n
\to0.
}
$$

Therefore

$$
\boxed{
\text{perfect signed coherence}
\not\Rightarrow
\text{microlocal atom}.
}
\tag{14.1}
$$

The C3 diffuse perfect matching is therefore not eliminated. It is precisely reclassified as a high-rank coherent diffuse ensemble.

---

# 15. C4-N2 — No unconditional extra remote-gap exponent

C3 constructed generic-angle high--high-to-low configurations satisfying

$$
|m_{\mathrm{sym}}|
\asymp
K^2N^{\beta-2}.
$$

A single such pair has

$$
\mathcal R_{\mathrm{eff}}=1
$$

and can have

$$
\mathcal T
=
\mathcal C_{\mathrm{sgn}}
=1.
$$

Hence coherence/rank information alone cannot produce a universal extra factor

$$
\left(\frac KN\right)^\sigma,
\qquad
\sigma>0,
$$

beyond the C3 exponent

$$
\rho_{\mathrm{mic}}=s_c+3.
$$

Therefore

$$
\boxed{
\text{C4 adds rigidity of near-paying configurations, not a new unconditional gap exponent.}
}
\tag{15.1}
$$

Any further universal exponent gain must use a genuinely new dynamical, spatial-overlap, or structural hypothesis.

---

# 16. Relation to A1-L2

A1-L2 partner-degree compensation required an asymmetric edge law. C3 showed that the natural gSQG tile interaction instead has a symmetric square-root structure and that bounded degree alone does not force atomicity.

C4 recovers the **philosophy** of A1-L2 at the correct coordinate:

$$
\boxed{
\text{bounded effective paying-pair rank}
+
\text{bounded occupancy}
+
\text{positive payment}
\Longrightarrow
\text{tile atom}.
}
$$

Thus the transferred complexity variable is not raw graph degree but the inverse-participation rank of the actual paying antipodal ensemble.

This is a proof-asset transformation rather than a literal reuse of A1-L2.

---

# 17. Bispectral interpretation

The edge amplitude $Z_e$ is a symbol-weighted third-order Fourier quantity: two parent frequencies interact with the conjugate output frequency. The normalized quantities

$$
\mathcal C_{\mathrm{ph}}
$$

and

$$
\mathcal C_{\mathrm{sgn}}
$$

therefore have a bispectral/bicoherence interpretation, but C4 uses them deterministically and locally in scale rather than as ensemble-averaged turbulence statistics.

Recent turbulence literature provides conceptual precedent that triadic phase organization can control nonlinear transfer direction and magnitude. C4 does not import any statistical closure or random-phase hypothesis from that literature.

---

# 18. Combined C4 ancestry tree

Combining C2, C3, and C4, a gSQG critical-shell first crossing enters the remote high--high branch only by paying the following hierarchy:

$$
\boxed{
\begin{aligned}
\text{critical-shell crossing}
\Longrightarrow{}&
\text{low deformation debt}
\vee
\text{near-shell critical cluster}
\vee
\text{long germ}
\\
&\vee
\text{critical-dissipation defect}
\\
&\vee
\Bigl[
\text{remote antipodal parent class}
\Bigr].
\end{aligned}
}
$$

For the remote class,

$$
\boxed{
\begin{aligned}
\text{remote payment}
\Longrightarrow{}&
\text{occupancy cost}
\gtrsim
2^{(s_c+3)M}
\\
&\text{and, near that cost, temporal persistence}
\\
&\text{and signed antipodal coherence}
\\
&\text{and}
\left(
\text{tile atom}
\vee
\text{large effective pair rank}
\right).
\end{aligned}
}\tag{18.1}
$$

The remaining diffuse obstruction is therefore not merely remote or numerous. It is a **high-rank coherent antipodal ensemble**.

---

# 19. What C4 achieves

C4 establishes:

1. a deterministic natural-tile spacetime coherence factorization;
2. a coherence--critical-dissipation product inequality;
3. an explicit reciprocal tax for temporal or signed-coherence deficiency;
4. a phase-concentration identity for high coherent transfer;
5. an effective paying-pair rank at canonical output-scale resolution;
6. an atom--rank rigidity theorem under bounded occupancy;
7. a precise reclassification of the C3 diffuse perfect matching as the high-rank coherent branch;
8. a no-go showing that coherence does not create a further universal remote-gap exponent.

---

# 20. What C4 does not achieve

C4 does not prove:

1. global regularity for supercritical gSQG;
2. elimination of the high-rank coherent ensemble;
3. a deterministic decay law for signed coherence in time;
4. spatial overlap of Fourier-coherent parent tiles;
5. that generic solutions cannot sustain large $\mathcal R_{\mathrm{eff}}$ and large $\mathcal C_{\mathrm{sgn}}$ simultaneously;
6. publication-level novelty of the exact theorem package.

---

# 21. C5 frontier

The surviving branch is

$$
\boxed{
\text{high-rank}
\;\wedge\;
\text{temporally persistent}
\;\wedge\;
\text{signed-coherent antipodal ensemble}.
}
$$

The next problem is therefore not another static partition refinement.

A natural next stage is

$$
\boxed{
\textbf{C5 — Spacetime Coherence Persistence and Dephasing Tax}.
}
$$

The main questions are:

1. What evolution equation is satisfied by the triad phase of a remote antipodal gSQG interaction?
2. Can a large number of paying edges remain phase locked over a first-crossing interval without producing an additional frequency or spatial-overlap defect?
3. Does variation of the gSQG symbol across an antipodal family force deterministic phase dispersion?
4. Can wave-packet localization turn Fourier coherence into a physical-space overlap tax?
5. Is there a rigorous alternative
   $$
   \text{coherence persistence}
   \vee
   \text{dephasing dissipation}
   \vee
   \text{wave-packet concentration}?
   $$

No random-phase hypothesis should be assumed.

---

# 22. Research status

The correct status is

$$
\boxed{
\text{INTERNALLY PROVED UNDER STATED HYPOTHESES; NOVELTY AUDIT OPEN.}
}
$$

The C4 claims are deterministic consequences of the C3 microlocal edge bound, natural-tile bounded degree, and the definitions introduced above. They should be independently checked before any external theorem claim.
