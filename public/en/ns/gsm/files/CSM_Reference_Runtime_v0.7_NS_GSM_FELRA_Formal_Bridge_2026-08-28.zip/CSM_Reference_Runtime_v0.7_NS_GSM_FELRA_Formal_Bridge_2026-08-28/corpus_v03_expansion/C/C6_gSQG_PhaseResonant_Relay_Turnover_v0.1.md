# C6 — Phase-Resonant Relay Turnover and Modulation Cost

**Version:** v0.1  
**Date:** 2026-08-17  
**Status:** internally proved under stated hypotheses; publication-level novelty audit open.

## Abstract

This note continues the C2--C5 transfer program for the fully nonlinear supercritical generalized surface quasi-geostrophic equation. C5 showed that a high-rank, temporally coherent remote ancestry can avoid large simultaneous coactivity through a small-duty sequential relay. The present note attacks that relay branch without identifying low duty with relay by fiat.

The main results are:

1. a representation-independent relay-depth statistic for normalized edge or tile activity;
2. a sharp simplex-variation lower bound: a relay through $R$ pairwise separated activity blocks forces at least order $R$ total variation;
3. a normalized-activity turnover theorem converting relay depth into variation of the underlying edge amplitudes;
4. an exact envelope-versus-gate turnover alternative for microlocal paying edges;
5. a PDE-level Fourier-tile energy turnover estimate for gSQG;
6. a dimensionless time-frequency modulation budget that upper-bounds genuine tile-energy relay depth;
7. a bounded-degree parent-envelope derivative estimate for natural antipodal Fourier-tile graphs;
8. a no-go theorem showing that instantaneous radial Gevrey control alone cannot bound same-shell angular/tile relay;
9. a master refinement: rapid sequential relay must pay through shell-energy turnover, microlocal correlation/gate turnover, or a large nonlinear time-frequency modulation budget.

No random-phase hypothesis, isolated-triad closure, or physical-space localization is assumed.

---

# 1. PDE setting and inherited state

We consider the dissipative gSQG family

$$
\partial_t\theta
+
\Lambda^{2\alpha}\theta
+
u_\theta\cdot\nabla\theta
=0,
$$

with

$$
\nu_\theta
=
\nabla^\perp\Lambda^{\beta-2}\theta,
$$

in the C2--C5 regime

$$
0<\alpha<\frac12,
\qquad
2\alpha+1\le\beta<2.
$$

The critical Sobolev exponent is

$$
s_c
=
1+\beta-2\alpha.
$$

C3 established the remote high--high microlocal suppression exponent

$$
\rho_{\mathrm{mic}}
=
s_c+3
=
4+\beta-2\alpha
\ge5.
$$

C4 and C5 refined a paying remote parent class into signed coherence, effective rank, spacetime phase persistence, phase-resonance/modulation defects, and the alternative

$$
\boxed{
\text{simultaneous high coactivity}
\quad\vee\quad
\text{small-duty temporal relay}.
}
$$

The purpose of C6 is to analyze the second branch.

---

# 2. Low duty is not automatically relay

Let $E$ be a finite or countable family of paying microlocal edges and let

$$
a_e(t)\ge0
$$

be the unsigned instantaneous edge activity inherited from C5.

Define

$$
S(t)
:=
\sum_{e\in E}a_e(t).
$$

Whenever $S(t)>0$, define the normalized activity distribution

$$
\boxed{
\pi_e(t)
:=
\frac{a_e(t)}{S(t)}.
}
$$

Then

$$
\pi_e(t)\ge0,
\qquad
\sum_e\pi_e(t)=1.
$$

C5's small duty coefficient measures intermittency in time. It does **not** by itself prove that the normalized activity vector $\pi(t)$ travels through many distinct regions of the probability simplex. C6 therefore introduces relay depth explicitly.

---

# 3. C6-D1 — Relay depth

Fix

$$
0\le\varepsilon<\frac12.
$$

## Definition C6-D1

The $\varepsilon$-relay depth of $\pi$ on an interval $J$ is the largest integer $R$ for which there exist times

$$
t_1<t_2<\cdots<t_R
$$

and pairwise disjoint edge blocks

$$
B_1,\ldots,B_R\subset E
$$

such that

$$
\boxed{
\pi(t_j)(B_j)
:=
\sum_{e\in B_j}\pi_e(t_j)
\ge
1-\varepsilon
}
$$

for every $j$.

We denote this quantity by

$$
\mathfrak R_\varepsilon(\pi;J).
$$

The definition allows a relay block to contain many diffuse edges. Thus it does not identify relay with a single-edge or single-tile atom.

---

# 4. C6-T1 — Simplex relay-turnover lower bound

## Theorem C6-T1

Let

$$
R
=
\mathfrak R_\varepsilon(\pi;J).
$$

Then

$$
\boxed{
\operatorname{Var}_{\ell^1}(\pi;J)
\ge
2(1-2\varepsilon)(R-1).
}
$$

Here

$$
\operatorname{Var}_{\ell^1}(\pi;J)
$$

is the total variation of the curve $t\mapsto\pi(t)$ in $\ell^1(E)$.

### Proof

At consecutive relay times $t_j,t_{j+1}$, the blocks $B_j$ and $B_{j+1}$ are disjoint. Hence

$$
\pi(t_j)(B_j)
\ge
1-\varepsilon,
$$

while

$$
\pi(t_{j+1})(B_j)
\le
\varepsilon.
$$

Therefore

$$
\left|
\pi(t_j)(B_j)
-
\pi(t_{j+1})(B_j)
\right|
\ge
1-2\varepsilon.
$$

For probability vectors, total variation distance is half the $\ell^1$ distance, so

$$
\|\pi(t_{j+1})-\pi(t_j)\|_{\ell^1}
\ge
2(1-2\varepsilon).
$$

Summing along the ordered relay times gives the claim.

---

# 5. C6-T2 — Activity-turnover tax

Assume now that every $a_e$ is absolutely continuous on $J$ and that the relay is observed on an active core satisfying

$$
\boxed{
S(t)\ge s_*>0
}
$$

for almost every $t\in J$.

## Theorem C6-T2

Under these assumptions,

$$
\boxed{
\operatorname{Var}_{\ell^1}(\pi;J)
\le
\frac{2}{s_*}
\sum_e
\int_J|a_e'(t)|\,dt.
}
$$

Consequently,

$$
\boxed{
\sum_e
\|a_e'\|_{L^1(J)}
\ge
s_*(1-2\varepsilon)
\left(
\mathfrak R_\varepsilon(\pi;J)-1
\right).
}
$$

### Proof

Since

$$
\pi_e
=
\frac{a_e}{S},
$$

we have

$$
\pi_e'
=
\frac{a_e'}{S}
-
\frac{a_eS'}{S^2}.
$$

Summing absolute values,

$$
\sum_e|\pi_e'|
\le
\frac{1}{S}\sum_e|a_e'|
+
\frac{|S'|}{S}.
$$

Because

$$
|S'|
\le
\sum_e|a_e'|,
$$

and $S\ge s_*$,

$$
\sum_e|\pi_e'|
\le
\frac{2}{s_*}
\sum_e|a_e'|.
$$

Integrating and combining with C6-T1 proves the result.

---

# 6. C6-D2 — Envelope and gate turnover

C3--C5 provide pointwise microlocal envelopes. For C6 it is useful to write the unsigned activity in the factorized form

$$
\boxed{
a_e(t)
=
B_e(t)g_e(t),
}
$$

where

$$
B_e(t)\ge0,
\qquad
0\le g_e(t)\le1.
$$

Here $B_e$ is a nonnegative analytic envelope determined by shell/tile amplitudes and the microlocal symbol bound. The factor $g_e$ contains the remaining correlation/saturation information required for the true edge amplitude to approach that envelope.

Define

$$
\boxed{
\mathfrak V_B[J]
:=
\sum_e\int_J|B_e'(t)|\,dt,
}
$$

and

$$
\boxed{
\mathfrak V_g[J]
:=
\sum_e\int_JB_e(t)|g_e'(t)|\,dt.
}
$$

The second quantity is a weighted correlation/gate-turnover budget.

---

# 7. C6-T3 — Envelope-turnover / gate-turnover alternative

## Theorem C6-T3

Assume the hypotheses of C6-T2 and the factorization

$$
a_e=B_eg_e.
$$

Then

$$
\boxed{
\mathfrak V_B[J]
+
\mathfrak V_g[J]
\ge
s_*(1-2\varepsilon)
\left(
\mathfrak R_\varepsilon(\pi;J)-1
\right).
}
$$

Therefore a large genuine relay depth requires at least one of

$$
\boxed{
\mathfrak V_B[J]
\gtrsim
s_*\mathfrak R_\varepsilon
}
$$

or

$$
\boxed{
\mathfrak V_g[J]
\gtrsim
s_*\mathfrak R_\varepsilon.
}
$$

### Proof

By the product rule,

$$
|a_e'|
=
|(B_eg_e)'|
\le
|B_e'|g_e+B_e|g_e'|.
$$

Since $0\le g_e\le1$,

$$
|a_e'|
\le
|B_e'|+B_e|g_e'|.
$$

Sum over $e$, integrate over $J$, and apply C6-T2.

### Interpretation

A sequential relay cannot be hidden inside the phrase ``small duty.'' It must be implemented dynamically by either:

1. moving the analytic parent-energy envelope among different edge blocks; or
2. keeping the envelope relatively fixed while rapidly changing which microlocal correlations actually saturate it.

The second mechanism includes amplitude/correlation gating and is logically distinct from the phase-velocity defect already isolated in C5.

---

# 8. Fourier-tile energy turnover

We now connect a genuine same-shell relay to the PDE.

Fix a parent annulus $p$ and decompose it into natural Fourier tiles $\tau$ using a uniformly almost-orthogonal smooth partition. Write

$$
\theta_{p,\tau}
:=
P_{p,\tau}\theta.
$$

Define tile energies

$$
\boxed{
e_\tau(t)
:=
\|\theta_{p,\tau}(t)\|_2^2
}
$$

and parent-annulus energy

$$
\boxed{
E_p(t)
:=
\sum_\tau e_\tau(t).
}
$$

Whenever $E_p(t)>0$, define the normalized tile-energy distribution

$$
\boxed{
\mu_\tau(t)
:=
\frac{e_\tau(t)}{E_p(t)}.
}
$$

Then

$$
\mu_\tau\ge0,
\qquad
\sum_\tau\mu_\tau=1.
$$

---

# 9. C6-P1 — Tile-energy derivative bound

Let

$$
\mathcal N(\theta)
:=
\nu_\theta\cdot\nabla\theta.
$$

For a smooth solution,

$$
\partial_t\theta
=
-\Lambda^{2\alpha}\theta
-\mathcal N(\theta).
$$

Since the Fourier tile projections commute with the radial dissipative multiplier,

$$
\frac12e_\tau'
+
\|\Lambda^\alpha\theta_{p,\tau}\|_2^2
=
-
\operatorname{Re}
\langle
P_{p,\tau}\mathcal N(\theta),
\theta_{p,\tau}
\rangle.
$$

Consequently,

$$
|e_\tau'|
\le
2\|\Lambda^\alpha\theta_{p,\tau}\|_2^2
+
2\|P_{p,\tau}\mathcal N(\theta)\|_2
\|\theta_{p,\tau}\|_2.
$$

Summing over the almost-orthogonal tile family gives

$$
\boxed{
\sum_\tau|e_\tau'|
\lesssim
2D_p(t)
+
2N_p(t)E_p(t)^{1/2},
}
$$

where

$$
D_p(t)
:=
\|\Lambda^\alpha\theta_p(t)\|_2^2
$$

and

$$
N_p(t)
:=
\|\widetilde P_p\mathcal N(\theta)(t)\|_2.
$$

The harmless constants depend only on the fixed Littlewood--Paley/tile overlap convention.

---

# 10. C6-T4 — PDE tile-relay modulation bound

## Theorem C6-T4

Assume

$$
E_p(t)>0
$$

throughout an interval $J$. Then

$$
\boxed{
\operatorname{Var}_{\ell^1}(\mu;J)
\lesssim
4
\int_J
\left(
\frac{D_p(t)}{E_p(t)}
+
\frac{N_p(t)}{E_p(t)^{1/2}}
\right)dt.
}
$$

Define the dimensionless parent-shell modulation budget

$$
\boxed{
\mathfrak M_p[J]
:=
\int_J
\left(
\frac{D_p(t)}{E_p(t)}
+
\frac{N_p(t)}{E_p(t)^{1/2}}
\right)dt.
}
$$

If the normalized tile-energy distribution has $\varepsilon$-relay depth $R$, then

$$
\boxed{
R-1
\lesssim
\frac{2}{1-2\varepsilon}
\mathfrak M_p[J].
}
$$

### Proof

Differentiate

$$
\mu_\tau
=
\frac{e_\tau}{E_p}.
$$

Since

$$
|E_p'|
\le
\sum_\tau|e_\tau'|,
$$

we obtain

$$
\sum_\tau|\mu_\tau'|
\le
\frac{2}{E_p}
\sum_\tau|e_\tau'|.
$$

Apply C6-P1 and integrate. The relay-depth estimate then follows from C6-T1.

---

# 11. Parabolic-time form

On the parent annulus,

$$
D_p(t)
\sim
\lambda_p^{2\alpha}E_p(t)
$$

up to fixed annular constants. Thus

$$
\mathfrak M_p[J]
\lesssim
C\lambda_p^{2\alpha}|J|
+
\int_J
\frac{N_p(t)}{E_p(t)^{1/2}}dt.
$$

Define the parent normalized duration

$$
\boxed{
L_p[J]
:=
\lambda_p^{2\alpha}|J|.
}
$$

Then

$$
\boxed{
R-1
\lesssim
\frac{C}{1-2\varepsilon}
\left[
L_p[J]
+
\int_J
\frac{N_p(t)}{\|\theta_p(t)\|_2}dt
\right].
}
$$

Hence a relay through arbitrarily many almost-disjoint tile blocks cannot occur at bounded normalized duration and bounded nonlinear modulation cost.

This is the first direct PDE-level relay-count estimate in the C2--C6 chain.

---

# 12. C6-P2 — Natural antipodal envelope turnover

C3 showed that at the natural output-scale tile resolution the antipodal partner graph has uniformly bounded degree.

Let

$$
G=(V,E)
$$

be such a graph, with

$$
\deg(i)\le D_0.
$$

For each parent tile $i$, write

$$
x_i(t)
:=
\|P_i\theta(t)\|_2.
$$

Consider a static weighted pair envelope

$$
\boxed{
B_{ij}(t)
:=
c_{ij}x_i(t)x_j(t),
}
$$

where

$$
0\le c_{ij}\le c_*.
$$

The C3 remote symbol factor and the common child-shell factor may be absorbed into $c_{ij}$ and a common prefactor when comparing the normalized parent-edge distribution.

## Proposition C6-P2

Whenever the tile amplitudes are absolutely continuous,

$$
\boxed{
\sum_{(i,j)\in E}|B_{ij}'(t)|
\le
2D_0c_*
\|x(t)\|_{\ell^2}
\|x'(t)\|_{\ell^2}.
}
$$

Moreover,

$$
|x_i'(t)|
\le
\|P_i\partial_t\theta(t)\|_2
$$

for almost every time at which $x_i>0$, with the standard absolutely-continuous extension through zeros. Hence

$$
\boxed{
\mathfrak V_B[J]
\lesssim
2D_0c_*
\int_J
\|\widetilde P_p\theta(t)\|_2
\|\widetilde P_p\partial_t\theta(t)\|_2dt.
}
$$

Using the gSQG equation,

$$
\boxed{
\mathfrak V_B[J]
\lesssim
C D_0c_*
\int_J
\left[
\lambda_p^{2\alpha}
\|\widetilde P_p\theta\|_2^2
+
\|\widetilde P_p\theta\|_2
\|\widetilde P_p\mathcal N(\theta)\|_2
\right]dt.
}
$$

### Proof

Differentiate the pair envelope:

$$
|B_{ij}'|
\le
c_*
\left(
|x_i'|x_j+x_i|x_j'|
\right).
$$

For the first term,

$$
\sum_{(i,j)\in E}|x_i'|x_j
\le
\left(
\sum_{(i,j)\in E}|x_i'|^2
\right)^{1/2}
\left(
\sum_{(i,j)\in E}x_j^2
\right)^{1/2}.
$$

The degree bound gives

$$
\sum_{(i,j)\in E}|x_i'|^2
\le
D_0\|x'\|_{\ell^2}^2,
$$

and

$$
\sum_{(i,j)\in E}x_j^2
\le
D_0\|x\|_{\ell^2}^2.
$$

Thus the first term is at most

$$
D_0\|x'\|_{\ell^2}\|x\|_{\ell^2}.
$$

The second term is identical. Almost orthogonality and the equation then give the remaining claims.

---

# 13. C6-T5 — Phase-resonant relay turnover alternative

Combine C6-T3 with C6-P2.

## Theorem C6-T5

Consider an active remote parent class on $J$ with

$$
S(t)\ge s_*>0.
$$

Assume its unsigned edge activities factor as

$$
a_e=B_eg_e,
$$

where $B_e$ is the natural antipodal parent envelope and $0\le g_e\le1$.

If

$$
R
=
\mathfrak R_\varepsilon(\pi;J),
$$

then

$$
\boxed{
\begin{aligned}
s_*(1-2\varepsilon)(R-1)
\lesssim{}&
C D_0c_*
\int_J
\left[
\lambda_p^{2\alpha}
\|\widetilde P_p\theta\|_2^2
+
\|\widetilde P_p\theta\|_2
\|\widetilde P_p\mathcal N(\theta)\|_2
\right]dt
\\
&+
\mathfrak V_g[J].
\end{aligned}
}
$$

Therefore a high-depth coherent relay requires at least one of:

$$
\boxed{
\text{large dissipative/time-frequency parent turnover},
}
$$

$$
\boxed{
\text{large nonlinear parent modulation},
}
$$

or

$$
\boxed{
\text{large microlocal gate/correlation turnover}.
}
$$

This theorem does not assume that a low C5 duty factor automatically has large relay depth. Instead it gives a quantitative tax whenever the sequential-relay interpretation is genuinely realized.

---

# 14. C6-N1 — Gevrey smoothing alone does not control same-shell relay

Instantaneous Gevrey smoothing is an important regularity fact for dissipative gSQG, but a radial Gevrey norm by itself does not control angular or tile switching within one fixed annulus.

## No-Go C6-N1

Let $k_1,k_2\in\mathbb Z^2$ satisfy

$$
|k_1|
=
|k_2|
=N,
$$

for example

$$
k_1=(N,0),
\qquad
k_2=(0,N).
$$

Define a smooth real Fourier path

$$
f_\omega(t,x)
=
a\cos(\omega t)\cos(k_1\cdot x)
+
a\sin(\omega t)\cos(k_2\cdot x).
$$

For every radial multiplier $M(\Lambda)$,

$$
\boxed{
\|M(\Lambda)f_\omega(t)\|_2
}
$$

is independent of $t$ and $\omega$.

In particular, all radial Sobolev or Gevrey norms of the form

$$
\|e^{\sigma\Lambda^\rho}\Lambda^s f_\omega(t)\|_2
$$

remain constant in time.

However, the normalized energies of the two tiles are

$$
\mu_1(t)
=
\cos^2(\omega t),
$$

$$
\mu_2(t)
=
\sin^2(\omega t),
$$

and therefore

$$
\operatorname{Var}_{\ell^1}(\mu;[0,T])
$$

grows linearly with $\omega T$.

Thus

$$
\boxed{
\text{uniform radial Gevrey control}
\not\Rightarrow
\text{uniform same-shell tile-turnover control}.
}
$$

### Meaning

This counterexample is not asserted to be a gSQG solution. It proves the narrower and necessary statement that a bound on radial Gevrey norms alone is insufficient to exclude rapid angular relay. To exploit Gevrey smoothing in C6 one must combine it with an actual time-regularity estimate, such as control of

$$
\partial_t\theta,
$$

or equivalently use the PDE through C6-T4 or C6-P2.

---

# 15. C6-C1 — Gevrey plus time regularity

Suppose that on a positive-time interval

$$
J=[\tau,T],
\qquad
\tau>0,
$$

one has a PDE-derived bound

$$
\int_J
\frac{
\|\widetilde P_p\partial_t\theta(t)\|_2
}{
\|\widetilde P_p\theta(t)\|_2
}dt
\le
M_{p,\tau,T}.
$$

Then C6-P2 and C6-T4 convert this into a finite same-shell relay budget. Instantaneous Gevrey smoothing can be useful for proving the regularity needed to make such quantities meaningful, but C6-N1 shows that the Gevrey norm itself is not the turnover bound.

---

# 16. C6-N2 — A static high-rank distribution is not relay

A second no-go clarifies the relation to C5.

Let

$$
\pi_e(t)
\equiv
\frac1R
$$

for $R$ edges throughout $J$. Then

$$
\mathcal R_V=R,
$$

but

$$
\operatorname{Var}_{\ell^1}(\pi;J)=0.
$$

This configuration is not a sequential relay. It is a simultaneous diffuse high-rank ensemble, precisely the branch already separated by C5's concurrency variable.

Therefore

$$
\boxed{
\text{high integrated rank}
\not\Rightarrow
\text{large relay depth}.
}
$$

A turnover theorem must be conditioned on genuine movement of the activity distribution or derived from additional concurrency/duty information.

---

# 17. C6 master refinement

Combining C4--C6, a paying remote high--high ancestry now satisfies the following research-routing tree.

After excluding parent-atom and critical-dissipation defects, C4--C5 require signed coherence, temporal phase persistence, and high effective paying rank. C5 then gives

$$
\boxed{
\text{simultaneous high coactivity}
\quad\vee\quad
\text{small-duty temporal organization}.
}
$$

C6 refuses to rename the second branch ``relay'' automatically. If the small-duty organization has large genuine relay depth, then

$$
\boxed{
\begin{aligned}
\text{large relay depth}
\Longrightarrow{}&
\text{large shell-energy/time-frequency modulation}
\\
&\vee
\text{large parent-envelope turnover}
\\
&\vee
\text{large microlocal gate/correlation turnover}.
\end{aligned}
}
$$

Meanwhile C5 independently supplies

$$
\boxed{
\text{many phase-resonant edges}
\quad\vee\quad
\text{large phase/amplitude modulation defect}.
}
$$

Thus a low-cost surviving remote ancestry must become increasingly organized in **both** phase and support dynamics.

---

# 18. What C6 proves and does not prove

C6 proves:

1. genuine sequential relay has a sharp deterministic simplex-length cost;
2. on an active core, this forces total variation of the actual paying amplitudes;
3. paying-amplitude variation splits into analytic-envelope turnover and correlation/gate turnover;
4. Fourier-tile energy relay is bounded by an explicit gSQG time-frequency modulation budget;
5. natural antipodal parent-envelope turnover is controlled by $\theta_p$ and $\partial_t\theta_p$;
6. Gevrey smoothing alone cannot suppress same-shell angular switching without a time-regularity input.

C6 does **not** prove:

1. that every C5 low-duty configuration has large relay depth;
2. that gate/correlation turnover is automatically large or impossible;
3. that a phase-resonant relay cannot occur;
4. that gSQG is globally regular for large data;
5. that Fourier relay implies physical-space transport or localization;
6. that Gevrey smoothing by itself bounds Fourier-tile switching.

---

# 19. Literature position

The dissipative gSQG critical-space theory of Jolly--Kumar--Martinez establishes existence, uniqueness, and instantaneous Gevrey smoothing in supercritical regimes while preserving the equation's commutator structure. Kumar's 2026 work studies global small-data behavior and decay in the fully nonlinear supercritical regime used by C2--C6.

Recent turbulence work on triad phases provides independent motivation for regarding phase organization as dynamically relevant to spectral transfer, but those works use shell-model or statistical/closure viewpoints. C6 remains deterministic and does not import a random-phase closure.

The present finite literature search did not identify the exact relay-depth/simplex-variation plus gSQG tile-turnover theorem package above. This is not a publication-level novelty determination.

---

# 20. C7 handoff

C6 isolates one remaining branch that is now more precise than ``rapid relay'':

$$
\boxed{
\text{large microlocal gate/correlation turnover}.
}
$$

Recommended next title:

$$
\boxed{
\textbf{C7 — Correlation-Gate Evolution and Commutator Turnover}
}
$$

Priority questions:

1. Write the actual natural-tile edge saturation
   $$
   g_e(t)
   =
   \frac{a_e(t)}{B_e(t)}
   $$
   away from envelope zeros and differentiate a regularized version.
2. Determine whether
   $$
   \mathfrak V_g[I]
   $$
   can be controlled by commutator norms already present in critical gSQG theory.
3. Separate three mechanisms inside gate turnover:
   $$
   \text{parent-shape rotation},
   \qquad
   \text{child-overlap rotation},
   \qquad
   \text{symbol-null crossing}.
   $$
4. Seek a theorem of the form
   $$
   \text{large gate turnover}
   \Longrightarrow
   \text{large commutator budget}
   \vee
   \text{near-envelope-zero defect}.
   $$
5. Introduce wave packets only if controlling the gate requires genuine physical overlap information.

The C6 prohibition remains:

$$
\boxed{
\text{Fourier turnover}
\not\Rightarrow
\text{physical-space transport}
}
$$

without an additional localization argument.

---

# 21. Final C6 state

The proof-asset path now reads

$$
\boxed{
\begin{aligned}
\text{NS proof assets}
&\longrightarrow
\text{gSQG critical-shell crossing}
\\
&\longrightarrow
\text{remote antipodal parent geometry}
\\
&\longrightarrow
\text{microlocal symbol cancellation}
\\
&\longrightarrow
\text{signed coherence and effective rank}
\\
&\longrightarrow
\text{spacetime phase persistence}
\\
&\longrightarrow
\text{phase resonance / modulation defect}
\\
&\longrightarrow
\text{simultaneous coactivity / temporal organization}
\\
&\longrightarrow
\text{relay depth / turnover tax}
\\
&\longrightarrow
\text{PDE modulation or correlation-gate turnover}.
\end{aligned}
}
$$

The surviving obstruction is therefore no longer merely ``many coherent Fourier parents.'' A true sequential escape route must now move a normalized paying distribution through a long path in activity space, and gSQG forces that path to be financed by explicit time-frequency or microlocal correlation turnover.
