# C5 — Spacetime Coherence Persistence, Phase Resonance, and Relay Rigidity

**Series:** NS Proof-Asset Transfer → gSQG Escape Line  
**Version:** v0.1  
**Date:** 2026-08-17  
**Status:** internally proved under the stated smoothness/microlocal hypotheses; publication-level novelty audit remains open.

## Abstract

This note continues C2--C4 for the fully nonlinear supercritical generalized surface quasi-geostrophic equation. C4 reduced a paying remote high--high ancestry to a temporally surviving, signed-coherent, high-effective-rank antipodal family unless a critical-dissipation or parent-atom defect occurs. The present note asks what such coherence means dynamically.

The main conclusions are:

1. the C4 temporal-survival factor admits an exact refinement into **analytic-envelope saturation** and **true temporal phase persistence**;
2. the resulting spacetime phase field obeys exact weighted concentration identities, so near-minimal-cost positive flux forces the actual edge-time phases to concentrate near the positive-flux direction;
3. for active Fourier modes, the dissipative multiplier does not rotate phase, and the exact triad-phase velocity is generated entirely by the nonlinear Fourier term;
4. the fixed gSQG symbol produces static sign/null geometry but no temporal dephasing by itself;
5. a deterministic nonstationary-phase estimate yields a **phase-resonance versus modulation-defect alternative**;
6. when the C4 effective rank is large, either many paying edges encounter phase-velocity resonance or the ensemble pays a large dephasing/modulation budget;
7. high integrated effective rank does not imply simultaneous high rank: a perfectly coherent sequential relay is an exact counterexample;
8. an exact rank--duty factorization separates genuine simultaneous coactivity from temporal relay/intermittency.

Thus the surviving C5 obstruction is no longer merely a high-rank coherent antipodal family. It is forced into a sharper set of possibilities: a simultaneously coactive phase-resonant family, a strongly modulated/dephasing family, or a temporally relayed coherent family.

---

# 1. gSQG and inherited C4 notation

We work with

$$
\partial_t\theta
+
\Lambda^{2\alpha}\theta
+
u_\theta\cdot\nabla\theta
=
0,
$$

where

$$
u_\theta
=
\nabla^\perp\Lambda^{\beta-2}\theta,
$$

in the fully nonlinear range

$$
0<\alpha<\frac12,
\qquad
2\alpha+1\le\beta<2.
$$

The scaling-critical Sobolev index is

$$
\boxed{
 s_c=1+\beta-2\alpha.
}
$$

For a remote parent scale $N\sim\lambda_p$ and low output scale $K\sim\lambda_q$, write

$$
p=q+M+O(1),
\qquad
M\gg1.
$$

C3 established the symmetrized high--high-to-low symbol

$$
\boxed{
 m_{\mathrm{sym}}(\xi,\eta)
 =
 -\frac12
 (\xi^\perp\!\cdot\eta)
 \left(
 |\xi|^{\beta-2}
 -
 |\eta|^{\beta-2}
 \right)
}
$$

and the remote exponent

$$
\boxed{
 \rho_{\mathrm{mic}}
 =
 s_c+3
 =
 4+\beta-2\alpha
 \ge5.
}
$$

At natural output-scale Fourier-tile resolution, C4 assigns to each antipodal edge $e$ an instantaneous complex edge amplitude

$$
\mathfrak z_e(t),
$$

an integrated amplitude

$$
Z_e[I]
=
\int_I\mathfrak z_e(t)\,dt,
$$

and a rigorous absolute envelope

$$
A_e[I].
$$

Define

$$
A[I]
=
\sum_e A_e[I],
$$

$$
U[I]
=
\sum_e|Z_e[I]|,
$$

and the positive signed payment

$$
F[I]
=
\operatorname{Re}\sum_e Z_e[I].
$$

C4 defined

$$
\mathcal T
=
\frac{U}{A},
$$

$$
\mathcal C_{\mathrm{sgn}}
=
\frac{F}{U},
$$

and therefore

$$
\frac FA
=
\mathcal T\mathcal C_{\mathrm{sgn}}.
$$

For a paying remote class,

$$
F[I]\ge\eta>0,
$$

C4 proved

$$
\boxed{
 \mathcal T
 \mathcal C_{\mathrm{sgn}}
 \mathfrak W_p[I]
 \gtrsim_\beta
 \eta b^{-1/2}
 2^{\rho_{\mathrm{mic}}M}.
}
$$

C5 begins by separating two logically different effects that were both contained in $\mathcal T$.

---

# 2. Instantaneous edge mass and the missing temporal factorization

Write the polar decomposition

$$
\mathfrak z_e(t)
=
a_e(t)e^{i\phi_e(t)},
\qquad
 a_e(t)=|\mathfrak z_e(t)|.
$$

At zeros of $\mathfrak z_e$, the phase is irrelevant and may be chosen arbitrarily.

Define the unsigned spacetime edge mass

$$
\boxed{
 v_e[I]
 :=
 \int_I a_e(t)\,dt
}
$$

and

$$
\boxed{
 V[I]
 :=
 \sum_e v_e[I].
}
$$

Because

$$
|\mathfrak z_e(t)|
\le
\text{the C3/C4 pointwise edge envelope},
$$

we have

$$
0\le V\le A.
$$

Also

$$
|Z_e|
\le
v_e,
$$

so

$$
0\le U\le V.
$$

This produces two new dimensionless factors.

## Definition C5-D1 — Envelope saturation

$$
\boxed{
 \mathcal E[I]
 :=
 \frac{V[I]}{A[I]}
}
$$

when $A>0$, and $0$ otherwise.

Thus

$$
0\le\mathcal E\le1.
$$

It measures the slack between the rigorous absolute microlocal envelope and the actual unsigned trilinear amplitude.

## Definition C5-D2 — True temporal phase persistence

$$
\boxed{
 \mathcal P[I]
 :=
 \frac{U[I]}{V[I]}
}
$$

when $V>0$, and $0$ otherwise.

Again

$$
0\le\mathcal P\le1.
$$

Unlike $\mathcal T$, $\mathcal P$ measures only cancellation in time inside the actual complex edge amplitudes.

---

# 3. C5-T1 — Three-factor persistence factorization

## Theorem C5-T1

Whenever $A>0$ and $F>0$,

$$
\boxed{
 \mathcal T
 =
 \mathcal E\mathcal P
}
$$

and hence

$$
\boxed{
 \frac FA
 =
 \mathcal E
 \mathcal P
 \mathcal C_{\mathrm{sgn}}.
}
$$

### Proof

By definition,

$$
\mathcal E\mathcal P
=
\frac VA\frac UV
=
\frac UA
=
\mathcal T.
$$

Multiplying by $\mathcal C_{\mathrm{sgn}}=F/U$ gives the second identity.

---

## Corollary C5-C1 — Refined coherence--occupancy rigidity

If

$$
F[I]\ge\eta>0,
$$

then

$$
\boxed{
 \mathcal E[I]
 \mathcal P[I]
 \mathcal C_{\mathrm{sgn}}[I]
 \mathfrak W_p[I]
 \gtrsim_\beta
 \eta b^{-1/2}
 2^{\rho_{\mathrm{mic}}M}.
}
$$

If additionally

$$
\mathfrak W_p[I]\le R,
$$

then each of the three factors individually obeys

$$
\boxed{
 \mathcal E,
 \mathcal P,
 \mathcal C_{\mathrm{sgn}}
 \gtrsim_\beta
 \frac{\eta}{b^{1/2}R}
 2^{\rho_{\mathrm{mic}}M},
}
$$

because every factor belongs to $[0,1]$.

Thus near-minimal remote dissipation cost forces three distinct forms of rigidity:

1. the pointwise microlocal envelope must nearly saturate;
2. the actual edge phases must survive temporal integration;
3. different integrated edges must cooperate in the positive flux direction.

---

# 4. C5-T2 — Exact spacetime phase concentration

C4 proved phase concentration only for the integrated edge amplitudes $Z_e$. C5 can state an exact identity for the full edge-time phase field.

Let

$$
S[I]
:=
\sum_e Z_e[I]
=
\sum_e\int_I a_e(t)e^{i\phi_e(t)}\,dt.
$$

When $S\ne0$, write

$$
\psi_*:=\arg S.
$$

Also define the C4 complex cross-edge coherence

$$
\mathcal C_{\mathrm{ph}}
:=
\frac{|S|}{U}.
$$

## Theorem C5-T2A — Resultant-direction spacetime identity

If $V>0$ and $S\ne0$, then

$$
\boxed{
\frac1V
\sum_e
\int_I
 a_e(t)
 \left|
 e^{i\phi_e(t)}
 -
 e^{i\psi_*}
 \right|^2
 dt
=
2
\left(
1-
\mathcal P
\mathcal C_{\mathrm{ph}}
\right).
}
$$

### Proof

Expand

$$
\left|
 e^{i\phi}-e^{i\psi_*}
\right|^2
=
2-2\operatorname{Re}
\left(
 e^{i(\phi-\psi_*)}
\right).
$$

After weighting by $a_e$, integrating, and summing,

$$
\sum_e\int_I
 a_e
 \operatorname{Re}
 e^{i(\phi_e-\psi_*)}
 dt
=
|S|.
$$

Divide by $V$ and use

$$
\frac{|S|}{V}
=
\frac UV\frac{|S|}{U}
=
\mathcal P\mathcal C_{\mathrm{ph}}.
$$

---

## Theorem C5-T2B — Positive-flux spacetime identity

If $V>0$, then

$$
\boxed{
\frac1V
\sum_e
\int_I
 a_e(t)
 \left|
 e^{i\phi_e(t)}-1
 \right|^2
 dt
=
2
\left(
1-
\mathcal P
\mathcal C_{\mathrm{sgn}}
\right).
}
$$

### Proof

Since

$$
F
=
\operatorname{Re}S,
$$

we have

$$
\frac FV
=
\frac UV\frac FU
=
\mathcal P\mathcal C_{\mathrm{sgn}}.
$$

Now use

$$
|e^{i\phi}-1|^2
=
2(1-\cos\phi).
$$

---

## Corollary C5-C2 — Spacetime phase-mass concentration

If

$$
\mathcal P
\mathcal C_{\mathrm{sgn}}
\ge
1-\varepsilon,
$$

then

$$
\boxed{
\frac1V
\sum_e
\int_I
 a_e(t)
 |e^{i\phi_e(t)}-1|^2
 dt
\le
2\varepsilon.
}
$$

Therefore near-perfect positive payment is not merely an alignment of time-integrated edge vectors. The actual edge-time phase mass is concentrated near the positive flux direction.

---

# 5. Exact Fourier-mode phase dynamics

We now separate a rigorous kinematic fact from any closure hypothesis.

For a smooth periodic solution, write

$$
\partial_t\widehat\theta(k)
+
|k|^{2\alpha}\widehat\theta(k)
=
\widehat{\mathcal N[\theta]}(k),
$$

where

$$
\mathcal N[\theta]
:=
-u_\theta\cdot\nabla\theta.
$$

Whenever

$$
\widehat\theta(k,t)\ne0,
$$

write

$$
\widehat\theta(k,t)
=
r_k(t)e^{i\vartheta_k(t)}.
$$

## Proposition C5-P1 — Exact mode-phase velocity

On every time interval on which $\widehat\theta(k,t)\ne0$,

$$
\boxed{
 \dot\vartheta_k(t)
 =
 \operatorname{Im}
 \frac{
 \widehat{\mathcal N[\theta]}(k,t)
 }{
 \widehat\theta(k,t)
 }.
}
$$

### Proof

Divide the Fourier equation by $\widehat\theta(k)$:

$$
\frac{\partial_t\widehat\theta(k)}{\widehat\theta(k)}
=
-|k|^{2\alpha}
+
\frac{\widehat{\mathcal N[\theta]}(k)}{\widehat\theta(k)}.
$$

The imaginary part of the left side is $\dot\vartheta_k$. The dissipative multiplier $-|k|^{2\alpha}$ is real and therefore contributes nothing to phase rotation.

---

# 6. C5-P2 — Exact triad-phase velocity

For a non-null fixed triad

$$
\xi+\eta=\zeta
$$

away from a zero of $m_{\mathrm{sym}}$, define

$$
\Phi_{\xi,\eta,\zeta}
:=
\vartheta_\xi
+
\vartheta_\eta
-
\vartheta_\zeta
+
\arg m_{\mathrm{sym}}(\xi,\eta).
$$

Because $m_{\mathrm{sym}}$ is real and time independent for fixed frequencies,

$$
\arg m_{\mathrm{sym}}
\in\{0,\pi\}
$$

is constant on every fixed sign component.

Define

$$
\Omega_k
:=
\operatorname{Im}
\frac{
\widehat{\mathcal N[\theta]}(k)
}{
\widehat\theta(k)
}.
$$

Then

$$
\boxed{
 \dot\Phi_{\xi,\eta,\zeta}
 =
 \Omega_\xi
 +
 \Omega_\eta
 -
 \Omega_\zeta.
}
$$

This is exact whenever the three Fourier amplitudes are nonzero.

---

# 7. C5-N1 — Static-symbol dephasing no-go

The C3/C4 symbol contains powerful **spatial-frequency geometry**:

$$
K^2N^{\beta-2},
$$

angular null factors, sign changes, and antipodal restrictions.

However, for a fixed Fourier triad it contains no time dependence. Therefore

$$
\boxed{
\partial_t
\arg m_{\mathrm{sym}}(\xi,\eta)
=0
}
$$

away from symbol zeros.

Hence:

$$
\boxed{
\text{variation of the fixed gSQG symbol across edges does not itself create temporal dephasing.}
}
$$

It can produce static sign incompatibility and angular suppression, which C3--C4 already encode, but any true time dephasing must come through the nonlinear phase velocities $\Omega_k$ and the evolution of the amplitudes.

---

# 8. C5-N2 — Isolated-triad closure no-go

The exact quantity

$$
\Omega_k
=
\operatorname{Im}
\frac{
\widehat{\mathcal N[\theta]}(k)
}{
\widehat\theta(k)
}
$$

contains the full quadratic convolution producing mode $k$.

Therefore the exact triad-phase equation

$$
\dot\Phi
=
\Omega_\xi+
\Omega_\eta-
\Omega_\zeta
$$

is not a closed ODE for the single triad $(\xi,\eta,\zeta)$.

Any reduction to an isolated triad, noisy oscillator, random phase model, or nearest-neighbor phase model requires an additional closure or approximation.

C5 assumes none.

---

# 9. A deterministic nonstationary-phase lemma

The next result is purely deterministic.

## Lemma C5-L1 — Edge dephasing bound

Let

$$
z(t)=a(t)e^{i\phi(t)}
$$

on an interval $J$, with

$$
a\in W^{1,1}(J)\cap L^\infty(J),
$$

$$
\phi\in W^{2,1}(J),
$$

and suppose

$$
|\phi'(t)|\ge\Omega>0
$$

throughout $J$.

Then

$$
\boxed{
\left|
\int_J a(t)e^{i\phi(t)}dt
\right|
\le
\frac{
2\|a\|_{L^\infty(J)}
+
\|a'\|_{L^1(J)}
}{\Omega}
+
\frac{
\|a\phi''\|_{L^1(J)}
}{\Omega^2}.
}
$$

### Proof

Use

$$
e^{i\phi}
=
\frac1{i\phi'}
\frac d{dt}e^{i\phi}
$$

and integrate by parts:

$$
\int_Jae^{i\phi}dt
=
\left[
\frac{ae^{i\phi}}{i\phi'}
\right]_{\partial J}
-
\int_Je^{i\phi}
\left(
\frac{a'}{i\phi'}
-
\frac{a\phi''}{i(\phi')^2}
\right)dt.
$$

Take absolute values and use $|\phi'|\ge\Omega$.

---

# 10. Phase-resonant edges and modulation defect

Fix a phase-velocity threshold

$$
\Omega>0.
$$

For each edge $e$, split its active set

$$
\{t\in I:a_e(t)>0\}
$$

into connected components on which a continuous phase branch is chosen.

Call an edge **$\Omega$-nonresonant** if on every active component

$$
|\phi_e'(t)|\ge\Omega.
$$

Otherwise call it **$\Omega$-resonant**.

For an $\Omega$-nonresonant edge define

$$
\boxed{
\mathfrak D_e(\Omega)
:=
\sum_{J\in\mathcal J_e}
\left[
\frac{
2\|a_e\|_{L^\infty(J)}
+
\|a_e'\|_{L^1(J)}
}{\Omega}
+
\frac{
\|a_e\phi_e''\|_{L^1(J)}
}{\Omega^2}
\right].
}
$$

Then C5-L1 gives

$$
|Z_e|
\le
\mathfrak D_e(\Omega)
$$

for every nonresonant edge.

The quantity $\mathfrak D_e$ deliberately absorbs two ways to defeat naive dephasing:

1. sharp amplitude gating through large $a_e'$ or large $\|a_e\|_\infty$;
2. strong phase acceleration through large $\phi_e''$.

---

# 11. A rank subset lemma

Let

$$
z_e:=|Z_e|,
\qquad
U=\sum_e z_e,
$$

and recall

$$
\mathcal R_{\mathrm{eff}}
=
\frac{U^2}{\sum_ez_e^2}.
$$

## Lemma C5-L2 — Small subsets cannot carry a high-rank payment

For every subset $S$ of $m$ edges,

$$
\boxed{
\sum_{e\in S}z_e
\le
U
\sqrt{
\frac m{\mathcal R_{\mathrm{eff}}}
}.
}
$$

### Proof

By Cauchy--Schwarz,

$$
\sum_{e\in S}z_e
\le
\sqrt m
\left(
\sum_{e\in S}z_e^2
\right)^{1/2}
\le
\sqrt m
\left(
\sum_ez_e^2
\right)^{1/2}.
$$

Use

$$
\sum_ez_e^2
=
\frac{U^2}{\mathcal R_{\mathrm{eff}}}.
$$

---

# 12. C5-T3 — High-rank phase-resonance / dephasing alternative

## Theorem C5-T3

Assume

$$
F[I]\ge\eta>0.
$$

Let

$$
\mathcal R_\Omega
$$

be the set of $\Omega$-resonant edges.

Then at least one of the following holds:

$$
\boxed{
|\mathcal R_\Omega|
\ge
\frac14
\mathcal R_{\mathrm{eff}}
}
$$

or

$$
\boxed{
\sum_{e\notin\mathcal R_\Omega}
\mathfrak D_e(\Omega)
\ge
\frac12U
\ge
\frac12\eta.
}
$$

### Proof

Suppose

$$
|\mathcal R_\Omega|
<
\frac14\mathcal R_{\mathrm{eff}}.
$$

By C5-L2,

$$
\sum_{e\in\mathcal R_\Omega}|Z_e|
<
\frac12U.
$$

Therefore the nonresonant edges carry more than $U/2$ of the integrated absolute mass:

$$
\sum_{e\notin\mathcal R_\Omega}|Z_e|
>
\frac12U.
$$

But each nonresonant edge obeys

$$
|Z_e|
\le
\mathfrak D_e(\Omega).
$$

Hence

$$
\sum_{e\notin\mathcal R_\Omega}
\mathfrak D_e(\Omega)
>
\frac12U.
$$

Finally $F\le U$ and $F\ge\eta$.

---

## Interpretation

Large effective pair rank plus positive payment cannot be maintained by only a few phase-resonant edges unless the remaining edges pay a large modulation/dephasing defect.

Thus the C4 high-rank branch refines to

$$
\boxed{
\text{many phase-resonant edges}
\quad\vee\quad
\text{large amplitude/phase-modulation defect}.
}
$$

This is deterministic and uses no random-phase hypothesis.

---

# 13. C5-N3 — Large phase velocity alone does not imply dephasing

There is no theorem of the form

$$
\text{large }|\phi'|
\Longrightarrow
\text{small temporal coherence}
$$

without further hypotheses.

Two countermechanisms are elementary.

## Counterexample A — Fast small-excursion phase

Take

$$
\phi(t)
=
\varepsilon\sin(\omega t)
$$

and

$$
a(t)\equiv1.
$$

For fixed small $\varepsilon$,

$$
e^{i\phi(t)}
$$

stays in an $O(\varepsilon)$ arc and therefore has temporal coherence approaching $1$ as $\varepsilon\to0$.

But

$$
\|\phi'\|_\infty
=
\varepsilon\omega
$$

can be arbitrarily large by taking $\omega\to\infty$.

The price is that $\phi'$ repeatedly crosses zero and $\phi''$ becomes large.

## Counterexample B — Amplitude gating

Take a monotone fast phase

$$
\phi(t)=\Omega t,
$$

but choose $a(t)$ concentrated in short windows around times for which

$$
\phi(t)\in2\pi\mathbb Z.
$$

Then the weighted integral can remain highly coherent even for large $\Omega$.

The price is large amplitude concentration/variation, which appears explicitly in $\mathfrak D_e(\Omega)$.

Therefore the correct deterministic obstruction is not phase speed alone. It is phase speed together with amplitude gating and phase-acceleration control.

---

# 14. Unsigned edge rank

C4's effective rank is built from the time-integrated complex amplitudes:

$$
\mathcal R_{\mathrm{eff}}
=
\frac{U^2}{\sum_e|Z_e|^2}.
$$

To distinguish simultaneous coactivity from sequential relay, C5 introduces the unsigned spacetime edge masses

$$
v_e
=
\int_Ia_e(t)dt.
$$

Define

$$
\boxed{
\mathcal R_V
:=
\frac{V^2}{\sum_ev_e^2}.
}
$$

This is the effective rank before temporal phase cancellation.

---

# 15. C5-T4 — Rank transfer under temporal phase persistence

## Theorem C5-T4

Let

$$
\mathcal P
=
\frac UV.
$$

Then

$$
\boxed{
\mathcal R_V
\ge
\frac1{
\mathcal P^2/\mathcal R_{\mathrm{eff}}
+
1-\mathcal P^2
}.
}
$$

### Proof

Normalize by $V$ and set

$$
\widetilde v_e
=
\frac{v_e}{V},
\qquad
\widetilde z_e
=
\frac{|Z_e|}{V}.
$$

Then

$$
\sum_e\widetilde v_e=1,
\qquad
\sum_e\widetilde z_e=\mathcal P,
$$

and

$$
0\le\widetilde z_e\le\widetilde v_e.
$$

Write

$$
d_e
=
\widetilde v_e-\widetilde z_e
\ge0,
$$

so

$$
\sum_ed_e
=
1-\mathcal P.
$$

Then

$$
\sum_e\widetilde v_e^2
=
\sum_e(\widetilde z_e+d_e)^2.
$$

Using

$$
\sum_e\widetilde z_ed_e
\le
\left(\sum_e\widetilde z_e\right)
\left(\sum_ed_e\right)
$$

and

$$
\sum_ed_e^2
\le
\left(\sum_ed_e\right)^2,
$$

we obtain

$$
\sum_e\widetilde v_e^2
\le
\sum_e\widetilde z_e^2
+
1-\mathcal P^2.
$$

But

$$
\sum_e\widetilde z_e^2
=
\frac{\mathcal P^2}{\mathcal R_{\mathrm{eff}}}.
$$

Since

$$
\frac1{\mathcal R_V}
=
\sum_e\widetilde v_e^2,
$$

the claim follows.

---

## Corollary C5-C3 — Near-perfect temporal survival transfers rank

If

$$
\mathcal R_{\mathrm{eff}}\ge R
$$

and

$$
1-\mathcal P^2
\le
\frac1R,
$$

then

$$
\boxed{
\mathcal R_V
\ge
\frac R2.
}
$$

Thus extremely high C4 effective rank becomes a genuinely high unsigned edge rank only when the temporal survival deficit is correspondingly small.

---

# 16. Simultaneous coactivity versus temporal relay

Let

$$
T:=|I|.
$$

Define the edge-amplitude duty coefficient

$$
\boxed{
\mathcal D_{\mathrm{amp}}
:=
\frac{
\sum_ev_e^2
}{
T\int_I\sum_ea_e(t)^2dt
}.
}
$$

By Cauchy--Schwarz on each edge,

$$
0\le\mathcal D_{\mathrm{amp}}\le1.
$$

Define the instantaneous concurrency number

$$
\boxed{
\mathcal H
:=
\frac{
\int_I
\left(\sum_ea_e(t)\right)^2dt
}{
\int_I\sum_ea_e(t)^2dt
}.
}
$$

At each time,

$$
\left(\sum_ea_e\right)^2
\ge
\sum_ea_e^2,
$$

so

$$
\mathcal H\ge1.
$$

Finally define the total activity duty factor

$$
\boxed{
\mathcal D_{\mathrm{tot}}
:=
\frac{
V^2
}{
T\int_I
\left(\sum_ea_e(t)\right)^2dt
}.
}
$$

Again

$$
0\le\mathcal D_{\mathrm{tot}}\le1.
$$

---

# 17. C5-T5 — Rank--duty--relay identity

## Theorem C5-T5

The quantities above satisfy the exact identity

$$
\boxed{
\mathcal D_{\mathrm{amp}}
\mathcal R_V
=
\mathcal D_{\mathrm{tot}}
\mathcal H.
}
$$

Both sides equal

$$
\boxed{
\frac{
V^2
}{
T\int_I\sum_ea_e(t)^2dt
}.
}
$$

### Proof

First,

$$
\mathcal D_{\mathrm{amp}}
\mathcal R_V
=
\frac{
\sum_ev_e^2
}{
T\int_I\sum_ea_e^2dt
}
\frac{V^2}{\sum_ev_e^2}.
$$

Second,

$$
\mathcal D_{\mathrm{tot}}
\mathcal H
=
\frac{
V^2
}{
T\int_I(\sum_ea_e)^2dt
}
\frac{
\int_I(\sum_ea_e)^2dt
}{
\int_I\sum_ea_e^2dt
}.
$$

Both reduce to the same expression.

---

## Corollary C5-C4 — Large rank requires concurrency or relay

Since

$$
\mathcal D_{\mathrm{tot}}\le1,
$$

C5-T5 gives

$$
\boxed{
\mathcal H
\ge
\mathcal D_{\mathrm{amp}}
\mathcal R_V.
}
$$

Therefore if

$$
\mathcal R_V\gg1
$$

but

$$
\mathcal H\le H_*,
$$

then necessarily

$$
\boxed{
\mathcal D_{\mathrm{amp}}
\le
\frac{H_*}{\mathcal R_V}.
}
$$

Thus a large integrated rank with bounded simultaneous concurrency can survive only through small edge duty: a temporal relay/intermittency mechanism.

---

# 18. C5-N4 — High integrated rank does not imply simultaneous high rank

Take $n$ edges and split

$$
I
$$

into $n$ disjoint subintervals of equal length.

On the $j$th subinterval set only edge $j$ active, with positive real amplitude, and set all other edges to zero.

Choose amplitudes so that

$$
Z_1=\cdots=Z_n>0.
$$

Then

$$
\mathcal P=1,
$$

$$
\mathcal C_{\mathrm{sgn}}=1,
$$

and

$$
\boxed{
\mathcal R_{\mathrm{eff}}=n.
}
$$

But at every time exactly one edge is active, so

$$
\boxed{
\mathcal H=1.
}
$$

Moreover

$$
\mathcal D_{\mathrm{amp}}
=\frac1n.
$$

Thus the identity

$$
\mathcal D_{\mathrm{amp}}\mathcal R_V
=
1
$$

is saturated.

Hence:

$$
\boxed{
\text{high-rank coherent integrated ancestry}
\not\Rightarrow
\text{simultaneous high-rank ensemble}.
}
$$

The missing alternative is **sequential coherent relay**.

---

# 19. C5-T6 — Refined remote-ancestry routing theorem

Combine C4 with C5.

Suppose a remote parent class pays

$$
F[I]\ge\eta>0.
$$

Assume the C3/C4 microlocal hypotheses and exclude the previously identified parent-atom and large critical-dissipation branches.

Then the surviving remote ancestry must satisfy the C4 coherence/rank requirements. C5 refines that branch as follows.

For every fixed phase-velocity threshold $\Omega>0$, at least one of the following mechanisms must occur:

$$
\boxed{
\begin{aligned}
&\text{envelope-saturation defect},\\
&\text{temporal phase-survival defect},\\
&\text{signed-coherence defect},\\
&\text{large modulation/dephasing defect},\\
&\text{many phase-velocity-resonant paying edges},\\
&\text{large simultaneous edge coactivity},\\
&\text{small-duty sequential coherent relay}.
\end{aligned}
}
$$

In the near-minimal-cost, near-perfect-coherence regime, the first three branches are suppressed. If the C4 effective rank is large and $\mathcal P$ is sufficiently close to $1$, C5-T4 transfers this to large unsigned edge rank. C5-T5 then forces either large simultaneous coactivity or a small-duty relay. Independently, C5-T3 forces either many phase-resonant edges or a large dephasing/modulation budget.

Thus the strongest surviving configuration has the schematic form

$$
\boxed{
\text{phase-resonant coherent ancestry}
\quad+
\left(
\text{simultaneous high coactivity}
\vee
\text{rapid sequential relay}
\right).
}
$$

This is the C5 refinement of the C4 high-rank coherent obstruction.

---

# 20. What C5 does not prove

C5 does **not** prove global regularity for supercritical gSQG.

It does not prove that the phase-resonant branch is impossible.

It does not prove a uniform bound on

$$
\mathcal R_{\mathrm{eff}}.
$$

It does not derive an unconditional decay law for $\mathcal C_{\mathrm{sgn}}$.

It does not show that large Fourier coherence implies physical-space localization.

It does not obtain another universal remote-gap exponent beyond

$$
\rho_{\mathrm{mic}}
=
 s_c+3.
$$

It does not assume random phases, stochastic independence, or turbulence closures.

---

# 21. Main conceptual change from C4 to C5

C4 identified the residual remote obstruction as

$$
\text{high-rank coherent antipodal ensemble}.
$$

C5 shows that this phrase still conflates distinct dynamics.

The correct refinement is

$$
\boxed{
\text{integrated coherence}
=
\text{envelope saturation}
\times
\text{temporal phase persistence}
\times
\text{cross-edge signed coherence}.
}
$$

And

$$
\boxed{
\text{integrated high rank}
=
\text{simultaneous coactivity}
\quad\text{or}\quad
\text{temporal relay/intermittency},
}
$$

once the relevant duty factors are exposed.

Finally, deterministic nonstationary-phase analysis adds

$$
\boxed{
\text{persistent high-rank payment}
\Longrightarrow
\text{many phase resonances}
\vee
\text{large modulation defect}.
}
$$

This is the first stage in the series at which the surviving obstruction is explicitly dynamical in time rather than only geometric in frequency.

---

# 22. Relation to current literature

Current rigorous gSQG work in the fully nonlinear supercritical regime is formulated in the critical Sobolev space

$$
H^{1+\beta-2\alpha}
$$

and uses Littlewood--Paley/commutator structure and parabolic smoothing. C5 uses that PDE environment but does not import any phase-statistical closure.

Recent turbulence work on triad phases provides conceptual precedent for treating phase alignment and phase synchronization as dynamically relevant to nonlinear spectral transfer. Those works also emphasize that the full phase dynamics receive contributions from neighboring triads, motivating reduced or stochastic closures. C5 deliberately stops before such a closure and retains the exact full-convolution quantity $\Omega_k$.

Therefore literature proximity should not be confused with novelty confirmation. The exact deterministic factorization/rank/relay theorem package in this note remains subject to publication-level literature audit.

---

# 23. C6 handoff

C5 leaves two sharply separated dynamic routes:

$$
\boxed{
\text{many phase-resonant edges}
}
$$

and

$$
\boxed{
\text{small-duty sequential coherent relay}.
}
$$

The next project should therefore not ask vaguely whether coherence persists. It should attack **turnover**.

Recommended title:

$$
\boxed{
\textbf{C6 — Phase-Resonant Relay Turnover and Modulation Cost}
}
$$

Priority questions:

1. Can the PDE control the total variation
   $$
   \sum_e\|a_e'\|_{L^1(I)}
   $$
   or a weaker tile-energy turnover quantity?
2. Does a relay across $R$ antipodal edges force a lower bound on time-frequency modulation occupancy?
3. Can instantaneous Gevrey smoothing constrain extremely rapid switching among high-frequency tiles?
4. Can one prove
   $$
   \text{large relay rank}
   \Longrightarrow
   \text{large turnover budget}
   \vee
   \text{persistent simultaneous resonance}?
   $$
5. Introduce wave packets only if a Fourier-tile turnover theorem requires a physical-space overlap variable.

The key prohibition remains:

$$
\boxed{
\text{Fourier phase coherence}
\not\Rightarrow
\text{physical-space localization}
}
$$

without an additional wave-packet argument.

---

# 24. Final C5 state

The proof-asset transfer path now reads

$$
\boxed{
\begin{aligned}
\text{NS proof assets}
&\longrightarrow
\text{gSQG critical-shell crossing}\\
&\longrightarrow
\text{remote antipodal parent geometry}\\
&\longrightarrow
\text{microlocal symbol cancellation}\\
&\longrightarrow
\text{signed coherence and effective rank}\\
&\longrightarrow
\text{spacetime phase persistence}\\
&\longrightarrow
\text{phase resonance / modulation defect}\\
&\longrightarrow
\text{simultaneous coactivity / temporal relay}.
\end{aligned}
}
$$

The remaining obstruction is no longer an undifferentiated high-frequency cascade. It is a dynamically organized phase-resonant or relay structure with explicitly measurable failure modes.
