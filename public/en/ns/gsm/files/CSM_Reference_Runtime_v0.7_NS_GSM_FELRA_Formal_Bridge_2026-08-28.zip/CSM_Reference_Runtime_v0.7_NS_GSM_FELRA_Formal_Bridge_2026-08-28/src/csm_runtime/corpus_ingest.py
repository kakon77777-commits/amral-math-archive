from __future__ import annotations

from dataclasses import dataclass
import hashlib
from typing import Mapping

from .corpus_manifest import CorpusManifest, CorpusSource
from .ledger import EventLedger, LedgerEvent
from .model import NativeState
from .series_profiles import profile_for_code, profile_for_filename
from .source_parser import parse_markdown_source


@dataclass(frozen=True)
class CorpusIngestionBatch:
    manifest_version: str
    source_ids: tuple[str, ...]
    events: tuple[LedgerEvent, ...]


def _artifact_id(source: CorpusSource) -> str:
    digest = hashlib.sha256(f"{source.source_id}|{source.source_hash or "nohash"}".encode("utf-8")).hexdigest()[:20]
    return f"artifact:corpus:{digest}"


def _event_id(prefix: str, stable_id: str) -> str:
    digest = hashlib.sha256(stable_id.encode("utf-8")).hexdigest()[:20]
    return f"corpus:{prefix}:{digest}"


def build_corpus_batch(
    state: NativeState,
    ledger: EventLedger,
    manifest: CorpusManifest,
    source_texts: Mapping[str, str],
) -> CorpusIngestionBatch:
    events: list[LedgerEvent] = []
    sequence = len(ledger.events) + 1

    def emit(event_id: str, event_type: str, payload: dict, provenance: dict | None = None) -> None:
        nonlocal sequence
        events.append(LedgerEvent(
            event_id=event_id,
            event_type=event_type,
            payload=payload,
            sequence=sequence,
            provenance=provenance or {},
            operator_version="v0.2",
            policy_version=state.policy_version,
        ))
        sequence += 1

    for source in manifest.ordered_sources():
        if source.source_id not in source_texts:
            raise KeyError(f"missing source text: {source.source_id}")
        artifact_id = _artifact_id(source)
        if artifact_id not in state.objects:
            emit(
                _event_id("artifact", f"{source.source_id}|{source.source_hash or 'nohash'}"),
                "REGISTER_OBJECT",
                {
                    "object_id": artifact_id,
                    "object_type": "ARTIFACT",
                    "domain_id": "formal",
                    "version": source.version or manifest.version,
                    "status": "UNVERIFIED",
                    "authority": "DISPLAY",
                    "metadata": source.to_dict(),
                },
                {"source_id": source.source_id, "source_ref": source.source_ref},
            )

        profile = profile_for_code(source.series) if source.series else profile_for_filename(source.file_name)
        parsed = parse_markdown_source(source_texts[source.source_id], source.source_id, profile.code)
        for candidate in parsed.all_candidates():
            if candidate.candidate_id in state.candidates:
                continue
            emit(
                _event_id("candidate", candidate.candidate_id),
                "REGISTER_CANDIDATE",
                {
                    "candidate_id": candidate.candidate_id,
                    "source_ref": source.source_ref or source.source_id,
                    "candidate_type": candidate.candidate_type,
                    "proposed_object": candidate.to_dict(),
                    "parser_version": "v0.2",
                    "confidence": None,
                    "validation_state": "UNVERIFIED",
                },
                {"source_id": source.source_id, "artifact_id": artifact_id, "series": profile.code},
            )

    return CorpusIngestionBatch(
        manifest_version=manifest.version,
        source_ids=tuple(s.source_id for s in manifest.ordered_sources()),
        events=tuple(events),
    )
