from __future__ import annotations

from collections import defaultdict

from .candidate_validation import CrossSeriesProposal, ValidationClass
from .model import NativeState


def _series(candidate) -> str | None:
    meta = (candidate.proposed_object or {}).get("metadata") or {}
    value = meta.get("series")
    return str(value) if value is not None else None


def _statement(candidate) -> str:
    value = (candidate.proposed_object or {}).get("statement") or ""
    return " ".join(str(value).split()).casefold()


def exact_statement_proposals(state: NativeState) -> list[CrossSeriesProposal]:
    """Return conservative cross-series exact-statement proposals.

    This is deliberately not semantic quotienting. Exact textual agreement
    across different series is only a review proposal and never auto-merges.
    """
    groups: dict[tuple[str, str], list] = defaultdict(list)
    for candidate in state.candidates.values():
        statement = _statement(candidate)
        if not statement:
            continue
        groups[(candidate.candidate_type, statement)].append(candidate)

    proposals: list[CrossSeriesProposal] = []
    for (_candidate_type, statement), values in groups.items():
        values = sorted(values, key=lambda c: c.candidate_id)
        for i, left in enumerate(values):
            left_series = _series(left)
            for right in values[i + 1 :]:
                right_series = _series(right)
                if not left_series or not right_series or left_series == right_series:
                    continue
                proposals.append(CrossSeriesProposal(
                    left_candidate_id=left.candidate_id,
                    right_candidate_id=right.candidate_id,
                    relation="POSSIBLE_EXACT_STATEMENT_MATCH",
                    reason=(
                        f"Exact normalized candidate statement appears in distinct series "
                        f"{left_series} and {right_series}: {statement[:160]}"
                    ),
                    validation_class=ValidationClass.NEEDS_REVIEW,
                    auto_quotient=False,
                ))
    return sorted(proposals, key=lambda p: (p.left_candidate_id, p.right_candidate_id))
