from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Mapping

from .canonical import state_hash
from .corpus_ingest import build_corpus_batch
from .corpus_manifest import CorpusManifest
from .ledger import EventLedger, LedgerEvent
from .model import NativeState
from .transaction import ClosureTransaction


@dataclass(frozen=True)
class IngestionCheckpoint:
    checkpoint_id: str
    status: str
    state: NativeState
    input_state_hash: str
    output_state_hash: str
    event_count: int
    source_ids: tuple[str, ...]


def checkpoint_hash(manifest: CorpusManifest, parser_version: str = "v0.2") -> str:
    payload = {
        "manifest": manifest.to_dict(),
        "parser_version": parser_version,
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def commit_corpus_batch(
    state: NativeState,
    ledger: EventLedger,
    manifest: CorpusManifest,
    source_texts: Mapping[str, str],
    *,
    parser_version: str = "v0.2",
) -> IngestionCheckpoint:
    digest = checkpoint_hash(manifest, parser_version)
    checkpoint_id = f"corpus:checkpoint:{digest[:24]}"
    input_hash = state_hash(state)

    existing = next((e for e in ledger.events if e.event_id == checkpoint_id), None)
    if existing is not None:
        return IngestionCheckpoint(
            checkpoint_id=checkpoint_id,
            status="IDEMPOTENT_NOOP",
            state=state,
            input_state_hash=input_hash,
            output_state_hash=input_hash,
            event_count=0,
            source_ids=tuple(s.source_id for s in manifest.ordered_sources()),
        )

    # Build completely before transaction creation so input errors cannot mutate anything.
    batch = build_corpus_batch(state, ledger, manifest, source_texts)
    events = list(batch.events)
    seq = len(ledger.events) + len(events) + 1
    events.append(LedgerEvent(
        event_id=checkpoint_id,
        event_type="CORPUS_CHECKPOINT",
        payload={
            "checkpoint_id": checkpoint_id,
            "manifest_hash": digest,
            "parser_version": parser_version,
            "source_ids": list(batch.source_ids),
        },
        sequence=seq,
        provenance={"kind": "corpus_checkpoint"},
        operator_version="v0.2",
        policy_version=state.policy_version,
    ))

    txn = ClosureTransaction(state, ledger)
    for event in events:
        txn.stage(event)
    result = txn.commit()
    return IngestionCheckpoint(
        checkpoint_id=checkpoint_id,
        status=result.commit_status,
        state=result.state,
        input_state_hash=result.input_state_hash,
        output_state_hash=result.output_state_hash,
        event_count=len(events),
        source_ids=batch.source_ids,
    )
