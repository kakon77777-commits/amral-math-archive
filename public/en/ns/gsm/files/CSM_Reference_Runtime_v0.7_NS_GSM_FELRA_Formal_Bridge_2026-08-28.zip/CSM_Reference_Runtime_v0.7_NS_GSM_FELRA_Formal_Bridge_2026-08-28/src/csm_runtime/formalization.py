from __future__ import annotations

import hashlib
import json
from typing import Any

from .enums import Authority
from .model import FormalizationRecord, NativeState, ObjectRecord

LANGUAGE = "NSGSM-FIR/0.1"

_CASES: dict[str, dict[str, Any]] = {
    "Theorem D103.1 — Eigen-lock commutator equation": {
        "case_id": "d103.1", "kind": "ALGEBRAIC_CORE", "status": "CORE_COMPLETE",
        "variables": ["S:Sym0(3)", "Phi:Sym0(3)", "beta:scalar", "r:scalar"],
        "goals": ["[S^2,Phi] = beta [S,Phi]"],
        "derivation_kind": "matrix_commutator_identity",
        "normalized_claim": {"relation": "commutator", "lhs": "[S^2,Phi]", "rhs": "beta*[S,Phi]"},
    },
    "Theorem D103.2 — Shear resonance condition": {
        "case_id": "d103.2", "kind": "ALGEBRAIC_CORE", "status": "CORE_COMPLETE",
        "variables": ["s1,s2,s3,beta:scalar", "Phi_ij:scalar"],
        "goals": ["(si-sj)(si+sj-beta)Phi_ij = 0"],
        "derivation_kind": "eigenbasis_factorization",
        "normalized_claim": {"factor": "(si-sj)*(si+sj-beta)*Phi_ij", "expected": "0"},
    },
    "Theorem D103.3 — Single-shear theorem": {
        "case_id": "d103.3", "kind": "ALGEBRAIC_CORE", "status": "CORE_COMPLETE",
        "variables": ["s1,s2,s3,beta:scalar"],
        "goals": ["two active shear pairs imply repeated strain eigenvalue"],
        "derivation_kind": "resonance_degeneracy",
        "normalized_claim": {"if": ["beta=-s3", "beta=-s2"], "then": "s2=s3"},
    },
    "Theorem D103.4 — Five-Ray Spectrum": {
        "case_id": "d103.4", "kind": "ALGEBRAIC_CORE", "status": "CORE_COMPLETE",
        "variables": ["S:Sym0(3)", "r=0"],
        "goals": ["spec(L_S)={-s1,-s2,-s3,+sqrt(2/3)|S|,-sqrt(2/3)|S|}"],
        "derivation_kind": "characteristic_polynomial",
        "normalized_claim": {"spectrum": ["-s1", "-s2", "-s3", "+dS", "-dS"], "dS2": "2|S|^2/3"},
    },
    "Theorem D103.5 — Riesz-loaded coaxial response": {
        "case_id": "d103.5", "kind": "ALGEBRAIC_CORE", "status": "CORE_COMPLETE",
        "variables": ["beta,r,dS:scalar", "S,C:diagonal-basis"],
        "goals": ["Phi_diag = 2r/(beta^2-dS^2) (beta S + 2 C)"],
        "derivation_kind": "two_by_two_linear_solve",
        "normalized_claim": {"a": "2*beta*r/(beta^2-dS^2)", "b": "4*r/(beta^2-dS^2)"},
    },
    "Theorem D105.1 — Simple-shear TR angular scalar": {
        "case_id": "d105.1", "kind": "ALGEBRAIC_CORE", "status": "CORE_COMPLETE",
        "variables": ["r>0", "n,v:R3", "Hij:simple-shear", "c:scalar"],
        "goals": ["directional Riesz-kernel derivative contracted with Hij equals stated scalar"],
        "derivation_kind": "symbolic_kernel_differentiation",
        "normalized_claim": {"scalar": "-6*c*r^-4*(vi*nj+vj*ni-5*(v.n)*ni*nj)"},
    },
    "Theorem D105.2 — Local Kelvin/TR compatibility witness": {
        "case_id": "d105.2", "kind": "EXACT_WITNESS", "status": "CORE_COMPLETE",
        "variables": ["n=e3", "v=e1", "H=H13", "Q=e1⊗e1", "A=diag(1,-1,0)"],
        "goals": ["A:Q=1", "TR(H13,n=e3,v=e1) != 0"],
        "derivation_kind": "explicit_witness_evaluation",
        "normalized_claim": {"kelvin_projection": "1", "tr_projection": "-6*c*r^-4", "compatible": True},
    },
    "Theorem D105.3 — Exact viscosity residual on the inviscid kernel": {
        "case_id": "d105.3", "kind": "ALGEBRAIC_CORE", "status": "CORE_COMPLETE",
        "variables": ["M0 Phi=0", "M_eps=M0+eps|xi|^2 I"],
        "goals": ["M_eps Phi = eps |xi|^2 Phi"],
        "derivation_kind": "operator_substitution",
        "normalized_claim": {"residual": "eps*|xi|^2*Phi"},
    },
    "Theorem D105.4 — Fixed-band viscosity matching": {
        "case_id": "d105.4", "kind": "ANALYTIC_SCHEMA", "status": "SCHEMA_COMPLETE",
        "variables": ["0<rho_-<=|xi|<=rho_+", "Phi in inviscid kernel"],
        "goals": ["eps rho_-^2 ||Phi||2 <= ||M_eps Phi||2 <= eps rho_+^2 ||Phi||2"],
        "derivation_kind": "support_bound_l2_monotonicity",
        "normalized_claim": {"lower": "eps*rho_-^2*||Phi||2", "upper": "eps*rho_+^2*||Phi||2"},
        "limitations": ["FIR records the analytic inequality schema, not a measure-theory kernel proof"],
    },
    "Theorem 32.1": {
        "case_id": "rfp05.32.1", "kind": "GRAPH_SCHEMA", "status": "SCHEMA_COMPLETE",
        "variables": ["finitely branching rooted provenance graph"],
        "goals": ["nonempty qualified path set at every finite depth implies an infinite path"],
        "derivation_kind": "konig_infinity_schema",
        "normalized_claim": {"premises": ["finite_branching", "all_finite_depths_nonempty"], "conclusion": "infinite_path_exists"},
        "limitations": ["FIR records the graph-theorem schema; no proof-assistant kernel is available"],
    },
    "Theorem 12.1": {
        "case_id": "rfp12.12.1", "kind": "ALGEBRAIC_CORE", "status": "CORE_COMPLETE",
        "variables": ["A=||Delta S||2^2>0", "B=<Delta S,S>", "C=||S||2^2"],
        "goals": ["min_rho ||-rho Delta S-S||2^2 = C-B^2/A"],
        "derivation_kind": "quadratic_minimization",
        "normalized_claim": {"quadratic": "A*rho^2+2*B*rho+C", "minimizer": "-B/A", "minimum": "C-B^2/A"},
    },
    "Theorem 19.1": {
        "case_id": "rfp12.19.1", "kind": "COUNTEREXAMPLE_WITNESS", "status": "WITNESS_COMPLETE",
        "variables": ["fixed-annulus divergence-free bump g", "N separated translations"],
        "goals": ["fixed L2 norm with Linfinity tending to zero; Fourier annulus support preserved"],
        "derivation_kind": "translation_separation_counterexample",
        "normalized_claim": {"L2": "constant", "Linf": "N^-1/2*||g||inf", "fourier_support": "fixed_annulus"},
    },
}


def _canonical_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def formalization_bundle_sha256(bundle: dict[str, Any]) -> str:
    return hashlib.sha256(_canonical_bytes(bundle)).hexdigest()


def v06_proof_assets(state: NativeState) -> list[ObjectRecord]:
    assets = [
        obj for obj in state.objects.values()
        if obj.authority is Authority.PROOF and str(obj.metadata.get("statement") or "") in _CASES
    ]
    return sorted(assets, key=lambda o: _CASES[str(o.metadata["statement"])]["case_id"])


def build_formalization_bundle(state: NativeState, subject_id: str) -> dict[str, Any]:
    obj = state.objects[subject_id]
    statement = str(obj.metadata.get("statement") or "")
    if statement not in _CASES:
        raise KeyError(f"no v0.6 formalization case for {statement!r}")
    cfg = _CASES[statement]
    return {
        "language": LANGUAGE,
        "case_id": cfg["case_id"],
        "subject_id": subject_id,
        "statement": statement,
        "scope": str(obj.metadata.get("reviewed_scope") or ""),
        "assumptions": sorted(obj.metadata.get("assumptions") or []),
        "variables": list(cfg.get("variables") or []),
        "goals": list(cfg.get("goals") or []),
        "derivation_kind": cfg["derivation_kind"],
        "normalized_claim": dict(cfg["normalized_claim"]),
        "dependencies": sorted(obj.certificate_refs),
        "limitations": sorted(cfg.get("limitations") or []),
    }


def formalization_record_for_asset(state: NativeState, subject_id: str) -> FormalizationRecord:
    bundle = build_formalization_bundle(state, subject_id)
    digest = formalization_bundle_sha256(bundle)
    cfg = _CASES[bundle["statement"]]
    return FormalizationRecord(
        formalization_id=f"formalization:{digest[:24]}",
        subject_id=subject_id,
        language=LANGUAGE,
        formalization_kind=cfg["kind"],
        status=cfg["status"],
        statement=bundle["statement"],
        scope=bundle["scope"],
        assumptions=list(bundle["assumptions"]),
        goals=list(bundle["goals"]),
        dependencies=list(bundle["dependencies"]),
        bundle_sha256=digest,
        limitations=list(bundle["limitations"]),
        evidence_refs=[f"formalization:sha256:{digest}"],
        formalized_at_version="v0.6",
    )


def case_for_statement(statement: str) -> str:
    return _CASES[statement]["case_id"]
