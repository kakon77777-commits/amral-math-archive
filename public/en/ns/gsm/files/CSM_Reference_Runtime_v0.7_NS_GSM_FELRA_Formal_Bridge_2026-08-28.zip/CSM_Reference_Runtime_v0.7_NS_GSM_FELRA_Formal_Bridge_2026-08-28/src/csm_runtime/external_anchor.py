from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib
from pathlib import Path
import re
import yaml

from .canonical import state_hash
from .errors import AuthorityError, ValidationError
from .ledger import EventLedger, LedgerEvent
from .model import AuthorityTierReceipt, CertificateRecord, ExternalTheoremAnchorRecord, NativeState
from .state import apply_event
from .transaction import ClosureTransaction

@dataclass(frozen=True)
class ExternalAnchorCommitResult:
    status: str
    state: NativeState
    event_count: int = 0
    input_state_hash: str = ""
    output_state_hash: str = ""


def _short(v: str) -> str:
    return hashlib.sha256(v.encode()).hexdigest()[:24]


def load_external_anchor_manifest(path) -> list[ExternalTheoremAnchorRecord]:
    data=yaml.safe_load(Path(path).read_text(encoding='utf-8')) or {}
    records=[]
    for raw in data.get('anchors') or []:
        records.append(ExternalTheoremAnchorRecord(
            anchor_id=raw['anchor_id'], subject_id=raw['subject_id'], citation_key=raw['citation_key'],
            title=raw['title'], authors=list(raw.get('authors') or []), year=int(raw['year']), doi=raw['doi'],
            imported_statement=raw['imported_statement'], ns_gsm_use=raw['ns_gsm_use'], scope=raw['scope'],
            source_refs=list(raw.get('source_refs') or []), status=raw.get('status','PENDING'),
            limitations=list(raw.get('limitations') or []), anchored_at_version='v0.6'))
    return records


def verify_external_anchor_record(record: ExternalTheoremAnchorRecord) -> None:
    if not re.fullmatch(r"10\.1070/RM2003v058n02ABEH000609", record.doi):
        raise ValidationError('unexpected external theorem DOI')
    if record.year != 2003 or len(record.authors) < 3:
        raise ValidationError('invalid external theorem bibliographic identity')
    if record.status != 'BIBLIOGRAPHICALLY_VERIFIED':
        raise ValidationError('external theorem anchor must be bibliographically verified')
    if not record.imported_statement.strip() or not record.ns_gsm_use.strip() or not record.scope.strip():
        raise ValidationError('external theorem anchor requires statement/use/scope')
    if not any('does not re-prove' in x for x in record.limitations):
        raise ValidationError('external theorem anchor must declare non-reproof limitation')


def commit_external_anchor(state: NativeState, ledger: EventLedger, record: ExternalTheoremAnchorRecord, *, batch_id: str) -> ExternalAnchorCommitResult:
    verify_external_anchor_record(record)
    if record.subject_id not in state.objects:
        raise AuthorityError(f'unknown external anchor subject: {record.subject_id}')
    checkpoint=f'v06:external-anchor:checkpoint:{_short(batch_id)}'
    input_hash=state_hash(state)
    if any(e.event_id==checkpoint for e in ledger.events):
        return ExternalAnchorCommitResult('IDEMPOTENT_NOOP',state,input_state_hash=input_hash,output_state_hash=input_hash)
    seq=len(ledger.events)+1
    cert_id=f'cert:external-anchor:{_short(record.anchor_id)}'
    cert=CertificateRecord(cert_id,'EXTERNAL_THEOREM_ANCHOR',[record.subject_id],'VALID',scope=record.scope,
                           evidence_refs=sorted(record.source_refs),
                           verifier_results=[{'citation_key':record.citation_key,'doi':record.doi,'status':record.status,
                                              'authority_effect':'NONE','limitations':sorted(record.limitations)}],version='v0.6')
    anchor_eid=f'v06:anchor:{_short(record.anchor_id)}'
    cert_eid=f'v06:anchor-cert:{_short(cert_id)}'
    tier_eid=f'v06:anchor-tier:{_short(record.subject_id)}'
    events=[
        LedgerEvent(anchor_eid,'REGISTER_EXTERNAL_THEOREM_ANCHOR',record.to_dict(),seq,provenance={'kind':'external_theorem_anchor'},operator_version='v0.6',policy_version=state.policy_version),
        LedgerEvent(cert_eid,'REGISTER_CERTIFICATE',cert.to_dict(),seq+1,provenance={'kind':'external_theorem_anchor_certificate'},operator_version='v0.6',policy_version=state.policy_version),
        LedgerEvent(tier_eid,'ADD_AUTHORITY_TIER',{'object_id':record.subject_id,'tier_type':'EXTERNAL_THEOREM_ANCHORED','certificate_id':cert_id},seq+2,certificate_refs=(cert_id,),provenance={'kind':'external_theorem_anchor_tier'},operator_version='v0.6',policy_version=state.policy_version),
    ]
    effect=deepcopy(state)
    for e in events: apply_event(effect,e)
    effect_hash=state_hash(effect)
    receipt=AuthorityTierReceipt(f'tier:{_short("EXTERNAL_THEOREM_ANCHORED"+record.subject_id)}',record.subject_id,'EXTERNAL_THEOREM_ANCHORED',record.anchor_id,cert_id,[anchor_eid,cert_eid,tier_eid],input_hash,effect_hash)
    events.append(LedgerEvent(f'v06:anchor-receipt:{_short(receipt.tier_receipt_id)}','REGISTER_AUTHORITY_TIER_RECEIPT',receipt.to_dict(),seq+3,provenance={'kind':'external_theorem_anchor_receipt'},operator_version='v0.6',policy_version=state.policy_version))
    events.append(LedgerEvent(checkpoint,'NOTE',{'kind':'external_theorem_anchor_checkpoint','batch_id':batch_id},seq+4,provenance={'kind':'external_theorem_anchor_checkpoint'},operator_version='v0.6',policy_version=state.policy_version))
    tx=ClosureTransaction(state,ledger)
    for e in events: tx.stage(e)
    committed=tx.commit()
    return ExternalAnchorCommitResult(committed.commit_status,committed.state,len(events),committed.input_state_hash,committed.output_state_hash)
