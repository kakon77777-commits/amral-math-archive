from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
import hashlib, json
from pathlib import Path
from typing import Callable

from .canonical import state_hash
from .enums import Authority
from .errors import AuthorityError
from .independent_verification import VerificationResult, proof_artifact_bytes, proof_artifact_sha256, proof_eligible
from .ledger import EventLedger, LedgerEvent
from .model import AuthorityUpgradeReceipt, CertificateRecord, IndependentVerificationRecord, NativeState
from .state import apply_event
from .transaction import ClosureTransaction

@dataclass(frozen=True)
class VerificationTarget:
    subject_id: str
    verifier_id: str
    verifier_version: str
    verifier: Callable[[], VerificationResult]

@dataclass(frozen=True)
class VerificationBatchResult:
    batch_id: str
    status: str
    state: NativeState
    verification_count: int
    upgrade_count: int
    deferred_count: int
    event_count: int
    input_state_hash: str
    output_state_hash: str


def _short(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()[:24]


def _input_hash(state: NativeState, target: VerificationTarget) -> str:
    obj=state.objects[target.subject_id]
    payload={
        'subject_id':obj.object_id,'statement':obj.metadata.get('statement',''),
        'scope':obj.metadata.get('reviewed_scope',''),'authority':obj.authority.value,
        'status':obj.status.value,'source_refs':sorted(obj.source_refs),
        'certificate_refs':sorted(obj.certificate_refs),'verifier_id':target.verifier_id,
        'verifier_version':target.verifier_version,
    }
    return hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()


def commit_independent_verification_batch(state: NativeState, ledger: EventLedger, targets, *, evidence_dir, batch_id: str) -> VerificationBatchResult:
    checkpoint_id=f'verification:checkpoint:{_short(batch_id)}'
    input_hash=state_hash(state)
    if any(e.event_id==checkpoint_id for e in ledger.events):
        return VerificationBatchResult(batch_id,'IDEMPOTENT_NOOP',state,0,0,0,0,input_hash,input_hash)
    evidence_dir=Path(evidence_dir); evidence_dir.mkdir(parents=True,exist_ok=True)
    sequence=len(ledger.events)+1
    events=[]; upgrades=[]; deferred=0
    for target in sorted(targets,key=lambda t:t.subject_id):
        if target.subject_id not in state.objects:
            raise AuthorityError(f'unknown verification subject: {target.subject_id}')
        obj=state.objects[target.subject_id]
        result=target.verifier()
        artifact_bytes=proof_artifact_bytes(result.artifact)
        artifact_hash=proof_artifact_sha256(result.artifact)
        artifact_name=f'{artifact_hash}.json'
        artifact_path=evidence_dir/artifact_name
        artifact_path.write_bytes(artifact_bytes+b'\n')
        verification_id=f'verification:{_short(target.verifier_id+target.subject_id)}'
        record=IndependentVerificationRecord(
            verification_id=verification_id,subject_id=target.subject_id,
            verifier_id=target.verifier_id,verifier_kind=result.verifier_kind,
            verifier_version=target.verifier_version,statement=str(obj.metadata.get('statement') or obj.object_id),
            scope=str(obj.metadata.get('reviewed_scope') or ''),input_sha256=_input_hash(state,target),
            proof_artifact_sha256=artifact_hash,result=result.result,limitations=list(result.limitations),
            evidence_refs=[f'proof-artifact:sha256:{artifact_hash}']+list(result.evidence_refs),verified_at_version='v0.5',
        )
        verify_event_id=f'verification:record:{_short(verification_id)}'
        events.append(LedgerEvent(verify_event_id,'REGISTER_INDEPENDENT_VERIFICATION',record.to_dict(),sequence,
                                  provenance={'kind':'independent_verification','batch_id':batch_id},operator_version='v0.5',policy_version=state.policy_version)); sequence+=1
        if not proof_eligible(result):
            deferred+=1
            continue
        if obj.authority is not Authority.AUDIT:
            raise AuthorityError(f'{obj.object_id}: expected AUDIT authority before independent upgrade, got {obj.authority.value}')
        cert_id=f'cert:independent:{_short(verification_id)}'
        cert=CertificateRecord(
            certificate_id=cert_id,certificate_type=f'INDEPENDENT_{result.verifier_kind}',subject_ids=[obj.object_id],
            status='VALID',scope=record.scope,evidence_refs=[f'proof-artifact:sha256:{artifact_hash}'],
            verifier_results=[{'verifier_id':target.verifier_id,'verifier_version':target.verifier_version,'result':'VALID','proof_artifact_sha256':artifact_hash}],
            version='v0.5')
        cert_event_id=f'verification:cert:{_short(cert_id)}'
        set_event_id=f'verification:authority:{_short(obj.object_id)}'
        events.append(LedgerEvent(cert_event_id,'REGISTER_CERTIFICATE',cert.to_dict(),sequence,provenance={'kind':'independent_certificate','verification_id':verification_id},operator_version='v0.5',policy_version=state.policy_version)); sequence+=1
        events.append(LedgerEvent(set_event_id,'SET_AUTHORITY',{'object_id':obj.object_id,'authority':'PROOF','certificate_id':cert_id,'cause':verification_id},sequence,certificate_refs=(cert_id,),provenance={'kind':'authority_upgrade','verification_id':verification_id},operator_version='v0.5',policy_version=state.policy_version)); sequence+=1
        upgrades.append((target,record,cert_id,verify_event_id,cert_event_id,set_event_id))

    effect=deepcopy(state)
    for e in events: apply_event(effect,e)
    effect_hash=state_hash(effect)
    for target,record,cert_id,verify_event_id,cert_event_id,set_event_id in upgrades:
        receipt=AuthorityUpgradeReceipt(
            upgrade_id=f'upgrade:{_short(record.verification_id)}',verification_id=record.verification_id,subject_id=target.subject_id,
            old_authority='AUDIT',new_authority='PROOF',certificate_id=cert_id,event_ids=[verify_event_id,cert_event_id,set_event_id],
            state_hash_before=input_hash,state_hash_after=effect_hash)
        events.append(LedgerEvent(f'verification:receipt:{_short(receipt.upgrade_id)}','REGISTER_AUTHORITY_UPGRADE',receipt.to_dict(),sequence,
                                  provenance={'kind':'authority_upgrade_receipt','batch_id':batch_id},operator_version='v0.5',policy_version=state.policy_version)); sequence+=1
    events.append(LedgerEvent(checkpoint_id,'NOTE',{'kind':'independent_verification_checkpoint','batch_id':batch_id,'verification_count':len(targets),'upgrade_count':len(upgrades),'deferred_count':deferred,'effect_state_hash':effect_hash},sequence,provenance={'kind':'independent_verification_checkpoint'},operator_version='v0.5',policy_version=state.policy_version))
    txn=ClosureTransaction(state,ledger)
    for e in events: txn.stage(e)
    tx=txn.commit()
    return VerificationBatchResult(batch_id,tx.commit_status,tx.state,len(targets),len(upgrades),deferred,len(events),tx.input_state_hash,tx.output_state_hash)
