from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
import json
from typing import Iterable

from .model import CandidateRecord, ReviewRecord
from .series_profiles import SeriesProfile, profile_for_code


class ReviewAction(str, Enum):
    PROMOTE_PROOF_ASSET = "PROMOTE_PROOF_ASSET"
    PROMOTE_OBSTRUCTION = "PROMOTE_OBSTRUCTION"
    PROMOTE_SURVIVOR = "PROMOTE_SURVIVOR"
    PROMOTE_FRONTIER = "PROMOTE_FRONTIER"
    PROMOTE_NONCLAIM = "PROMOTE_NONCLAIM"
    MARK_DUPLICATE = "MARK_DUPLICATE"
    REOPEN_RELATED = "REOPEN_RELATED"
    DEFER = "DEFER"
    REJECT = "REJECT"


@dataclass(frozen=True)
class ReviewDecision:
    candidate_id: str
    action: ReviewAction
    reason: str
    theorem_promotion_allowed: bool = False
    tier: str = "TIER0"

    def to_dict(self) -> dict[str, object]:
        return {
            "candidate_id": self.candidate_id,
            "action": self.action.value,
            "reason": self.reason,
            "theorem_promotion_allowed": self.theorem_promotion_allowed,
            "tier": self.tier,
        }


@dataclass(frozen=True)
class ReviewBatch:
    batch_id: str
    review_policy_version: str
    candidate_ids: tuple[str, ...]
    decisions: tuple[ReviewDecision, ...]


_STRUCTURAL = {
    "NonclaimCandidate": ReviewAction.PROMOTE_NONCLAIM,
    "FrontierCandidate": ReviewAction.PROMOTE_FRONTIER,
    "NextFrontierCandidate": ReviewAction.PROMOTE_FRONTIER,
    "SurvivorCandidate": ReviewAction.PROMOTE_SURVIVOR,
}


def _statement(candidate: CandidateRecord) -> str:
    value = (candidate.proposed_object or {}).get("statement")
    return str(value or "")


def _series(candidate: CandidateRecord) -> str:
    meta = (candidate.proposed_object or {}).get("metadata") or {}
    return str(meta.get("series") or "GENERIC_NS")


def classify_structural_candidate(candidate: CandidateRecord, profile: SeriesProfile | None = None) -> ReviewDecision:
    profile = profile or profile_for_code(_series(candidate))
    statement = _statement(candidate)
    lower = statement.lower()

    if candidate.candidate_type in _STRUCTURAL:
        action = _STRUCTURAL[candidate.candidate_type]
        return ReviewDecision(
            candidate_id=candidate.candidate_id,
            action=action,
            reason=f"Explicit {candidate.candidate_type} is safe for structural review only.",
            theorem_promotion_allowed=False,
        )

    if candidate.candidate_type == "StatusCandidate" and profile.research_cycle_closed_is_process_only and "closed" in lower:
        return ReviewDecision(
            candidate_id=candidate.candidate_id,
            action=ReviewAction.DEFER,
            reason="Research-cycle closure is process metadata, not theorem closure.",
            theorem_promotion_allowed=False,
        )

    if candidate.candidate_type in {"TheoremCandidate", "StatusCandidate", "ObstructionCandidate"}:
        return ReviewDecision(
            candidate_id=candidate.candidate_id,
            action=ReviewAction.DEFER,
            reason="Theorem-bearing or obstruction-bearing candidate requires semantic/evidence review.",
            theorem_promotion_allowed=False,
        )

    return ReviewDecision(
        candidate_id=candidate.candidate_id,
        action=ReviewAction.DEFER,
        reason="Candidate class is outside Tier-0 structural promotion.",
        theorem_promotion_allowed=False,
    )


def build_structural_review_batch(candidates: Iterable[CandidateRecord], review_policy_version: str = "v0.3") -> ReviewBatch:
    ordered = sorted(candidates, key=lambda c: c.candidate_id)
    payload = [c.to_dict() for c in ordered]
    raw = json.dumps(
        {"review_policy_version": review_policy_version, "candidates": payload},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    batch_id = f"review-batch:{hashlib.sha256(raw).hexdigest()[:24]}"
    decisions = tuple(classify_structural_candidate(c) for c in ordered)
    return ReviewBatch(
        batch_id=batch_id,
        review_policy_version=review_policy_version,
        candidate_ids=tuple(c.candidate_id for c in ordered),
        decisions=decisions,
    )


def decision_to_review_record(
    decision: ReviewDecision,
    candidate: CandidateRecord,
    *,
    review_id: str,
    status: str = "APPROVED",
    target_native_id: str | None = None,
    review_version: str = "v0.3",
) -> ReviewRecord:
    return ReviewRecord(
        review_id=review_id,
        candidate_id=candidate.candidate_id,
        decision=decision.action.value,
        reviewer_type="STRUCTURAL_TIER0",
        reason=decision.reason,
        scope="formal",
        evidence_refs=[candidate.source_ref],
        certificate_refs=[],
        target_native_id=target_native_id,
        review_version=review_version,
        status=status,
    )
