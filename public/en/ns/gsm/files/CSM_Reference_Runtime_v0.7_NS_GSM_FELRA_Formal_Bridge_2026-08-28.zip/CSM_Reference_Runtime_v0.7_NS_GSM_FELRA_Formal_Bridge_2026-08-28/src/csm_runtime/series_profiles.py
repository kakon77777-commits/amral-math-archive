from __future__ import annotations

from dataclasses import dataclass
import re


@dataclass(frozen=True)
class SeriesProfile:
    code: str
    research_cycle_closed_is_process_only: bool = False
    stop_semantics: str = "FRONTIER_CANDIDATE"
    auto_theorem_promotion: bool = False
    default_artifact_authority: str = "RESEARCH"


_PROFILES = {
    "C": SeriesProfile("C"),
    "RFP": SeriesProfile("RFP", research_cycle_closed_is_process_only=True),
    "MORP": SeriesProfile("MORP"),
    "X72": SeriesProfile("X72"),
    "DCRP": SeriesProfile("DCRP"),
    "FCBP": SeriesProfile("FCBP"),
    "PAM": SeriesProfile("PAM"),
    "GENERIC_NS": SeriesProfile("GENERIC_NS"),
}


def profile_for_filename(filename: str) -> SeriesProfile:
    name = filename.upper()
    # DCRP files commonly also contain X72 bridge round identifiers; choose DCRP first.
    if "DCRP" in name:
        return _PROFILES["DCRP"]
    if "_RFP_" in name or name.startswith("NS_RFP"):
        return _PROFILES["RFP"]
    if "_MORP_" in name or name.startswith("NS_MORP"):
        return _PROFILES["MORP"]
    if "FCBP" in name:
        return _PROFILES["FCBP"]
    if "PROOF_ASSET" in name or "PROOF-ASSET" in name:
        return _PROFILES["PAM"]
    if "X72" in name or "24/72" in name:
        return _PROFILES["X72"]
    if re.search(r"NS_C[1-6][A-Z0-9_-]", name) or name.startswith("NS_C1") or name.startswith("NS_C2"):
        return _PROFILES["C"]
    return _PROFILES["GENERIC_NS"]


def profile_for_code(code: str) -> SeriesProfile:
    return _PROFILES.get(code.upper(), _PROFILES["GENERIC_NS"])
