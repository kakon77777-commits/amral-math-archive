from __future__ import annotations
from dataclasses import dataclass, field
import hashlib, json
from typing import Any

PROOF_ELIGIBLE_KINDS = {"SYMBOLIC_EXACT", "EXACT_WITNESS", "ANALYTIC_SCHEMA", "GRAPH_THEOREM_REDUCTION", "INDEPENDENT_AUDIT"}

@dataclass(frozen=True)
class VerificationResult:
    result: str
    verifier_kind: str
    artifact: dict[str, Any]
    limitations: list[str] = field(default_factory=list)
    evidence_refs: list[str] = field(default_factory=list)


def proof_artifact_bytes(artifact: dict[str, Any]) -> bytes:
    return json.dumps(artifact, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def proof_artifact_sha256(artifact: dict[str, Any]) -> str:
    return hashlib.sha256(proof_artifact_bytes(artifact)).hexdigest()


def proof_eligible(result: VerificationResult) -> bool:
    return result.result == "VALID" and result.verifier_kind in PROOF_ELIGIBLE_KINDS and not result.limitations
