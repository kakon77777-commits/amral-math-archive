from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib, json

from .canonical import state_hash
from .enums import Authority
from .errors import AuthorityError
from .ledger import EventLedger, LedgerEvent
from .model import CertificateRecord, FELRAFormalRunRecord, FormalObligationRecord, KernelFormalProofReceipt, NativeState, TranslationCertificateRecord
from .state import apply_event
from .transaction import ClosureTransaction


def _short(s: str) -> str: return hashlib.sha256(s.encode()).hexdigest()[:24]
def _digest(v) -> str: return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def _event(eid,typ,payload,seq,state,certs=()):
    return LedgerEvent(eid,typ,payload,seq,certificate_refs=tuple(certs),provenance={'kind':'v07_kernel_formal'},operator_version='v0.7',policy_version=state.policy_version)

@dataclass
class KernelFormalBatchResult:
    status: str
    state: NativeState
    event_count: int=0
    input_state_hash: str=''
    output_state_hash: str=''


def commit_kernel_formal_proof(state: NativeState, ledger: EventLedger, translation: TranslationCertificateRecord, obligation: FormalObligationRecord, formal_run: FELRAFormalRunRecord, *, batch_id: str) -> KernelFormalBatchResult:
    checkpoint=f'v07:kernel:checkpoint:{_short(batch_id)}'
    ih=state_hash(state)
    if any(e.event_id==checkpoint for e in ledger.events):
        return KernelFormalBatchResult('IDEMPOTENT_NOOP',state,0,ih,ih)
    subject=translation.subject_id
    obj=state.objects.get(subject)
    if obj is None: raise AuthorityError('unknown formal proof subject')
    if obj.authority is not Authority.PROOF: raise AuthorityError('FORMAL_PROOF requires base PROOF authority')
    if 'FORMALIZED_CORE_ONLY' not in (obj.metadata.get('authority_tiers') or []): raise AuthorityError('FORMAL_PROOF requires formalized core tier')
    if translation.status!='VALID' or translation.backend!='lean': raise AuthorityError('VALID Lean translation required')
    if obligation.subject_id!=subject or obligation.translation_id!=translation.translation_id or obligation.backend!='lean': raise AuthorityError('formal obligation identity mismatch')
    if obligation.obligation_sha256!=translation.obligation_sha256 or obligation.project_digest_sha256!=translation.project_digest_sha256: raise AuthorityError('translation/obligation digest mismatch')
    if formal_run.subject_id!=subject or formal_run.backend!='lean' or formal_run.formal_status!='verified' or formal_run.status!='VALID': raise AuthorityError('verified VALID Lean formal run required')
    if formal_run.obligation_sha256!=obligation.obligation_sha256: raise AuthorityError('formal run obligation hash mismatch')
    if not formal_run.checker_version or len(formal_run.checker_executable_sha256)!=64: raise AuthorityError('checker version/hash required')
    if not formal_run.theorems_audited or formal_run.theorems_audited<1: raise AuthorityError('non-vacuous axiom audit required')
    allowed=set((obligation.axiom_policy or {}).get('allowed') or [])
    if not set(formal_run.axioms_seen).issubset(allowed): raise AuthorityError('axiom overflow')

    cert_id=f'cert:kernel-formal:{_short(subject+formal_run.formal_run_id)}'
    cert=CertificateRecord(cert_id,'KERNEL_FORMAL_PROOF',[subject],'VALID',scope=str(obj.metadata.get('reviewed_scope') or ''),
        evidence_refs=list(formal_run.evidence_refs)+list(translation.evidence_refs),
        verifier_results=[{'kernel_checked':True,'tool':'lean','checker_version':formal_run.checker_version,
            'checker_executable_sha256':formal_run.checker_executable_sha256,'proof_object_sha256':obligation.obligation_sha256,
            'formal_run_id':formal_run.formal_run_id,'translation_id':translation.translation_id}],version='v0.7')
    seq=len(ledger.events)+1; events=[]
    if translation.translation_id not in state.translation_certificates:
        events.append(_event(f'v07:translation:{_short(translation.translation_id)}','REGISTER_TRANSLATION_CERTIFICATE',translation.to_dict(),seq,state)); seq+=1
    if obligation.obligation_id not in state.formal_obligations:
        events.append(_event(f'v07:obligation:{_short(obligation.obligation_id)}','REGISTER_FORMAL_OBLIGATION',obligation.to_dict(),seq,state)); seq+=1
    if formal_run.formal_run_id not in state.felra_formal_runs:
        events.append(_event(f'v07:felra-run:{_short(formal_run.formal_run_id)}','REGISTER_FELRA_FORMAL_RUN',formal_run.to_dict(),seq,state)); seq+=1
    events.append(_event(f'v07:kernel-cert:{_short(cert_id)}','REGISTER_CERTIFICATE',cert.to_dict(),seq,state,(cert_id,))); seq+=1
    tier_eid=f'v07:kernel-tier:{_short(subject)}'
    events.append(_event(tier_eid,'ADD_AUTHORITY_TIER',{'object_id':subject,'tier_type':'FORMAL_PROOF','certificate_id':cert_id},seq,state,(cert_id,))); seq+=1
    effect=deepcopy(state)
    for e in events: apply_event(effect,e)
    effect_hash=state_hash(effect)
    receipt=KernelFormalProofReceipt(
        formal_proof_receipt_id=f'kernel-formal-proof:{_short(subject+formal_run.formal_run_id)}',subject_id=subject,backend='lean',
        translation_id=translation.translation_id,formal_run_id=formal_run.formal_run_id,certificate_id=cert_id,
        obligation_sha256=obligation.obligation_sha256,checker_executable_sha256=formal_run.checker_executable_sha256,
        axiom_policy_digest=_digest(obligation.axiom_policy),event_ids=[e.event_id for e in events],state_hash_before=ih,state_hash_after=effect_hash)
    events.append(_event(f'v07:kernel-receipt:{_short(receipt.formal_proof_receipt_id)}','REGISTER_KERNEL_FORMAL_PROOF_RECEIPT',receipt.to_dict(),seq,state)); seq+=1
    events.append(_event(checkpoint,'NOTE',{'kind':'v07_kernel_checkpoint','batch_id':batch_id},seq,state))
    txn=ClosureTransaction(state,ledger)
    for e in events: txn.stage(e)
    tx=txn.commit()
    return KernelFormalBatchResult(tx.commit_status,tx.state,len(events),tx.input_state_hash,tx.output_state_hash)
