from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class AuthorityManifestEntry:
    audit_id: str
    source_path: str
    source_sha256: str
    subject_id: str
    subject_kind: str
    statement: str
    scope: str
    assumptions: tuple[str, ...]
    certificate_refs: tuple[str, ...]
    nonclaim_refs: tuple[str, ...]
    verdict: str
    authority_cap: str
    reason: str
    source_anchor: str = ""
    canonical_restatement: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "audit_id": self.audit_id,
            "source_path": self.source_path,
            "source_sha256": self.source_sha256,
            "subject_id": self.subject_id,
            "subject_kind": self.subject_kind,
            "statement": self.statement,
            "scope": self.scope,
            "assumptions": list(self.assumptions),
            "certificate_refs": list(self.certificate_refs),
            "nonclaim_refs": list(self.nonclaim_refs),
            "verdict": self.verdict,
            "authority_cap": self.authority_cap,
            "reason": self.reason,
            "source_anchor": self.source_anchor,
            "canonical_restatement": self.canonical_restatement,
        }


@dataclass(frozen=True)
class AuthorityReviewManifest:
    version: str
    entries: tuple[AuthorityManifestEntry, ...]
    manifest_hash: str


def _entry(data: dict[str, Any]) -> AuthorityManifestEntry:
    return AuthorityManifestEntry(
        audit_id=data["audit_id"],
        source_path=data["source_path"],
        source_sha256=data["source_sha256"],
        subject_id=data["subject_id"],
        subject_kind=data["subject_kind"],
        statement=data["statement"],
        scope=data.get("scope", ""),
        assumptions=tuple(data.get("assumptions") or ()),
        certificate_refs=tuple(data.get("certificate_refs") or ()),
        nonclaim_refs=tuple(data.get("nonclaim_refs") or ()),
        verdict=data.get("verdict", "DEFER_OPEN_OBLIGATION"),
        authority_cap=data.get("authority_cap", "AUDIT"),
        reason=data.get("reason", ""),
        source_anchor=data.get("source_anchor", ""),
        canonical_restatement=bool(data.get("canonical_restatement", False)),
    )


def load_authority_manifest(path: str | Path) -> AuthorityReviewManifest:
    path = Path(path)
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    version = str(raw.get("version", "v0.4"))
    entries = tuple(sorted((_entry(item) for item in raw.get("entries") or []), key=lambda x: x.audit_id))
    payload = {
        "version": version,
        "entries": [entry.to_dict() for entry in entries],
    }
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return AuthorityReviewManifest(version=version, entries=entries, manifest_hash=hashlib.sha256(canonical).hexdigest())
