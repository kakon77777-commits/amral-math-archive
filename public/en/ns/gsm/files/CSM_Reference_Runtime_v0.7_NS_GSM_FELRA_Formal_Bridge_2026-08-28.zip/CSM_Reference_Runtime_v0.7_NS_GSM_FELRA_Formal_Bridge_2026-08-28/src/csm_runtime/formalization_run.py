from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path

from .external_anchor import ExternalAnchorCommitResult, commit_external_anchor, load_external_anchor_manifest
from .formalization import build_formalization_bundle, formalization_record_for_asset, v06_proof_assets
from .replication import run_replication
from .tier_batch import TierBatchResult, commit_formalization_replication_tiers
from .verification_run import V05VerificationRun, run_v05_independent_verification


def _canonical_bytes(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


@dataclass
class V06FormalizationRun:
    baseline: V05VerificationRun
    tier_batch: TierBatchResult
    anchor_batch: ExternalAnchorCommitResult
    state: object
    ledger: object
    formalizations: list
    replications: list
    anchor: object

    def reapply(self, evidence_dir):
        tier = commit_formalization_replication_tiers(
            self.state, self.ledger, self.formalizations, self.replications,
            batch_id="v0.6-formalization-replication",
        )
        anchor = commit_external_anchor(
            tier.state, self.ledger, self.anchor, batch_id="v0.6-ess-external-anchor"
        )
        return tier, anchor


def run_v06_formalization_replication(root, evidence_dir) -> V06FormalizationRun:
    root=Path(root); evidence_dir=Path(evidence_dir)
    baseline=run_v05_independent_verification(
        root/'fixtures/NS_GSM_Seed_Dataset_v0.1', root/'corpus',
        expansion_root=root/'corpus_v03_expansion',
        authority_manifest=root/'authority_review_manifest_v0.4.yaml',
        evidence_dir=evidence_dir/'v05-verifiers',
    )
    formal_dir=evidence_dir/'formalizations'; formal_dir.mkdir(parents=True,exist_ok=True)
    repl_dir=evidence_dir/'replications'; repl_dir.mkdir(parents=True,exist_ok=True)
    formals=[]; replications=[]
    script=root/'replicators/ns_gsm_replica_v06.py'
    for obj in v06_proof_assets(baseline.state):
        bundle=build_formalization_bundle(baseline.state,obj.object_id)
        formal=formalization_record_for_asset(baseline.state,obj.object_id)
        (formal_dir/f'{formal.bundle_sha256}.json').write_bytes(_canonical_bytes(bundle)+b'\n')
        repl=run_replication(bundle,formal,script,repl_dir)
        formals.append(formal); replications.append(repl)
    tier=commit_formalization_replication_tiers(
        baseline.state,baseline.ledger,formals,replications,batch_id='v0.6-formalization-replication')
    anchors=load_external_anchor_manifest(root/'external_theorem_anchors_v0.6.yaml')
    if len(anchors)!=1:
        raise ValueError('v0.6 requires exactly one external theorem anchor')
    anchor=anchors[0]
    anchor_batch=commit_external_anchor(tier.state,baseline.ledger,anchor,batch_id='v0.6-ess-external-anchor')
    return V06FormalizationRun(baseline,tier,anchor_batch,anchor_batch.state,baseline.ledger,formals,replications,anchor)
