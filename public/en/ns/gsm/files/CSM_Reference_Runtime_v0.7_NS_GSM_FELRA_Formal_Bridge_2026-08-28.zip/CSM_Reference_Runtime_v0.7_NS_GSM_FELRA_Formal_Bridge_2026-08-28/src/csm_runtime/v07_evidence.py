from __future__ import annotations
import json
from pathlib import Path
from .canonical import state_hash
from .query import QueryEngine
from .replay import replay_ledger


def _write(root,name,value):
    (root/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,sort_keys=True)+"\n",encoding='utf-8')

def write_v07_evidence(run,evidence_dir):
    root=Path(evidence_dir); root.mkdir(parents=True,exist_ok=True)
    q=QueryEngine(run.state)
    bridges=q.formalization_bridges().answer
    translations=q.translation_certificates().answer
    obligations=q.formal_obligations().answer
    runs=q.felra_formal_runs().answer
    receipts=q.kernel_formal_proofs().answer
    proof_assets=q.formal_proof_assets().answer
    deferred=q.formal_proof_deferred().answer
    manifests=[x.bridge_manifest for x in run.exports]
    _write(root,'bridge_manifest.json',{'count':len(manifests),'bridges':manifests})
    _write(root,'translations.json',{'count':len(translations),'translations':translations})
    _write(root,'formal_obligations.json',{'count':len(obligations),'obligations':obligations})
    _write(root,'felra_formal_runs.json',{'count':len(runs),'runs':runs})
    _write(root,'kernel_formal_proof_receipts.json',{'count':len(receipts),'receipts':receipts})
    _write(root,'formal_proof_assets.json',{'count':len(proof_assets),'assets':proof_assets})
    _write(root,'formal_proof_deferred.json',{'count':len(deferred),'deferred':deferred})
    _write(root,'kernel_revalidation.json',{'performed':False,'reason':'no fresh external kernel revalidation requested during evidence freeze'})
    current=state_hash(run.state)
    with (root/'ns_gsm_v07_ledger.jsonl').open('w',encoding='utf-8',newline='\n') as f:
        for e in run.ledger.events: f.write(json.dumps(e.to_dict(),ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
    _write(root,'native_snapshot.json',{'state_hash':current,'state':run.state.to_dict()})
    replayed=replay_ledger(run.ledger.events,policy_version=run.state.policy_version); rh=state_hash(replayed)
    replay={'expected_hash':current,'replayed_hash':rh,'match':rh==current,'event_count':len(run.ledger.events)}
    _write(root,'replay_report.json',replay)
    reapply=run.reapply()
    checks={
      'bridge_count_5':len(bridges)==5,
      'translation_count_5':len(translations)==5,
      'all_translations_valid':all(x['status']=='VALID' for x in translations),
      'obligation_count_5':len(obligations)==5,
      'formal_proof_count_explicit':len(proof_assets)>=0,
      'bridge_ready_zero_proofs':run.release_mode!='BRIDGE_READY' or len(proof_assets)==0,
      'root_open':run.state.objects['claim:formal-root-regularity'].status.value=='OPEN',
      'c1_open':run.state.objects['claim:c1-chain-necessity'].status.value=='OPEN',
      'c2_open':run.state.objects['claim:c2-finite-obstruction'].status.value=='OPEN',
      'replay_exact':replay['match'],
      'bridge_reapply_idempotent':reapply=='IDEMPOTENT_NOOP',
      'canonical_runs_path_free':all('/tmp/' not in json.dumps(x) and ':\\' not in json.dumps(x) for x in runs),
    }
    con={'suite':'NS_GSM v0.7 FELRA bridge','passed':sum(checks.values()),'total':len(checks),'all_passed':all(checks.values()),'checks':checks}
    _write(root,'conformance_report.json',con)
    summary={'version':'v0.7','runtime_version':'0.7.0','release_mode':run.release_mode,'scope':run.state.scope,'root_status':run.state.objects['claim:formal-root-regularity'].status.value,'state_hash':current,'replay_match':replay['match'],'ledger_event_count':len(run.ledger.events),'bridge_count':len(bridges),'translation_count':len(translations),'formal_obligation_count':len(obligations),'felra_formal_run_count':len(runs),'formal_proof_count':len(proof_assets),'deferred_count':len(deferred),'conformance_all_passed':con['all_passed']}
    _write(root,'run_summary.json',summary)
    return summary
