"""CSM Reference Runtime v0.7."""

__version__ = "0.7.0"
