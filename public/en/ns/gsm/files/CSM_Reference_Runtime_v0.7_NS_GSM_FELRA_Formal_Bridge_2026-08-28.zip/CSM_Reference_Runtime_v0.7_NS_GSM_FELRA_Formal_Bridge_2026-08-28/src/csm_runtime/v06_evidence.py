from __future__ import annotations

import json
from pathlib import Path

from .canonical import state_hash
from .query import QueryEngine
from .replay import replay_ledger


def _write_json(root: Path, name: str, value) -> None:
    (root / name).write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8", newline="\n",
    )


def write_v06_evidence(run, evidence_dir) -> dict:
    root = Path(evidence_dir)
    root.mkdir(parents=True, exist_ok=True)
    q = QueryEngine(run.state)

    formalizations = q.formalizations().answer
    replications = q.replications().answer
    anchors = q.external_theorem_anchors().answer
    tiers = q.authority_tiers().answer
    formal_proofs = q.formal_proof_assets().answer
    replicated = q.replicated_assets().answer

    _write_json(root, "formalizations_v06.json", {"count": len(formalizations), "formalizations": formalizations})
    _write_json(root, "replications_v06.json", {"count": len(replications), "replications": replications})
    _write_json(root, "external_anchors_v06.json", {"count": len(anchors), "anchors": anchors})
    _write_json(root, "authority_tiers_v06.json", {"count": len(tiers), "assets": tiers})
    _write_json(root, "formal_proof_assets_v06.json", {"count": len(formal_proofs), "assets": formal_proofs})
    _write_json(root, "replicated_assets_v06.json", {"count": len(replicated), "assets": replicated})

    current_hash = state_hash(run.state)
    with (root / "ns_gsm_v06_ledger.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
        for event in run.ledger.events:
            handle.write(json.dumps(event.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
    _write_json(root, "native_snapshot_v06.json", {"state_hash": current_hash, "state": run.state.to_dict()})

    replayed = replay_ledger(run.ledger.events, policy_version=run.state.policy_version)
    replay_hash = state_hash(replayed)
    replay = {
        "expected_hash": current_hash,
        "replayed_hash": replay_hash,
        "match": replay_hash == current_hash,
        "event_count": len(run.ledger.events),
    }
    _write_json(root, "replay_report_v06.json", replay)

    tier_again, anchor_again = run.reapply(root / "reapply")
    proof_assets = [o for o in run.state.objects.values() if o.authority.value == "PROOF"]
    replicated_ids = {x["object_id"] for x in replicated}
    formalized_ids = {
        x["object_id"] for x in tiers if "FORMALIZED_CORE_ONLY" in x["tiers"]
    }
    anchor_subjects = {a["subject_id"] for a in anchors}

    checks = {
        "root_open": run.state.objects["claim:formal-root-regularity"].status.value == "OPEN",
        "c1_open": run.state.objects["claim:c1-chain-necessity"].status.value == "OPEN",
        "c2_open": run.state.objects["claim:c2-finite-obstruction"].status.value == "OPEN",
        "formalization_count_12": len(formalizations) == 12,
        "replication_count_12": len(replications) == 12,
        "all_replications_match": all(r["result"] == "MATCH" for r in replications),
        "all_proof_assets_formalized": len(proof_assets) == 12 and {o.object_id for o in proof_assets} == formalized_ids,
        "all_proof_assets_replicated": len(proof_assets) == 12 and {o.object_id for o in proof_assets} == replicated_ids,
        "formal_proof_count_zero": len(formal_proofs) == 0,
        "external_anchor_count_one": len(anchors) == 1,
        "etnx_anchor_subject_exact": anchor_subjects == {"claim:uv-escape-necessity"},
        "etnx_base_authority_stays_audit": run.state.objects["claim:uv-escape-necessity"].authority.value == "AUDIT",
        "replay_exact": replay["match"],
        "tier_batch_idempotent": tier_again.status == "IDEMPOTENT_NOOP",
        "anchor_batch_idempotent": anchor_again.status == "IDEMPOTENT_NOOP",
    }
    conformance = {
        "suite": "NS_GSM v0.6 formalization / cross-implementation replication",
        "passed": sum(checks.values()),
        "total": len(checks),
        "all_passed": all(checks.values()),
        "checks": checks,
    }
    _write_json(root, "conformance_report_v06.json", conformance)

    summary = {
        "version": "v0.6",
        "runtime_version": "0.6.0",
        "scope": run.state.scope,
        "root_status": run.state.objects["claim:formal-root-regularity"].status.value,
        "state_hash": current_hash,
        "replay_match": replay["match"],
        "ledger_event_count": len(run.ledger.events),
        "formalization_count": len(formalizations),
        "replication_count": len(replications),
        "replication_match_count": sum(r["result"] == "MATCH" for r in replications),
        "formalized_asset_count": len(formalized_ids),
        "replicated_asset_count": len(replicated_ids),
        "external_anchor_count": len(anchors),
        "formal_proof_count": len(formal_proofs),
        "conformance_all_passed": conformance["all_passed"],
    }
    _write_json(root, "run_summary_v06.json", summary)
    return summary
