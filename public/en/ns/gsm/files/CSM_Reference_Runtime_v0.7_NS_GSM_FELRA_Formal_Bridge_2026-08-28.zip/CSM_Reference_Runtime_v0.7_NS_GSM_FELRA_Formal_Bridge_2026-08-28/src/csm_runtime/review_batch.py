from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib

from .canonical import state_hash
from .errors import UnknownObjectError, ValidationError
from .ledger import EventLedger, LedgerEvent
from .model import NativeState, PromotionReceipt
from .promotion import promote_frontier, promote_nonclaim, promote_obstruction, promote_survivor
from .review import ReviewAction, ReviewBatch, decision_to_review_record
from .state import apply_event
from .transaction import ClosureTransaction


@dataclass(frozen=True)
class ReviewBatchResult:
    batch_id: str
    status: str
    state: NativeState
    input_state_hash: str
    output_state_hash: str
    event_count: int
    review_count: int
    promotion_count: int


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:24]


def _review_id(batch_id: str, candidate_id: str) -> str:
    return f"review:{_digest(batch_id + '|' + candidate_id)}"


def _promotion_id(review_id: str, object_id: str) -> str:
    return f"promotion:{_digest(review_id + '|' + object_id)}"


def _promote_for_action(working: NativeState, candidate, review, action: ReviewAction):
    if action is ReviewAction.PROMOTE_NONCLAIM:
        return promote_nonclaim(working, candidate, review)
    if action is ReviewAction.PROMOTE_FRONTIER:
        return promote_frontier(working, candidate, review)
    if action is ReviewAction.PROMOTE_SURVIVOR:
        return promote_survivor(working, candidate, review)
    if action is ReviewAction.PROMOTE_OBSTRUCTION:
        return promote_obstruction(working, candidate, review)
    return None


def commit_review_batch(state: NativeState, ledger: EventLedger, batch: ReviewBatch) -> ReviewBatchResult:
    checkpoint_id = f"review:checkpoint:{batch.batch_id.split(':')[-1]}"
    input_hash = state_hash(state)
    if any(e.event_id == checkpoint_id for e in ledger.events):
        return ReviewBatchResult(
            batch_id=batch.batch_id,
            status="IDEMPOTENT_NOOP",
            state=state,
            input_state_hash=input_hash,
            output_state_hash=input_hash,
            event_count=0,
            review_count=0,
            promotion_count=0,
        )

    decision_by_id = {d.candidate_id: d for d in batch.decisions}
    if set(decision_by_id) != set(batch.candidate_ids):
        raise ValidationError("review batch candidate/decision mismatch")
    for candidate_id in batch.candidate_ids:
        if candidate_id not in state.candidates:
            raise UnknownObjectError(candidate_id)

    # Precompute all review/promotion effects against an isolated state.
    promotion_working = deepcopy(state)
    review_records = []
    promoted_objects = []
    review_event_ids: dict[str, str] = {}
    object_event_ids: dict[str, str] = {}

    for candidate_id in sorted(batch.candidate_ids):
        candidate = state.candidates[candidate_id]
        decision = decision_by_id[candidate_id]
        review_id = _review_id(batch.batch_id, candidate_id)
        status = "APPROVED" if decision.action.name.startswith("PROMOTE_") else (
            "REJECTED" if decision.action is ReviewAction.REJECT else "DEFERRED"
        )
        review = decision_to_review_record(
            decision,
            candidate,
            review_id=review_id,
            status=status,
            review_version=batch.review_policy_version,
        )
        obj = _promote_for_action(promotion_working, candidate, review, decision.action)
        review_records.append(review)
        if obj is not None:
            promoted_objects.append((review, obj))
        review_event_ids[review_id] = f"review:event:{_digest(review_id)}"
        if obj is not None:
            object_event_ids[obj.object_id] = f"review:object:{_digest(obj.object_id)}"

    # Build base effects (reviews + native structural objects) first.
    events: list[LedgerEvent] = []
    sequence = len(ledger.events) + 1
    for review in sorted(review_records, key=lambda r: r.review_id):
        events.append(LedgerEvent(
            event_id=review_event_ids[review.review_id],
            event_type="REGISTER_REVIEW",
            payload=review.to_dict(),
            sequence=sequence,
            provenance={"kind": "candidate_review", "batch_id": batch.batch_id},
            operator_version="v0.3",
            policy_version=state.policy_version,
        ))
        sequence += 1
        match = next((obj for r, obj in promoted_objects if r.review_id == review.review_id), None)
        if match is not None:
            events.append(LedgerEvent(
                event_id=object_event_ids[match.object_id],
                event_type="REGISTER_OBJECT",
                payload=match.to_dict(),
                sequence=sequence,
                provenance={"kind": "review_promotion", "review_id": review.review_id},
                operator_version="v0.3",
                policy_version=state.policy_version,
            ))
            sequence += 1

    effect_state = deepcopy(state)
    for event in events:
        apply_event(effect_state, event)
    effect_hash = state_hash(effect_state)

    # Receipts record the before/after hash of the promotion effects; receipt registration itself is later in the same atomic transaction.
    for review, obj in sorted(promoted_objects, key=lambda pair: pair[1].object_id):
        receipt = PromotionReceipt(
            promotion_id=_promotion_id(review.review_id, obj.object_id),
            review_id=review.review_id,
            candidate_id=review.candidate_id,
            native_object_id=obj.object_id,
            promotion_class=obj.object_type,
            certificate_refs=list(obj.certificate_refs),
            debt_refs=list(obj.debt_refs),
            event_ids=[review_event_ids[review.review_id], object_event_ids[obj.object_id]],
            state_hash_before=input_hash,
            state_hash_after=effect_hash,
        )
        events.append(LedgerEvent(
            event_id=f"review:receipt:{_digest(receipt.promotion_id)}",
            event_type="REGISTER_PROMOTION_RECEIPT",
            payload=receipt.to_dict(),
            sequence=sequence,
            provenance={"kind": "promotion_receipt", "batch_id": batch.batch_id},
            operator_version="v0.3",
            policy_version=state.policy_version,
        ))
        sequence += 1

    events.append(LedgerEvent(
        event_id=checkpoint_id,
        event_type="NOTE",
        payload={
            "kind": "review_checkpoint",
            "batch_id": batch.batch_id,
            "review_policy_version": batch.review_policy_version,
            "review_count": len(review_records),
            "promotion_count": len(promoted_objects),
            "effect_state_hash": effect_hash,
        },
        sequence=sequence,
        provenance={"kind": "review_checkpoint"},
        operator_version="v0.3",
        policy_version=state.policy_version,
    ))

    txn = ClosureTransaction(state, ledger)
    for event in events:
        txn.stage(event)
    result = txn.commit()
    return ReviewBatchResult(
        batch_id=batch.batch_id,
        status=result.commit_status,
        state=result.state,
        input_state_hash=result.input_state_hash,
        output_state_hash=result.output_state_hash,
        event_count=len(events),
        review_count=len(review_records),
        promotion_count=len(promoted_objects),
    )
