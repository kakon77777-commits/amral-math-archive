from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib
from pathlib import Path

from .authority_audit import AuditOutcome, AuthorityAuditVerifier, certificate_authority_cap
from .authority_manifest import AuthorityManifestEntry
from .canonical import state_hash
from .enums import Authority, ClosureStatus
from .errors import AuthorityError
from .ledger import EventLedger, LedgerEvent
from .model import CertificateRecord, NativeState, ObjectRecord, PromotionReceipt
from .state import apply_event
from .transaction import ClosureTransaction


@dataclass(frozen=True)
class AuthorityBatchResult:
    batch_id: str
    status: str
    state: NativeState
    input_state_hash: str
    output_state_hash: str
    event_count: int
    audit_count: int
    promotion_count: int
    deferred_count: int


def _short(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:24]


def _series_for(state: NativeState, entry: AuthorityManifestEntry) -> str | None:
    if entry.subject_kind == "CANDIDATE":
        candidate = state.candidates.get(entry.subject_id)
        if candidate:
            return str(((candidate.proposed_object or {}).get("metadata") or {}).get("series") or "GENERIC_NS")
    obj = state.objects.get(entry.subject_id)
    if obj:
        return str((obj.metadata or {}).get("series") or "SEED")
    return None


def _effective_cap(state: NativeState, entry: AuthorityManifestEntry) -> Authority:
    requested = Authority(entry.authority_cap)
    if requested is not Authority.PROOF:
        return Authority.AUDIT if requested is Authority.AUDIT else requested
    for cert_id in entry.certificate_refs:
        if certificate_authority_cap(state, cert_id) is Authority.PROOF:
            return Authority.PROOF
    return Authority.AUDIT


def _asset_records(state: NativeState, entry: AuthorityManifestEntry):
    if entry.verdict not in {"PROMOTE_AUDIT_ASSET", "PROMOTE_AUDIT_OBSTRUCTION"}:
        return None, None
    kind = "PROOF_ASSET" if entry.verdict == "PROMOTE_AUDIT_ASSET" else "OBSTRUCTION"
    object_id = f"authority:{kind.lower()}:{_short(entry.audit_id)}"
    cert_id = f"cert:authority:{_short(entry.audit_id)}"
    cert_type = "SOURCE_INTERNAL_PROOF" if kind == "PROOF_ASSET" else "SOURCE_INTERNAL_NO_GO"
    source_cert = CertificateRecord(
        certificate_id=cert_id,
        certificate_type=cert_type,
        subject_ids=[object_id],
        status="VALID_SOURCE_ASSERTION",
        scope=entry.scope,
        evidence_refs=[entry.source_path, entry.audit_id],
        verifier_results=[],
        version="v0.4",
    )
    authority = _effective_cap(state, entry)
    obj = ObjectRecord(
        object_id=object_id,
        object_type=kind,
        domain_id="formal",
        version="v0.4",
        status=ClosureStatus.CLOSED_POSITIVE if kind == "PROOF_ASSET" else ClosureStatus.OPEN,
        role_tags=[kind],
        source_refs=[entry.source_path],
        certificate_refs=[cert_id] + list(entry.certificate_refs),
        authority=authority,
        metadata={
            "authority_audit_id": entry.audit_id,
            "source_subject_id": entry.subject_id,
            "statement": entry.statement,
            "reviewed_scope": entry.scope,
            "assumptions": list(entry.assumptions),
            "series": _series_for(state, entry),
            "source_claim_status": "SOURCE_INTERNAL",
            "parent_mutation_authorized": False,
        },
    )
    return source_cert, obj


def commit_authority_review_batch(
    state: NativeState,
    ledger: EventLedger,
    entries: list[AuthorityManifestEntry] | tuple[AuthorityManifestEntry, ...],
    *,
    source_root: str | Path,
    batch_id: str,
) -> AuthorityBatchResult:
    checkpoint_id = f"authority:checkpoint:{_short(batch_id)}"
    input_hash = state_hash(state)
    if any(event.event_id == checkpoint_id for event in ledger.events):
        return AuthorityBatchResult(batch_id, "IDEMPOTENT_NOOP", state, input_hash, input_hash, 0, 0, 0, 0)

    verifier = AuthorityAuditVerifier(source_root)
    verified = []
    deferred = 0
    for entry in sorted(entries, key=lambda item: item.audit_id):
        result = verifier.verify_entry(state, entry)
        if result.outcome is AuditOutcome.REFUSE:
            raise AuthorityError(f"{entry.audit_id}: {result.reason}")
        if result.outcome is AuditOutcome.DEFER:
            deferred += 1
        verified.append((entry, result, verifier.to_record(entry, result)))

    sequence = len(ledger.events) + 1
    events: list[LedgerEvent] = []
    promotion_meta: list[tuple[AuthorityManifestEntry, str, str, str, list[str]]] = []

    for entry, verification, audit in verified:
        audit_event_id = f"authority:audit:{_short(entry.audit_id)}"
        events.append(LedgerEvent(
            event_id=audit_event_id,
            event_type="REGISTER_AUTHORITY_AUDIT",
            payload=audit.to_dict(),
            sequence=sequence,
            provenance={"kind": "authority_audit", "batch_id": batch_id},
            operator_version="v0.4",
            policy_version=state.policy_version,
        ))
        sequence += 1
        if verification.outcome is not AuditOutcome.VALID:
            continue
        cert, obj = _asset_records(state, entry)
        if obj is None:
            continue
        cert_event_id = f"authority:cert:{_short(cert.certificate_id)}"
        object_event_id = f"authority:object:{_short(obj.object_id)}"
        events.append(LedgerEvent(
            event_id=cert_event_id,
            event_type="REGISTER_CERTIFICATE",
            payload=cert.to_dict(),
            sequence=sequence,
            provenance={"kind": "authority_source_certificate", "audit_id": entry.audit_id},
            operator_version="v0.4",
            policy_version=state.policy_version,
        ))
        sequence += 1
        events.append(LedgerEvent(
            event_id=object_event_id,
            event_type="REGISTER_OBJECT",
            payload=obj.to_dict(),
            sequence=sequence,
            provenance={"kind": "authority_asset", "audit_id": entry.audit_id},
            operator_version="v0.4",
            policy_version=state.policy_version,
        ))
        sequence += 1
        promotion_meta.append((entry, audit_event_id, cert_event_id, object_event_id, obj.certificate_refs))

    effect_state = deepcopy(state)
    for event in events:
        apply_event(effect_state, event)
    effect_hash = state_hash(effect_state)

    for entry, audit_event_id, cert_event_id, object_event_id, cert_refs in promotion_meta:
        kind = "PROOF_ASSET" if entry.verdict == "PROMOTE_AUDIT_ASSET" else "OBSTRUCTION"
        object_id = f"authority:{kind.lower()}:{_short(entry.audit_id)}"
        receipt = PromotionReceipt(
            promotion_id=f"authority:promotion:{_short(entry.audit_id)}",
            review_id=entry.audit_id,
            candidate_id=entry.subject_id,
            native_object_id=object_id,
            promotion_class=kind,
            certificate_refs=list(cert_refs),
            event_ids=[audit_event_id, cert_event_id, object_event_id],
            state_hash_before=input_hash,
            state_hash_after=effect_hash,
        )
        events.append(LedgerEvent(
            event_id=f"authority:receipt:{_short(receipt.promotion_id)}",
            event_type="REGISTER_PROMOTION_RECEIPT",
            payload=receipt.to_dict(),
            sequence=sequence,
            provenance={"kind": "authority_promotion_receipt", "batch_id": batch_id},
            operator_version="v0.4",
            policy_version=state.policy_version,
        ))
        sequence += 1

    events.append(LedgerEvent(
        event_id=checkpoint_id,
        event_type="NOTE",
        payload={
            "kind": "authority_review_checkpoint",
            "batch_id": batch_id,
            "audit_count": len(verified),
            "promotion_count": len(promotion_meta),
            "deferred_count": deferred,
            "effect_state_hash": effect_hash,
        },
        sequence=sequence,
        provenance={"kind": "authority_review_checkpoint"},
        operator_version="v0.4",
        policy_version=state.policy_version,
    ))

    txn = ClosureTransaction(state, ledger)
    for event in events:
        txn.stage(event)
    result = txn.commit()
    return AuthorityBatchResult(
        batch_id=batch_id,
        status=result.commit_status,
        state=result.state,
        input_state_hash=result.input_state_hash,
        output_state_hash=result.output_state_hash,
        event_count=len(events),
        audit_count=len(verified),
        promotion_count=len(promotion_meta),
        deferred_count=deferred,
    )
