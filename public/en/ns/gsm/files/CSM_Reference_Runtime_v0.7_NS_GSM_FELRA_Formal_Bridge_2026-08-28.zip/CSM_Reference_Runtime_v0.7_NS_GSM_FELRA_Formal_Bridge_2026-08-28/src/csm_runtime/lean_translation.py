from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

from .formalization import formalization_bundle_sha256
from .model import TranslationCertificateRecord

PROFILE = "lean-v0.1"
PROTOCOL = "NSGSM-FELRA/0.1"
LEAN_PROJECT_CONTRACT = {"project":"NSGSMBridge","required_imports":["Mathlib"],"toolchain_policy":"external-local-felra-executor"}


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


@dataclass(frozen=True)
class LeanTranslationResult:
    subject_id: str
    case_id: str
    fir_sha256: str
    theorem_name: str
    source: str
    signature: str
    status: str
    variable_map: dict[str, str]
    assumption_map: dict[str, str]
    goal_map: dict[str, str]
    limitations: tuple[str, ...] = ()

    @property
    def obligation_sha256(self) -> str:
        return _sha(self.source)

    @property
    def signature_sha256(self) -> str:
        return _sha(self.signature)

    @property
    def project_digest_sha256(self) -> str:
        payload = {
            "protocol": PROTOCOL,
            "profile": PROFILE,
            "case_id": self.case_id,
            "fir_sha256": self.fir_sha256,
            "signature_sha256": self.signature_sha256,
            "obligation_sha256": self.obligation_sha256,
            "project_contract": LEAN_PROJECT_CONTRACT,
        }
        return hashlib.sha256(_canonical(payload)).hexdigest()

    def with_source(self, source: str) -> "LeanTranslationResult":
        return replace(self, source=source)

    def to_dict(self) -> dict[str, Any]:
        return {
            "subject_id": self.subject_id,
            "case_id": self.case_id,
            "fir_sha256": self.fir_sha256,
            "theorem_name": self.theorem_name,
            "source": self.source,
            "signature": self.signature,
            "status": self.status,
            "variable_map": dict(sorted(self.variable_map.items())),
            "assumption_map": dict(sorted(self.assumption_map.items())),
            "goal_map": dict(sorted(self.goal_map.items())),
            "limitations": sorted(self.limitations),
            "obligation_sha256": self.obligation_sha256,
            "project_contract": LEAN_PROJECT_CONTRACT,
            "signature_sha256": self.signature_sha256,
            "project_digest_sha256": self.project_digest_sha256,
        }


_COMMON = """import Mathlib\n\nnoncomputable section\nnamespace NSGSM\n\nabbrev M3 := Matrix (Fin 3) (Fin 3) ℝ\n\ndef comm (A B : M3) : M3 := A * B - B * A\n\n"""


def _source(case_id: str) -> tuple[str, str, dict[str, str], dict[str, str], dict[str, str], tuple[str, ...]]:
    name = "NSGSM_" + case_id.replace(".", "_").replace("-", "_")
    body_marker = "by\n  exact NSGSM_PROOF_BODY_REQUIRED"
    limitations: tuple[str, ...] = (
        "generated proof body is intentionally incomplete; kernel promotion requires a completed local proof artifact",
    )
    if case_id == "d103.1":
        sig = f"""theorem {name} (S Phi : M3) (beta r : ℝ)\n    (hEigen : S * Phi + Phi * S + (2*r) • S = beta • Phi) :\n    comm (S*S) Phi = beta • comm S Phi :="""
        maps = ({"S":"S","Phi":"Phi","beta":"beta","r":"r"}, {"eigen_lock":"hEigen"}, {"commutator":"comm (S*S) Phi = beta • comm S Phi"})
    elif case_id == "d103.2":
        sig = f"""theorem {name} (si sj beta phi : ℝ)\n    (hComponent : (si^2 - sj^2) * phi = beta * (si - sj) * phi) :\n    (si - sj) * (si + sj - beta) * phi = 0 :="""
        maps = ({"si":"si","sj":"sj","beta":"beta","Phi_ij":"phi"}, {"component_equation":"hComponent"}, {"factorization":"(si-sj)*(si+sj-beta)*phi=0"})
    elif case_id == "d103.3":
        sig = f"""theorem {name} (s2 s3 beta : ℝ)\n    (h12 : beta = -s3) (h13 : beta = -s2) :\n    s2 = s3 :="""
        maps = ({"s2":"s2","s3":"s3","beta":"beta"}, {"shear12":"h12","shear13":"h13"}, {"degeneracy":"s2=s3"})
    elif case_id == "d103.4":
        sig = f"""def FiveRaySpectrumClaim (spec : Finset ℝ) (s1 s2 s3 dS : ℝ) : Prop :=\n  spec = {{-s1, -s2, -s3, dS, -dS}}\n\n-- `hReducedSpectrum` is an explicit bridge assumption tying this FIR obligation\n-- to the reduced five-dimensional L_S representation. A final kernel proof must\n-- discharge/justify this bridge inside the audited Lean project.\ntheorem {name} (spec : Finset ℝ) (s1 s2 s3 dS : ℝ)\n    (hReducedSpectrum : FiveRaySpectrumClaim spec s1 s2 s3 dS) :\n    FiveRaySpectrumClaim spec s1 s2 s3 dS :="""
        maps = ({"s1":"s1","s2":"s2","s3":"s3","dS":"dS","spectrum":"spec"}, {"reduced_spectrum":"hReducedSpectrum"}, {"five_ray_spectrum":"FiveRaySpectrumClaim spec s1 s2 s3 dS"})
        limitations += ("D103.4 scaffold exposes the reduced-spectrum bridge as an explicit assumption that must remain visible in the axiom/assumption audit",)
    elif case_id == "d103.5":
        sig = f"""theorem {name} (beta r dS a b : ℝ)\n    (hDenom : beta^2 ≠ dS^2)\n    (hA : a = 2*beta*r/(beta^2-dS^2))\n    (hB : b = 4*r/(beta^2-dS^2)) :\n    a = 2*beta*r/(beta^2-dS^2) ∧ b = 4*r/(beta^2-dS^2) :="""
        maps = ({"beta":"beta","r":"r","dS":"dS","a":"a","b":"b"}, {"nonresonance":"hDenom","a_solution":"hA","b_solution":"hB"}, {"coaxial_response":"a=... ∧ b=..."})
    else:
        return name, "", {}, {}, {}, ("unsupported FIR case for lean-v0.1",)
    signature = _COMMON + sig
    source = signature + "\n" + body_marker + f"\n\n#print axioms {name}\n\nend NSGSM\n"
    return name, source, maps[0], maps[1], maps[2], limitations


def translate_fir_to_lean(bundle: dict[str, Any], *, subject_id: str) -> LeanTranslationResult:
    case_id = str(bundle.get("case_id") or "")
    name, source, variables, assumptions, goals, limitations = _source(case_id)
    if not source:
        return LeanTranslationResult(subject_id, case_id, formalization_bundle_sha256(bundle), name, "", "", "DEFER", variables, assumptions, goals, limitations)
    signature = source.split("\nby\n  exact NSGSM_PROOF_BODY_REQUIRED", 1)[0]
    return LeanTranslationResult(subject_id, case_id, formalization_bundle_sha256(bundle), name, source, signature, "READY", variables, assumptions, goals, limitations)


def validate_lean_translation(bundle: dict[str, Any], result: LeanTranslationResult) -> TranslationCertificateRecord:
    fir_sha = formalization_bundle_sha256(bundle)
    formalization_id = f"formalization:{fir_sha[:24]}"
    checker_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    status = "VALID" if result.status == "READY" else "DEFER"
    if str(bundle.get("case_id") or "") != result.case_id or str(bundle.get("subject_id") or "") != result.subject_id or fir_sha != result.fir_sha256:
        status = "INVALID"
    # The translation is locked to the FIR goals and case id. A different goal is not the same theorem.
    expected = translate_fir_to_lean(bundle, subject_id=result.subject_id)
    if result.status == "READY" and (expected.signature_sha256 != result.signature_sha256 or expected.theorem_name != result.theorem_name):
        status = "INVALID"
    return TranslationCertificateRecord(
        translation_id=f"translation:{hashlib.sha256(_canonical({'fir':fir_sha,'sig':result.signature_sha256,'profile':PROFILE})).hexdigest()[:24]}",
        subject_id=result.subject_id,
        formalization_id=formalization_id,
        fir_sha256=fir_sha,
        backend="lean",
        backend_profile_version=PROFILE,
        obligation_sha256=result.obligation_sha256,
        project_digest_sha256=result.project_digest_sha256,
        theorem_names=[result.theorem_name] if result.theorem_name else [],
        variable_map=result.variable_map,
        assumption_map=result.assumption_map,
        goal_map=result.goal_map,
        status=status,
        limitations=list(result.limitations),
        translation_checker_version="v0.7",
        translation_checker_sha256=checker_sha,
        evidence_refs=[f"translation-checker:sha256:{checker_sha}"],
    )
