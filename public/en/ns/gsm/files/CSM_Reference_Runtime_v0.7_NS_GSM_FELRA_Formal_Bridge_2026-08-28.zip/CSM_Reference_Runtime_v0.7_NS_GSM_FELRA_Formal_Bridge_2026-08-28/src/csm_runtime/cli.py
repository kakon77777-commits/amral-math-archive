from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import sys

from .canonical import state_hash
from .ledger import LedgerEvent
from .model import native_state_from_dict
from .ns_gsm_adapter import materialize_seed_state
from .query import QueryEngine
from .replay import replay_ledger


def _write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8", newline="\n")


def _write_ledger(path: Path, events: list[LedgerEvent]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for event in events:
            handle.write(json.dumps(event.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")))
            handle.write("\n")


def _read_ledger(path: Path) -> list[LedgerEvent]:
    events: list[LedgerEvent] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                events.append(LedgerEvent.from_dict(json.loads(line)))
    return events


def _read_snapshot(path: Path):
    raw = json.loads(path.read_text(encoding="utf-8"))
    return raw, native_state_from_dict(raw["state"])


def _seed_checks(state) -> dict[str, bool]:
    return {
        "A01_root_formal_open": state.objects["claim:formal-root-regularity"].status.value == "OPEN",
        "A02_c1_open": state.objects["claim:c1-chain-necessity"].status.value == "OPEN",
        "A03_c2_open": state.objects["claim:c2-finite-obstruction"].status.value == "OPEN",
        "A04_d103_does_not_close_root": state.objects["claim:formal-root-regularity"].status.value == "OPEN",
        "A05_d104_coaxial_branch_negative": state.objects["claim:d104-frozen-coaxial-no-go"].status.value == "CLOSED_NEGATIVE",
        "A06_d104_survivor_open": state.objects["survivor:d104-simple-shear"].status.value == "OPEN",
        "A07_scope_revision_recorded": any(x.get("event_type") == "SCOPE_REVISION" for x in state.status_history),
        "A08_d105_global_nonclaim": any(
            "global NS regularity" in obj.metadata.get("forbidden_promotion", "")
            for obj in state.objects.values() if obj.object_type == "NONCLAIM"
        ),
        "A09_d105_frontier_open": state.objects["frontier:d105-first-order"].status.value == "OPEN",
        "A10_source_labels_do_not_close_root": state.objects["claim:formal-root-regularity"].status.value == "OPEN",
        "A11_c6q_obstruction_present": "obstruction:c6q-projected-tail-not-intrinsic-growth-carrier" in state.objects,
        "A12_observed_relative": state.scope == "observed-relative",
    }


def command_seed_run(args) -> int:
    result = materialize_seed_state(Path(args.seed))
    state = result.state
    evidence = Path(args.evidence)
    evidence.mkdir(parents=True, exist_ok=True)

    current_hash = state_hash(state)
    _write_ledger(evidence / "ns_gsm_genesis_ledger.jsonl", result.ledger.events)
    snapshot = {"state_hash": current_hash, "state": state.to_dict()}
    _write_json(evidence / "ns_gsm_native_snapshot.json", snapshot)

    query = QueryEngine(state)
    demo = {
        "root": asdict(query.status("claim:formal-root-regularity")),
        "d104_coaxial": asdict(query.status("claim:d104-frozen-coaxial-no-go")),
        "d105_survivor": asdict(query.status("survivor:d105-vm-shear-pol")),
        "frontier": asdict(query.frontier()),
    }
    _write_json(evidence / "ns_gsm_query_demo.json", demo)

    checks = _seed_checks(state)
    _write_json(evidence / "conformance_report.json", {
        "suite": "NS_GSM seed runtime assertions",
        "passed": sum(checks.values()),
        "total": len(checks),
        "all_passed": all(checks.values()),
        "checks": checks,
    })

    replayed = replay_ledger(result.ledger.events, policy_version=state.policy_version)
    replay_hash = state_hash(replayed)
    replay_report = {
        "expected_hash": current_hash,
        "replayed_hash": replay_hash,
        "match": replay_hash == current_hash,
        "event_count": len(result.ledger.events),
    }
    _write_json(evidence / "replay_report.json", replay_report)
    print(json.dumps({"state_hash": current_hash, "replay_match": replay_report["match"]}, sort_keys=True))
    return 0 if replay_report["match"] and all(checks.values()) else 2


def command_replay_check(args) -> int:
    snapshot = json.loads(Path(args.snapshot).read_text(encoding="utf-8"))
    events = _read_ledger(Path(args.ledger))
    replayed = replay_ledger(events)
    replay_hash = state_hash(replayed)
    result = {
        "expected_hash": snapshot["state_hash"],
        "replayed_hash": replay_hash,
        "match": replay_hash == snapshot["state_hash"],
        "event_count": len(events),
    }
    print(json.dumps(result, sort_keys=True))
    return 0 if result["match"] else 2


def command_status(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).status(args.object_id)), ensure_ascii=False, sort_keys=True))
    return 0


def command_frontier(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).frontier()), ensure_ascii=False, sort_keys=True))
    return 0



def command_state_hash(args) -> int:
    raw, state = _read_snapshot(Path(args.snapshot))
    computed = state_hash(state)
    result = {"stored_hash": raw["state_hash"], "computed_hash": computed}
    print(json.dumps(result, sort_keys=True))
    return 0 if raw["state_hash"] == computed else 2


def command_why_blocked(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).why_blocked(args.object_id)), ensure_ascii=False, sort_keys=True))
    return 0


def command_corpus_summary(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).corpus_summary()), ensure_ascii=False, sort_keys=True))
    return 0


def command_series_summary(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).series_summary(args.series)), ensure_ascii=False, sort_keys=True))
    return 0


def command_candidates(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).candidates(args.series)), ensure_ascii=False, sort_keys=True))
    return 0


def command_source_history(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).source_history(args.source_id)), ensure_ascii=False, sort_keys=True))
    return 0


def command_duplicates(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).duplicates()), ensure_ascii=False, sort_keys=True))
    return 0


def command_ingestion_checkpoint(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).ingestion_checkpoint(args.checkpoint_id)), ensure_ascii=False, sort_keys=True))
    return 0



def command_review_summary(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).review_summary()), ensure_ascii=False, sort_keys=True))
    return 0


def command_pending_review(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).pending_review()), ensure_ascii=False, sort_keys=True))
    return 0


def command_promotion_summary(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).promotion_summary()), ensure_ascii=False, sort_keys=True))
    return 0


def command_review_candidate(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).review(args.candidate_id)), ensure_ascii=False, sort_keys=True))
    return 0


def command_run_structural_review(args) -> int:
    from .review_run import run_v03_review, write_v03_evidence

    run = run_v03_review(
        Path(args.seed),
        Path(args.corpus),
        expansion_root=Path(args.expansion) if args.expansion else None,
    )
    summary = write_v03_evidence(run, Path(args.evidence))
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    return 0 if summary["replay_match"] and summary["conformance_all_passed"] else 2


def command_authority_summary(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).authority_summary()), ensure_ascii=False, sort_keys=True))
    return 0

def command_authority_audit(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).authority_audit(args.audit_id)), ensure_ascii=False, sort_keys=True))
    return 0

def command_proof_assets(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).proof_assets()), ensure_ascii=False, sort_keys=True))
    return 0

def command_obstruction_assets(args) -> int:
    _raw, state = _read_snapshot(Path(args.snapshot))
    print(json.dumps(asdict(QueryEngine(state).obstruction_assets()), ensure_ascii=False, sort_keys=True))
    return 0

def command_run_proof_authority_review(args) -> int:
    from .authority_run import run_v04_authority_review, write_v04_evidence
    run = run_v04_authority_review(Path(args.seed), Path(args.corpus), expansion_root=Path(args.expansion), manifest_path=Path(args.manifest))
    summary = write_v04_evidence(run, Path(args.evidence))
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    return 0 if summary["replay_match"] and summary["conformance_all_passed"] else 2


def command_run_independent_verification(args) -> int:
    from .verification_run import run_v05_independent_verification, write_v05_evidence
    root=Path(args.evidence)
    run=run_v05_independent_verification(Path(args.seed),Path(args.corpus),expansion_root=Path(args.expansion),authority_manifest=Path(args.manifest),evidence_dir=root/'verifiers')
    summary=write_v05_evidence(run,root)
    print(json.dumps(summary,ensure_ascii=False,sort_keys=True))
    return 0 if summary['replay_match'] and summary['conformance_all_passed'] else 2

def command_verification_summary(args) -> int:
    _raw,state=_read_snapshot(Path(args.snapshot)); print(json.dumps(asdict(QueryEngine(state).verification_summary()),ensure_ascii=False,sort_keys=True)); return 0

def command_verification(args) -> int:
    _raw,state=_read_snapshot(Path(args.snapshot)); print(json.dumps(asdict(QueryEngine(state).verification(args.verification_id)),ensure_ascii=False,sort_keys=True)); return 0

def command_verification_deferred(args) -> int:
    _raw,state=_read_snapshot(Path(args.snapshot)); print(json.dumps(asdict(QueryEngine(state).verification_deferred()),ensure_ascii=False,sort_keys=True)); return 0

def command_proof_authority_assets(args) -> int:
    _raw,state=_read_snapshot(Path(args.snapshot)); print(json.dumps(asdict(QueryEngine(state).proof_authority_assets()),ensure_ascii=False,sort_keys=True)); return 0

def command_run_formalization_replication(args) -> int:
    from .formalization_run import run_v06_formalization_replication
    from .v06_evidence import write_v06_evidence
    root = Path(args.root)
    evidence = Path(args.evidence)
    run = run_v06_formalization_replication(root, evidence / "run")
    summary = write_v06_evidence(run, evidence)
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    return 0 if summary["replay_match"] and summary["conformance_all_passed"] else 2




def command_export_felra_bridge(args) -> int:
    from .felra_bridge import export_felra_bridge
    _raw,state=_read_snapshot(Path(args.snapshot))
    result=export_felra_bridge(state,args.subject,Path(args.output))
    print(json.dumps({"bridge_id":result.bridge_id,"bridge_manifest_sha256":result.bridge_manifest_sha256,"translation_status":result.translation.status},ensure_ascii=False,sort_keys=True))
    return 0

def command_import_felra_formal_result(args) -> int:
    from .felra_import import import_felra_formal_result
    bridge_path=Path(args.bridge)
    manifest=json.loads(bridge_path.read_text(encoding="utf-8"))
    translation_path=Path(args.translation) if args.translation else bridge_path.with_name("translation.json")
    translation=json.loads(translation_path.read_text(encoding="utf-8"))
    payload=json.loads(Path(args.felra_result).read_text(encoding="utf-8"))
    cert=json.loads(Path(args.felra_certificate).read_text(encoding="utf-8")) if args.felra_certificate else None
    d=import_felra_formal_result(manifest,translation,payload,certificate=cert)
    print(json.dumps({"decision":d.decision,"proof_eligible":d.proof_eligible,"reasons":d.reasons,"formal_run":d.formal_run.to_dict() if d.formal_run else None,"certificate_integrity_valid":d.certificate_integrity_valid},ensure_ascii=False,sort_keys=True))
    return 0 if d.decision=="VALID" else 2

def command_run_felra_bridge(args) -> int:
    from .felra_bridge_run import run_v07_felra_bridge
    from .v07_evidence import write_v07_evidence
    run=run_v07_felra_bridge(Path(args.root),Path(args.evidence)/"run")
    summary=write_v07_evidence(run,Path(args.evidence))
    print(json.dumps(summary,ensure_ascii=False,sort_keys=True))
    return 0 if summary["replay_match"] and summary["conformance_all_passed"] else 2

def command_v07_translations(args) -> int:
    _raw,state=_read_snapshot(Path(args.snapshot)); print(json.dumps(asdict(QueryEngine(state).translation_certificates()),ensure_ascii=False,sort_keys=True)); return 0

def command_v07_formal_proofs(args) -> int:
    _raw,state=_read_snapshot(Path(args.snapshot)); print(json.dumps(asdict(QueryEngine(state).kernel_formal_proofs()),ensure_ascii=False,sort_keys=True)); return 0

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="csm-runtime")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("seed-run")
    p.add_argument("--seed", required=True)
    p.add_argument("--evidence", required=True)
    p.set_defaults(func=command_seed_run)

    p = sub.add_parser("replay-check")
    p.add_argument("--ledger", required=True)
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_replay_check)

    p = sub.add_parser("status")
    p.add_argument("--snapshot", required=True)
    p.add_argument("object_id")
    p.set_defaults(func=command_status)

    p = sub.add_parser("frontier")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_frontier)

    p = sub.add_parser("state-hash")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_state_hash)

    p = sub.add_parser("why-blocked")
    p.add_argument("--snapshot", required=True)
    p.add_argument("object_id")
    p.set_defaults(func=command_why_blocked)

    p = sub.add_parser("corpus-summary")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_corpus_summary)

    p = sub.add_parser("series-summary")
    p.add_argument("--snapshot", required=True)
    p.add_argument("series")
    p.set_defaults(func=command_series_summary)

    p = sub.add_parser("candidates")
    p.add_argument("--snapshot", required=True)
    p.add_argument("--series")
    p.set_defaults(func=command_candidates)

    p = sub.add_parser("source-history")
    p.add_argument("--snapshot", required=True)
    p.add_argument("source_id")
    p.set_defaults(func=command_source_history)

    p = sub.add_parser("duplicates")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_duplicates)

    p = sub.add_parser("ingestion-checkpoint")
    p.add_argument("--snapshot", required=True)
    p.add_argument("checkpoint_id")
    p.set_defaults(func=command_ingestion_checkpoint)

    p = sub.add_parser("review-summary")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_review_summary)

    p = sub.add_parser("pending-review")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_pending_review)

    p = sub.add_parser("promotion-summary")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_promotion_summary)

    p = sub.add_parser("review-candidate")
    p.add_argument("--snapshot", required=True)
    p.add_argument("candidate_id")
    p.set_defaults(func=command_review_candidate)

    p = sub.add_parser("run-structural-review")
    p.add_argument("--seed", required=True)
    p.add_argument("--corpus", required=True)
    p.add_argument("--expansion")
    p.add_argument("--evidence", required=True)
    p.set_defaults(func=command_run_structural_review)

    p = sub.add_parser("authority-summary")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_authority_summary)

    p = sub.add_parser("authority-audit")
    p.add_argument("--snapshot", required=True)
    p.add_argument("audit_id")
    p.set_defaults(func=command_authority_audit)

    p = sub.add_parser("proof-assets")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_proof_assets)

    p = sub.add_parser("obstruction-assets")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_obstruction_assets)

    p = sub.add_parser("run-proof-authority-review")
    p.add_argument("--seed", required=True)
    p.add_argument("--corpus", required=True)
    p.add_argument("--expansion", required=True)
    p.add_argument("--manifest", required=True)
    p.add_argument("--evidence", required=True)
    p.set_defaults(func=command_run_proof_authority_review)
    p = sub.add_parser("run-independent-verification")
    p.add_argument("--seed", required=True)
    p.add_argument("--corpus", required=True)
    p.add_argument("--expansion", required=True)
    p.add_argument("--manifest", required=True)
    p.add_argument("--evidence", required=True)
    p.set_defaults(func=command_run_independent_verification)

    p = sub.add_parser("verification-summary")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_verification_summary)

    p = sub.add_parser("verification")
    p.add_argument("--snapshot", required=True)
    p.add_argument("verification_id")
    p.set_defaults(func=command_verification)

    p = sub.add_parser("verification-deferred")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_verification_deferred)

    p = sub.add_parser("proof-authority-assets")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_proof_authority_assets)

    p = sub.add_parser("export-felra-bridge")
    p.add_argument("--snapshot", required=True)
    p.add_argument("--subject", required=True)
    p.add_argument("--output", required=True)
    p.set_defaults(func=command_export_felra_bridge)

    p = sub.add_parser("import-felra-formal-result")
    p.add_argument("--bridge", required=True)
    p.add_argument("--translation")
    p.add_argument("--felra-result", required=True)
    p.add_argument("--felra-certificate")
    p.set_defaults(func=command_import_felra_formal_result)

    p = sub.add_parser("run-felra-bridge")
    p.add_argument("--root", required=True)
    p.add_argument("--evidence", required=True)
    p.set_defaults(func=command_run_felra_bridge)

    p = sub.add_parser("felra-translations")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_v07_translations)

    p = sub.add_parser("kernel-formal-proofs")
    p.add_argument("--snapshot", required=True)
    p.set_defaults(func=command_v07_formal_proofs)

    p = sub.add_parser("run-formalization-replication")
    p.add_argument("--root", required=True)
    p.add_argument("--evidence", required=True)
    p.set_defaults(func=command_run_formalization_replication)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
