from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .errors import UnknownObjectError
from .frontier import rebuild_frontier
from .model import NativeState


@dataclass(frozen=True)
class QueryResult:
    answer: Any
    authority: str
    scope: str
    certificate_refs: list[str]
    debt_refs: list[str]
    version: str
    source_layer: str = "native"


class QueryEngine:
    def __init__(self, state: NativeState):
        self.state = state

    def _object(self, object_id: str):
        try:
            return self.state.objects[object_id]
        except KeyError as exc:
            raise UnknownObjectError(object_id) from exc

    def status(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        return QueryResult(
            answer=obj.status.value,
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )

    def why_blocked(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        events = [
            event for event in self.state.status_history
            if event.get("object_id") == object_id
        ]
        return QueryResult(
            answer={"status": obj.status.value, "events": events},
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )

    def frontier(self) -> QueryResult:
        frontier = rebuild_frontier(self.state)
        certs: set[str] = set()
        debts: set[str] = set()
        for object_id in frontier.object_ids:
            obj = self.state.objects[object_id]
            certs.update(obj.certificate_refs)
            debts.update(obj.debt_refs)
        return QueryResult(
            answer=frontier.object_ids,
            authority="AUDIT",
            scope=frontier.scope,
            certificate_refs=sorted(certs),
            debt_refs=sorted(debts),
            version=frontier.version,
        )

    def debt(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        records = [self.state.debts[d].to_dict() for d in obj.debt_refs if d in self.state.debts]
        return QueryResult(
            answer=records,
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )

    def history(self, object_id: str) -> QueryResult:
        obj = self._object(object_id)
        events = [event for event in self.state.status_history if event.get("object_id") == object_id]
        return QueryResult(
            answer=events,
            authority=obj.authority.value,
            scope=self.state.scope,
            certificate_refs=sorted(obj.certificate_refs),
            debt_refs=sorted(obj.debt_refs),
            version=self.state.version,
        )


def _artifact_series(obj) -> str | None:
    value = obj.metadata.get("series")
    return str(value) if value is not None else None


def _candidate_series(candidate) -> str | None:
    proposed = candidate.proposed_object or {}
    meta = proposed.get("metadata") or {}
    value = meta.get("series")
    return str(value) if value is not None else None


def _source_id_from_artifact(obj) -> str | None:
    value = obj.metadata.get("source_id")
    return str(value) if value is not None else None


# Keep corpus queries on QueryEngine without changing the v0.1 object-query surface.
def _corpus_summary(self: QueryEngine) -> QueryResult:
    artifacts = [o for o in self.state.objects.values() if o.object_type == "ARTIFACT"]
    return QueryResult(
        answer={
            "artifact_count": len(artifacts),
            "candidate_count": len(self.state.candidates),
            "checkpoint_count": len(self.state.ingestion_checkpoints),
            "series": sorted({s for s in (_artifact_series(o) for o in artifacts) if s}),
        },
        authority="RESEARCH",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="native+candidate",
    )


def _series_summary(self: QueryEngine, series: str) -> QueryResult:
    artifacts = [o for o in self.state.objects.values() if o.object_type == "ARTIFACT" and _artifact_series(o) == series]
    candidates = [c for c in self.state.candidates.values() if _candidate_series(c) == series]
    by_type: dict[str, int] = {}
    for candidate in candidates:
        by_type[candidate.candidate_type] = by_type.get(candidate.candidate_type, 0) + 1
    return QueryResult(
        answer={
            "series": series,
            "artifact_count": len(artifacts),
            "candidate_count": len(candidates),
            "candidate_types": dict(sorted(by_type.items())),
        },
        authority="RESEARCH",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="native+candidate",
    )


def _candidates(self: QueryEngine, series: str | None = None) -> QueryResult:
    values = list(self.state.candidates.values())
    if series is not None:
        values = [c for c in values if _candidate_series(c) == series]
    return QueryResult(
        answer=[c.to_dict() for c in sorted(values, key=lambda c: c.candidate_id)],
        authority="RESEARCH",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="candidate",
    )


def _source_history(self: QueryEngine, source_id: str) -> QueryResult:
    artifacts = [o.to_dict() for o in self.state.objects.values() if o.object_type == "ARTIFACT" and _source_id_from_artifact(o) == source_id]
    candidates = [c.to_dict() for c in self.state.candidates.values() if (c.proposed_object or {}).get("source_id") == source_id]
    checkpoints = [p for p in self.state.ingestion_checkpoints.values() if source_id in (p.get("source_ids") or [])]
    return QueryResult(
        answer={"source_id": source_id, "artifacts": artifacts, "candidates": candidates, "checkpoints": checkpoints},
        authority="RESEARCH",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="native+candidate",
    )


def _duplicates(self: QueryEngine) -> QueryResult:
    artifacts = [o.to_dict() for o in self.state.objects.values() if o.object_type == "ARTIFACT" and o.metadata.get("canonicality") == "DUPLICATE"]
    return QueryResult(
        answer=artifacts,
        authority="DISPLAY",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="native",
    )


def _ingestion_checkpoint(self: QueryEngine, checkpoint_id: str) -> QueryResult:
    if checkpoint_id not in self.state.ingestion_checkpoints:
        raise UnknownObjectError(checkpoint_id)
    return QueryResult(
        answer=dict(self.state.ingestion_checkpoints[checkpoint_id]),
        authority="AUDIT",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="native",
    )


QueryEngine.corpus_summary = _corpus_summary
QueryEngine.series_summary = _series_summary
QueryEngine.candidates = _candidates
QueryEngine.source_history = _source_history
QueryEngine.duplicates = _duplicates
QueryEngine.ingestion_checkpoint = _ingestion_checkpoint


def _review(self: QueryEngine, candidate_id: str) -> QueryResult:
    records = [
        review.to_dict()
        for review in sorted(self.state.reviews.values(), key=lambda r: r.review_id)
        if review.candidate_id == candidate_id
    ]
    return QueryResult(
        answer=records,
        authority="AUDIT",
        scope=self.state.scope,
        certificate_refs=sorted({c for r in self.state.reviews.values() if r.candidate_id == candidate_id for c in r.certificate_refs}),
        debt_refs=[],
        version=self.state.version,
        source_layer="review",
    )


def _reviews(self: QueryEngine, series: str | None = None, decision: str | None = None) -> QueryResult:
    rows = []
    for review in sorted(self.state.reviews.values(), key=lambda r: r.review_id):
        candidate = self.state.candidates.get(review.candidate_id)
        if candidate is None:
            continue
        if series is not None and _candidate_series(candidate) != series:
            continue
        if decision is not None and review.decision != decision:
            continue
        rows.append(review.to_dict())
    return QueryResult(
        answer=rows,
        authority="AUDIT",
        scope=self.state.scope,
        certificate_refs=sorted({c for row in rows for c in row.get("certificate_refs", [])}),
        debt_refs=[],
        version=self.state.version,
        source_layer="review",
    )


def _review_summary(self: QueryEngine) -> QueryResult:
    by_decision: dict[str, int] = {}
    by_status: dict[str, int] = {}
    by_series: dict[str, int] = {}
    for review in self.state.reviews.values():
        by_decision[review.decision] = by_decision.get(review.decision, 0) + 1
        by_status[review.status] = by_status.get(review.status, 0) + 1
        candidate = self.state.candidates.get(review.candidate_id)
        series = _candidate_series(candidate) if candidate is not None else None
        if series:
            by_series[series] = by_series.get(series, 0) + 1
    return QueryResult(
        answer={
            "review_count": len(self.state.reviews),
            "by_decision": dict(sorted(by_decision.items())),
            "by_status": dict(sorted(by_status.items())),
            "by_series": dict(sorted(by_series.items())),
        },
        authority="AUDIT",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="review",
    )


def _pending_review(self: QueryEngine) -> QueryResult:
    reviews_by_candidate: dict[str, list] = {}
    for review in self.state.reviews.values():
        reviews_by_candidate.setdefault(review.candidate_id, []).append(review)
    pending = []
    for candidate in sorted(self.state.candidates.values(), key=lambda c: c.candidate_id):
        reviews = reviews_by_candidate.get(candidate.candidate_id, [])
        terminal = any(r.status in {"APPROVED", "REJECTED"} for r in reviews)
        if not reviews or not terminal:
            pending.append(candidate.to_dict())
    return QueryResult(
        answer=pending,
        authority="RESEARCH",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="candidate+review",
    )


def _promotion(self: QueryEngine, native_object_id: str) -> QueryResult:
    rows = [
        receipt.to_dict()
        for receipt in sorted(self.state.promotion_receipts.values(), key=lambda p: p.promotion_id)
        if receipt.native_object_id == native_object_id
    ]
    certs = sorted({c for row in rows for c in row.get("certificate_refs", [])})
    debts = sorted({d for row in rows for d in row.get("debt_refs", [])})
    return QueryResult(
        answer=rows,
        authority="AUDIT",
        scope=self.state.scope,
        certificate_refs=certs,
        debt_refs=debts,
        version=self.state.version,
        source_layer="promotion",
    )


def _promotion_summary(self: QueryEngine) -> QueryResult:
    by_class: dict[str, int] = {}
    for receipt in self.state.promotion_receipts.values():
        by_class[receipt.promotion_class] = by_class.get(receipt.promotion_class, 0) + 1
    return QueryResult(
        answer={
            "promotion_count": len(self.state.promotion_receipts),
            "by_class": dict(sorted(by_class.items())),
        },
        authority="AUDIT",
        scope=self.state.scope,
        certificate_refs=[],
        debt_refs=[],
        version=self.state.version,
        source_layer="promotion",
    )


QueryEngine.review = _review
QueryEngine.reviews = _reviews
QueryEngine.review_summary = _review_summary
QueryEngine.pending_review = _pending_review
QueryEngine.promotion = _promotion
QueryEngine.promotion_summary = _promotion_summary


def _authority_audit(self: QueryEngine, audit_id: str) -> QueryResult:
    if audit_id not in self.state.authority_audits:
        raise UnknownObjectError(audit_id)
    audit = self.state.authority_audits[audit_id]
    return QueryResult(
        answer=audit.to_dict(),
        authority="AUDIT",
        scope=self.state.scope,
        certificate_refs=sorted(audit.certificate_refs),
        debt_refs=[],
        version=self.state.version,
        source_layer="authority_audit",
    )


def _authority_assets(self: QueryEngine, object_type: str) -> list:
    return [
        obj for obj in sorted(self.state.objects.values(), key=lambda o: o.object_id)
        if obj.object_type == object_type and obj.version == "v0.4"
    ]


def _proof_assets(self: QueryEngine) -> QueryResult:
    rows = _authority_assets(self, "PROOF_ASSET")
    return QueryResult(
        answer=[o.to_dict() for o in rows], authority="AUDIT", scope=self.state.scope,
        certificate_refs=sorted({c for o in rows for c in o.certificate_refs}), debt_refs=[],
        version=self.state.version, source_layer="native_authority",
    )


def _obstruction_assets(self: QueryEngine) -> QueryResult:
    rows = _authority_assets(self, "OBSTRUCTION")
    return QueryResult(
        answer=[o.to_dict() for o in rows], authority="AUDIT", scope=self.state.scope,
        certificate_refs=sorted({c for o in rows for c in o.certificate_refs}), debt_refs=[],
        version=self.state.version, source_layer="native_authority",
    )


def _deferred_authority(self: QueryEngine) -> QueryResult:
    rows = [a for a in sorted(self.state.authority_audits.values(), key=lambda a: a.audit_id) if a.status == "DEFER"]
    return QueryResult(
        answer=[a.to_dict() for a in rows], authority="AUDIT", scope=self.state.scope,
        certificate_refs=sorted({c for a in rows for c in a.certificate_refs}), debt_refs=[],
        version=self.state.version, source_layer="authority_audit",
    )


def _authority_summary(self: QueryEngine) -> QueryResult:
    proofs = _authority_assets(self, "PROOF_ASSET")
    obstructions = _authority_assets(self, "OBSTRUCTION")
    deferred = [a for a in self.state.authority_audits.values() if a.status == "DEFER"]
    by_verdict: dict[str, int] = {}
    for audit in self.state.authority_audits.values():
        by_verdict[audit.verdict] = by_verdict.get(audit.verdict, 0) + 1
    return QueryResult(
        answer={
            "audit_count": len(self.state.authority_audits),
            "proof_asset_count": len(proofs),
            "obstruction_asset_count": len(obstructions),
            "deferred_count": len(deferred),
            "by_verdict": dict(sorted(by_verdict.items())),
        },
        authority="AUDIT", scope=self.state.scope, certificate_refs=[], debt_refs=[],
        version=self.state.version, source_layer="authority_audit+native",
    )


QueryEngine.authority_audit = _authority_audit
QueryEngine.proof_assets = _proof_assets
QueryEngine.obstruction_assets = _obstruction_assets
QueryEngine.deferred_authority = _deferred_authority
QueryEngine.authority_summary = _authority_summary

# v0.5 independent-verification audit surface.
def _verification(self: QueryEngine, verification_id: str) -> QueryResult:
    if verification_id not in self.state.independent_verifications:
        raise UnknownObjectError(verification_id)
    record=self.state.independent_verifications[verification_id]
    return QueryResult(record.to_dict(), 'AUDIT', self.state.scope, [], [], self.state.version, 'independent_verification')


def _verification_deferred(self: QueryEngine) -> QueryResult:
    from .independent_verification import PROOF_ELIGIBLE_KINDS
    def deferred(v):
        return v.result != "VALID" or bool(v.limitations) or v.verifier_kind not in PROOF_ELIGIBLE_KINDS
    rows=[v.to_dict() for v in sorted(self.state.independent_verifications.values(),key=lambda v:v.verification_id) if deferred(v)]
    return QueryResult(rows,'AUDIT',self.state.scope,[],[],self.state.version,'independent_verification')


def _verification_summary(self: QueryEngine) -> QueryResult:
    rows=list(self.state.independent_verifications.values())
    by_kind={}; by_result={}
    for v in rows:
        by_kind[v.verifier_kind]=by_kind.get(v.verifier_kind,0)+1
        by_result[v.result]=by_result.get(v.result,0)+1
    return QueryResult({
        'verification_count':len(rows),
        'valid_count':sum(v.result=='VALID' for v in rows),
        'upgrade_receipt_count':len(self.state.authority_upgrade_receipts),
        'by_kind':dict(sorted(by_kind.items())),
        'by_result':dict(sorted(by_result.items())),
    },'AUDIT',self.state.scope,[],[],self.state.version,'independent_verification+native')


def _proof_authority_assets(self: QueryEngine) -> QueryResult:
    rows=[o for o in sorted(self.state.objects.values(),key=lambda o:o.object_id) if o.authority.value=='PROOF']
    return QueryResult([o.to_dict() for o in rows],'PROOF',self.state.scope,sorted({c for o in rows for c in o.certificate_refs}),[],self.state.version,'native')

QueryEngine.verification=_verification
QueryEngine.verification_deferred=_verification_deferred
QueryEngine.verification_summary=_verification_summary
QueryEngine.proof_authority_assets=_proof_authority_assets


def _formalizations(self: QueryEngine) -> QueryResult:
    rows = [r.to_dict() for r in sorted(self.state.formalizations.values(), key=lambda x: x.formalization_id)]
    return QueryResult(
        answer=rows, authority="AUDIT", scope=self.state.scope,
        certificate_refs=sorted({c for o in self.state.objects.values() for c in o.certificate_refs if any(r["subject_id"] == o.object_id for r in rows)}),
        debt_refs=[], version=self.state.version, source_layer="formalization",
    )


def _replications(self: QueryEngine) -> QueryResult:
    rows = [r.to_dict() for r in sorted(self.state.replications.values(), key=lambda x: x.replication_id)]
    return QueryResult(
        answer=rows, authority="AUDIT", scope=self.state.scope,
        certificate_refs=[], debt_refs=[], version=self.state.version, source_layer="replication",
    )


def _external_theorem_anchors(self: QueryEngine) -> QueryResult:
    rows = [r.to_dict() for r in sorted(self.state.external_theorem_anchors.values(), key=lambda x: x.anchor_id)]
    return QueryResult(
        answer=rows, authority="AUDIT", scope=self.state.scope,
        certificate_refs=[], debt_refs=[], version=self.state.version, source_layer="external_theorem_anchor",
    )


def _authority_tiers(self: QueryEngine) -> QueryResult:
    rows = []
    for obj in sorted(self.state.objects.values(), key=lambda o: o.object_id):
        tiers = sorted(set((obj.metadata or {}).get("authority_tiers") or []))
        if tiers:
            rows.append({
                "object_id": obj.object_id,
                "object_type": obj.object_type,
                "base_authority": obj.authority.value,
                "status": obj.status.value,
                "tiers": tiers,
                "certificate_refs": sorted(obj.certificate_refs),
            })
    return QueryResult(
        answer=rows, authority="AUDIT", scope=self.state.scope,
        certificate_refs=sorted({c for row in rows for c in row["certificate_refs"]}),
        debt_refs=[], version=self.state.version, source_layer="authority_tier",
    )


def _replicated_assets(self: QueryEngine) -> QueryResult:
    rows = [row for row in _authority_tiers(self).answer if "CROSS_IMPLEMENTATION_REPLICATED" in row["tiers"]]
    return QueryResult(
        answer=rows, authority="AUDIT", scope=self.state.scope,
        certificate_refs=sorted({c for row in rows for c in row["certificate_refs"]}),
        debt_refs=[], version=self.state.version, source_layer="authority_tier",
    )


def _formal_proof_assets(self: QueryEngine) -> QueryResult:
    rows = [row for row in _authority_tiers(self).answer if "FORMAL_PROOF" in row["tiers"]]
    return QueryResult(
        answer=rows, authority="AUDIT", scope=self.state.scope,
        certificate_refs=sorted({c for row in rows for c in row["certificate_refs"]}),
        debt_refs=[], version=self.state.version, source_layer="authority_tier",
    )


QueryEngine.formalizations = _formalizations
QueryEngine.replications = _replications
QueryEngine.external_theorem_anchors = _external_theorem_anchors
QueryEngine.authority_tiers = _authority_tiers
QueryEngine.replicated_assets = _replicated_assets
QueryEngine.formal_proof_assets = _formal_proof_assets


def _translation_certificates(self: QueryEngine) -> QueryResult:
    rows=[x.to_dict() for x in sorted(self.state.translation_certificates.values(),key=lambda x:x.translation_id)]
    return QueryResult(rows,'AUDIT',self.state.scope,[],[],self.state.version,'translation')

def _formal_obligations(self: QueryEngine) -> QueryResult:
    rows=[x.to_dict() for x in sorted(self.state.formal_obligations.values(),key=lambda x:x.obligation_id)]
    return QueryResult(rows,'AUDIT',self.state.scope,[],[],self.state.version,'formal_obligation')

def _felra_formal_runs(self: QueryEngine) -> QueryResult:
    rows=[x.to_dict() for x in sorted(self.state.felra_formal_runs.values(),key=lambda x:x.formal_run_id)]
    return QueryResult(rows,'AUDIT',self.state.scope,[],[],self.state.version,'felra_formal_run')

def _kernel_formal_proofs(self: QueryEngine) -> QueryResult:
    rows=[x.to_dict() for x in sorted(self.state.kernel_formal_proof_receipts.values(),key=lambda x:x.formal_proof_receipt_id)]
    return QueryResult(rows,'PROOF',self.state.scope,sorted({r['certificate_id'] for r in rows}),[],self.state.version,'kernel_formal_proof')

def _formalization_bridges(self: QueryEngine) -> QueryResult:
    by_subject={}
    for t in self.state.translation_certificates.values():
        by_subject.setdefault(t.subject_id,{})['translation_id']=t.translation_id
    for o in self.state.formal_obligations.values():
        by_subject.setdefault(o.subject_id,{})['obligation_id']=o.obligation_id
    for r in self.state.kernel_formal_proof_receipts.values():
        by_subject.setdefault(r.subject_id,{})['formal_proof_receipt_id']=r.formal_proof_receipt_id
    rows=[]
    for subject,data in sorted(by_subject.items()):
        obj=self.state.objects.get(subject)
        rows.append({'subject_id':subject,**data,'tiers':sorted((obj.metadata.get('authority_tiers') or []) if obj else [])})
    return QueryResult(rows,'AUDIT',self.state.scope,[],[],self.state.version,'nsgsm_felra_bridge')

def _formal_proof_deferred(self: QueryEngine) -> QueryResult:
    proven={r.subject_id for r in self.state.kernel_formal_proof_receipts.values()}
    rows=[]
    for t in sorted(self.state.translation_certificates.values(),key=lambda x:x.subject_id):
        if t.subject_id not in proven:
            rows.append({'subject_id':t.subject_id,'translation_id':t.translation_id,'translation_status':t.status,'reason':'no imported verified kernel formal run'})
    return QueryResult(rows,'AUDIT',self.state.scope,[],[],self.state.version,'formal_proof_deferred')

QueryEngine.translation_certificates=_translation_certificates
QueryEngine.formal_obligations=_formal_obligations
QueryEngine.felra_formal_runs=_felra_formal_runs
QueryEngine.kernel_formal_proofs=_kernel_formal_proofs
QueryEngine.formalization_bridges=_formalization_bridges
QueryEngine.formal_proof_deferred=_formal_proof_deferred
