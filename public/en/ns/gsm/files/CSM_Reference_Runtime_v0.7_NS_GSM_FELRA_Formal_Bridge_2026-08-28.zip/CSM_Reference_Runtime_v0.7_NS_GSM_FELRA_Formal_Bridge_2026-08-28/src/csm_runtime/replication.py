from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

from .formalization import formalization_bundle_sha256
from .model import FormalizationRecord, ReplicationRecord


def _canonical_bytes(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def run_replication(bundle: dict, formalization: FormalizationRecord, script_path, evidence_dir) -> ReplicationRecord:
    script_path = Path(script_path).resolve()
    implementation_sha = _sha(script_path.read_bytes())
    bundle_sha = formalization_bundle_sha256(bundle)
    if bundle_sha != formalization.bundle_sha256:
        raise ValueError("formalization bundle hash mismatch")
    evidence_dir = Path(evidence_dir); evidence_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="ns_gsm_replica_v06_") as td:
        td = Path(td)
        bundle_path = td / "bundle.json"
        bundle_path.write_bytes(_canonical_bytes(bundle) + b"\n")
        proc = subprocess.run(
            [sys.executable, "-I", str(script_path), "--case", bundle["case_id"], "--bundle", str(bundle_path)],
            cwd=td, capture_output=True, text=True, timeout=20, check=False,
        )
    if proc.returncode != 0:
        output = {"case_id": bundle["case_id"], "result": "DEFER", "error": proc.stderr.strip(), "normalized_claim": {}}
    else:
        output = json.loads(proc.stdout)
    observed = output.get("normalized_claim") or {}
    matched = output.get("result") == "MATCH" and observed == bundle.get("normalized_claim")
    result = "MATCH" if matched else ("DEFER" if output.get("result") == "DEFER" else "MISMATCH")
    artifact = {
        "case_id": bundle["case_id"],
        "subject_id": bundle["subject_id"],
        "result": result,
        "normalized_claim": observed,
        "checks": output.get("checks") or {},
        "limitations": sorted(set((bundle.get("limitations") or []) + (output.get("limitations") or []))),
        "replicator_implementation_sha256": implementation_sha,
        "input_bundle_sha256": bundle_sha,
    }
    artifact_bytes = _canonical_bytes(artifact)
    output_sha = _sha(artifact_bytes)
    (evidence_dir / f"{output_sha}.json").write_bytes(artifact_bytes + b"\n")
    rid = hashlib.sha256((bundle["subject_id"] + implementation_sha + bundle_sha).encode()).hexdigest()[:24]
    return ReplicationRecord(
        replication_id=f"replication:{rid}",
        subject_id=bundle["subject_id"],
        replicator_id="standalone:ns-gsm-replica-v06",
        replicator_kind="CROSS_IMPLEMENTATION",
        replicator_version="v0.6",
        implementation_sha256=implementation_sha,
        formalization_id=formalization.formalization_id,
        input_bundle_sha256=bundle_sha,
        output_artifact_sha256=output_sha,
        result=result,
        limitations=list(artifact["limitations"]),
        evidence_refs=[f"replication:sha256:{output_sha}"],
        replicated_at_version="v0.6",
    )
