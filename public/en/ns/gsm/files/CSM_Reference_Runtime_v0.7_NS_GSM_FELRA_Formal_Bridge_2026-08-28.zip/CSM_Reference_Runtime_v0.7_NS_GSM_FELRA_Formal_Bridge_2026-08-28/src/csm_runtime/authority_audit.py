from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
from pathlib import Path

from .authority_manifest import AuthorityManifestEntry
from .model import AuthorityAuditRecord, NativeState


class AuditOutcome(str, Enum):
    VALID = "VALID"
    DEFER = "DEFER"
    REFUSE = "REFUSE"


@dataclass(frozen=True)
class AuditVerification:
    outcome: AuditOutcome
    reason: str


_PROMOTION_VERDICTS = {"PROMOTE_AUDIT_ASSET", "PROMOTE_AUDIT_OBSTRUCTION", "NARROW_SCOPE"}
_OPEN_OBLIGATIONS = {"claim:c1-chain-necessity", "claim:c2-finite-obstruction"}


class AuthorityAuditVerifier:
    def __init__(self, source_root: str | Path):
        self.source_root = Path(source_root)

    def verify_entry(self, state: NativeState, entry: AuthorityManifestEntry) -> AuditVerification:
        source = (self.source_root / entry.source_path).resolve()
        root = self.source_root.resolve()
        if root not in source.parents and source != root:
            return AuditVerification(AuditOutcome.REFUSE, "Source path escapes review root.")
        if not source.exists():
            return AuditVerification(AuditOutcome.REFUSE, "Source file is missing.")
        actual = hashlib.sha256(source.read_bytes()).hexdigest()
        if actual != entry.source_sha256:
            return AuditVerification(AuditOutcome.REFUSE, "Source SHA-256 mismatch.")

        if entry.subject_kind == "NATIVE_OBJECT":
            subject = state.objects.get(entry.subject_id)
            source_statement = str((subject.metadata or {}).get("statement") or "") if subject else ""
        elif entry.subject_kind == "CANDIDATE":
            subject = state.candidates.get(entry.subject_id)
            source_statement = str((subject.proposed_object or {}).get("statement") or "") if subject else ""
        else:
            return AuditVerification(AuditOutcome.REFUSE, f"Unknown subject kind: {entry.subject_kind}")
        if subject is None:
            return AuditVerification(AuditOutcome.REFUSE, "Reviewed subject does not exist in native state.")

        if entry.verdict == "DEFER_OPEN_OBLIGATION":
            return AuditVerification(AuditOutcome.DEFER, "Manifest explicitly defers this source-level proof obligation.")

        if entry.subject_id in _OPEN_OBLIGATIONS:
            return AuditVerification(AuditOutcome.DEFER, "C1/C2 remain open proof obligations in v0.4.")

        if entry.verdict in _PROMOTION_VERDICTS and not entry.scope.strip():
            return AuditVerification(AuditOutcome.DEFER, "Theorem/no-go promotion requires explicit reviewed scope.")

        if not entry.canonical_restatement and source_statement and entry.statement.strip() != source_statement.strip():
            return AuditVerification(AuditOutcome.REFUSE, "Reviewed statement does not match the subject statement.")

        text = source.read_text(encoding="utf-8", errors="replace")
        anchor = entry.source_anchor or entry.statement
        if anchor and anchor not in text:
            return AuditVerification(AuditOutcome.REFUSE, "Reviewed source anchor is absent from source artifact.")

        for cert_id in entry.certificate_refs:
            cert = state.certificates.get(cert_id)
            if cert is None:
                return AuditVerification(AuditOutcome.DEFER, f"Certificate not found: {cert_id}")
            if cert.subject_ids and entry.subject_kind == "NATIVE_OBJECT" and entry.subject_id not in cert.subject_ids:
                return AuditVerification(AuditOutcome.REFUSE, f"Certificate does not cover native subject: {cert_id}")

        return AuditVerification(AuditOutcome.VALID, "Source identity, statement, and scope gates passed.")

    def to_record(self, entry: AuthorityManifestEntry, verification: AuditVerification) -> AuthorityAuditRecord:
        status = "APPROVED" if verification.outcome is AuditOutcome.VALID else verification.outcome.value
        return AuthorityAuditRecord(
            audit_id=entry.audit_id,
            subject_id=entry.subject_id,
            subject_kind=entry.subject_kind,
            source_ref=entry.source_path,
            source_sha256=entry.source_sha256,
            statement=entry.statement,
            scope=entry.scope,
            assumptions=list(entry.assumptions),
            certificate_refs=list(entry.certificate_refs),
            nonclaim_refs=list(entry.nonclaim_refs),
            verdict=entry.verdict,
            authority_cap=entry.authority_cap,
            reason=f"{entry.reason} | {verification.reason}",
            reviewer_type="CURATED_V0_4",
            audit_version="v0.4",
            status=status,
        )


def certificate_authority_cap(state: NativeState, certificate_id: str):
    from .enums import Authority
    from .errors import AuthorityError

    cert = state.certificates.get(certificate_id)
    if cert is None:
        raise AuthorityError(f"certificate not found: {certificate_id}")
    independent_valid = any(
        str(result.get("result", "")).upper() == "VALID" and bool(result.get("independent", False))
        for result in cert.verifier_results
    )
    if independent_valid:
        return Authority.PROOF
    return Authority.AUDIT
