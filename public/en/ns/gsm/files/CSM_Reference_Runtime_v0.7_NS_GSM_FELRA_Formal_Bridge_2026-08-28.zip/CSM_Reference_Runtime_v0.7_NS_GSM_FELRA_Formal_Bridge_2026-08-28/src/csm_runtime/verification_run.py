from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path

from .authority_run import V04AuthorityRun, run_v04_authority_review
from .verification_batch import VerificationBatchResult, VerificationTarget, commit_independent_verification_batch
from .verifiers.d103 import verify_d103_1, verify_d103_2, verify_d103_3, verify_d103_4, verify_d103_5
from .verifiers.d105 import verify_d105_1, verify_d105_2, verify_d105_3, verify_d105_4
from .verifiers.rfp import verify_rfp05_32_1, verify_rfp10_42_1, verify_rfp12_12_1, verify_rfp12_19_1
from .verifiers.etnx import verify_etnx_prop8_1

_REGISTRY = {
    ('DCRP','Theorem D103.1 — Eigen-lock commutator equation'): ('sympy:d103.1', verify_d103_1),
    ('DCRP','Theorem D103.2 — Shear resonance condition'): ('sympy:d103.2', verify_d103_2),
    ('DCRP','Theorem D103.3 — Single-shear theorem'): ('sympy:d103.3', verify_d103_3),
    ('DCRP','Theorem D103.4 — Five-Ray Spectrum'): ('sympy:d103.4', verify_d103_4),
    ('DCRP','Theorem D103.5 — Riesz-loaded coaxial response'): ('sympy:d103.5', verify_d103_5),
    ('DCRP','Theorem D105.1 — Simple-shear TR angular scalar'): ('sympy:d105.1', verify_d105_1),
    ('DCRP','Theorem D105.2 — Local Kelvin/TR compatibility witness'): ('exact:d105.2', verify_d105_2),
    ('DCRP','Theorem D105.3 — Exact viscosity residual on the inviscid kernel'): ('sympy:d105.3', verify_d105_3),
    ('DCRP','Theorem D105.4 — Fixed-band viscosity matching'): ('analytic:d105.4', verify_d105_4),
    ('RFP','Theorem 32.1'): ('graph:rfp05.32.1', verify_rfp05_32_1),
    ('RFP','Theorem 42.1'): ('corpus:rfp10.42.1', verify_rfp10_42_1),
    ('RFP','Theorem 12.1'): ('analytic:rfp12.12.1', verify_rfp12_12_1),
    ('RFP','Theorem 19.1'): ('analytic:rfp12.19.1', verify_rfp12_19_1),
}


def build_v05_targets(state):
    targets=[]
    for obj in sorted(state.objects.values(), key=lambda o:o.object_id):
        statement=str((obj.metadata or {}).get('statement') or '')
        series=str((obj.metadata or {}).get('series') or '')
        key=(series,statement)
        if key in _REGISTRY and obj.object_type in {'PROOF_ASSET','OBSTRUCTION'}:
            verifier_id,fn=_REGISTRY[key]
            targets.append(VerificationTarget(obj.object_id,verifier_id,'v0.5',fn))
    targets.append(VerificationTarget('claim:uv-escape-necessity','analytic:etnx.prop8.1','v0.5',verify_etnx_prop8_1))
    return targets

@dataclass
class V05VerificationRun:
    baseline: V04AuthorityRun
    batch: VerificationBatchResult
    state: object
    ledger: object
    targets: list[VerificationTarget]

    def reapply(self, evidence_dir):
        return commit_independent_verification_batch(self.state,self.ledger,self.targets,evidence_dir=evidence_dir,batch_id='v0.5-independent-verification')


def run_v05_independent_verification(seed_path, corpus_root, *, expansion_root, authority_manifest, evidence_dir):
    baseline=run_v04_authority_review(seed_path,corpus_root,expansion_root=expansion_root,manifest_path=authority_manifest)
    targets=build_v05_targets(baseline.state)
    batch=commit_independent_verification_batch(baseline.state,baseline.ledger,targets,evidence_dir=evidence_dir,batch_id='v0.5-independent-verification')
    return V05VerificationRun(baseline,batch,batch.state,baseline.ledger,targets)


def write_v05_evidence(run: V05VerificationRun, evidence_dir) -> dict:
    import json
    from .canonical import state_hash
    from .replay import replay_ledger
    root=Path(evidence_dir); root.mkdir(parents=True,exist_ok=True)
    def write(name,value):
        (root/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,sort_keys=True),encoding='utf-8',newline='\n')
    verifications=[v.to_dict() for v in sorted(run.state.independent_verifications.values(),key=lambda v:v.verification_id)]
    upgrades=[u.to_dict() for u in sorted(run.state.authority_upgrade_receipts.values(),key=lambda u:u.upgrade_id)]
    upgraded_ids={u['subject_id'] for u in upgrades}
    verified_assets=[run.state.objects[i].to_dict() for i in sorted(upgraded_ids)]
    deferred=[v for v in verifications if v['subject_id'] not in upgraded_ids]
    verifier_manifest=[{
        'verification_id':v['verification_id'],'subject_id':v['subject_id'],'verifier_id':v['verifier_id'],
        'verifier_kind':v['verifier_kind'],'verifier_version':v['verifier_version'],'result':v['result'],
        'proof_artifact_sha256':v['proof_artifact_sha256'],'limitations':v['limitations'],
    } for v in verifications]
    write('independent_verifications_v05.json',{'count':len(verifications),'verifications':verifications})
    write('authority_upgrades_v05.json',{'count':len(upgrades),'upgrades':upgrades})
    write('verified_assets_v05.json',{'count':len(verified_assets),'assets':verified_assets})
    write('partial_or_deferred_v05.json',{'count':len(deferred),'verifications':deferred})
    write('verifier_manifest_v05.json',{'count':len(verifier_manifest),'verifiers':verifier_manifest})
    current_hash=state_hash(run.state)
    with (root/'ns_gsm_v05_ledger.jsonl').open('w',encoding='utf-8',newline='\n') as h:
        for e in run.ledger.events:
            h.write(json.dumps(e.to_dict(),ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
    write('native_snapshot_v05.json',{'state_hash':current_hash,'state':run.state.to_dict()})
    replayed=replay_ledger(run.ledger.events,policy_version=run.state.policy_version); replay_hash=state_hash(replayed)
    replay={'expected_hash':current_hash,'replayed_hash':replay_hash,'match':replay_hash==current_hash,'event_count':len(run.ledger.events)}
    write('replay_report_v05.json',replay)
    again=run.reapply(root/'verifiers')
    proof_v04=[o for o in run.state.objects.values() if o.version=='v0.4' and o.object_type=='PROOF_ASSET']
    rfp10=[o for o in proof_v04 if o.metadata.get('statement')=='Theorem 42.1'][0]
    obstruction=[o for o in run.state.objects.values() if o.version=='v0.4' and o.object_type=='OBSTRUCTION' and o.metadata.get('statement')=='Theorem 19.1'][0]
    checks={
        'root_open':run.state.objects['claim:formal-root-regularity'].status.value=='OPEN',
        'c1_open':run.state.objects['claim:c1-chain-necessity'].status.value=='OPEN',
        'c2_open':run.state.objects['claim:c2-finite-obstruction'].status.value=='OPEN',
        'verification_count_14':len(verifications)==14,
        'authority_upgrades_12':len(upgrades)==12,
        'v04_proof_assets_upgraded_11':sum(o.authority.value=='PROOF' for o in proof_v04)==11,
        'rfp10_corpus_audit_not_upgraded':rfp10.authority.value=='AUDIT',
        'rfp19_obstruction_proof_authority':obstruction.authority.value=='PROOF' and obstruction.status.value=='OPEN',
        'etnx_external_dependency_not_upgraded':run.state.objects['claim:uv-escape-necessity'].authority.value=='AUDIT',
        'replay_exact':replay['match'],
        'verification_batch_idempotent':again.status=='IDEMPOTENT_NOOP',
    }
    conf={'suite':'NS_GSM v0.5 independent verification','passed':sum(checks.values()),'total':len(checks),'all_passed':all(checks.values()),'checks':checks}
    write('conformance_report_v05.json',conf)
    summary={
        'version':'v0.5','runtime_version':'0.5.0','root_status':'OPEN','scope':run.state.scope,
        'state_hash':current_hash,'replay_match':replay['match'],'ledger_event_count':len(run.ledger.events),
        'verification_count':len(verifications),'authority_upgrade_count':len(upgrades),
        'proof_authority_asset_count':sum(o.authority.value=='PROOF' for o in run.state.objects.values()),
        'deferred_verification_count':len(deferred),'conformance_all_passed':conf['all_passed'],
    }
    write('run_summary_v05.json',summary)
    return summary
