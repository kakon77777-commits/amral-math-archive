from __future__ import annotations
import sympy as sp
from csm_runtime.independent_verification import VerificationResult


def _valid(artifact):
    artifact = dict(artifact)
    artifact["verified"] = bool(artifact.get("verified", True))
    return VerificationResult("VALID" if artifact["verified"] else "FAILED", "SYMBOLIC_EXACT", artifact, [])


def _generic_tracefree_symmetric(prefix: str):
    a,b,c,d,e = sp.symbols(f"{prefix}11 {prefix}22 {prefix}12 {prefix}13 {prefix}23")
    return sp.Matrix([[a,c,d],[c,b,e],[d,e,-a-b]])


def verify_d103_1():
    S = _generic_tracefree_symmetric("s")
    P = _generic_tracefree_symmetric("p")
    I = sp.eye(3)
    inner = sp.trace(S*P)
    L = S*P + P*S - sp.Rational(2,3)*inner*I
    lhs = sp.simplify(S*L - L*S)
    rhs = sp.simplify(S**2*P - P*S**2)
    zero = sp.simplify(lhs-rhs)
    verified = all(sp.simplify(x)==0 for x in zero)
    return _valid({"theorem":"D103.1","identity":"[S,L_S(Phi)]=[S^2,Phi]","verified":verified,"zero_entries":[str(sp.simplify(x)) for x in zero]})


def verify_d103_2():
    s1,s2,beta,p12,p13,p23 = sp.symbols("s1 s2 beta p12 p13 p23")
    s3 = -s1-s2
    S = sp.diag(s1,s2,s3)
    P = sp.Matrix([[0,p12,p13],[p12,0,p23],[p13,p23,0]])
    R = sp.expand((S**2-beta*S)*P - P*(S**2-beta*S))
    targets = {
        (0,1): (s1-s2)*(s1+s2-beta)*p12,
        (0,2): (s1-s3)*(s1+s3-beta)*p13,
        (1,2): (s2-s3)*(s2+s3-beta)*p23,
    }
    checks = {f"{i}{j}": sp.simplify(R[i,j]-expr)==0 for (i,j),expr in targets.items()}
    return _valid({"theorem":"D103.2","checks":checks,"verified":all(checks.values()),"tracefree_substitution":"s3=-s1-s2"})


def verify_d103_3():
    s1,s2,s3,beta = sp.symbols("s1 s2 s3 beta")
    # Any two active shear pairs sharing one index force equality of the complementary eigenvalues.
    pair_checks = {
        "12_and_13": sp.simplify((s1+s2)-(s1+s3) - (s2-s3)) == 0,
        "12_and_23": sp.simplify((s1+s2)-(s2+s3) - (s1-s3)) == 0,
        "13_and_23": sp.simplify((s1+s3)-(s2+s3) - (s1-s2)) == 0,
    }
    sol = sp.solve([sp.Eq(beta,s1+s2), sp.Eq(beta,s1+s3), sp.Eq(beta,s2+s3), sp.Eq(s1+s2+s3,0)], [s1,s2,s3,beta], dict=True)
    all_three_zero = bool(sol) and all(sp.simplify(sol[0].get(v, v))==0 for v in (s1,s2,s3,beta))
    return _valid({"theorem":"D103.3","pair_difference_checks":pair_checks,"all_three_active_tracefree_solution":{str(k):str(v) for k,v in (sol[0] if sol else {}).items()},"verified":all(pair_checks.values()) and all_three_zero})


def verify_d103_4():
    s1,s2,lam = sp.symbols("s1 s2 lambda")
    s3 = -s1-s2
    S = sp.diag(s1,s2,s3)
    # diagonal trace-free tensor diag(a,b,-a-b)
    a,b = sp.symbols("a b")
    P = sp.diag(a,b,-a-b)
    inner = sp.trace(S*P)
    L = sp.simplify(S*P+P*S-sp.Rational(2,3)*inner*sp.eye(3))
    # coefficients are first two diagonal entries
    M = sp.Matrix([[sp.diff(L[0,0],a), sp.diff(L[0,0],b)], [sp.diff(L[1,1],a), sp.diff(L[1,1],b)]])
    char = sp.factor(M.charpoly(lam).as_expr())
    norm2 = sp.expand(s1**2+s2**2+s3**2)
    target = sp.factor(lam**2-sp.Rational(2,3)*norm2)
    diag_match = sp.simplify(char-target)==0
    return _valid({"theorem":"D103.4","off_diagonal_eigenvalues":["-s3","-s2","-s1"],"diagonal_matrix":str(M),"diagonal_charpoly":str(char),"target_charpoly":str(target),"diagonal_charpoly_match":bool(diag_match),"verified":bool(diag_match)})


def verify_d103_5():
    beta,r,norm2 = sp.symbols("beta r norm2", nonzero=True)
    d2 = sp.Rational(2,3)*norm2
    denom = beta**2-d2
    a = 2*beta*r/denom
    b = 4*r/denom
    eq1 = sp.simplify(norm2*b/3 + 2*r - beta*a)
    eq2 = sp.simplify(2*a-beta*b)
    verified = eq1==0 and eq2==0
    return _valid({"theorem":"D103.5","solution":{"a":str(a),"b":str(b)},"residuals":[str(eq1),str(eq2)],"assumption":"beta^2 != (2/3)|S|^2","verified":verified})
