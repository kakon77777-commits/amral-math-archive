from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .formalization import build_formalization_bundle, formalization_bundle_sha256
from .lean_translation import LEAN_PROJECT_CONTRACT, PROTOCOL, translate_fir_to_lean, validate_lean_translation
from .model import FormalObligationRecord, NativeState, TranslationCertificateRecord


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _sha(value: Any) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


@dataclass
class BridgeExportResult:
    subject_id: str
    bridge_id: str
    output_dir: Path
    bridge_manifest: dict[str, Any]
    bridge_manifest_sha256: str
    translation: TranslationCertificateRecord
    obligation_record: FormalObligationRecord


AXIOM_ALLOWLIST = ["propext", "Classical.choice", "Quot.sound"]


def export_felra_bridge(
    state: NativeState,
    subject_id: str,
    output_dir: str | Path,
    *,
    backend: str = "lean",
) -> BridgeExportResult:
    if backend != "lean":
        raise ValueError(f"known backend for NSGSM-FELRA/0.1 Plan A is 'lean'; got {backend!r}")
    if subject_id not in state.objects:
        raise KeyError(subject_id)

    output = Path(output_dir)
    bundle = build_formalization_bundle(state, subject_id)
    fir_sha = formalization_bundle_sha256(bundle)
    result = translate_fir_to_lean(bundle, subject_id=subject_id)
    translation = validate_lean_translation(bundle, result)
    if translation.status != "VALID":
        raise ValueError(f"translation is not exportable: {translation.status}")

    bridge_id = "bridge:" + _sha({"subject": subject_id, "fir": fir_sha, "translation": translation.translation_id})[:24]
    manifest = {
        "protocol": PROTOCOL,
        "bridge_id": bridge_id,
        "subject_id": subject_id,
        "formalization_id": translation.formalization_id,
        "fir_sha256": fir_sha,
        "translation_id": translation.translation_id,
        "translation_sha256": _sha(translation.to_dict()),
        "backend": "lean",
        "obligation_relpath": "lean/obligation.lean",
        "obligation_sha256": result.obligation_sha256,
        "project_digest_sha256": result.project_digest_sha256,
        "theorem_names": [result.theorem_name],
        "expected_formal_status": "verified",
        "axiom_policy": {"mode": "allowlist", "allowed": AXIOM_ALLOWLIST},
        "assumptions": list(bundle.get("assumptions") or []),
        "limitations": sorted(set(list(bundle.get("limitations") or []) + list(result.limitations))),
        "derives_from": [
            f"ns_gsm_subject:{subject_id}",
            f"ns_gsm_fir:{translation.formalization_id}",
            f"ns_gsm_translation:{translation.translation_id}",
        ],
        "project_contract": LEAN_PROJECT_CONTRACT,
    }
    manifest_sha = _sha(manifest)
    obligation_record = FormalObligationRecord(
        obligation_id="obligation:" + result.obligation_sha256[:24],
        subject_id=subject_id,
        formalization_id=translation.formalization_id,
        translation_id=translation.translation_id,
        backend="lean",
        obligation_sha256=result.obligation_sha256,
        project_digest_sha256=result.project_digest_sha256,
        theorem_names=[result.theorem_name],
        axiom_policy={"mode": "allowlist", "allowed": AXIOM_ALLOWLIST},
        assumptions=list(bundle.get("assumptions") or []),
        limitations=list(manifest["limitations"]),
        bridge_manifest_sha256=manifest_sha,
        status="READY",
        evidence_refs=[f"obligation:sha256:{result.obligation_sha256}", f"bridge-manifest:sha256:{manifest_sha}"],
    )

    (output / "felra").mkdir(parents=True, exist_ok=True)
    (output / "lean/project").mkdir(parents=True, exist_ok=True)
    (output / "evidence").mkdir(parents=True, exist_ok=True)
    (output / "ns_gsm_bridge_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (output / "fir.json").write_text(json.dumps(bundle, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (output / "translation.json").write_text(json.dumps(translation.to_dict(), ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (output / "lean/obligation.lean").write_text(result.source, encoding="utf-8")
    (output / "lean/project/PROJECT_CONTRACT.json").write_text(json.dumps(LEAN_PROJECT_CONTRACT, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    project = {
        "project": {"id": "ns-gsm-felra-" + bridge_id.split(":", 1)[1], "title": "NS_GSM formal proof bridge", "language": "en"},
        "claims": [{"id": subject_id, "statement": str(state.objects[subject_id].metadata.get("statement") or subject_id), "status": "hypothesis", "required_checks": []}],
        "analyses": [{
            "id": "formal_" + bridge_id.split(":", 1)[1],
            "type": "formal_check",
            "title": "NS_GSM Lean kernel check",
            "claim_id": subject_id,
            "backend": "lean",
            "obligation": "../lean/obligation.lean",
            "project_dir": "../lean/project",
            "expect": "verified",
            "derives_from": manifest["derives_from"],
            "assumptions": manifest["assumptions"],
            "limitations": manifest["limitations"],
            "axioms_within": AXIOM_ALLOWLIST,
        }],
    }
    (output / "felra/project.yaml").write_text(yaml.safe_dump(project, allow_unicode=True, sort_keys=False), encoding="utf-8")

    return BridgeExportResult(subject_id, bridge_id, output, manifest, manifest_sha, translation, obligation_record)
