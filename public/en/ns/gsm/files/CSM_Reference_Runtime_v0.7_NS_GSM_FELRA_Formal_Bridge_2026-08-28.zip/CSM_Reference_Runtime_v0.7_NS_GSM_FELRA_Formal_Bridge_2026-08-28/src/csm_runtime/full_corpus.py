from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .corpus_checkpoint import IngestionCheckpoint, commit_corpus_batch
from .corpus_manifest import CorpusManifest, manifest_from_directory
from .ledger import EventLedger
from .model import NativeState
from .ns_gsm_adapter import materialize_seed_state


SERIES_ORDER = ("C", "RFP", "MORP", "X72", "DCRP", "FCBP", "PAM")


@dataclass(frozen=True)
class CorpusCoverage:
    series: str
    content_status: str
    source_count: int
    note: str

    def to_dict(self) -> dict:
        return {
            "series": self.series,
            "content_status": self.content_status,
            "source_count": self.source_count,
            "note": self.note,
        }


@dataclass(frozen=True)
class FullCorpusRun:
    state: NativeState
    ledger: EventLedger
    checkpoints: tuple[IngestionCheckpoint, ...]
    manifests: tuple[CorpusManifest, ...]
    coverage: tuple[CorpusCoverage, ...]


_COVERAGE_STATUS = {
    "C": ("PARTIAL", "C-series discovery/content ingestion is partial in v0.2; do not infer full C3-C6 coverage."),
    "RFP": ("COMPLETE_SERIES", "RFP Cycle I 01-12 plus canonical roadmap/handoff/recompilation are content-ingested."),
    "MORP": ("COMPLETE_SERIES", "MORP 01-05 plus Cycle VII roadmap/handoff are content-ingested."),
    "X72": ("SELECTED_MILESTONES", "Selected non-cumulative/milestone X72 sources are content-ingested; cumulative history is not claimed complete."),
    "DCRP": ("SELECTED_MILESTONES", "Selected DCRP milestone chain is content-ingested; DCRP 1-105 is not claimed complete."),
    "FCBP": ("COMPLETE_SERIES", "FCBP 01-06 plus Cycle VI roadmap are content-ingested."),
    "PAM": ("COMPLETE_INDEX_ARTIFACT", "The canonical Proof Asset Map index artifact is content-ingested."),
}


def _coverage(series: str, manifest: CorpusManifest) -> CorpusCoverage:
    status, note = _COVERAGE_STATUS[series]
    return CorpusCoverage(series, status, len(manifest.sources), note)


def ingest_corpus_tree_into(state: NativeState, ledger: EventLedger, corpus_root: str | Path) -> FullCorpusRun:
    root = Path(corpus_root)
    current = state
    checkpoints: list[IngestionCheckpoint] = []
    manifests: list[CorpusManifest] = []
    coverage: list[CorpusCoverage] = []

    for series in SERIES_ORDER:
        series_root = root / series
        if not series_root.exists():
            continue
        manifest = manifest_from_directory(series_root, source_namespace=f"ns-gsm-v0.2-{series.lower()}", series_override=series)
        if not manifest.sources:
            continue
        source_texts = {
            source.source_id: Path(source.materialized_path).read_text(encoding="utf-8")
            for source in manifest.sources
        }
        checkpoint = commit_corpus_batch(current, ledger, manifest, source_texts)
        current = checkpoint.state
        checkpoints.append(checkpoint)
        manifests.append(manifest)
        coverage.append(_coverage(series, manifest))

    return FullCorpusRun(
        state=current,
        ledger=ledger,
        checkpoints=tuple(checkpoints),
        manifests=tuple(manifests),
        coverage=tuple(coverage),
    )


def ingest_corpus_tree(seed_path: str | Path, corpus_root: str | Path) -> FullCorpusRun:
    seed = materialize_seed_state(seed_path)
    return ingest_corpus_tree_into(seed.state, seed.ledger, corpus_root)


def write_corpus_evidence(result: FullCorpusRun, evidence_dir: str | Path) -> dict:
    import json
    from dataclasses import asdict

    from .canonical import state_hash
    from .cross_series_audit import exact_statement_proposals
    from .query import QueryEngine
    from .replay import replay_ledger

    root = Path(evidence_dir)
    root.mkdir(parents=True, exist_ok=True)

    def write_json(name: str, value) -> None:
        (root / name).write_text(
            json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
            newline="\n",
        )

    inventory = {
        "scope": result.state.scope,
        "manifests": [manifest.to_dict() for manifest in result.manifests],
        "content_artifact_count": sum(len(manifest.sources) for manifest in result.manifests),
    }
    write_json("corpus_inventory.json", inventory)
    write_json("content_coverage.json", [entry.to_dict() for entry in result.coverage])

    engine = QueryEngine(result.state)
    series_codes = [entry.series for entry in result.coverage]
    candidate_summary = {
        "total": len(result.state.candidates),
        "series": {series: engine.series_summary(series).answer for series in series_codes},
        "source_layer": "candidate",
        "theorem_authority": "NONE_BY_DEFAULT",
    }
    write_json("candidate_summary.json", candidate_summary)
    write_json("series_checkpoints.json", [
        {
            "checkpoint_id": cp.checkpoint_id,
            "status": cp.status,
            "input_state_hash": cp.input_state_hash,
            "output_state_hash": cp.output_state_hash,
            "event_count": cp.event_count,
            "source_ids": list(cp.source_ids),
        }
        for cp in result.checkpoints
    ])

    proposals = exact_statement_proposals(result.state)
    proposal_records = []
    for proposal in proposals:
        row = asdict(proposal)
        row["validation_class"] = proposal.validation_class.value
        proposal_records.append(row)
    write_json("cross_series_proposals.json", {
        "proposal_count": len(proposal_records),
        "auto_quotient_count": sum(1 for row in proposal_records if row["auto_quotient"]),
        "proposals": proposal_records,
    })

    with (root / "ns_gsm_v02_ledger.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
        for event in result.ledger.events:
            handle.write(json.dumps(event.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")))
            handle.write("\n")

    current_hash = state_hash(result.state)
    write_json("ns_gsm_v02_native_snapshot.json", {"state_hash": current_hash, "state": result.state.to_dict()})
    replayed = replay_ledger(result.ledger.events, policy_version=result.state.policy_version)
    replay_hash = state_hash(replayed)
    replay_report = {
        "expected_hash": current_hash,
        "replayed_hash": replay_hash,
        "match": replay_hash == current_hash,
        "event_count": len(result.ledger.events),
    }
    write_json("replay_report.json", replay_report)

    root_status = result.state.objects["claim:formal-root-regularity"].status.value
    report = {
        "version": "v0.2",
        "scope": result.state.scope,
        "root_status": root_status,
        "state_hash": current_hash,
        "replay_match": replay_report["match"],
        "ledger_event_count": len(result.ledger.events),
        "content_artifact_count": inventory["content_artifact_count"],
        "candidate_count": len(result.state.candidates),
        "checkpoint_count": len(result.checkpoints),
        "cross_series_proposal_count": len(proposal_records),
        "cross_series_auto_quotient_count": sum(1 for row in proposal_records if row["auto_quotient"]),
        "coverage": [entry.to_dict() for entry in result.coverage],
    }
    write_json("run_summary.json", report)
    return report
