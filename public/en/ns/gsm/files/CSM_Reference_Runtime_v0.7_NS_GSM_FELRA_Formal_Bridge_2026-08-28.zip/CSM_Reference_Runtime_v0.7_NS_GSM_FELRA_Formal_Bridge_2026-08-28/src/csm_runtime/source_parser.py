from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import re
from typing import Any

import yaml


@dataclass(frozen=True)
class ParsedCandidate:
    candidate_id: str
    candidate_type: str
    source_id: str
    statement: str
    line_start: int
    line_end: int
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "candidate_type": self.candidate_type,
            "source_id": self.source_id,
            "statement": self.statement,
            "line_start": self.line_start,
            "line_end": self.line_end,
            "metadata": self.metadata,
        }


@dataclass
class ParsedSource:
    source_id: str
    series: str
    metadata: dict[str, Any] = field(default_factory=dict)
    headings: list[dict[str, Any]] = field(default_factory=list)
    theorem_candidates: list[ParsedCandidate] = field(default_factory=list)
    status_candidates: list[ParsedCandidate] = field(default_factory=list)
    obstruction_candidates: list[ParsedCandidate] = field(default_factory=list)
    survivor_candidates: list[ParsedCandidate] = field(default_factory=list)
    frontier_candidates: list[ParsedCandidate] = field(default_factory=list)
    nonclaim_candidates: list[ParsedCandidate] = field(default_factory=list)
    dependency_candidates: list[ParsedCandidate] = field(default_factory=list)
    next_candidates: list[ParsedCandidate] = field(default_factory=list)

    def all_candidates(self) -> list[ParsedCandidate]:
        groups = [
            self.theorem_candidates,
            self.status_candidates,
            self.obstruction_candidates,
            self.survivor_candidates,
            self.frontier_candidates,
            self.nonclaim_candidates,
            self.dependency_candidates,
            self.next_candidates,
        ]
        result: list[ParsedCandidate] = []
        for group in groups:
            result.extend(group)
        return sorted(result, key=lambda c: (c.line_start, c.candidate_type, c.candidate_id))


_HEADING = re.compile(r"^(#{1,6})\s+(.*\S)\s*$")
_STOP = re.compile(r"\b(STOP-[A-Z]+\d+)\b", re.IGNORECASE)
_THEOREM_WORD = re.compile(r"\b(Theorem|Proposition|Conjecture|Lemma|Corollary)\b|定理|命題|猜想|引理", re.IGNORECASE)
_NONCLAIM_HEADING = re.compile(r"what .*does not prove|what is not proved|non[- ]?claims?|不主張|非主張", re.IGNORECASE)
_DEP_HEADING = re.compile(r"internal dependencies|primary internal dependencies|內部依賴", re.IGNORECASE)
_NEXT_HEADING = re.compile(r"next autonomous step|^next\b|下一步|下一輪", re.IGNORECASE)
_STATUS_WORD = re.compile(r"\b(CLOSED|OPEN|CONDITIONAL|PARTIAL|PROVED|NOT PROVED)\b", re.IGNORECASE)
_NO_GO = re.compile(r"NO[- ]?GO", re.IGNORECASE)
_SURVIVOR = re.compile(r"SURVIVOR", re.IGNORECASE)


def _norm(text: str) -> str:
    return " ".join(text.strip().split())


def _candidate(source_id: str, candidate_type: str, statement: str, line_start: int, line_end: int | None = None, **metadata: Any) -> ParsedCandidate:
    normalized = _norm(statement)
    digest = hashlib.sha256(f"{source_id}|{candidate_type}|{line_start}|{normalized}".encode("utf-8")).hexdigest()[:20]
    return ParsedCandidate(
        candidate_id=f"candidate:{digest}",
        candidate_type=candidate_type,
        source_id=source_id,
        statement=normalized,
        line_start=line_start,
        line_end=line_end or line_start,
        metadata=metadata,
    )


def _front_matter(lines: list[str]) -> tuple[dict[str, Any], int]:
    if not lines or lines[0].strip() != "---":
        return {}, 0
    for idx in range(1, min(len(lines), 200)):
        if lines[idx].strip() == "---":
            raw = "\n".join(lines[1:idx])
            try:
                data = yaml.safe_load(raw) or {}
            except yaml.YAMLError:
                data = {}
            if not isinstance(data, dict):
                data = {}
            return data, idx + 1
    return {}, 0


def parse_markdown_source(text: str, source_id: str, series: str) -> ParsedSource:
    lines = text.splitlines()
    metadata, body_start = _front_matter(lines)
    parsed = ParsedSource(source_id=source_id, series=series, metadata=dict(metadata))

    status = metadata.get("status")
    if status:
        parsed.status_candidates.append(_candidate(source_id, "StatusCandidate", str(status), 1, source_field="status", series=series))
    epistemic = metadata.get("epistemic_status")
    if epistemic:
        epi = str(epistemic)
        if re.search(r"\bNo\b.*\b(proved|proof)\b|NOT PROVED|not proved|不主張", epi, re.IGNORECASE):
            parsed.nonclaim_candidates.append(_candidate(source_id, "NonclaimCandidate", epi, 1, source_field="epistemic_status", series=series))

    section_mode: str | None = None
    section_level = 99

    for i, raw in enumerate(lines, start=1):
        line = raw.strip()
        if not line:
            continue

        heading_match = _HEADING.match(raw)
        if heading_match:
            level = len(heading_match.group(1))
            title = _norm(heading_match.group(2))
            parsed.headings.append({"level": level, "title": title, "line": i})

            # Exit a captured section when a sibling/parent heading begins.
            if section_mode and level <= section_level:
                section_mode = None
                section_level = 99

            if _NONCLAIM_HEADING.search(title):
                section_mode = "nonclaim"
                section_level = level
            elif _DEP_HEADING.search(title):
                section_mode = "dependency"
                section_level = level
            elif _NEXT_HEADING.search(title):
                section_mode = "next"
                section_level = level

            if _THEOREM_WORD.search(title):
                parsed.theorem_candidates.append(_candidate(source_id, "TheoremCandidate", title, i, heading_level=level, series=series))
            if _STATUS_WORD.search(title):
                parsed.status_candidates.append(_candidate(source_id, "StatusCandidate", title, i, heading_level=level, series=series))
            for stop in _STOP.findall(title):
                parsed.frontier_candidates.append(_candidate(source_id, "FrontierCandidate", title, i, stop_id=stop.upper(), series=series))
            if _NO_GO.search(title):
                parsed.obstruction_candidates.append(_candidate(source_id, "ObstructionCandidate", title, i, series=series))
            if _SURVIVOR.search(title):
                parsed.survivor_candidates.append(_candidate(source_id, "SurvivorCandidate", title, i, series=series))
            continue

        # Section body candidates.
        if section_mode == "nonclaim" and (line.startswith("-") or re.search(r"not prove|NOT PROVED|not proved|不主張", line, re.IGNORECASE)):
            parsed.nonclaim_candidates.append(_candidate(source_id, "NonclaimCandidate", line.lstrip("- "), i, series=series))
        elif section_mode == "dependency" and line.startswith("-"):
            parsed.dependency_candidates.append(_candidate(source_id, "DependencyCandidate", line.lstrip("- "), i, series=series))
        elif section_mode == "next":
            # Preserve concise actual next-target lines, not decorative delimiters.
            if re.search(r"DCRP\d+|RFP[- ]?\d+|MORP[- ]?\d+|Round\s*\d+|Next\b|下一", line, re.IGNORECASE):
                parsed.next_candidates.append(_candidate(source_id, "NextFrontierCandidate", line, i, series=series))

        # Global explicit markers.
        for stop in _STOP.findall(line):
            parsed.frontier_candidates.append(_candidate(source_id, "FrontierCandidate", line, i, stop_id=stop.upper(), series=series))
        if _NO_GO.search(line):
            parsed.obstruction_candidates.append(_candidate(source_id, "ObstructionCandidate", line, i, series=series))
        if _SURVIVOR.search(line):
            parsed.survivor_candidates.append(_candidate(source_id, "SurvivorCandidate", line, i, series=series))
        if re.search(r"does \*\*not\*\* prove|does not prove|NOT PROVED|not proved|不主張", line, re.IGNORECASE):
            parsed.nonclaim_candidates.append(_candidate(source_id, "NonclaimCandidate", line, i, series=series))
        if re.search(r"\\text\{Next\}|\*\*Next:\*\*|^Next\s*[:&]|^下一步", line, re.IGNORECASE):
            parsed.next_candidates.append(_candidate(source_id, "NextFrontierCandidate", line, i, series=series))

    # Deterministic de-duplication of exact candidate identities.
    for attr in [
        "theorem_candidates", "status_candidates", "obstruction_candidates", "survivor_candidates",
        "frontier_candidates", "nonclaim_candidates", "dependency_candidates", "next_candidates",
    ]:
        values = getattr(parsed, attr)
        seen: set[str] = set()
        unique: list[ParsedCandidate] = []
        for candidate in values:
            if candidate.candidate_id not in seen:
                seen.add(candidate.candidate_id)
                unique.append(candidate)
        setattr(parsed, attr, unique)

    return parsed
