from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
import json
from typing import Iterable


@dataclass(frozen=True)
class CorpusSource:
    source_id: str
    file_name: str
    series: str
    series_index: int | None = None
    cycle: str | None = None
    date: str | None = None
    version: str | None = None
    source_ref: str | None = None
    source_hash: str | None = None
    normalized_hash: str | None = None
    canonicality: str = "CANONICAL"
    predecessor_refs: tuple[str, ...] = ()
    duplicate_of: str | None = None
    materialized_path: str | None = None

    def to_dict(self) -> dict:
        return {
            "source_id": self.source_id,
            "file_name": self.file_name,
            "series": self.series,
            "series_index": self.series_index,
            "cycle": self.cycle,
            "date": self.date,
            "version": self.version,
            "source_ref": self.source_ref,
            "source_hash": self.source_hash,
            "normalized_hash": self.normalized_hash,
            "canonicality": self.canonicality,
            "predecessor_refs": sorted(self.predecessor_refs),
            "duplicate_of": self.duplicate_of,
            "materialized_path": self.materialized_path,
        }


@dataclass(frozen=True)
class CorpusManifest:
    sources: list[CorpusSource]
    version: str = "v0.2"
    scope: str = "observed-relative"

    def ordered_sources(self) -> list[CorpusSource]:
        return sorted(self.sources, key=lambda s: (s.series, s.series_index is None, s.series_index or 0, s.file_name, s.source_id))

    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "scope": self.scope,
            "sources": [s.to_dict() for s in self.ordered_sources()],
        }


def manifest_hash(manifest: CorpusManifest) -> str:
    payload = json.dumps(manifest.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def deduplicate_manifest(manifest: CorpusManifest) -> CorpusManifest:
    seen: dict[tuple[str, str], str] = {}
    result: list[CorpusSource] = []
    for source in manifest.ordered_sources():
        key_value = source.source_hash or source.normalized_hash
        if not key_value:
            result.append(source)
            continue
        key = ("hash", key_value)
        if key in seen:
            result.append(replace(source, canonicality="DUPLICATE", duplicate_of=seen[key]))
        else:
            seen[key] = source.source_id
            result.append(replace(source, canonicality="CANONICAL", duplicate_of=None))
    return CorpusManifest(result, version=manifest.version, scope=manifest.scope)


def build_manifest(sources: Iterable[CorpusSource]) -> CorpusManifest:
    return deduplicate_manifest(CorpusManifest(list(sources)))


def manifest_from_directory(root, *, source_namespace: str = "local-corpus", version: str = "v0.2", series_override: str | None = None) -> CorpusManifest:
    """Build a deterministic manifest from materialized Markdown corpus files.

    File identity is stable across content revisions: source_id derives from the
    namespace and relative path, while source_hash records the exact revision.
    """
    from pathlib import Path
    import re
    import yaml
    from .series_profiles import profile_for_filename

    root_path = Path(root).resolve()
    sources: list[CorpusSource] = []
    for path in sorted(root_path.rglob("*.md"), key=lambda p: p.relative_to(root_path).as_posix()):
        raw = path.read_bytes()
        exact_hash = hashlib.sha256(raw).hexdigest()
        text = raw.decode("utf-8")
        normalized = text.replace("\r\n", "\n").replace("\r", "\n").encode("utf-8")
        normalized_hash = hashlib.sha256(normalized).hexdigest()
        relative = path.relative_to(root_path).as_posix()
        stable = hashlib.sha256(f"{source_namespace}|{relative}".encode("utf-8")).hexdigest()[:24]
        source_id = f"corpus:{source_namespace}:{stable}"

        meta: dict = {}
        lines = text.splitlines()
        if lines and lines[0].strip() == "---":
            for idx in range(1, min(len(lines), 200)):
                if lines[idx].strip() == "---":
                    try:
                        loaded = yaml.safe_load("\n".join(lines[1:idx])) or {}
                    except yaml.YAMLError:
                        loaded = {}
                    if isinstance(loaded, dict):
                        meta = loaded
                    break

        profile = profile_for_filename(path.name)
        series_code = series_override or profile.code
        # Numeric series index is used for deterministic logical ordering only.
        match = re.search(r"(?:^|_)(?:RFP|MORP|FCBP)[_-]?(\d{1,3})(?:_|$)", path.name, re.IGNORECASE)
        if match is None and profile.code == "DCRP":
            match = re.search(r"DCRP[_-]?(\d{1,3})", path.name, re.IGNORECASE)
        if match is None and profile.code == "X72":
            match = re.search(r"(?:Round|Checkpoint_v)(\d{1,3})", path.name, re.IGNORECASE)
        series_index = int(match.group(1)) if match else None

        sources.append(CorpusSource(
            source_id=source_id,
            file_name=path.name,
            series=series_code,
            series_index=series_index,
            cycle=str(meta.get("cycle")) if meta.get("cycle") is not None else None,
            date=str(meta.get("date")) if meta.get("date") is not None else None,
            version=str(meta.get("version")) if meta.get("version") is not None else None,
            source_ref=f"materialized:{source_namespace}:{relative}",
            source_hash=exact_hash,
            normalized_hash=normalized_hash,
            canonicality="CANONICAL",
            materialized_path=str(path),
        ))
    return build_manifest(sources)
