from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any

from .model import FELRAFormalRunRecord, TranslationCertificateRecord

_AXIOM_LINE = re.compile(r"'([^']+)' depends on axioms: \[([^\]]*)\]")
_AXIOM_FREE = re.compile(r"'([^']+)' does not depend on any axioms")


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


def _certificate_integrity(cert: dict[str, Any] | None) -> bool | None:
    if cert is None:
        return None
    recorded = cert.get("certificate_sha256")
    if not recorded:
        return False
    payload = {
        "kind": cert.get("kind"),
        "subject": cert.get("subject", ""),
        "data": cert.get("data") or {},
        "issuer": cert.get("issuer", "felra"),
    }
    return hashlib.sha256(_canonical(payload)).hexdigest() == recorded


def _theorem_names(stdout: str) -> set[str]:
    names = {name for name, _ in _AXIOM_LINE.findall(stdout or "")}
    names.update(_AXIOM_FREE.findall(stdout or ""))
    return names


@dataclass
class FELRAImportDecision:
    decision: str
    proof_eligible: bool
    reasons: list[str]
    formal_run: FELRAFormalRunRecord | None = None
    certificate_integrity_valid: bool | None = None


def import_felra_formal_result(
    bridge_manifest: dict[str, Any],
    translation: TranslationCertificateRecord | dict[str, Any],
    payload: dict[str, Any],
    *,
    certificate: dict[str, Any] | None = None,
) -> FELRAImportDecision:
    t = translation.to_dict() if hasattr(translation, "to_dict") else dict(translation)
    reasons: list[str] = []
    cert_ok = _certificate_integrity(certificate)
    if certificate is not None and not cert_ok:
        return FELRAImportDecision("REFUSE", False, ["FELRA certificate integrity mismatch"], certificate_integrity_valid=False)

    if payload.get("kind") != "formal_check":
        return FELRAImportDecision("REFUSE", False, ["payload kind is not formal_check"], certificate_integrity_valid=cert_ok)
    metrics = dict(payload.get("metrics") or {})
    checker = dict(metrics.get("checker") or {})
    obligation = dict(metrics.get("obligation") or {})
    formal_status = metrics.get("formal_status")
    backend = checker.get("backend") or metrics.get("backend")
    expected = metrics.get("expected_formal_status")
    expectation_met = metrics.get("expectation_met")
    wanted_sha = bridge_manifest.get("obligation_sha256")
    if t.get("status") != "VALID": reasons.append("translation certificate is not VALID")
    if t.get("fir_sha256") != bridge_manifest.get("fir_sha256"): reasons.append("translation FIR identity mismatch")
    if backend != "lean": reasons.append("formal backend is not lean")
    if formal_status != "verified": reasons.append(f"formal_status is {formal_status!r}, not verified")
    if expected != "verified" or expectation_met is not True: reasons.append("declared verified expectation was not met")
    if obligation.get("sha256") != wanted_sha or t.get("obligation_sha256") != wanted_sha: reasons.append("obligation SHA-256 mismatch")
    if not checker.get("version_string") or not checker.get("executable_sha256"): reasons.append("checker identity/version/hash incomplete")
    audited = metrics.get("theorems_audited")
    names = _theorem_names(str(metrics.get("stdout_tail") or ""))
    intended = set(bridge_manifest.get("theorem_names") or [])
    if not audited or audited < 1: reasons.append("axiom audit is vacuous")
    if intended and not intended.issubset(names): reasons.append("intended theorem name absent from Lean axiom audit")
    observed_axioms = set(metrics.get("axioms_seen") or [])
    allowed = set((bridge_manifest.get("axiom_policy") or {}).get("allowed") or [])
    if not observed_axioms.issubset(allowed): reasons.append("observed Lean axiom exceeds bridge allowlist")
    warning_text = " ".join(str(x) for x in (payload.get("warnings") or [])).lower()
    detail = str(metrics.get("detail") or "").lower()
    if any(token in warning_text + " " + detail for token in ("sorry", "unavailable", "undecided", "obligation not found", "malformed")):
        reasons.append("FELRA evidence contains incomplete/unavailable/malformed condition")

    normalized = {
        "subject_id": bridge_manifest.get("subject_id"),
        "bridge_id": bridge_manifest.get("bridge_id"),
        "felra_version": str(metrics.get("felra_version") or payload.get("felra_version") or "1.8.1"),
        "backend": "lean",
        "formal_status": formal_status,
        "obligation_sha256": obligation.get("sha256") or "",
        "checker_version": checker.get("version_string") or "",
        "checker_executable_sha256": checker.get("executable_sha256") or "",
        "exit_code": metrics.get("exit_code"),
        "theorems_audited": audited,
        "axioms_seen": sorted(observed_axioms),
        "assumptions": sorted(metrics.get("assumptions") or []),
        "limitations": sorted(metrics.get("limitations") or []),
    }
    result_sha = _digest(normalized)
    felra_cert_sha = str((certificate or {}).get("certificate_sha256") or "")
    run = FELRAFormalRunRecord(
        formal_run_id="felra-run:" + result_sha[:24],
        subject_id=str(bridge_manifest.get("subject_id") or ""),
        bridge_id=str(bridge_manifest.get("bridge_id") or ""),
        felra_version=normalized["felra_version"], backend="lean",
        formal_status=str(formal_status or ""), obligation_sha256=normalized["obligation_sha256"],
        checker_version=normalized["checker_version"], checker_executable_sha256=normalized["checker_executable_sha256"],
        exit_code=normalized["exit_code"], theorems_audited=audited, axioms_seen=sorted(observed_axioms),
        assumptions=normalized["assumptions"], limitations=normalized["limitations"],
        felra_result_sha256=result_sha, felra_certificate_sha256=felra_cert_sha,
        status="VALID" if not reasons else "DEFER",
        evidence_refs=[f"felra-result:sha256:{result_sha}"] + ([f"felra-certificate:sha256:{felra_cert_sha}"] if felra_cert_sha else []),
    )
    decision = "VALID" if not reasons else ("REFUSE" if any("mismatch" in r or "not lean" in r for r in reasons) else "DEFER")
    return FELRAImportDecision(decision, not reasons, reasons, run, cert_ok)
