from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import re

from .series_profiles import SeriesProfile
from .source_parser import ParsedCandidate


class ValidationClass(str, Enum):
    PROMOTABLE = "PROMOTABLE"
    NEEDS_REVIEW = "NEEDS_REVIEW"
    REJECTED = "REJECTED"


@dataclass(frozen=True)
class ValidationDecision:
    validation_class: ValidationClass
    theorem_promotion_allowed: bool
    reason: str


@dataclass(frozen=True)
class CrossSeriesProposal:
    left_candidate_id: str
    right_candidate_id: str
    relation: str
    reason: str
    validation_class: ValidationClass = ValidationClass.NEEDS_REVIEW
    auto_quotient: bool = False


_NON_THEOREM_STRUCTURAL = {
    "FrontierCandidate",
    "NextFrontierCandidate",
    "DependencyCandidate",
    "NonclaimCandidate",
}

_REVIEW_REQUIRED = {
    "TheoremCandidate",
    "StatusCandidate",
    "ObstructionCandidate",
    "SurvivorCandidate",
}


def classify_candidate(candidate: ParsedCandidate, profile: SeriesProfile) -> ValidationDecision:
    statement = candidate.statement.lower()
    if (
        candidate.candidate_type == "StatusCandidate"
        and profile.research_cycle_closed_is_process_only
        and "closed as a research cycle" in statement
    ):
        return ValidationDecision(
            ValidationClass.NEEDS_REVIEW,
            False,
            "Research cycle closure is process metadata and cannot become theorem closure.",
        )
    if candidate.candidate_type in _NON_THEOREM_STRUCTURAL:
        return ValidationDecision(
            ValidationClass.PROMOTABLE,
            False,
            "Safe structural promotion only; no theorem authority is granted.",
        )
    if candidate.candidate_type in _REVIEW_REQUIRED:
        return ValidationDecision(
            ValidationClass.NEEDS_REVIEW,
            False,
            "Semantic/theorem-bearing candidate requires evidence and scope review.",
        )
    return ValidationDecision(
        ValidationClass.NEEDS_REVIEW,
        False,
        "Unknown candidate class requires review.",
    )


def _tokens(text: str) -> set[str]:
    normalized = text.lower().replace("–", "-").replace("—", "-")
    return {
        token
        for token in re.findall(r"[a-z0-9_]+", normalized)
        if len(token) >= 3 and token not in {"the", "and", "for", "not", "proved", "proof"}
    }


def validate_promotion_against_nonclaims(target_statement: str, nonclaim_statements: list[str]) -> ValidationDecision:
    target_tokens = _tokens(target_statement)
    for nonclaim in nonclaim_statements:
        nonclaim_tokens = _tokens(nonclaim)
        negative = bool(re.search(r"\bnot\b.*\b(proved|proof)\b|does not prove|not proved|不主張", nonclaim, re.IGNORECASE))
        if negative and target_tokens and target_tokens.issubset(nonclaim_tokens):
            return ValidationDecision(
                ValidationClass.REJECTED,
                False,
                "Explicit nonclaim forbids this theorem promotion.",
            )
    return ValidationDecision(
        ValidationClass.NEEDS_REVIEW,
        False,
        "No explicit contradiction found; theorem promotion still requires evidence review.",
    )


def propose_cross_series_match(left: ParsedCandidate, right: ParsedCandidate, reason: str) -> CrossSeriesProposal:
    return CrossSeriesProposal(
        left_candidate_id=left.candidate_id,
        right_candidate_id=right.candidate_id,
        relation="POSSIBLE_SEMANTIC_MATCH",
        reason=reason,
        validation_class=ValidationClass.NEEDS_REVIEW,
        auto_quotient=False,
    )
