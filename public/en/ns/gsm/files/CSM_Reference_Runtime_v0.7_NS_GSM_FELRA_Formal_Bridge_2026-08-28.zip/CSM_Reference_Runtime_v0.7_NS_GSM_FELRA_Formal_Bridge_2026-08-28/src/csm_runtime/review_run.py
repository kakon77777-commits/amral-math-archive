from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .full_corpus import FullCorpusRun, ingest_corpus_tree, ingest_corpus_tree_into
from .ledger import EventLedger
from .model import NativeState
from .review import ReviewBatch, build_structural_review_batch
from .review_batch import ReviewBatchResult, commit_review_batch


@dataclass
class V03ReviewRun:
    corpus_run: FullCorpusRun
    expansion_run: FullCorpusRun | None
    state: NativeState
    ledger: EventLedger
    review_batch: ReviewBatch
    review_result: ReviewBatchResult

    def reapply_structural_review(self) -> ReviewBatchResult:
        return commit_review_batch(self.state, self.ledger, self.review_batch)


def run_v03_review(
    seed_path: str | Path,
    corpus_root: str | Path,
    *,
    expansion_root: str | Path | None = None,
) -> V03ReviewRun:
    corpus = ingest_corpus_tree(seed_path, corpus_root)
    current_state = corpus.state
    expansion = None
    if expansion_root is not None:
        expansion = ingest_corpus_tree_into(current_state, corpus.ledger, expansion_root)
        current_state = expansion.state
    batch = build_structural_review_batch(
        current_state.candidates.values(),
        review_policy_version="v0.3",
    )
    result = commit_review_batch(current_state, corpus.ledger, batch)
    return V03ReviewRun(
        corpus_run=corpus,
        expansion_run=expansion,
        state=result.state,
        ledger=corpus.ledger,
        review_batch=batch,
        review_result=result,
    )


def write_v03_evidence(run: V03ReviewRun, evidence_dir: str | Path) -> dict:
    import json
    from dataclasses import asdict

    from .canonical import state_hash
    from .cross_series_audit import exact_statement_proposals
    from .query import QueryEngine
    from .replay import replay_ledger

    root = Path(evidence_dir)
    root.mkdir(parents=True, exist_ok=True)

    def write_json(name: str, value) -> None:
        (root / name).write_text(
            json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
            newline="\n",
        )

    engine = QueryEngine(run.state)
    review_summary = engine.review_summary().answer
    promotion_summary = engine.promotion_summary().answer
    pending = engine.pending_review().answer

    write_json("review_summary.json", review_summary)
    write_json("promotion_summary.json", promotion_summary)
    write_json("pending_review.json", {
        "count": len(pending),
        "source_layer": "candidate+review",
        "candidates": pending,
    })
    write_json("promotion_receipts.json", {
        "count": len(run.state.promotion_receipts),
        "receipts": [
            r.to_dict() for r in sorted(run.state.promotion_receipts.values(), key=lambda x: x.promotion_id)
        ],
    })

    review_events = [
        e for e in run.ledger.events
        if e.event_type in {"REGISTER_REVIEW", "UPDATE_REVIEW_STATUS", "REGISTER_PROMOTION_RECEIPT"}
        or e.event_id.startswith("review:checkpoint:")
    ]
    with (root / "review_ledger.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
        for event in review_events:
            handle.write(json.dumps(event.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")))
            handle.write("\n")

    proposals = exact_statement_proposals(run.state)
    proposal_rows = []
    for proposal in proposals:
        row = asdict(proposal)
        row["validation_class"] = proposal.validation_class.value
        row.update({
            "review_status": "NEEDS_REVIEW",
            "scope_match": "UNKNOWN",
            "assumption_match": "UNKNOWN",
            "representation_match": "UNKNOWN",
            "auto_quotient": False,
        })
        proposal_rows.append(row)
    cross_series = {
        "proposal_count": len(proposal_rows),
        "auto_quotient_count": 0,
        "proposals": proposal_rows,
    }
    write_json("cross_series_review.json", cross_series)

    baseline_counts = {
        entry.series: entry.source_count for entry in run.corpus_run.coverage
    }
    expansion_counts = {
        entry.series: entry.source_count for entry in (run.expansion_run.coverage if run.expansion_run else ())
    }
    all_series = sorted(set(baseline_counts) | set(expansion_counts))
    coverage_rows = []
    for series in all_series:
        base = baseline_counts.get(series, 0)
        extra = expansion_counts.get(series, 0)
        total = base + extra
        coverage_rows.append({
            "series": series,
            "coverage_state": "CONTENT_INGESTED",
            "baseline_content_count": base,
            "v03_expansion_content_count": extra,
            "total_content_count": total,
            "note": (
                "v0.3 source-backed expansion added." if extra
                else "v0.2 content baseline retained; no new v0.3 materialization in this series."
            ),
        })
    write_json("content_coverage_v03.json", coverage_rows)

    current_hash = state_hash(run.state)
    with (root / "ns_gsm_v03_ledger.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
        for event in run.ledger.events:
            handle.write(json.dumps(event.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")))
            handle.write("\n")
    write_json("native_snapshot_v03.json", {"state_hash": current_hash, "state": run.state.to_dict()})

    replayed = replay_ledger(run.ledger.events, policy_version=run.state.policy_version)
    replay_hash = state_hash(replayed)
    replay_report = {
        "expected_hash": current_hash,
        "replayed_hash": replay_hash,
        "match": replay_hash == current_hash,
        "event_count": len(run.ledger.events),
    }
    write_json("replay_report_v03.json", replay_report)

    baseline_artifacts = sum(len(m.sources) for m in run.corpus_run.manifests)
    expansion_artifacts = sum(len(m.sources) for m in (run.expansion_run.manifests if run.expansion_run else ()))
    content_artifacts = baseline_artifacts + expansion_artifacts

    rfp_process_safe = any(
        review.decision == "DEFER"
        and review.status == "DEFERRED"
        and "process" in review.reason.lower()
        and (run.state.candidates.get(review.candidate_id) is not None)
        and (((run.state.candidates[review.candidate_id].proposed_object or {}).get("metadata") or {}).get("series") == "RFP")
        for review in run.state.reviews.values()
    )
    second = run.reapply_structural_review()
    conformance_checks = {
        "root_formal_ns_open": run.state.objects["claim:formal-root-regularity"].status.value == "OPEN",
        "observed_relative_scope": run.state.scope == "observed-relative",
        "replay_exact": replay_report["match"],
        "all_candidates_have_review": len(run.state.reviews) == len(run.state.candidates),
        "review_batch_idempotent": second.status == "IDEMPOTENT_NOOP" and second.event_count == 0,
        "cross_series_auto_quotient_zero": cross_series["auto_quotient_count"] == 0,
        "rfp_process_closed_not_theorem": rfp_process_safe,
        "structural_promotions_exist": len(run.state.promotion_receipts) > 0,
        "proof_asset_not_auto_promoted_in_tier0": promotion_summary.get("by_class", {}).get("PROOF_ASSET", 0) == 0,
        "obstruction_not_auto_promoted_in_tier0": promotion_summary.get("by_class", {}).get("OBSTRUCTION", 0) == 0,
        "v03_expansion_is_source_backed": expansion_artifacts == 15,
    }
    conformance = {
        "suite": "NS_GSM v0.3 candidate review / promotion conformance",
        "passed": sum(conformance_checks.values()),
        "total": len(conformance_checks),
        "all_passed": all(conformance_checks.values()),
        "checks": conformance_checks,
    }
    write_json("conformance_report_v03.json", conformance)

    summary = {
        "version": "v0.3",
        "runtime_version": "0.3.0",
        "scope": run.state.scope,
        "root_status": run.state.objects["claim:formal-root-regularity"].status.value,
        "state_hash": current_hash,
        "replay_match": replay_report["match"],
        "ledger_event_count": len(run.ledger.events),
        "baseline_artifact_count": baseline_artifacts,
        "expansion_artifact_count": expansion_artifacts,
        "content_artifact_count": content_artifacts,
        "candidate_count": len(run.state.candidates),
        "review_count": len(run.state.reviews),
        "promotion_count": len(run.state.promotion_receipts),
        "pending_review_count": len(pending),
        "cross_series_proposal_count": len(proposal_rows),
        "cross_series_auto_quotient_count": 0,
        "review_summary": review_summary,
        "promotion_summary": promotion_summary,
        "conformance_all_passed": conformance["all_passed"],
    }
    write_json("run_summary_v03.json", summary)
    return summary
