from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json

from .authority_batch import AuthorityBatchResult, commit_authority_review_batch
from .authority_manifest import AuthorityReviewManifest, load_authority_manifest
from .canonical import state_hash
from .ledger import EventLedger
from .model import NativeState
from .query import QueryEngine
from .replay import replay_ledger
from .review_run import V03ReviewRun, run_v03_review


@dataclass
class V04AuthorityRun:
    baseline: V03ReviewRun
    manifest: AuthorityReviewManifest
    core_result: AuthorityBatchResult
    rfp_result: AuthorityBatchResult
    state: NativeState
    ledger: EventLedger
    source_root: Path

    def reapply(self) -> tuple[AuthorityBatchResult, AuthorityBatchResult]:
        core = [e for e in self.manifest.entries if not e.audit_id.startswith("audit:rfp:")]
        rfp = [e for e in self.manifest.entries if e.audit_id.startswith("audit:rfp:")]
        a = commit_authority_review_batch(self.state, self.ledger, core, source_root=self.source_root, batch_id="v0.4-core-authority")
        b = commit_authority_review_batch(a.state, self.ledger, rfp, source_root=self.source_root, batch_id="v0.4-rfp-authority")
        return a, b


def run_v04_authority_review(seed_path, corpus_root, *, expansion_root, manifest_path) -> V04AuthorityRun:
    source_root = Path(manifest_path).resolve().parent
    baseline = run_v03_review(seed_path, corpus_root, expansion_root=expansion_root)
    manifest = load_authority_manifest(manifest_path)
    core = [e for e in manifest.entries if not e.audit_id.startswith("audit:rfp:")]
    rfp = [e for e in manifest.entries if e.audit_id.startswith("audit:rfp:")]
    core_result = commit_authority_review_batch(baseline.state, baseline.ledger, core, source_root=source_root, batch_id="v0.4-core-authority")
    rfp_result = commit_authority_review_batch(core_result.state, baseline.ledger, rfp, source_root=source_root, batch_id="v0.4-rfp-authority")
    return V04AuthorityRun(baseline, manifest, core_result, rfp_result, rfp_result.state, baseline.ledger, source_root)


def write_v04_evidence(run: V04AuthorityRun, evidence_dir) -> dict:
    root = Path(evidence_dir); root.mkdir(parents=True, exist_ok=True)
    engine = QueryEngine(run.state)
    def write(name, value):
        (root/name).write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8", newline="\n")
    audits = [a.to_dict() for a in sorted(run.state.authority_audits.values(), key=lambda a: a.audit_id)]
    proof_assets = engine.proof_assets().answer
    obstruction_assets = engine.obstruction_assets().answer
    deferred = engine.deferred_authority().answer
    write("authority_audits_v04.json", {"count": len(audits), "audits": audits})
    write("proof_assets_v04.json", {"count": len(proof_assets), "assets": proof_assets})
    write("obstruction_assets_v04.json", {"count": len(obstruction_assets), "assets": obstruction_assets})
    write("deferred_authority_v04.json", {"count": len(deferred), "audits": deferred})
    current_hash = state_hash(run.state)
    with (root/"ns_gsm_v04_ledger.jsonl").open("w", encoding="utf-8", newline="\n") as h:
        for e in run.ledger.events:
            h.write(json.dumps(e.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
    write("native_snapshot_v04.json", {"state_hash": current_hash, "state": run.state.to_dict()})
    replayed = replay_ledger(run.ledger.events, policy_version=run.state.policy_version)
    replay_hash = state_hash(replayed)
    replay = {"expected_hash": current_hash, "replayed_hash": replay_hash, "match": replay_hash == current_hash, "event_count": len(run.ledger.events)}
    write("replay_report_v04.json", replay)
    again_core, again_rfp = run.reapply()
    checks = {
        "root_formal_ns_open": run.state.objects["claim:formal-root-regularity"].status.value == "OPEN",
        "c1_open": run.state.objects["claim:c1-chain-necessity"].status.value == "OPEN",
        "c2_open": run.state.objects["claim:c2-finite-obstruction"].status.value == "OPEN",
        "replay_exact": replay["match"],
        "audit_count_20": len(audits) == 20,
        "proof_assets_12": len(proof_assets) == 12,
        "obstruction_assets_1": len(obstruction_assets) == 1,
        "deferred_3": len(deferred) == 3,
        "v04_assets_audit_only": all(a["authority"] == "AUDIT" for a in proof_assets + obstruction_assets),
        "d104_fixed_positive_scope_preserved": "Must not be promoted uniformly" in run.state.objects["claim:d104-positive-viscosity-frozen-kernel-empty"].metadata.get("scope_note", ""),
        "d105_survivor_open": run.state.objects["survivor:d105-vm-shear-pol"].status.value == "OPEN",
        "d105_frontier_open": run.state.objects["frontier:d105-first-order"].status.value == "OPEN",
        "authority_batches_idempotent": again_core.status == "IDEMPOTENT_NOOP" and again_rfp.status == "IDEMPOTENT_NOOP",
    }
    conf = {"suite":"NS_GSM v0.4 proof-authority review", "passed":sum(checks.values()), "total":len(checks), "all_passed":all(checks.values()), "checks":checks}
    write("conformance_report_v04.json", conf)
    summary = {
        "version":"v0.4", "runtime_version":"0.4.0", "root_status":"OPEN", "scope":run.state.scope,
        "state_hash":current_hash, "replay_match":replay["match"], "ledger_event_count":len(run.ledger.events),
        "candidate_count":len(run.state.candidates), "structural_review_count":len(run.state.reviews),
        "structural_promotion_count":sum(1 for p in run.state.promotion_receipts.values() if not p.promotion_id.startswith("authority:promotion:")),
        "authority_audit_count":len(audits), "proof_asset_count":len(proof_assets), "obstruction_asset_count":len(obstruction_assets),
        "deferred_authority_count":len(deferred), "authority_promotion_count":sum(1 for p in run.state.promotion_receipts.values() if p.promotion_id.startswith("authority:promotion:")),
        "conformance_all_passed":conf["all_passed"],
    }
    write("run_summary_v04.json", summary)
    return summary
