from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib

from .canonical import state_hash
from .errors import AuthorityError
from .ledger import EventLedger, LedgerEvent
from .model import AuthorityTierReceipt, CertificateRecord, FormalizationRecord, NativeState, ReplicationRecord
from .state import apply_event
from .transaction import ClosureTransaction

_ALLOWED_FORMALIZATION = {"CORE_COMPLETE", "SCHEMA_COMPLETE", "WITNESS_COMPLETE"}

@dataclass(frozen=True)
class TierBatchResult:
    status: str
    state: NativeState
    formalization_count: int = 0
    replication_count: int = 0
    tier_count: int = 0
    event_count: int = 0
    input_state_hash: str = ""
    output_state_hash: str = ""


def _short(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()[:24]


def _event(event_id, event_type, payload, sequence, state, *, certs=(), kind="v06_tier"):
    return LedgerEvent(event_id, event_type, payload, sequence, certificate_refs=tuple(certs),
                       provenance={"kind":kind}, operator_version="v0.6", policy_version=state.policy_version)


def commit_formalization_replication_tiers(state: NativeState, ledger: EventLedger, formalizations, replications, *, batch_id: str) -> TierBatchResult:
    checkpoint=f"v06:tier:checkpoint:{_short(batch_id)}"
    input_hash=state_hash(state)
    if any(e.event_id==checkpoint for e in ledger.events):
        return TierBatchResult("IDEMPOTENT_NOOP",state,input_state_hash=input_hash,output_state_hash=input_hash)
    formalizations=sorted(list(formalizations),key=lambda x:x.formalization_id)
    replications=sorted(list(replications),key=lambda x:x.replication_id)
    formal_by_id={f.formalization_id:f for f in formalizations}
    sequence=len(ledger.events)+1
    events=[]; tier_specs=[]
    for formal in formalizations:
        if formal.subject_id not in state.objects:
            raise AuthorityError(f"unknown formalization subject: {formal.subject_id}")
        events.append(_event(f"v06:formal:{_short(formal.formalization_id)}","REGISTER_FORMALIZATION",formal.to_dict(),sequence,state)); sequence+=1
        if formal.status in _ALLOWED_FORMALIZATION:
            cert_id=f"cert:formalization:{_short(formal.formalization_id)}"
            cert=CertificateRecord(cert_id,"FORMALIZATION_BUNDLE",[formal.subject_id],"VALID",scope=formal.scope,
                                   evidence_refs=list(formal.evidence_refs),
                                   verifier_results=[{"language":formal.language,"status":formal.status,"bundle_sha256":formal.bundle_sha256}],version="v0.6")
            cert_eid=f"v06:formal-cert:{_short(cert_id)}"; tier_eid=f"v06:formal-tier:{_short(formal.subject_id)}"
            events.append(_event(cert_eid,"REGISTER_CERTIFICATE",cert.to_dict(),sequence,state)); sequence+=1
            events.append(_event(tier_eid,"ADD_AUTHORITY_TIER",{"object_id":formal.subject_id,"tier_type":"FORMALIZED_CORE_ONLY","certificate_id":cert_id},sequence,state,certs=(cert_id,))); sequence+=1
            tier_specs.append((formal.subject_id,"FORMALIZED_CORE_ONLY",formal.formalization_id,cert_id,[cert_eid,tier_eid]))
    for repl in replications:
        if repl.subject_id not in state.objects:
            raise AuthorityError(f"unknown replication subject: {repl.subject_id}")
        formal=formal_by_id.get(repl.formalization_id) or state.formalizations.get(repl.formalization_id)
        if formal is None:
            raise AuthorityError(f"replication missing formalization: {repl.formalization_id}")
        if formal.subject_id != repl.subject_id or formal.bundle_sha256 != repl.input_bundle_sha256:
            raise AuthorityError("replication/formalization identity mismatch")
        events.append(_event(f"v06:replication:{_short(repl.replication_id)}","REGISTER_REPLICATION",repl.to_dict(),sequence,state)); sequence+=1
        if repl.result == "MATCH":
            cert_id=f"cert:replication:{_short(repl.replication_id)}"
            cert=CertificateRecord(cert_id,"CROSS_IMPLEMENTATION_REPLICATION",[repl.subject_id],"VALID",scope=formal.scope,
                                   evidence_refs=list(repl.evidence_refs),
                                   verifier_results=[{"replicator_id":repl.replicator_id,"implementation_sha256":repl.implementation_sha256,
                                                      "result":"MATCH","output_artifact_sha256":repl.output_artifact_sha256}],version="v0.6")
            cert_eid=f"v06:repl-cert:{_short(cert_id)}"; tier_eid=f"v06:repl-tier:{_short(repl.subject_id)}"
            events.append(_event(cert_eid,"REGISTER_CERTIFICATE",cert.to_dict(),sequence,state)); sequence+=1
            events.append(_event(tier_eid,"ADD_AUTHORITY_TIER",{"object_id":repl.subject_id,"tier_type":"CROSS_IMPLEMENTATION_REPLICATED","certificate_id":cert_id},sequence,state,certs=(cert_id,))); sequence+=1
            tier_specs.append((repl.subject_id,"CROSS_IMPLEMENTATION_REPLICATED",repl.replication_id,cert_id,[cert_eid,tier_eid]))
    effect=deepcopy(state)
    for e in events: apply_event(effect,e)
    effect_hash=state_hash(effect)
    for subject,tier,source_record,cert_id,event_ids in tier_specs:
        receipt=AuthorityTierReceipt(f"tier:{_short(tier+subject)}",subject,tier,source_record,cert_id,event_ids,input_hash,effect_hash)
        events.append(_event(f"v06:tier-receipt:{_short(receipt.tier_receipt_id)}","REGISTER_AUTHORITY_TIER_RECEIPT",receipt.to_dict(),sequence,state)); sequence+=1
    events.append(_event(checkpoint,"NOTE",{"kind":"v06_tier_checkpoint","batch_id":batch_id,"tier_count":len(tier_specs)},sequence,state))
    txn=ClosureTransaction(state,ledger)
    for e in events: txn.stage(e)
    tx=txn.commit()
    return TierBatchResult(tx.commit_status,tx.state,len(formalizations),len(replications),len(tier_specs),len(events),tx.input_state_hash,tx.output_state_hash)


def attach_formal_proof_tier(state: NativeState, ledger: EventLedger, subject_id: str, certificate_id: str, *, batch_id: str) -> TierBatchResult:
    checkpoint=f"v06:formal-proof:checkpoint:{_short(batch_id)}"
    input_hash=state_hash(state)
    if any(e.event_id==checkpoint for e in ledger.events):
        return TierBatchResult("IDEMPOTENT_NOOP",state,input_state_hash=input_hash,output_state_hash=input_hash)
    if subject_id not in state.objects:
        raise AuthorityError(f"unknown subject: {subject_id}")
    cert=state.certificates.get(certificate_id)
    if cert is None or cert.certificate_type != "KERNEL_FORMAL_PROOF" or cert.status != "VALID" or subject_id not in cert.subject_ids:
        raise AuthorityError("FORMAL_PROOF requires VALID KERNEL_FORMAL_PROOF certificate for subject")
    accepted=False
    for result in cert.verifier_results:
        digest=str(result.get("proof_object_sha256") or "")
        if result.get("kernel_checked") is True and str(result.get("tool") or "").strip() and len(digest)==64:
            accepted=True
    if not accepted:
        raise AuthorityError("FORMAL_PROOF requires kernel_checked tool and proof-object SHA-256")
    sequence=len(ledger.events)+1
    tier_eid=f"v06:formal-proof-tier:{_short(subject_id)}"
    events=[_event(tier_eid,"ADD_AUTHORITY_TIER",{"object_id":subject_id,"tier_type":"FORMAL_PROOF","certificate_id":certificate_id},sequence,state,certs=(certificate_id,))]
    sequence+=1
    effect=deepcopy(state); apply_event(effect,events[0]); effect_hash=state_hash(effect)
    receipt=AuthorityTierReceipt(f"tier:{_short('FORMAL_PROOF'+subject_id)}",subject_id,"FORMAL_PROOF",certificate_id,certificate_id,[tier_eid],input_hash,effect_hash)
    events.append(_event(f"v06:formal-proof-receipt:{_short(receipt.tier_receipt_id)}","REGISTER_AUTHORITY_TIER_RECEIPT",receipt.to_dict(),sequence,state)); sequence+=1
    events.append(_event(checkpoint,"NOTE",{"kind":"formal_proof_checkpoint","batch_id":batch_id},sequence,state))
    txn=ClosureTransaction(state,ledger)
    for e in events: txn.stage(e)
    tx=txn.commit()
    return TierBatchResult(tx.commit_status,tx.state,tier_count=1,event_count=len(events),input_state_hash=tx.input_state_hash,output_state_hash=tx.output_state_hash)
