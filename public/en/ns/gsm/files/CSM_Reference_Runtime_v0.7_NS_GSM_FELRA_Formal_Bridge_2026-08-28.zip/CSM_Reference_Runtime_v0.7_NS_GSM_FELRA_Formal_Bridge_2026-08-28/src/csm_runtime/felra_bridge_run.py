from __future__ import annotations

from dataclasses import dataclass, field
import json, hashlib
from pathlib import Path
from typing import Any

from .canonical import state_hash
from .felra_bridge import BridgeExportResult, export_felra_bridge
from .felra_import import FELRAImportDecision, import_felra_formal_result
from .formalization import case_for_statement, v06_proof_assets
from .kernel_formal_batch import KernelFormalBatchResult, commit_kernel_formal_proof
from .ledger import EventLedger, LedgerEvent
from .model import NativeState, native_state_from_dict
from .transaction import ClosureTransaction


def _short(s:str)->str: return hashlib.sha256(s.encode()).hexdigest()[:24]
def _event(eid,typ,payload,seq,state):
    return LedgerEvent(eid,typ,payload,seq,provenance={'kind':'v07_bridge_ready'},operator_version='v0.7',policy_version=state.policy_version)


def load_v06_frozen(root: Path) -> tuple[NativeState, EventLedger]:
    snap=json.loads((root/'evidence/v0.6/native_snapshot_v06.json').read_text(encoding='utf-8'))
    state=native_state_from_dict(snap['state'])
    events=[]
    for line in (root/'evidence/v0.6/ns_gsm_v06_ledger.jsonl').read_text(encoding='utf-8').splitlines():
        if line.strip(): events.append(LedgerEvent.from_dict(json.loads(line)))
    ledger=EventLedger(events)
    # v0.7 adds empty canonical registries, so the v0.6 serialized hash migrates.
    # Integrity is established by requiring migrated snapshot == replayed v0.6 ledger.
    from .replay import replay_ledger
    replayed = replay_ledger(events, policy_version=state.policy_version)
    if state_hash(state) != state_hash(replayed):
        raise ValueError('v0.6 snapshot/ledger migration mismatch')
    return state,ledger


def _commit_bridge_ready(state: NativeState, ledger: EventLedger, exports: list[BridgeExportResult]) -> tuple[str,NativeState]:
    checkpoint='v07:bridge-ready:checkpoint:'+_short('D103.1-5')
    if any(e.event_id==checkpoint for e in ledger.events): return 'IDEMPOTENT_NOOP',state
    seq=len(ledger.events)+1; events=[]
    for exp in sorted(exports,key=lambda x:x.subject_id):
        t=exp.translation; o=exp.obligation_record
        if t.translation_id not in state.translation_certificates:
            events.append(_event('v07:translation:'+_short(t.translation_id),'REGISTER_TRANSLATION_CERTIFICATE',t.to_dict(),seq,state)); seq+=1
        if o.obligation_id not in state.formal_obligations:
            events.append(_event('v07:obligation:'+_short(o.obligation_id),'REGISTER_FORMAL_OBLIGATION',o.to_dict(),seq,state)); seq+=1
    events.append(_event(checkpoint,'NOTE',{'kind':'v07_bridge_ready_checkpoint','export_count':len(exports)},seq,state))
    txn=ClosureTransaction(state,ledger)
    for e in events: txn.stage(e)
    tx=txn.commit(); return tx.commit_status,tx.state

@dataclass
class V07BridgeRun:
    root: Path
    state: NativeState
    ledger: EventLedger
    exports: list[BridgeExportResult]
    imports: list[FELRAImportDecision] = field(default_factory=list)
    kernel_batches: list[KernelFormalBatchResult] = field(default_factory=list)
    release_mode: str='BRIDGE_READY'

    def reapply(self):
        status,_=_commit_bridge_ready(self.state,self.ledger,self.exports)
        return status


def run_v07_felra_bridge(root, evidence_dir, felra_results: dict[str,dict[str,Any]]|None=None) -> V07BridgeRun:
    root=Path(root); evidence_dir=Path(evidence_dir)
    state,ledger=load_v06_frozen(root)
    exports=[]
    d103=[o for o in v06_proof_assets(state) if str(o.metadata.get('statement') or '').startswith('Theorem D103.')]
    for obj in sorted(d103,key=lambda o:case_for_statement(str(o.metadata['statement']))):
        case=case_for_statement(str(obj.metadata['statement']))
        exports.append(export_felra_bridge(state,obj.object_id,evidence_dir/'bridges'/case))
    if len(exports)!=5: raise ValueError(f'v0.7 requires five D103 targets; got {len(exports)}')
    _,state=_commit_bridge_ready(state,ledger,exports)
    imports=[]; batches=[]
    results=felra_results or {}
    for exp in exports:
        payload=results.get(exp.subject_id)
        if payload is None: continue
        decision=import_felra_formal_result(exp.bridge_manifest,exp.translation,payload)
        imports.append(decision)
        if decision.proof_eligible and decision.formal_run is not None:
            batch=commit_kernel_formal_proof(state,ledger,exp.translation,exp.obligation_record,decision.formal_run,batch_id=exp.bridge_id)
            state=batch.state; batches.append(batch)
    mode='FORMAL_PROOF_ACTIVE' if state.kernel_formal_proof_receipts else 'BRIDGE_READY'
    return V07BridgeRun(root,state,ledger,exports,imports,batches,mode)
