from __future__ import annotations

from typing import Any

from .enums import Authority, ClosureStatus
from .errors import IllegalTransitionError, UnknownObjectError, ValidationError
from .ledger import LedgerEvent
from .model import (
    AuthorityAuditRecord, AuthorityTierReceipt, AuthorityUpgradeReceipt, CandidateRecord, CertificateRecord,
    DebtRecord, EdgeRecord, ExternalTheoremAnchorRecord, FormalizationRecord, IndependentVerificationRecord,
    FELRAFormalRunRecord, FormalObligationRecord, KernelFormalProofReceipt, NativeState, ObjectRecord,
    PromotionReceipt, ReplicationRecord, ReviewRecord, TranslationCertificateRecord,
)


def _object_from_payload(p: dict[str, Any]) -> ObjectRecord:
    return ObjectRecord(
        object_id=p["object_id"],
        object_type=p["object_type"],
        domain_id=p.get("domain_id", "formal"),
        version=p.get("version", "v0.1"),
        status=ClosureStatus(p.get("status", "UNVERIFIED")),
        role_tags=list(p.get("role_tags") or []),
        source_refs=list(p.get("source_refs") or []),
        certificate_refs=list(p.get("certificate_refs") or []),
        debt_refs=list(p.get("debt_refs") or []),
        authority=Authority(p.get("authority", "NONE")),
        metadata=dict(p.get("metadata") or {}),
    )


def _candidate_from_payload(p: dict[str, Any]) -> CandidateRecord:
    return CandidateRecord(
        candidate_id=p["candidate_id"],
        source_ref=p["source_ref"],
        candidate_type=p["candidate_type"],
        proposed_object=dict(p.get("proposed_object") or {}),
        parser_version=p.get("parser_version", "v0.2"),
        confidence=p.get("confidence"),
        validation_state=p.get("validation_state", "UNVERIFIED"),
    )


def _edge_from_payload(p: dict[str, Any]) -> EdgeRecord:
    return EdgeRecord(
        edge_id=p["edge_id"],
        edge_type=p["edge_type"],
        source_ids=list(p.get("source_ids") or []),
        target_ids=list(p.get("target_ids") or []),
        version=p.get("version", "v0.1"),
        metadata=dict(p.get("metadata") or {}),
    )


def _cert_from_payload(p: dict[str, Any]) -> CertificateRecord:
    return CertificateRecord(
        certificate_id=p["certificate_id"],
        certificate_type=p["certificate_type"],
        subject_ids=list(p.get("subject_ids") or []),
        status=p.get("status", "PENDING"),
        scope=p.get("scope"),
        evidence_refs=list(p.get("evidence_refs") or []),
        verifier_results=list(p.get("verifier_results") or []),
        version=p.get("version", "v0.1"),
    )


def _debt_from_payload(p: dict[str, Any]) -> DebtRecord:
    return DebtRecord(
        debt_id=p["debt_id"],
        debt_type=p["debt_type"],
        subject_id=p["subject_id"],
        status=p.get("status", "OPEN"),
        cause=p.get("cause"),
        discharge_requirements=list(p.get("discharge_requirements") or []),
        dependencies=list(p.get("dependencies") or []),
        version=p.get("version", "v0.1"),
    )


def _review_from_payload(p: dict[str, Any]) -> ReviewRecord:
    return ReviewRecord(
        review_id=p["review_id"],
        candidate_id=p["candidate_id"],
        decision=p["decision"],
        reviewer_type=p["reviewer_type"],
        reason=p.get("reason", ""),
        scope=p.get("scope"),
        evidence_refs=list(p.get("evidence_refs") or []),
        certificate_refs=list(p.get("certificate_refs") or []),
        target_native_id=p.get("target_native_id"),
        review_version=p.get("review_version", "v0.3"),
        status=p.get("status", "PENDING"),
    )


def _promotion_receipt_from_payload(p: dict[str, Any]) -> PromotionReceipt:
    return PromotionReceipt(
        promotion_id=p["promotion_id"],
        review_id=p["review_id"],
        candidate_id=p["candidate_id"],
        native_object_id=p["native_object_id"],
        promotion_class=p["promotion_class"],
        certificate_refs=list(p.get("certificate_refs") or []),
        debt_refs=list(p.get("debt_refs") or []),
        event_ids=list(p.get("event_ids") or []),
        state_hash_before=p.get("state_hash_before", ""),
        state_hash_after=p.get("state_hash_after", ""),
    )


def _authority_audit_from_payload(p: dict[str, Any]) -> AuthorityAuditRecord:
    return AuthorityAuditRecord(
        audit_id=p["audit_id"],
        subject_id=p["subject_id"],
        subject_kind=p["subject_kind"],
        source_ref=p["source_ref"],
        source_sha256=p["source_sha256"],
        statement=p["statement"],
        scope=p.get("scope", ""),
        assumptions=list(p.get("assumptions") or []),
        certificate_refs=list(p.get("certificate_refs") or []),
        nonclaim_refs=list(p.get("nonclaim_refs") or []),
        verdict=p.get("verdict", "DEFER_OPEN_OBLIGATION"),
        authority_cap=p.get("authority_cap", "AUDIT"),
        reason=p.get("reason", ""),
        reviewer_type=p.get("reviewer_type", "CURATED_V0_4"),
        audit_version=p.get("audit_version", "v0.4"),
        status=p.get("status", "PENDING"),
    )


def _independent_verification_from_payload(p: dict[str, Any]) -> IndependentVerificationRecord:
    return IndependentVerificationRecord(
        verification_id=p["verification_id"], subject_id=p["subject_id"], verifier_id=p["verifier_id"],
        verifier_kind=p["verifier_kind"], verifier_version=p["verifier_version"], statement=p["statement"],
        scope=p["scope"], input_sha256=p["input_sha256"], proof_artifact_sha256=p["proof_artifact_sha256"],
        result=p["result"], limitations=list(p.get("limitations") or []), evidence_refs=list(p.get("evidence_refs") or []),
        verified_at_version=p.get("verified_at_version", "v0.5"),
    )


def _authority_upgrade_from_payload(p: dict[str, Any]) -> AuthorityUpgradeReceipt:
    return AuthorityUpgradeReceipt(
        upgrade_id=p["upgrade_id"], verification_id=p["verification_id"], subject_id=p["subject_id"],
        old_authority=p["old_authority"], new_authority=p["new_authority"], certificate_id=p["certificate_id"],
        event_ids=list(p.get("event_ids") or []), state_hash_before=p.get("state_hash_before", ""),
        state_hash_after=p.get("state_hash_after", ""),
    )


def _formalization_from_payload(p: dict[str, Any]) -> FormalizationRecord:
    return FormalizationRecord(
        formalization_id=p["formalization_id"], subject_id=p["subject_id"], language=p["language"],
        formalization_kind=p["formalization_kind"], status=p["status"], statement=p["statement"], scope=p["scope"],
        assumptions=list(p.get("assumptions") or []), goals=list(p.get("goals") or []),
        dependencies=list(p.get("dependencies") or []), bundle_sha256=p.get("bundle_sha256", ""),
        limitations=list(p.get("limitations") or []), evidence_refs=list(p.get("evidence_refs") or []),
        formalized_at_version=p.get("formalized_at_version", "v0.6"),
    )

def _replication_from_payload(p: dict[str, Any]) -> ReplicationRecord:
    return ReplicationRecord(
        replication_id=p["replication_id"], subject_id=p["subject_id"], replicator_id=p["replicator_id"],
        replicator_kind=p["replicator_kind"], replicator_version=p["replicator_version"],
        implementation_sha256=p["implementation_sha256"], formalization_id=p["formalization_id"],
        input_bundle_sha256=p["input_bundle_sha256"], output_artifact_sha256=p["output_artifact_sha256"],
        result=p["result"], limitations=list(p.get("limitations") or []), evidence_refs=list(p.get("evidence_refs") or []),
        replicated_at_version=p.get("replicated_at_version", "v0.6"),
    )

def _external_anchor_from_payload(p: dict[str, Any]) -> ExternalTheoremAnchorRecord:
    return ExternalTheoremAnchorRecord(
        anchor_id=p["anchor_id"], subject_id=p["subject_id"], citation_key=p["citation_key"], title=p["title"],
        authors=list(p.get("authors") or []), year=int(p["year"]), doi=p["doi"],
        imported_statement=p["imported_statement"], ns_gsm_use=p["ns_gsm_use"], scope=p["scope"],
        source_refs=list(p.get("source_refs") or []), status=p.get("status", "PENDING"),
        limitations=list(p.get("limitations") or []), anchored_at_version=p.get("anchored_at_version", "v0.6"),
    )

def _tier_receipt_from_payload(p: dict[str, Any]) -> AuthorityTierReceipt:
    return AuthorityTierReceipt(
        tier_receipt_id=p["tier_receipt_id"], subject_id=p["subject_id"], tier_type=p["tier_type"],
        source_record_id=p["source_record_id"], certificate_id=p["certificate_id"],
        event_ids=list(p.get("event_ids") or []), state_hash_before=p.get("state_hash_before", ""),
        state_hash_after=p.get("state_hash_after", ""),
    )



def _translation_from_payload(p: dict[str, Any]) -> TranslationCertificateRecord:
    return TranslationCertificateRecord(
        translation_id=p["translation_id"], subject_id=p["subject_id"], formalization_id=p["formalization_id"],
        fir_sha256=p["fir_sha256"], backend=p["backend"], backend_profile_version=p["backend_profile_version"],
        obligation_sha256=p["obligation_sha256"], project_digest_sha256=p["project_digest_sha256"],
        theorem_names=list(p.get("theorem_names") or []), variable_map=dict(p.get("variable_map") or {}),
        assumption_map=dict(p.get("assumption_map") or {}), goal_map=dict(p.get("goal_map") or {}),
        status=p.get("status", "DEFER"), limitations=list(p.get("limitations") or []),
        translation_checker_version=p.get("translation_checker_version", "v0.7"),
        translation_checker_sha256=p.get("translation_checker_sha256", ""), evidence_refs=list(p.get("evidence_refs") or []),
    )

def _obligation_from_payload(p: dict[str, Any]) -> FormalObligationRecord:
    return FormalObligationRecord(
        obligation_id=p["obligation_id"], subject_id=p["subject_id"], formalization_id=p["formalization_id"],
        translation_id=p["translation_id"], backend=p["backend"], obligation_sha256=p["obligation_sha256"],
        project_digest_sha256=p["project_digest_sha256"], theorem_names=list(p.get("theorem_names") or []),
        axiom_policy=dict(p.get("axiom_policy") or {}), assumptions=list(p.get("assumptions") or []),
        limitations=list(p.get("limitations") or []), bridge_manifest_sha256=p.get("bridge_manifest_sha256", ""),
        status=p.get("status", "READY"), evidence_refs=list(p.get("evidence_refs") or []),
    )

def _felra_run_from_payload(p: dict[str, Any]) -> FELRAFormalRunRecord:
    return FELRAFormalRunRecord(
        formal_run_id=p["formal_run_id"], subject_id=p["subject_id"], bridge_id=p["bridge_id"],
        felra_version=p["felra_version"], backend=p["backend"], formal_status=p["formal_status"],
        obligation_sha256=p["obligation_sha256"], checker_version=p["checker_version"],
        checker_executable_sha256=p["checker_executable_sha256"], exit_code=p.get("exit_code"),
        theorems_audited=p.get("theorems_audited"), axioms_seen=list(p.get("axioms_seen") or []),
        assumptions=list(p.get("assumptions") or []), limitations=list(p.get("limitations") or []),
        felra_result_sha256=p.get("felra_result_sha256", ""), felra_certificate_sha256=p.get("felra_certificate_sha256", ""),
        status=p.get("status", "DEFER"), evidence_refs=list(p.get("evidence_refs") or []),
    )

def _kernel_receipt_from_payload(p: dict[str, Any]) -> KernelFormalProofReceipt:
    return KernelFormalProofReceipt(
        formal_proof_receipt_id=p["formal_proof_receipt_id"], subject_id=p["subject_id"], backend=p["backend"],
        translation_id=p["translation_id"], formal_run_id=p["formal_run_id"], certificate_id=p["certificate_id"],
        obligation_sha256=p["obligation_sha256"], checker_executable_sha256=p["checker_executable_sha256"],
        axiom_policy_digest=p["axiom_policy_digest"], event_ids=list(p.get("event_ids") or []),
        state_hash_before=p.get("state_hash_before", ""), state_hash_after=p.get("state_hash_after", ""),
    )

def apply_event(state: NativeState, event: LedgerEvent) -> None:
    p = event.payload
    if event.event_type == "REGISTER_OBJECT":
        obj = _object_from_payload(p)
        if obj.object_id in state.objects:
            raise ValidationError(f"duplicate object id: {obj.object_id}")
        state.objects[obj.object_id] = obj
    elif event.event_type == "REGISTER_CANDIDATE":
        candidate = _candidate_from_payload(p)
        if candidate.candidate_id in state.candidates:
            raise ValidationError(f"duplicate candidate id: {candidate.candidate_id}")
        state.candidates[candidate.candidate_id] = candidate
    elif event.event_type == "REGISTER_REVIEW":
        review = _review_from_payload(p)
        if review.review_id in state.reviews:
            raise ValidationError(f"duplicate review id: {review.review_id}")
        state.reviews[review.review_id] = review
    elif event.event_type == "UPDATE_REVIEW_STATUS":
        review_id = p["review_id"]
        if review_id not in state.reviews:
            raise UnknownObjectError(review_id)
        state.reviews[review_id].status = p["status"]
    elif event.event_type == "REGISTER_PROMOTION_RECEIPT":
        receipt = _promotion_receipt_from_payload(p)
        if receipt.promotion_id in state.promotion_receipts:
            raise ValidationError(f"duplicate promotion id: {receipt.promotion_id}")
        state.promotion_receipts[receipt.promotion_id] = receipt
    elif event.event_type == "REGISTER_AUTHORITY_AUDIT":
        audit = _authority_audit_from_payload(p)
        if audit.audit_id in state.authority_audits:
            raise ValidationError(f"duplicate authority audit id: {audit.audit_id}")
        state.authority_audits[audit.audit_id] = audit
    elif event.event_type == "REGISTER_INDEPENDENT_VERIFICATION":
        record = _independent_verification_from_payload(p)
        if record.verification_id in state.independent_verifications:
            raise ValidationError(f"duplicate verification id: {record.verification_id}")
        state.independent_verifications[record.verification_id] = record
    elif event.event_type == "REGISTER_AUTHORITY_UPGRADE":
        receipt = _authority_upgrade_from_payload(p)
        if receipt.upgrade_id in state.authority_upgrade_receipts:
            raise ValidationError(f"duplicate authority upgrade id: {receipt.upgrade_id}")
        state.authority_upgrade_receipts[receipt.upgrade_id] = receipt
    elif event.event_type == "SET_AUTHORITY":
        object_id = p["object_id"]
        if object_id not in state.objects:
            raise UnknownObjectError(object_id)
        state.objects[object_id].authority = Authority(p["authority"])
        cert_id = p.get("certificate_id")
        if cert_id and cert_id not in state.objects[object_id].certificate_refs:
            state.objects[object_id].certificate_refs.append(cert_id)
    elif event.event_type == "REGISTER_FORMALIZATION":
        record = _formalization_from_payload(p)
        if record.formalization_id in state.formalizations:
            raise ValidationError(f"duplicate formalization id: {record.formalization_id}")
        state.formalizations[record.formalization_id] = record
    elif event.event_type == "REGISTER_REPLICATION":
        record = _replication_from_payload(p)
        if record.replication_id in state.replications:
            raise ValidationError(f"duplicate replication id: {record.replication_id}")
        state.replications[record.replication_id] = record
    elif event.event_type == "REGISTER_EXTERNAL_THEOREM_ANCHOR":
        record = _external_anchor_from_payload(p)
        if record.anchor_id in state.external_theorem_anchors:
            raise ValidationError(f"duplicate external theorem anchor id: {record.anchor_id}")
        state.external_theorem_anchors[record.anchor_id] = record
    elif event.event_type == "ADD_AUTHORITY_TIER":
        object_id = p["object_id"]
        if object_id not in state.objects:
            raise UnknownObjectError(object_id)
        tiers = sorted(set(list(state.objects[object_id].metadata.get("authority_tiers") or []) + [p["tier_type"]]))
        state.objects[object_id].metadata["authority_tiers"] = tiers
        cert_id = p.get("certificate_id")
        if cert_id and cert_id not in state.objects[object_id].certificate_refs:
            state.objects[object_id].certificate_refs.append(cert_id)
    elif event.event_type == "REGISTER_AUTHORITY_TIER_RECEIPT":
        receipt = _tier_receipt_from_payload(p)
        if receipt.tier_receipt_id in state.authority_tier_receipts:
            raise ValidationError(f"duplicate authority tier receipt id: {receipt.tier_receipt_id}")
        state.authority_tier_receipts[receipt.tier_receipt_id] = receipt
    elif event.event_type == "REGISTER_TRANSLATION_CERTIFICATE":
        record = _translation_from_payload(p)
        if record.translation_id in state.translation_certificates: raise ValidationError(f"duplicate translation id: {record.translation_id}")
        state.translation_certificates[record.translation_id] = record
    elif event.event_type == "REGISTER_FORMAL_OBLIGATION":
        record = _obligation_from_payload(p)
        if record.obligation_id in state.formal_obligations: raise ValidationError(f"duplicate obligation id: {record.obligation_id}")
        state.formal_obligations[record.obligation_id] = record
    elif event.event_type == "REGISTER_FELRA_FORMAL_RUN":
        record = _felra_run_from_payload(p)
        if record.formal_run_id in state.felra_formal_runs: raise ValidationError(f"duplicate formal run id: {record.formal_run_id}")
        state.felra_formal_runs[record.formal_run_id] = record
    elif event.event_type == "REGISTER_KERNEL_FORMAL_PROOF_RECEIPT":
        record = _kernel_receipt_from_payload(p)
        if record.formal_proof_receipt_id in state.kernel_formal_proof_receipts: raise ValidationError(f"duplicate formal proof receipt id: {record.formal_proof_receipt_id}")
        state.kernel_formal_proof_receipts[record.formal_proof_receipt_id] = record
    elif event.event_type == "REGISTER_CERTIFICATE":
        cert = _cert_from_payload(p)
        if cert.certificate_id in state.certificates:
            raise ValidationError(f"duplicate certificate id: {cert.certificate_id}")
        state.certificates[cert.certificate_id] = cert
    elif event.event_type == "REGISTER_DEBT":
        debt = _debt_from_payload(p)
        if debt.debt_id in state.debts:
            raise ValidationError(f"duplicate debt id: {debt.debt_id}")
        state.debts[debt.debt_id] = debt
        if debt.subject_id in state.objects:
            obj = state.objects[debt.subject_id]
            if debt.debt_id not in obj.debt_refs:
                obj.debt_refs.append(debt.debt_id)
    elif event.event_type == "ADD_EDGE":
        edge = _edge_from_payload(p)
        if edge.edge_id in state.edges:
            raise ValidationError(f"duplicate edge id: {edge.edge_id}")
        for object_id in edge.source_ids + edge.target_ids:
            if object_id not in state.objects:
                raise UnknownObjectError(object_id)
        state.edges[edge.edge_id] = edge
    elif event.event_type == "SET_STATUS":
        object_id = p["object_id"]
        if object_id not in state.objects:
            raise UnknownObjectError(object_id)
        old = state.objects[object_id].status
        new = ClosureStatus(p["status"])
        state.objects[object_id].status = new
        state.status_history.append({
            "object_id": object_id,
            "old_status": old.value,
            "new_status": new.value,
            "cause": p.get("cause"),
            "event_id": event.event_id,
            "version": state.version,
        })
    elif event.event_type == "DISCHARGE_DEBT":
        debt_id = p["debt_id"]
        if debt_id not in state.debts:
            raise UnknownObjectError(debt_id)
        state.debts[debt_id].status = "DISCHARGED"
    elif event.event_type == "SET_FRONTIER":
        ids = list(p.get("frontier_ids") or [])
        for object_id in ids:
            if object_id not in state.objects:
                raise UnknownObjectError(object_id)
        state.frontier_ids = ids
    elif event.event_type == "SCOPE_REVISION":
        source_id = p["source_object_id"]
        target_id = p["target_object_id"]
        if source_id not in state.objects:
            raise UnknownObjectError(source_id)
        if target_id not in state.objects:
            raise UnknownObjectError(target_id)
        state.status_history.append({
            "event_type": "SCOPE_REVISION",
            "source_object_id": source_id,
            "target_object_id": target_id,
            "preserves_source_status": bool(p.get("preserves_source_status", True)),
            "invalidates_promotion": p.get("invalidates_promotion"),
            "cause": p.get("cause"),
            "event_id": event.event_id,
            "version": state.version,
        })
    elif event.event_type == "CORPUS_CHECKPOINT":
        checkpoint_id = p["checkpoint_id"]
        state.ingestion_checkpoints[checkpoint_id] = dict(p)
    elif event.event_type == "NOTE":
        pass
    else:
        raise ValidationError(f"unsupported event type: {event.event_type}")
    state.ledger_head = event.sequence
