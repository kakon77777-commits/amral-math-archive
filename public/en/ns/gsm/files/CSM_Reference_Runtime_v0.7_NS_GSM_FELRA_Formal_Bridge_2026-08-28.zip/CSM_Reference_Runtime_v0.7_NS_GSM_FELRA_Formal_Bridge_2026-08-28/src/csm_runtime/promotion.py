from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib

from .enums import Authority, ClosureStatus
from .errors import AuthorityError, IllegalTransitionError
from .model import CandidateRecord, NativeState, ObjectRecord, ReviewRecord
from .candidate_validation import ValidationClass, validate_promotion_against_nonclaims
from .operators import certificate_authorizes, close_positive


class GateOutcome(str, Enum):
    ALLOW_STRUCTURAL = "ALLOW_STRUCTURAL"
    ALLOW_PROOF_CARRYING = "ALLOW_PROOF_CARRYING"
    DEFER = "DEFER"
    REFUSE = "REFUSE"


@dataclass(frozen=True)
class GateDecision:
    outcome: GateOutcome
    reason: str


_EXPECTED_STRUCTURAL: dict[str, str] = {
    "NonclaimCandidate": "PROMOTE_NONCLAIM",
    "FrontierCandidate": "PROMOTE_FRONTIER",
    "NextFrontierCandidate": "PROMOTE_FRONTIER",
    "SurvivorCandidate": "PROMOTE_SURVIVOR",
    "ObstructionCandidate": "PROMOTE_OBSTRUCTION",
}


class PromotionGate:
    def evaluate(self, state: NativeState, candidate: CandidateRecord, review: ReviewRecord) -> GateDecision:
        if review.candidate_id != candidate.candidate_id:
            return GateDecision(GateOutcome.REFUSE, "Review candidate identity mismatch.")
        if review.status != "APPROVED":
            return GateDecision(GateOutcome.REFUSE, "Review is not approved.")
        expected = _EXPECTED_STRUCTURAL.get(candidate.candidate_type)
        if expected is not None:
            if review.decision != expected:
                return GateDecision(GateOutcome.REFUSE, f"Review decision {review.decision} does not match {candidate.candidate_type}.")
            return GateDecision(GateOutcome.ALLOW_STRUCTURAL, "Reviewed structural promotion is allowed without theorem authority.")
        if candidate.candidate_type in {"TheoremCandidate", "StatusCandidate"}:
            return GateDecision(GateOutcome.DEFER, "Theorem-bearing candidate requires proof-authority review.")
        return GateDecision(GateOutcome.DEFER, "Candidate class is not promotable by the structural gate.")

    def evaluate_proof(
        self,
        state: NativeState,
        candidate: CandidateRecord,
        review: ReviewRecord,
        certificate_id: str | None,
    ) -> GateDecision:
        if review.candidate_id != candidate.candidate_id:
            return GateDecision(GateOutcome.REFUSE, "Review candidate identity mismatch.")
        if review.status != "APPROVED":
            return GateDecision(GateOutcome.REFUSE, "Review is not approved.")
        if review.decision != "PROMOTE_PROOF_ASSET":
            return GateDecision(GateOutcome.DEFER, "Review does not request proof-asset promotion.")
        if candidate.candidate_type not in {"TheoremCandidate", "StatusCandidate"}:
            return GateDecision(GateOutcome.REFUSE, "Candidate type is not proof-bearing.")
        if not certificate_id:
            return GateDecision(GateOutcome.DEFER, "Accepted proof certificate is required.")
        target_id = review.target_native_id or _native_id(candidate, "PROOF_ASSET")
        try:
            cert = certificate_authorizes(state, certificate_id, "ClosePositive", target_id)
        except AuthorityError as exc:
            return GateDecision(GateOutcome.REFUSE, str(exc))
        if cert.scope and review.scope and cert.scope != review.scope:
            return GateDecision(GateOutcome.REFUSE, "Certificate scope does not match reviewed scope.")
        return GateDecision(GateOutcome.ALLOW_PROOF_CARRYING, "Proof certificate and reviewed scope authorize bounded promotion.")


def _statement(candidate: CandidateRecord) -> str:
    return str((candidate.proposed_object or {}).get("statement") or "")


def _series(candidate: CandidateRecord) -> str | None:
    meta = (candidate.proposed_object or {}).get("metadata") or {}
    value = meta.get("series")
    return str(value) if value is not None else None


def _native_id(candidate: CandidateRecord, kind: str) -> str:
    digest = hashlib.sha256(f"{candidate.candidate_id}|{kind}".encode("utf-8")).hexdigest()[:24]
    return f"reviewed:{kind.lower()}:{digest}"


def _promote_structural(
    state: NativeState,
    candidate: CandidateRecord,
    review: ReviewRecord,
    *,
    kind: str,
    role_tags: list[str],
    authority: Authority,
) -> ObjectRecord:
    gate = PromotionGate().evaluate(state, candidate, review)
    if gate.outcome is not GateOutcome.ALLOW_STRUCTURAL:
        raise AuthorityError(gate.reason)
    object_id = review.target_native_id or _native_id(candidate, kind)
    if object_id in state.objects:
        raise IllegalTransitionError(f"duplicate promoted object id: {object_id}")
    obj = ObjectRecord(
        object_id=object_id,
        object_type=kind,
        domain_id="formal",
        version=state.version,
        status=ClosureStatus.OPEN,
        role_tags=list(role_tags),
        source_refs=[candidate.source_ref],
        authority=authority,
        metadata={
            "candidate_id": candidate.candidate_id,
            "review_id": review.review_id,
            "statement": _statement(candidate),
            "series": _series(candidate),
            "source_layer": "reviewed-candidate",
            "structural_only": True,
        },
    )
    state.objects[object_id] = obj
    review.target_native_id = object_id
    return obj


def promote_nonclaim(state: NativeState, candidate: CandidateRecord, review: ReviewRecord) -> ObjectRecord:
    return _promote_structural(
        state,
        candidate,
        review,
        kind="NONCLAIM",
        role_tags=["AUTHORITY_BOUNDARY"],
        authority=Authority.AUDIT,
    )


def promote_frontier(state: NativeState, candidate: CandidateRecord, review: ReviewRecord) -> ObjectRecord:
    return _promote_structural(
        state,
        candidate,
        review,
        kind="FRONTIER",
        role_tags=["FRONTIER"],
        authority=Authority.RESEARCH,
    )


def promote_survivor(state: NativeState, candidate: CandidateRecord, review: ReviewRecord) -> ObjectRecord:
    return _promote_structural(
        state,
        candidate,
        review,
        kind="SURVIVOR",
        role_tags=["SURVIVOR"],
        authority=Authority.RESEARCH,
    )


def promote_obstruction(state: NativeState, candidate: CandidateRecord, review: ReviewRecord) -> ObjectRecord:
    return _promote_structural(
        state,
        candidate,
        review,
        kind="OBSTRUCTION",
        role_tags=["OBSTRUCTION", "STRUCTURAL_ONLY"],
        authority=Authority.RESEARCH,
    )


def promote_proof_asset(
    state: NativeState,
    candidate: CandidateRecord,
    review: ReviewRecord,
    certificate_id: str,
    *,
    nonclaim_statements: list[str] | None = None,
) -> ObjectRecord:
    if nonclaim_statements:
        nonclaim_check = validate_promotion_against_nonclaims(_statement(candidate), nonclaim_statements)
        if nonclaim_check.validation_class is ValidationClass.REJECTED:
            raise AuthorityError(nonclaim_check.reason)

    gate = PromotionGate().evaluate_proof(state, candidate, review, certificate_id)
    if gate.outcome is not GateOutcome.ALLOW_PROOF_CARRYING:
        raise AuthorityError(gate.reason)

    object_id = review.target_native_id or _native_id(candidate, "PROOF_ASSET")
    if object_id in state.objects:
        raise IllegalTransitionError(f"duplicate promoted object id: {object_id}")
    cert = certificate_authorizes(state, certificate_id, "ClosePositive", object_id)
    authority = Authority.PROOF if cert.status == "VALID" else Authority.AUDIT
    obj = ObjectRecord(
        object_id=object_id,
        object_type="PROOF_ASSET",
        domain_id="formal",
        version=state.version,
        status=ClosureStatus.OPEN,
        role_tags=["PROOF_ASSET"],
        source_refs=[candidate.source_ref],
        certificate_refs=[],
        authority=authority,
        metadata={
            "candidate_id": candidate.candidate_id,
            "review_id": review.review_id,
            "statement": _statement(candidate),
            "series": _series(candidate),
            "source_layer": "reviewed-candidate",
            "reviewed_scope": review.scope,
        },
    )
    state.objects[object_id] = obj
    try:
        close_positive(state, object_id, certificate_id)
    except Exception:
        state.objects.pop(object_id, None)
        raise
    review.target_native_id = object_id
    return obj
