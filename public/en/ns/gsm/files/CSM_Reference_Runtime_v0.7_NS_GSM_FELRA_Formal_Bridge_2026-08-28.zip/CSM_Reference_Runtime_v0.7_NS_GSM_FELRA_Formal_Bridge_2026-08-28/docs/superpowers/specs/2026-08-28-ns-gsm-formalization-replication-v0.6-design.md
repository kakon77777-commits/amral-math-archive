# NS_GSM v0.6 — Formalization / Cross-Implementation Replication Design

**Date:** 2026-08-28  
**Status:** Approved architectural design  
**Baseline:** CSM Reference Runtime / NS_GSM v0.5  
**Baseline proof-authority assets:** 12  
**Runtime target:** 0.6.0

## 1. Goal

v0.6 strengthens the provenance and verification structure of the twelve v0.5 `PROOF`-authority assets without conflating stronger evidence with parent theorem closure.

The runtime must represent stronger evidence as **orthogonal typed tiers**, not as a single scalar authority ladder.

## 2. Non-Collapse Rules

```text
PROOF != FORMAL_PROOF
PROOF != CROSS_IMPLEMENTATION_REPLICATED
FORMALIZED_CORE_ONLY != FORMAL_PROOF
EXTERNAL_THEOREM_ANCHORED != theorem re-proof
replicated asset != parent claim closure
```

The root formal Navier–Stokes target, C1, and C2 remain `OPEN` unless independently changed by their own proof-carrying closure transactions.

## 3. v0.6 Authority Tiers

### 3.1 `FORMALIZED_CORE_ONLY`

The asset has a deterministic machine-readable formalization bundle in `NSGSM-FIR/0.1`.

This tier means the bounded statement, scope, assumptions, variables, goal and derivation schema have been normalized into a formal intermediate representation.

It does **not** mean a proof assistant kernel accepted the theorem.

### 3.2 `CROSS_IMPLEMENTATION_REPLICATED`

A second implementation, executed in an isolated subprocess and forbidden from importing `csm_runtime`, independently reconstructs the bounded result from the formalization bundle.

The replication implementation has its own source hash and produces a content-addressed output artifact.

This tier is independent at the implementation level, not external peer review.

### 3.3 `EXTERNAL_THEOREM_ANCHORED`

An external theorem dependency has an explicit bibliographic record: title, authors, year, DOI/identifier, imported statement, NS_GSM use and limitations.

Bibliographic/theorem anchoring does not re-prove the external theorem and does not automatically upgrade an asset to `PROOF`.

### 3.4 `FORMAL_PROOF`

Reserved for a proof object accepted by a named proof-assistant/kernel or equivalently strong checked formal system.

Current execution environment has no Lean or Coq executable. Therefore v0.6 release invariant:

```text
FORMAL_PROOF count = 0
```

Attempting to attach `FORMAL_PROOF` without a kernel-checked certificate must fail closed.

## 4. New Canonical Records

### `FormalizationRecord`

Fields:

- `formalization_id`
- `subject_id`
- `language = NSGSM-FIR/0.1`
- `formalization_kind`
- `status`
- `statement`
- `scope`
- `assumptions`
- `goals`
- `dependencies`
- `bundle_sha256`
- `limitations`
- `evidence_refs`
- `formalized_at_version`

### `ReplicationRecord`

Fields:

- `replication_id`
- `subject_id`
- `replicator_id`
- `replicator_kind = CROSS_IMPLEMENTATION`
- `replicator_version`
- `implementation_sha256`
- `formalization_id`
- `input_bundle_sha256`
- `output_artifact_sha256`
- `result`
- `limitations`
- `evidence_refs`
- `replicated_at_version`

### `ExternalTheoremAnchorRecord`

Fields:

- `anchor_id`
- `subject_id`
- `citation_key`
- `title`
- `authors`
- `year`
- `doi`
- `imported_statement`
- `ns_gsm_use`
- `scope`
- `source_refs`
- `status`
- `limitations`
- `anchored_at_version`

### `AuthorityTierReceipt`

Fields:

- `tier_receipt_id`
- `subject_id`
- `tier_type`
- `source_record_id`
- `certificate_id`
- `event_ids`
- `state_hash_before`
- `state_hash_after`

## 5. State and Event Semantics

`NativeState` gains registries for formalizations, replications, external theorem anchors, and authority-tier receipts.

New events:

```text
REGISTER_FORMALIZATION
REGISTER_REPLICATION
REGISTER_EXTERNAL_THEOREM_ANCHOR
ADD_AUTHORITY_TIER
REGISTER_AUTHORITY_TIER_RECEIPT
```

`ADD_AUTHORITY_TIER` mutates only `object.metadata.authority_tiers` and certificate references. It must not mutate:

- base `Authority` enum value;
- `ClosureStatus`;
- parent/child objects;
- graph edges.

## 6. Formal Intermediate Representation

`NSGSM-FIR/0.1` bundle:

```json
{
  "language": "NSGSM-FIR/0.1",
  "subject_id": "...",
  "statement": "...",
  "scope": "...",
  "assumptions": [],
  "variables": [],
  "goals": [],
  "derivation_kind": "...",
  "normalized_claim": {},
  "dependencies": [],
  "limitations": []
}
```

Canonical JSON bytes are hashed with SHA-256.

### Expected formalization classes

- D103.1–D103.5: algebraic core complete;
- D105.1–D105.3: algebraic/exact-witness core complete;
- D105.4: analytic bound schema complete, no measure-theory kernel proof;
- RFP-12.1: quadratic minimization core complete;
- RFP-12.19.1: counterexample/witness core complete;
- RFP-05.32.1: graph-theorem schema complete, no proof-assistant kernel proof.

All twelve may receive `FORMALIZED_CORE_ONLY`; per-record status/limitations preserve the distinction between core-complete and schema-complete.

## 7. Independent Replicator Architecture

One standalone script lives under `replicators/` and is executed as:

```text
python -I replicators/ns_gsm_replica_v06.py --case <case-id> --bundle <bundle.json>
```

Constraints:

- no import from `csm_runtime`;
- no import from original v0.5 verifier modules;
- deterministic output;
- source implementation SHA-256 recorded;
- input bundle SHA-256 checked;
- result output content-addressed;
- execution from an isolated working directory;
- no network access required.

Replication status values:

```text
MATCH
MISMATCH
DEFER
```

A mismatch or crash never removes the original v0.5 PROOF authority; it records replication failure/debt and attaches no replication tier.

## 8. Replication Cases

The v0.6 cross-implementation suite covers the twelve v0.5 PROOF assets:

- D103.1 commutator equation;
- D103.2 shear resonance;
- D103.3 single-shear degeneracy;
- D103.4 five-ray spectrum;
- D103.5 Riesz-loaded coaxial response;
- D105.1 simple-shear Riesz derivative scalar;
- D105.2 local Kelvin/TR witness;
- D105.3 exact viscosity residual;
- D105.4 fixed-band viscosity matching schema;
- RFP-05 Theorem 32.1 infinite-path extraction schema;
- RFP-12 Theorem 12.1 spectral-variance identity;
- RFP-12 Theorem 19.1 frequency-norm synchronization no-go witness.

Replication must not rely on the v0.5 `VerificationResult` artifact as an answer key. It compares its independently computed normalized result with the `NSGSM-FIR` goal/claim.

## 9. External Theorem Anchor

v0.6 adds a theorem-anchor record for ETN-X Proposition 8.1's critical-L3 dependency:

- Luis Escauriaza;
- Gregory/Grigorii Seregin;
- Vladimir Šverák;
- *L_{3,∞}-solutions of the Navier-Stokes equations and backward uniqueness*;
- Russian Mathematical Surveys 58(2), 211–250 (2003);
- DOI `10.1070/RM2003v058n02ABEH000609`.

The source abstract states that the `L_{3,∞}` solutions of the 3D Navier–Stokes Cauchy problem are smooth.

NS_GSM use: theorem dependency anchor for the critical-L3 boundedness criterion used in the UV-escape reduction.

Limitation: v0.6 verifies the bibliographic/theorem anchor identity, not the proof of the Escauriaza–Seregin–Šverák theorem. Therefore `claim:uv-escape-necessity` does not automatically move from `AUDIT` to `PROOF` in v0.6.

## 10. Tier Attachment Rules

A tier certificate must be typed.

### Formalization tier

Requires a valid canonical bundle hash and a `FormalizationRecord` with status `CORE_COMPLETE` or `SCHEMA_COMPLETE`.

### Replication tier

Requires:

- matching subject;
- matching bundle hash;
- matching replicator source hash;
- subprocess exit 0;
- `ReplicationRecord.result = MATCH`.

### External theorem anchor tier

Requires bibliographic identity fields and nonempty limitation declaring that anchoring is not theorem re-proof.

### Formal proof tier

Requires:

- `kernel_checked = true`;
- named kernel/tool;
- checked proof-object SHA-256;
- valid certificate type `KERNEL_FORMAL_PROOF`.

No other certificate can attach this tier.

## 11. Query Surface

Add read-only queries:

```text
formalizations
replications
external-theorem-anchors
authority-tiers
formal-proof-assets
replicated-assets
```

Every result remains scoped and source-layer tagged.

## 12. v0.6 Release Evidence

Generate:

- `formalizations_v06.json`
- `replications_v06.json`
- `external_anchors_v06.json`
- `authority_tiers_v06.json`
- `formal_proof_assets_v06.json`
- `replicated_assets_v06.json`
- `native_snapshot_v06.json`
- `ns_gsm_v06_ledger.jsonl`
- `replay_report_v06.json`
- `conformance_report_v06.json`
- `run_summary_v06.json`

## 13. Release Invariants

At release:

1. all twelve v0.5 PROOF assets still have base authority `PROOF`;
2. all twelve have formalization records;
3. all twelve are attempted through the independent replicator;
4. only `MATCH` records receive `CROSS_IMPLEMENTATION_REPLICATED`;
5. no asset receives `FORMAL_PROOF` without a kernel checker;
6. v0.6 `FORMAL_PROOF` count is zero in the current environment;
7. ETN-X Prop 8.1 gets an external theorem anchor but no automatic PROOF upgrade;
8. root formal NS, C1, and C2 remain OPEN;
9. canonical state is evidence-location independent;
10. full ledger replay exactly reproduces the native state hash.

## 14. Explicit Non-Goals

v0.6 does not:

- install Lean/Coq from the network;
- claim SymPy is a proof-assistant kernel;
- claim cross-implementation replication is peer review;
- re-prove the Escauriaza–Seregin–Šverák theorem;
- propagate asset tiers to parent claims;
- modify C1/C2;
- claim Navier–Stokes regularity.
