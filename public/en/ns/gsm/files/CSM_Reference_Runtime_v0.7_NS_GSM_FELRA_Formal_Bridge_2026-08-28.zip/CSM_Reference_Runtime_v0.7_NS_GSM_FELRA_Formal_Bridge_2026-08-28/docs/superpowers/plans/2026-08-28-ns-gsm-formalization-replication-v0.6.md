# NS_GSM v0.6 Formalization / Replication Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add typed formalization, cross-implementation replication, and external-theorem-anchor evidence to the twelve v0.5 `PROOF` assets without changing root Navier–Stokes closure status.

**Architecture:** Extend `NativeState` with replayable formalization/replication/anchor/tier records. Generate `NSGSM-FIR/0.1` bundles for all twelve proof assets, execute a standalone `python -I` replicator that cannot import `csm_runtime`, attach orthogonal authority tiers through atomic transactions, and preserve `FORMAL_PROOF=0` because no Lean/Coq kernel is available.

**Tech Stack:** Python 3.11+, standard library, PyYAML, SymPy 1.14, pytest.

**Spec:** `docs/superpowers/specs/2026-08-28-ns-gsm-formalization-replication-v0.6-design.md`

## Global Constraints

- Do not change the base `Authority` enum beyond `PROOF`.
- Authority tiers live in typed records and `object.metadata.authority_tiers`.
- Tier attachment must not change `ClosureStatus`.
- No tier may propagate to parent/child graph nodes.
- `FORMAL_PROOF` requires a kernel-checked certificate and must be zero in the v0.6 release environment.
- Cross-implementation replicators must run in isolated subprocesses and must not import `csm_runtime` or v0.5 verifier modules.
- Evidence identity is content-addressed and location-independent.
- Root formal NS, C1, and C2 remain OPEN.

---

### Task 1: Canonical tier records and replay

**Files:**
- Modify: `src/csm_runtime/model.py`
- Modify: `src/csm_runtime/state.py`
- Test: `tests/test_v06_tier_model.py`

**Interfaces:**
- Produces: `FormalizationRecord`, `ReplicationRecord`, `ExternalTheoremAnchorRecord`, `AuthorityTierReceipt` and `NativeState` registries.

- [ ] **Step 1: Write failing round-trip/replay tests**

```python
def test_v06_tier_records_round_trip_and_replay():
    state = NativeState()
    # add one record of each new type through ledger events
    # assert native_state_from_dict(state.to_dict()).to_dict() == state.to_dict()
    # assert replay hash is identical
```

- [ ] **Step 2: Run focused test and confirm RED**

Run: `pytest -q tests/test_v06_tier_model.py`

Expected: import failure for missing v0.6 record classes.

- [ ] **Step 3: Implement dataclasses, serializers, state loaders, and event reducers**

Add events:

```text
REGISTER_FORMALIZATION
REGISTER_REPLICATION
REGISTER_EXTERNAL_THEOREM_ANCHOR
ADD_AUTHORITY_TIER
REGISTER_AUTHORITY_TIER_RECEIPT
```

`ADD_AUTHORITY_TIER` must only mutate sorted unique `metadata["authority_tiers"]` and optional certificate refs.

- [ ] **Step 4: Run focused + canonical/replay tests**

Run: `pytest -q tests/test_v06_tier_model.py tests/test_canonical.py tests/test_replay.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/model.py src/csm_runtime/state.py tests/test_v06_tier_model.py
git commit -m "feat: add replayable v0.6 authority tier records"
```

### Task 2: NSGSM-FIR formalization bundles

**Files:**
- Create: `src/csm_runtime/formalization.py`
- Test: `tests/test_v06_formalization.py`

**Interfaces:**
- Produces: `build_formalization_bundle(state, subject_id)`, `formalization_bundle_sha256(bundle)`, `formalization_record_for_asset(...)`.

- [ ] **Step 1: Write failing tests for all twelve v0.5 PROOF assets**

Tests assert:

```text
12 bundles
language = NSGSM-FIR/0.1
subject/scope/assumptions copied from native asset
content-addressed hash stable across output directories
D103.1-5 status CORE_COMPLETE
D105.1-3 status CORE_COMPLETE
D105.4 status SCHEMA_COMPLETE
RFP12.12.1 / RFP12.19.1 status CORE_COMPLETE or WITNESS_COMPLETE
RFP05.32.1 status SCHEMA_COMPLETE
```

- [ ] **Step 2: Run and confirm RED**

Run: `pytest -q tests/test_v06_formalization.py`

- [ ] **Step 3: Implement deterministic bundle builders**

Bundle contains statement, reviewed scope, assumptions, variables, goals, derivation kind, normalized claim, dependencies, limitations. No proof-assistant claim is emitted.

- [ ] **Step 4: Verify GREEN**

Run: `pytest -q tests/test_v06_formalization.py tests/test_v05_run.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/formalization.py tests/test_v06_formalization.py
git commit -m "feat: compile NS_GSM proof assets to FIR bundles"
```

### Task 3: Standalone cross-implementation replicator

**Files:**
- Create: `replicators/ns_gsm_replica_v06.py`
- Create: `src/csm_runtime/replication.py`
- Test: `tests/test_v06_replication.py`

**Interfaces:**
- Produces: `run_replication(bundle, case_id, script_path, evidence_dir) -> ReplicationRecord`.

- [ ] **Step 1: Write failing isolation tests**

Tests assert:

```text
replicator source contains no "csm_runtime" import
runner uses python -I
replicator source SHA-256 is recorded
output is content-addressed
same bundle in two evidence directories yields same replication record/state identity
```

- [ ] **Step 2: Write failing mathematical replication tests for all twelve cases**

Case IDs:

```text
d103.1 d103.2 d103.3 d103.4 d103.5
d105.1 d105.2 d105.3 d105.4
rfp05.32.1 rfp12.12.1 rfp12.19.1
```

Expected result for release corpus: `MATCH` for every case, with limitations retained for schema-level replications.

- [ ] **Step 3: Run and confirm RED**

Run: `pytest -q tests/test_v06_replication.py`

- [ ] **Step 4: Implement standalone formulas independently**

The standalone script imports only stdlib/SymPy. It does not import runtime modules or original verifier modules. It reads the FIR bundle JSON and emits deterministic JSON with observed normalized claim and checks.

- [ ] **Step 5: Implement isolated subprocess runner and comparison gate**

The runner checks script hash, bundle hash, exit code, output schema, subject/case identity, and expected normalized claim.

- [ ] **Step 6: Verify GREEN**

Run: `pytest -q tests/test_v06_replication.py tests/test_v05_d103_symbolic.py tests/test_v05_d105_verifiers.py tests/test_v05_rfp_etnx.py`

- [ ] **Step 7: Commit**

```bash
git add replicators/ns_gsm_replica_v06.py src/csm_runtime/replication.py tests/test_v06_replication.py
git commit -m "feat: add isolated cross-implementation replication"
```

### Task 4: Authority-tier transaction gate

**Files:**
- Create: `src/csm_runtime/tier_batch.py`
- Test: `tests/test_v06_tier_gate.py`

**Interfaces:**
- Produces: `commit_formalization_replication_tiers(...)` and `attach_formal_proof_tier(...)`.

- [ ] **Step 1: Write failing atomicity/firewall tests**

Assert:

```text
formalization tier requires valid bundle record
replication tier requires ReplicationRecord.result == MATCH
base authority remains PROOF
closure status unchanged
parent objects unchanged
FORMAL_PROOF without KERNEL_FORMAL_PROOF certificate raises AuthorityError
failed batch leaves state/ledger unchanged
same batch ID is idempotent no-op
```

- [ ] **Step 2: Run and confirm RED**

Run: `pytest -q tests/test_v06_tier_gate.py`

- [ ] **Step 3: Implement atomic transaction and typed certificates**

Certificates:

```text
FORMALIZATION_BUNDLE
CROSS_IMPLEMENTATION_REPLICATION
EXTERNAL_THEOREM_ANCHOR
KERNEL_FORMAL_PROOF
```

Only the last can authorize `FORMAL_PROOF`, and it requires `kernel_checked=true`, tool name, and proof object hash.

- [ ] **Step 4: Verify GREEN**

Run: `pytest -q tests/test_v06_tier_gate.py tests/test_v05_upgrade_batch.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/tier_batch.py tests/test_v06_tier_gate.py
git commit -m "feat: enforce typed v0.6 authority tier gates"
```

### Task 5: External theorem anchor for ETN-X Prop 8.1

**Files:**
- Create: `external_theorem_anchors_v0.6.yaml`
- Create: `src/csm_runtime/external_anchor.py`
- Test: `tests/test_v06_external_anchor.py`

**Interfaces:**
- Produces: `load_external_anchor_manifest()`, `verify_external_anchor_record()`, `commit_external_anchor()`.

- [ ] **Step 1: Write failing anchor tests**

The manifest must contain DOI `10.1070/RM2003v058n02ABEH000609`, authors Escauriaza/Seregin/Šverák, year 2003, subject `claim:uv-escape-necessity`, imported statement, NS_GSM use, and a limitation saying bibliographic anchoring does not re-prove the theorem.

- [ ] **Step 2: Run and confirm RED**

Run: `pytest -q tests/test_v06_external_anchor.py`

- [ ] **Step 3: Implement manifest loader/validator and anchor commit**

Attach `EXTERNAL_THEOREM_ANCHORED` tier to `claim:uv-escape-necessity`; do not change its `Authority.AUDIT`, C1/C2, or root status.

- [ ] **Step 4: Verify GREEN**

Run: `pytest -q tests/test_v06_external_anchor.py tests/test_v05_run.py`

- [ ] **Step 5: Commit**

```bash
git add external_theorem_anchors_v0.6.yaml src/csm_runtime/external_anchor.py tests/test_v06_external_anchor.py
git commit -m "feat: anchor ETN-X critical-L3 external theorem dependency"
```

### Task 6: Real v0.5 -> v0.6 integration run

**Files:**
- Create: `src/csm_runtime/formalization_run.py`
- Test: `tests/test_v06_run.py`

**Interfaces:**
- Produces: `run_v06_formalization_replication(root, evidence_dir)`.

- [ ] **Step 1: Write failing integration test**

Expected release semantics:

```text
12 v0.5 PROOF assets preserved
12 formalization records
12 replication attempts
12 MATCH replications
12 FORMALIZED_CORE_ONLY tier attachments
12 CROSS_IMPLEMENTATION_REPLICATED tier attachments
1 EXTERNAL_THEOREM_ANCHORED tier on ETN-X UV necessity
0 FORMAL_PROOF assets
root/C1/C2 OPEN
full replay exact
second v0.6 run idempotent no-op
```

- [ ] **Step 2: Run and confirm RED**

Run: `pytest -q tests/test_v06_run.py`

- [ ] **Step 3: Implement deterministic integration pipeline**

Rebuild v0.5 state using existing v0.5 runner; produce FIR bundles; run isolated replicators; commit tier batch; commit external anchor; return state/ledger/summary.

- [ ] **Step 4: Verify GREEN**

Run: `pytest -q tests/test_v06_run.py tests/test_v05_run.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/formalization_run.py tests/test_v06_run.py
git commit -m "feat: execute NS_GSM v0.6 formalization replication closure"
```

### Task 7: Query, CLI, and release evidence

**Files:**
- Modify: `src/csm_runtime/query.py`
- Modify: `src/csm_runtime/cli.py`
- Create: `src/csm_runtime/v06_evidence.py`
- Test: `tests/test_v06_queries_cli.py`

**Interfaces:**
- Query methods: `formalizations()`, `replications()`, `external_theorem_anchors()`, `authority_tiers()`, `formal_proof_assets()`, `replicated_assets()`.
- CLI command: `run-formalization-replication`.

- [ ] **Step 1: Write failing query/CLI/evidence tests**

Evidence must include the files required by the spec and must record `formal_proof_count=0`.

- [ ] **Step 2: Run and confirm RED**

Run: `pytest -q tests/test_v06_queries_cli.py`

- [ ] **Step 3: Implement read-only query surface, CLI, and content-addressed evidence writer**

- [ ] **Step 4: Verify GREEN**

Run: `pytest -q tests/test_v06_queries_cli.py tests/test_cli.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/query.py src/csm_runtime/cli.py src/csm_runtime/v06_evidence.py tests/test_v06_queries_cli.py
git commit -m "feat: expose v0.6 formalization replication audit surface"
```

### Task 8: 0.6.0 release closure

**Files:**
- Modify: `pyproject.toml`
- Modify: `src/csm_runtime/__init__.py`
- Modify: `README.md`
- Create: `NS_GSM_FORMALIZATION_REPLICATION_V0.6_REPORT.md`
- Create: `RELEASE_MANIFEST_V0.6.json`
- Generated: `evidence/v0.6/*`

- [ ] **Step 1: Bump runtime to 0.6.0 and update dependency/report metadata**

No new runtime dependency beyond existing PyYAML/SymPy is required.

- [ ] **Step 2: Fresh full regression in harness-safe mutually exclusive shards**

All test files must be covered exactly once and all shards must exit 0.

- [ ] **Step 3: Freeze v0.6 evidence**

Run the CLI to produce the canonical v0.6 state and evidence package. Record state hash, counts, replay result, tier counts, and `FORMAL_PROOF=0`.

- [ ] **Step 4: Build deterministic wheel**

Use fixed `SOURCE_DATE_EPOCH`, PEP517 no-build-isolation if required by the offline environment, and verify two builds have identical SHA-256.

- [ ] **Step 5: Installed-wheel smoke from outside repo**

Install wheel with `pip --target` or an equivalent isolated target; verify `csm_runtime.__file__` comes from target, not repo `src/`; run full v0.6 CLI and require exact canonical state hash.

- [ ] **Step 6: Commit release source/evidence metadata**

Do not force ignored wheel artifacts into Git.

- [ ] **Step 7: Commit-post verification**

Repeat test shards and installed-wheel smoke from the release commit.

- [ ] **Step 8: Package release ZIP and verify `ZipFile.testzip() is None`**

Exclude `.git`, caches and temporary build directories. Produce external release manifest with source commit, state hash, wheel hash, ZIP hash and evidence counts.

---

## Plan Self-Review

- Spec coverage: canonical records, FIR, isolated replication, tier gates, external anchor, integration, queries/evidence, formal-proof firewall and release closure are all assigned to tasks.
- Placeholder scan: no TODO/TBD/"implement later" requirements remain.
- Type consistency: record and function names used by later tasks are defined in earlier tasks.
- Scope: v0.6 does not install theorem provers, re-prove external PDE theorems, or alter root closure semantics.
