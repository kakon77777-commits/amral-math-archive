# NS_GSM v0.5 Independent Verification Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add replayable independent verification records, exact verifier implementations, and atomic `AUDIT -> PROOF` authority upgrades for bounded NS_GSM assets.

**Architecture:** Add a verifier registry separate from source authority audits. Exact verifier outputs are hashed, event-sourced, and may create independent certificates; authority upgrades occur only in an atomic batch transaction and never propagate to parent NS targets.

**Tech Stack:** Python 3.11+, SymPy 1.14+, PyYAML, pytest, standard library SHA-256/JSON.

**Spec:** `docs/superpowers/specs/2026-08-28-ns-gsm-independent-verification-v0.5-design.md`

## Global Constraints
- No parent/root/C1/C2 mutation.
- `PARTIAL/FAILED/DEFER/CORPUS_AUDIT` cannot upgrade authority.
- Source-internal certificates remain audit evidence, not independent proof.
- Every PROOF upgrade requires a new independent certificate and hashed verifier artifact.
- Verification and upgrades must replay deterministically.

---

### Task 1: Verification and upgrade state model
**Files:** modify `model.py`, `state.py`; test `test_v05_verification_model.py`.
- [ ] Write failing round-trip/replay tests for `IndependentVerificationRecord` and `AuthorityUpgradeReceipt`.
- [ ] Run focused tests and confirm RED.
- [ ] Implement dataclasses, state registries, `REGISTER_INDEPENDENT_VERIFICATION`, `REGISTER_AUTHORITY_UPGRADE`, and `SET_AUTHORITY` event reducer.
- [ ] Run focused tests and full regression shard.
- [ ] Commit.

### Task 2: Verifier protocol and proof artifact hashing
**Files:** create `independent_verification.py`; test `test_v05_verifier_protocol.py`.
- [ ] Write failing tests for verifier result kinds, deterministic proof-artifact hash, statement/scope matching, and non-upgrade-eligible result classes.
- [ ] Implement verifier protocol, result model, canonical proof artifact writer/hash helper, and verifier manifest.
- [ ] Verify and commit.

### Task 3: D103 symbolic exact verifiers
**Files:** create `verifiers/d103.py`; test `test_v05_d103_symbolic.py`.
- [ ] RED tests for D103.1–D103.5.
- [ ] Implement exact SymPy checks: commutator identity, shear resonance, single-shear contradiction, five-ray characteristic polynomial, Riesz-loaded 2x2 solve.
- [ ] Require all five to return `VALID` with exact artifacts.
- [ ] Verify and commit.

### Task 4: D105 exact/analytic verifiers
**Files:** create `verifiers/d105.py`; test `test_v05_d105_verifiers.py`.
- [ ] RED tests for D105.1–D105.4.
- [ ] Implement kernel derivative symbolic check, exact Kelvin/TR witness, viscosity residual identity, and fixed-band support inequality schema.
- [ ] If D105.1 cannot be closed symbolically, return `PARTIAL` rather than weakening the test.
- [ ] Verify and commit.

### Task 5: RFP + ETN-X independent verifiers
**Files:** create `verifiers/rfp.py`, `verifiers/etnx.py`; test `test_v05_rfp_etnx.py`.
- [ ] RED tests for RFP-05 32.1, RFP-10 42.1, RFP-12 12.1, RFP-12 19.1, ETN-X Prop 8.1.
- [ ] Implement graph-theorem reduction for RFP-05, corpus-audit-only result for RFP-10, quadratic minimization schema for RFP-12 12.1, constructive translation-separation schema for RFP-12 19.1, and bounded analytic derivation for ETN-X Prop 8.1.
- [ ] Verify result classes and commit.

### Task 6: Atomic authority-upgrade batch
**Files:** create `verification_batch.py`; test `test_v05_upgrade_batch.py`.
- [ ] RED tests: VALID eligible verifier upgrades AUDIT->PROOF; PARTIAL/DEFER/CORPUS_AUDIT do not; independent cert added; source cert preserved; second batch is idempotent; root/C1/C2 unchanged.
- [ ] Implement batch transaction and receipts.
- [ ] Verify and commit.

### Task 7: v0.5 run, query, CLI, evidence
**Files:** create `verification_run.py`; modify `query.py`, `cli.py`; tests `test_v05_run.py`, `test_v05_cli.py`.
- [ ] RED integration test rebuilding v0.4 then running all v0.5 verifiers.
- [ ] Add queries `verification-summary`, `verification`, `proof-authority-assets`, `verification-deferred`.
- [ ] Add CLI `run-independent-verification`.
- [ ] Write evidence bundle and conformance checks.
- [ ] Verify replay exact and idempotency.
- [ ] Commit.

### Task 8: Release 0.5.0
**Files:** update `pyproject.toml`, `__init__.py`, README/report/manifest.
- [ ] Set version 0.5.0.
- [ ] Fresh full test coverage (sharded if harness command limit requires).
- [ ] Freeze v0.5 evidence and record exact upgrade counts/hash.
- [ ] Build wheel without network, isolated installed-wheel smoke, confirm module loaded from venv.
- [ ] Create release ZIP and run `testzip()`.
- [ ] Commit release and rerun post-commit verification.
