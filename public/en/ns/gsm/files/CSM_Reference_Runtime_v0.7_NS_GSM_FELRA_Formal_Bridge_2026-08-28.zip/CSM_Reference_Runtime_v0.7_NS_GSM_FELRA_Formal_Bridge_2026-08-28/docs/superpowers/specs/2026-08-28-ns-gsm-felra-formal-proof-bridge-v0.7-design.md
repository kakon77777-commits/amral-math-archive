# NS_GSM v0.7 — FELRA Formal Proof Bridge & Kernel Authority Protocol

**Date:** 2026-08-28  
**Status:** Draft for user review  
**Baseline:** CSM Reference Runtime / NS_GSM v0.6  
**Baseline canonical state:** `f5d4a8a739d15b5605d59ba354dd1d5771924c50d355a3787db0f7b75e06dfac`  
**Baseline formalized/replicated assets:** 12  
**Primary external execution dependency:** `kakon77777-commits/FELRA`, audited `main`, package version `1.8.1`  
**Runtime target:** 0.7.0

---

## 1. Goal

NS_GSM v0.7 introduces a formal-proof execution bridge between NS_GSM and FELRA without collapsing the responsibilities of either system.

The bridge must allow a bounded NS_GSM proof asset to travel through the following chain:

```text
NS_GSM native proof asset
  -> NSGSM-FIR formalization
  -> generated formal obligation identity
  -> completed Lean proof artifact
  -> FELRA formal_check
  -> Lean kernel verdict
  -> FELRA formal evidence / external_formal certificate
  -> NS_GSM import validation
  -> FORMAL_PROOF[lean] authority tier
```

The bridge must never infer parent theorem closure merely because one bounded child asset receives a kernel-checked proof.

The first v0.7 release uses FELRA's already-registered Lean backend. Coq is a second-stage FELRA backend extension and is not required for the first v0.7 release gate.

---

## 2. Architectural Boundary

The approved architecture is **NS_GSM ↔ FELRA Bridge**, not repository fusion and not direct library embedding.

### 2.1 NS_GSM owns

- mathematical asset identity;
- claim / theorem statement identity;
- scope and assumptions;
- NSGSM-FIR;
- formal obligation generation;
- FIR-to-obligation translation audit;
- content-addressed bridge manifests;
- formal-proof import policy;
- authority-tier semantics;
- closure graph and parent/child propagation rules;
- replayable native state.

### 2.2 FELRA owns

- closed formal-backend registry;
- formal checker invocation;
- checker availability semantics;
- checker resolved path/version/hash evidence;
- obligation path/hash/size evidence;
- formal verdict (`verified`, `refuted`, `unknown`, `unavailable`);
- Lean axiom audit through `#print axioms` / `axioms_within`;
- external formal certificate issuance;
- formal-run evidence and replay/provenance artifacts.

### 2.3 Lean kernel owns

- elaboration/type checking of the completed Lean obligation;
- rejection of ill-typed/incomplete proof artifacts;
- proof acceptance relative to Lean's kernel and declared axiom policy.

### 2.4 Boundary rule

NS_GSM must not import FELRA Python internals as part of its canonical runtime semantics.

The bridge is an **artifact/subprocess protocol**:

```text
NS_GSM export bundle
      |
      v
FELRA CLI / local FELRA environment
      |
      v
FELRA evidence bundle
      |
      v
NS_GSM import gate
```

A future implementation may offer an optional convenience Python wrapper, but the authoritative interface remains file/artifact based.

---

## 3. FELRA Source Audit Basis

The v0.7 design is grounded in the inspected FELRA repository state on 2026-08-28.

### Audited files

| FELRA file | Git blob SHA | Relevant contract |
|---|---|---|
| `pyproject.toml` | `95721c6c0276b12f9d509df5edd3c399701de3a7` | package version `1.8.1`, CLI `felra` |
| `README.md` | `842fe0b7b595e90a70d0125fa1b127bc1a61f75b` | Python-first evidence workbench, external formal backends |
| `docs/FORMAL_BACKENDS.md` | `e1f35370583ee1d8fbdd7b364f68df8ba0988a10` | Lean/TLC/Z3 registry, Lean axiom policy, no Lean/Coq proof-script generation |
| `src/felra/formal.py` | `f1666c5ab22c8c635d643688d0551e6a12221bca` | backend identity, Lean verdict mapping, checker/obligation provenance |
| `src/felra/analysis/formal_check.py` | `b759acaa31759cf076c51cdae9592d4fda26c653` | separates pipeline `success` from `formal_status` |
| `src/felra/certificates.py` | `ac32e505170f0b0bfea84fde994354b634954235` | `external_formal` certificate issuance and integrity verification |
| `examples/formal_check/project.yaml` | `738454e2e6dc5f0b4720c6f20df33d9e33fe1b96` | declarative formal-check configuration shape |

### Existing FELRA properties that v0.7 relies on

1. Formal status is distinct from FELRA pipeline success.
2. Missing checker is `unavailable`, not `verified`.
3. Lean `sorry` is `unknown`, not `verified`.
4. Lean compile failure or `error:` is not accepted as proof.
5. FELRA records checker backend, command, resolved path, version, and executable hash.
6. FELRA records obligation SHA-256 and byte count.
7. `axioms_within` can audit reported Lean theorem axiom dependencies.
8. A declared axiom audit with no theorem output is `unknown`, preventing vacuous success.
9. FELRA formal certificates are content-hashed and independently integrity-checkable.
10. FELRA intentionally does not claim that certificate-integrity verification re-runs or independently re-proves the theorem.

These properties are prerequisites for the v0.7 bridge rather than features to duplicate inside NS_GSM.

---

## 4. Non-Collapse Rules

The following are hard v0.7 invariants:

```text
NSGSM-FIR != Lean obligation
Lean obligation != Lean proof
Lean elaboration success != translation correctness
FELRA success != FELRA formal_status
FELRA formal_status=verified != NS_GSM FORMAL_PROOF by itself
FELRA certificate integrity valid != fresh kernel replay
FORMAL_PROOF[lean] != parent claim closure
FORMAL_PROOF[lean] != Navier-Stokes regularity proof
FORMAL_PROOF[lean] != CROSS_KERNEL_FORMAL_REPLICATION
FORMAL_PROOF[lean] != FORMAL_PROOF[coq]
```

The formal Navier-Stokes root, C1 and C2 remain `OPEN` unless their own proof-carrying closure transactions independently satisfy existing NS_GSM closure rules. In short: root NS, C1 and C2 remain `OPEN`.

---

## 5. Why Translation Is a Separate Authority Layer

FELRA can establish:

> this exact Lean artifact was accepted by this exact Lean toolchain under this recorded axiom policy.

FELRA does **not** establish:

> this Lean artifact means exactly what the NS_GSM FIR asset intended.

Therefore v0.7 adds an explicit translation layer:

```text
NSGSM-FIR
   |
   | Translate
   v
Lean obligation source
   |
   | Translation audit
   v
TranslationCertificate
```

`FORMAL_PROOF[lean]` requires both a valid translation certificate and a FELRA `verified` formal run.

---

## 6. Formal Obligation Bundle

Each bounded target has a content-addressed bridge bundle:

```text
bridge/<bridge-id>/
  ns_gsm_bridge_manifest.json
  fir.json
  translation.json
  felra/
    project.yaml
  lean/
    obligation.lean
    project/
      lakefile.toml or lakefile.lean
      lean-toolchain
      [generated support modules]
  evidence/
    [created by FELRA/local execution]
```

The exported bundle does not include machine-local prover paths.

### 6.1 `ns_gsm_bridge_manifest.json`

Required fields:

```yaml
protocol: NSGSM-FELRA/0.1
bridge_id:
subject_id:
formalization_id:
fir_sha256:
translation_id:
translation_sha256:
backend: lean
obligation_relpath:
obligation_sha256:
project_digest_sha256:
theorem_names: []
expected_formal_status: verified
axiom_policy:
  mode: allowlist
  allowed: []
assumptions: []
limitations: []
derives_from: []
```

### 6.2 Machine-local values are excluded from bridge identity

The following may appear in FELRA execution evidence but must not enter NS_GSM canonical mathematical identity:

- absolute `lake` path;
- absolute project path;
- absolute obligation path;
- host username;
- temporary directory;
- elapsed duration;
- raw stdout/stderr;
- shell-specific command spelling.

NS_GSM imports normalized, content-addressed values only.

---

## 7. Translation Protocol

### 7.1 Translation inputs

- one existing v0.6 `FormalizationRecord`;
- canonical `NSGSM-FIR/0.1` bundle;
- target backend profile `lean-v0.1`;
- theorem-name policy;
- axiom policy.

### 7.2 Translation outputs

- Lean obligation source;
- theorem declaration inventory;
- normalized translation map;
- content hashes;
- `TranslationCertificateRecord`.

### 7.3 Translation certificate

New canonical record:

```text
TranslationCertificateRecord
```

Required fields:

- `translation_id`;
- `subject_id`;
- `formalization_id`;
- `fir_sha256`;
- `backend`;
- `backend_profile_version`;
- `obligation_sha256`;
- `project_digest_sha256`;
- `theorem_names`;
- `variable_map`;
- `assumption_map`;
- `goal_map`;
- `status`;
- `limitations`;
- `translation_checker_version`;
- `translation_checker_sha256`;
- `evidence_refs`.

Translation status values:

```text
VALID
PARTIAL
INVALID
DEFER
```

Only `VALID` is eligible for a formal-proof import.

### 7.4 Translation checker scope

The v0.7 translation checker establishes structural/semantic preservation of the declared FIR fields under the supported Lean profile.

It does not prove the theorem.

If a FIR construct has no declared Lean translation rule, translation must return `DEFER` instead of inventing an approximation.

---

## 8. Proof-Body Boundary

NS_GSM v0.7 may generate theorem signatures and obligation scaffolding, but it must not treat generated proof text as trusted.

The design distinguishes:

```text
generated obligation identity
completed proof artifact
```

A local human/agent may complete the Lean proof body.

Before FELRA execution, the bridge preflight must verify that the theorem signature, assumptions and target statement still match the original bridge manifest and translation certificate.

Editing the statement to make the proof easier invalidates the translation certificate and requires a new translation record.

A proof artifact containing `sorry` is ineligible because FELRA already maps such a Lean result to `unknown`.

---

## 9. FELRA Execution Bundle

For each Lean target, NS_GSM exports a FELRA project with a `formal_check` analysis equivalent to:

```yaml
project:
  id: ns-gsm-felra-<bridge-id>
  title: NS_GSM formal proof bridge

claims:
  - id: <subject-id>
    statement: <bounded statement>
    status: hypothesis
    required_checks: []

analyses:
  - id: formal_<bridge-id>
    type: formal_check
    claim_id: <subject-id>
    backend: lean
    obligation: ../lean/obligation.lean
    project_dir: ../lean/project
    expect: verified
    derives_from:
      - ns_gsm_subject:<subject-id>
      - ns_gsm_fir:<formalization-id>
      - ns_gsm_translation:<translation-id>
    assumptions: [...]
    limitations: [...]
    axioms_within: [...]
```

The exact project path layout may be normalized during implementation, but the semantic fields above are mandatory.

FELRA may resolve `lake` from PATH or a declared path. The declared path is execution configuration, not part of the exported canonical bridge identity.

---

## 10. FELRA Formal Evidence Import

NS_GSM does not trust FELRA's top-level `success` flag as a proof verdict.

The importer reads the formal analysis payload and requires:

```text
kind == formal_check
formal_status == verified
expected_formal_status == verified
expectation_met == true
backend == lean
obligation.sha256 == bridge manifest obligation_sha256
```

If `axioms_within` was declared, import additionally requires:

- `theorems_audited > 0`;
- theorem inventory includes the intended theorem names;
- `axioms_seen` is a subset of the bridge axiom allowlist;
- no FELRA detail/warning indicates `sorry`, unavailable checker, undecided run, missing obligation or malformed request.

The importer also verifies the FELRA-issued `external_formal` certificate integrity where such a certificate is present.

Certificate integrity is necessary but not sufficient: the fresh formal-run payload is the kernel-run evidence.

---

## 11. New Canonical Records

### 11.1 `FormalObligationRecord`

Fields:

- `obligation_id`;
- `subject_id`;
- `formalization_id`;
- `translation_id`;
- `backend`;
- `obligation_sha256`;
- `project_digest_sha256`;
- `theorem_names`;
- `axiom_policy`;
- `assumptions`;
- `limitations`;
- `bridge_manifest_sha256`;
- `status`;
- `evidence_refs`.

### 11.2 `FELRAFormalRunRecord`

Canonicalized imported fields only:

- `formal_run_id`;
- `subject_id`;
- `bridge_id`;
- `felra_version`;
- `backend`;
- `formal_status`;
- `obligation_sha256`;
- `checker_version`;
- `checker_executable_sha256`;
- `exit_code`;
- `theorems_audited`;
- `axioms_seen`;
- `assumptions`;
- `limitations`;
- `felra_result_sha256`;
- `felra_certificate_sha256`;
- `status`;
- `evidence_refs`.

Absolute local paths and timing values are intentionally excluded from the canonical record.

### 11.3 `KernelFormalProofReceipt`

Fields:

- `formal_proof_receipt_id`;
- `subject_id`;
- `backend`;
- `translation_id`;
- `formal_run_id`;
- `certificate_id`;
- `obligation_sha256`;
- `checker_executable_sha256`;
- `axiom_policy_digest`;
- `event_ids`;
- `state_hash_before`;
- `state_hash_after`.

---

## 12. Kernel Formal-Proof Certificate

NS_GSM v0.7 uses the existing generic certificate registry with certificate type:

```text
KERNEL_FORMAL_PROOF
```

Required data:

```yaml
subject_id:
backend: lean
kernel_checked: true
translation_id:
formal_run_id:
obligation_sha256:
checker_version:
checker_executable_sha256:
theorem_names: []
axioms_seen: []
axiom_policy_digest:
felra_result_sha256:
felra_certificate_sha256:
```

The certificate is `VALID` only after the import gate in Section 10 succeeds.

---

## 13. Authority-Tier Semantics

The generic authority tier remains:

```text
FORMAL_PROOF
```

Backend identity is carried by the receipt/certificate rather than encoded into a new scalar authority enum.

Views may render:

```text
FORMAL_PROOF[lean]
FORMAL_PROOF[coq]
```

if receipts exist for those backends.

`FORMAL_PROOF` is orthogonal to base `Authority.PROOF` and existing tiers such as:

- `FORMALIZED_CORE_ONLY`;
- `CROSS_IMPLEMENTATION_REPLICATED`;
- `EXTERNAL_THEOREM_ANCHORED`.

Adding `FORMAL_PROOF` must not mutate:

- `ClosureStatus`;
- parent object status;
- child object status;
- graph edges;
- route completeness;
- root theorem status.

---

## 14. Formal-Proof Promotion Gate

A subject is eligible for `FORMAL_PROOF[lean]` iff all conditions hold:

1. subject exists in native state;
2. subject already has `Authority.PROOF`;
3. subject has `FORMALIZED_CORE_ONLY`;
4. subject has a matching `FormalizationRecord`;
5. translation certificate is `VALID`;
6. obligation identity matches translation and bridge manifest;
7. FELRA formal run is `verified`;
8. expected formal status was `verified` and expectation was met;
9. FELRA backend is `lean`;
10. checker executable hash and version are recorded;
11. obligation SHA-256 matches exactly;
12. required theorem axiom audit is non-vacuous;
13. observed axioms stay inside policy;
14. no `sorry` / unknown / unavailable / malformed-run condition exists;
15. content-addressed evidence artifacts exist;
16. transaction input state hash is current.

Any failure returns `DEFER` or `REFUSE` and attaches no formal-proof tier.

---

## 15. First Lean Target Batch

The first v0.7 Lean batch is deliberately restricted to the five D103 algebraic assets:

| NS_GSM asset | Source statement | v0.6 state |
|---|---|---|
| `authority:proof_asset:eff2219d7a5467e10be77147` | D103.1 Eigen-lock commutator equation | PROOF + formalized + replicated |
| `authority:proof_asset:94f3255e3b78bbc0d9192b8f` | D103.2 Shear resonance condition | PROOF + formalized + replicated |
| `authority:proof_asset:afa3a6beea0d736b9717fcac` | D103.3 Single-shear theorem | PROOF + formalized + replicated |
| `authority:proof_asset:d8ae2219282a007c44012707` | D103.4 Five-Ray Spectrum | PROOF + formalized + replicated |
| `authority:proof_asset:417fac1f647fe8e3aa6e3128` | D103.5 Riesz-loaded coaxial response | PROOF + formalized + replicated |

These are chosen because their v0.6 formalization class is finite-dimensional algebraic core, making FIR-to-Lean translation auditable without importing the full Navier-Stokes functional-analytic envelope.

The other seven v0.6 PROOF assets remain unchanged in the first v0.7 release.

---

## 16. Lean Project Strategy

v0.7 uses a minimal dedicated Lean project for the D103 algebraic batch.

Design goals:

- no network fetch during proof execution once the project/toolchain exists locally;
- minimal dependency surface;
- explicit toolchain version;
- theorem names stable and derived from NS_GSM case IDs;
- all generated support source content hashed;
- axiom audit emitted for each target theorem;
- no `sorry` in release proof files;
- proof bodies may be written/edited locally, but target signatures remain translation-locked.

The initial implementation should prefer Lean core/mathlib constructs already available in the user's local project/toolchain rather than inventing a bespoke algebra library.

---

## 17. FELRA Certificate Mapping

FELRA already supports `external_formal` certificates containing checker identity and obligation hash.

The v0.7 bridge maps one FELRA formal certificate into an NS_GSM `KERNEL_FORMAL_PROOF` certificate only through the import gate.

```text
FELRA external_formal certificate
        +
FELRA verified FormalOutcome
        +
NS_GSM TranslationCertificate
        +
NS_GSM bridge manifest
        =
NS_GSM KERNEL_FORMAL_PROOF certificate
```

No single component alone is sufficient.

---

## 18. Fresh Run vs Stored Certificate

A stored FELRA certificate can be re-checked for integrity without re-running Lean.

That is useful but insufficient for a new formal-proof promotion.

The v0.7 distinction is:

```text
FELRA_CERTIFICATE_INTEGRITY_VALID
!=
FELRA_KERNEL_RUN_VERIFIED
```

Initial `FORMAL_PROOF` promotion requires a formal-run record produced by an actual FELRA execution whose formal status is `verified`.

Replay of an already committed NS_GSM ledger does not require re-running Lean; it replays the previously committed kernel-proof receipt. Revalidation is a separate operation.

---

## 19. Revalidation Semantics

v0.7 distinguishes:

### `REPLAY`

Reconstruct committed NS_GSM state from ledger. No external prover invocation.

### `CERTIFICATE_VERIFY`

Verify stored content hashes and certificate integrity. No external prover invocation.

### `KERNEL_REVALIDATE`

Re-run FELRA/Lean against the same obligation/project digest.

Possible results:

```text
MATCH
MISMATCH
UNAVAILABLE
UNKNOWN
```

A revalidation mismatch creates evidence debt and marks the formal-proof receipt `STALE` or `DISPUTED` according to policy; it does not silently erase historical evidence.

---

## 20. State/Event Additions

New registries:

- `translation_certificates`;
- `formal_obligations`;
- `felra_formal_runs`;
- `kernel_formal_proof_receipts`.

New events:

```text
REGISTER_TRANSLATION_CERTIFICATE
REGISTER_FORMAL_OBLIGATION
REGISTER_FELRA_FORMAL_RUN
REGISTER_KERNEL_FORMAL_PROOF_CERTIFICATE
ATTACH_FORMAL_PROOF_TIER
REGISTER_KERNEL_FORMAL_PROOF_RECEIPT
MARK_FORMAL_PROOF_STALE
REGISTER_KERNEL_REVALIDATION
```

Every authority-changing operation is atomic and replayable.

---

## 21. Canonical Hash Rules

Canonical state must not depend on where FELRA or Lean is installed.

Allowed canonical identifiers include:

- backend name;
- checker version;
- checker executable SHA-256;
- obligation SHA-256;
- project digest;
- result/certificate SHA-256;
- theorem names;
- axiom names;
- normalized assumptions/limitations.

Disallowed canonical identity inputs include:

- absolute executable path;
- absolute project path;
- absolute evidence path;
- hostname;
- username;
- temporary-directory name;
- wall-clock duration;
- raw transcript ordering artifacts unrelated to semantics.

This extends the location-independence invariant established in v0.5.

---

## 22. Project Digest

FELRA currently hashes the declared obligation artifact and checker binary. NS_GSM v0.7 additionally computes a bridge-level project digest over every proof-relevant local source/config file required by the obligation.

The project digest includes, in canonical path order:

- `obligation.lean`;
- generated support Lean modules;
- `lean-toolchain`;
- `lakefile.toml` / `lakefile.lean` if used;
- local bridge translation manifest;
- theorem/axiom audit source if separate.

The digest excludes build outputs such as `.olean`, `.lake/build`, logs and timing files.

This prevents an obligation file hash from appearing stable while an imported support module silently changes meaning.

---

## 23. Failure Semantics

### FELRA unavailable

No formal-proof tier. Record `UNAVAILABLE` execution evidence outside native mathematical authority.

### Lean `unknown`

No formal-proof tier.

### Lean `refuted`

No formal-proof tier. Create formalization/proof debt; do not infer the mathematical source theorem is false until translation correctness and proof artifact intent are audited.

### Translation invalid

No FELRA result can override this. Refuse import.

### Obligation hash mismatch

Refuse import.

### Project digest mismatch

Refuse import.

### Axiom allowlist exceeded

Refuse formal-proof promotion and preserve explicit axiom-debt evidence.

### `sorry` detected

FELRA should return `unknown`; NS_GSM independently refuses promotion even if malformed downstream data says otherwise.

### FELRA top-level `success=true` but `formal_status != verified`

No formal-proof promotion.

---

## 24. Query Surface

New v0.7 query operations:

```text
formal-obligation <subject-id>
translation <subject-id>
felra-run <subject-id>
formal-proof <subject-id>
formal-proof-summary
kernel-revalidation <subject-id>
```

Every response includes:

- subject identity;
- backend;
- bounded scope;
- FIR hash;
- translation hash;
- obligation hash;
- project digest;
- checker identity hash/version;
- formal status;
- axiom audit summary;
- certificate refs;
- evidence refs;
- authority tiers;
- native state version.

---

## 25. CLI Surface

Planned v0.7 CLI commands:

```text
export-felra-bridge
import-felra-formal-result
formal-proof-summary
kernel-revalidate
```

### Example export

```bash
python -m csm_runtime.cli export-felra-bridge \
  --root . \
  --subject authority:proof_asset:eff2219d7a5467e10be77147 \
  --backend lean \
  --output artifacts/v0.7/d103-1
```

### Example local FELRA execution

```bash
felra run artifacts/v0.7/d103-1/felra/project.yaml \
  --output artifacts/v0.7/d103-1/felra-run
```

### Example import

```bash
python -m csm_runtime.cli import-felra-formal-result \
  --bridge artifacts/v0.7/d103-1/ns_gsm_bridge_manifest.json \
  --felra-result artifacts/v0.7/d103-1/felra-run/<formal-result-artifact> \
  --evidence evidence/v0.7
```

Implementation will bind `<formal-result-artifact>` to the actual FELRA 1.8.1 run-output layout after an integration fixture is established; no filename is guessed in the design.

---

## 26. Testing Strategy

### 26.1 Pure runtime tests

- canonical serialization of new records;
- stable hashes;
- no local paths in canonical records;
- transaction atomicity;
- deterministic replay;
- no parent closure propagation.

### 26.2 Translation tests

- supported FIR variables map exactly;
- assumptions map exactly;
- theorem target maps exactly;
- unsupported FIR operation returns `DEFER`;
- modifying theorem statement invalidates certificate;
- proof-body-only edits preserve statement identity but change obligation/project digest.

### 26.3 FELRA fixture tests

Because the current execution environment may not contain Lean/FELRA toolchains, repository tests include deterministic FELRA formal-result fixtures for:

- `verified`;
- `unknown` (`sorry`);
- `unavailable`;
- `refuted`;
- axiom overflow;
- vacuous axiom audit;
- obligation hash mismatch;
- checker identity missing.

Fixtures validate the NS_GSM importer, not the FELRA backend implementation.

### 26.4 Real local gate

The actual v0.7 formal-proof release requires a real local FELRA+Lean run for at least one D103 theorem before any `FORMAL_PROOF[lean]` count can exceed zero.

For the full first batch target, release goal is five D103 Lean proofs if the local proof work succeeds. Partial completion is allowed; failed/incomplete obligations remain without `FORMAL_PROOF`.

---

## 27. Release Success Criteria

A v0.7 release may be called bridge-complete when:

1. export protocol is deterministic;
2. translation certificates are replayable;
3. FELRA result importer is fail-closed;
4. canonical state is machine/path-location independent;
5. real FELRA+Lean execution can be imported;
6. at least one D103 bounded asset obtains a real `KERNEL_FORMAL_PROOF` certificate from Lean through FELRA;
7. no `sorry` proof is promoted;
8. axiom audit is non-vacuous and within policy;
9. formal proof attachment changes no parent status;
10. root NS, C1 and C2 remain `OPEN`;
11. complete ledger replay reproduces exact state hash;
12. bridge re-application is idempotent;
13. previous v0.6 tests remain passing;
14. new bridge conformance vectors pass;
15. release evidence records FELRA and Lean versions/hashes without incorporating machine-local paths into state identity.

If no Lean toolchain is available in the execution environment used to build the release, the software bridge can be released as `BRIDGE_READY`, but `FORMAL_PROOF count = 0` must remain a release invariant. A later local kernel-run evidence package can be imported without redesigning the runtime.

---

## 28. First-Batch Axiom Policy

The initial D103 Lean batch should use the narrowest practical policy supported by the chosen Lean/mathlib proof implementation.

The bridge must declare the allowlist explicitly rather than inheriting an unbounded default.

The current FELRA Lean register recognizes the standard Lean axiom set used by its validated whole-development audit:

```text
propext
Classical.choice
Quot.sound
```

v0.7 does not automatically assume all three are necessary. The actual proof batch records the smallest observed subset. If a theorem is axiom-free, the audit should record that fact.

---

## 29. Coq Phase B Design

Coq integration is intentionally a FELRA backend extension, not an NS_GSM private runner.

### 29.1 Proposed FELRA backend identity

```text
backend = coq
```

The backend remains part of FELRA's closed registry and must be documented in `docs/FORMAL_BACKENDS.md` before being trusted.

### 29.2 Proposed toolchain

Minimum execution path:

```text
coqc <obligation.v>
```

Preferred stronger path:

```text
coqc <obligation.v>
coqchk <compiled-module>
```

Assumption audit should use a stable Coq command/artifact path such as `Print Assumptions <theorem>` or an equivalent machine-readable audit module.

### 29.3 Coq provenance fields

- `coqc` resolved path/version/SHA-256;
- `coqchk` resolved path/version/SHA-256 when used;
- `.v` source SHA-256;
- compiled `.vo` SHA-256 when stable/useful;
- theorem inventory;
- assumptions seen;
- exit codes;
- formal status;
- limitations.

### 29.4 Coq registration gate

The Coq backend must not be added merely from expected command semantics.

Before FELRA registers `coq`, the adapter must be exercised against at least:

1. one real verified theorem artifact;
2. one intentionally invalid/refuted/incomplete artifact;
3. one unavailable-tool scenario;
4. an assumption-audit case;
5. path-resolution behavior;
6. certificate/replay behavior.

This follows FELRA's existing policy of refusing unexercised formal backends.

### 29.5 Cross-kernel tier

Only after the *same NS_GSM subject and translation-equivalent obligation* is verified independently by both Lean and Coq may NS_GSM add:

```text
CROSS_KERNEL_FORMAL_REPLICATION
```

This tier never follows merely from two files having similar theorem names.

---

## 30. Cross-Kernel Equivalence Contract

Future Lean/Coq equivalence requires a shared backend-neutral FIR identity.

For a subject `S`:

```text
FIR(S)
  -> LeanTranslation(S)
  -> CoqTranslation(S)
```

Both translation certificates must bind to the same:

- subject ID;
- FIR SHA-256;
- normalized variables;
- normalized assumptions;
- normalized goal;
- scope contract.

Then:

```text
FORMAL_PROOF[lean]
+
FORMAL_PROOF[coq]
+
translation-equivalence audit
->
CROSS_KERNEL_FORMAL_REPLICATION
```

The tier says two distinct kernels accepted backend-specific translations of the same FIR contract. It still does not imply any parent theorem not represented by that FIR.

---

## 31. Security Boundary

NS_GSM must never accept arbitrary shell commands through the bridge manifest.

The bridge manifest selects a known backend (`lean`, later `coq`), while FELRA owns the allowed executable mapping.

This preserves FELRA's closed-backend design and prevents an NS_GSM artifact from becoming executable shell configuration.

---

## 32. Versioning and Compatibility

Bridge protocol version:

```text
NSGSM-FELRA/0.1
```

Initial compatibility declaration:

```text
NS_GSM runtime: 0.7.x
FELRA: 1.8.1-compatible formal_check contract
Lean backend: FELRA registered `lean`
```

Compatibility is contract-based, not merely semver-based. A future FELRA version that changes formal result meaning or fields requires bridge conformance revalidation even if semver appears compatible.

---

## 33. Evidence Package

v0.7 evidence directory should include:

```text
evidence/v0.7/
  bridge_manifest.json
  translations.json
  formal_obligations.json
  felra_formal_runs.json
  kernel_formal_proof_receipts.json
  formal_proof_assets.json
  formal_proof_deferred.json
  kernel_revalidation.json
  replay_report.json
  conformance_report.json
  run_summary.json
  felra_raw/
    ... raw FELRA output bundles ...
```

Raw FELRA artifacts may contain local paths and transcripts. They remain evidence artifacts and are not serialized into canonical state identity.

---

## 34. Explicit Non-Goals for v0.7 Initial Release

The first v0.7 release does not:

- prove Navier-Stokes global regularity;
- prove C1;
- prove C2;
- formalize all twelve v0.6 assets in Lean;
- generate arbitrary Lean proof bodies automatically;
- add Coq to FELRA before real local validation;
- treat Z3 as a substitute for Lean kernel proof on Lean-targeted assets;
- import arbitrary FELRA analyses as theorem authority;
- reimplement FELRA backend execution inside NS_GSM;
- automatically propagate formal proof authority across graph edges;
- claim external peer review or publication replication.

---

## 35. Planned Implementation Decomposition

After this spec is approved, implementation should be split into two plans.

### Plan A — NS_GSM v0.7 Lean Bridge

1. bridge canonical records/events;
2. FIR-to-Lean translation profile;
3. deterministic export bundle;
4. translation validation;
5. FELRA result importer;
6. kernel formal-proof promotion gate;
7. D103 five-target bridge export;
8. real/local FELRA+Lean evidence import path;
9. queries/CLI/evidence/replay/release.

### Plan B — FELRA Coq Backend

1. Coq backend design against FELRA's existing formal contract;
2. real local `coqc` validation;
3. optional/required `coqchk` policy decision based on real tool behavior;
4. assumption-audit parser;
5. closed registry update;
6. verified/refuted/unavailable real-tool tests;
7. formal certificate compatibility;
8. NS_GSM Coq import fixture;
9. cross-kernel replication protocol test.

Plan B begins only when a real Coq environment is available for adapter validation.

---

## 36. Definition of Done for the Design

The design is internally complete if a future implementer can answer all of these without inventing semantics:

- who owns theorem identity? **NS_GSM**;
- who owns FIR-to-Lean translation? **NS_GSM bridge**;
- who executes Lean? **FELRA**;
- who accepts/rejects proof terms? **Lean kernel**;
- who records executable/obligation provenance? **FELRA**;
- who decides whether the returned evidence changes closure authority? **NS_GSM**;
- does FELRA `success` mean proof? **No**;
- does a stored FELRA certificate alone create a new formal proof? **No**;
- does a verified Lean file prove its FIR translation is faithful? **No; TranslationCertificate is separately required**;
- does one bounded formal proof close NS? **No**;
- may Coq be added without a real Coq validation run? **No**.
