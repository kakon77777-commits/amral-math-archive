# NS_GSM v0.3 Candidate Review / Promotion Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a replayable candidate review and proof-carrying promotion subsystem to the v0.2 NS_GSM runtime, execute the first structural review batch, and release auditable v0.3 evidence without inflating theorem authority.

**Architecture:** Add review records and promotion receipts to `NativeState`, event-source them through the existing ledger/replay system, and route all candidate-to-native mutations through a `PromotionGate` plus existing atomic operators. Tier-0 structural review is deterministic; theorem/NO-GO promotion remains certificate-gated.

**Tech Stack:** Python 3.11+, dataclasses, JSON/YAML, SHA-256 canonical serialization, pytest.

**Spec:** `docs/superpowers/specs/2026-08-27-ns-gsm-candidate-review-promotion-v0.3-design.md`

## Global Constraints

- Root formal NS target remains OPEN.
- Candidate labels never directly mutate theorem status.
- `BLOCKED != CLOSED_NEGATIVE`.
- `SURVIVOR` is OPEN + role tag.
- STOP/frontier promotion is structural, not theorem closure.
- Cross-series exact text never auto-quotients.
- Review/promotion must replay deterministically.
- v0.3 remains observed-relative.

---

### Task 1: Review model and canonical replay state

**Files:**
- Modify: `src/csm_runtime/model.py`
- Modify: `src/csm_runtime/replay.py`
- Modify: `src/csm_runtime/canonical.py`
- Test: `tests/test_review_model.py`

**Interfaces:**
- Produces: `ReviewRecord`, `PromotionReceipt`, `NativeState.reviews`, `NativeState.promotion_receipts`, replay support for review/receipt events.

- [ ] Write failing round-trip/hash tests for reviews and receipts.
- [ ] Verify RED with `pytest tests/test_review_model.py -q`.
- [ ] Implement minimal dataclasses + serialization/deserialization.
- [ ] Add replay reducers for `REGISTER_REVIEW`, `UPDATE_REVIEW_STATUS`, `REGISTER_PROMOTION_RECEIPT`.
- [ ] Verify focused tests + full regression.
- [ ] Commit `feat: add replayable review records and promotion receipts`.

### Task 2: Review decision and Tier-0 structural triage

**Files:**
- Create: `src/csm_runtime/review.py`
- Test: `tests/test_structural_review.py`

**Interfaces:**
- Produces: `ReviewDecision`, `ReviewBatch`, `classify_structural_candidate()`, `build_structural_review_batch()`.

- [ ] Write failing tests for Nonclaim/Frontier/NextFrontier/Survivor/process-status decisions.
- [ ] Verify RED.
- [ ] Implement deterministic Tier-0 review classification.
- [ ] Assert RFP `CLOSED AS A RESEARCH CYCLE` becomes process/defer review, not theorem promotion.
- [ ] Verify focused + full regression.
- [ ] Commit `feat: add structural candidate review tier`.

### Task 3: Promotion gate and safe structural promotions

**Files:**
- Create: `src/csm_runtime/promotion.py`
- Modify: `src/csm_runtime/operators.py`
- Test: `tests/test_promotion_gate.py`

**Interfaces:**
- Produces: `PromotionGate`, `promote_nonclaim()`, `promote_frontier()`, `promote_survivor()`, `promote_obstruction()`.

- [ ] Write failing tests for gate outcomes.
- [ ] Verify RED.
- [ ] Implement structural promotion operators through transaction-compatible mutations.
- [ ] Ensure obstruction promotion never calls `close_negative`.
- [ ] Ensure survivor is OPEN + `SURVIVOR` role tag.
- [ ] Verify focused + full regression.
- [ ] Commit `feat: enforce candidate promotion authority gate`.

### Task 4: Proof-authority promotion firewall

**Files:**
- Modify: `src/csm_runtime/promotion.py`
- Modify: `src/csm_runtime/candidate_validation.py`
- Test: `tests/test_proof_promotion.py`

**Interfaces:**
- Produces: proof/no-go promotion decisions requiring accepted certificate + scope compatibility.

- [ ] Write failing tests: source label alone refused; proof candidate without cert deferred; no-go without negative cert cannot close claim; source-internal cert may create bounded native proof asset only at policy-permitted authority.
- [ ] Verify RED.
- [ ] Implement certificate compatibility rules.
- [ ] Verify full regression.
- [ ] Commit `feat: add proof-carrying promotion firewall`.

### Task 5: Review ledger transactions and idempotent batches

**Files:**
- Modify: `src/csm_runtime/transaction.py`
- Modify: `src/csm_runtime/ledger.py`
- Modify: `src/csm_runtime/review.py`
- Test: `tests/test_review_batches.py`

**Interfaces:**
- Produces: `commit_review_batch()`, deterministic batch ID, idempotent no-op semantics, promotion receipt lineage.

- [ ] Write failing tests for atomicity/idempotency/hash lineage.
- [ ] Verify RED.
- [ ] Implement review batch transaction path.
- [ ] Verify full regression.
- [ ] Commit `feat: add atomic review batch transactions`.

### Task 6: Review and promotion queries / CLI

**Files:**
- Modify: `src/csm_runtime/query.py`
- Modify: `src/csm_runtime/cli.py`
- Test: `tests/test_review_queries.py`
- Test: `tests/test_review_cli.py`

**Interfaces:**
- Produces: review/promotion summary, pending review, per-candidate review and per-object promotion history.

- [ ] Write failing query tests.
- [ ] Implement query methods with authority/source-layer metadata.
- [ ] Write failing CLI tests.
- [ ] Implement CLI commands.
- [ ] Verify full regression.
- [ ] Commit `feat: expose review and promotion audit queries`.

### Task 7: Execute v0.3 structural review on v0.2 corpus

**Files:**
- Create: `src/csm_runtime/review_run.py`
- Test: `tests/test_real_review_v03.py`
- Generate: `evidence/v0.3/*`

**Interfaces:**
- Produces: first corpus-wide Tier-0 review, structural promotions, pending theorem/obstruction queue, replay-stable snapshot.

- [ ] Write failing integration test against the 46-artifact corpus.
- [ ] Run structural review batch.
- [ ] Promote safe Nonclaim/Frontier/Survivor records.
- [ ] Keep theorem/NO-GO candidates pending unless proof gate passes.
- [ ] Assert root NS target OPEN and cross-series auto quotient = 0.
- [ ] Verify replay exact hash.
- [ ] Commit `feat: execute NS_GSM v0.3 structural review batch`.

### Task 8: Coverage expansion and release closure

**Files:**
- Modify/add corpus manifest/evidence files only where real sources are available.
- Modify: `pyproject.toml`
- Modify: `src/csm_runtime/__init__.py`
- Create/update: `NS_GSM_CANDIDATE_REVIEW_V0.3_REPORT.md`

**Interfaces:**
- Produces: release 0.3.0, wheel, ZIP, conformance and coverage evidence.

- [ ] Expand inventory/materialization only with source-backed files.
- [ ] Generate coverage with `CONTENT_INGESTED / INVENTORIED_ONLY / MISSING_SOURCE`.
- [ ] Generate review/promotion/pending/cross-series/replay/conformance evidence.
- [ ] Run fresh full regression.
- [ ] Build wheel and isolated install smoke.
- [ ] Verify ZIP integrity and hashes.
- [ ] Commit `release: NS_GSM candidate review and promotion v0.3`.
