# NS_GSM v0.3 — Candidate Review / Promotion Design

**Date:** 2026-08-27  
**Baseline:** CSM Reference Runtime 0.2.0 / NS_GSM Full Corpus v0.2  
**Scope:** observed-relative  
**Status:** approved continuation design

## 1. Goal

Turn the v0.2 Candidate Layer into a reviewable, replayable, proof-carrying promotion workflow while preserving the core firewall:

```text
candidate evidence != review decision != native theorem authority
```

v0.3 must support real corpus review progress without allowing source labels, exact-text matches, parser confidence, or review heuristics to silently mutate theorem-level native state.

## 2. Chosen Architecture

Use a two-stage review architecture:

```text
CandidateRecord
    |
    v
ReviewRecord / ReviewDecision
    |
    +--> DEFER / DUPLICATE / NONCLAIM / FRONTIER / SURVIVOR (structural outcomes)
    |
    +--> PromotionRequest
              |
              v
        PromotionGate
              |
              v
        existing atomic transaction / ledger / replay
              |
              v
        Native Object / Status mutation
```

The review subsystem never bypasses `operators.py` or `transaction.py`.

## 3. New Canonical Objects

### 3.1 ReviewDecision

Allowed decisions:

- `PROMOTE_PROOF_ASSET`
- `PROMOTE_OBSTRUCTION`
- `PROMOTE_SURVIVOR`
- `PROMOTE_FRONTIER`
- `PROMOTE_NONCLAIM`
- `MARK_DUPLICATE`
- `REOPEN_RELATED`
- `DEFER`
- `REJECT`

### 3.2 ReviewRecord

Required fields:

- `review_id`
- `candidate_id`
- `decision`
- `reviewer_type`
- `reason`
- `scope`
- `evidence_refs`
- `certificate_refs`
- `target_native_id`
- `review_version`
- `status`

Review records are append-only via ledger events.

### 3.3 PromotionReceipt

A committed promotion stores:

- `promotion_id`
- `review_id`
- `candidate_id`
- `native_object_id`
- `promotion_class`
- `certificate_refs`
- `debt_refs`
- `event_ids`
- `state_hash_before`
- `state_hash_after`

A receipt proves that a candidate reached native state through the review + operator path.

## 4. Authority Matrix

### Structural promotions

`NONCLAIM`, `FRONTIER`, and `SURVIVOR` may be promoted as native research/audit objects when source identity, series, statement span, and declared semantics are preserved.

They must not create parent theorem closure.

### Duplicate marking

Exact source-hash duplicate or explicitly reviewed semantic duplicate may be marked `DUPLICATE`, but duplicate marking never merges theorem authority by itself.

### Proof assets

A theorem/proved candidate may become a native `CLAIM` or `PROOF_ASSET` only when:

1. source statement is explicit;
2. scope is explicit or deliberately constrained;
3. the candidate has a certificate path accepted by policy;
4. the resulting status transition is legal;
5. no source nonclaim forbids the requested promotion.

If independent verification is pending, it may be promoted only at the authority level permitted by the certificate policy, not automatically to maximal theorem authority.

### Obstructions / NO-GO

An obstruction candidate may become an `OBSTRUCTION` object after statement/scope/assumption review.

Closing a claim negative still requires the existing `close_negative` operator with a compatible negative certificate. Creating an obstruction is not the same as refuting the parent claim.

## 5. Review Tiers

### Tier 0 — deterministic structural triage

Safe machine classifications:

- exact duplicate;
- explicit nonclaim;
- explicit STOP / next frontier;
- explicit survivor role;
- source/process status that must remain non-theorem.

Tier 0 can create review records automatically, but theorem promotion is forbidden.

### Tier 1 — source-grounded semantic review

Uses parsed statement, source metadata, series profile, surrounding source context, and nonclaim constraints.

Outputs `READY_FOR_PROMOTION` or `NEEDS_REVIEW`.

### Tier 2 — proof-authority review

Required for theorem-level positive/negative closure. Requires accepted certificate path and scope compatibility.

## 6. Promotion Gate

`PromotionGate.review(record, state)` returns one of:

- `ALLOW_STRUCTURAL`
- `ALLOW_PROOF_CARRYING`
- `DEFER`
- `REFUSE`

Critical rules:

1. candidate label alone never yields `ALLOW_PROOF_CARRYING`;
2. cross-series exact text never yields automatic quotient;
3. `SURVIVOR` promotion creates `OPEN + role_tag SURVIVOR`;
4. `FRONTIER` promotion creates an `OPEN` frontier object;
5. `NONCLAIM` promotion creates an authority-boundary object;
6. obstruction promotion creates an obstruction object and does not refute parent claims;
7. theorem promotion must use existing proof-carrying status operators.

## 7. Review Ledger and Replay

NativeState gains:

- `reviews: dict[str, ReviewRecord]`
- `promotion_receipts: dict[str, PromotionReceipt]`

New ledger event types:

- `REGISTER_REVIEW`
- `UPDATE_REVIEW_STATUS`
- `REGISTER_PROMOTION_RECEIPT`

Replay must reconstruct reviews and receipts exactly.

## 8. Review Batch

A deterministic `ReviewBatch` groups candidates by series and review tier.

Batch identity is derived from:

- candidate IDs;
- source hashes;
- review policy version;
- series profile version.

Re-running the same batch is idempotent.

## 9. First v0.3 Review Batch

The first executable batch targets lower-risk structural classes across the existing 46-artifact v0.2 corpus:

1. `NonclaimCandidate`
2. `FrontierCandidate`
3. `NextFrontierCandidate`
4. `SurvivorCandidate`
5. exact duplicates / duplicate proposals

Then a small proof-authority audit batch is run only on explicit source-internal proof/no-go candidates whose source and scope can be reconstructed from the corpus.

The formal root NS target must remain OPEN throughout v0.3 unless an entirely new parent-level certificate appears; no such certificate is part of the v0.3 input corpus.

## 10. Cross-Series Review

The 219 v0.2 exact-statement proposals remain proposals.

v0.3 adds a review record with fields:

- statement match;
- series pair;
- scope match;
- assumption match;
- representation match;
- decision.

`auto_quotient` remains false by default. A reviewed duplicate may be marked duplicate without merging theorem authority; a semantic quotient still requires explicit equivalence review.

## 11. Coverage Expansion

v0.3 also expands corpus inventory/materialization where source files are available, but coverage state is always explicit:

- `CONTENT_INGESTED`
- `INVENTORIED_ONLY`
- `MISSING_SOURCE`

Coverage growth must never be reported as theorem progress.

## 12. Query Surface

Add queries:

- `review(candidate_id)`
- `reviews(series=None, decision=None)`
- `promotion(native_object_id)`
- `review-summary`
- `promotion-summary`
- `pending-review`

Every response includes source layer and authority.

## 13. CLI

Add:

- `review-summary`
- `pending-review`
- `review-candidate`
- `run-structural-review`
- `promotion-summary`

The CLI may generate review records automatically for Tier 0, but theorem-level decisions still use the promotion gate.

## 14. Conformance Requirements

v0.3 must prove by tests:

1. source `CLOSED` does not auto-promote theorem status;
2. RFP Cycle-I `CLOSED AS A RESEARCH CYCLE` remains a process-status review record;
3. explicit nonclaims can be promoted as native authority boundaries without changing parent target status;
4. STOP becomes an OPEN frontier object;
5. SURVIVOR becomes OPEN + SURVIVOR role tag;
6. obstruction object creation does not close parent claim negative;
7. theorem/no-go promotion without accepted certificate is refused/deferred;
8. review replay is deterministic;
9. review batch is idempotent;
10. promotion receipt hash lineage is exact;
11. cross-series exact matches remain no-auto-quotient;
12. root formal NS remains OPEN.

## 15. Release Evidence

v0.3 release writes:

- `review_summary.json`
- `promotion_summary.json`
- `pending_review.json`
- `review_ledger.jsonl`
- `promotion_receipts.json`
- `cross_series_review.json`
- `content_coverage_v03.json`
- `native_snapshot_v03.json`
- `replay_report_v03.json`
- `conformance_report_v03.json`

## 16. Non-Goals

v0.3 does not:

- claim all 1,460 candidates are human-verified;
- auto-prove Navier–Stokes;
- auto-quotient cross-series claims by text similarity;
- import generalized/physical NS theorem authority;
- start DCRP106 research;
- replace external theorem verification with LLM judgment.
