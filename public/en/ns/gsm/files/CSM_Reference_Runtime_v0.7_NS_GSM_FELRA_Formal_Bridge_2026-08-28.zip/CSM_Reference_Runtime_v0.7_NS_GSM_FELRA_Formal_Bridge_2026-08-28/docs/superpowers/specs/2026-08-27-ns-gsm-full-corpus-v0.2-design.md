# NS_GSM Full Corpus Ingestion v0.2 — Design Specification

**Date:** 2026-08-27  
**Status:** Approved continuation of NS_GSM v0.1  
**Base branch:** `workbench/runtime-v0.1`  
**Implementation branch:** `workbench/ns-gsm-full-corpus-v0.2`

## 1. Goal

Extend CSM Reference Runtime v0.1 from a seven-unit seed into a series-aware, manifest-driven ingestion system capable of expanding the observed-relative NS_GSM corpus without weakening the v0.1 authority firewall.

The v0.2 goal is **not** to assert that all historical Navier–Stokes research has been theorem-verified. The goal is to make large-corpus ingestion deterministic, source-grounded, resumable, series-scoped, and replayable.

## 2. Architectural Choice

Use **manifest-driven staged ingestion**.

Pipeline:

```text
Corpus Inventory
  -> Source Manifest
  -> Artifact/Series Native Registration
  -> Series-Profile Extraction
  -> Candidate Layer
  -> Validation / Promotion
  -> Series Checkpoint Transaction
  -> Frontier Rebuild
  -> Cross-Series Audit
  -> Snapshot / Replay
```

### Rejected approach A — one-shot full-text auto-ingestion

Rejected because source labels such as `CLOSED`, `NO-GO`, `PROVED`, `STOP-*`, and `SURVIVOR` are semantically heterogeneous. One-shot promotion would amplify false closure.

### Rejected approach B — fully manual per-paper encoding

Rejected because it does not scale to the historical corpus and duplicates information already present in structured front matter, status ledgers, roadmap files, dependency sections, nonclaim sections, STOP checkpoints, and `Next` blocks.

## 3. Authority Boundary

Two different ingestion authorities are required.

### Native inventory authority

The runtime may automatically commit verified file metadata as native `ARTIFACT`, `SERIES`, and `PREDECESSOR_OF` / source-lineage edges when the source identity is known.

### Candidate semantic authority

The runtime may automatically extract but **not theorem-promote**:

- status labels;
- theorem headings;
- propositions;
- NO-GO claims;
- survivor statements;
- STOP frontiers;
- nonclaims;
- next-step/frontier statements;
- dependencies.

These become deterministic candidate records first.

## 4. Corpus Scope

v0.2 expands in this order:

1. C3–C6;
2. RFP;
3. MORP;
4. selected canonical X72 checkpoints;
5. DCRP;
6. FCBP;
7. Proof Asset Map / roadmap / handoff material;
8. validation scripts where available.

RFP roadmap v1.1 explicitly records 12 Cycle-I papers and states the dangerous core is not proved empty. The ingestor must preserve cycle-level `CLOSED AS A RESEARCH CYCLE` separately from mathematical closure.

## 5. New Runtime Modules

```text
src/csm_runtime/
  corpus_manifest.py
  corpus_ingest.py
  source_parser.py
  series_profiles.py
  candidate_validation.py
  corpus_checkpoint.py
```

### `corpus_manifest.py`

Defines `CorpusSource`, `CorpusManifest`, duplicate/content identity metadata, series ordering, source hashes, source refs, and canonicality.

### `source_parser.py`

Deterministically extracts source-declared structure. No LLM. It parses:

- YAML front matter where present;
- headings;
- explicit status / epistemic_status;
- `What is NOT proved`, `Nonclaim`, `本文不主張`;
- `STOP-*`;
- `Next`;
- `Internal dependencies`;
- theorem / proposition / conjecture headings.

### `series_profiles.py`

Series-specific parsing rules without series-specific theorem authority. Profiles identify naming conventions and source-section semantics.

### `corpus_ingest.py`

Converts parsed sources into native artifact registrations and semantic candidates.

### `candidate_validation.py`

Runs deterministic validation checks and creates `PROMOTABLE`, `NEEDS_REVIEW`, or `REJECTED` candidate classifications. `PROMOTABLE` still does not mean theorem-proved unless a certificate policy permits it.

### `corpus_checkpoint.py`

Commits one series/batch at a time and emits checkpoint evidence.

## 6. Source Manifest Model

```yaml
source_id:
file_name:
series:
series_index:
cycle:
date:
version:
source_ref:
source_hash:
canonicality:
predecessor_refs: []
duplicate_of:
materialized_path:
```

`canonicality` values:

```text
CANONICAL
CHECKPOINT
HANDOFF
ROADMAP
VALIDATION
DUPLICATE
SUPERSEDED
UNKNOWN
```

## 7. Duplicate and Revision Policy

Same-name files are not automatically distinct mathematical artifacts.

Duplicate detection uses:

1. exact source hash;
2. normalized textual hash;
3. explicit version / predecessor lineage;
4. file-name suffixes such as `(1)` only as weak hints.

Exact duplicates remain in the manifest but one becomes `DUPLICATE` and points to the canonical source.

## 8. Deterministic Source Parser

The parser returns `ParsedSource`.

```python
ParsedSource(
    metadata,
    headings,
    theorem_candidates,
    status_candidates,
    obstruction_candidates,
    survivor_candidates,
    frontier_candidates,
    nonclaim_candidates,
    dependency_candidates,
    next_candidates,
)
```

Every candidate retains source line/span references when available.

## 9. Series Semantics

### C3–C6

Treat each file as a route / theorem / checkpoint source. `CLOSED` is ambiguous until local statement and evidence are classified.

### RFP

Roadmap status such as `Cycle I — CLOSED AS A RESEARCH CYCLE` is series/process metadata, never root mathematical closure. Individual papers may expose theorem-style results and finite-obstruction debts.

### MORP

Explicit `epistemic_status` and formal status ledgers are first-class extraction targets. A paper can contain simultaneous `PROVED`, `CONDITIONAL`, `OPEN`, and `NOT PROVED` statements.

### X72

`STOP-Cxx` becomes frontier candidate; `Next` becomes next-frontier candidate; `Proof-Route Experiment` remains research-level artifact authority.

### DCRP

`STOP-Dxx`, `What is NOT proved`, immediate predecessor, and scope-revision lineage are first-class fields.

### FCBP

No finite forest obstruction / coercive budget is promoted unless source-level certificate policy supports it.

## 10. Candidate Identity

Candidate IDs are deterministic hashes of:

```text
source_id | candidate_type | normalized_span | normalized_statement
```

Re-ingesting the same corpus must not duplicate candidates.

## 11. Incremental / Resumable Ingestion

Each batch stores:

- manifest hash;
- source hashes;
- parser version;
- generated candidate IDs;
- transaction IDs;
- input state hash;
- output state hash.

Re-running an unchanged batch is idempotent.

Changed sources create a new revision / supersession path instead of overwriting history.

## 12. Series Checkpoint Commit

After each series batch:

1. commit artifact identities;
2. commit candidate records;
3. commit safe lineage edges;
4. rebuild observed-relative frontier;
5. replay-check;
6. write checkpoint report.

A failed batch must not partially mutate native state.

## 13. Cross-Series Audit

Cross-series matching is **candidate-only** in v0.2.

The runtime may propose:

- same-obstruction candidates;
- same-route candidates;
- predecessor / handoff mappings;
- terminology overlaps.

It may not auto-quotient mathematical objects across series.

## 14. New Query Surfaces

Add:

```text
corpus-summary
series-summary <series>
candidates <series>
source-history <source_id>
duplicates
ingestion-checkpoint <series>
```

## 15. v0.2 Evidence Outputs

```text
evidence/v0.2/
  corpus_manifest.json
  corpus_inventory_report.json
  candidate_summary.json
  series_checkpoints/
  cross_series_candidates.json
  replay_report.json
  conformance_report.json
```

## 16. Testing

### Parser tests

Use real fixture excerpts for:

- RFP roadmap cycle status;
- MORP mixed status ledger;
- X72 STOP/Next;
- DCRP nonclaims / STOP;
- duplicate file detection.

### Authority tests

- research-cycle CLOSED never closes NS root;
- source `PROVED` creates a candidate, not a native proof;
- `STOP-D79` creates frontier candidate;
- `Navier-Stokes regularity is NOT proved` creates nonclaim candidate;
- same terminology across series never auto-quotients.

### Idempotency tests

- same manifest twice => same state hash / no duplicate events;
- one changed source => only one revision batch changes.

### Regression tests

All v0.1 52 tests must continue to pass.

## 17. Definition of Done

v0.2 is complete when:

1. v0.1 regression remains green;
2. manifest and source parser tests pass;
3. RFP / MORP / X72 / DCRP representative real-source fixtures parse correctly;
4. full accessible corpus inventory can be converted to a deterministic manifest;
5. at least one complete expansion batch beyond the seed is committed through the new batch pipeline;
6. repeated unchanged ingestion is idempotent;
7. replay hash matches stored state;
8. no source status label directly changes root theorem status;
9. cross-series matching remains candidate-only;
10. evidence package and ZIP are generated.

## 18. Non-Goals

- no LLM semantic extraction in the native pipeline;
- no automatic theorem proof verification;
- no absolute route completeness;
- no generalized / physical NS theorem promotion;
- no GUI;
- no database migration;
- no automatic cross-series quotient;
- no DCRP106 research.
