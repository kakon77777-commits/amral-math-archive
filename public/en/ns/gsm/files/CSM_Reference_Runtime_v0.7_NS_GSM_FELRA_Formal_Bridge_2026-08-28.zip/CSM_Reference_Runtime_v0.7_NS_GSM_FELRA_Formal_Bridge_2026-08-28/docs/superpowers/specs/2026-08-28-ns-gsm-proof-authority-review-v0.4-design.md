# NS_GSM v0.4 — Proof-Authority Review Batch Design

## Goal

Review a bounded, source-grounded subset of the v0.3 deferred candidate pool and convert only well-scoped, evidence-backed results into native AUDIT-level proof assets or obstruction assets without granting root Navier–Stokes theorem authority.

## Core authority rule

`SOURCE_INTERNAL_*` certificates are admissible evidence for bounded AUDIT-level assets, not independent PROOF authority. A source-internal theorem may be represented as a native `PROOF_ASSET` whose own statement is closed-positive at `AUDIT` authority. It may not close an unrelated parent target, discharge route-completeness debt, or become cross-series authority without a separate bridge/certificate.

Only a certificate with independent verifier result `VALID` may authorize `PROOF` authority.

## Curated review manifest

v0.4 does not automatically infer theorem scope from all 999 deferred candidates. It introduces `authority_review_manifest_v0.4.yaml`. Each entry binds:

- audit id;
- source artifact path and SHA-256;
- candidate id or existing native object id;
- exact reviewed statement;
- reviewed scope;
- reviewed assumptions / representation notes;
- source claim classification;
- source certificate id/type when available;
- explicit nonclaim / transfer limitations;
- verdict: `PROMOTE_AUDIT_ASSET`, `PROMOTE_AUDIT_OBSTRUCTION`, `KEEP_EXISTING_AUDIT`, `DEFER_OPEN_OBLIGATION`, `REJECT_PROMOTION`, `NARROW_SCOPE`;
- authority cap: `AUDIT` or `PROOF`;
- source line range / section anchor.

The manifest is itself hashed and versioned.

## Native records

Add `AuthorityAuditRecord` to `NativeState`:

- `audit_id`
- `subject_id`
- `subject_kind`
- `source_ref`
- `source_sha256`
- `statement`
- `scope`
- `assumptions`
- `certificate_refs`
- `nonclaim_refs`
- `verdict`
- `authority_cap`
- `reason`
- `reviewer_type`
- `audit_version`
- `status`

Add event `REGISTER_AUTHORITY_AUDIT` and deterministic replay support.

## Audit verification

`AuthorityAuditVerifier` checks:

1. source file exists and SHA-256 matches the manifest;
2. subject candidate/native object exists;
3. reviewed statement matches the subject semantics or is explicitly marked as a narrower canonical restatement;
4. scope is nonempty for theorem/no-go promotions;
5. cited certificate exists, subject-compatible, and has an accepted source status;
6. source-internal certificates cap authority at `AUDIT` unless an independent `VALID` verifier result exists;
7. explicit nonclaims cannot be contradicted;
8. `C1` and `C2` remain open proof obligations;
9. D104 fixed-positive-viscosity no-go may not transfer uniformly to epsilon -> 0;
10. no asset promotion changes `claim:formal-root-regularity` directly.

## Promotion semantics

### AUDIT proof asset

Create `ObjectRecord`:

- `object_type = PROOF_ASSET`
- `status = CLOSED_POSITIVE`
- `authority = AUDIT`
- certificate refs retained;
- metadata records reviewed scope, source audit id, and source-internal status.

This states only that the bounded reviewed mathematical asset is accepted as source-grounded audit material.

### AUDIT obstruction asset

Create `ObjectRecord`:

- `object_type = OBSTRUCTION`
- `status = OPEN`
- `authority = AUDIT`
- role tag `OBSTRUCTION`;
- metadata records the no-go statement and exact scope.

Creating the obstruction object does not block a route and never closes a parent claim. `BlockRoute` still requires an OPCert-compatible operation.

### Existing seed claims

ETN-X Proposition 8.1, D103 five-ray spectrum, D104 narrow no-go claims, and D105 nonuniformity already exist as AUDIT-authority native claims. v0.4 attaches authority audits and preserves their existing status/authority. It does not silently promote them to `PROOF`.

## First curated batch

### ETN-X

- Proposition 8.1 / Critical UV Necessity: keep existing `CLOSED_POSITIVE`, authority `AUDIT`; source says it proves blowup -> critical UV escape and explicitly does not prove global regularity.
- C1 Chain Necessity: `DEFER_OPEN_OBLIGATION`.
- C2 Finite Obstruction: `DEFER_OPEN_OBLIGATION`.

### DCRP103

Review a bounded local-algebra set centered on:

- Eigen-lock commutator equation;
- shear resonance condition;
- single-shear theorem;
- five-ray spectrum;
- Riesz-loaded coaxial response.

These may become AUDIT-level `PROOF_ASSET` objects only within the declared local simple-strain / frozen adjoint algebra scope. D103 explicitly does not claim full NS regularity.

### DCRP104

- frozen coaxial whole-space L2 no-go -> AUDIT obstruction asset;
- fixed-positive-viscosity globally frozen L2 eigen-lock no-go -> AUDIT obstruction asset;
- retain shear / axisymmetric survivors;
- preserve nonclaim against full NS regularity and uniform epsilon->0 transfer.

### DCRP105

Review bounded assets:

- simple-shear TR angular scalar;
- local Kelvin/TR compatibility witness;
- exact viscosity residual on inviscid kernel;
- fixed-band viscosity matching;
- source-level nonuniformity result.

These become AUDIT-level proof assets, while the viscosity-matched survivor and first-order solvability frontier remain OPEN.

### RFP

v0.4 selects only explicit theorem-style results whose local statement/scope can be bound without inventing missing hypotheses. Research-cycle closure, dangerous-core completion, C1/C2 completion, finite obstruction, and global regularity remain deferred.

## Batch transaction

`AuthorityReviewBatch` stages:

1. audit records;
2. new proof/obstruction assets;
3. promotion receipts;
4. an authority-review checkpoint.

All are committed atomically. Re-running the same manifest is `IDEMPOTENT_NOOP`.

## Query surface

Add:

- `authority_audit(id)`;
- `authority_audits(subject_id=None)`;
- `proof_assets(series=None)`;
- `obstruction_assets(series=None)`;
- `authority_summary()`.

All results carry source layer and authority metadata.

## Release invariants

- root formal NS remains `OPEN`;
- C1/C2 remain `OPEN`;
- route/representation completeness debts remain open;
- source-internal certs never create `PROOF` authority without an independent verifier;
- D104 narrow no-go remains narrow;
- D105 survivor/frontier remain open;
- no automatic cross-series quotient;
- full ledger replay hash equals native snapshot hash;
- second authority-review batch is idempotent.
