# NS_GSM v0.7 FELRA Formal Proof Bridge Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement an artifact-based NS_GSM↔FELRA Lean bridge that can export D103 FIR assets as translation-locked Lean obligations, import fail-closed FELRA formal evidence, and attach `FORMAL_PROOF[lean]` only when translation, kernel run, axiom policy, and content identity all validate.

**Architecture:** NS_GSM owns theorem identity, FIR, translation, bridge manifests, canonical import records, and authority semantics. FELRA remains an external artifact/subprocess executor; NS_GSM never depends on FELRA Python internals for canonical semantics. `FORMAL_PROOF` is an orthogonal tier and never changes `ClosureStatus`, parent status, C1/C2, or the formal NS root.

**Tech Stack:** Python 3.11+, standard library, PyYAML, SymPy 1.14, pytest; external FELRA 1.8.1-compatible `formal_check` contract; Lean execution is external/optional in this environment.

**Spec:** `docs/superpowers/specs/2026-08-28-ns-gsm-felra-formal-proof-bridge-v0.7-design.md`

## Global Constraints

- Bridge protocol is `NSGSM-FELRA/0.1`.
- NS_GSM must not import FELRA Python internals as canonical runtime semantics.
- `FELRA success != FELRA formal_status`.
- `FELRA certificate integrity != fresh kernel run`.
- `Lean verified != FIR translation faithful`; a `VALID` translation certificate is separately required.
- Canonical state excludes absolute local paths, hostnames, duration, raw stdout/stderr, and temporary directories.
- `FORMAL_PROOF` is a tier only; it does not change base `Authority.PROOF` or `ClosureStatus`.
- `FORMAL_PROOF[lean]` never propagates to parents or route/root closure.
- Root formal NS, C1, and C2 remain `OPEN`.
- Initial target set is exactly D103.1–D103.5.
- If no real Lean/FELRA kernel run is available, release mode is `BRIDGE_READY` and `FORMAL_PROOF count = 0`.
- Coq backend work is out of Plan A scope.

---

### Task 1: Canonical bridge records and replay

**Files:**
- Modify: `src/csm_runtime/model.py`
- Modify: `src/csm_runtime/state.py`
- Test: `tests/test_v07_bridge_model.py`

**Interfaces:**
- Produces: `TranslationCertificateRecord`, `FormalObligationRecord`, `FELRAFormalRunRecord`, `KernelFormalProofReceipt`.
- Produces state registries: `translation_certificates`, `formal_obligations`, `felra_formal_runs`, `kernel_formal_proof_receipts`.

- [ ] **Step 1: Write failing round-trip/replay test**

```python
def test_v07_bridge_records_round_trip_and_replay():
    state = NativeState()
    # register one record of each new type through ledger events
    # assert native_state_from_dict(state.to_dict()).to_dict() == state.to_dict()
    # assert replayed hash == committed hash
```

- [ ] **Step 2: Run RED**

Run: `pytest -q tests/test_v07_bridge_model.py`

Expected: missing record/registry imports.

- [ ] **Step 3: Implement records, serializers, loaders, reducers**

Add events:

```text
REGISTER_TRANSLATION_CERTIFICATE
REGISTER_FORMAL_OBLIGATION
REGISTER_FELRA_FORMAL_RUN
REGISTER_KERNEL_FORMAL_PROOF_RECEIPT
```

Canonical `FELRAFormalRunRecord` must not serialize local execution path, command, duration, or raw transcript.

- [ ] **Step 4: Run GREEN + canonical/replay regression**

Run: `pytest -q tests/test_v07_bridge_model.py tests/test_canonical.py tests/test_replay.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/model.py src/csm_runtime/state.py tests/test_v07_bridge_model.py
git commit -m "feat: add replayable FELRA bridge records"
```

### Task 2: FIR-to-Lean translation profile and translation certificate

**Files:**
- Create: `src/csm_runtime/lean_translation.py`
- Test: `tests/test_v07_lean_translation.py`

**Interfaces:**
- Consumes: v0.6 `FormalizationRecord` + FIR bundle.
- Produces: `translate_fir_to_lean(bundle, *, subject_id) -> LeanTranslationResult`.
- Produces: `validate_lean_translation(bundle, result) -> TranslationCertificateRecord`.

- [ ] **Step 1: Write failing tests for D103.1–D103.5 and unsupported FIR**

```python
def test_d103_translation_is_deterministic_and_valid():
    result = translate_fir_to_lean(bundle, subject_id=subject)
    cert = validate_lean_translation(bundle, result)
    assert cert.status == "VALID"
    assert cert.fir_sha256 == bundle_sha
    assert cert.obligation_sha256 == sha256(result.source)


def test_unsupported_translation_defers():
    result = translate_fir_to_lean(unsupported_bundle, subject_id="x")
    assert result.status == "DEFER"
```

Also assert statement mutation invalidates translation and proof-body-only mutation leaves the theorem-signature digest unchanged while changing obligation/project digest.

- [ ] **Step 2: Run RED**

Run: `pytest -q tests/test_v07_lean_translation.py`

- [ ] **Step 3: Implement minimal `lean-v0.1` profile**

Supported initial constructs are only those needed for D103.1–D103.5. Translation must emit stable theorem names derived from v0.6 case IDs, explicit assumptions, target signatures, and an axiom-audit footer (`#print axioms`). No arbitrary FIR fallback is allowed.

- [ ] **Step 4: Run GREEN**

Run: `pytest -q tests/test_v07_lean_translation.py tests/test_v06_formalization.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/lean_translation.py tests/test_v07_lean_translation.py
git commit -m "feat: translate D103 FIR to Lean obligations"
```

### Task 3: Deterministic bridge export bundle

**Files:**
- Create: `src/csm_runtime/felra_bridge.py`
- Test: `tests/test_v07_bridge_export.py`

**Interfaces:**
- Produces: `export_felra_bridge(state, subject_id, output_dir) -> BridgeExportResult`.
- Produces files: `ns_gsm_bridge_manifest.json`, `fir.json`, `translation.json`, `lean/obligation.lean`, `felra/project.yaml`.

- [ ] **Step 1: Write failing location-independence/export-contract tests**

Assert two output directories produce identical bridge identity hashes and semantically identical manifests. Assert exported project contains `backend: lean`, `expect: verified`, `derives_from`, assumptions/limitations, and explicit `axioms_within`.

- [ ] **Step 2: Run RED**

Run: `pytest -q tests/test_v07_bridge_export.py`

- [ ] **Step 3: Implement deterministic exporter**

`project_digest_sha256` must cover obligation source, generated support modules/toolchain/config content that influence proof meaning, but never absolute paths. The manifest selects only known backend `lean`; it must reject arbitrary shell command fields.

- [ ] **Step 4: Run GREEN**

Run: `pytest -q tests/test_v07_bridge_export.py tests/test_v07_lean_translation.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/felra_bridge.py tests/test_v07_bridge_export.py
git commit -m "feat: export deterministic NS_GSM FELRA bridge bundles"
```

### Task 4: Fail-closed FELRA formal-result importer

**Files:**
- Create: `src/csm_runtime/felra_import.py`
- Create: `tests/fixtures/felra_v07/verified.json`
- Create: `tests/fixtures/felra_v07/unknown_sorry.json`
- Create: `tests/fixtures/felra_v07/unavailable.json`
- Create: `tests/fixtures/felra_v07/refuted.json`
- Create: `tests/fixtures/felra_v07/axiom_overflow.json`
- Create: `tests/fixtures/felra_v07/vacuous_axiom_audit.json`
- Create: `tests/fixtures/felra_v07/hash_mismatch.json`
- Test: `tests/test_v07_felra_import.py`

**Interfaces:**
- Produces: `import_felra_formal_result(bridge_manifest, translation, payload, certificate=None) -> FELRAImportDecision`.
- Produces canonical `FELRAFormalRunRecord` only for structurally valid payloads.

- [ ] **Step 1: Write fixture-driven RED tests**

Verified fixture must pass only when:

```text
kind=formal_check
formal_status=verified
expected_formal_status=verified
expectation_met=true
backend=lean
obligation.sha256 matches
checker version/hash present
axiom audit non-vacuous and within allowlist
```

All other fixtures must `DEFER` or `REFUSE` and never become proof-eligible.

- [ ] **Step 2: Run RED**

Run: `pytest -q tests/test_v07_felra_import.py`

- [ ] **Step 3: Implement importer and certificate-integrity validation**

Normalize FELRA 1.8.1-compatible fields. Strip machine-local path, command, duration, and stdout/stderr from canonical record. If an `external_formal` certificate is supplied, verify its digest/integrity separately; certificate validity alone must not make the decision proof-eligible.

- [ ] **Step 4: Run GREEN**

Run: `pytest -q tests/test_v07_felra_import.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/felra_import.py tests/fixtures/felra_v07 tests/test_v07_felra_import.py
git commit -m "feat: import FELRA formal evidence fail closed"
```

### Task 5: Kernel formal-proof promotion gate

**Files:**
- Create: `src/csm_runtime/kernel_formal_batch.py`
- Test: `tests/test_v07_kernel_formal_gate.py`

**Interfaces:**
- Produces: `commit_kernel_formal_proof(state, ledger, translation, obligation, formal_run, *, batch_id) -> KernelFormalBatchResult`.

- [ ] **Step 1: Write failing atomicity/non-propagation tests**

A valid D103 child must receive:

```text
authority tier: FORMAL_PROOF
certificate type: KERNEL_FORMAL_PROOF
receipt backend: lean
```

while base authority remains `PROOF`, child status remains unchanged, and root/C1/C2 statuses remain `OPEN`.

Reject or defer on translation mismatch, stale state, wrong backend, missing checker hash, empty axiom audit, unexpected axiom, or non-verified run. Reapplying the same batch must be an idempotent no-op.

- [ ] **Step 2: Run RED**

Run: `pytest -q tests/test_v07_kernel_formal_gate.py`

- [ ] **Step 3: Implement atomic gate**

Register `KERNEL_FORMAL_PROOF` certificate, `FELRAFormalRunRecord`, `KernelFormalProofReceipt`, and `ADD_AUTHORITY_TIER` in one transaction. No graph edge/status mutation is allowed.

- [ ] **Step 4: Run GREEN**

Run: `pytest -q tests/test_v07_kernel_formal_gate.py tests/test_v06_tier_batch.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/kernel_formal_batch.py tests/test_v07_kernel_formal_gate.py
git commit -m "feat: gate kernel formal proof authority"
```

### Task 6: D103 five-target bridge batch and bridge-ready integration

**Files:**
- Create: `src/csm_runtime/felra_bridge_run.py`
- Test: `tests/test_v07_bridge_run.py`

**Interfaces:**
- Produces: `run_v07_felra_bridge(root, evidence_dir, felra_results_dir=None) -> V07BridgeRunResult`.

- [ ] **Step 1: Write failing five-target integration test**

Without real FELRA results, assert:

```text
5 bridge exports
5 VALID translation certificates
5 FormalObligationRecords
FORMAL_PROOF count = 0
release_mode = BRIDGE_READY
root/C1/C2 remain OPEN
replay exact
second run idempotent
```

With a verified fixture for one target, assert exactly one bounded child gets `FORMAL_PROOF[lean]` and nothing propagates.

- [ ] **Step 2: Run RED**

Run: `pytest -q tests/test_v07_bridge_run.py`

- [ ] **Step 3: Implement runner**

Runner consumes the v0.6 frozen closure state, exports D103.1–D103.5 bridge bundles, optionally imports supplied FELRA result artifacts, applies proof tiers through Task 5 gate, rebuilds replay state, and reports `BRIDGE_READY` versus `FORMAL_PROOF_ACTIVE`.

- [ ] **Step 4: Run GREEN**

Run: `pytest -q tests/test_v07_bridge_run.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/felra_bridge_run.py tests/test_v07_bridge_run.py
git commit -m "feat: execute D103 FELRA bridge batch"
```

### Task 7: Query, CLI, and evidence package

**Files:**
- Modify: `src/csm_runtime/query.py`
- Modify: `src/csm_runtime/cli.py`
- Create: `src/csm_runtime/v07_evidence.py`
- Test: `tests/test_v07_queries_cli.py`
- Test: `tests/test_v07_evidence.py`

**Interfaces:**
- Query methods: `formalization_bridges()`, `translation_certificates()`, `formal_obligations()`, `felra_formal_runs()`, `kernel_formal_proofs()`, `formal_proof_deferred()`.
- CLI: `run-felra-bridge`, `export-felra-bridge`, `import-felra-formal-result`, plus read-only audit commands.
- Evidence writer: `write_v07_evidence(run_result, evidence_dir)`.

- [ ] **Step 1: Write RED query/CLI/evidence tests**

Evidence directory must contain:

```text
bridge_manifest.json
translations.json
formal_obligations.json
felra_formal_runs.json
kernel_formal_proof_receipts.json
formal_proof_assets.json
formal_proof_deferred.json
kernel_revalidation.json
replay_report.json
conformance_report.json
run_summary.json
```

In a no-Lean build environment conformance must explicitly report `FORMAL_PROOF count = 0`, not omit the field.

- [ ] **Step 2: Run RED**

Run query and evidence tests separately if harness timeout requires it.

- [ ] **Step 3: Implement audit surface and evidence writer**

Raw FELRA outputs may be copied under `felra_raw/` but must never enter native state hash.

- [ ] **Step 4: Run GREEN**

Run: `pytest -q tests/test_v07_queries_cli.py`

Run: `pytest -q tests/test_v07_evidence.py`

- [ ] **Step 5: Commit**

```bash
git add src/csm_runtime/query.py src/csm_runtime/cli.py src/csm_runtime/v07_evidence.py tests/test_v07_queries_cli.py tests/test_v07_evidence.py
git commit -m "feat: expose v0.7 FELRA bridge evidence"
```

### Task 8: Release closure

**Files:**
- Modify: `src/csm_runtime/__init__.py`
- Modify: `pyproject.toml`
- Modify: `README.md`
- Create: `NS_GSM_FELRA_FORMAL_BRIDGE_V0.7_REPORT.md`
- Create generated evidence under: `evidence/v0.7/`
- Test: `tests/test_v07_version.py`

**Interfaces:**
- Runtime version: `0.7.0`.
- Release modes: `BRIDGE_READY` or `FORMAL_PROOF_ACTIVE`.

- [ ] **Step 1: Write RED version test and update to 0.7.0**

Assert `csm_runtime.__version__ == "0.7.0"` and `pyproject.toml` matches.

- [ ] **Step 2: Freeze source-tree v0.7 evidence**

Run the full D103 bridge export. If real FELRA+Lean output is unavailable, freeze `BRIDGE_READY` with five valid translations and zero formal proofs. If one or more real verified outputs are supplied, import them and record the exact count.

- [ ] **Step 3: Run complete regression in mutually exclusive file shards**

The union of shards must equal `pytest --collect-only -q` exactly; every shard exits zero.

- [ ] **Step 4: Build deterministic 0.7.0 wheel and installed-target smoke**

Use fixed `SOURCE_DATE_EPOCH`; build twice and require identical wheel SHA-256. Install/copy wheel to an isolated target outside repo and run bridge/export/query smoke from there. Installed output must reproduce the same bridge state hash as source-tree freeze.

- [ ] **Step 5: Commit release tree and verify again**

Commit source/tests/docs/evidence metadata, then repeat regression shards and installed-wheel smoke against the release commit.

- [ ] **Step 6: Package external artifacts**

Create source/tests/corpus/evidence ZIP excluding `.git` and caches; run `ZipFile.testzip()`; write external release manifest containing final commit, state hash, wheel hash, ZIP hash, FELRA contract version, and `FORMAL_PROOF` count.

---

## Plan Self-Review

- Spec coverage: canonical bridge records, translation, export, FELRA import, formal-proof gate, D103 batch, BRIDGE_READY fallback, query/CLI/evidence, deterministic packaging, and no-parent-propagation are all mapped to tasks.
- Scope: Coq backend Plan B is intentionally excluded.
- Type consistency: record/function names are fixed above and reused consistently.
- Placeholder scan: no placeholder markers or unspecified production steps remain.
- Release behavior is explicit when Lean/FELRA are unavailable: software bridge may complete, but `FORMAL_PROOF count = 0` remains mandatory.
