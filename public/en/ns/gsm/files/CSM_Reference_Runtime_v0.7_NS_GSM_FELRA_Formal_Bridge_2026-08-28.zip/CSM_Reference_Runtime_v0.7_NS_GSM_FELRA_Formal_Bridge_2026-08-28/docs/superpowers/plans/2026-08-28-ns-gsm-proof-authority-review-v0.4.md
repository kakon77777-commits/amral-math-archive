# NS_GSM v0.4 Proof-Authority Review Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add source-hash/scope/certificate authority auditing and run the first curated proof-authority review batch over ETN-X, DCRP103-105, and selected RFP assets.

**Architecture:** Extend the v0.3 event-sourced runtime with an `AuthorityAuditRecord` registry and an atomic `AuthorityReviewBatch`. Curated manifest entries are verified against source hashes and bounded source-internal certificates; source-internal results may create AUDIT-level assets but never independent PROOF authority or root NS closure.

**Tech Stack:** Python 3.11+, standard library, PyYAML, pytest.

**Spec:** `docs/superpowers/specs/2026-08-28-ns-gsm-proof-authority-review-v0.4-design.md`

## Global Constraints

- Root formal NS remains OPEN.
- C1/C2 remain OPEN proof obligations.
- Source-internal certificates cap at AUDIT unless an independent verifier result is VALID.
- Obstruction asset creation does not block routes or refute parent claims.
- D104 fixed-positive-viscosity no-go cannot silently transfer to epsilon -> 0.
- D105 survivor/frontier remain OPEN.
- All mutations are event-sourced, atomic, deterministic, replayable, and idempotent.
- No automatic cross-series quotient.

---

### Task 1: Authority audit state + replay

**Files:** `src/csm_runtime/model.py`, `src/csm_runtime/replay.py`, `tests/test_authority_audit_state.py`

- [ ] Write failing tests for `AuthorityAuditRecord` round-trip and `REGISTER_AUTHORITY_AUDIT` replay.
- [ ] Run focused tests and confirm red.
- [ ] Implement the record, `NativeState.authority_audits`, serialization, and replay reducer.
- [ ] Run focused + full tests.
- [ ] Commit.

### Task 2: Manifest loader + source integrity verifier

**Files:** `src/csm_runtime/authority_manifest.py`, `src/csm_runtime/authority_audit.py`, `tests/test_authority_manifest.py`

- [ ] Write failing tests for deterministic manifest hash, source SHA mismatch refusal, missing scope defer, C1/C2 open enforcement.
- [ ] Run red.
- [ ] Implement loader/verifier with verdict enum and authority cap.
- [ ] Run green + full tests.
- [ ] Commit.

### Task 3: Certificate trust-cap policy

**Files:** `src/csm_runtime/authority_audit.py`, `src/csm_runtime/operators.py`, `tests/test_authority_certificate_cap.py`

- [ ] Test SOURCE_INTERNAL cert -> maximum AUDIT authority.
- [ ] Test independent verifier `VALID` + proof cert -> PROOF authority eligible.
- [ ] Test source-internal no-go cannot directly block unrelated route / root claim.
- [ ] Implement `certificate_authority_cap()` and compatibility checks.
- [ ] Run full tests and commit.

### Task 4: Proof/obstruction asset promotion

**Files:** `src/csm_runtime/promotion.py`, `src/csm_runtime/authority_batch.py`, `tests/test_authority_promotion.py`

- [ ] Test AUDIT proof asset = `PROOF_ASSET/CLOSED_POSITIVE/AUDIT`.
- [ ] Test AUDIT obstruction = `OBSTRUCTION/OPEN/AUDIT` and parent status unchanged.
- [ ] Test existing seed claim audit preserves status/authority.
- [ ] Test atomic batch rollback and idempotency.
- [ ] Implement promotion + receipts + checkpoint.
- [ ] Run full tests and commit.

### Task 5: Curated ETN-X + D103-105 manifest

**Files:** `authority_review_manifest_v0.4.yaml`, `tests/test_v04_curated_core_batch.py`

- [ ] Add source hashes and reviewed entries for ETN-X Proposition 8.1, C1, C2, D103 bounded algebra assets, D104 narrow no-go assets, D105 bounded residual/compatibility assets.
- [ ] Test source hashes, verdicts, scope caps, C1/C2 defer, D104 nonuniform transfer guard, D105 survivor/frontier preservation.
- [ ] Run batch and full tests.
- [ ] Commit.

### Task 6: Selected RFP proof-authority batch

**Files:** extend manifest; `tests/test_v04_rfp_batch.py`

- [ ] Select only explicit theorem-style source statements with bounded local scope.
- [ ] Assert research-cycle closure / dangerous-core / finite obstruction / root regularity remain deferred.
- [ ] Promote selected source-internal results to AUDIT-level proof assets only.
- [ ] Run full tests and commit.

### Task 7: Query/CLI/evidence/release

**Files:** `src/csm_runtime/query.py`, `src/csm_runtime/cli.py`, `src/csm_runtime/authority_run.py`, release evidence/docs/tests.

- [ ] Add authority-audit and proof/obstruction query tests.
- [ ] Add `run-proof-authority-review` CLI test.
- [ ] Generate v0.4 ledger, native snapshot, authority audits, proof assets, obstruction assets, deferred list, conformance, replay and idempotency reports.
- [ ] Bump package to 0.4.0.
- [ ] Fresh full regression.
- [ ] Build wheel and isolated installed-wheel smoke.
- [ ] Package ZIP and verify `testzip()`.
- [ ] Commit release and run post-commit full regression.
