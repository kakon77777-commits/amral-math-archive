# NS_GSM v0.5 — Independent Verification and Authority Upgrade Design

**Date:** 2026-08-28
**Baseline:** CSM Reference Runtime 0.4.0 / NS_GSM v0.4
**Goal:** Independently verify bounded v0.4 proof/obstruction assets and upgrade only exactly verified assets from `AUDIT` to `PROOF` authority.

## 1. Safety Boundary

`source-internal theorem` is not an independent proof certificate. v0.5 introduces a separate verification registry and requires every authority upgrade to bind:

- existing native asset id;
- exact asset statement and reviewed scope;
- verifier id/version;
- verifier kind;
- deterministic input hash;
- proof/check artifact hash;
- result `VALID | PARTIAL | FAILED | DEFER`;
- explicit limitations.

No verification event may mutate the formal NS root, C1, C2, a parent route, or any sibling asset.

## 2. Verification Classes

### `SYMBOLIC_EXACT`
Exact algebraic verification using deterministic SymPy expressions and exact arithmetic. Eligible for `PROOF` when it checks the entire bounded asset statement under the asset's declared assumptions.

### `EXACT_WITNESS`
Exact construction/substitution proving an existence or compatibility witness. Eligible for `PROOF` only for the witness-level statement.

### `ANALYTIC_SCHEMA`
A deterministic proof-schema checker for a standard finite chain of analytic facts (e.g. quadratic minimization or support inequality). It is eligible for `PROOF` only when the schema covers the full bounded theorem statement and no hidden PDE premise is introduced.

### `GRAPH_THEOREM_REDUCTION`
Checks exact reduction to a standard abstract theorem such as the finitely-branching infinity principle. Eligible for `PROOF` for the abstract graph theorem, not for unverified upstream PDE premises.

### `CORPUS_AUDIT`
Checks a statement relative to the current corpus inventory/coverage. It remains `AUDIT`; it cannot become mathematical `PROOF` authority.

## 3. Canonical State Objects

Add `IndependentVerificationRecord`:

```text
verification_id
subject_id
verifier_id
verifier_kind
verifier_version
statement
scope
input_sha256
proof_artifact_sha256
result
limitations[]
evidence_refs[]
verified_at_version
```

Add `AuthorityUpgradeReceipt`:

```text
upgrade_id
verification_id
subject_id
old_authority
new_authority
certificate_id
state_hash_before
state_hash_after
event_ids[]
```

Both records are event-sourced and replayable.

## 4. Independent Certificate

A successful full verification creates a new `CertificateRecord`:

```text
certificate_type = INDEPENDENT_<VERIFIER_KIND>
status = VALID
subject_ids = [asset_id]
verifier_results = [{verifier_id, verifier_version, result=VALID, proof_artifact_sha256}]
```

The pre-existing source-internal certificate remains attached and is never overwritten.

## 5. Upgrade Rule

`AUDIT -> PROOF` is allowed iff:

1. asset exists and currently has `authority=AUDIT`;
2. verification subject matches the exact asset id;
3. verification result is `VALID`;
4. statement and scope match the asset's reviewed statement/scope;
5. proof/check artifact hash is present;
6. verifier kind is proof-eligible;
7. verification limitations do not narrow below the native asset statement;
8. new independent certificate is registered in the same atomic transaction.

`PARTIAL`, `FAILED`, `DEFER`, or `CORPUS_AUDIT` never upgrade authority.

## 6. v0.5 Verification Batch

The first batch targets the 12 v0.4 proof assets plus the v0.4 obstruction asset, but does not require every target to upgrade.

### D103
- D103.1 commutator equation — `SYMBOLIC_EXACT`
- D103.2 shear resonance — `SYMBOLIC_EXACT`
- D103.3 single-shear theorem — `SYMBOLIC_EXACT`
- D103.4 five-ray spectrum — `SYMBOLIC_EXACT`
- D103.5 Riesz-loaded coaxial response — `SYMBOLIC_EXACT`

### D105
- D105.1 simple-shear TR angular scalar — `SYMBOLIC_EXACT` if full kernel differentiation check succeeds; otherwise `PARTIAL`
- D105.2 local Kelvin/TR compatibility witness — `EXACT_WITNESS`
- D105.3 exact viscosity residual — `SYMBOLIC_EXACT`
- D105.4 fixed-band viscosity matching — `ANALYTIC_SCHEMA`

### RFP
- RFP-05 Theorem 32.1 Infinite Path Extraction — `GRAPH_THEOREM_REDUCTION`
- RFP-10 Theorem 42.1 Current Finite-Obstruction Incompleteness — `CORPUS_AUDIT`, never PROOF-upgraded in v0.5
- RFP-12 Theorem 12.1 Exact Spectral-Variance Identity — `ANALYTIC_SCHEMA`
- RFP-12 Theorem 19.1 Frequency-Norm Synchronization No-Go obstruction — independent mathematical audit / constructive schema; upgrade only if the exact schema verifier succeeds.

### ETN-X seed claim
The existing `claim:uv-escape-necessity` is separately eligible for an independent analytic audit of Proposition 8.1. Because it is not one of the v0.4 generated proof assets, v0.5 may add an independent certificate and upgrade only that bounded native claim's authority; C1/C2 remain OPEN.

## 7. No Parent Propagation

Even if every bounded asset above reaches `PROOF`:

```text
root formal NS = OPEN
C1 = OPEN
C2 = OPEN
```

No automatic implication propagation or route exhaustion is added in v0.5.

## 8. Evidence

Release evidence includes:

- `independent_verifications_v05.json`
- `authority_upgrades_v05.json`
- `verified_assets_v05.json`
- `partial_or_deferred_v05.json`
- `verifier_manifest_v05.json`
- proof/check artifacts under `evidence/v0.5/verifiers/`
- full ledger and native snapshot
- exact replay report
- conformance report

## 9. Definition of Done

- existing v0.4 regression remains green;
- verification records replay deterministically;
- no failed/partial/deferred verification can upgrade authority;
- every PROOF upgrade has a new independent certificate and hashed proof/check artifact;
- root/C1/C2 remain OPEN;
- installed-wheel smoke reproduces the frozen state hash;
- release ZIP passes integrity check.
