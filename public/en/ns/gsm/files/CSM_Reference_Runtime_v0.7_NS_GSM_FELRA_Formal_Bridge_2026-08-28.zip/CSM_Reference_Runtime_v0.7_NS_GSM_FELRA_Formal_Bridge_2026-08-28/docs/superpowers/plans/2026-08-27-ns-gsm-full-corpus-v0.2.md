# NS_GSM Full Corpus Ingestion v0.2 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add deterministic, manifest-driven, series-aware, resumable NS_GSM corpus ingestion while preserving all v0.1 closure-authority invariants.

**Architecture:** Add a corpus manifest layer, deterministic Markdown source parser, series profiles, candidate-only semantic extraction, idempotent batch ingestion, and series checkpoint evidence. Inventory/lineage can be native; semantic theorem/status extraction stays candidate-only unless existing proof-carrying policy explicitly promotes it.

**Tech Stack:** Python 3.11+, standard library, PyYAML, pytest.

**Spec:** `docs/superpowers/specs/2026-08-27-ns-gsm-full-corpus-v0.2-design.md`

## Global Constraints

- All 52 v0.1 tests remain passing.
- Source status labels never directly mutate theorem status.
- RFP `CLOSED AS A RESEARCH CYCLE` is process metadata, not mathematical closure.
- Cross-series equivalence remains candidate-only.
- Ingestion is idempotent and replayable.
- No LLM, database, GUI, theorem prover, or DCRP106 research.

---

### Task 1: Corpus manifest and duplicate identity

**Files:**
- Create: `src/csm_runtime/corpus_manifest.py`
- Test: `tests/test_corpus_manifest.py`

**Interfaces:**
- Produces `CorpusSource`, `CorpusManifest`, `build_manifest()`, `deduplicate_manifest()`, `manifest_hash()`.

- [ ] Write tests for exact duplicate hash, canonical duplicate pointer, deterministic sort, and manifest hash.
- [ ] Run `pytest tests/test_corpus_manifest.py -q` and verify failure.
- [ ] Implement dataclasses and deterministic hashing.
- [ ] Run tests and verify pass.
- [ ] Commit `feat: add deterministic corpus manifest`.

### Task 2: Deterministic Markdown source parser

**Files:**
- Create: `src/csm_runtime/source_parser.py`
- Test: `tests/test_source_parser.py`
- Create: `tests/fixtures/corpus_excerpt/`

**Interfaces:**
- Produces `ParsedSource`, `ParsedCandidate`, `parse_markdown_source(text, source_id, profile)`.

- [ ] Add real-source fixture excerpts for RFP roadmap, MORP status ledger, X72 STOP/Next, DCRP nonclaim/STOP.
- [ ] Test front matter, theorem headings, status labels, nonclaims, dependencies, STOP, and Next extraction.
- [ ] Implement parser without LLM or semantic guessing.
- [ ] Verify deterministic candidate IDs.
- [ ] Commit `feat: parse source-declared corpus semantics`.

### Task 3: Series profiles

**Files:**
- Create: `src/csm_runtime/series_profiles.py`
- Test: `tests/test_series_profiles.py`

**Interfaces:**
- Produces `SeriesProfile`, `profile_for_filename()`, explicit profiles for C, RFP, MORP, X72, DCRP, FCBP.

- [ ] Test filename/metadata profile routing.
- [ ] Test RFP cycle-closure safety metadata.
- [ ] Test X72/DCRP STOP semantics.
- [ ] Implement minimal profiles.
- [ ] Commit `feat: add NS_GSM series ingestion profiles`.

### Task 4: Candidate-only corpus ingestion

**Files:**
- Create: `src/csm_runtime/corpus_ingest.py`
- Modify: `src/csm_runtime/model.py`
- Modify: `src/csm_runtime/state.py`
- Test: `tests/test_corpus_ingest.py`

**Interfaces:**
- Produces `CorpusIngestionBatch`, `build_corpus_batch()`, `apply_corpus_batch()`.
- Native Artifact/Series records may be registered automatically; semantic extraction becomes Candidate records.

- [ ] Test that `PROVED`, `CLOSED`, `NO-GO`, `STOP` never directly close root claims.
- [ ] Test candidate registration is deterministic and idempotent.
- [ ] Add candidate registry to NativeState or a separate state field serialized canonically.
- [ ] Implement candidate events and replay handling.
- [ ] Commit `feat: add candidate-only corpus ingestion`.

### Task 5: Batch checkpoint transactions and idempotency

**Files:**
- Create: `src/csm_runtime/corpus_checkpoint.py`
- Modify: `src/csm_runtime/ledger.py`
- Test: `tests/test_corpus_checkpoint.py`

**Interfaces:**
- Produces `IngestionCheckpoint`, `commit_corpus_batch()`, `checkpoint_hash()`.

- [ ] Test unchanged batch re-run yields no duplicate committed events.
- [ ] Test changed source creates revision/supersession metadata.
- [ ] Test failed batch leaves state/ledger unchanged.
- [ ] Implement checkpoint event identity derived from manifest/parser/source hashes.
- [ ] Commit `feat: add resumable corpus checkpoints`.

### Task 6: Candidate validation and cross-series proposals

**Files:**
- Create: `src/csm_runtime/candidate_validation.py`
- Test: `tests/test_candidate_validation.py`

**Interfaces:**
- Produces `ValidationClass` = `PROMOTABLE | NEEDS_REVIEW | REJECTED`; cross-series proposal records remain non-native equivalence candidates.

- [ ] Test process-level RFP CLOSED is `NEEDS_REVIEW` for theorem closure.
- [ ] Test explicit nonclaim blocks incompatible promotion.
- [ ] Test same terminology across series does not auto-quotient.
- [ ] Implement deterministic validation rules.
- [ ] Commit `feat: validate corpus candidates without authority inflation`.

### Task 7: Corpus queries and CLI

**Files:**
- Modify: `src/csm_runtime/query.py`
- Modify: `src/csm_runtime/cli.py`
- Test: `tests/test_corpus_queries.py`

**Interfaces:**
- Adds `corpus-summary`, `series-summary`, `candidates`, `source-history`, `duplicates`, `ingestion-checkpoint`.

- [ ] Write failing query/CLI tests.
- [ ] Implement authority-carrying result payloads.
- [ ] Run focused tests.
- [ ] Commit `feat: add corpus ingestion queries`.

### Task 8: Build expanded NS_GSM corpus package

**Files:**
- Create: `fixtures/NS_GSM_Corpus_v0.2/`
- Create: `evidence/v0.2/`
- Test: `tests/test_real_corpus_v02.py`

**Interfaces:**
- Consumes materialized source files and a generated manifest.
- Produces deterministic corpus inventory, candidate summary, series checkpoints, native snapshot, ledger, replay report.

- [ ] Materialize accessible C3-C6/RFP/MORP/X72/DCRP/FCBP sources selected by manifest discovery.
- [ ] Build deterministic manifest.
- [ ] Run at least one complete series expansion beyond seed through checkpoint commit.
- [ ] Verify root NS target remains OPEN.
- [ ] Verify replay exact match.
- [ ] Commit `feat: ingest expanded NS_GSM corpus v0.2`.

### Task 9: Full regression, evidence, packaging

**Files:**
- Modify: `README.md`
- Create: `evidence/v0.2/conformance_report.json`
- Create: `evidence/v0.2/replay_report.json`
- Create: `NS_GSM_FULL_CORPUS_V0.2_REPORT.md`

- [ ] Run `pytest -q`; all v0.1 and v0.2 tests must pass.
- [ ] Run corpus ingestion twice and verify idempotency.
- [ ] Run replay and compare exact state hash.
- [ ] Generate inventory/candidate/checkpoint reports.
- [ ] Build wheel and smoke install if environment allows.
- [ ] Create ZIP and verify `zipfile.testzip() is None`.
- [ ] Commit `release: NS_GSM full corpus ingestion v0.2`.

## Plan Self-Review

- Spec coverage includes discovery, duplicates, parser, series profiles, candidate firewall, idempotent checkpointing, validation, queries, real-corpus batch, replay, evidence, and packaging.
- v0.1 authority invariants remain unchanged.
- Cross-series quotient remains intentionally deferred.
- No placeholder implementation requirements remain.
