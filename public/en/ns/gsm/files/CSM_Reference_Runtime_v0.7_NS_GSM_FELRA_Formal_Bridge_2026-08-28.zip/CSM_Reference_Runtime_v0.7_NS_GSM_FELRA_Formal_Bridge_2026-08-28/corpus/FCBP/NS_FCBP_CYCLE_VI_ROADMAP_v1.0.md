---
title: "Navier–Stokes Forest Coercive Budget Program：Cycle-VI Roadmap"
version: "v1.0"
date: "2026-08-16"
status: "Cycle-VI closed as a critical-lift construction/audit cycle; unconditional forest coercive budget remains open"
---

# NS-FCBP Cycle-VI Roadmap v1.0

## Completed papers

1. FCBP-01 — Critical Forest Coercivity / One-Derivative Gap
2. FCBP-02 — Filtered Stretching / Comparable-Annulus Barrier
3. FCBP-03 — Signed Pressure--Flux / Slow-Scale Schedule Lift
4. FCBP-04 — Moving Filters / Horizon Time-Thickness Barrier
5. FCBP-05 — Sharp Half-Exponent Temporal Observability
6. FCBP-06 — Causal-to-Audit / Invisible Cascade / Closure Audit

## What Cycle VI solved

### Generic scaling audit

At:

$$
p=4/3,
$$

the energy-class vorticity forcing is one derivative below the critical forcing topology.

Generic energy-duality alone is a no-go.

### Structural derivative recovery

Filtered near-field stretching is absorbed by diffusion.

The differentiated commutator is converted into a scale-critical increment defect.

### Non-summable schedule

Variable-radius pressure--flux telescoping permits slow schedules with:

$$
\sum r_k^2<\infty,
$$

but:

$$
\sum r_k=\infty.
$$

### Filter compatibility

Continuous moving compact filters have finite Leray drift debt on full-thickness slow schedules.

Co-moving heat filters give exact horizon-relative filtering on thin aligned slabs.

### Temporal geometry

The normalized thin-window schedule has sharp threshold:

$$
\boxed{
\gamma q=1/2
}
$$

for polynomial moving-window observability deterioration.

## CAR factorization

$$
\boxed{
CAR=CAR0+CAR1+CAR2+CAR3.
}
$$

### CAR0

NS-generated audit coordinates:

$$
\boxed{
\mathrm{EXTERNAL/CONSTRUCTED}.
}
$$

### CAR1

Dangerous causal certificate to native audit quotient separation:

$$
\boxed{
\mathrm{OPEN}.
}
$$

Copied-gate realizations are rejected as tautological coercivity.

### CAR2

Fixed-window local-to-clean anti-phantom transfer:

$$
\boxed{
\mathrm{EXTERNAL/CONDITIONAL}.
}
$$

### CAR3

Horizon/moving-window uniformity:

$$
\boxed{
\mathrm{OPEN}.
}
$$

## Paid-side compiler

If:

$$
\sum w_k|L_k|
\le
\eta
\sum w_kA_k+C_L,
$$

$$
\sum w_kW_k^-
\le
\gamma
\sum w_kW_k^+ + C_B,
$$

$$
W_k^+\ge c_AA_k,
$$

and:

$$
\gamma+\eta/c_A<1,
$$

then:

$$
\boxed{
\left(
1-\gamma-\eta/c_A
\right)
\sum w_kW_k^+
+
\sum w_kD_k
<
\infty.
}
$$

Thus sign-coherent backscatter plus caloric leakage absorption would close the paid side.

These PDE estimates remain open.

## Invisible cascade

External moving-window theory leaves an NS-realizable combined-invisible residual:

$$
A_{W_n}^*y_n\to0,
$$

$$
J_n^Py_n,
J_n^Fy_n,
J_n^Ey_n
\to0,
$$

while a nontrivial residual pairing survives.

No universal exclusion theorem is known.

Model-cone and filtered-increment channels can shrink this invisible class on mechanism-specific branches but do not yet cover every dangerous branch.

## Final theorem obligations

$$
\boxed{
XTR
}
$$

non-tautological native extraction;

$$
\boxed{
UNI
}
$$

moving-window scale-uniformity;

$$
\boxed{
RIG
}
$$

combined-invisible cascade rigidity;

$$
\boxed{
SIGN
}
$$

paid-side sign/leakage coercivity.

## Final status

$$
\boxed{
\text{Forest Coercive Budget}
:
\mathrm{OPEN}.
}
$$

$$
\boxed{
\text{Finite Forest Obstruction}
:
\mathrm{OPEN}.
}
$$

$$
\boxed{
\text{Navier--Stokes regularity}
:
\mathrm{NOT\ PROVED}.
}
$$

## Next program

$$
\boxed{
\textbf{
NS-MORP —
Navier--Stokes Minimal Obstruction Rigidity Program
}
}
$$

### MORP-01

Non-Tautological Defect Extraction / Minimal Combined-Invisible Profiles / Mechanism-Augmented Kernels / Obstruction Rigidity.

## Hard rules

- Do not copy the dangerous norm into a detector/gate and call that coercivity.
- NS coordinate realizability is weaker than native quotient separation.
- Fixed-window anti-phantom gaps are weaker than moving-window uniformity.
- ANP causal dual witnesses are not automatically finite-window adjoint-trace visible.
- Bounded endpoint energy does not control backscatter variation.
- Adding observables helps only with an equation-derived compatibility theorem.
- No regularity claim is made.
