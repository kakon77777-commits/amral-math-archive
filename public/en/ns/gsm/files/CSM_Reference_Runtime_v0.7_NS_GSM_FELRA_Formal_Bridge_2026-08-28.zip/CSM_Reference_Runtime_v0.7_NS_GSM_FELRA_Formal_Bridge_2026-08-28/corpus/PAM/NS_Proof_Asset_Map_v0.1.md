# NS Proof Asset Map v0.1

**Date:** 2026-08-16  
**Scope:** first-pass extraction from `NS.zip`  
**Status:** research map / not a novelty claim / not a Navier-Stokes proof  
**Canonical source:** UTF-8 Markdown with `$...$` and `$$...$$` only for mathematics

---

## 0. Executive result

The correct object is no longer "the NS proof attempt". It is a proof-asset corpus.

After recursively opening the archive and removing exact duplicate Markdown content, the current corpus contains:

- 221 unique Markdown documents;
- 118 paper/research-note documents after excluding checkpoints, roadmaps, handoffs, source policies, and changelogs;
- 26 checkpoint documents;
- 982 theorem-like **heading-level** entries in the 118-paper corpus, including 451 headings containing `Theorem`, 59 containing `Lemma`, and 176 containing `No-Go`.

The main strategic conclusion is:

$$
\boxed{
\text{NS failure to close}
\not\Rightarrow
\text{proof assets have zero value}
}
$$

and the migration program should be:

$$
\boxed{
\text{Extract}
\rightarrow
\text{Minimize assumptions}
\rightarrow
\text{Audit proof}
\rightarrow
\text{Match structures}
\rightarrow
\text{Transfer}
\rightarrow
\text{Stress-test}
}
$$

The highest-value assets found in the first pass are not the most NS-specific ones. They are the abstract concentration, graph, sequence, compactness, quotient, adjoint, matrix-rigidity, spectral-measure, and proof-routing results that were produced while attacking NS.

---

## 1. Corpus topology

The 118 research-note corpus splits naturally into the following tracks.

| Track | Paper count | Main role |
|---|---:|---|
| `NS_O` C1–C6 | 67 | long obstruction-compression backbone; strain/pressure/triad/defect-cycle/ancient-profile analysis |
| `FCBP` Cycle VI | 6 | forest coercive budget, filtered stretching, telescoping, moving filters, observability |
| `MORP` Cycle VII | 5 | minimal obstruction, compactness, profile splitting, rigidity, diffuse escape |
| `DCRP-A` Cycle VIII | 4 | diffuse-carrier concentration, interaction graphs, Young rigidity, impulsive recurrence |
| `DCRP-B / RMRM extension` | 13 | model-cone debt, spectral moments, first crossing, supplier ancestry, PFET/trace realization |
| `IDRP` Cycle IX | 4 | impulsive defect recurrence, burst visibility, source quotient, adjoint synchronization |
| `TSKR` Cycle X | 4 | tangent-source geometry, fixed points, harmonic rank-one rigidity, residual kernels |
| `RKAP` Cycle XI | 1 | hyperbolic mismatch fiber, PSD lift tax, amplitude frontier |
| `X72` pure-continuous route | 14 | continuous hierarchy, Gevrey radius, spectral covariance, triad phases, critical quotient/gauge |

`RMRM` checkpoints are not counted as independent papers above. They are treated as **proof-process assets** because they record corrections, frontier compression, research routing, and explicit anti-overclaim rules.

---

## 2. Asset grading

Every extracted result should eventually receive three independent scores:

$$
A(T)
=
\bigl(
S_{NS},
C_{proof},
R_{transfer}
\bigr),
$$

where:

- $S_{NS}$ = how much the theorem depends on NS-specific structure;
- $C_{proof}$ = how complete and independently checkable the proof is;
- $R_{transfer}$ = how many other mathematical structures can realize the assumptions.

For triage, use three tiers.

### Tier A — abstractly portable

The theorem can be rewritten with little or no NS vocabulary. Examples:

- superlinear concentration recovery;
- partner-degree compensation;
- strict-convexity Young rigidity;
- weighted sequence logarithmic atom floor;
- sharp half-exponent schedule theorem;
- distance-to-subspace lower bounds from transverse duals;
- adjoint synchronization;
- rank-one PSD attenuation;
- rank-one harmonic matrix rigidity;
- PSD two-sided lift tax.

### Tier B — PDE-portable

The theorem uses PDE machinery, but not something unique to the exact NS equation. Examples:

- moving-filter derivative control;
- variable-radius telescoping;
- first-crossing multiscale arguments;
- Duhamel ancestry;
- spectral-moment separation;
- solenoidal trace windows;
- Gevrey/analytic-radius resummation;
- Fourier-triad phase/coherence machinery.

### Tier C — NS-specific or proof-process assets

These may still be valuable, but should be transferred as **templates**, not copied statements. Examples:

- pressure-strain specific geometry;
- Betchov/local strain identities;
- NS-specific critical tolls;
- typed defect graph/SCC elimination;
- ancient NS profile classification;
- RMRM frontier-reduction and anti-quantifier-swap rules.

---

## 3. High-value Tier-A assets

### 3.1 Superlinear Concentration Recovery

Source: DCRP-A01, Theorem 8.1.

If normalized carrier weights satisfy a superlinear local-output bound of the schematic form

$$
|q_\alpha|
\le
C e_\alpha^{1+\theta},
\qquad
\theta>0,
$$

then a fixed total nonlinear output forces a fixed-size carrier atom.

This is not an NS theorem in its minimal form. It is a generic concentration lemma.

**Transfer radius:** interaction networks, localized nonlinear PDE outputs, multilinear decompositions, probabilistic carrier models.

**Research value:** high, although the core inequality is elementary. The reusable value lies in turning diffuse-output claims into an explicit atomicity alternative.

### 3.2 Partner-Degree Compensation

Source: DCRP-A02, Theorem 4.1.

For a weighted interaction graph with edge contributions bounded schematically by

$$
|q_{ij}|
\le
C_0 c_i e_j^{1/2},
$$

fixed aggregate output plus vanishing maximal atom forces weighted partner degree to grow like the reciprocal square root of the maximal atom.

This creates a reusable trilemma:

$$
\boxed{
\text{persistent output}
\Rightarrow
\text{atomicity}
\vee
\text{degree explosion}
\vee
\text{failure of locality assumptions}
}
$$

This is an obvious target for MHD/Hall-MHD triad graphs and for other frequency-interaction systems.

### 3.3 Strict-Convexity Young Rigidity

Source: DCRP-A03, Theorem 21.1.

Under a full generalized Young representation, zero strictly convex Jensen/concentration tax forces both:

$$
\lambda=0
$$

and

$$
\nu_{x,t}=\delta_{\bar V(x,t)}.
$$

This should be detached from the NS story and rewritten as a general lemma about oscillation/concentration defects.

### 3.4 Weighted Sequence Logarithmic Atom Floor

Source: DCRP-A04, Lemma 13.1.

Given $b_m\ge0$, positive total mass, and a weighted quadratic moment bound, one obtains a quantitative lower bound on $\sup_m b_m$ with only logarithmic degradation.

This is useful anywhere a far-field/annular decomposition has a strong weighted $\ell^2$ constraint but only weak $\ell^1$ information on total output.

### 3.5 Sharp Half-Exponent Horizon Schedule

Source: FCBP-05, Theorem 8.1.

For positive nonincreasing $r_k$ with

$$
\sum_k r_k^2<\infty,
$$

and

$$
d_k
=
1-
\left(\frac{r_{k+1}}{r_k}\right)^2,
$$

one has

$$
\sum_k r_k d_k^a<\infty
\qquad
\text{for every }a>\frac12,
$$

while $a=1/2$ is an attainable divergence threshold.

This is one of the cleanest standalone assets in the corpus and should be isolated as its own short lemma note.

### 3.6 Source-Quotient Transverse Dual Bound

Source: IDRP-03, Theorem 4.1.

This is a distance-to-subspace estimate. If a dual witness has a nonzero component transverse to the clean/model subspace, then the pairing gives a quantitative lower bound on quotient distance.

Minimal form:

$$
\operatorname{dist}(F,S)
\ge
\frac{|\langle F,\psi_\perp\rangle|}{\|\psi_\perp\|}.
$$

This has a large transfer radius: observability, inverse problems, control, PDE quotient defects, and model-reduction audits.

### 3.7 Adjoint Synchronization

Source: IDRP-04, Theorem 12.1.

Two backward dual evolutions with common terminal datum and nearby generators obey a Duhamel-Gronwall difference estimate. Schematically,

$$
\|\phi_C-\phi_A\|_{L^\infty(I;H)}
\lesssim
\|\zeta\|
\int_I
\|L_C(t)-L_A(t)\|dt.
$$

This is not NS-specific and should be reused wherever a causal certificate and an audit/control adjoint must be synchronized.

### 3.8 Rank-One Attenuation Rigidity

Source: TSKR-02, Theorem 5.1.

If

$$
u\otimes u
=
U\otimes U+R,
\qquad
R\ge0,
$$

then, outside the zero case,

$$
U=\theta u,
\qquad
R=(1-\theta^2)u\otimes u,
\qquad
|\theta|\le1.
$$

This is finite-dimensional PSD geometry and should be extracted independently from the NS language.

### 3.9 Rank-One Harmonic Matrix Rigidity

Source: TSKR-03, Theorem 11.1.

For a connected domain, if a symmetric matrix field is PSD, has rank at most one, is not identically zero, and every component is harmonic, the internal proof derives

$$
F(x)=h(x)v\otimes v,
$$

with $v$ constant and $h>0$ harmonic.

This is a priority **novelty-audit candidate**. The argument is short and self-contained enough to audit separately from NS.

### 3.10 Exact Two-Sided PSD Lift Tax

Source: RKAP-01, Theorem 12.1.

For symmetric $H$, minimizing

$$
\operatorname{tr}A+\operatorname{tr}B
$$

subject to

$$
A,B\ge0,
\qquad
H=A-B,
$$

gives exactly

$$
\|H\|_\ast.
$$

This is almost certainly classical convex/matrix analysis in substance, so it should not be advertised as new before literature search. It is nevertheless an excellent reusable **cost functional** for converting signed residuals into positive two-package costs.

---

## 4. High-value Tier-B assets

### 4.1 Variable-radius telescoping

FCBP-03 shows that a pressure/flux telescope need not be tied to a geometric radius schedule. The important transferable idea is:

$$
\text{choose the scale weight so the endpoint coefficient becomes scale-independent.}
$$

The exact identity is equation-dependent, but the schedule design principle should be tested in MHD and Boussinesq filtered budgets.

### 4.2 Moving-filter compatibility

FCBP-04 contains an exact filter-scale derivative estimate and derives the extra term created by a continuously time-dependent filter. This is directly relevant to any PDE proof that uses a scale following the evolving solution.

### 4.3 Pressure-only visibility no-go

IDRP-04/TSKR-01 construct source directions invisible to the active pressure symbol but visible to the projected forcing. The transferable lesson is operator-theoretic:

$$
\boxed{
\ker O_1
\not\subset
\ker O_2
}
$$

for two natural observation channels. This prevents false single-detector closure arguments in related systems.

### 4.4 Hyperbolic mismatch fiber

TSKR-04 compresses energy/flux-invisible two-sided linearized stress mismatch to a low-dimensional fiber. This is a good candidate for coupled quadratic PDEs whose stress geometry differs only by extra fields.

### 4.5 Spectral Hellinger geometry

DCRP-B06 defines derivative-weighted spectral probability measures and identifies their Hellinger/Bhattacharyya affinity with a normalized adjacent-moment alignment parameter.

The general pattern is:

$$
\text{adjacent spectral moments}
\longrightarrow
\text{probability measures}
\longrightarrow
\text{overlap / separation geometry}.
$$

This can be transferred to other Sobolev/Gevrey hierarchies.

### 4.6 First-crossing parent-or-defect localization

DCRP-B10 converts a critical first crossing into a finite alternative involving low-mode shear, near-scale clustering, bounded-relative high-high parents, derivative occupancy, or long normalized supplier germ.

This is deeply PDE-specific, but the architecture is valuable:

$$
\boxed{
\text{first crossing}
\Rightarrow
\text{finite structural alternative}
}
$$

rather than trying to obtain an impossible monotone cascade law.

### 4.7 Universal finite-dimensional solenoidal trace window

DCRP-B14 is especially interesting. Its compactness/unique-continuation argument attempts to replace a solution-dependent diagnostic by one universal finite-dimensional divergence-free test space that detects every normalized nonvanishing annular supplier increment.

This deserves a dedicated proof audit because, if correct in its stated hypotheses, it is a reusable observability lemma for incompressible systems.

### 4.8 Pure-continuous hierarchy and triad assets

X72 Rounds 07–13 contain a second family of assets largely independent of the forest/defect program:

- Gevrey/analytic-radius resummation;
- weighted spectral-replicator identities;
- viscous covariance bounds;
- Fourier-triad phase/coherence variables;
- phase-locking dynamics;
- critical dual quotient geometry modulo gradients;
- gauge-covariance failure and one-form transport repair.

These should be tested independently of the NS closure attempt.

---

## 5. Tier-C proof-process assets

### 5.1 Typed defect graph and SCC reduction

The later `NS_O` papers increasingly represent proof obligations as typed nodes and typed dynamic edges, then recompute strongly connected components after deleting static compatibility relations that do not imply temporal recurrence.

This is a general proof-engineering principle:

$$
\boxed{
\text{compatibility edge}
\neq
\text{dynamical transition edge}
}
$$

and it is portable to other long conjecture programs.

### 5.2 Provenance as a mathematical variable

A recurring correction is that two quantities may be equal or compatible at one event without one being the **same-history cause** of the other. This yields a useful distinction:

$$
\text{state compatibility}
\neq
\text{causal heredity}.
$$

This matters in multiscale cascades, profile limits, Duhamel arguments, and recurrence constructions.

### 5.3 RMRM frontier router

RMRM explicitly optimizes research actions by closure gain, frontier reduction, transfer value, verification debt, and correlated-assumption risk. The useful abstraction is not the mathematician names; it is the state-dependent router:

$$
\mathcal S_t
\xrightarrow{a_t}
\mathcal S_{t+1},
$$

with an action value of the schematic form

$$
J(a\mid\mathcal S_t)
=
\alpha G_{\rm closure}
+
\beta\Delta_{\rm frontier}
+
\gamma G_{\rm transfer}
-
\lambda\Delta V
-
\mu C_{\rm correlation}.
$$

For the present migration project, $G_{\rm transfer}$ should now receive much larger weight than it did during the pure NS attack.

### 5.4 Anti-overclaim rules

RMRM v14 records several extremely valuable proof-hygiene rules. In abstract form:

1. do not replace a newly defined carrier by a familiar physical carrier without a bridge theorem;
2. do not infer an infinite limiting object from $\forall n\,\exists P_n$ without compactness/consistency;
3. do not identify profile recurrence with recurrence along one actual history;
4. nonzero leakage is not automatically a positive coercive tax;
5. rapid frontier compression is not evidence that QED is near.

These should become permanent validators for all transferred proof programs.

---

## 6. Transfer target matrix

The first migration wave should stay structurally close to the source corpus.

| Target | Structural match | Best assets | Main mismatch | Priority |
|---|---|---|---|---|
| 3D incompressible MHD | Very high | A01–A07, A11–A20, A23–A26 | coupled velocity/magnetic channels and cross-helicity | 1 |
| Hall-MHD | High | A01–A07, A18–A20, A23–A25 | Hall term adds derivative/nonlocal interaction complexity | 2 |
| 3D Boussinesq | Very high | FCBP moving filters/telescopes, IDRP source quotients/adjoints, MORP compactness | active scalar forcing and two-field criticality | 1 |
| 3D Euler | High but non-dissipative | TSKR geometry, NS_O strain/pressure, MORP profiles, X72 triads/Gevrey | no viscous budget; all dissipation-tax assets drop out | 2 |
| supercritical generalized SQG | Medium-high | DCRP concentration/graphs, MORP profiles, spectral/Hellinger, X72 continuous hierarchy | active-scalar singular integral has different geometry | 2 |
| energy-supercritical NLS/wave | Medium | MORP compactness/profile splitting, A01–A07 | dispersive rather than parabolic; NS geometry mostly unusable | 3 |
| abstract Young/measure problems | High for selected assets | A01–A04, A11–A13, A18 | not necessarily attached to one famous conjecture | 1 |

The priority score here is a **migration priority**, not a claim that any target is easier than NS.

---

## 7. Current literature anchors checked on 2026-08-16

A small external check confirms that the NS corpus is connected to real current literature rather than only internal naming.

Verified 2026 NS anchors used by the corpus include:

- Runlong Yu, *A Structural Audit of Navier-Stokes Obstruction Calculus*, arXiv:2606.25341;
- Runlong Yu, *Finite-Window Local-to-Clean Transfer and Anti-Phantom Detection for Sharp Navier-Stokes Packages*, arXiv:2606.18476;
- Runlong Yu, *Filtered Vortex Stretching and Subgrid Defects for the Three-Dimensional Navier-Stokes Equations*, arXiv:2606.27560.

Current transfer-target anchors include:

- Adam Larios and Yuan Pei, 3D MHD Voigt regularization and blow-up criterion, arXiv:2605.05139;
- Jinwook Jung and Jaeyong Shin, Hall-MHD eventual regularity/asymptotics, arXiv:2606.03542;
- Hassan Babaei and Mimi Dai, Hall/electron-MHD determining wavenumbers, arXiv:2604.10804;
- Qianyun Miao and Jiakun Yang, 3D non-diffusive Boussinesq at large Prandtl number, arXiv:2607.13803;
- Patricia L. Guidolin, Wilberclay G. Melo, Thyago S. R. Santos, fractional 3D Boussinesq blow-up criteria, arXiv:2605.31461;
- Peter Constantin, Mihaela Ignatova, Vlad Vicol, putative self-similarity for incompressible 3D Euler, arXiv:2602.17570;
- Anuj Kumar, supercritical generalized SQG in critical Sobolev spaces, arXiv:2605.13176;
- Xuan Liu, defocusing energy-supercritical NLS in high dimensions, arXiv:2608.00951.

These references are **target anchors**, not evidence that the present assets are new or that they solve those problems.

---

## 8. First experimental program

The migration project should not start by attacking another Millennium problem at full strength.

Use a three-stage ladder.

### Stage I — theorem extraction and reproof

Take the Tier-A assets and remove all NS notation.

For each result produce:

$$
\boxed{
\text{Statement}
+
\text{minimal assumptions}
+
\text{self-contained proof}
+
\text{known-theorem search}
}
$$

First candidates:

1. Sharp Half-Exponent Schedule Theorem;
2. Rank-One Harmonic Matrix Rigidity;
3. Partner-Degree Compensation;
4. Source-Quotient Transverse Dual Bound;
5. Spectral Hellinger Identity.

The goal is **not novelty**. The goal is to obtain clean portable theorem objects.

### Stage II — known-result reproduction in neighboring PDE

Before attacking an open problem, use the assets to rederive a known theorem or known criterion in:

- incompressible MHD;
- 3D Boussinesq;
- Hall-MHD;
- Euler or gSQG.

If the machinery cannot reproduce an already-known easier statement, it is not ready for an open frontier.

### Stage III — new local theorem / obstruction

Only after Stage II succeeds, target something modest but genuinely open-ended:

$$
\boxed{
\text{new criterion}
\vee
\text{new no-go}
\vee
\text{new quantitative bound}
\vee
\text{new compactness/rigidity reduction}
}
$$

before attempting a famous global conjecture.

---

## 9. Recommended first three migration projects

### Project M1 — MHD Proof Asset Port

Port only the machinery that survives the two-field structure:

- interaction-graph concentration;
- moving-filter calculus;
- adjoint synchronization;
- quotient/source transversality;
- first-crossing alternatives;
- spectral/Hellinger geometry;
- triad phase/coherence.

Target output:

$$
\boxed{
\text{MHD Asset Compatibility Report}
+
\text{one reproduced known criterion}
}
$$

### Project B1 — Boussinesq Source/Defect Port

This is especially natural because Boussinesq already inserts an explicit active forcing channel into the velocity equation.

Focus on:

- source quotient geometry;
- causal-to-adjoint synchronization;
- moving-window observability;
- forced first-crossing/critical-norm growth;
- compactness/profile escape.

### Project A1 — Standalone Abstract Lemma Pack

Extract 5–10 Tier-A results into a source file that contains **no NS notation**.

This is the cheapest way to discover which parts of the corpus are genuinely reusable mathematics.

---

## 10. Verification ladder

Every migrated asset should move through the following states:

$$
V_0
\rightarrow
V_1
\rightarrow
V_2
\rightarrow
V_3
\rightarrow
V_4.
$$

- $V_0$: extracted from corpus;
- $V_1$: assumptions minimized and proof rechecked locally;
- $V_2$: symbolic/numerical counterexample search where applicable;
- $V_3$: literature novelty/prior-art audit;
- $V_4$: independent AI/human proof audit and target-domain stress test.

No result should be called "new theorem" merely because it survived $V_1$.

---

## 11. Immediate conclusion

The archive already contains enough structure to justify a separate research program:

$$
\boxed{
\textbf{NS Proof Asset Migration Program}
}
$$

The important shift is conceptual:

$$
\boxed{
\text{Do not ask only whether NS was proved.}
}
$$

Ask instead:

$$
\boxed{
\text{Which mathematical objects were proved while NS resisted closure?}
}
$$

The first-pass answer is: **many**.

Some are elementary but reusable; some are likely rediscoveries of known functional/matrix facts; some are conditional PDE compilers; some are nontrivial NS-specific reductions; and some are proof-engineering methods. The next research step is therefore not another blind extension of the NS tree. It is **theorem extraction + prior-art audit + structural transfer**.

---

## 12. Package files

- `corpus_inventory_118.csv` — all 118 research-note documents with track/status/tags and a conservative heuristic portability score;
- `theorem_heading_index_982.csv` — heading-level theorem/lemma/no-go/rigidity/barrier/dichotomy/trichotomy index;
- `top_asset_candidates_28.csv` — first curated high-value transfer set;
- `validation.json` — source/package validation metadata;
- `CHECKSUMS.sha256` — package checksums.
