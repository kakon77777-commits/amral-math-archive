# C6 Handoff — Phase-Resonant Relay Turnover and Modulation Cost

## Source state

C5 proves:

$$
\mathcal T
=
\mathcal E\mathcal P,
$$

$$
\frac FA
=
\mathcal E\mathcal P\mathcal C_{\mathrm{sgn}},
$$

and exact spacetime phase concentration identities.

The exact Fourier-mode phase velocity is

$$
\dot\vartheta_k
=
\operatorname{Im}
\frac{\widehat{\mathcal N[\theta]}(k)}{\widehat\theta(k)},
$$

so dissipation does not directly rotate phase and the fixed symbol does not create temporal dephasing.

C5-T3 gives, for every $\Omega>0$,

$$
\text{many $\Omega$-phase-resonant edges}
\vee
\text{large modulation/dephasing defect}.
$$

C5-T4 transfers C4 effective rank to unsigned edge rank when temporal persistence is sufficiently close to one.

C5-T5 gives the exact rank--duty identity

$$
\mathcal D_{\mathrm{amp}}\mathcal R_V
=
\mathcal D_{\mathrm{tot}}\mathcal H.
$$

Thus large integrated rank means either large simultaneous coactivity or low-duty sequential relay.

## C6 objective

Attack the relay branch rather than assuming it away.

## Main questions

1. Derive a PDE-level estimate for tile-amplitude turnover, for example a controllable surrogate of
   $$
   \sum_e\|a_e'\|_{L^1(I)}.
   $$
2. Test whether a relay through $R$ distinct antipodal edges forces a lower bound on a time-frequency modulation budget.
3. Determine whether Gevrey smoothing yields a usable bound on rapid high-frequency tile switching.
4. Seek a theorem of the form
   $$
   \text{large relay rank}
   \Longrightarrow
   \text{large turnover defect}
   \vee
   \text{persistent simultaneous phase resonance}.
   $$
5. Use wave packets only if Fourier-tile turnover cannot encode the relevant physical overlap.

## Prohibitions

- Do not infer physical-space localization from Fourier coherence.
- Do not assume random phases.
- Do not assume high integrated rank means simultaneous high rank; C5-N4 forbids this.
- Do not treat large phase speed alone as dephasing; C5-N3 forbids this.
- Do not attribute temporal phase dispersion to the static gSQG symbol; C5-N1 forbids this.
