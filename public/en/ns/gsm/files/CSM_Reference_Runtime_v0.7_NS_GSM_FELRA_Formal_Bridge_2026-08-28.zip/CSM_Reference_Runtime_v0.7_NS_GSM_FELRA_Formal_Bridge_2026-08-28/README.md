# CSM Reference Runtime v0.7

A deterministic local reference runtime for **Closure-Space Mathematics (CSM)** with staged **NS_GSM corpus ingestion, proof-authority review, independent verification, formalization/replication, and a FELRA formal-proof bridge**.

v0.3 preserves the v0.2 authority firewall and adds a replayable review layer. Every corpus candidate now receives an explicit review decision; only structurally safe classes are automatically promoted, while theorem/NO-GO candidates remain deferred unless a matching certificate and scope audit authorize native mutation.

## What v0.3 proves about itself

It proves runtime/review conformance only: corpus candidates can be reviewed deterministically; review batches are atomic and idempotent; promotion receipts are replayable; safe structural objects can be promoted without closing parent claims; cross-series matches never auto-quotient; and the final native state replays to the exact stored hash.

It does **not** prove Navier–Stokes global regularity, route completeness, representation completeness, generalized NS-like closure, physical-model adequacy, or that all deferred candidates are true/false.

## Core authority invariants

```text
No certificate path => no native theorem mutation.
Candidate != Review != Promotion != Theorem.
Obstruction object creation != parent refutation.
SURVIVOR => OPEN + SURVIVOR role tag.
STOP/Next => OPEN frontier object.
Cross-series exact match => NEEDS_REVIEW; auto_quotient=false.
```

## v0.3 frozen checkpoint

- baseline v0.2 content artifacts: 46
- v0.3 source-backed expansion artifacts: 15
- total content artifacts: 61
- candidates: 1,726
- review records: 1,726
- structural promotions: 727
- pending/deferred reviews: 999
- cross-series proposals: 252
- automatic quotients: 0
- ledger events: 5,066
- root formal NS: `OPEN`
- scope: `observed-relative`
- native/replay state SHA-256: `be70fd6236051454bda1e0e1a46fbb943b1d53729713cf79a5d3b09f3498bd7b`
- conformance: 11/11 PASS

### Structural promotion classes

| Class | Count | Native meaning |
|---|---:|---|
| FRONTIER | 498 | OPEN frontier object |
| NONCLAIM | 159 | explicit authority boundary |
| SURVIVOR | 70 | OPEN route with SURVIVOR role |

Tier-0 intentionally performs **zero automatic PROOF_ASSET and zero automatic OBSTRUCTION promotion**. Those remain for certificate/scope-aware review.

## v0.3 coverage expansion

The original v0.2 46-artifact corpus remains unchanged. v0.3 adds a separate `corpus_v03_expansion/` with 15 source-backed files:

- C-series: C4, C5, C6 (3)
- DCRP milestones: 11, 13, 18, 29, 64, 65, 66, 67, 69, 77, 98, 100 (12)

This is **coverage expansion**, not theorem progress by itself.

## Run tests

```bash
pytest -q
```

## Run full v0.3 structural review

```bash
PYTHONPATH=src python -m csm_runtime.cli run-structural-review \
  --seed <NS_GSM_SEED_PATH> \
  --corpus corpus \
  --expansion corpus_v03_expansion \
  --evidence evidence/v0.3
```

## Review audit queries

```bash
PYTHONPATH=src python -m csm_runtime.cli review-summary \
  --snapshot evidence/v0.3/native_snapshot_v03.json

PYTHONPATH=src python -m csm_runtime.cli pending-review \
  --snapshot evidence/v0.3/native_snapshot_v03.json

PYTHONPATH=src python -m csm_runtime.cli promotion-summary \
  --snapshot evidence/v0.3/native_snapshot_v03.json
```

## Architecture

```text
Corpus / Expansion
-> Manifest + deterministic parser
-> Candidate Layer
-> ReviewRecord / ReviewDecision
-> PromotionGate
-> existing atomic ClosureTransaction
-> Native structural object / status
-> PromotionReceipt
-> Ledger / Snapshot / Replay
```

The review layer is auditable state, not an external spreadsheet. Review decisions and promotion receipts are part of the canonical replay path.

## v0.4 — Proof-Authority Review

Runtime 0.4.0 adds curated source-hash/scope/certificate authority audits. The first batch audits 20 ETN-X / DCRP103-105 / RFP subjects, creates 12 bounded AUDIT-level proof assets and one AUDIT-level obstruction asset, defers three unresolved closure obligations, and keeps the formal Navier-Stokes root OPEN. Source-internal results are not independent proof verification.

## v0.5 — Independent Verification and Authority Upgrade

v0.5 separates source-internal authority from independent verification. Bounded v0.4 assets are checked by exact symbolic, exact-witness, analytic-schema, graph-theorem, or corpus-audit verifiers. Only a full `VALID` result from a proof-eligible verifier, with no narrowing limitation, may upgrade an existing asset from `AUDIT` to `PROOF` authority. No verification automatically propagates to the formal NS root, C1, or C2.

## v0.6 — Formalization / Cross-Implementation Replication

v0.6 adds orthogonal authority tiers on top of the v0.5 bounded `PROOF` assets:

- `FORMALIZED_CORE_ONLY`
- `CROSS_IMPLEMENTATION_REPLICATED`
- `EXTERNAL_THEOREM_ANCHORED`
- `FORMAL_PROOF` (schema reserved; current release count is zero)

Twelve bounded proof assets compile to `NSGSM-FIR/0.1` and are recomputed by a standalone `python -I` replicator that does not import `csm_runtime` or the original verifier modules. ETN–X Proposition 8.1 receives a typed external theorem dependency anchor but retains its base `AUDIT` authority.

Source-tree release run:

```bash
PYTHONPATH=src python -m csm_runtime.cli run-formalization-replication \
  --root . \
  --evidence evidence/v0.6
```

The formal Navier–Stokes root, C1, and C2 remain `OPEN`.

## v0.7 — FELRA Formal Proof Bridge & Kernel Authority Protocol

v0.7 adds an artifact/subprocess bridge from `NSGSM-FIR/0.1` to FELRA's registered Lean backend. NS_GSM owns theorem identity, scope, translation certificates and authority semantics; FELRA owns checker execution/provenance/formal status; the Lean kernel owns elaboration/type checking.

First bridge batch: D103.1–D103.5. The sandbox has no `lake`, `lean`, or `felra`, so the canonical release is deliberately `BRIDGE_READY` with **5 valid translations, 5 formal obligations, and 0 FORMAL_PROOF receipts**. The formal NS root, C1 and C2 remain `OPEN`.

Source-tree bridge freeze:

```bash
PYTHONPATH=src python -m csm_runtime.cli run-felra-bridge \
  --root . \
  --evidence evidence/v0.7
```

Bridge export/import surfaces:

```bash
PYTHONPATH=src python -m csm_runtime.cli export-felra-bridge \
  --snapshot evidence/v0.7/native_snapshot.json \
  --subject <D103-proof-asset-id> \
  --output bridge-out

PYTHONPATH=src python -m csm_runtime.cli import-felra-formal-result \
  --bridge bridge-out/ns_gsm_bridge_manifest.json \
  --felra-result <FELRA-result.json>
```

A FELRA `success` flag, a stored certificate, or a Lean obligation that merely exists is never enough for formal authority. `FORMAL_PROOF[lean]` requires a fresh verified formal result, exact obligation/translation identity, checker provenance, and a non-vacuous axiom audit. Formal proof on a bounded D103 child never propagates to parent NS closure.

See `NS_GSM_FELRA_FORMAL_BRIDGE_V0.7_REPORT.md` and `docs/superpowers/specs/2026-08-28-ns-gsm-felra-formal-proof-bridge-v0.7-design.md`.
