# SOURCES

1. HUN-REN Alfréd Rényi Institute of Mathematics, Paul Erdős collected papers.
2. P. Erdős, *Applications of Probabilistic Methods to Graph Theory* (1967).
3. P. Erdős and J. Larson, *On Pairwise Balanced Block Designs with the Sizes of Blocks as Uniform as Possible* (1982).
4. P. Erdős, *Some Problems and Results in Number Theory* (1985) and related problems-and-results papers.
5. Erdős Problems database, current 2026 snapshot: 1217 catalogued problems; 147 catalogued problem-list papers.
6. Erdős Problems FAQ and Prizes pages.
7. Erdős Number Project, 2025 data: 514 direct coauthors; 202 with more than one joint paper.

Evidence labels: OBS / INF / HYP / UNK.
The Erdős Problems database is evolving and is not the complete set of all problems Erdős ever posed.
Prize amounts are treated as noisy research-priority signals, not exact difficulty scores.
