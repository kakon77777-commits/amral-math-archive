# RMRM-C001 Execution Run 01 — Stage A Audit

**Date:** 2026-08-16  
**Protocol:** RMRM-C001 v0.1  
**Sampling provenance:** `work_seeded_proxy`  
**Final cohort selected:** No  
**D_median computed:** No  

## Why this run is provisional

The available OpenAlex-backed connector exposes work-level search and paper metadata, but not a bulk author-level random-sample endpoint or complete author-profile vectors. Therefore this run does **not** pretend to have executed the preregistered multivariate median ranking.

Instead it executes the parts that can be completed without violating the protocol:

1. work-level field discovery;
2. author deduplication / identity sanity checks;
3. field-content audit;
4. career-window audit;
5. preregistered E01–E06 exclusion audit;
6. construction of an author-level audit queue.

The data-acquisition deviation is recorded as:

`sampling_path = work_seeded_proxy`

The selection rules, career window, exclusion codes, fixed-corpus rule, blind methodology coding rule, and final baseline equations are unchanged.

## Current queue

- 35 anonymous IDs instantiated across the seven macro-strata.
- Several entries have already failed E03 career-window checks.
- Several exceptional-visibility candidates have failed or been held under E01/E02.
- Identity contamination has already appeared as a real failure mode (E04).

## Important non-result

`median_rank = NOT_COMPUTED` for all rows.

No row in this artifact should be described as a top-5 median finalist yet.

## Next execution step

For each stratum:

1. replace E03/E01/E02/E04 failures with additional work-seeded authors;
2. freeze a larger reference pool;
3. collect author-level publication/citation/collaboration/topic/continuity variables from public profiles or reproducible proxies;
4. calculate robust field/career medians and MAD;
5. only then produce anonymous ranks and the 35 genuine finalists.

This report is an audit checkpoint, not the final cohort.
