# SOURCES

Primary / authoritative anchors:
1. Emmy Noether, dissertation / early invariant-theory work on ternary biquadratic forms.
2. Emmy Noether, Zur Invariantentheorie der Formen von n Variabeln.
3. Emmy Noether, correspondence with David Hilbert, 1913–1914.
4. Emmy Noether, Habilitation curriculum vitae / autobiographical statement, 1919.
5. Emmy Noether, Invariante Variationsprobleme, 1918.
6. Emmy Noether, Idealtheorie in Ringbereichen, 1921.
7. Emmy Noether, Abstrakter Aufbau der Idealtheorie in algebraischen Zahl- und Funktionenkörpern, 1927.
8. Emmy Noether, Hyperkomplexe Größen und Darstellungstheorie, 1929.
9. Emmy Noether, Nichtkommutative Algebra, 1933.

Attribution notes:
- The 1929 basis-independent transformation/matrix distinction is preserved with the explicit van der Waerden attribution recorded by Noether.
- Ernst Fischer is described only as a decisive methodological stimulus because Noether herself reports this; the transition is not reduced to a single causal source.
- RMRM reconstructs public methodological patterns and does not claim access to Noether's private mental states.

Falsification notes:
- Early 1907–1911 work is retained as a negative control against projecting the mature fingerprint backward.
- No new O39 is introduced in v1.0; Intrinsic Structural Re-Encoding remains a candidate composition pending cross-person evidence.
