# RMRM SPECIMENS — v1.0

1. Terence Tao — Obstruction-Centered Research Compilation
2. Alexander Grothendieck — Lossless Abstraction by Relational Reconstruction
3. Srinivasa Ramanujan — High-Compression Mathematical Phenomenon Generation
4. Paul Erdős — Distributed Unknown-Space Engineering
5. William Thurston — Mathematical Understanding through Geometric Re-embodiment
6. Maryam Mirzakhani — Ambient Globalization, Rigid Return, and Research-Hub Reinvestment
7. Timothy Gowers — Diagnostic Regime Decomposition and Research-State Compilation
8. Jean Bourgain — Quantitative Interface Engineering and Technique Migration
9. Grigori Perelman — Closure-Bearing Structure Compression and Rigidity-Boundary Calibration
10. Emmy Noether — Theorem-Architecture Compilation with Methodological Phase Transition

Next planned specimen: RMRM-011 Andrey Kolmogorov.
