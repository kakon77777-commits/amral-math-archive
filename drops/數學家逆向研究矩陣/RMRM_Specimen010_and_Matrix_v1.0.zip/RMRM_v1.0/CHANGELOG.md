# CHANGELOG — RMRM v1.0

Date: 2026-08-16

Major framework change from RMRM-010 Emmy Noether:
- Fingerprints are now time-dependent: F_m -> F_m(t).
- Added D28 Methodological Phase Transition.
- Added Methodological Phase State.
- Added Longitudinal Method Invariants.
- Added Phase Transition Profile.
- Added Post-Transition Methodological Stability.
- Added Structural Carrier schema.
- Added Hypothesis–Consequence Graph.
- Added ConverseTest and GeneralizationProbe concepts.
- Research Router upgraded to v0.7 and made phase-aware.
- Added Method Trajectory graph.
- No O39 added: Intrinsic Structural Re-Encoding remains a candidate composition pending cross-person validation.

Noether falsification results:
- Early 1907–1911 formal invariant-theory work does not naturally fit the mature theorem-compiler fingerprint.
- The earlier condition-only model was too narrow; representation/module work requires a Structural Carrier model.
- Generalization can separate accidental coincidences rather than merely unify them.

Current global catalog:
C1–C11
O1–O38
D1–D28

RMRM-010 Noether is the first explicit methodological-phase-transition specimen.
