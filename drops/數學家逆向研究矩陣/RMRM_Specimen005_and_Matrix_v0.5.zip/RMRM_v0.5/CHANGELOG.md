# CHANGELOG — RMRM v0.5

Date: 2026-08-15

Added from RMRM-005 William Thurston:
- O30 Cross-Representation Reconciliation.
- O31 Geometric Re-embodiment.
- O32 Decompose–Model–Reassemble.
- O33 Deformation-Space Exploration.
- O34 Cognitive Infrastructure Externalization.
- D19 Understanding-State Tracking.
- D20 Audience-Conditioned Transfer.
- D21 Infrastructure-Gap Bridging.
- D22 Community-Uptake Propagation.
- D23 Dissemination-Policy Recalibration.
- New obligations: understand / transfer / uptake.
- Understanding Debt Vector U.
- Infrastructure Gap I(K,A).
- Knowledge Carrier Set.
- Understanding Expansion Factor chi.
- Manipulability Preservation.
- Research Router v0.2 with GapDetect and UptakeAudit.

Specimens:
RMRM-001 Tao; RMRM-002 Grothendieck; RMRM-003 Ramanujan; RMRM-004 Erdős; RMRM-005 Thurston.
