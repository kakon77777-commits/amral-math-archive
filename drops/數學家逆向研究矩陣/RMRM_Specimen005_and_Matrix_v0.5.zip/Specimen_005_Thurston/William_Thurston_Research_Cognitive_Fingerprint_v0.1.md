# William Thurston Research Cognitive Fingerprint v0.1

**RMRM Specimen 005**

**框架**：Mathematician Reverse Research Matrix (RMRM)  
**Specimen**：William P. Thurston  
**日期**：2026-08-15  
**版本**：v0.1  
**狀態**：provisional frozen

## 0. 定位

Thurston specimen 不被簡化成「幾何直覺型數學家」。本文逆向的是一個更可操作的研究系統：

$$
\boxed{
\text{formal object}
\to
\text{manipulable model}
\to
\text{multi-representation understanding}
\to
\text{external cognitive infrastructure}
\to
\text{community reuse}.
}
$$

核心區分：

$$
\boxed{
\text{Proof}
\neq
\text{Understanding}
\neq
\text{Transfer}
\neq
\text{Uptake}.
}
$$

證據標記：`OBS / INF / HYP / UNK`。

---

# 1. Corpus

核心材料包括：

- surface automorphisms / Nielsen–Thurston classification；
- pseudo-Anosov maps、measured foliations；
- 3-manifold geometrization；
- hyperbolic Dehn surgery / holonomy / deformation；
- *The Geometry and Topology of Three-Manifolds*；
- *On Proof and Progress in Mathematics*；
- *Geometry and the Imagination*；
- Geometry Center 相關視覺化、模型與教學實踐；
- Dunfield–Thurston computer experiments。

這些材料共同測試：

$$
\boxed{
\text{internal model}
\to
\text{external representation}
\to
\text{shared mathematical infrastructure}.
}
$$

---

# 2. Cognitive Substrate

## C1 — Abstract–Concrete Bidirectional Conversion

**L4 / OBS+INF**

$$
\boxed{
\text{formal/topological object}
\leftrightarrow
\text{geometric/dynamical model}.
}
$$

## C2 — Pre-symbolic Structure Capture

**L4 / INF**

核心 structural model 可先於 canonical formal-language alignment，但私人 mental process 不可直接觀察。

## C3 — Counterfactual / Imagined Manipulation

**L4 / OBS+INF**

主要形式：

- cut / glue；
- deformation；
- filling；
- degeneration；
- dimensional re-embodiment；
- model perturbation。

## C4 — Logical Rigor

**L4 / OBS**

Thurston 不把 understanding 當 proof 替代品，而是把兩者分開追蹤。

## C5 — Cross-domain Translation

**L4 / OBS**

$$
\text{topology}
\leftrightarrow
\text{geometry}
\leftrightarrow
\text{dynamics}
\leftrightarrow
\text{complex analysis}
\leftrightarrow
\text{group theory}.
$$

## C6 — Deep Pattern Recognition

**L4 / OBS+INF**

$$
\boxed{
\mu_6(\mathrm{Th})
=
\text{shared manipulable geometric/dynamical archetype}.
}
$$

## C7 — Problem Rewriting

**L3 / INF**

representation change 常使原問題在另一 model world 中重新顯形。

## C8 — Mathematical Aesthetics

**L4 / INF**

高權重偏好：

- canonical decomposition；
- finite model dictionary；
- deformation；
- spatial/dynamic manipulability；
- model worlds that can be mentally inhabited。

## C9 — Long-horizon Persistence

**L4 / OBS**

surface dynamics、3-manifolds、geometry、communication methodology 具有高度一致的 model-centered style。

## C10 — Metacognitive Calibration

**L4 / OBS**

明確區分：

- proof completion；
- understanding；
- audience gap；
- infrastructure；
- field ecology；
- dissemination policy。

## C11 — Latent Theory Landscape

**L4 / OBS+INF**

geometrization 是典型的「建立整個可導航研究世界」。

---

# 3. Core General Operators

Thurston 對既有 operators 的高權重 implementation：

$$
O_3=\text{Representation Switching},
$$

其 mode 為：

$$
\boxed{
\mu_3(\mathrm{Th})
=
\text{re-embodiment into a manipulable model space}.
}
$$

$$
O_{10}=\text{Local–Global Bridge},
$$

其 mode：

$$
\boxed{
\text{local geometric pieces}
+
\text{compatibility/gluing}
\to
\text{global manifold}.
}
$$

$$
O_{13}=\text{Geometrization},
$$

為本 specimen 的代表 operator。

$$
O_{14}=\text{Computation},
$$

其 mode：

$$
\boxed{
\mu_{14}(\mathrm{Th})
=
\text{experimental model feedback}.
}
$$

---

# 4. New General Operator Candidates

## O30 — Cross-Representation Reconciliation

對同一 knowledge object：

$$
\mathcal R(K)=\{R_1(K),\ldots,R_k(K)\}
$$

建立：

$$
\boxed{
\Phi_{ij}:R_i(K)\leftrightarrow R_j(K)
}
$$

並檢查 invariants 是否低損保持。

## O31 — Geometric Re-embodiment

$$
\boxed{
K\to M_K
}
$$

把抽象 object 搬入可被：

- visualize；
- deform；
- cut；
- glue；
- manipulate；

的 geometric / dynamical world。

## O32 — Decompose–Model–Reassemble

$$
\boxed{
K
\to
\{K_i\}
\to
\{M_{\alpha(i)}\}
\to
K.
}
$$

surface classification 與 geometrization 都支持此模式。

## O33 — Deformation-Space Exploration

不只研究 $K$，而研究：

$$
\boxed{
\mathcal N_{\mathrm{model}}(K).
}
$$

透過 movement、degeneration、boundary、rigidity 理解 object。

## O34 — Cognitive Infrastructure Externalization

將 private/local working model 外化成：

- notes；
- diagrams；
- models；
- simulations；
- software；
- examples；
- vocabulary；
- exercises；
- discussion protocols。

---

# 5. Six Core Thurston Clusters

## $\mathsf{Th}_A$ — Multi-Representation Reconciliation

$$
\boxed{
\text{one concept}
\to
\text{many cognitive realizations}
\to
\text{cross-representation consistency}.
}
$$

## $\mathsf{Th}_B$ — Geometric Re-embodiment

$$
\boxed{
\text{formal object}
\to
\text{spatial/geometric/dynamical working model}.
}
$$

## $\mathsf{Th}_C$ — Decompose–Model–Reassemble

$$
\boxed{
\text{complex world}
\to
\text{canonical cuts}
\to
\text{few archetypes}
\to
\text{global reconstruction}.
}
$$

## $\mathsf{Th}_D$ — Deformation-Space Manipulation

$$
\boxed{
K
\to
\mathcal N(K)
\to
\text{motion / degeneration / rigidity}
\to
\text{understanding}.
}
$$

## $\mathsf{Th}_E$ — Cognitive Infrastructure Engineering

$$
\boxed{
\text{private model}
\to
\text{external carriers}
\to
\text{shared working infrastructure}.
}
$$

## $\mathsf{Th}_F$ — Ecology-Aware Understanding Transfer

$$
\boxed{
\text{same mathematics}
+
\text{different audience}
\to
\text{different transfer interface}.
}
$$

---

# 6. Understanding Obligations

新增三個 research obligations：

$$
\boxed{
\omega_{\mathrm{understand}},
\quad
\omega_{\mathrm{transfer}},
\quad
\omega_{\mathrm{uptake}}.
}
$$

其中：

### Understand

是否具有穩定、可操控 working model？

### Transfer

指定 receiver 是否取得該 working model？

### Uptake

receiver 是否能自主：

- reuse；
- adapt；
- extend；
- apply；
- retransmit。

因此：

$$
\boxed{
\omega_{\mathrm{proof}}=1
\not\Rightarrow
\omega_{\mathrm{understand}}
=
\omega_{\mathrm{transfer}}
=
\omega_{\mathrm{uptake}}
=1.
}
$$

---

# 7. Understanding Debt

定義：

$$
\boxed{
\mathbf U(K,A)
=
(
U_{\mathrm{model}},
U_{\mathrm{crossrep}},
U_{\mathrm{manip}},
U_{\mathrm{infra}},
U_{\mathrm{transfer}},
U_{\mathrm{uptake}}
).
}
$$

可能出現：

$$
\boxed{
\mathbf V\approx0,
\qquad
\mathbf U\gg0.
}
$$

也就是 theorem 已認證，但 cognition 尚未 closure。

---

# 8. Infrastructure Gap

$$
\boxed{
I(K,A)
=
\operatorname{RequiredInfra}(K)
-
\operatorname{AvailableInfra}(A).
}
$$

若：

$$
I(K,A)\gg0,
$$

正確 routing 可能不是：

$$
K\to A,
$$

而是：

$$
\boxed{
K
\to
\operatorname{InfrastructureTransfer}
\to
A.
}
$$

---

# 9. Knowledge Carrier Set

$$
\boxed{
\mathcal C_{\mathrm{carrier}}(K)
=
\{c_1,\ldots,c_m\}.
}
$$

carrier 可包括：

- formal paper；
- informal notes；
- diagram；
- physical model；
- simulation；
- software；
- interactive visualization；
- example library；
- exercise；
- lecture；
- shared vocabulary；
- discussion protocol。

所以：

$$
\boxed{
K_{\mathrm{research}}
\neq
\sum\text{documents}.
}
$$

---

# 10. Understanding Expansion Factor

定義候選：

$$
\boxed{
\chi(K;A\to B)
=
\frac{
C_{\mathrm{externalization}}(K\mid B)
}{
C_{\mathrm{internal}}(K\mid A)
}.
}
$$

若 receiver infrastructure gap 高，必要 cognitive decompression 也可能變高。

因此：

$$
\boxed{
\text{minimal token transfer}
\neq
\text{maximal understanding transfer}.
}
$$

---

# 11. Manipulability Preservation

Thurston-style representation 的重要目標不是只保留 reconstructability，而是：

$$
\boxed{
M_{\mathrm{manip}}(R)
}
$$

即 representation 能否支援：

- prediction；
- deformation；
- specialization；
- generalization；
- construction；
- counterfactual reasoning。

---

# 12. New Dynamics

## D19 — Understanding-State Tracking

追蹤：

$$
\omega_{\mathrm{understand}}.
$$

## D20 — Audience-Conditioned Transfer

$$
\boxed{
E(K\mid A)
}
$$

而非 one-size-fits-all exposition。

## D21 — Infrastructure-Gap Bridging

先測：

$$
I(K,A),
$$

必要時先建 prerequisite bridge。

## D22 — Community-Uptake Propagation

成功 uptake 的標準至少是：

$$
\boxed{
\text{reuse}
+
\text{extend}
+
\text{retransmit}.
}
$$

## D23 — Dissemination-Policy Recalibration

Thurston 的 foliation → geometrization 經驗支持：

$$
\boxed{
\text{result-first}
\to
\text{infrastructure-first dissemination}.
}
$$

---

# 13. AI Distillation

建立以下 Agent roles：

- $A_{\mathrm{model}}$：建立 working representations；
- $A_{\mathrm{translator}}$：跨 representation 轉譯；
- $A_{\mathrm{teacher}}$：橋接 infrastructure gap；
- $A_{\mathrm{visualizer}}$：建立 spatial/dynamic carrier；
- $A_{\mathrm{uptake}}$：測 receiver 是否能自主 reuse。

Uptake 不靠詢問「你理解嗎」，而靠 unseen-task transfer：

- adjacent lemma；
- boundary prediction；
- variant repair；
- counterexample；
- analogous problem；
- onward teaching。

---

# 14. Anti-Overclaim

本版不主張：

1. visual representation 等於 understanding；
2. Thurston 所有 proof 都來自幾何直覺；
3. Geometry Center 全部成果可歸因 Thurston；
4. 公開材料能直接重建 Thurston 私人 mental states；
5. understanding 可由單一 scalar 完整量化；
6. informal notes 可替代 proof certification；
7. computer experiment 可替代 proof；
8. multi-representation robustness 等於 consciousness-level understanding。

---

# 15. Meta-Fingerprint

$$
\boxed{
\textbf{
Mathematical Understanding through
Geometric Re-embodiment,
Manipulable Multi-Representations,
and Shared Cognitive Infrastructure
}
}
$$

中文：

**以幾何再具身化、可操控多重表示與共享認知基礎設施生成數學理解。**

完整 pipeline：

$$
\boxed{
\begin{aligned}
\text{formal / complex object}
&\to
\text{geometric re-embodiment}\\
&\to
\text{archetypal decomposition}\\
&\to
\text{manipulable model space}\\
&\to
\text{multi-representation reconciliation}\\
&\to
\text{external cognitive carriers}\\
&\to
\text{audience-adaptive transfer}\\
&\to
\text{community reuse}.
\end{aligned}
}
$$

標記：

`INF — strongly supported`.

---

# 16. Final Fingerprint

$$
\boxed{
\mathfrak F_{\mathrm{Th}}^{(0.1)}
=
\text{Multi-Representation Reconciliation}
+
\text{Geometric Re-embodiment}
+
\text{Decompose–Model–Reassemble}
+
\text{Deformation-Space Manipulation}
+
\text{Cognitive Infrastructure Engineering}
+
\text{Ecology-Aware Understanding Transfer}.
}
$$

$$
\boxed{
\text{RMRM-005 / v0.1 / provisional frozen}.
}
$$
