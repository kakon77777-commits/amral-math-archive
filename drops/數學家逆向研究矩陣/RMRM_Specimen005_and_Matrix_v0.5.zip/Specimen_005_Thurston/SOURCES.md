# SOURCES

Primary / authoritative anchors:
1. William P. Thurston, On Proof and Progress in Mathematics (1994).
2. William P. Thurston, The Geometry and Topology of Three-Manifolds.
3. William P. Thurston, On the Geometry and Dynamics of Diffeomorphisms of Surfaces.
4. Thurston hyperbolic structures / Dehn surgery manuscripts and collected works.
5. Conway, Doyle, Gilman, Thurston, Geometry and the Imagination.
6. Cornell / AMS materials on Thurston and his collected works.
7. Dunfield–Thurston computational work on virtual Haken covers and 3-manifold experiments.

Evidence: OBS / INF / HYP / UNK.
Geometry Center was a community institution; its complete output is not attributed to Thurston.
