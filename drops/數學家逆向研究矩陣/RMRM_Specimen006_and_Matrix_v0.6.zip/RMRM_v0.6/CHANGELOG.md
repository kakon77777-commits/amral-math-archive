# CHANGELOG — RMRM v0.6

Date: 2026-08-15

Added from RMRM-006 Maryam Mirzakhani:
- O35 Research-Hub Construction.
- D24 Research-Asset Reinvestment.
- Hub Leverage Profile: breadth / depth / machinery reuse / search-cost reduction.
- Research Asset Node and Asset Registry.
- ResultLeverageAudit.
- HubMatch and AssetRegister in Research Router v0.3.
- Near-Domain Control as a specimen-design falsification rule.
- Explicit distinction between universality, cognitive infrastructure, and research-hub leverage.

Specimens:
RMRM-001 Tao
RMRM-002 Grothendieck
RMRM-003 Ramanujan
RMRM-004 Erdős
RMRM-005 Thurston
RMRM-006 Mirzakhani
