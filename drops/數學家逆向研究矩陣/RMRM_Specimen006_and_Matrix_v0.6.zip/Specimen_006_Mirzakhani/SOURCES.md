# SOURCES

Primary / authoritative anchors:
1. Maryam Mirzakhani, Simple geodesics and Weil–Petersson volumes of moduli spaces of bordered Riemann surfaces.
2. Maryam Mirzakhani, Weil–Petersson volumes and intersection theory on the moduli space of curves.
3. Maryam Mirzakhani, Growth of the number of simple closed geodesics on hyperbolic surfaces.
4. Maryam Mirzakhani, Ergodic theory of the earthquake flow.
5. Alex Eskin and Maryam Mirzakhani, Invariant and stationary measures for the SL(2,R) action on moduli space.
6. Alex Eskin, Maryam Mirzakhani, Amir Mohammadi, Isolation, equidistribution, and orbit closures for the SL(2,R) action on moduli space.
7. Maryam Mirzakhani, Counting Mapping Class group orbits on hyperbolic surfaces.
8. Mirzakhani–Zograf large-genus Weil–Petersson volume work.
9. IMU Fields Medal citation and Stanford methodological/memorial materials.

Joint-work attribution rule:
EM / EMM technical components remain joint achievements; only cross-corpus methodological patterns are assigned to the Mirzakhani fingerprint.

Evidence: OBS / INF / HYP / UNK.
