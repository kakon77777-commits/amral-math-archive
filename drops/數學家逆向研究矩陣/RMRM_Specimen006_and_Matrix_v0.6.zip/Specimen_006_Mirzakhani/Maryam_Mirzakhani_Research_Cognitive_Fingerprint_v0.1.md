# Maryam Mirzakhani Research Cognitive Fingerprint v0.1

**RMRM Specimen 006**

**研究框架**：Mathematician Reverse Research Matrix (RMRM)  
**Specimen**：Maryam Mirzakhani  
**日期**：2026-08-15  
**版本**：v0.1  
**狀態**：provisional frozen

## 0. 核心定位

本 specimen 以 Thurston 作為近域控制，不把 surfaces / moduli / laminations 領域本身的典型方法誤認為 Mirzakhani 個人指紋。

目前跨四期最穩定的研究骨架為：

$$
\boxed{
\text{local / discrete difficult object}
\to
\text{ambient state space}
\to
\text{global measure / dynamical law}
\to
\text{rigid or quantitative return}
\to
\text{reusable research hub}.
}
$$

因此正式 meta-fingerprint 為：

$$
\boxed{
\textbf{
Ambient Globalization,
Rigid Return,
and Research-Hub Reinvestment
}
}
$$

中文：

**母狀態空間全域化—剛性回返—研究樞紐再投資。**

證據標記：`OBS / INF / HYP / UNK`。

---

# 1. Longitudinal Phases

## Phase I — WP / Doctoral Period

核心：

- generalized McShane identities；
- bordered moduli spaces；
- Fenchel–Nielsen coordinates；
- Weil–Petersson integration；
- recursive volumes；
- tautological intersections；
- Witten–Kontsevich bridge。

典型：

$$
\boxed{
\text{cut}
\to
\text{parameterize}
\to
\text{integrate}
\to
\text{recurse}
\to
\text{export}.
}
$$

## Phase II — Simple-Geodesic Counting / Random Surfaces / Large Genus

$$
\boxed{
\text{discrete curve problem}
\to
\text{continuous measured population}
\to
\text{distribution law}
\to
\text{individual asymptotic}.
}
$$

## Phase III — Earthquake Dynamics

$$
\boxed{
D_{\mathrm{hard}}
\to
D_{\mathrm{better\ understood}}
\to
\text{transport dynamical law back}.
}
$$

## Phase IV — Eskin–Mirzakhani / EMM Rigidity

$$
\boxed{
\text{wild orbit}
\to
\text{ambient dynamical population}
\to
\text{measure rigidity}
\to
\text{affine carrier}
\to
\text{orbit classification}.
}
$$

---

# 2. Longitudinal Invariants

真正跨四期穩定的是：

$$
\boxed{
\text{Ambient State-Space Lift}
}
$$

$$
\boxed{
\text{Global-Law Extraction}
}
$$

$$
\boxed{
\text{Global-to-Individual Return}
}
$$

$$
\boxed{
\text{Architecture Transplant with Mechanism Substitution}
}
$$

$$
\boxed{
\text{Research-Hub Construction and Reinvestment}.
}
$$

`Cut–Integrate–Recurse` 因此被降為 Phase-I implementation，而不是最高階 fingerprint。

---

# 3. Cognitive Substrate

## C1 — Abstract–Concrete Bidirectional Conversion

**L4 / OBS+INF**

$$
\boxed{
\text{surface / curve}
\leftrightarrow
\text{moduli point / measured object / coordinate datum}.
}
$$

## C2 — Pre-symbolic Structure Capture

**L3 / INF**

公開大紙與圖畫工作方式可支持 external exploratory practice，但不直接推論其內在因果機制。

## C3 — Counterfactual / Branch Generation

**L4 / INF**

允許長時間維持未收斂 branch，讓旁支結果、新工具與跨域 analogies 逐步進入。

## C4 — Logical Rigor

**L4 / OBS**

跨幾何、積分、遍歷與剛性理論維持高 proof control。

## C5 — Cross-domain Translation

**L4 / OBS**

$$
\boxed{
\text{hyperbolic geometry}
\leftrightarrow
\text{moduli integration}
\leftrightarrow
\text{intersection theory}
\leftrightarrow
\text{ergodic dynamics}
\leftrightarrow
\text{rigidity}.
}
$$

## C6 — Deep Pattern Recognition

**L4 / OBS+INF**

$$
\boxed{
\mu_6(\mathrm M)
=
\text{shared ambient law across a population of geometric objects}.
}
$$

## C7 — Problem Rewriting

**L4 / OBS+INF**

把 fixed-object problem 改寫成 population / moduli / orbit problem。

## C8 — Mathematical Direction Choice

**L4 / INF**

高權重偏好：

- ambient spaces；
- natural measures；
- group actions；
- recursion / asymptotics；
- affine / rigid laws；
- reusable bridges。

## C9 — Long-Horizon Persistence

**L4 / OBS+INF**

從博士期到 EM/EMM collaborative period，高階架構持續存在。

## C10 — Metacognitive Calibration

**L3 / INF**

保留 long-horizon search tolerance；不把「slow」當能力尺度。

## C11 — Latent-Theory Landscape

**L4 / OBS+INF**

moduli / strata 被反覆用成可導航的 ambient research worlds。

---

# 4. Existing Operators — Mirzakhani Modes

## O3 — Representation Switching

$$
\boxed{
\mu_3(\mathrm M)
=
\text{counting / rigidity-oriented continuous envelope}.
}
$$

## O4 — Proof-Architecture Transplant

EM collaborative corpus 的 implementation：

$$
\boxed{
\mu_4(\mathrm M)
=
\text{rigidity architecture transplant with mechanism substitution}.
}
$$

joint-work attribution 保留：不將每個 technical innovation 單獨歸於 Mirzakhani。

## O10 — Local–Global Bridge

$$
\boxed{
\text{local datum}
\to
\text{ambient state space}
\to
\text{global law}
\to
\text{return}.
}
$$

## O11 — Average–Individual Bridge

$$
\boxed{
\mu_{11}(\mathrm M)
=
\text{moduli integration / ergodic return}.
}
$$

---

# 5. Core Clusters

## $\mathsf M_A$ — Ambient State-Space Lift

$$
\boxed{
X\to\mathcal A(X).
}
$$

將 fixed / local / discrete object 放入：

- moduli space；
- measured lamination space；
- stratum；
- dynamical orbit space。

## $\mathsf M_B$ — Global-Law Extraction

在 ambient world 中加入：

$$
\mu,\quad
\omega,\quad
\text{flow},\quad
G\text{-action},\quad
\text{coordinates},
$$

並抽取：

- recursion；
- polynomiality；
- scaling；
- ergodicity；
- equidistribution；
- rigidity。

## $\mathsf M_C$ — Global-to-Individual Return

$$
\boxed{
X
\to
\mathcal A
\to
L_{\mathcal A}
\to
P(X).
}
$$

## $\mathsf M_D$ — Architecture Transplant with Mechanism Substitution

$$
\boxed{
\text{foreign architecture}
\to
\text{target domain}
\to
\text{mechanism mismatch}
\to
\text{replacement engine}
\to
\text{analogous global theorem}.
}
$$

## $\mathsf M_E$ — Research-Hub Construction and Reinvestment

$$
\boxed{
\{P_i\}
\to
H
\to
\{Q_j\}.
}
$$

代表性 hub：

### $H_{\mathrm{WP}}$

Weil–Petersson integration / volume machinery。

出口包括：

- volume recursion；
- intersection theory；
- Witten–Kontsevich；
- geodesic counting；
- random surfaces；
- large-genus asymptotics。

### $H_{\mathrm{aff}}$

strata / period coordinates / affine invariant submanifold infrastructure。

出口包括：

- measure classification；
- orbit closure；
- equidistribution；
- downstream affine-invariant-submanifold research。

---

# 6. New Global Operator

## O35 — Research-Hub Construction

定義：

> 建立 reusable intermediate structure $H$，使多個不同 research obligations 可 route 進 $H$，並透過同一核心 machinery 產生多個 downstream outputs。

形式：

$$
\boxed{
\{P_i\}_{i=1}^{m}
\to
H
\to
\{Q_j\}_{j=1}^{n}.
}
$$

必要判準：

1. Multiple independent interfaces；
2. Core machinery reuse；
3. Observable search-cost reduction / avoided method-stack reconstruction。

所以：

$$
\boxed{
\text{important theorem}
\not\Rightarrow
\text{research hub}.
}
$$

---

# 7. Hub Leverage Profile

$$
\boxed{
\mathbf H(H)
=
(
H_{\mathrm{breadth}},
H_{\mathrm{depth}},
H_{\mathrm{reuse}},
H_{\mathrm{costred}}
).
}
$$

初期採 qualitative：

`low / medium / high / extreme / UNK`。

---

# 8. New Dynamic

## D24 — Research-Asset Reinvestment

$$
\boxed{
\text{Research Output}
\to
\text{Reusable Research Asset}.
}
$$

可再投資對象：

- theorem；
- recursion；
- invariant；
- representation；
- proof architecture；
- dataset；
- software；
- moduli/state space；
- ontology。

---

# 9. Problem Reproduction vs Result Reinvestment

Erdős：

$$
\boxed{
P
\to
P_1,P_2,\ldots
}
$$

Mirzakhani：

$$
\boxed{
T
\to
H
\to
Q_1,Q_2,\ldots
}
$$

研究系統因此應同時執行：

$$
\boxed{
\operatorname{ProblemDerivative}(P)
}
$$

以及：

$$
\boxed{
\operatorname{ResultLeverageAudit}(T).
}
$$

---

# 10. Long-Horizon Branch Tolerance

作為 supporting dynamic：

$$
\boxed{
\text{允許長時間維持未收斂 problem state}
}
$$

並讓新方法、side results、cross-domain analogies 逐步進入。

標記：

`L3 / INF`。

不列入最高階 meta-fingerprint。

---

# 11. Near-Domain Control — Thurston

兩者 domain overlap 高：

$$
\text{surfaces},
\quad
\text{moduli},
\quad
\text{laminations},
\quad
\text{dynamics}.
$$

但：

$$
\boxed{
\text{Thurston}:
\text{Model Space}
\to
\text{Manipulable Understanding},
}
$$

$$
\boxed{
\text{Mirzakhani}:
\text{Ambient State Space}
\to
\text{Global Law}
\to
\text{Rigid Quantitative Return}.
}
$$

因此目前控制結果強烈支持：

$$
\boxed{
\text{RMRM 捕捉的不只是 domain signature}.
}
$$

---

# 12. AI Distillation

## M-A — Ambient Lift Agent

問：

> 單一 object 問題是否應先升成整體 population / moduli / state-space 問題？

## M-B — Global Structure Agent

搜尋：

- measure；
- form；
- flow；
- group action；
- coordinates；
- invariant subspaces。

## M-C — Global-Law Extractor

搜尋：

- recursion；
- scaling；
- polynomiality；
- equidistribution；
- ergodicity；
- rigidity；
- asymptotics。

## M-D — Return Agent

把 global law 回填到 individual problem。

## M-E — Architecture Porter

保留 proof architecture，替換 domain-incompatible mechanism。

## M-F — Hub Builder

將 reusable intermediate structures 註冊為 research assets。

## M-G — Leverage Auditor

每完成 theorem / lemma / recursion 後執行：

$$
\boxed{
\operatorname{LeverageAudit}(T).
}
$$

---

# 13. Anti-Overclaim

本版不主張：

1. Mirzakhani 所有研究都由單一 moduli-space strategy 產生；
2. 她的圖畫直接等於 proof-generation mechanism；
3. 「slow mathematician」是能力尺度；
4. EM / EMM 所有技術創新可單獨歸因於 Mirzakhani；
5. theorem 重要就自動是 research hub；
6. Hub Leverage 已能精確數值化；
7. ambient globalization 是 geometry 專屬方法；
8. near-domain control 已完全排除所有 domain effect。

---

# 14. Final Fingerprint

$$
\boxed{
\mathfrak F_{\mathrm M}^{(0.1)}
=
\text{Ambient State-Space Lift}
+
\text{Global-Law Extraction}
+
\text{Global-to-Individual Return}
+
\text{Architecture Transplant with Mechanism Substitution}
+
\text{Research-Hub Construction and Reinvestment}.
}
$$

$$
\boxed{
\text{RMRM-006 / v0.1 / provisional frozen}.
}
$$
