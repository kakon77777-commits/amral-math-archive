# Terence Tao Research Cognitive Fingerprint v0.1

**RMRM Specimen 001**

**研究框架**：Mathematician Reverse Research Matrix (RMRM) v0.1  
**Specimen**：Terence Tao  
**編製**：Neo.K / EveMissLab；Aletheia / GPT-5.6 Sol 協作整理  
**日期**：2026-08-14  
**版本**：v0.1  
**定位**：數學研究方法論逆向工程／縱向版本分析／可比較研究認知指紋

---

## 0. 研究聲明

本文不是 Terence Tao 的人格分析，也不是對其「天才程度」的評分。

本文只研究公開可觀測的數學研究行為：

- 問題如何被重寫；
- 表示如何被切換；
- obstruction 如何被定位；
- 中介結構如何被建立；
- near-counterexample 如何被利用；
- proof interface 如何被修改；
- 論文如何跨版本維護；
- 方法的適用邊界如何被標示；
- 舊失敗研究如何被新工具重新活化。

因此本文的輸出不是：

$$
\text{Genius Score},
$$

而是：

$$
\boxed{
\mathfrak F_{\mathrm{Tao}}^{(0.1)}
=
(
\mathcal C,
\mathcal O,
\mathcal D;
\mathcal E
)
}
$$

其中：

- $\mathcal C$：認知能力底座；
- $\mathcal O$：研究操作算子；
- $\mathcal D$：動態研究循環；
- $\mathcal E$：可觀測證據。

所有判斷使用：

- `OBS`：直接可觀測；
- `INF`：由多個公開研究行為支持的推論；
- `HYP`：待更多 specimen 驗證；
- `UNK`：公開資料不足。

---

# 1. Corpus

本版選取三個主 specimen 與一組方法論自述。

## Specimen A — Collatz

Terence Tao, *Almost all orbits of the Collatz map attain almost bounded values*, arXiv:1909.03562.

核心結論是：對任意趨向無限的函數 $f(N)$，幾乎所有正整數 $N$ 的 Collatz 軌道都會降到 $f(N)$ 以下；這裡的「幾乎所有」使用 logarithmic density。

其 proof spine 為：

$$
\boxed{
\text{Collatz}
\to
\text{Syracuse}
\to
\text{valuation code}
\to
\text{approximate transport}
\to
3\text{-adic characteristic functions}
\to
\text{2D renewal geometry}.
}
$$

版本歷史：

$$
v1_{2019}
\to
v2_{2019}
\to
v3_{2020}
\to
v4_{2021}
\to
v5_{2022}
\to
v6_{2026}
\to
v7_{2026}.
$$

截至 2026-07-16 為 $v7$。

## Specimen B — Averaged Navier–Stokes

Terence Tao, *Finite time blowup for an averaged three-dimensional Navier-Stokes equation*, arXiv:1402.0290.

研究核心不是直接證真正 Navier–Stokes blowup，而是建立一個 averaged nonlinear operator $\widetilde B$，保留 energy cancellation 及大量 harmonic-analysis 型控制，卻仍然可 finite-time blow up。

因此得到 barrier：

$$
\boxed{
\text{energy identity}
+
\text{generic harmonic-analysis estimates}
\not\Rightarrow
\text{global regularity}.
}
$$

這迫使任何真正的正向 regularity proof 必須使用 Navier–Stokes 非線性 $B(u,u)$ 的更細緻結構。

版本歷史：

$$
v1_{2014}
\to
v2_{2014}
\to
v3_{2015}.
$$

$v3$ 依 referee correction 將 averaging class 擴張至 dilation、Fourier multiplier、rotation。

## Specimen C — Erdős discrepancy

Terence Tao, *The Erdős discrepancy problem*, arXiv:1509.05363.

proof spine：

$$
\boxed{
\text{general sequence}
\to
\text{stochastic completely multiplicative model}
\to
\text{pretentious structured candidate}
\to
\text{Dirichlet-character-like enemy}
\to
\bot.
}
$$

三個主要 ingredient：

1. Polymath5 的 Fourier-analytic reduction；
2. logarithmically averaged Elliott theorem；
3. generalized Borwein–Choi–Coons / Polymath5 terminal argument。

版本歷史：

$$
v1_{2015}
\to
v2_{2015}
\to
v3_{2015}
\to
v4_{2015}
\to
v5_{2015}
\to
v6_{2017}.
$$

伴生工具論文：

Terence Tao, *The logarithmically averaged Chowla and Elliott conjectures for two-point correlations*, arXiv:1509.05422.

其中包含 entropy decrement argument，並在最終版吸收第二輪 referee comments。

## Methodology Corpus

另參考 Tao 公開方法論文章：

- *On the importance of partial progress*；
- *245A: Problem solving strategies*；
- *Be sceptical of your own work*；
- Collatz、Erdős discrepancy、Navier–Stokes 的作者研究博客。

這些材料用來區分：

$$
\text{我們從論文推論的研究習慣}
$$

與：

$$
\text{作者自己公開描述的方法論}.
$$

---

# 2. 第一層：Cognitive Substrate

以下強度等級：

- L0：未知；
- L1：偶發；
- L2：重複出現；
- L3：穩定；
- L4：跨問題高度標誌性。

L4 不是世界排名，而是「在目前 corpus 中高度穩定」。

## C1. 抽象—具體雙向轉換

**初判：L4 / OBS+INF**

Tao 的研究不只是往更高抽象層移動，而會反覆：

$$
\text{抽象}
\leftrightarrow
\text{toy model}
\leftrightarrow
\text{countermodel}
\leftrightarrow
\text{幾何化}
\leftrightarrow
\text{原問題}.
$$

在公開 problem-solving 指南中，他也明確建議先考慮較簡單但仍保留困難本質的模型問題。

## C2. 前符號結構捕捉

**初判：L2 / INF**

公開成果可顯示 Tao 經常重新命名或重新切出中層研究對象，例如：

- first-passage random variable；
- local cascade operator；
- entropy decrement mechanism；
- pretentious structured enemy。

但「概念形成前的內部狀態」不可由公開材料直接觀察，因此不升至 L3/L4。

## C3. 想像與反事實生成

**初判：L4 / OBS**

averaged Navier–Stokes 是極強 specimen：

$$
\text{保留一組結構}
+
\text{修改另一組結構}
+
\text{觀察 pathology 是否仍存活}.
$$

這是制度化的反事實數學。

## C4. 邏輯嚴謹與證明鏈維護

**初判：L4 / OBS**

最明顯證據不是「論文長」，而是版本修正會精確落在：

- first-passage event；
- numerical constants；
- lemma domain；
- non-degeneracy；
- residual multiplicative perturbation。

## C5. 概念／領域轉換

**初判：L4 / OBS**

Collatz 中從 PDE local/global architecture 吸收思想，是公開明說的跨域 proof-architecture transplant。

此外不同案例反覆使用 Fourier、probability、renewal、ODE cascade、multiplicative number theory 等表示。

## C6. 深層模式識別

**初判：L4 / INF**

跨三個 specimen 的共同模式不是同一 theorem，而是：

$$
\boxed{
\text{巨大未知空間}
\to
\text{低複雜度 obstruction}
\to
\text{專用攻擊}.
}
$$

## C7. 問題提出／重寫

**初判：L4 / OBS**

Navier–Stokes 的問題被改寫為：

> 哪些通常被使用的 regularity resources 本身不足？

Collatz 則將 full conjecture 降到可精確處理的 almost-all statement。

Erdős discrepancy 則先轉到 multiplicative stochastic model。

## C8. 數學審美與方向選擇

**初判：L3 / INF**

可觀察到偏好：

- canonical representation；
- invariant / approximate-invariant structures；
- low-complexity structured obstructions；
- 可重用 proof interfaces。

但審美屬於部分內在判斷，因此不以公開結果直接推成 L4。

## C9. 長期韌性與研究時間尺度

**初判：L4 / OBS**

Collatz 論文從 2019 到 2026 仍有正式版本更新；Navier–Stokes barrier program 亦跨多年延展。

## C10. 元認知校準

**初判：L4 / OBS**

Tao 經常明確區分：

$$
\text{method limit}
\neq
\text{theorem false}.
$$

Collatz 論文明確指出 fixed absolute bound 幾乎與 full conjecture 同級，超出該方法。

averaged Navier–Stokes 則明確說明它證明的是 barrier，而非 true Navier–Stokes blowup。

---

# 3. 第二層：Research Operators

## O1. 問題定向

**L4 / OBS**

反覆先找：

$$
\boxed{
\text{真正卡住 proof 的是哪一層？}
}
$$

而不是直接增加計算量。

## O2. 問題降階／加速／規範化

**L4 / OBS**

Collatz 使用 Syracuse acceleration，是因為 proof 需要 $3$-adic analysis，而不是因為 Syracuse 形式單純較漂亮。

Navier–Stokes 則以 averaged system 建立 barrier model。

## O3. Representation Cascade

**L4 / OBS**

Tao 最強標誌之一。

Collatz：

$$
\text{orbit}
\to
\text{valuation}
\to
\text{random affine}
\to
3\text{-adic}
\to
\text{Fourier}
\to
\text{renewal geometry}.
$$

Erdős discrepancy：

$$
\text{arbitrary sign sequence}
\to
\text{multiplicative stochastic object}
\to
\text{pretentious object}.
$$

## O4. Proof-Architecture Transplant

**L4 / OBS**

Collatz 的 local-to-almost-global strategy 明確受 Bourgain 非線性 PDE 方法啟發。

這不是單一 theorem 套用，而是：

$$
\text{proof architecture}_{A}
\rightsquigarrow
\text{proof architecture}_{B}.
$$

## O5. 不變量抽取

**L3 / OBS**

在 Navier–Stokes barrier model 中，刻意保留 energy cancellation；後續高 fidelity model 又逐步加回更多 fluid structure。

## O6. Obstruction Localization

**L4 / OBS+INF**

三個 specimen 都高度出現。

其研究動作可抽象為：

$$
P
\rightsquigarrow
\{G_1,\ldots,G_k\}.
$$

## O7. 中介定理生成

**L4 / OBS**

大量 proof 被拆成明確 bridge theorem / proposition，而不是單線推導。

## O8. 逆向條件回填

**L3 / INF**

Erdős discrepancy 尤其明顯：需要某種 Elliott input，之後再調整下游接口以接受較弱的 averaged theorem。

## O9. 例外集管理

**L4 / OBS**

Collatz 的核心困難之一就是：

$$
\text{第一階段 almost-all set}
$$

可能被映入：

$$
\text{下一階段 exceptional set}.
$$

因此必須建立 alternate approximate transport measure。

## O10. Local–Global Bridge

**L4 / OBS**

Collatz 是最直接 specimen。

## O11. Average–Individual Bridge

**L3 / OBS**

在 Collatz、multiplicative number theory 中皆是核心 tension。

但目前 corpus 不足以判定此 operator 在 Tao 全研究生涯中的普遍程度。

## O12. Dual / Fourier Transformation

**L4 / OBS**

三個 specimen 均有高權重 Fourier / characteristic-function / multiplier 結構。

## O13. Geometrization of Obstruction

**L3 / OBS**

Collatz 最終將 high-frequency characteristic-function 問題轉成：

$$
\text{2D renewal process}
+
\text{triangular regions}.
$$

## O14. Computation / Counterexample Pruning

**L4 / OBS**

Tao 公開 problem-solving 方法論明確建議：

- 畫圖；
- 找反例；
- 找模型問題；
- 精確研究方法失敗的位置。

averaged Navier–Stokes 則是大型 countermodel specimen。

## O15. Proof Compression / Expansion

**L4 / OBS**

Tao 同時有：

- 正式長證明；
- blog proof sketch；
- lecture-level conceptual compression；
- 對 heuristic 的嚴格化。

## O16. Research Boundary Detection

**L4 / OBS**

多個 specimen 明確標出：

$$
\text{此方法可到哪裡}
$$

以及：

$$
\text{再強一步需要新 structure}.
$$

## O17. Degeneracy Breaking

**L3 / OBS**

在 averaged Navier–Stokes $v3$，referee 指出的 non-degeneracy failure 促使 averaging class 加入 dilation，使 frequency geometry 離開退化 locus。

抽象形式：

$$
\boxed{
\text{detect accidental degeneracy}
\to
\text{inject controlled degree of freedom}
\to
\text{restore non-degeneracy}.
}
$$

目前只有一個強 specimen，因此暫為 L3。

## O18. Near-Counterexample Tomography

**L4 / OBS+INF**

Erdős discrepancy introduction 系統考察多類 near-counterexamples：

$$
\mathcal N(P)
=
\{\text{almost-failing examples}\}.
$$

研究的不是只有：

$$
\exists\text{ counterexample?}
$$

而是：

$$
\operatorname{Struct}(\mathcal N(P)).
$$

即：

> theorem 若失敗，敵人最可能具有什麼結構？

## O19. Minimal-Sufficient-Input Retargeting

**L4 / OBS**

Erdős discrepancy 是乾淨 specimen。

原先證明接口期待較強 Elliott input：

$$
A\Rightarrow P.
$$

實際取得較弱 averaged theorem：

$$
A'.
$$

Tao 沒有必須先證：

$$
A'\Rightarrow A,
$$

而是修改下游 argument，使：

$$
\boxed{
A'\Rightarrow P.
}
$$

因此：

$$
\boxed{
\text{不是一味追求更強工具，
而是降低 proof interface 的最低必要需求。}
}
$$

---

# 4. 第三層：Research Dynamics

## D1. Partial Progress Preservation

**L4 / OBS**

Tao 公開主張 partial progress 本身具有高研究價值，因為失敗點可以揭露：

- 哪部分已解；
- 哪個 structure 缺失；
- 哪些方法互補。

## D2. Branch Management

**L3 / INF**

可看到多種 model / special case / partial theorem 被保留，而非只有 winner-takes-all 路線。

但完整私人分支狀態無法觀察。

## D3. Dynamic Knowledge-Space Expansion

**L4 / OBS**

Polymath5 在 2010 未解 Erdős discrepancy，但留下 Fourier reduction 與相關結構。

2015 新的 multiplicative-function tools 出現後，舊 dormant interface 被重新接通。

## D4. Version Evolution

**L4 / OBS**

三條主要研究線都具有多版本演化。

尤其 Collatz：

$$
2019\to2026.
$$

## D5. Revision Mode Classification

目前觀察到：

- $R_1$：量詞／domain 校準；
- $R_2$：proof gap / local mechanism；
- $R_3$：representation class 擴張。

但三個 specimen 中沒有看到主 proof architecture 被版本更新全面推翻。

## D6. Longitudinal Method Consistency

**L4 / INF**

跨 Collatz、Navier–Stokes、Erdős discrepancy，反覆出現：

$$
\text{representation}
\to
\text{obstruction}
\to
\text{structured reduction}
\to
\text{specialized closure}.
$$

## D7. Proof Interface Hardening

**L4 / OBS+INF**

定義：

> 長期版本更新中，持續校準 theorem、lemma、量詞、適用域、依賴條件與下游調用接口。

Collatz 中可以看到：

- early proof gap；
- quantitative constants；
- referee-driven reformulation；
- publication 後仍修 lemma statement。

## D8. Countermodel Fidelity Ascent

**L4 / OBS+INF**

Navier–Stokes 線：

$$
\text{averaged model}
\to
\text{identify missing true-fluid structure}
\to
\text{higher-fidelity pathological model}.
$$

其核心不是單純「造假的 PDE」，而是：

$$
\boxed{
\text{逐步把真系統結構加回反模型，
直到 pathology 無法維持。}
}
$$

這可以用來定位可能真正負責 regularity 的結構。

## D9. Dormant Branch Reactivation

**L3 / OBS+INF**

Polymath5 的未完成研究在後來的新工具出現後重新成為有效 proof infrastructure。

---

# 5. Revision Engine

## 5.1 Revision Depth

定義：

$$
R_0<R_1<R_2<R_3<R_4<R_5.
$$

- $R_0$：文字／notation；
- $R_1$：常數／量詞／適用域；
- $R_2$：lemma mechanism / proof gap；
- $R_3$：representation class；
- $R_4$：proof architecture；
- $R_5$：theorem target / research problem。

目前三 specimen：

### Collatz

主要 revision：

$$
R_1\sim R_2.
$$

核心 architecture 從早期已相對穩定。

### Averaged Navier–Stokes

referee correction 到：

$$
R_3,
$$

因為 admissible averaging class 必須新增 dilation。

但主 barrier target 與 cascade architecture 仍保留。

### Erdős discrepancy

$v1\to v2$ 對 residual multiplicative factor 的處理屬：

$$
R_2.
$$

後續則大量包含 probabilistic exposition、boundary case 與 formulation hardening。

## 5.2 Minimum Necessary Revision Principle

**狀態：HYP（高可信候選）**

目前版本鏈支持：

$$
\boxed{
\text{修正盡可能停在足以恢復 proof 的最低必要層。}
}
$$

若 $R_1$ 能解，不升 $R_2$；

若 $R_3$ 足以修復，不跳 $R_4$。

仍需更多 Tao corpus 才能升成 longitudinal theorem-like fingerprint。

---

# 6. 四個核心 Tao Operator Clusters

## $\mathsf T_1$ — Representation Cascade

$$
\boxed{
P_0
\overset{\Phi_1}{\to}
P_1
\overset{\Phi_2}{\to}
\cdots
\overset{\Phi_r}{\to}
P_r
}
$$

研究忠誠對象不是固定表示，而是需要保留的 obstruction。

## $\mathsf T_2$ — Proof Interface Hardening

$$
\boxed{
\text{detect interface debt}
\to
\text{localize}
\to
\text{calibrate}
\to
\text{rewire}
\to
\text{preserve core}.
}
$$

## $\mathsf T_3$ — Countermodel Fidelity Ascent

$$
\boxed{
\text{countermodel}
\to
\text{missing structure}
\to
\text{higher fidelity}
\to
\text{retest pathology}.
}
$$

## $\mathsf T_4$ — Structured-Enemy Compression

$$
\boxed{
\text{arbitrary enemy}
\to
\text{constrained enemy}
\to
\text{low-complexity enemy}
\to
\text{specialized elimination}.
}
$$

---

# 7. Meta-Fingerprint

目前三個跨域 specimen 最穩定的共同結構可壓縮為：

$$
\boxed{
\textbf{Obstruction-Centered Research Compilation}
}
$$

即：

$$
\boxed{
P
\overset{\mathrm{compile}}{\longrightarrow}
G
\overset{\mathrm{structure}}{\longrightarrow}
G'
\overset{\mathrm{specialized\ attack}}{\longrightarrow}
\bot
\text{ or closure}.
}
$$

其中真正的中心是：

$$
\boxed{
\text{the obstruction currently under interrogation}.
}
$$

表示、模型、工具、量詞甚至 proof interface 都可以為它重新配置。

因此目前最精確的縱向描述不是：

> Tao 知道很多數學。

而是：

> **Tao 反覆將不可直接攻擊的未知空間編譯成少數可命名、低複雜度、可被特定工具攻擊的 obstruction，並在工具不足時重新降低證明接口需求，而非只是一味增強上游 theorem。**

狀態：

`INF — strongly supported by three independent specimens`.

---

# 8. 雙循環模型

目前可辨認兩條互補 research loop。

## Forward Loop

$$
\boxed{
\text{Problem}
\to
\text{Representation}
\to
\text{Obstruction}
\to
\text{Structured Reduction}
\to
\text{Proof}.
}
$$

## Adversarial Loop

$$
\boxed{
\text{Claimed Proof Resources}
\to
\text{Countermodel}
\to
\text{Pathology}
\to
\text{Missing Structure}
\to
\text{Higher-Fidelity Countermodel}.
}
$$

二者共同作用：

$$
\boxed{
\Omega_{\mathrm{proof}}
\longrightarrow
\Omega_{\mathrm{proof}}'
\subset
\Omega_{\mathrm{proof}}.
}
$$

所以 Tao 在這些案例中不只是在找 proof。

更像是在：

$$
\boxed{
\text{繪製 theorem 周圍的 proof-space geometry}.
}
$$

---

# 9. RMRM Evidence Matrix

| 維度 | 強度 | 標記 | 主要 specimen |
|---|---:|---|---|
| C1 抽象—具體雙向轉換 | L4 | OBS+INF | 三者＋方法論文章 |
| C2 前符號結構捕捉 | L2 | INF | 多個新中層對象 |
| C3 反事實生成 | L4 | OBS | averaged N–S |
| C4 邏輯／依賴維護 | L4 | OBS | revision history |
| C5 跨域轉換 | L4 | OBS | Collatz ← PDE |
| C6 深層模式識別 | L4 | INF | 三 specimen |
| C7 問題重寫 | L4 | OBS | 三 specimen |
| C8 數學審美 | L3 | INF | 多案例 |
| C9 長期研究尺度 | L4 | OBS | Collatz / N–S |
| C10 元認知校準 | L4 | OBS | Collatz / N–S |
| O1 問題定向 | L4 | OBS | 三 specimen |
| O2 降階／規範化 | L4 | OBS | Collatz / N–S |
| O3 Representation Cascade | L4 | OBS | Collatz / EDP |
| O4 Proof-Architecture Transplant | L4 | OBS | Collatz |
| O5 不變量抽取 | L3 | OBS | N–S |
| O6 Obstruction Localization | L4 | OBS+INF | 三 specimen |
| O7 中介定理生成 | L4 | OBS | 三 specimen |
| O8 逆向條件回填 | L3 | INF | EDP |
| O9 例外集管理 | L4 | OBS | Collatz |
| O10 Local–Global Bridge | L4 | OBS | Collatz |
| O11 Average–Individual Bridge | L3 | OBS | Collatz / NT |
| O12 Dual/Fourier | L4 | OBS | 三 specimen |
| O13 Geometrization | L3 | OBS | Collatz |
| O14 反例／模型剪枝 | L4 | OBS | N–S＋自述 |
| O15 Proof Compression/Expansion | L4 | OBS | papers/blogs |
| O16 Boundary Detection | L4 | OBS | Collatz / N–S |
| O17 Degeneracy Breaking | L3 | OBS | N–S revision |
| O18 Near-Counterexample Tomography | L4 | OBS+INF | EDP |
| O19 Minimal-Sufficient-Input Retargeting | L4 | OBS | EDP |
| D1 Partial Progress Preservation | L4 | OBS | 方法論自述 |
| D2 Branch Management | L3 | INF | 多案例 |
| D3 Knowledge-Space Expansion | L4 | OBS | Polymath5→2015 |
| D4 Version Evolution | L4 | OBS | 三 specimen |
| D5 Revision Mode | L3 | OBS | 三版本鏈 |
| D6 Longitudinal Consistency | L4 | INF | 三 specimen |
| D7 Proof Interface Hardening | L4 | OBS+INF | Collatz / EDP |
| D8 Countermodel Fidelity Ascent | L4 | OBS+INF | N–S |
| D9 Dormant Branch Reactivation | L3 | OBS+INF | Polymath5→EDP |

---

# 10. 目前不能下的結論

以下維度必須保留：

## UNK-1：私人直覺的實際生成方式

公開論文無法直接告訴我們 Tao 在第一個概念出現前「看到」什麼。

因此：

$$
C2
$$

只能部分逆向。

## UNK-2：失敗分支的完整數量與比例

發表論文與 blog 只留下可公開痕跡。

不能把：

$$
\text{observed failed branches}
$$

當成：

$$
\text{all failed branches}.
$$

## UNK-3：合作研究中的細粒度歸因

Polymath、合著論文與共同體工具必須另外建立 collaboration-aware matrix，不能把集體方法全部歸因給 Tao。

## UNK-4：領域知識量與 operator ability 的因果方向

目前只能說二者高度耦合。

不能直接斷言：

$$
\text{跨域能力}
=
\text{representation switching}
$$

而與知識量無關。

## UNK-5：是否存在尚未觀測的完全不同 Tao-mode

三個 specimen 都偏 analysis / number theory / dynamics / PDE 型問題。

不能據此聲稱覆蓋其全部數學研究型態。

---

# 11. 對 AI 方法論蒸餾的可轉移部分

RMRM 的目的不是模仿語氣或「扮演 Tao」。

真正可移植的是 operator。

## AI Module A — Obstruction Compiler

輸入：

$$
P.
$$

輸出：

$$
\{G_1,\ldots,G_k\}
$$

並為每個 $G_i$ 產生：

- 可觀測證據；
- 等價表示；
- known tools；
- countermodel；
- failure mode。

## AI Module B — Representation Search

對每個 obstruction 搜尋：

$$
\Phi_i:
G
\mapsto
G_i'.
$$

評估：

- 結構保留度；
- 工具可用度；
- 複雜度；
- 量詞損失；
- 例外集成本。

## AI Module C — Near-Counterexample Tomography

主動生成：

$$
\mathcal N(P)
$$

並聚類：

$$
\operatorname{Struct}(\mathcal N(P)).
$$

## AI Module D — Minimal Input Retargeter

若目標 proof 原需：

$$
A\Rightarrow P,
$$

但目前只能得到：

$$
A',
$$

AI 不應只嘗試：

$$
A'\Rightarrow A.
$$

還要自動搜索：

$$
\boxed{
A'\Rightarrow P
}
$$

的新 bridge。

## AI Module E — Countermodel Fidelity Ladder

建立：

$$
M_0,M_1,\ldots
$$

使：

$$
\mathcal S(M_0)
\subset
\mathcal S(M_1)
\subset
\cdots
\subset
\mathcal S(P),
$$

並反覆測試 pathology。

## AI Module F — Revision Depth Controller

發現錯誤時依序測試：

$$
R_0,R_1,\ldots,R_5
$$

並優先尋找最低必要修正層。

這不是要求 AI 模仿 Tao。

而是把可重用研究操作變成：

$$
\boxed{
\text{methodological primitives}.
}
$$

---

# 12. 最終 v0.1 指紋

目前最短的描述：

$$
\boxed{
\mathfrak F_{\mathrm{Tao}}^{(0.1)}
=
\text{Obstruction-Centered Research Compilation}
+
\text{Representation Cascade}
+
\text{Structured-Enemy Compression}
+
\text{Interface Retargeting}
+
\text{Countermodel Fidelity Ascent}
+
\text{Longitudinal Proof Hardening}.
}
$$

更口語化但仍相對精確：

> **面對過硬問題，先重新編譯問題；面對不可控失敗，先把敵人強迫成低複雜度結構；面對工具不夠強，不一定把工具做到最強，而是重新降低 proof interface 的最低需求；面對反模型，逐步增加與真問題的結構相似度；面對版本缺陷，盡可能在最低必要層修復並保留已穩定的主架構。**

此描述目前標記：

`INF — v0.1 longitudinal fingerprint`.

---

# 13. 後續規則

Tao Specimen 001 在 v0.1 暫時封存。

除非未來出現：

- 明顯反例；
- 新研究材料；
- 跨數學域的新 operator；
- 或比較其他數學家後發現 RMRM 維度不足；

否則不繼續無限細拆 Tao。

下一階段應換第二個數學家，使 RMRM 開始具備：

$$
\boxed{
\text{cross-mathematician contrast}.
}
$$

只有當大量 specimen 完成後，才進入：

$$
\boxed{
\text{operator library}
\to
\text{method clustering}
\to
\text{AI dynamic composition}.
}
$$

最終目標不是：

$$
\text{AI imitates famous mathematician}.
$$

而是：

$$
\boxed{
\text{AI learns a recomposable library of research methodologies}.
}
$$

---

# References

1. Terence Tao, *Almost all orbits of the Collatz map attain almost bounded values*, arXiv:1909.03562, 2019–2026.
2. Terence Tao, *Finite time blowup for an averaged three-dimensional Navier-Stokes equation*, arXiv:1402.0290, 2014–2015.
3. Terence Tao, *The Erdős discrepancy problem*, arXiv:1509.05363, 2015–2017.
4. Terence Tao, *The logarithmically averaged Chowla and Elliott conjectures for two-point correlations*, arXiv:1509.05422, 2015–2016.
5. Terence Tao, *On the importance of partial progress*, What's new.
6. Terence Tao, *245A: Problem solving strategies*, What's new, 2010.
7. Terence Tao, *Be sceptical of your own work*, What's new.
8. Terence Tao, *Almost all Collatz orbits attain almost bounded values*, What's new, 2019.
9. Terence Tao, *The Erdős discrepancy problem via the Elliott conjecture*, What's new, 2015.
10. Terence Tao, *The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdős discrepancy problem*, What's new, 2015.
11. Terence Tao, discussion of Euler/vorticity-type blowup models, What's new, 2016.

