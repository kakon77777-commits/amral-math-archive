# Sources

Primary public sources used for RMRM Specimen 001.

1. Tao, Terence. *Almost all orbits of the Collatz map attain almost bounded values*. arXiv:1909.03562. Versions v1 (2019-09-08) through v7 (2026-07-16).
2. Tao, Terence. *Finite time blowup for an averaged three-dimensional Navier-Stokes equation*. arXiv:1402.0290. Versions v1 (2014-02-03) through v3 (2015-04-01).
3. Tao, Terence. *The Erdős discrepancy problem*. arXiv:1509.05363. Versions v1 (2015-09-17) through v6 (2017-01-13).
4. Tao, Terence. *The logarithmically averaged Chowla and Elliott conjectures for two-point correlations*. arXiv:1509.05422. Versions v1 (2015-09-17) through v4 (2016-07-29).
5. Tao, Terence. *On the importance of partial progress*. What's new.
6. Tao, Terence. *245A: Problem solving strategies*. What's new, 2010-10-21.
7. Tao, Terence. *Be sceptical of your own work*. What's new.
8. Tao, Terence. *Almost all Collatz orbits attain almost bounded values*. What's new, 2019-09-10.
9. Tao, Terence. *The Erdős discrepancy problem via the Elliott conjecture*. What's new, 2015-09-11.
10. Tao, Terence. *The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdős discrepancy problem*. What's new, 2015-09-18.
11. Tao, Terence. 2016 discussion of Euler/vorticity-type blowup models on What's new.

Evidence conventions:
- OBS = directly observable in primary public material.
- INF = inference supported by repeated public behavior.
- HYP = hypothesis requiring more specimens.
- UNK = insufficient public evidence.
