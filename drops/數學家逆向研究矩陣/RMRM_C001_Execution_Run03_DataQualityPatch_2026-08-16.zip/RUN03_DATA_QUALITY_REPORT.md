# RMRM-C001 Execution Run 03 — Data Quality Patch

**Date:** 2026-08-16  
**Protocol:** RMRM-C001 v0.1

## E04 identity collision discovered

The public OpenAlex-derived proxy search for **Nan Jiang** resolved to an author cluster dominated by soil science and ecology, while the intended candidate is the University of Florida numerical analyst working in computational fluid dynamics.

Therefore:

$$
\boxed{
\text{Nan Jiang}_{\mathrm{UF}}
\neq
\text{retrieved OpenAlex-derived author cluster}
}
$$

The candidate is not allowed to contribute author-level metrics under the current identity resolution.

Status:

`E04_RISK — remove from metric pool`

This is exactly the author-contamination failure mode preregistered in RMRM-C001.

## Replacement

The Applied/Numerical/Optimization reference pool replaces this slot with **Heyrim Cho**:

- PhD in Applied Mathematics, Brown University, 2015;
- research in numerical PDE, scientific computing, stochastic/high-dimensional computational methods, and biomedical mathematical modeling.

This replacement is based only on eligibility and field fit. It is **not** a median ranking.

## Metric-layer conclusion

Three access paths were tested:

1. OpenAlex-backed work-level scholarly connector — available;
2. direct OpenAlex author API — blocked by the execution environment;
3. search-indexed OpenAlex-derived author proxy pages — incomplete and susceptible to identity collisions.

Therefore the preregistered eight-dimensional author vector cannot be honestly completed for all 35 candidates in this execution environment without introducing heterogeneous, non-comparable metrics.

Accordingly:

$$
\boxed{
D_{\mathrm{median}}
\text{ remains NOT COMPUTED}.
}
$$

No fake median ranking is substituted.

## Valid outputs from Runs 01–03

What *has* been executed reproducibly:

- live seven-stratum scholarly discovery;
- content/field sanity audit;
- career-window screening;
- E01–E04 exclusion behavior;
- balanced 35-person reference pool construction;
- identity-collision detection and replacement provenance.

What has *not* been executed:

- homogeneous author-level eight-dimensional metric matrix;
- field/career MAD normalization;
- anonymous median ranking;
- genuine 35 finalists;
- final 21-person cohort.

This boundary is a result of the execution audit, not a relaxation of the protocol.
