# SOURCES

## Primary / high-value sources
1. Ramanujan, S. *Modular equations and approximations to pi*.
2. Ramanujan, S. *On certain infinite series*.
3. Ramanujan, S. *Highly Composite Numbers*.
4. Ramanujan, S. *Some properties of p(n), the number of partitions of n into positive integers*.
5. Ramanujan, S. *Proof of certain identities in combinatory analysis*.
6. Hardy, G. H.; Ramanujan, S. Partition asymptotics / circle-method papers.
7. Trinity College Cambridge, Ramanujan Papers and correspondence archive.
8. Berndt, B. C. *Ramanujan's Notebooks*, Vols. I-V.
9. Andrews, G. E.; Berndt, B. C. *Ramanujan's Lost Notebook*, Vols. I-V.
10. Modern mock-theta / harmonic Maass-form literature used only for downstream theory-debt evidence.

## Evidence rules
- OBS = directly visible in public source.
- INF = inference supported by multiple independent sources.
- HYP = hypothesis.
- UNK = insufficient evidence.
