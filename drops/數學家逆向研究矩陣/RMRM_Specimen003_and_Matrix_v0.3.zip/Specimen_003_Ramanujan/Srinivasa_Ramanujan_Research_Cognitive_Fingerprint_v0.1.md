# Srinivasa Ramanujan Research Cognitive Fingerprint v0.1

**RMRM Specimen 003**

**研究框架**：Mathematician Reverse Research Matrix (RMRM)  
**Specimen**：Srinivasa Ramanujan  
**編製**：Neo.K / EveMissLab；Aletheia / GPT-5.6 Sol 協作整理  
**日期**：2026-08-15  
**版本**：v0.1  
**定位**：數學研究方法論逆向工程／高密度結果生成／驗證債務／訓練環境相變分析

---

## 0. 研究聲明

本文不是將 Ramanujan 神秘化為「純直覺天才」，也不把 notebooks 中缺乏 proof trace 直接等同於「不會證明」。

本文只根據公開可觀測材料逆向：

- notebooks 中 statement 的高密度保存方式；
- 正式 solo papers 中的 proof architecture；
- partition congruences、continued fractions、$q$-series、highly composite numbers、mock theta functions 等研究線；
- 1913 Hardy correspondence；
- Cambridge 前後 domain / convergence / proof-condition sensitivity 的變化；
- 後世對 notebooks 與 lost notebook 的 proof-decompression / correction / theory-building 負擔。

因此本文區分：

$$
\text{proof generation}
\neq
\text{proof externalization}
\neq
\text{proof certification}.
$$

對 Ramanujan 的最終輸出不是「直覺分數」，而是：

$$
\boxed{
\mathfrak F_{\mathrm R}^{(0.1)}
=
(
\mathcal C_{\mathrm R},
\mathcal O_{\mathrm R},
\mathcal D_{\mathrm R};
\mathcal E_{\mathrm R},
\boldsymbol\mu_{\mathrm R},
\boldsymbol\lambda_{\mathrm R},
\mathbf V_{\mathrm R},
\boldsymbol\rho_{\mathrm R},
\mathcal K_{\mathrm R}
)
}
$$

其中：

- $\mathbf V_{\mathrm R}$：Verification Debt Vector；
- $\boldsymbol\rho_{\mathrm R}$：generation / verification / compression profile；
- $\mathcal K_{\mathrm R}$：Ramanujan-specific operator clusters。

判斷標記：

- `OBS`：公開材料直接支持；
- `INF`：跨多個獨立 corpus 的穩健推論；
- `HYP`：待更多資料驗證；
- `UNK`：公開資料不足。

---

# 1. Corpus

## A. Early Notebooks

Ramanujan 的三本主要 notebooks 保存近三千項以上的定理、公式、恆等式與特殊值，絕大多數沒有附完整 proof。

本 corpus 用來測：

$$
\text{result-seed density},
\quad
\text{proof externalization},
\quad
\text{formula-space navigation}.
$$

## B. Lost Notebook

包含大量晚期 $q$-series、continued fractions、mock theta 等結果；相較早期 organized notebooks，可觀察到更多 speculative / incomplete / correction-demanding material。

## C. 1913 Hardy Correspondence

用來分析：

- Ramanujan 早期 statement precision；
- prime-number / divergent-series 類錯誤；
- Hardy 對 proof、validity condition 與 modern analytic method 的要求；
- 外部 rigorousness interface 如何進入 Ramanujan research pipeline。

## D. Formal Solo Papers

主要包括：

- *Modular equations and approximations to $\pi$*；
- *On certain infinite series*；
- *Highly Composite Numbers*；
- *Some properties of $p(n)$, the number of partitions of $n$ into positive integers*；
- *Proof of certain identities in combinatory analysis*。

這些用來反證：

$$
\text{notebook proof sparsity}
\Rightarrow
\text{proof inability}.
$$

## E. Hardy–Ramanujan Collaboration

尤其 partition asymptotics / circle-method 形成過程，用來測：

$$
\text{heterogeneous research coupling}.
$$

## F. Longitudinal Afterlife

Berndt notebooks editions、Andrews–Berndt lost-notebook series、mock-theta / Maass-form developments等，用來測：

$$
\text{proof debt},
\quad
\text{interpretation debt},
\quad
\text{theory debt}.
$$

---

# 2. Cognitive Substrate

## C1. 抽象—具體雙向轉換

**L4 / OBS+INF**

Ramanujan 的 implementation mode 不是以幾何 toy model 為主，而是：

$$
\boxed{
\text{symbolic family}
\leftrightarrow
\text{special value}
\leftrightarrow
\text{exact identity}
\leftrightarrow
\text{numerical behavior}.
}
$$

## C2. 前符號結構捕捉

**L3 / INF**

mock theta functions 顯示：

$$
\text{repeated asymptotic phenomenon}
\to
\text{new class label}
$$

可早於完整 modern formal theory。

但無法直接重建其內在 pre-symbolic state，因此不給 L4。

## C3. 想像與反事實生成

**L3 / INF**

主要表現在：

- special-parameter search；
- transformation search；
- class-boundary probing；
- extremal-number construction。

## C4. 邏輯嚴謹與依賴維護

**L3 / OBS**

正式論文可包含完整 proof architecture；但 notebook surface 與 publication surface 高度不同。

此維度的關鍵不是能力低，而是：

$$
\boxed{
\text{proof externalization is surface-dependent}.
}
$$

## C5. 概念／領域轉換

**L4 / OBS**

integrals、series、continued fractions、elliptic/modular objects、partition functions 等間可見強烈 transformation-based translation。

## C6. 深層模式識別

**L4 / OBS+INF**

Ramanujan-mode：

$$
\boxed{
\mu_6(\mathrm R)
=
\text{shared transformation / identity texture}.
}
$$

不同於：

$$
\mu_6(\mathrm T)
=
\text{shared failure structure},
$$

與：

$$
\mu_6(\mathrm G)
=
\text{shared universal relational law}.
$$

## C7. 問題提出與問題重寫

**L4 / OBS**

高度代表性 specimen：

$$
d(n)
\to
\text{record-setters of }d
\to
\text{highly composite numbers}.
$$

即從 irregular function behavior 建立新 object class。

## C8. 數學審美與方向選擇

**L4 / INF**

高權重偏好包括：

- compact identities；
- modular transformation；
- special values；
- continued fractions；
- exact algebraic collapse；
- extremely efficient asymptotics。

## C9. 長期韌性與研究時間尺度

**L4 / OBS**

由印度時期 notebooks 到 Cambridge 正式論文，再到生命最後 mock-theta work，生成型核心持續存在。

## C10. 元認知校準

**L3 / OBS+INF**

重要證據：

- partition general congruence family 被明確標為資料支持但尚無 general proof；
- mock theta letter 明確區分大量 examples 與尚未 rigorously proved 的關鍵 assertion；
- Cambridge 期 formal papers 對 validity / convergence / error conditions 的標記更加清楚。

## C11. 潛在理論地景感知

**L3 / INF**

Ramanujan 常先產生一族高信號 results，後來才被現代理論吸收。

其 mode 不同於 Grothendieck 的「先建 program」：

$$
\boxed{
\mu_{11}(\mathrm R)
=
\text{theory landscape inferred forward from dense phenomena}.
}
$$

---

# 3. General Research Operators — Ramanujan Modes

## O1. Problem Orientation

**L3 / OBS+INF**

常從：

$$
\text{numerical/symbolic irregularity}
$$

轉成：

$$
\text{family / extremal object / transformation problem}.
$$

## O2. Reduction / Normalization / Acceleration

**L4 / OBS**

Ramanujan-mode 常用 special-value substitution、auxiliary functions、functional shifts，使 high-complexity relation collapse。

## O3. Representation Switching

**L4 / OBS**

implementation mode：

`formula-family recoding / auxiliary-function transform / special-value collapse`.

## O4. Proof-Architecture Transplant

**L2 / INF**

不是 dominant mode。

## O5. Invariant Extraction

**L2 / INF**

非最具辨識力。

## O6. Obstruction Localization

**L2 / INF**

不是其 dominant search style。

## O7. Intermediate Theorem / Structure Generation

**L4 / OBS**

但 implementation mode 與 Tao / Grothendieck 不同：

`result-family / identity-family generation`.

## O8. Reverse Condition Backfilling

**L3 / INF**

可見於從特殊 identities 反推 generating-function / modular witness。

## O9. Exceptional-Set Management

**L1 / UNK**

非目前核心。

## O10. Local–Global Bridge

**L2 / INF**

非主要辨識維度。

## O11. Average–Individual Bridge

**L2 / INF**

highly composite / partition asymptotics 中存在，但不是第一核心。

## O12. Dual / Transform-Domain Shift

**L4 / OBS**

implementation mode：

`series-product-integral-continued-fraction transformation`.

## O13. Geometrization

**L0 / UNK**

目前不是主要 corpus 的核心。

## O14. Computation / Counterexample Pruning

**L4 / OBS**

implementation mode：

`manual symbolic-numerical experimentation / tabulation / special-value testing`.

## O15. Proof Compression / Expansion

**L4 / OBS+INF**

Ramanujan 最具辨識力之一：

$$
\boxed{
\text{notebook: extreme statement compression}
}
$$

與：

$$
\boxed{
\text{formal paper: proof decompression}.
}
$$

## O16. Research Boundary Detection

**L3 / OBS**

尤其 partition congruence / mock-theta materials。

## O17. Degeneracy Breaking

**L2 / INF**

非主型。

## O18. Near-Counterexample Tomography

**L1 / UNK**

非主型。

## O19. Minimal-Sufficient-Input Retargeting

**L2 / INF**

非主型。

## O20. Primitive-Skeleton Extraction

**L2 / INF**

有 auxiliary-function / recurrence simplification，但不是 Grothendieck-mode primitive ontology extraction。

## O21. Universality Lift

**L3 / OBS+INF**

partition congruence family、continued-fraction family、modular relations顯示：

$$
\text{special cases}
\to
\text{family identity}.
$$

## O22. Reconstruction-from-Relational-Invariants

**L1 / UNK**

非目前核心。

## O23. Pattern-to-Witness Lift

**L4 / OBS**

新增。

定義：

> 從 numerical / residue / symbolic pattern 出發，搜尋一個 generating function、functional identity、modular equation 或其他 structural witness，使 pattern 成為結構性 consequence。

形式：

$$
\boxed{
\mathcal P_{\mathrm{emp}}
\to
W
\to
\mathcal P_{\mathrm{structural}}.
}
$$

partition congruence 是核心 specimen。

## O24. Special-Value Collapse

**L4 / OBS**

新增。

定義：

> 搜尋特殊參數 $p_\ast$，使高複雜度 transformation / modular equation 因 symmetry 或 algebraic constraint 大幅降階。

形式：

$$
F(x,y;p)=0
\quad
\stackrel{p=p_\ast}{\longrightarrow}
\quad
F_\ast(x)=0.
$$

## O25. Extremal-Object Formation

**L4 / OBS**

新增。

定義：

> 從 irregular numerical function 中抽取 record / extremal setters，並把該 record family 物件化為新的研究類別。

形式：

$$
\mathcal R_f
=
\{
n:
f(n)>f(m),\ \forall m<n
\}.
$$

highly composite numbers 是核心 specimen。

---

# 4. Ramanujan Operator Clusters

## $\mathsf R_1$ — Dense Result Harvesting

$$
\boxed{
\text{explore}
\to
\text{detect relation}
\to
\text{record compressed result seed}
\to
\text{continue exploration}.
}
$$

## $\mathsf R_2$ — Functional-Recursion Crystallization

$$
\boxed{
\text{complex series/product}
\to
\text{auxiliary function}
\to
\text{shift relation}
\to
\text{self-recursion}
\to
\text{continued fraction / identity}.
}
$$

## $\mathsf R_3$ — Empirical Extremum Objectification

$$
\boxed{
\text{irregular numerical behavior}
\to
\text{record filter}
\to
\text{new object class}
\to
\text{structural theorem}.
}
$$

## $\mathsf R_4$ — Phenomenon-First Class Formation

$$
\boxed{
\text{repeated unexplained behavior}
\to
\text{new class label}
\to
\text{examples}
\to
\text{later theory}.
}
$$

mock theta functions are the canonical specimen.

## $\mathsf R_5$ — Pattern-to-Witness Lift

$$
\boxed{
\text{empirical pattern}
\to
\text{family conjecture}
\to
\text{structural witness}
\to
\text{proof or partial certification}.
}
$$

## $\mathsf R_6$ — Generator-Preserving Validation Coupling

$$
\boxed{
G_R
+
V_{\mathrm{external}}
+
\mathcal K_{\mathrm{modern}}
+
E_{\mathrm{formal}}
}
$$

without replacing $G_R$ itself.

---

# 5. Verification Debt Vector

RMRM v0.3 引入：

$$
\boxed{
\mathbf V
=
(
V_{\mathrm{proof}},
V_{\mathrm{correct}},
V_{\mathrm{domain}},
V_{\mathrm{interpret}},
V_{\mathrm{theory}}
)
}
$$

## $V_{\mathrm{proof}}$

statement 已記錄，但 proof trace 缺失。

Ramanujan notebooks：

`high`.

## $V_{\mathrm{correct}}$

statement 本身需要修正。

早期 organized notebooks：

`low`.

lost notebook：

`higher / heterogeneous`.

## $V_{\mathrm{domain}}$

公式可能在 convergence、validity range、regularization 等條件上不完整。

lost-notebook divergent identities 是重要 specimen。

## $V_{\mathrm{interpret}}$

已有 proof，但為何成立、與哪些深層結構相連仍不清楚。

Ramanujan corpus 中常為：

`high`.

## $V_{\mathrm{theory}}$

現有理論語言不足以自然容納 statement / class。

mock theta functions 是極端 specimen：

$$
\boxed{
\text{phenomenon appears}
\ll
\text{natural modern theory appears}.
}
$$

---

# 6. Research Compression Ratio

定義概念量：

$$
\boxed{
\kappa
=
\frac{
\text{downstream proof / explanation / theory complexity}
}{
\text{original recorded statement complexity}
}.
}
$$

不是要求精確數值，而是標記：

- low；
- medium；
- high；
- extreme；
- UNK。

Ramanujan notebooks 中一些 statements 具有：

$$
\boxed{
\kappa\gg1.
}
$$

因此 Ramanujan-mode 不只是 high generation rate，而是：

$$
\boxed{
\text{high semantic compression per recorded statement}.
}
$$

---

# 7. Generative Value of Error

新增動態量：

$$
\boxed{
\gamma_{\mathrm{err}}
=
\operatorname{ResearchValue}
(
\text{false or malformed candidate after diagnosis}
).
}
$$

錯誤不再只有：

$$
\text{discard}.
$$

validator 應輸出：

- refuted；
- repairable；
- domain-error；
- structurally suggestive；
- requires-new-theory；
- unknown。

因此：

$$
\boxed{
\text{False}
\not\Rightarrow
\text{ResearchValue}=0.
}
$$

---

# 8. Training-Regime Transition

Ramanujan 是 RMRM 第一個「同一數學家、不同訓練環境」 specimen。

定義：

$$
\boxed{
\Delta_{\mathrm{train}}
=
\mathfrak F_{m,t_2}
-
\mathfrak F_{m,t_1}.
}
$$

但不預設所有維度一起改變。

## India Phase

可觀測：

- 高密度 result generation；
- notebooks 中 proof trace 高度壓縮；
- uneven modern analytic-domain constraints；
- prime-number / divergent-series mistakes。

## Cambridge Phase

可觀測增加：

- formal proof externalization；
- convergence / validity / error-condition awareness；
- access to contemporary analytic methods；
- explicit interaction with Hardy / Littlewood / literature。

但 mock theta letter 顯示：

$$
\boxed{
\text{phenomenon-first generator persisted}.
}
$$

因此最穩健模型是：

$$
\boxed{
\textbf{Research-Pipeline Recalibration}
}
$$

而不是：

$$
\text{Cognitive Replacement}.
$$

標記：

`INF`.

---

# 9. Heterogeneous Research Coupling

Hardy–Ramanujan 不應被粗分成：

$$
\text{intuition}
+
\text{rigor}.
$$

RMRM v0.3 定義：

$$
\boxed{
\mathcal J(A,B)
=
\text{Research Coupling System}.
}
$$

其輸出：

$$
S_{AB}
=
\mathcal J(S_A,S_B)
$$

不必滿足：

$$
S_{AB}=S_A+S_B.
$$

可能產生 emergent methodology。

Hardy–Ramanujan partition work 是候選：

$$
\boxed{
\text{heterogeneous research coupling}
}
$$

而不是單純「一人猜、一人證」。

---

# 10. Research Dynamics

## D1. Partial Progress Preservation

**L4 / OBS**

notebooks 本身就是大規模 compressed partial-result store。

## D2. Branch Management

**L3 / INF**

多條 formula families 並行，但私人 branch history 不完整。

## D3. Dynamic Knowledge-Space Expansion

**L4 / OBS**

Cambridge period 可觀察到 modern analytic toolkit 與 literature interface 明顯擴張。

## D4. Version / Manuscript Evolution

**L4 / OBS**

notebooks、letters、formal papers、lost notebook 形成多 surface 演化，而非單一 version chain。

## D5. Revision-Mode Classification

Ramanujan-mode 包括：

- self-correction；
- domain correction；
- later proof completion；
- later theory reconstruction。

## D6. Longitudinal Method Consistency

**L4 / INF**

高密度 phenomenon generation 從印度期延續至最後 mock-theta work。

## D7. Proof Interface Hardening

**L3 / OBS+INF**

Cambridge formal publications 強於 notebook surface。

## D8. Countermodel Fidelity Ascent

**L0 / UNK**

非主型。

## D9. Dormant Branch Reactivation

**L4 / OBS+INF**

其 results 在數十年至百年後持續被新理論重新解讀。

注意：其中大量工作由後世數學家完成，不能歸因成 Ramanujan 自己的 active reactivation。

## D10. Conceptual Refactoring

**L3 / INF**

存在，但不是最主要外顯 dynamic。

## D11. Generative Scratchpad Preservation

**L4 / OBS**

notebooks 是極端 specimen。

## D12. Verification-Debt Accumulation

**L4 / OBS+INF**

新增。

定義：

> compressed result-seed production 速度高於 proof / interpretation / theory closure 時，研究系統累積可追蹤的 verification debt。

## D13. Training-Regime Recalibration

**L4 / OBS+INF**

新增。

同一研究者在外部知識、審查、合作、訓練與 publication constraints 改變後，研究 pipeline 可變而核心 generator 部分保持。

---

# 11. Meta-Fingerprint

本版最強候選：

$$
\boxed{
\textbf{
High-Compression Mathematical Phenomenon Generation
with Structural Crystallization and Externalized Validation
}
}
$$

中文：

**高壓縮數學現象生成－結構結晶－外部驗證型研究。**

其核心不是：

$$
\text{guess randomly}.
$$

而是：

$$
\boxed{
\begin{aligned}
&\text{dense symbolic/numerical exploration}\\
&\to
\text{transformation texture detection}\\
&\to
\text{high-information result seed}\\
&\to
\text{family / structural witness}\\
&\to
\text{verification / correction / interpretation}\\
&\to
\text{new theory if required}.
\end{aligned}
}
$$

標記：

`INF — strongly supported by independent corpora`.

---

# 12. Tao–Grothendieck–Ramanujan Contrast

| 維度 | Tao | Grothendieck | Ramanujan |
|---|---|---|---|
| 起點 | hard problem | structural mismatch | dense formula / numerical phenomenon |
| 核心 | obstruction compression | relational reconstruction | phenomenon mining / crystallization |
| C6 mode | shared failure structure | shared universal relational law | shared transformation texture |
| O3 mode | attack-oriented cascade | ambient-language recoding | formula-family / auxiliary-function recoding |
| 計算 | 剪枝／驗證 | 低 | 高 |
| 典型輸出 | proof closure | universal framework | identity / family / class / result seed |
| compression | proof-sufficient | reconstruction-preserving | statement-semantic compression |
| proof storage | high | high | surface-dependent; notebooks extremely compressed |
| 驗證債務 | low-moderate | low-moderate | high proof / interpretation debt |
| theory relation | use/recombine | build before families | results may precede natural theory |
| training shift | not studied | not studied | pipeline recalibration observable |

---

# 13. AI Distillation

## R-A — Phenomenon Generator

最大化：

$$
\text{novelty}
+
\text{structural signal}
+
\text{unexpected relation}.
$$

## R-B — Special-Value Explorer

搜尋：

$$
p_\ast
$$

使 transformation family collapse。

## R-C — Pattern-to-Witness Search

由：

$$
\mathcal P_{\mathrm{emp}}
$$

搜尋 generating-function / modular / functional witness。

## R-D — Extremal Object Miner

由 function data 建立 record-setter / extremal class。

## R-E — Verification Debt Manager

對每個 candidate 維護：

$$
\mathbf V.
$$

## R-F — Proof / Theory Decompressor

將高 $\kappa$ statement 分派到：

- proof agent；
- domain agent；
- interpretation agent；
- theory-building agent。

## R-G — Error Neighborhood Miner

對 false candidate 不直接丟棄，而搜尋：

$$
\text{repair}
+
\text{surviving structure}
+
\gamma_{\mathrm{err}}.
$$

---

# 14. Anti-Overclaim

本版不主張：

1. notebooks 中沒寫 proof 等於 Ramanujan 沒有 proof；
2. Hardy 單向「教會 Ramanujan 證明」；
3. Hardy–Ramanujan 的每個步驟都能可靠分工歸因；
4. Ramanujan 的 early notebooks 有精確可知的真實 error rate；
5. 後世 proof complexity 等於 Ramanujan 當年的內在 proof complexity；
6. mock theta theory 的現代框架就是 Ramanujan 當年心中的框架；
7. Ramanujan-mode 應直接進 formal theorem channel 而不經 validator。

---

# 15. Final Fingerprint

$$
\boxed{
\mathfrak F_{\mathrm R}^{(0.1)}
=
\text{Dense Result Harvesting}
+
\text{Functional-Recursion Crystallization}
+
\text{Special-Value Collapse}
+
\text{Extremal-Object Formation}
+
\text{Phenomenon-First Class Formation}
+
\text{Pattern-to-Witness Lift}
+
\text{Generator-Preserving Validation Coupling}
+
\text{Verification-Debt Management}.
}
$$

本版狀態：

$$
\boxed{
\text{RMRM-003 / v0.1 / provisional frozen}
}
$$

下一階段應以新的數學家 specimen 壓力測試，而非無限細拆 Ramanujan。

