# CHANGELOG — RMRM v0.3

Date: 2026-08-15

## Added from Ramanujan specimen
- O23 Pattern-to-Witness Lift.
- O24 Special-Value Collapse.
- O25 Extremal-Object Formation.
- D12 Verification-Debt Accumulation.
- D13 Training-Regime Recalibration.
- D14 Heterogeneous Coupling Adaptation.
- Verification Debt Vector V = (V_proof, V_correct, V_domain, V_interpret, V_theory).
- Research Compression Ratio kappa.
- Generative Value of Error gamma_err.
- Output-rate profile rho_gen / rho_verify / rho_closure.
- Training-Regime Transition Delta_train.
- Heterogeneous Research Coupling J(A,B).
- Mandatory exploratory/certification channel separation for AI integration.

## Key design change
RMRM now models not only which research operators exist, but also how result seeds accumulate downstream proof, correction, interpretation and theory obligations.

## Specimens incorporated
- RMRM-001 Terence Tao.
- RMRM-002 Alexander Grothendieck.
- RMRM-003 Srinivasa Ramanujan.
