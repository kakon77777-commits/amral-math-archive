# RMRM-C001 v0.1 — Package Notes

This package is intentionally pre-selection.

Included:
- `RMRM_C001_Median_Line_Control_Cohort_v0.1.md` — methodology paper.
- `protocol.json` — executable protocol constants.
- `selection_schema.json` — anonymous selection and exclusion record schema.
- `coding_schema.json` — blind RMRM methodology coding schema.
- `validation.json` — UTF-8 / LaTeX source validation.
- `CHECKSUMS.sha256` — package integrity hashes.

Not included yet:
- candidate identities;
- live bibliometric data;
- web-source snapshot;
- selected 21-person cohort;
- fixed 126-paper corpus;
- baseline fingerprint.

Those belong to the next execution phase after the protocol is frozen.
