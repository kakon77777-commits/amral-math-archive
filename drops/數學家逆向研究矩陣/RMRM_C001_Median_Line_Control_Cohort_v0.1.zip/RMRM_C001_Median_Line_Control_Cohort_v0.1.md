# RMRM-C001：數學研究平均線控制群
## Median-Line Mathematician Control Cohort
### A Baseline Control Protocol for Reverse Engineering Mathematical Research Methodologies

**Framework**：Mathematician Reverse Research Matrix (RMRM)  
**Control ID**：RMRM-C001  
**Version**：v0.1  
**Date**：2026-08-16  
**Status**：Protocol Draft / Pre-Selection Baseline  
**Selection state**：No mathematician identities selected

---

# 摘要

既有 RMRM specimen 主要由歷史級、方法論特徵高度突出的數學家構成。這種 sampling 對發現高張力研究 primitive 有利，卻存在一個根本辨識問題：

> 一個在傑出數學家身上反覆出現的方法，到底是其 exceptional methodological signature，還是所有成熟數學研究者本來就會使用的 professional baseline？

為回答此問題，本文提出 **RMRM-C001 — Median-Line Mathematician Control Cohort**，建立一個由多個數學子領域、職涯階段受控、且在產量、引用、合作、主題廣度與研究持續性等外部研究行為維度上接近同儕中位數的專業數學研究者控制群。

本 protocol 刻意將兩個概念分離：

$$
\boxed{
\text{Selection Median}
\neq
\text{Methodological Median}.
}
$$

bibliometric / career variables 只用於建立「外部研究行為的平均線控制群」，不預先假定這些人具有平均方法論。真正的 methodological baseline 必須在完成身份盲化、固定論文抽樣與 RMRM coding 後，由控制群資料反向估計。

最終目標是建立：

$$
\boxed{
\mathfrak F_{\mathrm{baseline}}
}
$$

並將既有 mathematician fingerprint 重新表示為：

$$
\boxed{
\mathfrak F_m^{\mathrm{rel}}
=
\mathfrak F_m^{\mathrm{abs}}
-
\mathfrak F_{\mathrm{baseline}}.
}
$$

使 RMRM 能進一步區分：

$$
\boxed{
\mathcal M_{\mathrm{universal}},
\qquad
\mathcal M_{\mathrm{professional}},
\qquad
\mathcal M_{\mathrm{exceptional}}.
}
$$

---

# 1. 研究問題

RMRM-C001 的主要研究問題為：

$$
\boxed{
Q_1:
\text{哪些 RMRM primitives 是成熟數學研究的普遍／近普遍操作？}
}
$$

$$
\boxed{
Q_2:
\text{哪些 primitives 是一般專業數學研究者的常見 baseline，但非邏輯必需？}
}
$$

$$
\boxed{
Q_3:
\text{哪些 historical specimens 的高權重 operators 在扣除 baseline 後仍形成顯著偏離？}
}
$$

$$
\boxed{
Q_4:
\text{bibliometric/career centrality 與 methodological centrality 是否相關？}
}
$$

最後一題尤其重要，因為本 protocol 不允許假定：

$$
\boxed{
\text{bibliometrically ordinary}
\Rightarrow
\text{methodologically ordinary}.
}
$$

---

# 2. 控制實驗的必要性

若沒有控制群，對歷史級 specimen 的解讀容易產生：

$$
\boxed{
\text{Exceptional-Person Attribution Bias}.
}
$$

例如某位數學家頻繁使用：

- representation switching；
- local-global bridges；
- counterexamples；
- intermediate lemmas；
- collaboration；
- proof revision；

這些操作可能只是專業數學研究的常規組件。

因此 RMRM 必須從：

$$
\boxed{
\text{What does mathematician }m\text{ do?}
}
$$

進一步轉成：

$$
\boxed{
\text{What does }m\text{ do more / less / differently than baseline researchers?}
}
$$

---

# 3. 控制群定義

RMRM-C001 的控制群不是「弱數學家」、「沒有成果的人」或「隨機一般人」。

目標 population 是：

$$
\boxed{
\mathcal U_{\mathrm{math}}
=
\text{active professional mathematical researchers}.
}
$$

控制群應接近：

$$
\boxed{
\text{multivariate professional median}.
}
$$

即候選人在多個外部研究行為維度都位於其領域與職涯條件下的中央區域，而非只在某一個指標上恰好接近平均。

---

# 4. Selection Median 與 Methodological Median

本文正式區分：

## 4.1 Selection Median

根據外部、可機械取得的研究行為量建立。

用途：

$$
\boxed{
\text{select a cohort without using methodological impressions}.
}
$$

## 4.2 Methodological Median

由固定 corpus 經 RMRM coding 後得到。

用途：

$$
\boxed{
\text{estimate actual baseline research methodology}.
}
$$

因此：

$$
\boxed{
\text{Selection process}
\perp
\text{Methodology coding process}
}
$$

應盡量成立。

---

# 5. Cohort Size

v0.1 主 cohort 建議：

$$
\boxed{
N=21.
}
$$

分為七個 macro-strata，每個三人：

1. Algebra / Number Theory；
2. Geometry / Topology；
3. Analysis / PDE；
4. Probability / Statistics；
5. Combinatorics / Discrete Mathematics；
6. Applied / Numerical / Optimization；
7. Logic / Foundations。

此七分法只是 control-design stratification，不宣稱為數學的完整本體分類。

---

# 6. Career Control

主 cohort 優先限定：

$$
\boxed{
10
\le
Y_{\mathrm{career}}
\le
25
}
$$

其中 $Y_{\mathrm{career}}$ 定義為第一篇可確認研究型數學論文至 selection date 的年數。

目的：

$$
\boxed{
\text{reduce career-length confounding}.
}
$$

同時要求近期仍存在可確認 research activity，避免：

- 長期退出研究；
- 只因短暫生涯造成低產；
- 已退休數十年而產出自然下降；

被誤認為「平均線」。

---

# 7. Eligibility Rules

候選人原則上需滿足：

1. 主要 scholarly identity 可確認；
2. 主要研究活動屬 mathematics 或高度數學化 research；
3. 有足夠完整 publication history；
4. career length 落入 protocol window；
5. 近年仍 active；
6. 不存在明顯 author-profile merge / split contamination；
7. 不以單一極端指標進入 cohort。

---

# 8. Exclusion Rules

unblinding 後才執行 exclusion audit。

預先允許的 exclusion reasons：

- `E01`：major international prize / globally exceptional award outlier；
- `E02`：citation / productivity extreme outlier；
- `E03`：career trajectory 明顯不符合 cohort window；
- `E04`：author identity contamination；
- `E05`：主要研究並非數學；
- `E06`：publication record 不足以建立固定 corpus；
- `E07`：其他事先未預見但可客觀審核的資料品質問題。

禁止理由：

- 「這個人感覺太有趣」；
- 「這個人的研究好像有特色」；
- 「我聽過他的名字」；
- 「他某篇論文看起來很厲害」。

即：

$$
\boxed{
\text{methodological impression}
\notin
\text{selection criteria}.
}
$$

---

# 9. External Selection Vector

對 candidate $a_i$ 建立：

$$
\boxed{
\mathbf X_i
=
(
P_i,
C_i,
H_i,
A_i,
S_i,
B_i,
T_i,
R_i
).
}
$$

其中：

### $P_i$ — Publication Rate

career-normalized annual research output。

### $C_i$ — Citation Centrality

field / year normalized citation profile。

### $H_i$ — Career-Normalized h-position

不可使用 raw h-index 跨 field 比較。

### $A_i$ — Collaboration Size

median / robust coauthor-count statistic。

### $S_i$ — Solo-Author Share

反映 field-specific collaboration culture。

### $B_i$ — Topic Breadth

跨 topic / subfield 的 research breadth。

### $T_i$ — Topical Concentration

避免 breadth 與 concentration 被視為同一軸。

### $R_i$ — Research Continuity

career 中 active publication years 的穩定程度。

---

# 10. Robust Centrality

在相同 field/career reference class 中，對 dimension $j$ 求：

$$
\tilde x_j
=
\operatorname{Median}(x_j).
$$

並以 MAD 做 robust scaling：

$$
\boxed{
z_{ij}
=
\frac{
x_{ij}-\tilde x_j
}{
1.4826\,\operatorname{MAD}_j+\varepsilon
}.
}
$$

定義 median distance：

$$
\boxed{
D_{\mathrm{median}}(a_i)
=
\sqrt{
\sum_j
w_j z_{ij}^{2}
}.
}
$$

v0.1 初始設定可取：

$$
w_j
=
\frac{1}{8},
$$

後續可進 sensitivity analysis。

---

# 11. Central-Band Constraint

只靠 $D_{\mathrm{median}}$ 會容許：

$$
\text{high extreme}
+
\text{low extreme}
\to
\text{artificial centrality}.
$$

因此對核心 dimensions 加：

$$
\boxed{
Q_{20}
\le
x_{ij}
\le
Q_{80}.
}
$$

通過 central-band 後才比較：

$$
D_{\mathrm{median}}.
$$

這使 cohort 接近：

$$
\boxed{
\text{multivariate centrality}
}
$$

而不是平均值抵銷。

---

# 12. Blind Selection Protocol

## Stage A — Anonymous Candidate Generation

candidate identity 替換成：

```text
C-A-000001
C-A-000002
C-B-000001
...
```

selection engine 僅看：

$$
\mathbf X_i
$$

與 eligibility data。

## Stage B — Anonymous Ranking

每個 macro-stratum 先選最接近 median 的前五名。

得到：

$$
\boxed{
7\times5=35
}
$$

匿名 finalists。

## Stage C — Identity Unblinding

只為執行事先定義的 exclusion audit。

## Stage D — Final Cohort

每 stratum 選三人：

$$
\boxed{
N=21.
}
$$

所有 replacement 必須保留：

- excluded ID；
- exclusion code；
- replacement rank；
- audit note。

---

# 13. Corpus Construction

選人後不挑「代表作」。

每位 researcher 固定取：

$$
\boxed{
6\text{ papers}.
}
$$

按 career chronology：

$$
\boxed{
2_{\mathrm{early}}
+
2_{\mathrm{middle}}
+
2_{\mathrm{recent}}.
}
$$

因此主 corpus：

$$
\boxed{
21\times6
=
126\text{ papers}.
}
$$

paper selection 優先使用時間位置，而不是：

- citation；
- venue；
- famous theorem；
- recommendation。

若固定位置論文不可取得，使用事先定義的最近可取得替代規則。

---

# 14. Methodology Coding Blind

methodology coders 不取得：

- $D_{\mathrm{median}}$；
- citation centrality；
- h-index；
- candidate 排名；
- 控制群內相對位置。

只讀：

- fixed paper corpus；
-必要 contextual metadata；
-可追溯 proof/version evidence。

coding 維度：

$$
\boxed{
C_1\text{--}C_{11},
\quad
O_1\text{--}O_{38},
\quad
D_1\text{--}D_{28}.
}
$$

證據標記：

$$
\boxed{
\mathrm{OBS},
\mathrm{INF},
\mathrm{HYP},
\mathrm{UNK}.
}
$$

---

# 15. Individual Control Fingerprint

對 cohort member $a_i$ 得：

$$
\boxed{
\mathfrak F_{a_i}^{\mathrm{abs}}.
}
$$

但不先寫人物傳記式敘事。

優先記錄：

- operator strengths；
- implementation modes；
- longitudinal changes；
- debts / assets；
- proof/search topology；
- evidence quality。

---

# 16. Baseline Fingerprint

對 primitive $j$ 定義：

$$
\boxed{
B_j
=
\operatorname{Median}_{a\in C001}
F_{aj}.
}
$$

另存 prevalence：

$$
\boxed{
p_j^{(3+)}
=
\frac{
|\{a:F_{aj}\ge3\}|
}{
N
}.
}
$$

以及 dispersion：

$$
\boxed{
V_j
=
\operatorname{MAD}
(
F_{1j},
\dots,
F_{Nj}
).
}
$$

最後：

$$
\boxed{
\mathfrak F_{\mathrm{baseline}}
=
\{B_j,p_j,V_j\}_{j}.
}
$$

---

# 17. Relative Fingerprint

歷史 specimen $m$ 原本有：

$$
\mathfrak F_m^{\mathrm{abs}}.
$$

現在新增：

$$
\boxed{
\mathfrak F_m^{\mathrm{rel}}
=
\mathfrak F_m^{\mathrm{abs}}
-
\mathfrak F_{\mathrm{baseline}}.
}
$$

primitive-level：

$$
\boxed{
\Delta F_{mj}
=
F_{mj}-B_j.
}
$$

因此：

$$
\boxed{
\text{absolute strength}
\neq
\text{exceptional distinctiveness}.
}
$$

---

# 18. Three-Layer Method Model

控制群完成後，RMRM 將嘗試區分：

$$
\boxed{
\mathcal M
=
\mathcal M_{\mathrm{universal}}
+
\mathcal M_{\mathrm{professional}}
+
\mathcal M_{\mathrm{exceptional}}.
}
$$

## Universal / Near-Universal Layer

若某 primitive 在控制群高度普遍：

$$
p_j^{(3+)}
\ge0.80,
$$

則暫列 near-universal candidate。

## Professional Baseline Layer

若：

$$
0.40
\lesssim
p_j^{(3+)}
<
0.80,
$$

則可能是成熟專業數學研究常見操作。

## Exceptional Signature Candidate

若：

$$
p_j^{(3+)}
<0.25,
$$

但某 historical specimen：

$$
F_{mj}\approx4,
$$

且跨 independent corpora 穩定，

才開始有資格列為：

$$
\boxed{
\text{Exceptional Methodological Signature}.
}
$$

所有 cutoff 皆為 protocol parameters，不視為自然常數。

---

# 19. Selection Centrality vs Methodological Centrality

控制群完成後可測：

$$
\boxed{
\rho
(
D_{\mathrm{selection}},
D_{\mathrm{method}}
).
}
$$

若低相關：

$$
\boxed{
\text{bibliometric centrality}
\not\Rightarrow
\text{methodological centrality}.
}
$$

此結果本身即具有方法論價值。

---

# 20. Negative Controls

RMRM-C001 應主動保留：

### NC1 — Famous-but-median-metric candidate

如果外部 metric 接近 median，但身份屬明顯 historical outlier，依 exclusion protocol 排除並記錄。

### NC2 — Bibliometric median, methodological outlier

不能因 methodology coding 發現其特殊而事後排除。

這是重要控制：

$$
\boxed{
\text{selection remains valid even if methodology is unusual}.
}
$$

### NC3 — Field-specific culture

合作／solo-author／citation 等必須 field-normalized。

---

# 21. Bias and Failure Modes

主要風險：

1. bibliometric database author disambiguation；
2. field normalization 不充分；
3. career-age confounding；
4. publication-language bias；
5. inaccessible papers；
6. AI methodology coding bias；
7. historical specimen 與現代 cohort 時代差；
8. survivor bias；
9. subfield publication-culture差異；
10. cohort size 過小；
11. central-band arbitrariness；
12. fixed six-paper corpus 可能漏掉 phase transition。

---

# 22. Sensitivity Analysis

正式 baseline 前至少重跑：

### S1 — Cohort Size

$$
N=14,\ 21,\ 28.
$$

### S2 — Central Band

$$
Q_{15}\text{--}Q_{85},
\quad
Q_{20}\text{--}Q_{80},
\quad
Q_{25}\text{--}Q_{75}.
$$

### S3 — Metric Weights

equal weights vs robust inverse-correlation weights。

### S4 — Paper Count

$$
4,\ 6,\ 9
$$

papers per person。

### S5 — Macro-Strata

合併／拆分部分領域，檢查 baseline stability。

若 baseline primitives 對 protocol 小改動極不穩定，則不能宣稱 professional baseline。

---

# 23. Reproducibility Requirements

正式執行時保存：

- candidate universe timestamp；
- data-source identifiers；
- normalization version；
- exclusion log；
- anonymous rank table；
- fixed paper selection log；
- coding rubric；
- coder decisions；
- disagreement audit；
- baseline computation；
- sensitivity results；
- final checksums。

---

# 24. Pre-Registration Principle

本文件作為：

$$
\boxed{
\textbf{pre-selection methodological protocol}.
}
$$

下一階段網路搜尋原則上只能：

1. 建立 candidate universe；
2. 填入 protocol 所需 variables；
3. 執行 blind ranking；
4. 依 exclusion rules 審核；
5. 固定 cohort；
6. 抽取論文。

不得因看到候選人後任意修改：

- cohort size；
- centrality metric；
- exclusion logic；
- paper sampling；
- RMRM coding criteria。

若必須修改，必須升 protocol version 並記錄原因。

---

# 25. Falsification Criteria

RMRM-C001 應被判定失敗或需重設，如果：

1. cohort 無法穩定代表多 field 的中央區域；
2. author disambiguation 大量失敗；
3. baseline 對合理 sensitivity settings 高度不穩；
4. method coding inter-rater agreement 極低；
5. six-paper corpus 無法捕捉穩定 methodology；
6. selection median 與 cohort identity 被系統性 visibility bias 污染；
7. control-group primitives 無法和 historical specimens 做同尺度比較；
8. relative fingerprints 對 protocol 小變化高度敏感。

---

# 26. Primary Outputs

RMRM-C001 預期輸出：

## O1 — Control Cohort Registry

$$
C001=\{a_1,\ldots,a_{21}\}.
$$

## O2 — Fixed 126-Paper Corpus

$$
\mathcal P_{C001}.
$$

## O3 — Baseline Fingerprint

$$
\mathfrak F_{\mathrm{baseline}}.
$$

## O4 — Primitive Prevalence Table

$$
\{B_j,p_j,V_j\}.
$$

## O5 — Relative Historical Fingerprints

$$
\Delta\mathfrak F_m.
$$

## O6 — Universal / Professional / Exceptional Primitive Taxonomy

$$
\mathcal M_{\mathrm{universal}},
\quad
\mathcal M_{\mathrm{professional}},
\quad
\mathcal M_{\mathrm{exceptional}}.
$$

---

# 27. Research Significance

若本 control protocol 成功，RMRM 將第一次能區分：

$$
\boxed{
\text{能力存在}
}
$$

與：

$$
\boxed{
\text{能力具有辨識度}.
}
$$

一個 mathematician 使用某 operator，不代表該 operator 是其 fingerprint。

只有當：

$$
\boxed{
F_{mj}
-
B_j
}
$$

足夠大、跨 corpus 穩定且具可觀察 implementation difference，

才更有資格稱為：

$$
\boxed{
\textbf{methodological signature}.
}
$$

---

# 28. Conclusion

RMRM-C001 的核心不是找「最普通的人」。

而是建立：

$$
\boxed{
\textbf{
a deliberately boring control experiment
for an otherwise exceptional-person research program.
}
}
$$

其完整流程：

$$
\boxed{
\begin{aligned}
\text{Professional Math Universe}
&\to
\text{Field/Career Stratification}\\
&\to
\text{Eligibility Filter}\\
&\to
\text{Robust Multivariate Median}\\
&\to
\text{Anonymous Ranking}\\
&\to
\text{Identity Exclusion Audit}\\
&\to
21\text{-Person Cohort}\\
&\to
126\text{-Paper Fixed Corpus}\\
&\to
\text{Blind RMRM Coding}\\
&\to
\mathfrak F_{\mathrm{baseline}}\\
&\to
\mathfrak F_m^{\mathrm{rel}}\\
&\to
\text{Universal / Professional / Exceptional Separation}.
\end{aligned}
}
$$

真正要被驗證的不是：

> 「平均數學家是不是很普通？」

而是：

$$
\boxed{
\textbf{
After subtracting professional mathematical research,
what is actually left of a legendary mathematician's method?
}
}
$$

這就是 RMRM-C001 的基本命題。
