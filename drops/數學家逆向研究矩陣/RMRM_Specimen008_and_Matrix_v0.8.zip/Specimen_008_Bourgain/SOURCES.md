# SOURCES

Primary / authoritative anchors:
1. Jean Bourgain, A Harmonic Analysis Approach to Problems in Nonlinear Partial Differential Equations.
2. Bourgain, Fourier transform restriction phenomena for certain lattice subsets and applications to nonlinear evolution equations, Parts I–II.
3. Bourgain, Periodic nonlinear Schrödinger equation and invariant measures.
4. Bourgain, Invariant measures for the 2D-defocusing nonlinear Schrödinger equation.
5. Bourgain–Katz–Tao, A sum-product estimate in finite fields, and applications.
6. Bourgain–Glibichuk–Konyagin, Estimates for sums/products and exponential sums in finite fields.
7. Bourgain–Demeter, The proof of the l^2 decoupling conjecture.
8. Bourgain–Demeter–Guth, Proof of the main conjecture in Vinogradov's mean value theorem for degrees higher than three.
9. Bourgain, Decoupling, exponential sums and the Riemann zeta function.
10. Jean Bourgain, Shaw Prize autobiography.
11. Terence Tao, Exploring the toolkit of Jean Bourgain.
12. Terence Tao, Jean Bourgain memorial reflections.
13. IAS / IMU / Shaw Prize official summaries.

Evidence: OBS / INF / HYP / UNK.
Joint-work attribution is preserved.
