# CHANGELOG — RMRM v0.8

Date: 2026-08-15

Added from RMRM-008 Jean Bourgain:
- O37 Quantitative Interface Engineering.
- D26 Interface Migration and Generalization.
- Decisive Estimate Profile.
- Quantitative Interface State.
- Adaptive Toolkit Sequencing.
- Quantitative Control Transport.
- Localize–Control–Recouple.
- Layered Globalizer Selection.
- Adaptive Quantitative Hub subtype.
- Research Router v0.5 with ControlAudit, DecisiveEstimateDesign, ToolkitSequence, GlobalizerSelect, PortabilityAudit.

Specimens: Tao, Grothendieck, Ramanujan, Erdős, Thurston, Mirzakhani, Gowers, Bourgain.
