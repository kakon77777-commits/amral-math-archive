# CHANGELOG — RMRM v0.9

Date: 2026-08-16

Added from RMRM-009 Grigori Perelman:
- O38 Critical-Regime Localization.
- D27 Rigidity-Boundary Calibration.
- Closure-Bearing Structure Profile.
- Critical Dependency Graph.
- Rigidity Boundary Profile.
- Protected-Regime proof obligation.
- Research-Space Compression and attention-budget sparsification.
- Legal Local Modification schema retained as a person-cluster candidate, not promoted to O39.
- Research Router upgraded to v0.6.
- Operator-consolidation gate made explicit.

Important falsification result:
`Widths of Nonnegatively Curved Spaces` does not naturally reduce to O38. Therefore Perelman's meta-fingerprint is not "critical sets everywhere"; the more general cross-corpus pattern is Closure-Bearing Structure Compression.

Current specimens:
RMRM-001 Terence Tao
RMRM-002 Alexander Grothendieck
RMRM-003 Srinivasa Ramanujan
RMRM-004 Paul Erdős
RMRM-005 William Thurston
RMRM-006 Maryam Mirzakhani
RMRM-007 Timothy Gowers
RMRM-008 Jean Bourgain
RMRM-009 Grigori Perelman
