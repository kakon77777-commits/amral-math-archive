# SOURCES

Primary / authoritative anchors:
1. Grigori Perelman, The entropy formula for the Ricci flow and its geometric applications.
2. Grigori Perelman, Ricci flow with surgery on three-manifolds.
3. Grigori Perelman, Finite extinction time for the solutions to the Ricci flow on certain three-manifolds.
4. Grigori Perelman, Alexandrov's spaces with curvatures bounded from below II.
5. Grigori Perelman, Proof of the soul conjecture of Cheeger and Gromoll.
6. Grigori Perelman, Manifolds of positive Ricci curvature with almost maximal volume.
7. Grigori Perelman, Widths of nonnegatively curved spaces.
8. Grigori Perelman, Collapsing with no proper extremal subsets.
9. Grigori Perelman, Complete Riemannian manifold of positive Ricci curvature with Euclidean volume growth and nonunique asymptotic cone.
10. Grigori Perelman, Construction of manifolds of positive Ricci curvature with big volume and large Betti numbers.
11. Perelman–Petrunin, Extremal subsets in Aleksandrov spaces and the generalized Liberman theorem.
12. Standard historical accounts of Hamilton's Ricci-flow program, Cheeger–Gromoll soul theory, and Alexandrov geometry used only for attribution/context.

Evidence labels: OBS / INF / HYP / UNK.

Attribution rule:
- Hamilton's Ricci-flow program is not attributed to Perelman as an original program.
- Perelman–Petrunin results remain joint work.
- Cheeger–Gromoll, Sharafutdinov, Bishop–Gromov, Hamilton and other predecessor machinery remain explicitly external dependencies.
- RMRM reconstructs cross-corpus methodological patterns from public mathematical artifacts; it does not claim access to Perelman's private mental states.

Falsification rule:
`Widths of Nonnegatively Curved Spaces` is preserved as a negative control against overgeneralizing Critical-Regime Localization.
