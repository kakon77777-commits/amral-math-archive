# RMRM-C001 Execution Run 02 — Reference Pool Freeze

**Date:** 2026-08-16  
**Protocol:** RMRM-C001 v0.1  
**Sampling provenance:** `work_seeded_proxy + targeted replacement audit`  
**Pool size:** 35 = 7 strata × 5  
**True median ranking computed:** No  
**Final 21-person cohort selected:** No

## What is frozen in this run

A 35-person **reference pool** now exists with exactly five candidates in each macro-stratum.

The pool is not the preregistered "anonymous top-5 finalists." It is the smallest balanced set from which the author-level metric layer can now be built under the current tool constraints.

Every identity has been unblinded only for eligibility/field/career audit.

## What remains prohibited

No candidate may be called:
- "median";
- "top-5";
- "average";
- "finalist";
- "selected control";

until the multivariate reference distributions and $D_{\mathrm{median}}$ are actually computed.

## Known pending eligibility fields

A small number of candidates still require exact first-paper/career anchors. Those rows are marked `PENDING_CAREER_ANCHOR` or `PASS_TO_METRICS_BORDERLINE`.

This matters because the preregistered career variable is first confirmed research output, not merely PhD year.

## Next stage

For each of the 35 candidates, construct an author-level metric record:

1. publication-rate proxy;
2. field/year-normalized citation centrality proxy;
3. h-position proxy;
4. median coauthor count;
5. solo-author share;
6. topic breadth;
7. topic concentration;
8. research continuity.

Then build field/career reference medians, MAD scales, central-band tests, and finally:

$$
D_{\mathrm{median}}(a_i)
=
\sqrt{
\sum_j w_j z_{ij}^2
}.
$$

Only after that may the protocol emit the real anonymous finalists.

## Data-acquisition caveat

The current execution environment exposes OpenAlex primarily through work-level search rather than a bulk author-level endpoint. This run therefore preserves the deviation label:

`sampling_path = work_seeded_proxy`

This is a provenance limitation, not permission to replace the median calculation with human judgment.
