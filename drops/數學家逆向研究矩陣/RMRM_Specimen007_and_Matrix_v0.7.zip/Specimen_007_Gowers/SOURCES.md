# SOURCES

Primary / authoritative anchors:
1. Timothy Gowers, Pólya Project / How to find proofs.
2. Gowers–Maurey, The Unconditional Basic Sequence Problem.
3. Timothy Gowers, An infinite Ramsey theorem and some Banach-space dichotomies.
4. Timothy Gowers, A new proof of Szemerédi's theorem.
5. Timothy Gowers, Rough structure and classification.
6. Gowers–Wolf, true-complexity / uniformity work.
7. Timothy Gowers, Decompositions, approximate structure, transference, and the Hahn–Banach theorem.
8. Gowers's Weblog, Polymath design / scaling reflections.
9. DHJ Polymath, A new proof of the density Hales–Jewett theorem.
10. Data for Mathematical Copilots: Better Ways of Presenting Proofs for Machine Learning.

Evidence: OBS / INF / HYP / UNK.
Joint-work attribution is preserved; later inverse-theorem and Polymath results are not collapsed into Gowers-only credit.
