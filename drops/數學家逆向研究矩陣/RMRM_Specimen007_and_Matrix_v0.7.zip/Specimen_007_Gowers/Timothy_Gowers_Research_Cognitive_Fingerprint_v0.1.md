# Timothy Gowers Research Cognitive Fingerprint v0.1

**RMRM Specimen 007**

**研究框架**：Mathematician Reverse Research Matrix (RMRM)  
**Specimen**：Sir William Timothy Gowers  
**日期**：2026-08-15  
**版本**：v0.1  
**狀態**：provisional frozen

---

# 0. 核心定位

Gowers specimen 橫跨四類公開 corpus：

1. Banach-space counterexamples / dichotomies；
2. additive combinatorics / Gowers norms / structure–randomness；
3. Pólya-style proof-discovery writings；
4. Polymath / open distributed mathematics / mathematical-AI workflow research。

跨 corpus 最穩定的高階結構不是單純「分解」，而是：

$$
\boxed{
\textbf{
Diagnose
\to
Decompose
\to
Search
\to
Route
\to
Compile
}
}
$$

完整 meta-fingerprint：

$$
\boxed{
\textbf{
Problem-Driven Mathematical Progress through
Diagnostic Regime Decomposition,
Local Search,
Method Routing,
and Research-State Compilation
}
}
$$

中文：

**以診斷式區域分解、局部搜尋、方法路由與研究狀態編譯推進問題導向數學。**

證據標記：

- `OBS`：公開材料直接支持；
- `INF`：跨 corpus 穩健推論；
- `HYP`：待更多 specimen 壓力測試；
- `UNK`：證據不足。

---

# 1. Longitudinal Corpus

## Phase I — Banach Spaces

高階模式：

$$
\boxed{
\text{expected universal structure fails}
\to
\text{counterexample}
\to
\text{opposite structural regime}
\to
\text{dichotomy / rough classification}.
}
$$

重要特徵：

$$
\boxed{
\neg A
\not\Rightarrow
\text{mere exception};
\qquad
\neg A
\Rightarrow
\text{evidence for alternative regime }B.
}
$$

## Phase II — Additive Combinatorics

$$
\boxed{
\text{target pattern}
\to
\text{diagnostic quantity}
\to
\text{random-like / structured regime}
\to
\text{regime-specific method}.
}
$$

## Phase III — Proof Discovery / Pólya Project

Gowers 明確嘗試將：

$$
\boxed{
\text{How could a computer discover a proof?}
}
$$

top-down 拆為愈來愈小的 proof-discovery tasks。

典型：

$$
\boxed{
\text{problem}
\to
\text{nearest solved analogue}
\to
\text{local diagnostic question}
\to
\text{failure condition}
\to
\text{constraint}
\to
\text{next search move}.
}
$$

最後：

$$
\boxed{
\text{messy discovery trace}
\to
\text{clean certified proof}.
}
$$

## Phase IV — Polymath / Open Distributed Reasoning

Polymath1：

$$
\boxed{
\text{large proof search}
\to
\text{small public cognitive steps}
\to
\text{shared branch diagnosis}
\to
\text{compiled state}
\to
\text{proof}.
}
$$

Polymath8：

$$
\boxed{
\text{modular proof architecture}
\to
\text{specialist subgroups}
\to
\text{clear interfaces}
\to
\text{production pipeline}
\to
\text{integrated bound}.
}
$$

## Phase V — Mathematical AI / Copilot Methodology

Gowers 參與的 mathematical-copilot data work主張，單純：

$$
\text{theorem statement}
\to
\text{final proof}
$$

不足以表示真實數學研究；更需要：

$$
\boxed{
\text{mathematical workflows}
=
\text{sequences of atomic research tasks}.
}
$$

---

# 2. Core Cognitive Substrate

## C3 — Counterfactual / Branch Generation

**L4 / OBS+INF**

依賴 special cases、failed constructions、alternative regimes、short speculative branches。

## C4 — Logical Rigor

**L4 / OBS**

discovery trace 與 final proof 被明確分開；messy search 不等於降低 certification standard。

## C5 — Cross-domain Translation

**L4 / OBS**

Banach spaces、Fourier analysis、combinatorics、functional analysis、computer mathematics、collaborative workflows。

## C6 — Deep Pattern Recognition

**L4 / OBS+INF**

$$
\boxed{
\mu_6(\mathrm G)
=
\text{shared diagnostic regime structure}.
}
$$

## C7 — Problem Rewriting

**L4 / OBS**

問題常被改寫為 dichotomy、minimal diagnostic、structure/randomness split、local proof-discovery subproblem、collaborative module。

## C8 — Mathematical Direction Choice

**L4 / INF**

偏好 problem-driven tool creation、rough classification、diagnostic quantities、reusable general principles、local tractability。

## C9 — Long-Horizon Persistence

**L4 / OBS+INF**

1990s Banach → additive combinatorics → Pólya writings → Polymath → AI-math workflows，方法拓撲延續。

## C10 — Metacognitive Calibration

**L4 / OBS**

明確討論 proof discovery、problem granularity、collaboration scaling、context cost、computer mathematics、explanation quality。

---

# 3. O36 — Diagnostic Regime Decomposition

定義：

> 建立 diagnostic $D$，將複雜 research state $S$ 映射到少數具有不同有效後續操作的 regimes。

$$
\boxed{
D:S\to\{R_1,\ldots,R_k\}
}
$$

並存在：

$$
\boxed{
R_i\mapsto M_i,
}
$$

其中 $M_i$ 是該 regime 的優先方法。

operator 的輸出不是 theorem，而是：

$$
\boxed{
\text{which reasoning engine should be used next}.
}
$$

代表 implementation：

- Banach：structural dichotomy；
- Additive combinatorics：uniformity diagnostic；
- Proof discovery：diagnostic question → proof regime；
- Polymath：branch/module diagnosis → distributed routing。

---

# 4. Five Core Gowers Clusters

## $\mathsf G_A$ — Diagnostic Regime Decomposition

$$
\boxed{
S
\to
D(S)
\to
R_i
\to
M_i.
}
$$

## $\mathsf G_B$ — Property-Targeted Diagnostic Engineering

$$
\boxed{
P
\to
D_P
}
$$

設計最適合目標 property 的 diagnostic。

## $\mathsf G_C$ — Constructive Dichotomy and Failure-to-Constraint

$$
\boxed{
\neg A
\Rightarrow
\text{usable evidence for }B.
}
$$

failed construction 編譯成 invariant、constraint、branch-pruning condition 或 alternative regime。

## $\mathsf G_D$ — Microstep Search and Distributed Routing

$$
\boxed{
\text{large reasoning obligation}
\to
s_1,s_2,\ldots,s_n.
}
$$

但：

$$
\boxed{
\text{microstep size}
\neq
\text{context cost}.
}
$$

## $\mathsf G_E$ — Research-State Compilation

$$
\boxed{
\{
\text{ideas},
\text{failures},
\text{partial results},
\text{branches},
\text{diagnostics}
\}
\to
S_t^{\mathrm{compiled}}.
}
$$

Polymath 中：

$$
\boxed{
\text{thread}
\to
\text{wiki / compiled state}
\to
\text{formal paper}.
}
$$


---

# 5. Polymath Collaboration Topologies

## Type A — Coupled Microstep Mesh

適合：

$$
\operatorname{density}(\Gamma(P))\gg0.
$$

特徵：

- high shared context；
- short contributions；
- rapid feedback；
- small synchronized core；
- state compiler 必要。

## Type B — Modular Production Pipeline

適合：

$$
\Gamma(P)
$$

接近 modular DAG。

特徵：

- specialist modules；
- clear input/output interfaces；
- parallel optimization；
- integration stage。

## Type C — Optimization Swarm

若存在 monotone progress metric：

$$
m(S_{t+1})>m(S_t),
$$

則可讓多組研究者持續改良同一 quantitative frontier。

---

# 6. Context-to-Contribution Ratio

定義：

$$
\boxed{
\kappa_{\mathrm{ctx}}
=
\frac{
C_{\mathrm{context\ required}}
}{
C_{\mathrm{local\ contribution}}
}.
}
$$

當：

$$
\kappa_{\mathrm{ctx}}\gg1,
$$

即使 contribution 很小，onboarding 成本仍高。

因此：

$$
\boxed{
\text{task decomposition}
\neq
\text{context decomposition}.
}
$$

---

# 7. Integration Debt

定義：

$$
\boxed{
\mathbf D_{\mathrm{int}}
=
(
D_{\mathrm{context}},
D_{\mathrm{interface}},
D_{\mathrm{consistency}},
D_{\mathrm{assembly}},
D_{\mathrm{exposition}}
).
}
$$

### $D_{\mathrm{context}}$

不同子群組共享背景不同步。

### $D_{\mathrm{interface}}$

module input/output contract 不清。

### $D_{\mathrm{consistency}}$

notation、hypotheses、constants、definitions 不一致。

### $D_{\mathrm{assembly}}$

局部結果尚未接成完整 proof dependency chain。

### $D_{\mathrm{exposition}}$

完整論證存在，但尚未形成 coherent human-readable artifact。

因此：

$$
\boxed{
\forall i,\ \operatorname{Valid}(R_i)=1
\not\Rightarrow
\operatorname{Integrated}(\{R_i\})=1.
}
$$

---

# 8. D25 — Research-State Compilation

定義：

> 將高熵、分散、帶失敗與分支的 research trace 壓成下一輪可以直接操作的低熵 shared state。

$$
\boxed{
\operatorname{Compile}
(
r_1,\ldots,r_N
)
=
S_t^{\mathrm{compiled}}.
}
$$

compiler 必須保留：

- current frontier；
- accepted lemmas；
- active branches；
- rejected branches + reasons；
- unresolved interfaces；
- proof obligations；
- dependencies；
- integration debt。

---

# 9. Negative Research Assets

失敗不是 dead text。

定義：

$$
\boxed{
H^-
=
(
\text{failed approach},
\text{failure condition},
\text{precise obstruction},
\text{salvageable subresults},
\text{neighboring viable branches}
).
}
$$

作用：

$$
\boxed{
\text{failure discovered once}
\to
\text{search-space reduction for all agents}.
}
$$

---

# 10. Dependency-Aware Collaboration Policy

給 proof / problem dependency graph：

$$
\Gamma(P)=(V,E).
$$

協作 policy：

$$
\boxed{
\operatorname{CollabPolicy}
=
F(
\Gamma(P),
\kappa_{\mathrm{ctx}},
m(P),
N_{\mathrm{agents}},
\mathbf D_{\mathrm{int}}
).
}
$$

所以：

$$
\boxed{
\text{More Agents}
\not\Rightarrow
\text{More Progress}.
}
$$

---

# 11. Discovery IR and Proof Compilation

Gowers proof-discovery corpus 清楚區分：

$$
\boxed{
\text{discovery order}
\neq
\text{final proof order}.
}
$$

定義 Discovery IR：

$$
\mathcal D
=
\{
\text{questions},
\text{failed attempts},
\text{special cases},
\text{diagnostics},
\text{constraints},
\text{local lemmas}
\}.
$$

然後：

$$
\boxed{
\operatorname{ProofCompile}(\mathcal D)
=
\Pi.
}
$$

---

# 12. AI Distillation

## G-A — Diagnostic Designer

搜尋 $D_P$，使其能辨別下一個 method regime。

## G-B — Regime Router

$$
D_P(S)\to R_i\to M_i.
$$

## G-C — Failure Compiler

$$
\text{failed attempt}
\to
\text{constraint / invariant / negative asset}.
$$

## G-D — Microstep Generator

把 proof-discovery obligation 拆成 local tractable states。

## G-E — State Compiler

維護最新 coherent shared research state。

## G-F — Integration Auditor

追蹤：

$$
\mathbf D_{\mathrm{int}}.
$$

## G-G — Collaboration Topology Selector

依 $\Gamma(P)$ 選：

- coupled mesh；
- modular pipeline；
- optimization swarm。

---

# 13. Cross-Corpus Inference

本 specimen 最強 longitudinal inference：

$$
\boxed{
\text{Hard Mathematics}
\approx
\text{Proof-Discovery Pedagogy}
\approx
\text{Polymath Design}
\approx
\text{AI-Math Workflow Design}.
}
$$

其中「$\approx$」只表示高階 search topology 相似：

$$
\boxed{
\text{complex search}
\to
\text{diagnosable local states}
\to
\text{state-specific method}
\to
\text{compiled global result}.
}
$$

標記：

`INF — strong`.

---

# 14. Anti-Overclaim

本版不主張：

1. Polymath 是 Gowers 個人數學方法的直接心理外化；
2. 所有 Polymath 成功都由 Gowers 方法主導；
3. Gowers norms / inverse theory 後續全部成果可歸因 Gowers；
4. 更多 microsteps 必然更有效；
5. public reasoning trace 必然降低 research cost；
6. Integration Debt 已可精確數值化；
7. diagnostic decomposition 適合所有數學問題；
8. AI atomic workflows 已足以重現高階數學研究。

---

# 15. Final Fingerprint

$$
\boxed{
\mathfrak F_{\mathrm G}^{(0.1)}
=
\text{Diagnostic Regime Decomposition}
+
\text{Property-Targeted Diagnostic Engineering}
+
\text{Constructive Dichotomy / Failure-to-Constraint}
+
\text{Microstep Search and Distributed Routing}
+
\text{Research-State Compilation}.
}
$$

狀態：

$$
\boxed{
\text{RMRM-007 / v0.1 / provisional frozen}.
}
$$
