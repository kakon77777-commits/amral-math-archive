# CHANGELOG — RMRM v0.7

Date: 2026-08-15

Added from RMRM-007 Timothy Gowers:
- O36 Diagnostic Regime Decomposition.
- D25 Research-State Compilation.
- Integration Debt vector.
- Context-to-Contribution Ratio.
- Discovery Intermediate Representation.
- Negative Research Assets.
- Dependency-aware collaboration topology.
- Coupled Microstep Mesh / Modular Production Pipeline / Optimization Swarm.
- Research Router v0.4 with DiagnosticDesign, RegimeClassify, TopologySelect, StateCompile.
- Integration Budget / forced compilation concept.

Specimens:
RMRM-001 Tao
RMRM-002 Grothendieck
RMRM-003 Ramanujan
RMRM-004 Erdős
RMRM-005 Thurston
RMRM-006 Mirzakhani
RMRM-007 Gowers
