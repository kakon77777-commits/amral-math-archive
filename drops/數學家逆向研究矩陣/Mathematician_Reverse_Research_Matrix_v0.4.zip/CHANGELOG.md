# CHANGELOG — RMRM v0.4

Date: 2026-08-15

Added from RMRM-004 Paul Erdős:
- O26 Extremalization.
- O27 Proof Resource Audit.
- O28 Constructivization.
- O29 Problem Seeding / Open-Problem Externalization.
- D15 Problem Reproduction.
- D16 Research-Priority Signaling.
- D17 Obligation-Ladder Propagation.
- D18 Specialist-Channel Persistence.
- Research-Obligation Vector Omega(P).
- Existence / Constructive / Algorithmic / Natural-Explicit separation.
- Problem Priority Profile W(P).
- Problem Ecology Graph.
- Problem / Obligation / Agent routing.
- Research Router v0.1.
- Proof-Role Multiplicity.
- Randomize-and-Repair as a general search policy.

Specimens incorporated:
RMRM-001 Tao; RMRM-002 Grothendieck; RMRM-003 Ramanujan; RMRM-004 Erdős.
