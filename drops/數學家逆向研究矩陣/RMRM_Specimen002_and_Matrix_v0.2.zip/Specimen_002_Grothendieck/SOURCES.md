# SOURCES

## Primary / authoritative anchors

1. Grothendieck, Alexander. *Éléments de géométrie algébrique I: Le langage des schémas*. Publications Mathématiques de l'IHÉS 4 (1960), 5-228. DOI: 10.1007/BF02684778.
2. Grothendieck, Alexander; Raynaud, Michèle (modern public edition). *Revêtements étales et groupe fondamental (SGA 1)*. arXiv:math/0206203.
3. Grothendieck, Alexander; Verdier, Jean-Louis et al. *Théorie des topos et cohomologie étale des schémas (SGA 4)*. Lecture Notes in Mathematics 269 and related volumes.
4. Grothendieck, Alexander. *Pursuing Stacks*. 1983 manuscript; public modern edition arXiv:2111.01000.
5. Grothendieck, Alexander. *Esquisse d'un Programme*. 1984; later published in *Geometric Galois Actions*.
6. Université de Montpellier. *Archives Grothendieck*, archival inventory.
7. Institut des Hautes Études Scientifiques (IHES). Historical profile and EGA/SGA materials.
8. Grothendieck, Alexander. *Récoltes et Semailles*. Supplementary self-reflective evidence only.

## Evidence policy

- `OBS`: directly supported by public mathematical/archival material.
- `INF`: inference supported by multiple independent public corpora.
- `HYP`: hypothesis awaiting more specimens.
- `UNK`: insufficient public evidence.
