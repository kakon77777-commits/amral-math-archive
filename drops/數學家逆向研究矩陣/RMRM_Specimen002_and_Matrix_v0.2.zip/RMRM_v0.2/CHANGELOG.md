# CHANGELOG — RMRM v0.2

Date: 2026-08-15

## Added
- C11 Latent-Theory Landscape Perception.
- O20 Primitive-Skeleton Extraction.
- O21 Universality Lift.
- O22 Reconstruction-from-Relational-Invariants.
- D10 Conceptual Refactoring.
- D11 Generative Scratchpad Preservation.
- Implementation Mode `mu`.
- Information-Loss / Recoverability Profile `lambda`.
- Mathematician-specific Operator Clusters distinct from global operator codes.
- Revision Type alongside Revision Depth.
- Tao vs Grothendieck contrast as a falsification/diagnostic test.

## Changed
- O7 expanded from intermediate theorem generation to intermediate theorem/structure generation.
- O10 explicitly requires an implementation mode.
- Corpus protocol expanded beyond versioned papers to manuscripts, correspondence, seminars and programs.
- Dynamic knowledge-space expansion now includes ontology/object-class expansion.
- RMRM fingerprint schema changed from `(C,O,D;E)` to `(C,O,D;E,mu,lambda,K)`.

## Design rationale
The Tao and Grothendieck specimens showed that two researchers can score highly on the same general operator while implementing it in structurally different ways. Adding a new global operator for every implementation would make the matrix non-comparable. v0.2 therefore separates operator class from implementation mode.
