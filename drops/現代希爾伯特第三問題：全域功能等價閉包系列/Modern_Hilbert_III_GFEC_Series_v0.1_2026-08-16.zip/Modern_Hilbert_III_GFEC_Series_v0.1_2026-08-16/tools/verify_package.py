from pathlib import Path
import json

ROOT=Path(__file__).parents[1]
manifest=json.loads((ROOT/"meta"/"MANIFEST.json").read_text(encoding="utf-8"))
assert len(manifest["papers"])==10

for name in manifest["papers"]:
    p=ROOT/"papers"/name
    assert p.exists(), name
    t=p.read_text(encoding="utf-8")
    assert len(t)>1800, (name,len(t))
    assert "Claim Boundary" in t, name
    assert "\\(" not in t and "\\)" not in t, name
    assert "\\[" not in t and "\\]" not in t, name
    assert t.count("$$")%2==0, name

for rel in [
    "README.md",
    "meta/GLOSSARY.md",
    "meta/AI_HANDOFF.md",
    "references/REFERENCES.md",
]:
    assert (ROOT/rel).exists(), rel

assert manifest["claim_status"]["GFEC-1_pointwise_finite_closure"]=="CONJECTURE"

print("PASS: 10-paper MH3-GFEC series, claim boundaries, references, handoff, UTF-8 source, and canonical math delimiter hygiene.")
