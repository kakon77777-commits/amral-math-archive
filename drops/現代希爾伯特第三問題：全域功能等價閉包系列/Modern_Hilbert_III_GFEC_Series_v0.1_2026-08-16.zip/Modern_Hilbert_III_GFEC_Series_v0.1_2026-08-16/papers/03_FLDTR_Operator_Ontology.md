# Paper 03 — 有限局部拆解—變換—重組系統

## Finite Local Decompose–Transform–Reassemble Systems

## 摘要

Modern Hilbert III 不能把「不限方法論」誤解成「任何敘述都算證明」。本篇把搜尋自由與 closure 合法性分離：發現手段可以無界，但最終實現與證書必須有限、局部、合法、可驗證。

## 1. FLDTR

定義 route：

$$
R=(D,T,A,V),
$$

其中：

- $D$：decomposition；
- $T$：局部 transformation family；
- $A$：assembly/recomposition；
- $V$：verification map。

要求：

$$
|D|<\infty,\qquad
|T|<\infty,\qquad
|A|<\infty.
$$

## 2. 局部

「局部」不要求只能空間局部，而是每一步作用範圍可有限標定。

可以是幾何局部、材料局部、因果模組局部、軟體 component 局部、生物 pathway 局部或時間窗口局部。

## 3. 合法

每一步必須滿足 domain laws：

$$
T_i\in\mathcal L_S.
$$

例如：

- 不違反守恆律；
- 不使用禁止的無限 oracle；
- 不把「目標已達成」當 primitive operation；
- 不跳過不可逆物理限制；
- 不使用未定義觀察通道。

## 4. 方法論開放

搜尋器 $\mathcal H$ 可以是人類、AI、theorem prover、實驗、symbolic algebra、數值搜尋、evolutionary design 或尚未發明的方法。

但：

$$
\boxed{
\mathcal H
\text{ 只負責 propose，}
V
\text{ 才負責 close。}
}
$$

## 5. 變換語義

$$
O_0=O
\xrightarrow{T_1}
O_1
\xrightarrow{T_2}
\cdots
\xrightarrow{T_m}
O_m.
$$

要求：

$$
O_m\equiv_F S.
$$

若中途產生新 parts，每個 part 與作用都必須可追蹤。

## 6. Conservation ledger

每個 route 附：

$$
L_R=
(
\Delta M,
\Delta E,
\Delta Q,
\Delta I,
\Delta C,\ldots
),
$$

記錄 domain-specific 守恆／成本項。

## 7. 有限性為什麼重要

若允許不可驗證無限過程：

$$
R_\infty,
$$

「存在 route」可能失去 operational content。

所以關係明確限制：

$$
\exists R\in\mathfrak R_{\mathrm{fin,loc}}.
$$

## 8. compositionality

若：

$$
R_A:O_A\rightarrow S_A,
$$

$$
R_B:O_B\rightarrow S_B,
$$

不能自動推出：

$$
R_A\otimes R_B:
O_A\otimes O_B
\rightarrow
S_A\otimes S_B.
$$

需要 interface contract：

$$
K_{AB}.
$$

Assume-guarantee verification 正提供這類局部到全域的成熟工具。

## 9. preorder 與 equivalence

若 transformations 不可逆：

$$
O\rightarrow S
$$

不必推出：

$$
S\rightarrow O.
$$

所以區分：

$$
O\preceq_F S
$$

與：

$$
O\equiv_F S
\iff
O\preceq_F S
\land
S\preceq_F O.
$$

工程 replacement 常只需要前者。

## 10. 真正操作問題

$$
\boxed{
\text{哪一類有限局部合法操作語言，
對指定自然域具有足夠表達力？}
}
$$

## Claim Boundary

本篇給出操作本體，不宣稱所有自然過程都能被有限 FLDTR 表示。若某自然對象的必要演化本質上需要無限歷程，這可能形成 GFEC 的反例來源。
