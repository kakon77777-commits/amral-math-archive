# Paper 07 — 可判定性、複雜度與閉包光譜

## Decidability, Complexity, and Closure Spectra

## 摘要

即使 pointwise closure 成立，也不表示它可有效計算、成本可接受或存在 uniform bound。本篇把 MH3-GFEC 拆成存在性、可判定性、可構造性與複雜度四層。

## 1. 四個不同問題

### 存在性
$$
\exists C^\pm?
$$

### 可判定性
$$
\exists\text{ algorithm deciding }C^\pm?
$$

### 可構造性
$$
O\equiv_F S
\Rightarrow
\text{algorithm outputs FLDTR witness?}
$$

### 成本
$$
K(O,S)
=
\text{time/space/experiment/certificate cost}.
$$

這四者不能混為一談。

## 2. Closure depth

定義：

$$
n(O)
=
\min
\{
n:
O\text{ closes under }\mathfrak C_n
\}.
$$

可能：

$$
n(O)<\infty
$$

對所有 $O$，但：

$$
\sup_O n(O)=\infty.
$$

這就是逐點有限、全域無界。

## 3. Closure complexity

$$
K_{\mathrm{close}}(O)
=
\min
\{
\operatorname{cost}(C):
C\text{ closes }O
\}.
$$

理論上 finite 不等於工程上可接受。

## 4. Witness complexity

$$
K_{\mathrm{wit}}(O,S)
=
\min_R |R|.
$$

可能 decision 很快，但最短 transformation witness 巨大：

$$
\boxed{
\text{decision complexity}
\neq
\text{realization complexity}.
}
$$

## 5. Verification complexity

還需區分：

$$
K_{\mathrm{search}},
\quad
K_{\mathrm{witness}},
\quad
K_{\mathrm{verify}}.
$$

大型 witness 仍可能具有小型 compressed verifier certificate。

## 6. Finite quotient

Bisimulation 與 symbolic-model literature 的重要啟發是：某些無限狀態系統能被 finite quotient 壓縮；但這不是所有 dynamical systems 的普遍保證。

這可能是 GFEC 的 decidability boundary。

## 7. Undecidability frontier

若 object class 足以編碼一般計算，functional-equivalence query 可能繼承 undecidable reachability / halting-like boundary。

因此強形式的「整個自然科學宇宙統一可判定」很可能過強；真正合理的目標是找 decidable islands。

## 8. 三種總猜想

### Strong Uniform GFEC

存在 uniform depth / cost bound。

### Weak Effective GFEC

每個 instance termination，但 bound 依 instance。

### Existential GFEC

只要求 finite certificate 存在，不要求統一算法找到。

三者強度差異巨大。

## 9. Closure spectrum

自然 object class 可分成：

$$
\mathcal U
=
\mathcal U_{\mathrm{easy}}
\cup
\mathcal U_{\mathrm{hard}}
\cup
\mathcal U_{\mathrm{semi}}
\cup
\mathcal U_{\mathrm{nondec}}.
$$

這可能比追求單一 yes/no 猜想更符合真實科學。

## 10. Complexity 版 Modern Hilbert III

問是否存在 family：

$$
(O_n,S_n)
$$

滿足：

$$
O_n\equiv_F S_n,
$$

但：

$$
K_{\mathrm{wit}}(O_n,S_n)
$$

超多項式、超指數，或在某模型下不可有效生成。

## 11. Approximation 也可能改變 complexity class

Exact equivalence：

$$
d_F=0
$$

可能難或不可判定；

Approximate equivalence：

$$
d_F\le\varepsilon
$$

可能存在有效 relaxation。

因此 approximate GFEC 應被單獨研究，而非混進 exact theorem。

## Claim Boundary

本篇沒有證明 MH3-GFEC 不可判定；它指出：若不限制自然對象類別與操作語言，強全域可判定猜想可能過強。未來應建立 decidable islands 與 complexity transitions。
