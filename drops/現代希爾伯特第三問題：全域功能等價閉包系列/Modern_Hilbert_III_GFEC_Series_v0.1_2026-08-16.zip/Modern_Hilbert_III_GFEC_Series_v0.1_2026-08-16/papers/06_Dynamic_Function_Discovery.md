# Paper 06 — 動態功能發現與科學閉包

## Dynamic Function Discovery and Open Scientific Closure

## 摘要

真實自然科學最大的問題是：主體域 $S$ 可能從未被一次完整定義。新的觀測、干預、尺度與故障機制會持續擴張我們認為應保留的功能。本篇建立雙塔模型：功能定義塔與證書塔共同演化。

## 1. 靜態假設的限制

前篇假設：

$$
\mathcal F(S)
$$

已固定。

真實科學更可能是：

$$
\boxed{
\mathcal F_0(S)
\subseteq
\mathcal F_1(S)
\subseteq
\mathcal F_2(S)
\subseteq\cdots.
}
$$

## 2. 功能新發現

新 stage 可以新增：

- 新 observable；
- 新時間尺度；
- 新 environment；
- 新 intervention；
- 新 failure mode；
- 新 coupling；
- 新安全 constraint；
- 新 emergent behavior。

所以：

$$
O\equiv_F^{(n)}S
$$

可能在後續 stage 失效。

## 3. 雙動態塔

證書庫也增長：

$$
\mathfrak C_0
\subseteq
\mathfrak C_1
\subseteq
\cdots.
$$

因此科學閉包狀態：

$$
\boxed{
\mathcal S_n
=
(
\mathcal F_n,
\mathfrak C_n,
U_n
).
}
$$

## 4. 追趕問題

核心不是某一 stage 是否 closure，而是：

$$
\boxed{
\text{certificate growth 能否追上 functional-domain growth？}
}
$$

可能：

### 收斂
$$
L_n\rightarrow0.
$$

### 有界追趕
$$
\sup_nL_n<\infty.
$$

### 永久落後
$$
L_n
$$

長期不受控或不斷生成新 unresolved frontier。

## 5. DGFEC

### Dynamic GFEC

是否：

$$
\boxed{
\forall O,\forall n,
\quad
\exists m\ge n
}
$$

使 $O$ 對 stage-$n$ 已知功能域的等價狀態在 stage $m$ 得到 finite closure？

這不要求自然科學停止發現新功能。

## 6. 最終穩定等價

若存在：

$$
N
$$

使：

$$
\forall n\ge N,
$$

$O$ 與 $S$ 的等價狀態不再翻轉，稱 eventually stable equivalence。

否則可能：

$$
\text{equal}
\rightarrow
\text{not equal}
\rightarrow
\text{equal}
\rightarrow\cdots.
$$

## 7. Epistemic status

更準確的科學敘述應是：

$$
\boxed{
O\equiv_F S
\text{ relative to current closed domain }
\mathcal F_n.
}
$$

而不是把 stage-wise closure 說成絕對終極真理。

## 8. Instrument expansion

新增 instrument：

$$
J_{n+1}
$$

可能同時擴張：

$$
\mathcal F_n
$$

與：

$$
\mathfrak C_n.
$$

所以儀器是 domain-extension operator，而非純 measurement tool。

## 9. 與 identifiability 的關係

Identifiability 研究顯示：即使理想觀察很多，模型仍可能只能識別到 equivalence class；加入 interventions 能縮小 equivalence class。

DGFEC 把這種思想推廣到：功能域與證書域共同增長。

## 10. 動態閉包猜想

一個弱而合理的版本：

$$
\boxed{
\forall O,\forall n,
\quad
\exists m<\infty:
\operatorname{Status}_m(O;\mathcal F_n)
\in
\{\texttt{EQUIV},\texttt{NON\_EQUIV}\}.
}
$$

即每個已提出的 finite-stage 問題最終能 closure，即使新的 stage 又提出新問題。

## Claim Boundary

DGFEC 不要求自然科學達到終極真理。它只問：對每個已明確提出的有限 stage，判定系統是否終究能追上。
