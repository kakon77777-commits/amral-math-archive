# Paper 05 — 全域量詞與正負證書不對稱

## Global Quantifiers and the Asymmetry of Positive and Negative Certificates

## 摘要

「我找不到替代 route」不是「不存在替代 route」。Modern Hilbert III 的真正難度集中在 existential positive witness 與 universal negative closure 的不對稱。

## 1. 正問題

$$
O\preceq_F S
\iff
\exists R\in\mathfrak R_{\mathrm{fin,loc}}
:
R(O)\equiv_F S.
$$

只要找到一個 route 即可。

正證書：

$$
C^+
=
(R,\Pi_F,V).
$$

其中 $\Pi_F$ 證明 transformation 後滿足全功能規格。

## 2. 負問題

$$
O\not\preceq_F S
$$

要求：

$$
\boxed{
\forall R\in\mathfrak R_{\mathrm{fin,loc}},
\quad
R(O)\not\equiv_F S.
}
$$

有限嘗試失敗不能完成這個全稱量詞。

## 3. Dehn 原型

Dehn invariant 的力量是：

$$
D(P)\neq D(Q)
$$

一次排除全部 scissors routes。

現代 negative certificate 的理想型態同樣是找到對整個合法 route class 都成立的 obstruction。

## 4. 現代負證書族

自然科學中可能包括：

- topology obstruction；
- conservation obstruction；
- controllability obstruction；
- causal impossibility；
- thermodynamic inequality；
- bandwidth/information bound；
- stability obstruction；
- reachability obstruction；
- phase/material impossibility；
- complexity lower bound。

## 5. Domain-relative no-go

任何負證書必須寫明假設：

$$
\Gamma_C.
$$

因此：

$$
\boxed{
C^-:
\Gamma_C
\vdash
O\not\preceq_F S.
}
$$

一旦 domain laws 改變，負證書可能不再適用。

## 6. 搜尋失敗、方法阻礙、反證

必須區分：

$$
\texttt{NOT\_FOUND},
$$

$$
\texttt{METHOD\_BLOCKED},
$$

$$
\texttt{IMPOSSIBLE}.
$$

而且：

$$
\boxed{
\texttt{NOT\_FOUND}
\not\Rightarrow
\texttt{METHOD\_BLOCKED}
\not\Rightarrow
\texttt{IMPOSSIBLE}.
}
$$

## 7. 功能域本身也帶全稱量詞

即使 route 找到了，仍要驗：

$$
\forall c\in\mathcal C_S.
$$

所以正證書含：

$$
\exists R\;\forall c.
$$

負問題則常接近：

$$
\forall R\;\exists c
$$

或更強 no-go theorem。

量詞交換就是問題難度的重要來源。

## 8. Witness compression

即使 $\mathcal C_S$ 是無限集合，有限 certificate 仍可能透過：

- symbolic theorem；
- invariant；
- bisimulation relation；
- finite quotient；
- contract；
- Lyapunov function；
- causal morphism；

壓縮無限行為。

MH3-GFEC 問的正是：這種有限壓縮證書是否對每個 instance 最終存在。

## 9. Negative Certificate Completeness

一個特別強的猜想是：

$$
\boxed{
O\not\preceq_F S
\Longrightarrow
\exists\text{ finite }C^-.
}
$$

這要求每一個 impossibility 都有有限 obstruction witness。

## 10. 可能的 failure

可能存在：

$$
O^\star\not\preceq_F S,
$$

但任何有限 certificate language 都只能排除 route 的有限 fragment，而不能完成 global no-go。

若這種對象存在，negative certificate completeness 失敗。

## 11. 與 formal verification 的關係

Compositional verification 與 assume-guarantee contracts 顯示：一個全域 property 可以在適當 interface assumptions 下被拆成局部 proof obligations。

這提供一條重要希望：MH3-GFEC 的全域量詞未必必須靠全域 brute force 驗證，而可能被有限 contract / quotient / relation 壓縮。

## Claim Boundary

本篇不假設正負 closure complexity 對稱，也不假設所有 no-go 都存在有限 invariant。這正是系列最可能產生反例的地方之一。
