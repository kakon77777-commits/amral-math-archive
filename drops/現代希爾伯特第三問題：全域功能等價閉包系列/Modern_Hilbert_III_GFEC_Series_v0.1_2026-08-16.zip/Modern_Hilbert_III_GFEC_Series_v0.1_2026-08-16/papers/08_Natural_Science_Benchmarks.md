# Paper 08 — 自然科學 Benchmark 與實驗計畫

## Natural-Science Testbeds for Global Functional Equivalence

## 摘要

本篇把 MH3-GFEC 從抽象猜想轉成可實驗研究計畫。第一批 benchmark 不應選完全未知宇宙，而應選已有成熟模型、可干預、可做替代實驗、但仍具有多層等價問題的系統。

## 1. Benchmark 原則

良好 testbed 應具備：

1. 主體域可明確規格；
2. 可建立多種結構不同的客體；
3. 有合法 interventions；
4. 有 failure / long-horizon regime；
5. 可測量正負 certificate；
6. 可控制 ground truth 或近似 ground truth。

## 2. Testbed A：電路與 two-port network

固定 reference network $S$。

功能域可包含：

- transfer function；
- transient response；
- impedance envelope；
- noise；
- thermal regime；
- saturation；
- fault response。

只比 transfer function 容易得到假等價；加入 fault 或 internal intervention 會進一步分離。

## 3. Testbed B：控制系統與 dynamical modules

以：

$$
\dot x=f(x,u)
$$

或 hybrid system 為主體。

可借用：

- simulation；
- bisimulation；
- approximate bisimulation；
- assume-guarantee contracts。

研究：

$$
\text{何種 finite relation 足以證明全功能 equivalence？}
$$

## 4. Testbed C：熱力／能量轉換模組

功能域：

- energy throughput；
- response curve；
- efficiency；
- hysteresis；
- extreme temperature；
- degradation；
- recovery。

這適合測試「某些守恆量必要但不完備」的 Dehn 類比。

## 5. Testbed D：催化／化學 reaction module

主體功能可定義為：

$$
\mathcal F
=
(
\text{rate},
\text{selectivity},
\text{temperature window},
\text{poisoning},
\text{recovery},
\text{byproducts}
).
$$

不同 catalyst 可能在標準條件等功能，但在 poisoning intervention 下分離。

## 6. Testbed E：基因調控／細胞模組

使用：

- perturbation；
- knockout；
- dose-response；
- temporal dynamics；
- recovery；
- latent-state observation。

因果 discovery 與 interventional equivalence literature 已顯示 interventions 可以縮小 observational equivalence class。

MH3-GFEC 更進一步問：

> 一個不同機制的合成模組是否在完整 intervention set 下可作為原模組的功能替代？

## 7. Testbed F：軟體／數位系統作 calibration

雖然不是自然科學主體，但 software 可提供 formal ground truth：

- contracts；
- bisimulation；
- model checking；
- finite-state equivalence。

適合先驗證 Candidate-Certificate Ecology 是否工作。

## 8. 實驗資料結構

```text
subject/
  specification.md
  legal_contexts.json
  interventions.json
  observables.json

objects/
  O001/
  O002/

certificates/
  positive/
  negative/
  unresolved/

candidates/
  proposed/
  validated/
  rejected/
```

## 9. 每輪實驗

對每個 $O$：

1. 使用現有 $\mathfrak C_n$；
2. 判定 EQUIV / NON_EQUIV / UNRESOLVED；
3. 對 UNRESOLVED 生成候補；
4. 實驗或形式驗證候補；
5. 升格新證書；
6. 重跑 benchmark；
7. 測量 coverage 增量。

## 10. 指標

### Coverage
$$
\operatorname{Cov}_n
=
\frac{
|\text{closed objects}|
}{
|\mathcal U_{\mathrm{test}}|
}.
$$

### Candidate efficiency
$$
\eta(h)
=
\frac{
|\Delta\operatorname{Cov}(h)|
}{
\operatorname{cost}(h)
}.
$$

### Closure depth
$$
n(O).
$$

### Stability
當 $\mathcal F_n\rightarrow\mathcal F_{n+1}$ 時，原 closure 有多少翻轉。

## 11. Falsification-first design

必須刻意加入：

- observational twins；
- causal non-twins；
- long-horizon divergence；
- hidden failure；
- adversarial replacements；
- route-search traps。

如果候補系統無法分離這些案例，GFEC 研究程式必須修正。

## 12. 第一階段最推薦 domain

第一批應優先：

$$
\boxed{
\text{linear / hybrid dynamical systems}
}
$$

因為其 bisimulation、contracts、reachability、identifiability 工具相對成熟，又足以製造 nontrivial equivalence。

## Claim Boundary

Benchmark 成功不等於 global conjecture 成立；它只建立可檢驗的有限科學域，供後續尋找 theorem、counterexample 與 complexity transition。
