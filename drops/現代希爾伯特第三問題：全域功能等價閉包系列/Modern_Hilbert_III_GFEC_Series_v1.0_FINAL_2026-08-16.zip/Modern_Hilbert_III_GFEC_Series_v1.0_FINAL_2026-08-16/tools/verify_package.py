from pathlib import Path
import json

ROOT=Path(__file__).parents[1]
m=json.loads((ROOT/"meta"/"MANIFEST.json").read_text(encoding="utf-8"))

assert m["version"]=="v1.0 FINAL"
assert len(m["papers"])==11
assert m["paper_count"]==11

total=0
for name in m["papers"]:
    p=ROOT/"papers"/name
    assert p.exists(), name
    t=p.read_text(encoding="utf-8")
    assert len(t)>1800, (name,len(t))
    assert "Claim Boundary" in t, name
    assert "\\(" not in t and "\\)" not in t
    assert "\\[" not in t and "\\]" not in t
    assert t.count("$$")%2==0
    total += len(t)

assert total > 30000
for rel in [
    "README.md",
    "meta/GLOSSARY.md",
    "meta/AI_HANDOFF.md",
    "meta/RELEASE_NOTES.md",
    "references/REFERENCES.md"
]:
    assert (ROOT/rel).exists(), rel

print(f"PASS: MH3-GFEC v1.0 FINAL, 11 complete papers, {total} UTF-8 characters, claim boundaries, final handoff, and math-source hygiene.")
