# Paper 01 — 從 Hilbert 第三問題到全域功能等價

## From Scissors Congruence to Global Functional Equivalence

## 摘要

Hilbert 第三問題的核心不只是「切多面體」，而是：有限局部操作下，哪些全域量足以判定兩個對象是否屬於同一等價類。Dehn 的歷史解答顯示，一個看似自然的全域量可以是不完備的；真正關鍵是建立對所有合法局部操作都守恆或可驗證的 certificate。

二十一世紀版本可把問題抽象為：固定自然主體域 $S$，對任意客體 $O$，是否存在有限局部操作 $R$ 使 $R(O)$ 在完整合法功能域中等同於 $S$。

## 1. 古典量詞

Hilbert 第三問題實際問的是 volume 是否 complete：

$$
V(P)=V(Q)
\stackrel{?}{\Longrightarrow}
P\sim Q.
$$

Dehn 的貢獻是一張 negative certificate：

$$
D(P)\neq D(Q)
\Longrightarrow
P\not\sim Q.
$$

## 2. 現代抽象

把「多面體」換成任一可完整描述的自然對象。

把「切割與剛體運動」換成：

$$
\mathfrak R_{\mathrm{fin,loc}},
$$

即全部有限、局部、合法的拆解—變換—重組操作。

把「剪拼同構」換成：

$$
\equiv_F,
$$

即完整合法功能域上的等功能。

因此主問題是：

$$
\boxed{
O\equiv_S
\iff
\exists R\in\mathfrak R_{\mathrm{fin,loc}}
:
R(O)\equiv_F S.
}
$$

## 3. 為什麼不是單純 generalized scissors congruence

現代 higher scissors congruence 已把 cut-and-paste 提升到 $K$-theory spectrum，高階 homotopy groups 可記錄超過 classical object class 的資訊。

MH3-GFEC 則更換了等價目標：

- 幾何剪拼只是一種 FLDTR；
- 功能可替代性可以跨材料、尺度與結構；
- 允許變換不只 isometry；
- 允許研究過程動態生成新的 certificate language。

因此 higher scissors congruence 是歷史與技術祖先，而不是等價問題本身。

## 4. 全域量詞升級

新問題：

$$
\boxed{
\forall O\in\mathcal U_S,\quad
\operatorname{Decide}
\left[
\exists R\in\mathfrak R_{\mathrm{fin,loc}}
:
R(O)\equiv_F S
\right].
}
$$

若結果為否，真正需要：

$$
\boxed{
\forall R\in\mathfrak R_{\mathrm{fin,loc}},
\quad
R(O)\not\equiv_F S.
}
$$

這比「找不到 route」強得多。

## 5. 新增候補機制

古典問題常固定 invariant language 再求完備。

本系列允許：

$$
\mathfrak C_0\subseteq\mathfrak C_1\subseteq\cdots.
$$

未決客體可能生成：

- 新 invariant；
- 新介面；
- 新實驗；
- 新干預；
- 新 representation；
- 新 conservation law；
- 新 synthesis route；
- 新 verifier。

研究系統本身因此成為問題的一部分。

## 6. 鄰接理論

Bisimulation 表明「外部行為無法分辨」可以有嚴格數學語義；causal abstraction 進一步要求 interventions 下保持一致；compositional verification 則說明局部 certificate 可以在 interface contract 下支撐全域驗證。

這些理論都提供 MH3-GFEC 可借用的局部語言。

## 7. 第一原則

$$
\boxed{
\text{局部可替代}
\neq
\text{全域等功能}
}
$$

以及：

$$
\boxed{
\text{觀察一致}
\neq
\text{干預一致}
\neq
\text{完全功能等價}.
}
$$

## 8. 新問題的本質

真正的 Modern Hilbert III 不再只問：

> 還缺哪個 invariant？

而是：

> 對任一尚未 closure 的客體，是否總能在有限研究階段找到足夠的新證書，使全域等功能判定結束？

## Claim Boundary

本文只完成歷史抽象與量詞轉換。它不證明 GFE 可判定，也不主張現有 higher scissors theory 可直接解答自然科學中的功能替代問題。

## 9. Formal Completion Addendum

### Definition 9.1 — Dehn-type certificate pattern

稱一個證書 $I$ 為 Dehn-type obstruction，若：

$$
I(R(O))=I(O)
$$

對所有合法 route $R$ 成立，且：

$$
I(O)\neq I(S).
$$

則：

$$
O\not\preceq_F S.
$$

### Proposition 9.2 — Classical obstruction is a special case

古典 scissors-congruence problem 可嵌入 MH3-GFEC，只要：

- $S,Q$ 取多面體；
- $\mathcal F$ 取幾何重組等價；
- $\mathfrak R_{\mathrm{fin,loc}}$ 取有限 scissors operations。

因此 Modern Hilbert III 不是否定古典問題，而是包含其 certificate architecture。

### Definition 9.3 — Method-language extension

若原 route/certificate language 為：

$$
\mathcal L_n,
$$

候補發明可產生：

$$
\mathcal L_n
\subsetneq
\mathcal L_{n+1}.
$$

新問題的核心因此不是在固定語言中求 completeness，而是在允許語言擴張時問 pointwise termination。

### Research Question 9.4

是否存在自然 domain，使：

$$
\forall n,
\quad
\exists O_n
$$

逃離 $\mathcal L_n$，但每個固定 $O$ 最終仍能在某個更高語言 closure？

這會形成「無 uniform basis、但 pointwise closure」的標準模型。
