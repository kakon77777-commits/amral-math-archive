# Paper 04 — 候補證書生態與單調閉包

## Candidate-Certificate Ecology and Monotone Closure

## 摘要

本篇形式化「每證明一個，就發現或發明一個候補」的研究機制。候補不是錯誤證明，而是尚未成為 closure certificate 的可擴張研究物件。

## 1. 初始證書庫

令：

$$
\mathfrak C_0
=
\{
C_1,\ldots,C_m
\}.
$$

每個 certificate：

$$
C=(D,\Gamma,A,V,\sigma,K)
$$

可記錄 domain、假設、演算法、驗證器、soundness status 與成本。

## 2. 未決區域

$$
U_n
=
\mathcal U_S
\setminus
\operatorname{Cov}(\mathfrak C_n).
$$

## 3. 候補生成

當：

$$
O\in U_n,
$$

研究控制器產生：

$$
H_n(O)=\{h_1,h_2,\ldots\}.
$$

候補類型包括：

- 新 invariant；
- 新 behavioral quotient；
- 新 intervention；
- 新 sensor；
- 新 experiment；
- 新 decomposition primitive；
- 新 causal abstraction；
- 新 obstruction theorem；
- 新 synthesis route；
- 新 verifier。

## 4. 候補升格

候補只有通過：

$$
\operatorname{Validate}(h)=\texttt{PASS}
$$

才加入：

$$
\boxed{
\mathfrak C_{n+1}
=
\mathfrak C_n\cup\{h\}.
}
$$

因此：

$$
\operatorname{Cov}(\mathfrak C_n)
\subseteq
\operatorname{Cov}(\mathfrak C_{n+1}),
$$

以及：

$$
U_{n+1}\subseteq U_n.
$$

## 5. 不要求有限 basis

強形式：

$$
\exists\mathfrak C^\star
$$

一次 closure 全域。

弱形式：

$$
\boxed{
\forall O\;\exists n(O)<\infty.
}
$$

弱形式允許：

$$
\sup_O n(O)=\infty.
$$

也就是全域證書塔無界，但每個 instance 都有限結束。

## 6. 候補不只是 invariant

候補空間應寫成：

$$
\mathcal H
=
\mathcal H_{\mathrm{inv}}
\cup
\mathcal H_{\mathrm{exp}}
\cup
\mathcal H_{\mathrm{rep}}
\cup
\mathcal H_{\mathrm{syn}}
\cup
\mathcal H_{\mathrm{ver}}.
$$

其中包含 experiment、representation、synthesis 與 verifier。

## 7. unresolved 不是反證

$$
\texttt{UNRESOLVED}
\rightarrow
\text{analyze residual}
\rightarrow
\text{new candidate}
\rightarrow
\text{validate}
\rightarrow
\text{expand library}.
$$

這與 counterexample-guided abstraction/refinement 有家族相似性。

## 8. Candidate novelty

若：

$$
\operatorname{Cov}(h)
\subseteq
\operatorname{Cov}(\mathfrak C_n),
$$

則只是重述舊工具。

定義 marginal coverage：

$$
\Delta\operatorname{Cov}(h)
=
\operatorname{Cov}(h)
\setminus
\operatorname{Cov}(\mathfrak C_n).
$$

## 9. 儀器也是候補

新增 instrument 可能改變可觀察／可干預的 domain，因此自然科學儀器可被視為：

$$
\boxed{
\text{epistemic operator extension}.
}
$$

## 10. 候補閉包猜想

$$
\boxed{
O\in U_n
\Longrightarrow
\exists h\in H_n(O),\exists k<\infty:
O\notin U_{n+k}.
}
$$

這是 GFEC 最核心、也最可能失敗的假設之一。

## Claim Boundary

單調擴張不代表一定收斂。可能存在無限嚴格下降：

$$
U_0\supsetneq U_1\supsetneq\cdots
$$

但某個 $O^\star$ 永遠屬於所有 $U_n$。

## 11. Formal Completion Addendum

### Definition 11.1 — Candidate state machine

候補 $h$ 的狀態：

$$
\operatorname{State}(h)
\in
\{
\texttt{PROPOSED},
\texttt{TESTING},
\texttt{VALIDATED},
\texttt{REJECTED},
\texttt{SUPERSEDED}
\}.
$$

只有：

$$
\texttt{VALIDATED}
$$

才可進入 canonical certificate library。

### Definition 11.2 — Residual signature

對 unresolved object $O$ 定義：

$$
\rho_n(O)
$$

描述現有證書全部失敗後仍未被解釋的結構。

候補生成器應優先依賴 $\rho_n(O)$，而不是無條件隨機擴張理論。

### Proposition 11.3 — Coverage monotonicity

在功能域固定且只新增 sound certificates 時：

$$
\operatorname{Cov}_{n+1}
\supseteq
\operatorname{Cov}_n.
$$

### Definition 11.4 — Candidate productivity

$$
\operatorname{Prod}(h)
=
\frac{
|\Delta\operatorname{Cov}(h)|
}{
K_{\mathrm{discover}}(h)+K_{\mathrm{verify}}(h)
}.
$$

這可作為多候補 routing 的工程指標。

### Conjecture 11.5 — Residual-generated progress

對 GFEC-1 成立的 domain，應存在某種 residual-sensitive candidate generator，使每個 persistent unresolved instance 最終產生非零 marginal coverage 的候補。
