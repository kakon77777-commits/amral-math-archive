# 現代希爾伯特第三問題：全域功能等價閉包系列

## 統一總論：從有限剪拼到自然科學的全域可替代性

版本：v0.1  
日期：2026-08-16

## 摘要

Hilbert 第三問題問：兩個等體積多面體是否必然可以透過有限切割與剛體重組互相轉換。Dehn 的解答顯示，單一宏觀量「體積」不足以判定剪拼等價；後續理論則把 scissors congruence 推向完整分類與更高階 cut-and-paste $K$-theory。

本系列提出一個不同層級的現代化問題。固定一個被完整定義的自然主體域對象 $S$，考慮所有合法客體 $O\in\mathcal U_S$。允許的方法論不預先封閉，但真正的實現必須落在某個有限、局部、合法、可驗證的拆解—變換—重組系統中。核心問題不是找一個新的 Dehn invariant，而是：

$$
\boxed{
\forall O\in\mathcal U_S,\quad
\operatorname{Decide}
\left[
\exists R\in\mathfrak R_{\mathrm{fin,loc}}
:
R(O)\equiv_F S
\right]
}
$$

更進一步，本系列不要求一開始就存在固定有限 invariant basis，而允許研究過程本身持續發現或發明新的候補證書：

$$
\boxed{
\mathfrak C_0
\subseteq
\mathfrak C_1
\subseteq
\mathfrak C_2
\subseteq\cdots.
}
$$

因此真正的現代問題變成：**是否對每一個客體，都能在有限階段得到正或負 closure，即使全域證書塔本身無界？**

本系列將這個問題稱為：

$$
\boxed{
\textbf{MH3-GFEC：Modern Hilbert III — Global Functional Equivalence Closure}
}
$$

## 1. 歷史轉譯

古典問題：

$$
P\sim_{\mathrm{sc}}Q?
$$

現代問題：

$$
O
\stackrel{\mathfrak R_{\mathrm{fin,loc}}}{\longrightarrow}
S
\quad\text{且}\quad
R(O)\equiv_F S?
$$

Dehn 型思維主要處理負證書：

$$
I(P)\neq I(Q)
\Longrightarrow
P\not\sim Q.
$$

MH3-GFEC 則要求同時處理：

$$
C^+,\qquad C^-,
$$

以及當兩者皆不存在時如何產生新候補。

## 2. 系列的九個核心問題

1. 主體域如何被「完整定義」？
2. 什麼叫做「完全等功能」？
3. 哪些操作算有限、局部、合法的拆解—變換—重組？
4. 如何允許方法論無界，但保持 closure certificate 有限？
5. 正證書與負證書是否存在根本不對稱？
6. 若功能域本身隨科學發現擴張，等價判定如何維持？
7. pointwise finite closure 是否可能，而 uniform finite closure 不可能？
8. 自然科學中哪些系統適合成為第一批 benchmark？
9. 是否存在一個客體永遠迫使候補塔繼續增長而無法 closure？

## 3. 研究立場

本系列不把「完全等功能」等同於：

- 觀察資料相同；
- 靜態 input-output 相同；
- 結構同構；
- 因果圖相同；
- 材料相同；
- 幾何形狀相同。

完全等功能必須相對於已完整宣告的合法功能域定義。

因此兩個內部結構不同的系統仍可能功能等價；反之，兩個在既有觀察上完全一致的系統，也可能在新干預、極端環境或長時間尺度下分離。

## 4. 與既有理論的關係

Bisimulation 提供「行為不可區分」的一類嚴格形式化；causal abstraction 要求不同層模型在干預效果上保持一致；identifiability 研究觀察與干預資料是否足以唯一回復模型；compositional contracts 允許用局部 assume-guarantee 規格支撐全系統驗證；higher scissors congruence 則表明 cut-and-paste 本身具有高階結構。

MH3-GFEC 借用這些工具，但問題量詞更廣：

$$
\boxed{
\forall O
\;\exists n
\;\exists C_n^\pm
}
$$

而且 $C_n^\pm$ 的語言可因 unresolved case 而被擴張。

## 5. 最小總命題

### MH3-GFEC 弱閉包猜想

對一個具有完整合法功能規格的有限可描述自然主體域 $S$：

$$
\boxed{
\forall O\in\mathcal U_S,
\quad
\exists n(O)<\infty,
\quad
\exists C^\pm\in\mathfrak C_{n(O)}
}
$$

使 $C^\pm$ 可有限驗證地判定：

$$
O\equiv_F S
\quad\text{或}\quad
O\not\equiv_F S.
$$

### 強閉包猜想

存在與客體無關的有限上界：

$$
\boxed{
\exists N\;\forall O,\quad n(O)\le N.
}
$$

本系列不預設強猜想成立。

## 6. 真正的 failure condition

最重要的反例不是找到一個新 obstruction，而是找到：

$$
\boxed{
\exists O^\star\;\forall n,\quad
O^\star
\text{ 在 }
\mathfrak C_n
\text{ 下永遠 unresolved}.
}
$$

若這種對象存在，則 pointwise finite closure 失敗。

## 7. 本系列的角色

本系列不是宣稱 MH3-GFEC 已被證明，而是完成：

1. 問題量詞的正式化；
2. 主體／客體／功能域的拆分；
3. FLDTR 操作本體；
4. 候補證書生態；
5. 正負 closure 的不對稱；
6. 動態科學定義；
7. 完備性與複雜度光譜；
8. 第一批自然科學 benchmark；
9. 可供後續證明／反例研究使用的統一猜想。

## 8. 系列文件

- Paper 01：從 Hilbert III 到全域功能等價
- Paper 02：主體域、功能域與完全等功能
- Paper 03：有限局部拆解—變換—重組本體
- Paper 04：候補證書生態與單調閉包
- Paper 05：全域量詞與正負證書不對稱
- Paper 06：動態功能發現與科學閉包
- Paper 07：可判定性、複雜度與閉包光譜
- Paper 08：自然科學 benchmark 與實驗計畫
- Paper 09：統一猜想、反例形式與研究路線

## Claim Boundary

本文提出研究框架與猜想，並不宣稱自然科學中的完全功能等價普遍可判定。現有 bisimulation、causal abstraction、identifiability、contract verification 與 higher scissors congruence 是重要鄰接理論，但其已知結果不能直接推出 MH3-GFEC。

## 9. Formal Completion Addendum

### Definition 9.1 — MH3-GFEC instance

一個 MH3-GFEC instance 定義為：

$$
\boxed{
\mathfrak I
=
(
S,
\mathcal U_S,
\mathcal F_S,
\mathfrak R_{\mathrm{fin,loc}},
\mathfrak C_0
).
}
$$

只有當這五個 component 都被宣告，問題才算 well-posed。

### Definition 9.2 — Closure status

對 stage $n$ 與客體 $O$，定義：

$$
\operatorname{Status}_n(O)
\in
\{
\texttt{EQUIV},
\texttt{NON\_EQUIV},
\texttt{UNRESOLVED}
\}.
$$

要求 soundness：

$$
\texttt{EQUIV}
\Rightarrow
O\preceq_F S,
$$

$$
\texttt{NON\_EQUIV}
\Rightarrow
O\not\preceq_F S.
$$

### Proposition 9.3 — Monotone closure under sound library extension

若：

$$
\mathfrak C_n
\subseteq
\mathfrak C_{n+1},
$$

且新證書不撤銷舊證書的 soundness，則已 closure 的 object 不會因純 certificate-library expansion 回到 unresolved。

形式上：

$$
\operatorname{Closed}_n
\subseteq
\operatorname{Closed}_{n+1}.
$$

這裡不包含功能域擴張；Paper 06 專門處理 $\mathcal F_n$ 改變時 status 可能 reopen 的情況。

### Conjecture 9.4 — Pointwise finite closure

$$
\boxed{
\forall O\in\mathcal U_S,
\quad
\exists n<\infty:
\operatorname{Status}_n(O)
\neq
\texttt{UNRESOLVED}.
}
$$

### Non-implication 9.5

$$
\text{Pointwise finite closure}
\not\Rightarrow
\text{uniform finite closure}.
$$

這是整個系列最重要的量詞邊界之一。
