# Paper 02 — 主體域、功能域與完全等功能

## Subject-Domain Specification and Total Functional Equivalence

## 摘要

若「完全等功能」沒有精確邊界，MH3-GFEC 會退化為語義遊戲。本篇建立主體域 $S$ 的 reference specification，並把功能等價拆成觀察、干預、動力、因果、故障與適應層。

## 1. 主體不是心理學主體

本文的主體域 $S$ 只是被選為比較基準的 reference object。

它可以是馬達、細胞模組、催化系統、控制器、感測器、人工器官或能量轉換裝置。

## 2. 完整規格

定義：

$$
\boxed{
S=
(
X,\Sigma,\mathcal E,\mathcal I,\mathcal O,
\Phi,\Gamma,\Lambda,\mathcal R_f
).
}
$$

其中：

- $X$：可達狀態空間；
- $\Sigma$：結構與組成規格；
- $\mathcal E$：合法環境；
- $\mathcal I$：合法 interventions；
- $\mathcal O$：合法 observables；
- $\Phi$：動力與時間演化；
- $\Gamma$：因果／耦合結構；
- $\Lambda$：合法性、安全與存在約束；
- $\mathcal R_f$：故障、恢復、退化與適應 regimes。

## 3. Functional context

定義合法功能情境：

$$
c=(e,\iota,t,\rho)
\in
\mathcal C_S
=
\mathcal E\times\mathcal I\times\mathcal T\times\mathcal R_f.
$$

觀察映射：

$$
\operatorname{Obs}_S(c).
$$

最弱 observable equivalence 是：

$$
\forall c\in\mathcal C_S,\quad
\operatorname{Obs}_S(c)
=
\operatorname{Obs}_O(c).
$$

## 4. 為什麼 input-output 不夠

兩個系統可能在有限 dataset 上完全相同，但：

- 對新 intervention 不同；
- long horizon 分離；
- 極端環境不同；
- 一個存在 hidden failure mode；
- 一個可恢復，另一個不可；
- adaptation trajectory 不同。

Identifiability 文獻反覆顯示：observational equivalence 不保證 mechanism 或 intervention response 唯一。

## 5. 全功能等價

本系列提出：

$$
\boxed{
O\equiv_F S
}
$$

當且僅當在已完整宣告的合法功能域中，存在 interface-respecting correspondence $\Psi$，使：

### 觀察一致
$$
\forall c,\quad
\operatorname{Obs}_O(c)
=
\operatorname{Obs}_S(c).
$$

### 干預一致
$$
\Psi\circ\operatorname{do}_O(\iota)
\simeq
\operatorname{do}_S(\iota)\circ\Psi.
$$

### 動力一致
$$
\Psi\circ\Phi_O^t
\simeq
\Phi_S^t\circ\Psi.
$$

### 故障與恢復一致

對所有宣告為功能的一部分的 failure/recovery regimes，兩者可達行為相同。

## 6. 結構可以不同

完全等功能不要求：

$$
\Sigma_O\cong\Sigma_S.
$$

否則「替代」會被錯誤縮成「複製」。

真正需要保留的是宣告的 functional quotient。

## 7. Internal intervention 問題

如果內部機制也被列入合法 intervention domain，內部結構差異會重新變成可觀察差異。

因此：

$$
\boxed{
\equiv_F
=
\equiv_F^{\mathcal C_S}.
}
$$

「完整」永遠 relative to declared domain。

## 8. Exact 與 approximate

自然科學實務通常只有：

$$
d_F(O,S)\le\varepsilon.
$$

但 MH3-GFEC 核心先研究：

$$
d_F(O,S)=0.
$$

Approximate GFEC 應作第二層擴展。

## 9. 與 causal abstraction / bisimulation 的關係

Causal abstraction 提供跨層模型在 interventions 下保持 consistency 的語言；bisimulation 提供狀態轉移行為等價的語言。

本篇把它們視為 functional equivalence 的可選 certificate languages，而不是唯一正確定義。

## 10. 主體域完整性假設

本篇所有 exact proposition 都是 conditional：

$$
\boxed{
\text{Assume }S\text{ is completely specified relative to }\mathcal C_S.
}
$$

若 $S$ 本身持續被科學發現擴充，則需進入 Dynamic GFEC。

## Claim Boundary

「完整主體域」在真實科學中可能無法實際達到。本篇只定義：若完整規格存在，完全等功能應如何形式化。

## 11. Formal Completion Addendum

### Definition 11.1 — Functional question algebra

令：

$$
\mathcal Q_F(S)
$$

為所有合法功能問題的集合。

每個：

$$
q\in\mathcal Q_F(S)
$$

對 object $X$ 產生一個 response：

$$
\operatorname{Ans}_X(q).
$$

則最抽象的完全功能等價可寫成：

$$
\boxed{
O\equiv_F S
\iff
\forall q\in\mathcal Q_F(S),
\quad
\operatorname{Ans}_O(q)
=
\operatorname{Ans}_S(q).
}
$$

前文的 environment、intervention、time、failure regimes 都可以編碼進 $q$。

### Proposition 11.2 — Domain refinement anti-monotonicity

若：

$$
\mathcal Q_F^{(1)}
\subseteq
\mathcal Q_F^{(2)},
$$

則：

$$
O\equiv_F^{(2)}S
\Rightarrow
O\equiv_F^{(1)}S.
$$

反向一般不成立。

因此功能域越完整，equivalence class 只能維持或縮小。

### Definition 11.3 — Functional indistinguishability class

$$
[O]_{\mathcal Q_F}
=
\{
X:
X\equiv_F O
\}.
$$

Identifiability 問題可被理解為：資料／干預是否足以把這個 class 壓縮到需要的粒度。

### Research Boundary 11.4

「內部結構」是否算功能取決於：

$$
\mathcal Q_F.
$$

一旦允許直接內部 intervention，原本純 external functional twins 可能立即分離。
