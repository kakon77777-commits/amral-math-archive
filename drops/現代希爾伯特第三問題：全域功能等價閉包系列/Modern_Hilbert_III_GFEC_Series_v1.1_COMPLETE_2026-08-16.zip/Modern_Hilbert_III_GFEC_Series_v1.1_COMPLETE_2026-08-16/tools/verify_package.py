from pathlib import Path
import json

ROOT=Path(__file__).parents[1]
m=json.loads((ROOT/"meta"/"MANIFEST.json").read_text(encoding="utf-8"))
assert m["version"]=="v1.1 COMPLETE"
assert len(m["papers"])==11

total=0
for name in m["papers"]:
    p=ROOT/"papers"/name
    assert p.exists()
    t=p.read_text(encoding="utf-8")
    assert "Claim Boundary" in t
    assert "Formal Completion Addendum" in t
    assert "\\(" not in t and "\\)" not in t
    assert "\\[" not in t and "\\]" not in t
    assert t.count("$$")%2==0
    total += len(t)

for rel in [
    "meta/CLAIM_LEDGER.md",
    "meta/DEPENDENCY_GRAPH.md",
    "meta/FORMAL_STATEMENT_INDEX.md",
    "meta/GLOSSARY.md",
    "meta/AI_HANDOFF.md",
    "references/REFERENCES.md"
]:
    assert (ROOT/rel).exists()

ledger=(ROOT/"meta"/"CLAIM_LEDGER.md").read_text(encoding="utf-8")
assert "GFEC-1" in ledger and "CONJ" in ledger
assert total > 42000

print(f"PASS: MH3-GFEC v1.1 COMPLETE, 11 papers with formal addenda, {total} UTF-8 characters, claim ledger, dependency graph, statement index, and source hygiene.")
