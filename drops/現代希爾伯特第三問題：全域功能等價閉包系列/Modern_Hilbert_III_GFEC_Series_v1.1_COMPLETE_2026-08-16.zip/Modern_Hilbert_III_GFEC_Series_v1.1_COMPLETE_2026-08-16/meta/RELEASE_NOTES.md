# RELEASE NOTES — v1.0 FINAL

## Status

MH3-GFEC 第一版完整理論系列正式封頂。

## 與 v0.1 的差異

- v0.1：系列骨架與核心九問題。
- v1.0 Final：完成全部 00–10 正文、統一 conjecture lattice、falsification taxonomy、natural-science benchmark program、final conclusion 與 handoff。

## 不再於本系列新增

- 新抽象公理；
- 新 Hilbert III 歷史支線；
- 新 scissors-congruence 數論分支；
- 未實驗的 additional benchmark paper。

後續直接進 sandbox / theorem / counterexample 工作。

## 正確發表定位

- Research proposal
- Conjecture framework
- Formal problem program
- Certificate-ecology methodology

不是：

- solved theorem
- universal natural-science equivalence algorithm

## v1.1 COMPLETE

此版是理論系列的 complete edition。相較 v1.0 Final，不增加新的核心 conjecture，而是補全命題索引、依賴、claim status 與每篇 formal addendum。
