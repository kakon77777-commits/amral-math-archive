# CLAIM LEDGER — MH3-GFEC v1.1 COMPLETE

## Status codes

- **DEF**：definition
- **PROP**：elementary/logical proposition
- **FRAMEWORK**：research architecture
- **CONJ**：unproved conjecture
- **OPEN**：explicit open problem
- **EMPIRICAL**：future benchmark target, not yet demonstrated in this series

| ID | Claim | Status |
|---|---|---|
| GFEC-0 | Accepted certificates must be sound | DEF / design axiom |
| GFEC-1 | Every object reaches finite pointwise closure | CONJ |
| GFEC-2 | A uniform finite certificate basis exists | CONJ / may be false |
| GFEC-3 | A single effective algorithm closes every instance | CONJ / domain-dependent |
| GFEC-4 | Every positive instance has effective FLDTR witness extraction | CONJ |
| GFEC-5 | Every negative instance has finite obstruction certificate | CONJ |
| DGFEC | Every finite-stage functional question is eventually caught up by certificate growth | CONJ |
| Monotone certificate coverage | Fixed functional domain + sound library extension cannot reduce closure | PROP |
| Functional-domain refinement | Enlarging legal questions cannot enlarge equivalence classes | PROP |
| Search-open / closure-closed firewall | Proposal freedom does not itself license closure | FRAMEWORK |
| Candidate Progress | Every persistent residual eventually yields a useful candidate | CONJ |
| Natural-science benchmark convergence | Candidate ecology will empirically show monotone useful coverage in chosen domains | EMPIRICAL |

## Publication rule

任何摘要、網站、論文或 README 都不得把 `CONJ` 自動改寫成「proved」、「solved」或「complete theory」。

## Strongest statement currently justified

$$
\boxed{
\text{MH3-GFEC is a formally specified conjecture framework and experimental research program.}
}
$$
