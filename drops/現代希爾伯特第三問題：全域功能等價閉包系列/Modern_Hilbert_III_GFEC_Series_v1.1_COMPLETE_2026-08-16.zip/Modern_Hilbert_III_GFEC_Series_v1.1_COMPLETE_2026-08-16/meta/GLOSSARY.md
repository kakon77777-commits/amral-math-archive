# 術語與符號表

- **主體域對象 $S$**：被選為完整等功能判定基準的 reference object；不要求具有意識。
- **客體域對象 $O$**：任一被拿來與 $S$ 比較、替代、拆解、轉換或重組的候選對象。
- **比較宇宙 $\mathcal U_S$**：對 $S$ 合法且可比較的全部客體集合。
- **合法功能域 $\mathcal F(S)$**：應被保留的功能、環境、干預、時間、故障、適應與因果回應條件。
- **完全等功能 $\equiv_F$**：在已宣告的完整合法功能域上完全一致；不等於材料、幾何或內部結構相同。
- **FLDTR**：Finite Local Decompose–Transform–Reassemble，有限局部拆解—變換—重組系統。
- **方法論開放**：搜尋與發現方法不限；最終 closure certificate 仍須有限、合法、可驗證。
- $\mathfrak C_n$：第 $n$ 階證書庫。
- **正證書 $C^+$**：給出可驗證 FLDTR witness 與完全等功能證明。
- **負證書 $C^-$**：給出全域阻礙，排除全部合法 FLDTR route。
- **候補 $H$**：可成為新 invariant、experiment、representation、operator、theorem、intervention 或 verifier 的研究候選。
- **uniform finite closure**：
  $$
  \exists N\;\forall O,\quad n(O)\le N.
  $$
- **pointwise finite closure**：
  $$
  \forall O\;\exists n(O)<\infty.
  $$
- **non-closure**：
  $$
  \exists O^\star\;\forall n,\quad O^\star\text{ unresolved}.
  $$
- **MH3-GFEC**：Modern Hilbert III — Global Functional Equivalence Closure.
- **DGFEC**：Dynamic Global Functional Equivalence Closure.
