# SERIES DEPENDENCY GRAPH

## Paper dependency DAG

```text
00 Unified Overview
├── 01 From Hilbert III to GFE
├── 02 Subject Domain / Functional Equivalence
│   ├── 03 FLDTR Operator Ontology
│   │   └── 05 Global Quantifiers / Certificates
│   └── 06 Dynamic Function Discovery
├── 04 Candidate-Certificate Ecology
│   ├── 05 Global Quantifiers / Certificates
│   ├── 06 Dynamic Function Discovery
│   └── 07 Decidability / Complexity
├── 08 Natural-Science Benchmarks
│   └── depends on 02–07
├── 09 Unified Conjectures
│   └── depends on 01–08
└── 10 Series Conclusion
    └── depends on 00–09
```

## Logical dependency chain

$$
\boxed{
S
\rightarrow
\mathcal F_S
\rightarrow
\mathfrak R_{\mathrm{fin,loc}}
\rightarrow
\mathfrak C_n
\rightarrow
\operatorname{Status}_n
\rightarrow
\text{GFEC conjectures}.
}
$$

## Dependency warning

不能在沒有固定：

$$
\mathcal F_S
$$

時聲稱「完全等功能」。

不能在沒有固定：

$$
\mathfrak R_{\mathrm{fin,loc}}
$$

時聲稱「不存在合法 transformation」。

不能把：

$$
\texttt{UNRESOLVED}
$$

寫成：

$$
\texttt{NON\_EQUIV}.
$$
