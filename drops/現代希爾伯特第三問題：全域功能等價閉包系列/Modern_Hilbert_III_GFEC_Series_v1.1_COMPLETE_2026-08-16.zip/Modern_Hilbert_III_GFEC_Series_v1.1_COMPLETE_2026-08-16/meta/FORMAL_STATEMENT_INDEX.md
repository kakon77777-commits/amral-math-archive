# FORMAL STATEMENT INDEX

## Core Definitions

1. MH3-GFEC instance
2. Subject-domain specification
3. Functional question algebra
4. FLDTR word / route language
5. Candidate state machine
6. Positive / negative certificate
7. Dynamic research state
8. Closure depth / complexity profile

## Core Propositions

1. Monotone closure under sound library extension
2. Functional-domain refinement anti-monotonicity
3. Search openness does not automatically enlarge legal semantics
4. Finite route failure is not a universal negative proof
5. Quantifier-compressing certificates can represent infinite behavior
6. Certificate expansion and functional expansion have opposite monotonic effects

## Core Conjectures

1. GFEC-1 Pointwise Finite Closure
2. GFEC-2 Uniform Finite Basis
3. GFEC-3 Effective Closure
4. GFEC-4 Constructive Positive Closure
5. GFEC-5 Finite Negative Obstruction Completeness
6. DGFEC stage-wise catch-up
7. Candidate Progress Conjecture

## Primary falsification target

$$
\boxed{
\exists O^\star:
d_{\mathrm{cl}}(O^\star)=\infty.
}
$$

找到一個 well-defined instance 滿足此式，即可直接否定對應 domain 的 GFEC-1。
