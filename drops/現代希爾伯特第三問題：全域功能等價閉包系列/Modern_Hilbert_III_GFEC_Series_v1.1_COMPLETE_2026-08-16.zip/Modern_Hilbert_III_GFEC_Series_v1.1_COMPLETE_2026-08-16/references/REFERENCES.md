# 參考文獻與鄰接理論定位

本系列提出新的研究問題框架；以下工作提供鄰接工具，但**不等同於**本系列的全域功能等價閉包問題。

## Hilbert III、cut-and-paste 與高階 scissors congruence

1. Zakharevich, I. *Scissors Congruence as K-theory*. arXiv:1101.3833.
2. Malkiewich, C. *On higher scissors congruence*. arXiv:2210.08082.
3. Bohmann, A. M. et al. *A trace map on higher scissors congruence groups*. arXiv:2303.08172.
4. Merling, M. et al. *Scissors congruence K-theory for equivariant manifolds*. arXiv:2501.06928.

## Bisimulation / behavioral equivalence

5. Tabuada, P. *Controller synthesis for bisimulation equivalence*. arXiv:0706.0929.
6. Tavassoli, B. *A Computational Approach to Bisimulation of Hybrid Dynamical Systems*. arXiv:1409.0206.
7. Schmuck, A.-K., Raisch, J. *Simulation and Bisimulation over Multiple Time Scales in a Behavioral Setting*. arXiv:1402.3484.
8. *Minimization of Dynamical Systems over Monoids*. arXiv:2206.15169.

## Causal abstraction / interventions

9. Rubenstein, P. K. et al. *Causal Consistency of Structural Equation Models*. arXiv:1707.00819.
10. Beckers, S., Halpern, J. Y. *Abstracting Causal Models*. arXiv:1812.03789.
11. Otsuka, J., Saigo, H. *On the Equivalence of Causal Models: A Category-Theoretic Approach*. arXiv:2201.06981.
12. Geiger, A. et al. *Causal Abstraction: A Theoretical Foundation for Mechanistic Interpretability*. arXiv:2301.04709.

## Identifiability

13. *Causal models for dynamical systems*. arXiv:2001.06208.
14. Yang, K. D., Katcoff, A., Uhler, C. *Characterizing and Learning Equivalence Classes of Causal DAGs under Interventions*. arXiv:1802.06310.
15. *Towards Identifiability of Interventional Stochastic Differential Equations*. arXiv:2505.15987.

## Compositional verification / contracts

16. Sharf, M., Besselink, B., Johansson, K. H. *Verifying Compositional Refinement of Assume/Guarantee Contracts using Linear Programming*. arXiv:2103.13743.
17. Shali, B. M. et al. *Series composition of simulation-based assume-guarantee contracts for linear dynamical systems*. arXiv:2209.01844.
18. Martín, O., Verdejo, A., Martí-Oliet, N. *Compositional Verification in Rewriting Logic*. arXiv:2307.16537.

## 定位差異

現有研究分別固定某種等價語義、干預語言、contract 或 cut-and-paste 關係。本系列額外把

$$
\boxed{
\text{方法論開放}
+
\text{有限局部實現}
+
\text{全功能域量詞}
+
\text{候補證書可增生}
+
\text{逐點有限閉包}
}
$$

放到同一個問題中，因此本文將 MH3-GFEC 視為**問題提案／研究計畫**，而非已知定理的換名。


## v1.1 literature-completion note

以下三類文獻對本系列 formal completion 尤其重要：

- Bohmann–Gerhardt–Malkiewich–Merling–Zakharevich, arXiv:2303.08172：higher scissors congruence groups、trace map 與 cut-and-paste $K$-theory 的高階資訊。
- Geiger et al., arXiv:2301.04709；Beckers–Halpern, arXiv:1812.03789：causal abstraction、mechanism transformation 與 intervention-aware cross-level equivalence。
- Sharf–Besselink–Johansson, arXiv:2103.13743：compositional assume/guarantee contract refinement 的 necessary/sufficient verification conditions。

本系列使用它們作為「鄰接工具已成熟」的依據，而不是把 GFEC 猜想歸因於上述文獻。
