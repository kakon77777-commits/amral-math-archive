# CHANGELOG

## v0.1 — 2026-08-16

- Launches the Navier-Stokes Tangent Singular Kernel Rigidity Program.
- Proves a pressure-only complementary recovery no-go at the source-operator level.
- Proves forcing-pairing size alone cannot imply source quotient defect for tangent clean/model sources.
- Defines a quantitative tangent-source parameter and Tangent Reproduction Principle.
- Defines complementary native channels for tangent-source recovery.
- Proves a conditional complementary-channel tangent compiler.
- Proves exact/perturbative adjoint synchronization by Duhamel-Gronwall.
- Defines Adjoint Synchronization Compatibility as the remaining certificate-level theorem.
- Proves positivity of nonlinear Reynolds covariance cannot be imposed on arbitrary sign-changing linearized stress directions.
- Imports the positive-energy anti-kernel theorem for positive covariance directions.
- Compresses singular residual kernels using LEI, model-cone, increment, localization, and harmonic channels.
- Defines the Tangent Residual Singular Kernel (TRSK) normal form.
- Moves the next frontier to the exact quadratic geometry u tensor u versus U tensor U plus R.
