# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Pressure-source visibility is not assumed universal.
- Forcing-pairing size is not identified with source-quotient defect.
- Tangent source coordinates are not themselves declared defects.
- The source-tensor Fourier no-go is not promoted to an exact quadratic u tensor u realization theorem.
- Positive Reynolds covariance applies to actual coarse-grained packages, not arbitrary sign-changing linearized differences.
- Adjoint equation synchronization is separated from causal certificate synchronization.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
