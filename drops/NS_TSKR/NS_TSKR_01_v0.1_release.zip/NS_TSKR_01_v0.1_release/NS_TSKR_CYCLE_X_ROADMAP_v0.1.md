---
title: "Navier–Stokes Tangent Singular Kernel Rigidity Program：Cycle-X Roadmap"
version: "v0.1"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-TSKR Cycle-X Roadmap v0.1

## Starting point

IDRP Cycle IX reduced the surviving impulsive obstruction to:

$$
\boxed{
\textbf{TSIP}
}
$$

with:

$$
TANG
\vee
ADJ
\vee
SKER
\vee
AMP.
$$

TSKR attacks tangent source geometry and sign-changing residual kernels directly.

## TSKR-01 — Tangent Source / Singular Kernel Foundation

### Pressure-only no-go

There exist source tensors:

$$
F
$$

with:

$$
R_iR_jF_{ij}=0
$$

but:

$$
-\mathbb P\nabla\cdot F\neq0.
$$

Thus pressure alone does not recover every forcing-relevant source direction.

### Forcing-pairing no-go

A source inside the clean/model source subspace may have nonzero forcing pairing.

Therefore forcing-pairing size alone does not imply source quotient distance.

### Tangent source branch

Define:

$$
\tau_{\rm src}
=
\frac{
\|F^{act}-F^{mod}\|
}{
\|F^{act}\|+\varepsilon
}.
$$

TANG:

$$
\tau_{\rm src}\to0.
$$

Tangent sources must be tested through complementary native channels rather than source quotient distance.

### Complementary-channel compiler

If package distance is dominated by:

- source quotient;
- velocity/source reproduction;
- flux;
- energy;
- trace;
- model-cone;
- increment;
- LEI slack;
- localization/harmonic residuals,

then a native-separated tangent package has a fixed complementary-channel lower bound.

### Adjoint synchronization

For common terminal data:

$$
-\phi_C'=L_C^\ast\phi_C,
$$

$$
-\phi_A'=L_A^\ast\phi_A,
$$

one has:

$$
\boxed{
\|\phi_C-\phi_A\|_\infty
\lesssim
e^{M|I|}
\|\zeta\|
\int_I
\|L_C-L_A\|.
}
$$

Exact common generator gives exact dual synchronization.

The remaining problem is ASC: preserving the causal certificate under the synchronized PFET adjoint.

### Positive covariance

Actual Reynolds covariance satisfies:

$$
R\ge0.
$$

But general linearized stress directions:

$$
\dot R
$$

may be sign-changing.

Hence positive-covariance anti-kernel results do not classify arbitrary residual linearized kernels.

### Residual kernel

After positive-energy, LEI, model-cone, and increment reductions, the surviving residual is supported in:

- sign-changing stress;
- localization;
- harmonic pressure leakage;
- reproduction/transition residuals;
- other directions outside the represented positive/mechanism cones.

Define:

$$
\boxed{
\textbf{TRSK}
}
$$

— Tangent Residual Singular Kernel.

## TSKR-02

Quadratic Source Tangency / Velocity Reproduction Rigidity / Flux-Energy Response / Sign-Indefinite Stress Directions / Tangent Fixed-Point Classification.

Targets:

1. use:
   $$
   u\otimes u
   $$
   structure rather than arbitrary source tensors;
2. classify:
   $$
   u\otimes u\approx U\otimes U+R;
   $$
3. derive velocity reproduction from source tangency or identify equality failures;
4. extract flux/energy response from tangent source dynamics;
5. classify sign-indefinite tangent covariance directions;
6. connect TRSK to renormalized fixed/reproduction orbits;
7. seek a physical amplitude tax.

## Current obligations

$$
\boxed{
TANG\mbox{-}REC
}
$$

tangent source to complementary dynamics;

$$
\boxed{
ASC
}
$$

adjoint synchronization compatibility;

$$
\boxed{
SKER\mbox{-}RIG
}
$$

residual sign-changing kernel rigidity;

$$
\boxed{
AMP
}
$$

physical amplitude tax.

## Hard rules

- Pressure-only source visibility is not universal.
- Source tangency is not itself a defect.
- The source-tensor Fourier no-go is not an exact u tensor u realization theorem.
- Positive Reynolds covariance of nonlinear packages does not imply positivity of arbitrary linearized differences.
- Adjoint synchronization of equations does not automatically preserve a causal source certificate.
- Residual rigidity and physical amplitude packing remain separate.
- No Navier-Stokes regularity claim is made.
