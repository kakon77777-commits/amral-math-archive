# CHANGELOG

## v0.1 — 2026-08-16

- Closes Cycle X as a tangent/residual-kernel rigidity cycle.
- Linearizes the exact tangent constraint at a reproduced nonzero zero-covariance base.
- Proves energy-invisible two-sided mismatch stress has a rank-two hyperbolic spectrum.
- Adds flux invisibility and compresses the generic three-dimensional mismatch fiber to w parallel u cross S u.
- Distinguishes generic and degenerate hyperbolic fibers.
- Proves zero-base quadratic degeneracy is recoverable by second-order blow-up under a natural covariance scaling.
- Routes second-order positive covariance back to rank-one attenuation rigidity.
- Proves fixed interior harmonic-pressure drive forces an explicit outer harmonic-pressure oscillation.
- Routes HPR to the harmonic-tail/localization ledger.
- Proves reproduced state controls equation-level adjoint generator mismatch on smooth reduced classes.
- Compresses ASC to certificate anchoring after generator synchronization.
- Separates normalized residual direction rigidity from physical amplitude Critical Lift.
- Defines the Two-Sided Residual Phantom (TSRP).
- Launches the Navier-Stokes Residual Kernel and Amplitude Program.
