# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Two-sided sign-changing mismatch stress is kept distinct from actual positive Reynolds covariance.
- Hyperbolic fiber reduction is not promoted to universal NS-realizability or exclusion.
- Zero-base degeneracy is reprofiled only when a genuine second-order profile exists.
- Spatially harmonic pressure remains a physical local component; fixed interior drive is routed to a harmonic-tail norm rather than gauged away.
- Equation-level adjoint synchronization is separated from causal certificate anchoring.
- Kernel normalization does not remove physical residual amplitude from depletion.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
