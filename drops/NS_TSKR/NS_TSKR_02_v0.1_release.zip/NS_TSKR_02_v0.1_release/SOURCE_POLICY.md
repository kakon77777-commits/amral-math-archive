# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Canonical coarse source identity is exact; source tangency is not identified with small Reynolds covariance.
- Flux zero is not treated as covariance zero.
- Quadratic source equality is not treated as velocity equality without sign/trace/reproduction control.
- Positive energy covariance rigidity is used only on the positive NS-realizable cone and under its stated energy-separation hypotheses.
- Whole-space/periodic coarse-graining fixed-point rigidity is not promoted to a localized finite-window theorem.
- The L2 spectral-gap theorem is not silently upgraded to all suitable-weak source topologies.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
