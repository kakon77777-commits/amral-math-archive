# CHANGELOG

## v0.1 — 2026-08-16

- Replaces arbitrary source-tensor analysis by the actual rank-one quadratic source geometry.
- Distinguishes sharp active covariance mismatch from the exact canonical coarse-grained source identity.
- Proves exact tangent positive covariance forces a scalar attenuation fiber U=theta u.
- Proves approximate tangency forces approximate velocity-line alignment.
- Derives the exact flux formula on the attenuation fiber.
- Proves flux invisibility alone cannot eliminate positive covariance.
- Proves canonical covariance trace equals local velocity variance.
- Proves zero canonical covariance gives exact local velocity reproduction.
- Combines external positive-energy separation with tangent rigidity to collapse positive canonical tangent branches to reproduction.
- Isolates the pointwise sign fiber of the outer-product map and proves continuous connected sign rigidity.
- Proves exact whole-space quadratic coarse-graining fixed points vanish in Lp.
- Classifies periodic exact quadratic fixed points.
- Proves an L2 high-frequency spectral gap for approximate coarse-graining tangency.
- Compresses TRSK to localized low-frequency/harmonic, nodal sign, sign-changing linearized, adjoint, and amplitude branches.
