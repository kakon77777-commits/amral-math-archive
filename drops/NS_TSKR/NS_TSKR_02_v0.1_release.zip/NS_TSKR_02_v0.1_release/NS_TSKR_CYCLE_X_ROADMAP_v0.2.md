---
title: "Navier–Stokes Tangent Singular Kernel Rigidity Program：Cycle-X Roadmap"
version: "v0.2"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-TSKR Cycle-X Roadmap v0.2

## TSKR-01

Established:
- pressure-only complementary recovery no-go;
- forcing-pairing-only source-defect no-go;
- complementary-channel tangent compiler;
- adjoint synchronization stability;
- positive-cone versus sign-changing tangent distinction;
- TRSK normal form.

## TSKR-02 — Quadratic Source Tangency

### Sharp mismatch

$$
F^{act}
=
\eta u\otimes u,
$$

$$
F^{mod}
=
\eta(U\otimes U+R),
$$

$$
C^0
=
\eta(u\otimes u-U\otimes U-R).
$$

### Canonical coarse-graining

$$
U=S_\ell u,
$$

$$
R=S_\ell(u\otimes u)-U\otimes U\ge0,
$$

$$
U\otimes U+R=S_\ell(u\otimes u).
$$

Canonical source tangency is:

$$
u\otimes u\approx S_\ell(u\otimes u).
$$

### Rank-one rigidity

$$
u\otimes u=U\otimes U+R,\quad R\ge0
$$

implies:

$$
\boxed{
U=\theta u,
\quad
|\theta|\le1,
\quad
R=(1-\theta^2)u\otimes u.
}
$$

Approximate tangency gives approximate parallelism.

### Flux

With incompressibility:

$$
u\cdot\nabla\theta=0,
$$

and:

$$
\boxed{
\Pi
=
-(1-\theta^2)\theta
u\cdot\nabla(|u|^2/2).
}
$$

Flux zero does not force covariance zero.

### Variance/energy

$$
\boxed{
\operatorname{tr}R
=
S_\ell(|u|^2)-|U|^2
=
S_\ell|u-U|^2.
}
$$

Thus:

$$
R=0
\Longrightarrow
u=U
$$

on the averaging support.

External positive energy sees nonzero positive covariance trace.

### Sign fiber

$$
u\otimes u=U\otimes U
\Longrightarrow
U=\pm u.
$$

Divergence-free alone does not fix the sign.

Continuity on a connected nonvanishing set makes the sign constant.

Canonical zero covariance removes the ambiguity.

### Fixed point

$$
u\otimes u=S_\ell(u\otimes u).
$$

Whole-space finite-$L^p$ exact fixed point:

$$
u=0.
$$

Periodic exact fixed point:

$$
u\otimes u
$$

constant.

Smooth connected zero-mean periodic velocity:

$$
u=0.
$$

### Spectral gap

$$
\boxed{
\|P_{\ge\kappa/\ell}f\|_2
\le
C_\kappa
\|f-S_\ell f\|_2.
}
$$

Approximate tangent quadratic source is low-frequency dominated.

## Remaining normal forms

- localized low-frequency tangent fixed point;
- harmonic/localization leakage;
- nodal/sign reproduction fiber;
- sign-changing linearized stress kernel;
- ASC failure;
- physical amplitude summability.

## TSKR-03

Localized Quadratic Fixed Points / Nodal Sign Rigidity / Low-Frequency-Harmonic Tangency / Linearized Stress Kernels / Residual Fixed-Orbit Classification.

## Hard rules

- Canonical coarse source identity is exact; source tangency is not small Reynolds covariance.
- Flux zero does not imply covariance zero.
- Quadratic source equality alone determines velocity only up to sign.
- Positive energy rigidity applies only on the positive NS-realizable covariance cone.
- Whole-space/periodic fixed-point rigidity is not automatically localized.
- L2 spectral rigidity is not silently upgraded to every suitable-weak source topology.
- No Navier-Stokes regularity claim is made.
