# CHANGELOG

## v0.1 — 2026-08-16

- Localizes the quadratic coarse-graining fixed-point problem with an exact cutoff commutator identity.
- Proves a quantitative cutoff-commutator bound and localized high-frequency tangency rigidity.
- Proves global fixed-point rigidity cannot be naively localized because harmonic tensors are local fixed points for radial averaging.
- Classifies positive rank-one componentwise harmonic tensor fields as a fixed direction times one positive harmonic scalar.
- Converts harmonic quadratic velocity realizations to fixed-direction divergence-free shear geometry.
- Proves persistent exact harmonic quadratic tangency on clean projected NS/heat dynamics is spatially constant.
- Retains harmonic pressure and localization as the true escape for nontrivial local harmonic recurrence.
- Proves analytic nodal sign rigidity and isolates zero-base/nodal degeneracy.
- Proves intrinsic normalization preserves actual Reynolds covariance positivity.
- Proves relative covariance-energy invisibility kills actual covariance in the normalized residual.
- Linearizes exact tangent geometry at U=u,R=0 and proves one-sided PSD tangent directions are again attenuation directions.
- Proves first-order covariance-energy invisibility forces exact first-order velocity reproduction.
- Distinguishes actual covariance from two-sided sign-changing mismatch stress.
- Compresses TRSK to LHF/HPR/ZQD/TSM/ASC/AMP classes.
