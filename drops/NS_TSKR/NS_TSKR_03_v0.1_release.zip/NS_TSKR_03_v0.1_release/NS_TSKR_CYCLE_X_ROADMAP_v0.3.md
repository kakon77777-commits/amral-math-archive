---
title: "Navier–Stokes Tangent Singular Kernel Rigidity Program：Cycle-X Roadmap"
version: "v0.3"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-TSKR Cycle-X Roadmap v0.3

## TSKR-01

Reduced TSIP to tangent source geometry, adjoint compatibility, sign-changing residual kernels, and amplitude.

## TSKR-02

Used actual quadratic source geometry:

$$
u\otimes u
=
U\otimes U+R,
\qquad
R\ge0.
$$

Established rank-one attenuation rigidity, covariance variance/reproduction identity, flux-only no-go, sign-fiber classification, whole-space/periodic fixed-point rigidity, and high-frequency tangency control.

## TSKR-03 — Localized Fixed Points / One-Sided Kernel Rigidity

### Localized spectral gap

For:

$$
f=u\otimes u,
$$

and cutoff:

$$
\chi,
$$

$$
\boxed{
\chi f-S_\ell(\chi f)
=
\chi(f-S_\ell f)
+
[\chi,S_\ell]f.
}
$$

The cutoff commutator satisfies:

$$
\boxed{
\|[\chi,S_\ell]f\|_2
\lesssim
\ell
\|\nabla\chi\|_\infty
\|f\|_2.
}
$$

Hence:

$$
\boxed{
\|P_{\ge\kappa/\ell}(\chi f)\|_2
\lesssim_\kappa
\|\chi(f-S_\ell f)\|_2
+
\ell\|\nabla\chi\|_\infty\|f\|_2.
}
$$

Localized tangent source is low-frequency or pays localization.

### Harmonic local fixed-point branch

For radial averaging, componentwise harmonic tensors are exact local fixed points.

Thus global fixed-point rigidity cannot be naively localized.

### Rank-one harmonic rigidity

If:

$$
F\ge0,
\quad
\operatorname{rank}F\le1,
$$

and every component is harmonic on a connected region, then:

$$
\boxed{
F=h\,v\otimes v
}
$$

with constant:

$$
v
$$

and positive harmonic:

$$
h.
$$

A continuous velocity realization is:

$$
u=\sigma\sqrt h\,v.
$$

Incompressibility gives:

$$
v\cdot\nabla h=0.
$$

### Dynamic harmonic rigidity

On clean whole-space/periodic projected Navier--Stokes dynamics, fixed-direction shear has zero convection and evolves by heat.

If:

$$
u\otimes u
$$

remains harmonic through a time interval, then:

$$
\boxed{
u
\text{ is spatially constant}.
}
$$

Finite-energy whole-space or zero-mean periodic branches are trivial.

Nontrivial recurrent harmonic tangent requires harmonic-pressure/localization support.

### Analytic nodal sign rigidity

For analytic:

$$
u,U,
$$

on a connected region:

$$
u\otimes u=U\otimes U
$$

and:

$$
u\not\equiv0
$$

imply one global:

$$
U=\pm u.
$$

One trace anchor fixes:

$$
U=u.
$$

The unresolved sign fiber is concentrated near zero-base/nodal or nonanalytic limit sectors.

### Actual covariance cannot become sign-changing residual

If:

$$
R_n\ge0,
$$

then intrinsic normalization preserves PSD cone closure.

Moreover:

$$
\|R_n\|_F
\le
\operatorname{tr}R_n.
$$

Thus relative covariance-energy invisibility:

$$
\rho_n^{-1}
\int\operatorname{tr}R_n\to0
$$

implies:

$$
\boxed{
\rho_n^{-1}\|R_n\|_{L^1}\to0.
}
$$

Actual covariance disappears from the normalized residual.

### One-sided tangent at reproduced base

At:

$$
U=u,
\quad
R=0,
$$

first-order exact tangency gives:

$$
\dot R
=
u\otimes w+w\otimes u,
\qquad
w=\dot u-\dot U.
$$

If:

$$
\dot R\ge0,
$$

then:

$$
\boxed{
w=\alpha u,
\quad
\alpha\ge0.
}
$$

First-order energy invisibility gives:

$$
\boxed{
\alpha=0,
\quad
\dot u=\dot U,
\quad
\dot R=0.
}
$$

Therefore sign-changing stress can only survive as a two-sided mismatch/quotient residual, not an actual one-sided covariance tangent at zero covariance.

## Remaining classes

$$
\boxed{
\mathrm{LHF}
\vee
\mathrm{HPR}
\vee
\mathrm{ZQD}
\vee
\mathrm{TSM}
\vee
\mathrm{ASC}
\vee
\mathrm{AMP}.
}
$$

Where:

- LHF = localized low-frequency/harmonic fixed point;
- HPR = harmonic-pressure/localization support;
- ZQD = zero-base quadratic degeneracy;
- TSM = two-sided mismatch stress;
- ASC = adjoint synchronization compatibility failure;
- AMP = physical amplitude summability.

## TSKR-04

Two-Sided Mismatch Stress / Zero-Base Degeneracy / Harmonic-Pressure Leakage / Adjoint Compatibility / Amplitude Tax / Cycle-X Closure Audit.

## Hard rules

- Local fixed-point rigidity is not global fixed-point rigidity.
- Harmonic functions give real local fixed points for radial averaging.
- Harmonic tangent recurrence is trivial only on the clean projected branch; harmonic pressure/localization remains physical.
- Analytic sign rigidity is not applied to singular/nonanalytic limit packages without justification.
- Actual covariance and two-sided mismatch stress are distinct objects.
- Positivity of one-sided covariance tangents at R=0 is preserved.
- No Navier-Stokes regularity claim is made.
