# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Local fixed-point rigidity is kept distinct from global fixed-point rigidity.
- Harmonic local fixed points are stated only for radial spatial averaging and interior supports.
- Spatially harmonic pressure is retained as a physical local residual, not gauged away.
- Analytic sign rigidity is branch-specific and not imported into singular limit packages without analytic control.
- Actual positive Reynolds covariance is distinguished from two-sided sign-changing mismatch stress.
- One-sided PSD tangent conclusions are used only at the covariance-cone vertex.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
