---
title: "Navier–Stokes Causal Forest Obstruction Program：Cycle-V Roadmap"
version: "v0.2"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-CFOP Cycle-V Roadmap v0.2

## CFOP-01 — Causal Cutsets

Established:

$$
P_T+S_T\ge1,
$$

ensemble cut capacity,

Action--Congestion Duality,

source multiplicity/entropy,

and conditional disjoint-cut action accumulation.

## CFOP-02 — Spatial--Scale Forest Capacity

### Geometric capacity

For a state tight in:

- shell band width:
  $$
  W;
  $$
- footprint radius:
  $$
  R;
  $$
- frequency span:
  $$
  \Xi=2^JR,
  $$

the number of wavelength-scale cells is bounded by:

$$
\boxed{
\operatorname{Cap}_{ss}
\lesssim
W(1+A\Xi)^3.
}
$$

Therefore a strong space--scale atom exists with share:

$$
\boxed{
p_{\max}
\gtrsim
\frac{
1-\varepsilon
}{
W(1+A\Xi)^3
}.
}
$$

No strong atom implies:

$$
\boxed{
\text{shell-span growth}
\vee
\text{spatial-span growth}
\vee
\text{state-tail escape}.
}
$$

### Multiplicity/entropy ceiling

Inside a finite capacity region:

$$
\mathfrak M_{ss}
\le
\operatorname{Cap}_{ss},
$$

$$
\mathfrak H_{ss}
\le
\log\operatorname{Cap}_{ss}.
$$

### Sparseness guard

If intense super-level sets satisfy an established local one-dimensional sparseness criterion at the analyticity scale:

$$
\boxed{
G_{\rm SPARSE}
\Longrightarrow
\text{regularizing branch}.
}
$$

High cell multiplicity alone does not imply this guard.

### Universal finite state budget

Wavelength-cell occupation satisfies:

$$
\boxed{
\nu
\int_0^{T_\ast}
\sum_{k,a}
\mathcal E_{k,a}(t)dt
\lesssim
\|u_0\|_2^2.
}
$$

### State--Congestion Duality

For propagated forest cuts:

$$
\boxed{
\overline P^2
\le
\mathfrak O_{ss}
\mathfrak C_{ss}^2.
}
$$

Thus low-congestion propagated-dominant cut times consume finite enstrophy-time capacity.

### Spatial--Scale Action--Congestion Duality

For source-dominated cuts:

$$
\boxed{
\mathfrak A_{F,ss}
\mathfrak K_{C,ss}
\ge
\sigma^2.
}
$$

Define effective dual capacity:

$$
\mathfrak N_{ss}^{dual}
=
L_{ss}^2/
\mathfrak C_{ss}^2.
$$

If:

$$
L_{ss}\le L_0,
\qquad
\mathfrak N_{ss}^{dual}\ge N_0,
$$

then:

$$
\boxed{
\mathfrak A_{F,ss}(I)
\ge
\frac{
\sigma^2N_0
}{
L_0^2|I|
}.
}
$$

Thus more diffuse causal capacity raises source-action cost.

### Current forest accounting

Every dangerous cut is in at least one of:

- propagated / enstrophy-cost;
- propagated / congestion;
- source / forcing-action;
- source / congestion;
- strong space--scale atom;
- capacity growth;
- state-tail escape;
- external sparse-regularizing branch.

### Remaining residual

$$
\boxed{
R_{F\mbox{-}ACT}
\vee
R_{F\mbox{-}CONG}
\vee
R_{F\mbox{-}CAP}
\vee
R_{F\mbox{-}TAIL}
\vee
R_{F\mbox{-}NSPARSE}.
}
$$

## CFOP-03 — Finite Forest Obstruction / Cycle-V Audit

Targets:

1. seek finite standard-PDE budgets for source action;
2. convert unbounded congestion to energy/multiplicity debt;
3. combine capacity growth with geometric sparseness criteria;
4. handle state-tail escape;
5. decide whether a finite universal Forest Obstruction exists.

## Hard rules

- Spatial atomization is not spectral atomization.
- Weight tightness is not state tightness.
- High multiplicity does not automatically imply the external sparseness criterion.
- Propagated-state cuts and source cuts use different PDE budgets.
- Finite enstrophy-time is universal; finite nonlinear forcing action is not currently known.
- No Navier-Stokes regularity claim is made.
