# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Spatial atomization is not treated as spectral atomization.
- Weight tightness is not treated as weighted-state tightness.
- High spatial multiplicity is not treated as proof of a geometric sparseness criterion.
- The enstrophy-time budget is finite; the nonlinear shell-forcing action is not assumed finite.
- External flux/sparseness papers are calibration unless explicitly marked as an external guard.
- No complete Forest Obstruction or Navier-Stokes regularity claim is made.
