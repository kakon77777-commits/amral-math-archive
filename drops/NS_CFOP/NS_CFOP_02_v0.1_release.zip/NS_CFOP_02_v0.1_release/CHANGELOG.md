# CHANGELOG

## v0.1 — 2026-08-15

- Defines wavelength-cell and space-scale geometric forest capacity.
- Proves bounded shell width, scale span, and state-tail produce a quantitative strong space-scale atom.
- Defines effective space-scale multiplicity and entropy and proves capacity ceilings.
- Explicitly separates spatial atomization from spectral atomization.
- Adds an external SPARSE-GUARD interface using established geometric regularity criteria.
- Defines global wavelength-cell enstrophy occupation and proves its finite Leray budget.
- Localizes dual forest congestion to wavelength cells.
- Proves State-Congestion Duality for propagated cuts.
- Proves a finite time-capacity bound for low-congestion propagated-dominant cuts.
- Proves Spatial-Scale Action-Congestion Duality for source-dominated cuts.
- Defines effective dual space-scale capacity and proves diffuse-capacity action rigidity.
- Splits capacity growth into shell-span and spatial-span branches.
- Organizes the remaining forest residual into action, congestion, capacity, tail, and non-sparse geometry classes.
