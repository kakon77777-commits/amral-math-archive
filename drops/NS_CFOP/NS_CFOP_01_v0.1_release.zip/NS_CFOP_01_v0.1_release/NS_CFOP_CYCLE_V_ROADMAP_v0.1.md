---
title: "Navier–Stokes Causal Forest Obstruction Program：Cycle-V Roadmap"
version: "v0.1"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-CFOP Cycle-V Roadmap v0.1

## Starting point

ANP Cycle IV established:

$$
\boxed{
CN_{\rm Forest}
:
\mathrm{PROVED},
}
$$

while:

$$
\boxed{
CN3_{\rm Atomic}
:
\mathrm{OPEN}.
}
$$

Therefore Cycle V formulates obstruction directly on the actual horizon causal forest.

## CFOP-01 — Diffuse Horizon Causality / Forest Cutsets

### Physical causal cut

For terminal:

$$
T
$$

and:

$$
\tau<t_T,
$$

define:

$$
P_T(\tau)
=
[\mathcal I_T(\tau)]_+/A_T,
$$

and:

$$
S_T(\tau)
=
A_T^{-1}
\int_\tau^{t_T}
|
\langle
F_{k_T},
\Phi_T
\rangle
|dt.
$$

Then:

$$
\boxed{
P_T+S_T\ge1.
}
$$

### Ensemble cut

For terminal weights:

$$
\sum w_r=1,
$$

$$
\boxed{
\overline P+\overline S\ge1.
}
$$

If:

$$
\overline P\le1-\sigma,
$$

then:

$$
\overline S\ge\sigma.
$$

### Action--Congestion Duality

Define shell forcing action:

$$
\mathfrak A_F
=
\int
\sum_k
\|F_k\|_2^2dt,
$$

and forest dual congestion:

$$
\mathfrak K_C
=
\int
\sum_k
\left(
\sum_{r:k_r=k}
w_r
\|\Phi_r/A_r\|_2
\right)^2dt.
$$

Then:

$$
\boxed{
\mathfrak A_F
\mathfrak K_C
\ge
\sigma^2.
}
$$

### Source atomization

For fresh-source positive carrier shares:

$$
r_\alpha,
$$

effective multiplicity:

$$
\mathfrak M^{src}
=
(\sum r_\alpha^2)^{-1},
$$

and entropy:

$$
\mathfrak H^{src}
=
-\sum r_\alpha\log r_\alpha.
$$

If strongest child-normalized source atom has share:

$$
\eta_{\max},
$$

and net fresh source fraction is at least:

$$
\sigma,
$$

then:

$$
\boxed{
\mathfrak M^{src}
\ge
\sigma/\eta_{\max},
}
$$

$$
\boxed{
\mathfrak H^{src}
\ge
\log(\sigma/\eta_{\max}).
}
$$

### Disjoint cutsets

If pairwise disjoint cut slabs all have:

- fresh source deficiency:
  $$
  \sigma;
  $$
- dual congestion:
  $$
  \le K_0;
  $$

then forcing action accumulates at least:

$$
\boxed{
N\sigma^2/K_0.
}
$$

This gives a conditional forest obstruction under a finite global forcing-action budget.

### Current forest trichotomy

Every dangerous cut is forced into:

$$
\boxed{
\text{PROPAGATED-CUT}
\vee
\text{ACTION-CUT}
\vee
\text{CONGESTED-CUT}.
}
$$

Diffuse fresh-source cuts additionally pay multiplicity/entropy if no strong atom survives.

## CFOP-02 — Spatial--Scale Atomization / Forest Capacity

Targets:

1. wavelength-cell spatial multiplicity;
2. source entropy plus spatial packing;
3. scale/profile fragmentation capacity;
4. interface with:
   $$
   D_{\rm eig};
   $$
5. driver/dissipation cutsets;
6. finite forest-capacity bounds.

## CFOP-03 — Forest Obstruction Closure

Targets:

1. define finite forest obstruction;
2. audit whether existing standard PDE budgets can bound every cut functional;
3. distinguish conditional forest obstruction from actual regularity proof;
4. determine whether diffuse causal forests can be excluded.

## Hard rules

- A causal cut capacity is not a probability flow.
- Forest obstruction must survive branching/merging and need not select one atomic lineage.
- Source action and dual congestion are distinct costs.
- Source entropy is an atomization diagnostic, not a contradiction.
- Finite forcing-action budgets are not assumed unless independently proved.
- No Navier--Stokes regularity claim is made.
