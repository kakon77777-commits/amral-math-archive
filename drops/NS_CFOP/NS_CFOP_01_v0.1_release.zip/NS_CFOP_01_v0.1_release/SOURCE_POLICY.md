# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Causal cut capacity is not a probability flow.
- Fresh-source action is not assumed globally finite near a hypothetical singularity.
- Entropy/multiplicity growth is a forest-fragmentation diagnostic, not a contradiction.
- External energy-flux and forced-flow papers are calibration only unless explicitly marked otherwise.
- No complete Forest Obstruction or Navier-Stokes regularity claim is made.
