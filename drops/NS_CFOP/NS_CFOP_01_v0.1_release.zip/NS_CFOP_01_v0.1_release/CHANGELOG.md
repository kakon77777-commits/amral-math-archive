# CHANGELOG

## v0.1 — 2026-08-15

- Launches the Navier-Stokes Causal Forest Obstruction Program.
- Replaces path-only obstruction by physical-time causal cutset accounting.
- Proves every dangerous terminal cut has normalized causal capacity at least one.
- Extends causal cut capacity to weighted terminal ensembles.
- Defines forest dual-witness congestion.
- Proves the Action-Congestion Duality inequality A_F K_C >= sigma^2.
- Introduces source effective multiplicity and branching entropy.
- Proves strongest-source-share collapse forces multiplicity and entropy growth.
- Proves pairwise disjoint source-dominated low-congestion cuts force linearly accumulating shell-forcing action.
- States a conditional forest obstruction under finite total forcing action.
- Defines propagated, action, and congested cut classes.
- Distinguishes Path Obstruction, Forest Obstruction, and Finite Forest Obstruction.
- Moves the next frontier to spatial/scale atomization and forest capacity.
