# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Universal weak forcing budgets are not promoted to scale-critical obstruction budgets.
- Partial regularity is not promoted to full forest-capacity control.
- Conditional sparseness criteria are not applied when their hypotheses are absent.
- Scaling compatibility calculations are not singular-solution constructions.
- No Finite Forest Obstruction or Navier-Stokes regularity claim is made.
