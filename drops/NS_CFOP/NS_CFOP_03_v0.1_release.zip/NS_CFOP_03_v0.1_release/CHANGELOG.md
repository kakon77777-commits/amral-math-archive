# CHANGELOG

## v0.1 — 2026-08-15

- Audits every remaining CFOP forest residual against universal Navier-Stokes a priori budgets.
- Proves the velocity nonlinearity is universally bounded in L_t^{4/3}H_x^{-1} by the energy class.
- Proves the induced vorticity forcing is universally bounded in L_t^{4/3}H_x^{-2}.
- Replaces strong L2 forcing-action debt by a finite weak-forcing / strong-dual-congestion inequality.
- Proves infinitely many disjoint source-dominated cuts force quartic H2 dual congestion divergence.
- Reclassifies state-tail escape as adaptive spatial-capacity growth.
- Performs a parabolic scaling audit showing enstrophy-time costs O(R) per scale.
- Performs a forcing scaling audit showing H^{-2}, L_t^{4/3} costs O(R^{4/3}) per scale.
- Shows both known universal finite budgets are summable across geometric scales.
- Compresses the final forest residual to high-order dual congestion, capacity growth, and dense/non-sparse geometry.
- Defines the Forest Coercive Budget Problem.
- Closes Cycle V as a budget-audit cycle without claiming Finite Forest Obstruction.
- Launches NS-FCBP.
