# CHANGELOG

## v0.1 — 2026-08-16

- Launches the Navier-Stokes Impulsive Defect Recurrence Program.
- Imports Barker-Prange Type-I critical concentration and derives a full parabolic-thickness L3 horizon packet.
- Defines generic trace persistence-or-variation.
- Applies the trace dichotomy to the localized filtered-enstrophy ledger.
- Proves finite-energy Navier-Stokes velocity has time derivative in L_t^{4/3} H_x^{-1}.
- Defines a dyadic local critical kinetic atom.
- Proves rapid shell-atom disappearance forces quantitative H^-1 temporal action.
- Proves a global packing inequality for pairwise-disjoint spectral impulses.
- Derives the a^2 r^6 energy-class persistence floor.
- Proves generic energy-class temporal regularity is too weak for parabolic r^2 thickening.
- Identifies the balanced impulse scale delta=a^2 and separates normalized critical burst coercivity from physical-scale summability.
- Applies the scaling audit to DCRP logarithmic FAR atoms and retains the filtered-to-spectral transfer gap.
- Defines the Trace Thickening Problem and Burst Visibility Problem.
- Moves the next frontier to source/work/trace visibility of rapid impulse loss.
