# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Barker-Prange Type-I concentration is used only under its branch-specific hypotheses.
- Weak-Lorentz concentration is not silently converted into a strong spacetime L3 packet.
- Filtered-vorticity atoms and dyadic spectral atoms remain distinct without a transfer theorem.
- Filtered total-variation debt is not treated as a globally finite budget.
- Energy-class H^-1 temporal action is not promoted to parabolic trace thickening.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
