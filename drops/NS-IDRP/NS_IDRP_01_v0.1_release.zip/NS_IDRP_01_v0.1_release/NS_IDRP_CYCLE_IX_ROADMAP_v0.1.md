---
title: "Navier–Stokes Impulsive Defect Recurrence Program：Cycle-IX Roadmap"
version: "v0.1"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-IDRP Cycle-IX Roadmap v0.1

## Starting point

DCRP Cycle VIII reduced the surviving obstruction to:

$$
\boxed{
\mathcal K_{\rm IDR}
}
$$

— Impulsive Diffuse Recurrence.

The problem is no longer primarily spatial fragmentation.

It is whether critical carriers can appear and disappear on shrinking temporal windows before any finite budget can see them.

## IDRP-01 — Impulse Persistence / Trace Thickening

### Type-I full-thickness branch

External Barker--Prange concentration gives, under its Type-I hypotheses:

$$
\|u(t)\|_{L^3(B_{C\sqrt{T_*-t}})}
\ge
\gamma.
$$

Thus every late horizon slab:

$$
[T_*-2r^2,T_*-r^2]
$$

carries:

$$
\boxed{
r^{-2}
\iint
|u|^3
\gtrsim1.
}
$$

The strong Type-I critical state is already parabolically thick.

### Generic trace dichotomy

For an absolutely continuous nonnegative trace:

$$
A(t_0)\ge a,
$$

either:

$$
A\ge a/2
$$

through the selected window or total variation is at least:

$$
a/2.
$$

Applied to filtered enstrophy, rapid atom loss forces a fixed mechanism-ledger variation debt.

### Universal temporal action

Energy class gives:

$$
\boxed{
\partial_tu
\in
L_t^{4/3}\dot H_x^{-1}.
}
$$

### Spectral impulse action

For a dyadic scale:

$$
r,
$$

critical local kinetic atom strength:

$$
a,
$$

and disappearance within:

$$
\tau=\delta r^2,
$$

$$
\boxed{
r^{-4/3}
\int_I
\|\partial_tu_k\|_{\dot H^{-1}}^{4/3}
\gtrsim
a^{2/3}\delta^{-1/3}.
}
$$

### Burst packing

Pairwise-disjoint impulses satisfy:

$$
\boxed{
\sum_n
a_n^{2/3}
r_n^{4/3}
\delta_n^{-1/3}
<
\infty.
}
$$

Thus infinitely many atoms cannot all disappear faster than:

$$
\boxed{
\tau_n
\sim
a_n^2r_n^6.
}
$$

### Energy-class no-go

The persistence floor:

$$
a^2r^6
$$

is far below the desired:

$$
r^2.
$$

Generic energy-class temporal regularity therefore does not yield parabolic thickening.

### Balanced impulse scale

At:

$$
\delta=a^2,
$$

rapid disappearance pays order-one normalized temporal action.

Persistence instead gives a critical spacetime packet of size:

$$
a^3.
$$

Physical action still carries the summable:

$$
r^{4/3}
$$

weight.

### FAR logarithmic atom

DCRP logarithmic FAR atoms remain selected-time objects.

Energy action alone upgrades them only to an extremely short:

$$
r^6
[\log(C/r)]^{-4/3}
$$

packing-scale floor.

Filtered-to-spectral transfer is still separate.

## Core obligations

$$
\boxed{
\textbf{TTP}
}
$$

Trace Thickening Problem.

$$
\boxed{
\textbf{BVP}
}
$$

Burst Visibility Problem.

## IDRP-02

Source-Impulse Visibility / Filtered Trace Variation / PFET Burst Coupling / Logarithmic Atom Thickening / Moving-Window Depletion.

Targets:

1. source impulse -> combined detector;
2. filtered atom-loss mechanism decomposition;
3. branch-specific improvement beyond the r^6 energy floor;
4. FAR logarithmic atom persistence;
5. moving-window depletion using burst observability;
6. invisible-burst classification.

## Hard rules

- Type-I concentration is external and branch-specific.
- Weak Lorentz concentration is not silently converted into a strong spacetime L3 packet.
- Filtered FAR atoms are not automatically dyadic spectral atoms.
- Total variation debt is not a globally finite budget without mechanism-specific control.
- Energy-class time action gives only a very subparabolic persistence floor.
- Order-one normalized burst action still carries summable physical scale weights.
- No Navier-Stokes regularity claim is made.
