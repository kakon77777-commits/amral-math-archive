# CHANGELOG

## v0.1 — 2026-08-16

- Decomposes BDR into source transversality, causal/audit dual compatibility, and residual control.
- Proves a native source-quotient lower bound from a transverse causal source dual.
- Compiles source-quotient separation into sharp package BDR when source visibility is built into the package geometry.
- Proves a causal-to-audit dual transfer estimate with explicit mismatch and residual-ledger terms.
- Defines intrinsic residual normalization only after native NS residual realization.
- Proves a compact normalized moving-window operator family with kernel-free cluster limits has a uniform positive observability gap.
- Proves a strong RIB compactifies to a genuine nonzero singular-limit kernel/phantom pair under residual/operator compactness.
- Proves weak relative left-singular failure need not compactify to a true phantom.
- Proves amplitude normalization cannot remove the physical residual factor from an actual depletion law.
- Compresses the remaining IDRP problem to source transversality, dual compatibility, singular-limit kernel rigidity, and physical amplitude packing.
