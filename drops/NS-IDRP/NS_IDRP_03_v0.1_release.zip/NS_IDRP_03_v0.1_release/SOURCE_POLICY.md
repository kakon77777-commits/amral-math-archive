# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-native BDR uses actual NS-generated source/residual coordinates and never inserts the burst amplitude as a detector gate.
- Intrinsic amplitude normalization is allowed only after a native residual has been realized.
- Strong and weak relative invisible failures remain distinct.
- Moving-window operator compactness does not exclude RIB if singular limit operators are present.
- Residual normalization does not remove physical amplitude from depletion.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
