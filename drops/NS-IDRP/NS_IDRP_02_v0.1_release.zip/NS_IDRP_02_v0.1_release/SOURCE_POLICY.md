# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Filtered mechanism visibility is not promoted automatically to PFET visibility.
- Burst-to-Defect Realization is an open non-tautological bridge.
- Large weak source action is not promoted to one signed pressure-flux/energy-work channel.
- Relative residual amplitude may decay; it is not silently renormalized into fixed badness.
- The amplitude-aware depletion law is conditional and distinct from the external normalized moving-window depletion assumption.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
