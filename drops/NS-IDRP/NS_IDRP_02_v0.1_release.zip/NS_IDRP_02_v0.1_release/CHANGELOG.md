# CHANGELOG

## v0.1 — 2026-08-16

- Partially closes the Burst Visibility Problem at the filtered mechanism-ledger layer.
- Proves a filtered trace drop is paid by diffusion, negative near stretching, far field, commutator, or localization.
- Inserts the derivative-compatible commutator estimate and routes unpaid commutator trace loss into the scale-critical increment defect.
- Proves a general dual source-burst amplification theorem and the critical p=4/3 exponent.
- Combines the source theorem with the energy-class weak nonlinear-forcing budget to obtain disjoint source-burst packing.
- Defines the non-tautological Burst-to-Defect Realization problem.
- Proves the conditional BDR-to-PFET visibility compiler using the external combined-observability constant.
- Connects decaying burst residuals to the external relative trace-cost/left-singular alternative.
- Upgrades DCRP logarithmic selected FAR atoms to full-parabolic-window packet-or-mechanism-burst objects.
- Defines an amplitude-aware burst depletion model and proves logarithmic series thresholds.
- Separates the conditional amplitude-aware depletion law from the external normalized extraction/depletion theorem.
- Compresses the surviving temporal obstruction to Relative Invisible Burst / amplitude / observability / realization / residual failures.
- Moves the next paper to relative invisible-burst kernel rigidity and native BDR construction.
