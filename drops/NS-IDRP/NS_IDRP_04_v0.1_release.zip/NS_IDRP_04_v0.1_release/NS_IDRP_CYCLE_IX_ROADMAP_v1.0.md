---
title: "Navier–Stokes Impulsive Defect Recurrence Program：Cycle-IX Roadmap"
version: "v1.0"
date: "2026-08-16"
status: "Cycle-IX closed as a burst-realization/relative-kernel reduction cycle; tangent singular impulsive phantom remains open"
---

# NS-IDRP Cycle-IX Roadmap v1.0

## Completed

1. IDRP-01 — Impulse Persistence / Trace Thickening / Temporal Action Packing
2. IDRP-02 — Burst Visibility / PFET Coupling / Logarithmic Packet-or-Burst
3. IDRP-03 — Relative Invisible Burst / Source-Native BDR / Operator Compactification
4. IDRP-04 — Transversality / Adjoint Synchronization / Singular Kernel / Final Audit

## Cycle-IX main results

### Type-I temporal branch

Strong Type-I critical state concentration is already parabolically thick.

### Generic impulses

Rapid spectral atom loss pays:

$$
L_t^{4/3}\dot H^{-1}
$$

temporal action, but only yields a very subparabolic generic persistence floor.

### Filtered burst visibility

Rapid filtered trace loss is paid by:

- diffusion;
- negative near-field stretching;
- far field;
- critical increment defect;
- localization.

### Source-native BDR

A causal source burst with a fixed source-dual component transverse to the clean/model source subspace yields a native source quotient defect.

### Relative invisible burst

Compact normalized operator families with kernel-free cluster limits have a uniform observability gap.

Strong RIB compactifies to a genuine singular-limit kernel pair.

### Cycle-IX final audit

Pressure alone cannot universally see forcing-relevant source directions.

Forcing pairing alone cannot imply source-quotient distance.

Adjoint mismatch is controlled by generator mismatch.

Positive-covariance/energy limit kernels are removed under the external positive-energy anti-kernel hypotheses.

Weak source action carries a summable:

$$
r^{4/3}
$$

physical scale weight.

## Final surviving normal form

$$
\boxed{
\textbf{TSIP — Tangent Singular Impulsive Phantom}
}
$$

supported through one or more of:

- TANG: clean/model tangent source burst;
- ADJ: causal/PFET adjoint desynchronization;
- SKER: sign-changing/localization/harmonic/residual singular limit kernel;
- AMP: physical amplitude/depletion summability.

## Final status

$$
\boxed{
\text{generic BDR}
:
\mathrm{OPEN/PARTIAL}.
}
$$

$$
\boxed{
\text{Relative Invisible Burst exclusion}
:
\mathrm{OPEN/PARTIAL}.
}
$$

$$
\boxed{
\text{Impulsive Diffuse Recurrence exclusion}
:
\mathrm{OPEN}.
}
$$

$$
\boxed{
\text{Forest Coercive Budget}
:
\mathrm{OPEN}.
}
$$

$$
\boxed{
\text{Navier--Stokes regularity}
:
\mathrm{NOT\ PROVED}.
}
$$

## Next program

$$
\boxed{
\textbf{
NS-TSKR —
Navier--Stokes Tangent Singular Kernel Rigidity Program
}
}
$$

### TSKR-01

Tangent Source Geometry / Complementary Channel Recovery / Sign-Changing Stress Kernels / Adjoint Synchronization Compatibility / Residual Rigidity.

## Hard rules

- Pressure-source visibility is not universal.
- A source burst can be tangent to a clean/model source class.
- Source transversality must be proved or complemented by another native detector.
- Exact synchronized adjoints coincide; generic ANP/PFET synchronization remains a PDE/causal theorem.
- Positive-energy anti-kernel results do not classify sign-changing residual kernels.
- Normalized weak source bursts are physically summable on geometric scales.
- No Navier-Stokes regularity claim is made.
