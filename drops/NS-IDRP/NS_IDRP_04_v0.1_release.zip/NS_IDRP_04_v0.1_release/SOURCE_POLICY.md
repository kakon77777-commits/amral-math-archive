# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Pressure-source visibility is not assumed universal.
- Forcing-pairing size is not identified with source-quotient defect without transversality.
- The pressure-only Fourier no-go is a source-tensor result and is not promoted to an exact quadratic u tensor u realization theorem.
- Exact synchronized backward duals coincide; ANP/PFET synchronization compatibility remains a separate PDE/causal theorem.
- Positive-energy anti-kernel results are not promoted to sign-changing/residual kernel exclusion.
- Weak source-action scale-critical bursts remain physically summable on geometric scales.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
