# CHANGELOG

## v0.1 — 2026-08-16

- Closes Cycle IX as a burst-realization and relative-kernel reduction cycle.
- Proves active pressure alone cannot see every forcing-relevant source-tensor direction.
- Proves forcing-pairing size alone cannot imply native source quotient distance when the source lies in the clean/model subspace.
- Defines the Tangent Burst branch.
- Imports active/model source realization and reproduction geometry from the finite-window sharp package framework.
- Proves a quantitative backward Adjoint Synchronization theorem.
- Recasts DUAL as Adjoint Synchronization Compatibility rather than a semantic dual mismatch.
- Uses the external positive-energy anti-kernel theorem to eliminate positive-covariance/energy directions from stable singular PFE limit kernels.
- Compresses KERN to sign-changing/localization/harmonic/residual sectors.
- Proves the weak nonlinear-source L_t^{4/3} H^-1 action scales like r^{4/3} per parabolic scale.
- Proves fixed normalized weak source bursts on dyadic scales remain physically summable and do not yield Critical Lift.
- Defines the Tangent Singular Impulsive Phantom (TSIP).
- Launches the Navier-Stokes Tangent Singular Kernel Rigidity Program.
