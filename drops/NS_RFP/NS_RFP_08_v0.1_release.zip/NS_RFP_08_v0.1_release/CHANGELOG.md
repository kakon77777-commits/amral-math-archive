# CHANGELOG

## v0.1 — 2026-08-14

- Introduces a field-packet norm probability ledger independent of the current scalar dual sign.
- Defines packet amplification and proves strong future bridges must be packet-strong or pay amplification debt.
- Introduces packet output-depth gross and proves a tail bound.
- Proves direct bridges across deep synchronous plateaus require exponential packet-depth debt unless bridge amplification grows.
- Iterates the macro-edge Duhamel formula into an exact generation-age stock decomposition.
- Introduces source-age positive shares and recent-memory capture.
- Proves an age-tail bridge estimate with viscous-age damping.
- Gives a conditional finite-memory closure theorem and identifies viscous-age congestion / generation-envelope growth as memory-depth escape mechanisms.
- Rewrites fresh-source bypass as a triangular causal time domain.
- Splits fresh contributions into positive-lag and near-diagonal pieces.
- Proves fixed near-diagonal positive mass at vanishing lag forces temporal interaction-envelope divergence.
- Adds an adaptive temporal slice ledger and temporal-resolution escape.
- Defines a packet-complete strong-bridge graph under bounded packet amplification.
- Merges plateau crossing, untracked packet, old-stock and fresh-source bypass into one memory/time/packet enclosure.
- Moves the next frontier to a unified tax ledger.
