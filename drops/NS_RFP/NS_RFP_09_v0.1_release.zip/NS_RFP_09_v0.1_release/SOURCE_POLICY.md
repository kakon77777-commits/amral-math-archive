# SOURCE_POLICY

- Canonical manuscript format: UTF-8 Markdown.
- Canonical mathematics delimiters: `$...$` and `$$...$$` only.
- No `unicode_escape`-style round trip is used.
- No conversion of LaTeX source into Unicode mathematical glyphs is used as canonical source.
- Chat rendering is not the canonical manuscript.
- Source-level validation is recorded in `validation.json`.
- Render-level KaTeX/TeX compilation is not claimed in this release.
- Tax divergence is loss of uniform closure control, not automatically a blow-up mechanism.
- Band-passed far-source control is not raw pressure locality.
- Conditional certificate/path closure is not promoted to Navier-Stokes regularity.
