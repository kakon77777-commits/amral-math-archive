# CHANGELOG

## v0.1 — 2026-08-15

- Introduces a typed nine-coordinate scale-compatible core tax vector.
- Adds canonical strongest-half node classes and an atomization tax.
- Defines the best-predecessor bridge bottleneck tax.
- Proves active predecessor packet strength and finite candidate count.
- Reuses the RFP-04 parent-tail estimate to derive a uniform parent-gap selector.
- Combines bridge, amplification and packet-depth taxes to bound direct plateau gaps.
- Scale-audits the adjoint distortion tax.
- Introduces an interaction-inefficiency tax.
- Proves commutator leakage is a derived tax controlled by adjoint distortion and interaction inefficiency under canonical envelope semantics.
- Proves canonical band-passed far-source leakage is a derived tax controlled by interaction inefficiency and a fixed wavelength buffer.
- Extends memory depth to include initial plus old-generation stock.
- Defines a scale-invariant temporal-resolution tax.
- Proves bounded temporal tax converts nontrivial fresh share into a fixed normalized positive-lag source bridge.
- Proves the tax-to-selector compiler.
- Compresses many previously named escapes into nine core tax boundary faces.
- Proves a conditional bounded-tax certificate/path closure theorem.
- Proves a conditional finite core-tax escape alternative.
- Adds a machine-readable tax ledger schema.
- Moves the next frontier to tax-boundary dynamical classification and finite-obstruction candidates.
