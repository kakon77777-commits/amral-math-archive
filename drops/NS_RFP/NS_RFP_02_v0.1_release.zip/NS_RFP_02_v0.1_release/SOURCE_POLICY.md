# SOURCE_POLICY

- Canonical manuscript: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round-trip is used.
- Chat rendering is not the canonical source.
- Source-level validation is recorded in `validation.json`.
- Render-level KaTeX/TeX compilation is not claimed in this release.
