# CHANGELOG

## v0.1 — 2026-08-14

- Introduces the critical shell burden $\mathcal B_J$.
- Proves critical shell-burden UV necessity.
- Proves a canonical adjacent-scale first-passage skeleton $\tau_J(M)\uparrow T_\ast$.
- Introduces shell-carrier / deep-tail-bypass decomposition.
- Proves nonlinear Duhamel source debt on every non-synchronous first-passage edge.
- Derives coarse LH/HL/HH source-class debt.
- Identifies synchronous bypass, exact parent provenance, and spatial-core attachment as the remaining Chain-Necessity gaps.
- Adds $G_{\rm PARENT}$, $G_{\rm SYNC}$, $G_{\rm STOCK}$, and $G_{\rm SHELL}$.
