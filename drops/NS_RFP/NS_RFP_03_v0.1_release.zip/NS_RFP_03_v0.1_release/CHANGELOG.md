# CHANGELOG

## v0.1 — 2026-08-14

- Introduces the tail Banach space and explicit dual norming witness.
- Derives an exact signed dyadic parent-output ledger.
- Proves parent cancellation and cancellation-adjusted multiplicity debts.
- Proves no-far-up-jump and resonant-downshift Fourier support guards.
- Introduces parent-gap PT/PS/PE and synchronous carrier-depth CT/CS/CE classifications.
- Recasts the remaining parent-resolution problem as uniform tightness, witness persistence, escape control, and spatial-core attachment.
