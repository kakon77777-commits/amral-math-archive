# SOURCE_POLICY

- Canonical manuscript: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round-trip is used.
- No `unicode_escape`-style source transformation is used.
- Chat rendering is not the canonical source.
- Source-level validation is recorded in `validation.json`.
- Render-level KaTeX/TeX compilation is not claimed in this release.
- 2026 preprints listed as contemporary comparisons are not silently promoted to theorem inputs.
