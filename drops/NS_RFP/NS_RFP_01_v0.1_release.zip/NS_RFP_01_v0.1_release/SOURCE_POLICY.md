# SOURCE_POLICY

- Canonical source encoding: UTF-8.
- Canonical math delimiters: `$...$` and `$$...$$` only.
- No Unicode-math round-trip is used as a source transform.
- Rendered chat text is not the canonical manuscript.
- The release Markdown files are the canonical source artifacts.
- Source-level validation is recorded in `validation.json`.
- Render-level TeX/KaTeX validation has not been claimed in this release.
