# CHANGELOG

## v0.1 — 2026-08-14

- Introduces the scale-invariant dissipation-output budget $\mathfrak V_J=\mathfrak E_J\mathfrak O_J$.
- Proves the resonant high-high downshift tail estimate.
- Proves $1-C_J^{par}(L)\le C2^{-L}\mathfrak V_J$.
- Upgrades parent tightness to quantitative uniform tightness whenever $\mathfrak V_J$ is uniformly bounded.
- Proves PS/PE parent escape forces $\mathfrak V_J$ divergence along the classified subsequence.
- Adds output-depth probability and quantitative tail control.
- Upgrades C3-O adjoint cutoffs to an exact nonnegative partition of unity.
- Constructs an exact $(a;k;p,q)$ spacetime soft-tube ledger.
- Proves band-passed Leray pseudolocality and a pressure-compatible commutator estimate.
- Splits every tube contribution exactly into tube-local source plus commutator/leakage tax.
- Adds a conditional spacetime parent attachment certificate.
- Moves the next frontier to witness persistence and infinite path extraction.
