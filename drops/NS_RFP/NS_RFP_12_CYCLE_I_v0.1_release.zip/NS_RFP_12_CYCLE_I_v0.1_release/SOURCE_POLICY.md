# SOURCE_POLICY

- Canonical manuscript format: UTF-8 Markdown.
- Canonical mathematics delimiters: `$...$` and `$$...$$` only.
- No `unicode_escape`-style round trip is used.
- No conversion of LaTeX source into Unicode mathematical glyphs is used as canonical source.
- Chat rendering is not the canonical manuscript.
- Source-level validation is recorded in `validation.json`.
- Render-level KaTeX/TeX compilation is not claimed.
- External theorems are separated from internal deductions.
- Functional-analytic no-go examples are not claimed to be Navier-Stokes solutions.
- Dangerous-core emptiness is not claimed.
- Navier-Stokes regularity is not claimed.
