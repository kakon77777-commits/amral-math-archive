# CHANGELOG

## v0.1 — 2026-08-15

- Closes NS-RFP Cycle I.
- Adds Miller's approximate-Laplacian-eigenfunction criterion to the coercive action set.
- Proves the exact L2 spectral-variance formula for the best approximate eigen-shell residual.
- Proves middle-strain temporal intermittency propagates beyond every fixed Fourier cutoff.
- Proves fixed-frequency L2 activity does not force an L-infinity lower bound without spatial concentration.
- Proves multiple divergent coercive actions need not have synchronized spike sets.
- Identifies the Coercive Synchronization Problem as the central residual theorem gap.
- Defines a four-action dangerous core.
- Recompiles the rigorous Cycle-I content into standard PDE language.
- Separates unconditional PDE results from conditional certificate/graph architecture.
- Produces a Cycle-I handoff and a Cycle-II provisional roadmap.
- Explicitly records that Full Chain Necessity, Finite Obstruction, and Navier-Stokes regularity remain open.
