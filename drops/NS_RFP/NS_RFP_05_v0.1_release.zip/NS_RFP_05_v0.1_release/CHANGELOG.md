# CHANGELOG

## v0.1 — 2026-08-14

- Makes the global quantifier gap explicit: levelwise witness existence is not persistent-path existence.
- Proves exact local-source refinement of the spacetime tube ledger.
- Normalizes positive local-source entries into a witness probability ledger.
- Proves fixed-threshold witness sets have uniformly finite cardinality.
- Introduces witness atomization and proves effective multiplicity divergence.
- Defines exact first-passage time seams and geometric adjoint-tube overlap.
- Proves an effective spatial fan-out bound at fixed overlap threshold.
- Separates stock compatibility from equation-level provenance compatibility.
- Constructs thresholded layered witness graphs.
- Introduces backward survivor recursion.
- Proves finite-horizon survivor equivalence.
- Proves a self-contained finite-branching infinite-path extraction theorem.
- Defines finite stitching obstruction certificates and minimal obstruction horizon.
- Introduces horizon bottleneck and proves the finite obstruction / bottleneck collapse / uniform infinite path trichotomy.
- Adds the completeness guard preventing certificate-class graph failure from being mislabeled as Navier-Stokes dynamical impossibility.
- Moves the PDE frontier to inter-edge bridge realization and bottleneck lower bounds.
