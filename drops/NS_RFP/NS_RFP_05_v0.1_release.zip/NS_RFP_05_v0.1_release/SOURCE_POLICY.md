# SOURCE_POLICY

- Canonical manuscript format: UTF-8 Markdown.
- Canonical mathematics delimiters: `$...$` and `$$...$$` only.
- No `unicode_escape`-style round trip is used.
- No conversion of LaTeX source into Unicode mathematical glyphs is used as canonical source.
- Chat rendering is not the canonical manuscript.
- Source-level validation is recorded in `validation.json`.
- Render-level KaTeX/TeX compilation is not claimed in this release.
- Graph/certificate obstruction is not promoted to Navier-Stokes dynamical obstruction without a proved completeness bridge.
