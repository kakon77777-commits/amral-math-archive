# CHANGELOG

## v0.1 — 2026-08-15

- Introduces a theorem-grounded pathwise coercive action layer above the RFP tax layer.
- Imports and verifies the critical middle-strain-eigenvalue action.
- Proves a new synthesis consequence: for q=2, hypothetical blowup forces middle-strain temporal intermittency, with finite L1 mass but infinite critical L2 action.
- Proves critical middle-strain action remains infinite on arbitrarily thin high-amplitude time sets.
- Introduces macro-edge action increments and proves edge-average action-rate congestion for divergent finite-time actions.
- Imports the Miller strain-vorticity regular-model residual action and pointwise residual threshold.
- Splits the interaction face into regular/depleting versus potentially dangerous model-cone directions.
- Adds an interaction scalarization no-go.
- Imports the Bradshaw-Grujic moving finite-frequency-window action and finite-time/frequency certificate.
- Composes the three external regularity theorems into a triple action necessity filter.
- Adds the conditional Grujic logarithmic vortex-direction depletion filter.
- Defines Candidate Dynamical Cover v1 and the residual dangerous core.
- Shows the ten RFP frontier channels need only be studied inside the triple-divergent dangerous core.
- Moves Cycle I to a final dangerous-core realizability / standard-PDE recompilation paper.
