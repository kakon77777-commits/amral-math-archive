---
title: "Navier–Stokes Reverse Formation Program：Series Roadmap"
version: "v1.0"
date: "2026-08-15"
author: "Neo.K / EveMissLab"
language: "zh-TW"
status: "Research roadmap"
---

# NS-RFP Series Roadmap v1.0

## Completed structural ladder

### RFP-01 — Formation Architecture
State / Edge / Guard / Escape / Closure.

### RFP-02 — Critical UV First-Passage Skeleton
Canonical scale-time crossings and nonlinear source debt.

### RFP-03 — Exact Parent Ledger
Signed dyadic parent provenance.

### RFP-04 — Spacetime Tube / Uniform Parent Tightness
Pressure-compatible localization and quantitative parent tightness.

### RFP-05 — Persistence / Infinite Path Extraction
Finite-branching survivor recursion and quantifier closure.

### RFP-06 — Inter-Edge Source--Stock Bridge
Exact field packet propagation across seams.

### RFP-07 — Synchronous Plateau Compression
Finite spectral plateaus and hidden positive-time formation.

### RFP-08 — Memory / Time / Packet Closure
Field-packet completeness, memory age, causal lag, plateau-crossing debt.

### RFP-09 — Unified Tax Ledger
Nine-coordinate certificate tax vector and selector compiler.

### RFP-10 — Guard / Tax-Boundary Audit
Separates certificate compactness from dynamical coercivity; identifies bounded-tax interior accumulation.

### RFP-11 — Pathwise Coercive Actions

Introduces three cross-cutting standard-PDE actions:

$$
\mathcal A_{\lambda_2,q},
\qquad
\mathcal A_{SV,\alpha},
\qquad
\mathcal A_{freq,\epsilon}.
$$

Hypothetical finite blow-up must make all three diverge.

For $q=2$:

$$
\|\lambda_2^+\|_2^2
\in
L_t^1
\setminus
L_t^2,
$$

so critical middle-strain action must become temporally intermittent.

Defines the residual dangerous core:

$$
\boxed{
\mathfrak R_{\rm danger}
=
\mathfrak D_{\rm RFP}
\cap
D_{mid}
\cap
D_{SV}
\cap
D_{freq}.
}
$$

In Grujic's critical-point scenario:

$$
\boxed{
\mathfrak R_{\rm danger}^{crit}
=
\mathfrak R_{\rm danger}
\cap
R_{\log dep}^{c}.
}
$$

Candidate Dynamical Cover v1 is still incomplete because dangerous-core emptiness is not proved.

## Immediate frontier

### RFP-12 — Dangerous-Core Realizability、Coercive-Intersection Analysis 與 Standard PDE Recompilation

This is the final paper of the first NS-RFP cycle.

Main tasks:

1. analyze simultaneous divergence of:
   $$
   \mathcal A_{\lambda_2,q},
   \quad
   \mathcal A_{SV,\alpha},
   \quad
   \mathcal A_{freq,\epsilon};
   $$
2. connect middle-strain temporal intermittency to dyadic frequency/packet concentration;
3. connect $D_{SV}$ to exact interaction/model-cone alignment;
4. connect $D_{freq}$ to RFP parent-gap / packet-depth geometry;
5. test compatibility of all three action divergences with finite energy and viscosity;
6. in critical-point scenarios, add failure of logarithmic vortex-direction depletion;
7. either:
   - prove a coercive-intersection no-go;
   - isolate one explicit realizable dangerous-core escape class;
   - or prove the current RFP representation remains incomplete;
8. recompile every valid RFP theorem into standard PDE language;
9. formally audit quantifiers, theorem imports, scaling, and no-overclaiming status.

## Cycle-I closure rule

RFP-12 must not claim Navier–Stokes regularity unless a complete standard-PDE theorem chain has actually been proved.

If dangerous-core emptiness is not established, Cycle I ends with a precise frontier / handoff document rather than a false closure claim.
