# CHANGELOG

## v0.1 — 2026-08-14

- Replaces the RFP-05 abstract inter-edge bridge placeholder with an exact Duhamel source-stock bridge construction.
- Introduces field-valued seam packets for every dyadic output and local source channel.
- Proves exact full nonlinear increment refinement.
- Shows the scalar local ledger is a terminal dual shadow of the seam packet field.
- Replaces artificial shell-label equality by actual Littlewood-Paley projection visibility.
- Proves every nonzero packet has a bounded-offset shell with quantitative projection visibility.
- Adds frequency-localized heat survival and a viscous bridge-delay diagnostic.
- Proves exact parent-shell source-stock propagation across the first-passage seam.
- Splits the next parent source into older stock, previous-edge packets and fresh same-edge source.
- Further splits previous packets into tracked and untracked channels.
- Defines the realized slot-specific PDE bridge score.
- Updates the canonical RFP graph edge score to use the realized PDE bridge directly; geometric overlap remains a diagnostic rather than a second multiplicative charge.
- Proves the positive source-age simplex.
- Proves tracked bridge capture / effective multiplicity controls a strong bridge floor.
- Converts bridge bottleneck collapse into tracked-capture collapse or bridge multiplicity escape.
- Splits tracked-capture collapse into untracked-packet, older-stock and fresh-source bypass.
- Proves a conditional uniform bridge closure theorem using the RFP-05 finite-branching path extraction theorem.
- Moves the next frontier to the infinite PF-B synchronous-bypass branch.
