# SOURCE_POLICY

- Canonical manuscript format: UTF-8 Markdown.
- Canonical mathematics delimiters: `$...$` and `$$...$$` only.
- No `unicode_escape`-style round trip is used.
- No conversion of LaTeX source into Unicode mathematical glyphs is used as canonical source.
- Chat rendering is not the canonical manuscript.
- Source-level validation is recorded in `validation.json`.
- Render-level KaTeX/TeX compilation is not claimed in this release.
- Positive scalar witness graphs are not silently assumed complete for all nonzero field packets.
- Certificate or graph failure is not promoted to Navier-Stokes dynamical impossibility without a proved completeness bridge.
