---
title: "Navier–Stokes Reverse Formation Program：Series Roadmap"
version: "v0.9"
date: "2026-08-15"
author: "Neo.K / EveMissLab"
language: "zh-TW"
status: "Research roadmap"
---

# NS-RFP Series Roadmap v0.9

## Completed structural ladder

### RFP-01 — Formation Architecture

State / Edge / Guard / Escape / Closure.

### RFP-02 — Critical UV First-Passage Skeleton

Adjacent scale-time crossings plus nonlinear source debt.

### RFP-03 — Exact Parent Ledger

Exact signed dyadic parent provenance.

### RFP-04 — Spacetime Tube / Uniform Parent Tightness

Pressure-compatible spacetime source localization and quantitative parent-tail control.

### RFP-05 — Persistence / Infinite Path Extraction

Finite-branching quantifier closure and survivor recursion.

### RFP-06 — Inter-Edge Source--Stock Bridge

Exact field packet propagation from one edge into the next parent source.

### RFP-07 — Synchronous Plateau Compression

Finite spectral plateaus with hidden positive-time source history.

### RFP-08 — Memory / Time / Packet Closure

Packet-complete relevance, generation-age memory, causal time-lag resolution and plateau-crossing debt.

### RFP-09 — Unified Tax Ledger

Nine-coordinate certificate tax vector and bounded-tax selector compiler.

### RFP-10 — Guard Consolidation / Tax-Boundary Audit

Main audit conclusion:

$$
\boxed{
\text{certificate compactness}
\neq
\text{dynamical coercivity}.
}
$$

The nine pointwise tax faces are not yet a finite dynamical obstruction family.

A new interior accumulation channel appears because:

$$
\sum_n
\log
\mathfrak T_n^{adj}
=
\int
\|\nabla u\|_\infty dt
$$

may diverge even when every per-edge:

$$
\mathfrak T_n^{adj}
$$

is bounded.

Therefore the true frontier contains:

$$
\boxed{
I\mbox{-}A
+
F_{atom}
+
F_{bridge}
+
F_{amp}
+
F_{par}
+
F_{depth}
+
F_{adj}
+
F_{int}
+
F_{mem}
+
F_{time}.
}
$$

Current dynamical guard coverage is only partial.

## Immediate frontier

### RFP-11 — Pathwise Coercive Actions、Tax-Boundary Realizability 與 Dynamical Guard Coverage

Main tasks:

1. build pathwise actions only from explicit PDE inequalities;
2. refine:
   $$
   I\mbox{-}A
   $$
   using exact strain/vorticity/advection structure;
3. analyze resonant high--high transfer on:
   $$
   F_{par}\cap F_{depth};
   $$
4. test persistence of:
   $$
   F_{time}
   $$
   near-diagonal congestion;
5. split:
   $$
   F_{int}
   $$
   into depleting versus dangerous geometry;
6. test whether certificate-like:
   $$
   F_{atom},
   F_{bridge},
   F_{mem}
   $$
   can be absorbed by stronger field representations;
7. build Candidate Dynamical Cover v1;
8. determine whether the ten-channel frontier can be covered by a finite number of exact-N--S coercive guards.

### RFP-12 — Escape Realization、Standard PDE Recompilation 與 Formal Audit

For every channel not covered in RFP-11:

- attempt approximate realization;
- test stability and compactness;
- determine whether it is a genuine N--S escape or certificate artifact;
- translate all valid theorems back to standard PDE language;
- formally audit all quantifiers, dependencies and external theorem imports.

## Hard theorem-safety rules

- Tax divergence is not automatically a blow-up driver.
- Certificate failure is not dynamical impossibility.
- Per-edge bounded taxes do not imply bounded cumulative path actions.
- Finite Obstruction must cover both bounded-tax interior accumulation and tax-boundary escape.
- A pathwise action may be introduced only from an explicit PDE estimate or identity.
