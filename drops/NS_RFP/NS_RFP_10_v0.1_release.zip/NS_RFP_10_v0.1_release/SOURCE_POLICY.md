# SOURCE_POLICY

- Canonical manuscript format: UTF-8 Markdown.
- Canonical mathematics delimiters: `$...$` and `$$...$$` only.
- No `unicode_escape`-style round trip is used.
- No conversion of LaTeX source into Unicode mathematical glyphs is used as canonical source.
- Chat rendering is not the canonical manuscript.
- Source-level validation is recorded in `validation.json`.
- Render-level KaTeX/TeX compilation is not claimed in this release.
- Certificate failure is not promoted to dynamical impossibility.
- Tax divergence is not promoted to a blow-up mechanism.
- Pointwise tax-boundary analysis is explicitly separated from pathwise cumulative actions.
