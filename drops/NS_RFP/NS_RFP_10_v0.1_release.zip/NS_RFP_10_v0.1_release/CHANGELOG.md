# CHANGELOG

## v0.1 — 2026-08-15

- Consolidates the accumulated RFP guard library into five typed guard classes.
- Audits all nine core tax-boundary faces.
- Distinguishes certificate failure, dynamical constraint, dynamical obstruction, and depletion.
- Proves a cumulative-gradient continuation criterion via the standard $H^m$ energy estimate.
- Identifies the exact path action $\sum_n \log \mathfrak T_n^{adj}=\int \|\nabla u\|_\infty dt$.
- Proves cumulative divergence does not require any single per-edge adjoint tax to diverge.
- Introduces the bounded-tax Interior Accumulation Channel $IA_{adj}$.
- Proves a boundary-only finite-obstruction architecture is incomplete.
- Reclassifies interaction inefficiency as potentially depleting rather than monotonically dangerous.
- Adds cross-cutting PDE guards from frequency-localized regularity, strain eigenvalue criteria and logarithmic vortex-stretching depletion.
- Defines finite dynamical obstruction coverage.
- Proves a conditional Finite Coercive-Cover Closure Theorem.
- Audits Candidate Cover v0 and concludes it is incomplete.
- Moves the program from certificate-bookkeeping to dynamical-coercivity analysis.
