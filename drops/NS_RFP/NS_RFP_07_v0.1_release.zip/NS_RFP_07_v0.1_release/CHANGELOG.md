# CHANGELOG

## v0.1 — 2026-08-14

- Proves that a synchronous first-passage edge forces the intervening dyadic shell to vanish exactly at the common first-passage time.
- Extends this to exact spectral voids on finite synchronous plateaus.
- Proves no fixed-threshold synchronous plateau can extend to arbitrarily high dyadic index.
- Proves every maximal plateau is finite and ends in a strict PF-A break edge.
- Proves there are infinitely many PF-A break edges for every fixed positive threshold.
- Introduces the canonical plateau-compressed first-passage skeleton.
- Identifies plateau width with an exact spectral carrier-void width.
- Proves unbounded plateau width implies RFP-03 carrier-depth escape.
- Introduces threshold descent at the deepest plateau cutoff.
- Proves threshold descent opens a strictly positive-time hidden formation window.
- Proves a uniform hidden nonlinear source debt of $(1-\alpha)M$.
- Defines the scale-invariant hidden duration $\Psi_n^\alpha$.
- Proves temporal congestion forces normalized source-rate blow-up.
- Proves long hidden durations incur heat-taxed near-full replenishment debt.
- Establishes the temporal congestion / parabolic / long-reservoir fast-front trichotomy.
- Moves the remaining PF-A/PF-B problems into one merged memory-depth / time-resolution / untracked-packet frontier.
