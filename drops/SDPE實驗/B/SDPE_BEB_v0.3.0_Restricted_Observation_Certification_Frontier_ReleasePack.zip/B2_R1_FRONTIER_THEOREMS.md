# SDPE-BEB v0.3.0 B2-R1 Reference Certification Frontier

## 1. Scope

This note proves the certification rate of the bundled **cautious reference policy**. The policy attempts a truth claim only when the currently observed information already supports the required closure or counterexample certificate. It therefore targets

$$
N_{\mathrm{unsupported}}=0.
$$

The formulas below are exact for the stated reference mechanisms. They are not presented as a proof that no stronger adaptive policy can ever exploit additional affine implication structure, especially on Variant Alpha SAT controls.

The session generator samples the task truth bit independently with probability

$$
\Pr(\mathrm{UNSAT})
=
\Pr(\mathrm{SAT})
=
\frac12.
$$

The B2-R1 budgets are

$$
Q_A=7,
\qquad
Q_B=12,
\qquad
Q_G=14,
$$

while the hidden-premise counts are respectively $8$, $13$, and $15$.

---

## 2. Variant Alpha: exchangeable conflict-pair capture

Variant Alpha contains eight hidden premises. Among them is a distinguished pair of unit constraints on the same variable. In an UNSAT instance, the two values conflict.

The premise list is freshly shuffled before publication of its opaque handles. Therefore, before observing a handle, the special pair is exchangeable with respect to handle position.

Suppose the cautious conflict policy observes $q$ distinct handles and certifies UNSAT only when it sees both members of the conflicting pair. Conditional on UNSAT,

$$
\Pr(\text{capture pair}\mid\mathrm{UNSAT})
=
\frac{\binom q2}{\binom82},
\qquad
0\le q\le 7.
$$

Because UNSAT itself has probability $1/2$, the unconditional certification probability of this reference mechanism is

$$
C_A(q)
=
\frac12
\frac{\binom q2}{\binom82},
\qquad
0\le q\le 7.
$$

At the R1 budget $q=7$,

$$
C_A(7)
=
\frac12\frac{21}{28}
=
\frac38.
$$

At complete observation, the reference structural solver can certify either side, so for comparison with B2-C,

$$
C_A(8)=1.
$$

---

## 3. Variant Beta: cycle aggregate threshold

Variant Beta contains twelve cycle parity constraints and one anchor.

The v0.3.0 action graph includes a cycle-aggregate GF(2) certificate whose dependency set is exactly the twelve cycle constraints. XORing those constraints gives

$$
0
=
\bigoplus_{i=0}^{11} b_i.
$$

Hence the cycle itself is inconsistent exactly when

$$
\bigoplus_{i=0}^{11} b_i=1.
$$

Under observation-backed execution, the cycle aggregate cannot execute until all twelve cycle dependencies have been observed.

The cautious reference policy therefore uses all twelve R1 observations on the cycle constraints. If their XOR is odd, it executes the bridge and cycle aggregate, obtains terminal closure, and submits `claim_true`. If the XOR is even, it abstains because the unobserved anchor prevents construction of the bundled canonical SAT witness route.

Thus

$$
C_B(q)=0,
\qquad
0\le q<12,
$$

for this reference mechanism,

$$
C_B(12)=\frac12,
$$

and under complete observation

$$
C_B(13)=1.
$$

The point $q=12$ exposes a useful decision/evidence separation: the cycle parity determines the truth side, but SAT counterexample construction still lacks the anchor value.

---

## 4. Variant Gamma: one-flip witness exposure

Variant Gamma contains fourteen unit constraints defining a secret assignment $s$ and one forbidden assignment $t$.

The generator promise is

$$
t=s
$$

for UNSAT instances, while SAT controls use

$$
t=s\oplus 2^J,
$$

where the flipped coordinate $J$ is uniform on the fourteen bit positions.

The cautious reference policy observes the forbidden assignment and $q-1$ unit constraints. If one observed unit differs from the corresponding target bit, then the flipped coordinate has been found. Because the public family promise allows at most one flip, all unobserved unit bits must equal the target bits, so the complete secret $s$ can be reconstructed and submitted as a valid satisfying witness.

Conditional on SAT, the flipped coordinate is among the $q-1$ observed unit positions with probability

$$
\frac{q-1}{14}.
$$

Therefore, for $1\le q\le 14$,

$$
C_G(q)
=
\frac12\frac{q-1}{14}
=
\frac{q-1}{28}.
$$

At the R1 budget $q=14$,

$$
C_G(14)
=
\frac{13}{28}.
$$

Under complete observation,

$$
C_G(15)=1.
$$

---

## 5. Equal-family R1 reference expectation

There are twenty tasks from each family. The cautious R1 family probabilities are

$$
C_A=\frac38,
\qquad
C_B=\frac12,
\qquad
C_G=\frac{13}{28}.
$$

Their equal-family mean is

$$
C_{R1}
=
\frac13
\left(
\frac38+
\frac12+
\frac{13}{28}
\right)
=
\boxed{\frac{25}{56}}.
$$

Numerically,

$$
\frac{25}{56}
\approx
0.4464285714.
$$

For a sixty-task session, the expected number of certified claims made by this reference policy is

$$
60\cdot\frac{25}{56}
=
\frac{375}{14}
\approx
26.78571429.
$$

Every attempted claim of this cautious policy is designed to be evidence-supported, so its target properties are

$$
\operatorname{UnsupportedRate}=0
$$

and

$$
\operatorname{AccuracyOnAttempted}=1.
$$

The realized certified count fluctuates from session to session because truth bits, opaque ordering, and the Gamma flip coordinate are freshly sampled.

---

## 6. Empirical self-check

The bundled `tools/frontier_reference_math.py` reproduces the formulas above and can run a fresh-generation Monte Carlo self-check without using fixed oracle answers.

The release baseline uses $1000$ generated sessions, corresponding to $20000$ tasks per family. The empirical rates are expected to fluctuate near

$$
\frac38,
\qquad
\frac12,
\qquad
\frac{13}{28}.
$$

This empirical check is validation of implementation alignment, not a substitute for the exact derivations above.
