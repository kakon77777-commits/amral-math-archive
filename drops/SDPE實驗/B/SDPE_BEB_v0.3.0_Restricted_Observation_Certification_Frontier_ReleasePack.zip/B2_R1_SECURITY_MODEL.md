# SDPE-BEB v0.3.0 B2-R1 Security and Blindness Model

## 1. Claimed level

The reference architecture targets restricted-observation B2 managed-query blindness under the operational separation assumption

$$
\text{participant process}
\cap
\text{evaluator private state}
=
\varnothing.
$$

The concrete session corpus is fresh and committed before the first hidden-premise observation.

## 2. New v0.3.0 restriction

The defining profile condition is

$$
Q_t=|P_t|-1.
$$

At least one premise value therefore remains unobserved in every legally completed R1 task.

This is stronger than the v0.2.0 B2-C condition

$$
Q_t=|P_t|.
$$

## 3. No free hidden execution

If server execution were allowed to apply hidden predicates that the participant had never observed, the `execute` endpoint would itself become an unmetered information channel.

v0.3.0 therefore requires

$$
D(a)\subseteq O_t
$$

before any predicate-bearing action can execute.

Bridge actions remain dependency-free because they do not filter the survivor set.

## 4. Serialization-order hardening

Opaque identifiers are insufficient if the serialized order of handles preserves generator semantics.

v0.3.0 freshly shuffles the hidden premise order before the public `constraint_ids` list is formed. In particular, the Alpha special pair no longer occupies a fixed list position.

Beta and Gamma still expose some semantic roles through the public certificate dependency graph. This is intentional: those dependencies are part of the public proof-search interface and are used by the reference frontier constructions.

## 5. Start receipt and transcript binding

The transcript genesis binds the protocol version, profile identifier, session identifier, corpus root, descriptor manifest hash, and evaluator public key:

$$
h_0
=
H(
\texttt{protocol}
\Vert
\texttt{profile}
\Vert
\texttt{session}
\Vert
C
\Vert
D
\Vert
K_{pub}
).
$$

Official audit requires the pre-query start receipt containing those values.

The final transcript head is signed with Ed25519.

## 6. Semantic transcript audit

The post-session auditor does more than verify the hash chain. It replays the revealed transcript semantics from the committed task state and checks:

- observation budget accounting;
- repeated-query charging;
- observed dependency sets;
- action gating;
- unlock and prerequisite rules;
- step and cost budgets;
- certificate verification;
- terminal closure;
- witness evidence;
- task finalization;
- final summary reconstruction.

Thus

$$
\text{signed transcript}
\neq
\text{semantically valid transcript}
$$

and official audit requires both.

## 7. Family-profile conformance

Post-session reveal is also checked against the public B2-R1 family contract. This prevents a self-consistent evaluator from silently changing the family generator while continuing to report B2-R1 frontier numbers.

The auditor verifies family counts, public shapes, R1 budgets, direct premise-action coverage, Beta cycle structure, Beta cycle-aggregate availability, Gamma one-flip structure, and Gamma full-unit aggregate availability.

## 8. Explicit non-claims

v0.3.0 does not claim secure multi-party computation, trusted hardware isolation, zero knowledge, malicious-evaluator resistance, or B3 cryptographic opacity.

Possession of the evaluator-private state, generator seed, or Full-Dev bundle during a measured run invalidates the blindness claim for that run.
