# SDPE-BEB v0.3.0 B2-R1 Audit Contract

For a task $t$, let $P_t$ be its hidden-premise set, $O_t$ the set of distinct observed premise handles, $q_t$ the number of observation requests consumed, and $Q_t$ its observation budget.

The B2-R1 profile requires

$$
Q_t=|P_t|-1.
$$

A legal observation history satisfies

$$
0\le q_t\le Q_t.
$$

Repeated observations consume additional budget even though they do not enlarge $O_t$.

No rejected over-budget observation may disclose a hidden predicate.

For an action $a$, let $D(a)$ be the hidden-premise dependency set of its predicate source. A legal predicate-bearing execution requires

$$
D(a)\subseteq O_t.
$$

Let

$$
R_t=(a_1,\ldots,a_k)
$$

be the server-executed action path. The evaluator also enforces

$$
k\le B_t
$$

and

$$
\sum_{i=1}^{k} c(a_i)\le C_t.
$$

The survivor state remains evaluator-private during the task. The execution API reports terminal closure but does not reveal survivor cardinality or survivor assignments.

A task submission is terminal:

$$
\operatorname{Submit}(t)
\Longrightarrow
\text{no further observe or execute operation on }t.
$$

A true-claim certificate requires evaluator-side closure. A false-claim certificate requires a witness satisfying every hidden premise.

For session commitment, each hidden task/oracle pair has commitment

$$
c_t
=
H(
\operatorname{canon}(t,O_t^{\mathrm{oracle}})
\Vert
n_t
),
$$

where $O_t^{\mathrm{oracle}}$ denotes the exact private oracle record and $n_t$ is the commitment nonce.

The corpus root is

$$
C
=
H(
\operatorname{canon}([(t,c_t)]_{t\in T})
).
$$

Let $D$ be the public descriptor-manifest hash. The transcript genesis is

$$
h_0
=
H(
\texttt{protocol}
\Vert
\texttt{profile}
\Vert
\texttt{session}
\Vert
C
\Vert
D
\Vert
K_{pub}
).
$$

Each event extends the chain by

$$
h_i
=
H(
h_{i-1}
\Vert
\operatorname{canon}(e_i)
).
$$

At finalization the evaluator signs $h_m$ with Ed25519.

Official post-session audit requires the participant-preserved pre-query start receipt and verifies:

1. receipt binding;
2. corpus and descriptor commitments;
3. exact finite oracle semantics;
4. B2-R1 family/profile conformance;
5. transcript hash-chain integrity;
6. Ed25519 signature validity;
7. semantic transcript replay;
8. revealed task-state and final-summary consistency.

The authority separation remains

$$
\text{label correctness}
\neq
\text{evidence support}
\neq
\text{certification authority}.
$$
