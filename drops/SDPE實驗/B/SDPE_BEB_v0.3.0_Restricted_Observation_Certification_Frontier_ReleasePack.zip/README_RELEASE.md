# SDPE-BEB v0.3.0 — Restricted Observation Certification Frontier

v0.3.0 introduces the first official restricted-observation managed-query profile:

$$
\boxed{Q_t=|P_t|-1.}
$$

Every task therefore retains at least one unobserved premise value during a legal B2-R1 run.

The second defining rule is observation-backed execution. If $D(a)$ is the premise dependency set of an action and $O_t$ is the participant's observed constraint set, then predicate-bearing execution requires

$$
\boxed{D(a)\subseteq O_t.}
$$

This prevents the action endpoint from applying unobserved hidden predicates as a free side-channel.

The release also removes serialization-order leakage by freshly shuffling hidden premise order, adds a twelve-cycle GF(2) certificate for Variant Beta, binds `profile_id` into the start receipt and transcript genesis, validates family-profile conformance after reveal, and semantically replays the signed transcript during audit.

## Reference frontier

The bundled cautious policy has exact per-family certification probabilities at the R1 budget

$$
C_A=\frac38,
\qquad
C_B=\frac12,
\qquad
C_G=\frac{13}{28}.
$$

Hence its equal-family expected certified coverage is

$$
\boxed{
C_{R1}=\frac{25}{56}\approx 0.4464285714.
}
$$

The policy is constructed to make no unsupported claims.

The included 1000-session generator self-check produced an empirical equal-family mean near this exact value. A separate frozen HTTP session and a cold cross-package HTTP session are included/reported for end-to-end validation.

## Packages

- `SDPE_BEB_B2R_Participant_v0.3.0.zip`: participant-facing public protocol/client bundle; no evaluator-private implementation or hidden state.
- `SDPE_BEB_B2R_Evaluator_v0.3.0.zip`: evaluator-private server, generator, audit core, and tests.
- `SDPE_BEB_B2R_Full_Dev_v0.3.0.zip`: complete development/audit bundle with reference cautious client, frontier tool, tests, and frozen post-session reveal.
- `SDPE_BEB_v0.2.0_Managed_Query_Evaluator_Frontier_ReleasePack.zip`: lineage reference for the prior B2-C complete-observation profile.

B2-C v0.2.0 and B2-R1 v0.3.0 are different information profiles. Their scores must not be merged as if they used the same observation contract.
