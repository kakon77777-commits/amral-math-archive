# Migration from v0.2.0 to v0.3.0

v0.3.0 is a mathematical profile change, not a backwards-compatible patch to B2-C.

The main changes are:

1. protocol identifier changes from `sdpe-beb-b2-v0.2.0` to `sdpe-beb-b2r-v0.3.0`;
2. HTTP session endpoints move from `/v0.2/...` to `/v0.3/...`;
3. the official profile becomes `B2-R1-one-hidden-premise`;
4. every task satisfies $Q_t=|P_t|-1$;
5. hidden premise order is freshly shuffled before public handle publication;
6. predicate-bearing actions require all predicate dependencies to have been observed;
7. Variant Beta gains a twelve-cycle GF(2) aggregate action so the restricted closure frontier has an explicit certificate threshold;
8. the start receipt binds `profile_id`;
9. post-session audit validates B2-R1 family conformance;
10. post-session audit now semantically replays the transcript rather than checking only commitments, hash chain, and signature;
11. final summaries include certified coverage, unsupported-claim rate, observation utilization, and per-family metrics;
12. the Full-Dev package includes an exact reference-frontier derivation, Monte Carlo implementation self-check, and a frozen R1 cautious-policy session.

B2-C v0.2.0 remains a separate complete-observation benchmark profile. Scores from B2-C and B2-R1 must not be merged as though they were obtained under the same information budget.
