# SDPE-BEB v0.3.0 B2-R1 Public Protocol

## 1. Profile

The v0.3.0 measured profile is **B2-R1: one hidden premise per task**.

For every task $t$ with hidden-premise set $P_t$, the observation budget is

$$
Q_t=|P_t|-1.
$$

The concrete task corpus is freshly generated for each session. Task identifiers, constraint identifiers, action identifiers, hidden premise order, truth values, and commitments are fresh per session.

Truth values are sampled independently. No exact within-family truth balance is promised before reveal.

## 2. Public descriptor

Before the first premise observation, the participant receives a public descriptor containing:

- task family;
- number of Boolean variables;
- public claim;
- step and model-cost budgets;
- restricted observation budget;
- opaque constraint handles;
- public action graph and certificate dependency handles;
- per-task commitment.

The hidden predicates themselves remain evaluator-private until queried or post-session reveal.

## 3. Observation rule

A premise observation consumes one observation token, including a repeated observation of an already observed handle.

For task $t$, if $q_t$ observations have already been consumed, then a legal observation requires

$$
q_t<Q_t.
$$

An over-budget request is rejected without returning the hidden predicate.

## 4. Observation-backed execution

Let $O_t$ be the set of constraint handles whose predicates have actually been observed by the participant.

For an action $a$, let $D(a)$ be the set of premise dependencies required by its predicate source.

The evaluator permits predicate-bearing execution only if

$$
D(a)\subseteq O_t.
$$

A bridge action has

$$
D(a)=\varnothing.
$$

This rule prevents action execution from acting as a free hidden-premise oracle.

All ordinary unlock, prerequisite, step-budget, cost-budget, certificate, and terminal-closure rules remain enforced server-side.

## 5. Terminal submission

A task may be submitted exactly once with one of:

- `claim_true`;
- `claim_false` plus an integer witness;
- `undecided`.

A `claim_true` is evidence-supported only if the evaluator-side action path has reached terminal closure.

A `claim_false` is evidence-supported only if its witness satisfies every hidden premise.

After submission,

$$
\operatorname{Submit}(t)
\Longrightarrow
\text{no further observe or execute operation on }t.
$$

## 6. Session finalization and reveal

Truth feedback is withheld until every task has been finalized.

Post-session reveal publishes the committed hidden tasks, exact oracle records, commitment nonces, transcript, transcript head, evaluator signature, task results, and final summary.

Official audit requires the pre-query start receipt.

## 7. Primary B2-R metrics

The release reports at least:

$$
\operatorname{CertifiedCoverage}
=
\frac{N_{\mathrm{closure}}+N_{\mathrm{counterexample}}}{|T|},
$$

$$
\operatorname{UnsupportedRate}
=
\frac{N_{\mathrm{unsupported}}}{N_{\mathrm{attempted}}},
$$

and

$$
\operatorname{ObservationUtilization}
=
\frac{\sum_t q_t}{\sum_t Q_t}.
$$

Per-family versions of these metrics are included because the three families have different restricted-information certificate geometry.
