# SDPE-BEB v0.6.0 — Posterior Productivity Envelope

## 1. Purpose

The full unrestricted Bellman frontier is computationally large after the exact prefix. This document gives a rigorous upper bound that applies to every legal adaptive policy, including arbitrary switching and revisiting.

For family $F$, let $C_F$ be the number of certified tasks from that family and let $N_F$ be the total number of premise observations spent on those tasks.

The key local constants are

$$
\lambda_A=\frac17,
\qquad
\lambda_G=\frac4{47},
\qquad
\lambda_B=\frac2{25}.
$$

They are not assumed from mean completion times. The release independently verifies them by a posterior-state optimal-stopping dual.

---

## 2. Local stopping dual

Fix a family and a candidate productivity $\lambda$. For every posterior state $s$, define

$$
J_\lambda(s)
=
\max\left\{
0,
-\lambda
+
\mathbb E_s
\left[
R_1+J_\lambda(S_1)
\right]
\right\}.
$$

The zero branch is the option to stop allocating observations to that task. Because every local state graph is acyclic toward certification, this recursion is finite and exact.

The file `baselines/productivity_dual_upper_bound.json` contains the exact rational value of $J_\lambda(s)$ and the Bellman residual for every reachable state.

At the fresh roots the release verifies

$$
J_{1/7}(A_{0,0})=0,
$$

$$
J_{4/47}(G_\star)=0,
$$

and

$$
J_{2/25}(B_0)=0.
$$

Hence no legal local stopping rule beginning from a fresh task has positive expected net value $R-\lambda N$ at those prices. Equivalently,

$$
\mathbb E[C_A]
\le
\frac17\mathbb E[N_A],
$$

$$
\mathbb E[C_G]
\le
\frac4{47}\mathbb E[N_G],
$$

and

$$
\mathbb E[C_B]
\le
\frac2{25}\mathbb E[N_B].
$$

---

## 3. Why pauses and revisits do not invalidate the local dual

Take one concrete task $i$. Condition on all randomness external to that task, including observations from all other tasks and all randomized scheduling decisions based on those external histories.

After conditioning, the global scheduler induces a possibly randomized stopping rule on task $i$ that sees only the sequence of that task's own posterior states whenever the task is activated. Pauses do not change the local state because the benchmark arms are rested.

Therefore the local stopping dual applies conditionally. Integrating over the external randomness preserves the inequality.

Thus the bounds above remain valid for the complete unrestricted policy class, not only for nonpreemptive schedules.

---

## 4. Global analytic upper bound

There are at most twenty certificates from each family and the total expected number of observations is at most $Q$. Consequently any unrestricted policy must satisfy

$$
7\mathbb E[C_A]
+
\frac{47}{4}\mathbb E[C_G]
+
\frac{25}{2}\mathbb E[C_B]
\le Q,
$$

with

$$
0\le\mathbb E[C_F]\le20.
$$

The corresponding linear optimization fills the families in descending productivity order:

$$
\frac17
>
\frac4{47}
>
\frac2{25}.
$$

Hence

$$
\boxed{
U_{\mathrm{PD}}(Q)
=
\begin{cases}
Q/7, & 0\le Q\le140,\\
20+\frac4{47}(Q-140), & 140\le Q\le375,\\
40+\frac2{25}(Q-375), & 375\le Q\le625,\\
60, & Q\ge625.
\end{cases}
}
$$

and

$$
\boxed{
V_{\mathrm A}^{\star}(Q)
\le
U_{\mathrm{PD}}(Q).
}
$$

This upper bound uses only information available to the legal participant. It is therefore substantially stronger than the semantic-clairvoyant upper bound from v0.5.0.

---

## 5. Combined v0.6.0 envelope

For $Q\le12$, the unrestricted Bellman value is exact:

$$
L(Q)=U(Q)=V_{\mathrm A}^{\star}(Q).
$$

For $Q>12$, the release uses the constructive recycling value as a certified lower policy and the productivity dual as the unrestricted upper bound:

$$
\boxed{
V_{\mathrm{CR}}(Q)
\le
V_{\mathrm A}^{\star}(Q)
\le
U_{\mathrm{PD}}(Q).
}
$$

Selected checkpoints are:

| $Q$ | lower | upper | unresolved width |
|---:|---:|---:|---:|
| $40$ | $5.362830$ | $5.714286$ | $0.351456$ |
| $80$ | $11.032611$ | $11.428571$ | $0.395960$ |
| $120$ | $16.744612$ | $17.142857$ | $0.398245$ |
| $160$ | $21.415766$ | $21.702128$ | $0.286362$ |
| $240$ | $28.248969$ | $28.510638$ | $0.261669$ |
| $290$ | $32.504339$ | $32.765957$ | $0.261618$ |
| $420$ | $43.310222$ | $43.600000$ | $0.289778$ |
| $570$ | $55.304439$ | $55.600000$ | $0.295561$ |
| $613$ | $58.483978$ | $59.040000$ | $0.556022$ |
| $625$ | $59.139380$ | $60.000000$ | $0.860620$ |

At the principal $Q=290$ profile, the unresolved interval has width

$$
\frac{1540}{47}
-
32.5043389595\ldots
\approx
0.2616184872.
$$

Relative to the upper endpoint, this is below

$$
0.8\%.
$$

The corresponding machine-readable curve is `baselines/posterior_adaptive_envelope.csv`.

---

## 6. Interpretation

The productivity dual does not solve the finite-horizon scheduling problem. It proves that no posterior-adaptive policy can create certificates faster, in expectation, than the stated family productivity constraints allow from fresh tasks.

The remaining mathematical problem is therefore sharply localized:

$$
\boxed{
\text{joint posterior scheduling gain inside a narrow legal-information envelope}.
}
$$

The gap is no longer the very large clairvoyant interval from v0.5.0.
