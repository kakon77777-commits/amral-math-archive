# SDPE-BEB v0.6.0 — Posterior-Adaptive Audit Contract

An official v0.6.0 audit is valid only if all of the following hold.

## Corpus and receipt

The pre-query receipt must match the reveal in protocol version, profile identifier, profile specification, profile hash, session identifier, corpus root, descriptor-manifest hash, evaluator public key, and transcript genesis.

The generation seed revealed after finalization must regenerate the complete sixty-task corpus exactly.

## Global observation budget

Let $N_t$ be the number of successful premise observations for task $t$. The transcript must satisfy

$$
\sum_t N_t\le Q.
$$

The semantic replay recomputes this count independently from the transcript.

## Switch and revisit semantics

No audit rule requires consecutive observations of one task. A task may appear in several disjoint transcript intervals before submission.

For every such interval, semantic replay reconstructs the same cumulative observed-premise set, unlocked-action set, route cost, route steps, and submission state. A task submitted once becomes terminal and cannot be queried or executed afterward.

## Observation-backed action authority

For every executed action $a$ on task $t$,

$$
D(a)\subseteq O_t
$$

must hold at the exact transcript position where the action occurs.

## Submission bijection

Every committed task must receive exactly one terminal submission. Unknown, duplicated, or omitted task submissions invalidate official corpus scoring.

## Truth and evidence

The reveal auditor recomputes the finite Boolean oracle for all sixty tasks. Correct labels without evidence remain unsupported. False certified closures and false certified counterexamples are audit failures.

## Posterior-analysis artifacts

The posterior Bellman and productivity files are research artifacts, not additional participant authority. They may be used to choose which legal query to make next, but they do not bypass the evaluator's evidence requirements.
