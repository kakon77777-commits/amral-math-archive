# Migration to SDPE-BEB v0.6.0

## From v0.5.0

Version v0.5.0 introduced one global session budget and bounded the unrestricted optimum between a recycling lower policy and a semantic-clairvoyant upper bound.

Version v0.6.0 changes the research state model rather than the hidden mathematical corpus families.

### Protocol identifier

`sdpe-beb-b2gb-v0.5.0` becomes `sdpe-beb-b2pa-v0.6.0`.

HTTP endpoints move from `/v0.5/session/...` to `/v0.6/session/...`.

Profile identifiers move from `B2-GB-Qxxxx` to `B2-PA-Qxxxx`.

### New normative behavior

Switching among unfinished tasks and later revisiting them is explicitly supported and audited.

### New mathematics

The release adds exact posterior-state transition kernels, an exact unrestricted Bellman prefix for $Q\le12$, a strict separation between unrestricted posterior adaptation and capped recycling, and a legal-information productivity-dual upper bound for the full budget range.

### Claims deliberately not made

The complete exact curve $V_{\mathrm A}^{\star}(Q)$ for $13\le Q\le720$ is not claimed solved.
