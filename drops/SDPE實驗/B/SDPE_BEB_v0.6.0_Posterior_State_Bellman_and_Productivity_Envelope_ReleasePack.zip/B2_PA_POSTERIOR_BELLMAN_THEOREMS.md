# SDPE-BEB v0.6.0 — Posterior-State Bellman Theorems

## 1. Objective

Version v0.5.0 left the unrestricted shared-budget optimum

$$
V_{\mathrm A}^{\star}(Q)
$$

open. Version v0.6.0 resolves the missing state semantics and gives an exact Bellman characterization of that quantity. It also computes the unrestricted optimum exactly for the benchmark prefix

$$
0\le Q\le12.
$$

The full curve for

$$
13\le Q\le720
$$

is not claimed solved in this release.

The decisive correction is that elapsed query count is not a sufficient task state. The participant may observe different predicate types and relations after the same number of queries, and those histories have different continuation values.

---

## 2. Exact local posterior states

### 2.1 Alpha

An unresolved Alpha task is represented by

$$
A_{u,p},
$$

where $u$ distinct unit predicates and $p$ parity predicates have been observed, while the duplicated unit pair has not yet been completed. The legal unresolved region has

$$
0\le u\le5,
\qquad
0\le p\le2.
$$

Once the duplicated pair is observed with equal values, the truth is known to be SAT but no universally safe witness exists until the remaining premises are observed. This state is

$$
K_r,
$$

where $r$ hidden premises remain.

Let

$$
n=8-u-p,
\qquad
D_u=15-\binom{u}{2}.
$$

For a query from $A_{u,p}$, the parity transition has probability

$$
\Pr(A_{u,p}\to A_{u,p+1})
=
\frac{2-p}{n}.
$$

The probability that the next queried unit completes the hidden duplicated pair is

$$
c_{u,p}
=
\frac{u(6-u)}{D_u n}.
$$

Conditional on completing that pair, the truth coin remains balanced. Hence half of that mass yields an immediate UNSAT certificate, while the other half enters a known-SAT tail $K_r$, except when the final premise has just been observed and the SAT witness is already complete.

The remaining unit transition has probability

$$
\frac{6-u}{n}-c_{u,p}.
$$

A known-SAT tail obeys

$$
K_r\to K_{r-1}
$$

deterministically, and $K_1$ certifies on the next query.

### 2.2 Beta

Let

$$
B_j,
\qquad 0\le j\le11,
$$

mean that $j$ of the twelve cycle edges have been observed under the cycle-first policy. For $j<11$ the next cycle query deterministically advances to $B_{j+1}$.

At $B_{11}$ the twelfth cycle edge is observed. The cycle parity is odd with probability $1/2$, producing an immediate UNSAT certificate. Otherwise the task enters a one-query anchor tail

$$
B_K,
$$

whose next observation gives the SAT witness.

Querying the anchor before the cycle is complete is dominated: it cannot certify earlier and turns the favorable twelve-query UNSAT branch into a thirteen-query branch.

### 2.3 Gamma

Let $G_\star$ denote the untouched Gamma state before the forbidden target has been observed. One query gives the target and enters $G_0$.

In state

$$
G_k,
\qquad 0\le k\le13,
$$

the target is known and $k$ queried unit predicates have matched it. The next unit query produces the unique one-flip mismatch with conditional probability

$$
\frac{1}{28-k}.
$$

That event certifies SAT immediately. Otherwise the state advances to $G_{k+1}$. From $G_{13}$ the final unit query certifies with probability one: either it is the mismatch or all units match and the task is UNSAT.

---

## 3. Query age is not a sufficient statistic

Consider two Alpha histories after one query.

If the first observation is a parity predicate, the posterior state is $A_{0,1}$. No one-query certificate is possible from that state:

$$
V_1(A_{0,1})=0.
$$

If the first observation is a unit predicate, the posterior state is $A_{1,0}$. The next query can complete the duplicated pair and be conflicting, with probability

$$
\frac{1}{42}.
$$

Therefore

$$
V_1(A_{1,0})=\frac{1}{42}.
$$

Thus

$$
\boxed{
\text{same query age}
\not\Rightarrow
\text{same continuation value}.
}
$$

This proves that the v0.5.0 stopping-time compression is not Markov sufficient for unrestricted adaptive scheduling.

---

## 4. Exact global Bellman equation

Let $\mathcal S$ be the finite set of local posterior states and let

$$
\mathbf N=(N_s)_{s\in\mathcal S}
$$

be the counts of currently live tasks in those states. Untouched tasks are represented by the family roots $A_{0,0}$, $B_0$, and $G_\star$.

For one query of a task in state $s$, let

$$
P_s(r,s')
$$

denote the exact probability of immediate reward $r\in\{0,1\}$ and next state $s'$, with the absorbing certified outcome represented separately.

The unrestricted finite-horizon value is

$$
V_0(\mathbf N)=0
$$

and

$$
\boxed{
V_q(\mathbf N)
=
\max_{s:N_s>0}
\sum_{r,s'}
P_s(r,s')
\left[
 r+V_{q-1}(\mathbf N-\mathbf e_s+\mathbf e_{s'})
\right].
}
$$

For an absorbing transition, the $\mathbf e_{s'}$ term is omitted.

This recurrence allows arbitrary switching and arbitrary later revisits because inactive task states remain frozen.

---

## 5. Fresh-reservoir equivalence for the small-budget prefix

There are twenty tasks from each family. A policy with total budget $Q$ can touch at most $Q$ distinct tasks in total because the first observation of every newly touched task costs one query.

Hence for

$$
Q\le20,
$$

replacing each twenty-task untouched pool by an unlimited fresh reservoir cannot enlarge the feasible policy set before the horizon is exhausted. In particular, the exact reservoir Bellman computation is also exact for the actual $20/20/20$ benchmark on every computed budget in this release.

The implementation computes exact rational values through

$$
Q=12.
$$

---

## 6. Exact unrestricted prefix

The exact values are:

| $Q$ | $V_{\mathrm A}^{\star}(Q)$ | $V_{\mathrm{CR}}(Q)$ | strict gain |
|---:|---:|---:|---:|
| $2$ | $1/28$ | $1/28$ | $0$ |
| $3$ | $1/14$ | $1/14$ | $0$ |
| $4$ | $319/2940$ | $85/784$ | $1/11760$ |
| $5$ | $9/49$ | $71/392$ | $1/392$ |
| $6$ | $1444/5145$ | $12041/43904$ | $4217/658560$ |
| $7$ | $16549/41160$ | $533/1372$ | $559/41160$ |
| $8$ | $118207/115248$ | $2521233/2458624$ | $1549/7375872$ |
| $9$ | $2408677/2304960$ | $1283873/1229312$ | $11321/18439680$ |
| $10$ | $1109809/1008420$ | $151378361/137682944$ | $2213417/2065244160$ |
| $11$ | $150985277/129077760$ | $40207057/34420736$ | $835253/516311040$ |
| $12$ | $17012527877/13553164800$ | $9647613697/7710244864$ | $6890486431/1734805094400$ |

Therefore the actual sixty-task benchmark already has the strict separation

$$
\boxed{
V_{\mathrm A}^{\star}(4)
-
V_{\mathrm{CR}}(4)
=
\frac{1}{11760}
>0.
}
$$

Unrestricted posterior adaptation is not merely a larger policy class in notation; it has strictly positive benchmark value.

---

## 7. Switching and revisiting

The Bellman state retains every unfinished task separately. Consequently a policy may perform patterns such as

$$
A\to G\to A
$$

without losing the first Alpha posterior state.

The evaluator regression suite explicitly executes an Alpha query, switches to Gamma, and then revisits the same Alpha task before either task is submitted. The post-session semantic audit accepts the transcript.

The release does not claim that every optimal trajectory requires a strict revisit. What is proved is that posterior-conditioned switching can strictly improve expected certification, and the protocol supports the complete switch/revisit policy class needed by the Bellman equation.

---

## 8. Scope boundary

Version v0.6.0 does not claim an exact solution of the full joint-state Bellman recurrence for all

$$
13\le Q\le720.
$$

The exact state space grows combinatorially with the multiset of partially observed tasks. The release instead combines the exact $Q\le12$ prefix with a new global productivity-dual upper bound, described in `B2_PA_PRODUCTIVITY_ENVELOPE.md`.
