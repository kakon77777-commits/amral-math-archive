# SDPE-BEB v0.6.0 — Posterior-State Bellman and Productivity Envelope

Version v0.6.0 advances the shared-global-budget line from nonpreemptive recycling to a posterior-adaptive policy model in which a participant may pause a partially observed task, work on another task, and later revisit the first task.

The protocol identifier is:

`sdpe-beb-b2pa-v0.6.0`

## Main mathematical result

Let

$$
V_{\mathrm A}^{\star}(Q)
$$

be the unrestricted safe-certification optimum under one session observation budget $Q$.

Version v0.6.0 gives an exact posterior-state Bellman recurrence and computes the exact benchmark frontier for

$$
0\le Q\le12.
$$

The first strict separation from the v0.5.0 capped-recycling policy occurs on the actual sixty-task benchmark at

$$
Q=4,
$$

where

$$
V_{\mathrm A}^{\star}(4)
=
\frac{319}{2940},
$$

$$
V_{\mathrm{CR}}(4)
=
\frac{85}{784},
$$

and therefore

$$
\boxed{
V_{\mathrm A}^{\star}(4)-V_{\mathrm{CR}}(4)
=
\frac1{11760}>0.
}
$$

This proves that posterior-conditioned switching has strictly positive expected certification value; it is not merely a protocol convenience.

## Full-range rigorous envelope

For budgets beyond the exact prefix, v0.6.0 does not claim a solved unrestricted frontier. Instead it proves a posterior-productivity upper bound.

The local dual constants are

$$
\lambda_A=\frac17,
\qquad
\lambda_G=\frac4{47},
\qquad
\lambda_B=\frac2{25}.
$$

Hence every legal adaptive global policy obeys

$$
V_{\mathrm{CR}}(Q)
\le
V_{\mathrm A}^{\star}(Q)
\le
U_{\mathrm{PD}}(Q).
$$

At $Q=290$ this gives

$$
32.5043389595\ldots
\le
V_{\mathrm A}^{\star}(290)
\le
\frac{1540}{47}
=32.7659574468\ldots,
$$

leaving a rigorous gap of approximately $0.2616184872$.

## Protocol semantics

A paused task is a rested posterior state. Switching or revisiting a task does not reveal information by itself and does not bypass evidence authority. All premise observations consume the same global budget, and action execution remains gated by actually observed dependencies.

The evaluator continues to provide fresh-session HMAC-SHA256 deterministic generation from a hidden seed, pre-query corpus commitment, key-pinned start receipt, append-only hash-chained transcript, Ed25519 final signature, post-session seed reveal, exact generator replay, and semantic transcript audit.

## Packages

- `SDPE_BEB_B2PA_Participant_v0.6.0.zip` — participant-safe client, public protocol, posterior kernel, exact Bellman prefix strategy, and public numerical baselines.
- `SDPE_BEB_B2PA_Evaluator_v0.6.0.zip` — evaluator-private generator/server/auditor.
- `SDPE_BEB_B2PA_Full_Dev_v0.6.0.zip` — complete implementation, tests, exact-DP tools, productivity-dual verifier, and replayable frozen sessions.
- `SDPE_BEB_v0.5.0_Shared_Global_Budget_Allocation_Envelope_ReleasePack.zip` — preserved lineage reference.

## Scope boundary

Version v0.6.0 does **not** claim the complete exact values of

$$
V_{\mathrm A}^{\star}(Q)
$$

for every $13\le Q\le720$. The exact $Q\le12$ Bellman frontier and the full-range rigorous envelope are separate certified results.
