# SDPE-BEB v0.6.0 — Posterior-Adaptive Public Protocol

## 1. Profile

The protocol identifier is

`sdpe-beb-b2pa-v0.6.0`.

A session uses one globally committed observation budget

$$
Q\in\{0,1,\ldots,720\}.
$$

The profile identifier is

`B2-PA-Qxxxx`.

The corpus contains twenty fresh tasks from each of the three benchmark families.

## 2. Legal participant behavior

The participant may at any time:

1. observe an unobserved premise of any unfinished task;
2. switch to another unfinished task;
3. later revisit a previously observed unfinished task;
4. execute an action whose hidden dependencies have all been observed and whose public route prerequisites are satisfied;
5. submit `claim_true`, `claim_false` with a witness, or `undecided`.

Every successful premise observation consumes one unit from the same session budget. Repeated observations are not free. The evaluator rejects an observation that would exceed $Q$ before returning the hidden predicate.

An unfinished task is rested while another task is queried: its posterior state does not change during the pause.

## 3. Evidence semantics

A truth declaration, evidence support, and certification authority remain separate.

A `claim_true` requires a legal within-budget closure route.

A `claim_false` requires a valid satisfying witness against the complete hidden premise set.

`undecided` is an explicit abstention.

## 4. Observation-backed execution

If an action depends on hidden premise set $D(a)$ and the participant has observed set $O_t$ for task $t$, execution requires

$$
D(a)\subseteq O_t.
$$

Switching to other tasks does not erase $O_t$.

## 5. Session commitment and audit

Before the first query the evaluator commits the fresh corpus and returns a signed-key-pinned start receipt. The transcript is hash chained. After every task has a submission, the session is finalized, the hidden corpus is revealed, the generation seed is disclosed, and the auditor regenerates the corpus exactly.

Version v0.6.0 preserves the v0.5.0 cryptographic and provenance architecture while making switch/revisit behavior explicitly normative.

## 6. Reference exact regime

The release ships an exact posterior Bellman client for

$$
Q\le12.
$$

For larger budgets the client is not presented as the unrestricted optimum.
