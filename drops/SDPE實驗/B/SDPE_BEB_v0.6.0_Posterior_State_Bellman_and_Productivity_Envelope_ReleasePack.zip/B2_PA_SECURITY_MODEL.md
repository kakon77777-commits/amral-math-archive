# SDPE-BEB v0.6.0 — Posterior-Adaptive Security Model

## Preserved guarantees

Version v0.6.0 preserves the fresh-session HMAC-SHA256 counter generator, pre-query corpus commitment, key-pinned start receipt, append-only hash-chained transcript, Ed25519 final signature, deterministic post-session generator replay, and semantic transcript audit.

## New scheduling surface

The participant is now explicitly permitted to maintain several partially observed tasks and move among them. This increases the policy space but does not increase evidence authority.

A paused task reveals no new information and changes no server-side state until another legal operation addresses it.

## No free inference through execution

Action execution still requires all hidden dependencies to have been observed. Consequently an action endpoint cannot be used as a free oracle for a premise that the participant skipped.

## Posterior model boundary

The posterior-state kernel is derived from the public generator promises and the legal observations already returned by the evaluator. It does not contain the private session seed or unrevealed concrete predicates.

The exact Bellman policy shipped for small $Q$ therefore remains a legal participant-side strategy rather than an oracle-assisted strategy.

## Blindness level

The benchmark remains in the managed-query B2 family. It does not claim cryptographic concealment against a compromised evaluator host, nor does it claim B3 zero-knowledge evaluation.
