# SDPE-BEB v0.4.0 B2-RQ Public Protocol

## 1. Profile vector

v0.4.0 generalizes the fixed R1 budget into a pinned family observation vector

$$
\mathbf q=(q_A,q_B,q_G),
$$

with legal ranges

$$
0\le q_A\le8,
\qquad
0\le q_B\le13,
\qquad
0\le q_G\le15.
$$

The canonical profile identifier is

`B2-RQ-Axx-Byy-Gzz`.

For example, the v0.3.0 R1 point is represented by

`B2-RQ-A07-B12-G14`.

The full profile specification and its SHA-256 hash are returned in the pre-query start receipt and bound into transcript genesis.

## 2. Fresh session generation

Each evaluator session freshly samples task identifiers, constraint identifiers, action identifiers, hidden premise order, truth values, and commitment nonces.

Truth values remain independently sampled with probability $1/2$ per task. No exact family truth balance is promised before reveal.

Fresh generation uses a deterministic HMAC-SHA256 counter PRF stream keyed by a 256-bit evaluator-private session seed. The seed is not revealed until the session is finalized.

## 3. Observation and execution

For a task of family $F$, premise observations are limited by the pinned value $q_F$.

Repeated observations consume budget.

Predicate-bearing action execution remains observation-backed:

$$
D(a)\subseteq O_t.
$$

Thus an action cannot apply an unobserved hidden predicate as a free query.

## 4. Safe certification

Measured optimal-frontier claims in v0.4.0 use a zero-error completion semantics.

For transcript $z$, let $\mathcal K(z)$ be all positive-probability hidden completions consistent with the public descriptor and observations.

A claim is safe only if it is valid for every completion in $\mathcal K(z)$.

This definition is stricter than merely having high empirical attempted accuracy.

## 5. Finalization and reveal

Each task is finalized once with `claim_true`, `claim_false` plus integer witness, or `undecided`.

Truth feedback remains withheld until all tasks are finalized.

Reveal publishes the committed hidden corpus, exact oracle records, transcript, signature, task results, profile specification, profile hash, and post-session generation seed. Audit regenerates the corpus from this seed and requires exact task equality.

Official audit requires the pre-query start receipt.
