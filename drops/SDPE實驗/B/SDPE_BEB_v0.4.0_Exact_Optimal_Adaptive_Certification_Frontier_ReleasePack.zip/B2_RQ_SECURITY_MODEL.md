# SDPE-BEB v0.4.0 B2-RQ Security and Interpretation Model

## 1. What is pinned

The start receipt binds:

- protocol version;
- canonical profile identifier;
- full B2-RQ profile specification;
- profile-specification SHA-256;
- session identifier;
- corpus commitment root;
- descriptor-manifest hash;
- evaluator public key;
- transcript genesis.

The transcript genesis includes the profile-specification hash, so a reveal cannot silently reinterpret the observation vector after the run.

## 2. Generator randomness boundary

The fresh-session corpus is generated from a 256-bit secret session seed using a deterministic keyed HMAC-SHA256 counter PRF stream. The evaluator does not use Python `random.Random` for hidden-semantic generation.

This choice matters because public task, constraint, and action identifiers expose many pseudorandom-looking values. A non-cryptographic generator must not be treated as a secrecy boundary merely because its initial seed was sampled securely.

The generation seed remains evaluator-private during the session. After finalization it is included in reveal, and official audit regenerates the entire semantic corpus from that seed and requires exact equality with the revealed task set.

Thus post-session audit checks both

$$
\boxed{
\text{structural profile conformance}
}
$$

and

$$
\boxed{
\text{deterministic generator replay conformance}.
}
$$

## 3. What B2-RQ does not claim

B2-RQ is not an information-theoretic or cryptographic hiding theorem for the semantic family itself. The generator family and optimal-frontier theorem are public.

The security goal is narrower:

- fresh concrete hidden predicates;
- managed query counts;
- no evaluator-side free predicate application;
- no mid-session truth feedback;
- receipt-bound provenance;
- post-session exact replay and audit.

## 4. Safe frontier versus gambling

The exact formulas in `B2_RQ_OPTIMAL_FRONTIER_THEOREMS.md` optimize over safe policies.

A participant can always gamble by submitting guesses or guessed witnesses. Such behavior may increase attempted coverage on some finite runs, but it leaves the safe-policy class because a positive-probability compatible completion can make the claim unsupported.

Therefore the theorem is about

$$
\boxed{
\text{zero-error certification probability}
}
$$

rather than unconstrained prediction accuracy.

## 5. Profile comparability

Scores from different vectors

$$
(q_A,q_B,q_G)
$$

must not be merged as if they used the same information contract.

Reports must preserve the exact profile identifier and profile-specification hash.
