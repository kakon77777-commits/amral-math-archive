# Migration to SDPE-BEB v0.4.0

## From v0.3.0

v0.3.0 fixed one hidden premise per family:

$$
(7,12,14).
$$

v0.4.0 generalizes this into a pinned B2-RQ vector

$$
(q_A,q_B,q_G).
$$

The default server configuration remains the old R1 point for continuity.

## Protocol changes

- protocol version becomes `sdpe-beb-b2rq-v0.4.0`;
- HTTP endpoints move from `/v0.3/...` to `/v0.4/...`;
- server adds `--q-alpha`, `--q-beta`, and `--q-gamma`;
- start receipt adds `profile_spec` and `profile_spec_hash`;
- transcript genesis binds `profile_spec_hash`;
- reveal audit validates the full profile vector and every per-family task budget;
- hidden corpus generation moves from Python `random.Random` to a keyed HMAC-SHA256 counter PRF stream;
- post-session reveal publishes the generation seed and audit regenerates the entire corpus exactly.

## Theorem status change

The v0.3.0 document deliberately described $25/56$ as a constructive lower bound.

v0.4.0 proves that, under the explicit safe-certification completion semantics,

$$
\boxed{\frac{25}{56}}
$$

is the exact optimum for the R1 vector.

No mathematical task family was replaced to obtain this result. The change is a stronger analysis of the same fresh-session family generator plus a runtime generalization that permits other query vectors to be measured directly.
