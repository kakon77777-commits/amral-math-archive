# SDPE-BEB v0.4.0 B2-RQ Audit Contract

## 1. Corpus domain

An official session contains exactly sixty committed tasks with family counts

$$
20+20+20.
$$

Every task identifier appears exactly once in the reveal and exactly once in the committed descriptor domain.

## 2. Profile domain

The start receipt contains a profile specification

$$
\mathcal Q
=
(q_A,q_B,q_G)
$$

and its canonical SHA-256 hash.

Every revealed task of family $F$ must have observation budget exactly $q_F$.

The reveal profile specification, profile hash, canonical profile identifier, and receipt values must agree.

## 3. Commitment domain

For task $t$ with hidden task object $T_t$, exact oracle object $O_t$, and nonce $n_t$, the task commitment is

$$
c_t
=
H
\left(
\operatorname{canon}(T_t,O_t)
\Vert
n_t
\right).
$$

The corpus root is the hash of the canonical sorted commitment list.

## 4. Deterministic generator replay

After finalization the reveal includes the 256-bit generation seed. Audit reruns the canonical HMAC-SHA256 counter PRF generator under the revealed B2-RQ profile and requires the regenerated task map to equal the revealed task map exactly.

This is stronger than checking only family-level structural invariants.

## 5. Transcript genesis

The genesis hash binds the protocol, profile, evaluator key, and committed session state:

$$
h_0
=
H(
V
\Vert
Q
\Vert
H(\mathcal Q)
\Vert
S
\Vert
C
\Vert
D
\Vert
K_{\mathrm{pub}}
).
$$

Here $V$ is protocol version, $Q$ is canonical profile identifier, $S$ is session identifier, $C$ is corpus root, and $D$ is descriptor-manifest hash.

Each transcript event extends the chain by

$$
h_i
=
H
\left(
h_{i-1}
\Vert
\operatorname{canon}(e_i)
\right).
$$

## 6. Semantic replay

Audit replays observation counts, action dependencies, unlock state, step budget, model-cost budget, terminal closure, submissions, witness validity, and final summary.

For predicate-bearing action $a$ on task $t$, execution is legal only when

$$
D(a)\subseteq O_t.
$$

Closure is terminal.

## 7. Exact oracle validation

The reveal oracle is not accepted merely because it was committed. Audit recomputes exact finite survivors from the revealed hidden premises and checks the full oracle record.

Thus

$$
\boxed{
\text{commitment integrity}
\neq
\text{oracle semantic correctness}.
}
$$

## 8. Official validity

An official audit is valid only when all of the following hold:

$$
\boxed{
\text{receipt binding}
\land
\text{profile conformance}
\land
\text{generator replay integrity}
\land
\text{commitment integrity}
\land
\text{exact oracle integrity}
\land
\text{transcript hash integrity}
\land
\text{signature integrity}
\land
\text{semantic replay integrity}.
}
$$
