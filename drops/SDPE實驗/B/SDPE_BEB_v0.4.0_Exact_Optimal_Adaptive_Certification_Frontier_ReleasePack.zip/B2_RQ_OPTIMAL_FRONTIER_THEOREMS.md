# SDPE-BEB v0.4.0 — Exact Optimal Safe-Certification Frontier

## 1. Scope

This note upgrades the v0.3.0 reference lower bound to an exact optimality theorem for the public three-family generator under the B2-RQ observation model.

The theorem concerns **safe certification** rather than unconstrained label guessing. A policy may adaptively select premise handles, execute legal public actions, and finally return `claim_true`, `claim_false` with a witness, or `undecided`.

For an observation transcript $z$, let $\mathcal K(z)$ denote the set of hidden task completions having positive generator probability and consistent with the public descriptor and every observed predicate in $z$.

A non-abstaining output is called safe when it is valid for every completion in $\mathcal K(z)$:

- a `claim_true` must be backed by a legal terminal closure using only observed dependencies;
- a `claim_false` witness $w$ must satisfy every completion in $\mathcal K(z)$.

A safe policy therefore has zero unsupported-claim probability on every generator-supported task.

For family $F$ and observation budget $q$, define

$$
C_F^\star(q)
=
\sup_{\pi\in\Pi_{\mathrm{safe}}}
\Pr_{t\sim\mu_F}
\bigl[
\pi\text{ certifies }t\text{ within }q\text{ observations}
\bigr].
$$

The result is

$$
\boxed{
C_A^\star(q)
=
\frac12\frac{\binom q2}{\binom82}
\quad
(0\le q\le7),
\qquad
C_A^\star(8)=1,
}
$$

$$
\boxed{
C_B^\star(q)=0
\quad
(0\le q<12),
\qquad
C_B^\star(12)=\frac12,
\qquad
C_B^\star(13)=1,
}
$$

and

$$
\boxed{
C_G^\star(q)=0
\quad
(0\le q\le1),
}
$$

$$
\boxed{
C_G^\star(q)
=
\frac{q-1}{28}
\quad
(2\le q\le14),
\qquad
C_G^\star(15)=1.
}
$$

Thus the cautious mechanisms shipped in v0.3.0 were not merely constructive lower bounds: under the safe-certification definition they already attain the exact optimum at every restricted budget.

---

## 2. Variant Alpha

Variant Alpha contains eight hidden premises:

- four ordinary unit equations generated from a secret assignment $s$;
- two ternary parity equations generated from the same $s$;
- two unit equations on one distinguished variable $e$.

On SAT controls the distinguished units agree. On UNSAT instances one agrees with $s_e$ and the other is flipped.

The hidden premise order is freshly shuffled, and the Alpha public descriptor gives no role metadata that distinguishes one premise handle from another before observation.

### Lemma A1 — exchangeable handle sampling

For any deterministic adaptive policy that never wastes a query by repeating an already observed Alpha handle, the semantic role of the next chosen unobserved handle is uniformly distributed over the remaining semantic premises, conditional on the observation transcript.

Hence the set of $q$ semantic premises observed by any such policy has the same special-pair capture probability as a uniformly random $q$-subset of the eight premises.

Randomization cannot improve this probability because it is a convex combination of deterministic policies.

### Lemma A2 — the only legal small closure is the conflicting special pair

Alpha has only direct premise actions and a route budget of three actions. Let $r_e$ denote the row corresponding to the flipped special unit.

Every generated premise except $r_e$ is satisfied by the secret $s$. Therefore any inconsistent selected set must contain $r_e$ and the remaining selected premises must imply the correct unit value on $e$.

With at most two additional premises, the only way to imply that unit row is to use the matching special unit itself.

To see this in GF(2) row form:

- two ordinary unit rows are on variables distinct from $e$;
- an ordinary unit row XOR a weight-three parity row has Hamming weight two or four, never one;
- two weight-three parity rows have an XOR of even Hamming weight, never the weight-one row of $e$.

Thus no one- or two-premise subset of the ordinary base constraints implies the special unit row. Consequently

$$
\boxed{
\text{Alpha terminal closure within three actions}
\iff
\text{both conflicting special units were observed and executed}.
}
$$

Conditional on UNSAT, the pair-capture probability is

$$
\Pr(\text{capture special pair}\mid\mathrm{UNSAT})
=
\frac{\binom q2}{\binom82}.
$$

Since

$$
\Pr(\mathrm{UNSAT})=\frac12,
$$

the achievable closure probability is

$$
\frac12\frac{\binom q2}{\binom82}.
$$

### Lemma A3 — no safe SAT witness exists with one or more hidden premises

It remains to exclude a stronger SAT-side policy.

If the observation transcript does not expose the equal-valued distinguished pair, then an UNSAT completion remains possible whenever $q\le7$. A witness cannot be safe because at least one completion in $\mathcal K(z)$ is unsatisfiable.

Suppose instead that the equal-valued distinguished pair has been observed. Then the transcript forces the SAT side. It is enough to analyze the maximally informative restricted case $q=7$: if a universal witness existed at a coarser transcript, it would remain valid after any compatible refinement to seven observations.

There are two cases.

#### Case A3.1 — the hidden base premise is an ordinary unit

The seven observed premises contain:

- the equal distinguished pair, contributing one distinct fixed coordinate;
- three ordinary unit coordinates;
- two parity rows.

Ignoring the duplicate copy, the observed affine system therefore has rank at most six. Four coordinate unit rows are already present in its row span. A rank-six row space can contain at most two additional independent coordinate unit rows. Among the six coordinates eligible to be the hidden ordinary-unit coordinate, at least four are therefore not determined by the observed system.

For any such undetermined eligible coordinate $v$, there are two secret completions satisfying the observed equations but having opposite values of $s_v$. Since either completion can generate the hidden unit premise on $v$, no single witness can satisfy every compatible hidden-unit completion.

#### Case A3.2 — the hidden base premise is a ternary parity

The seven observed premises now contain five distinct fixed unit coordinates and one observed ternary parity row. The observed row span has rank at most six and therefore contains at most

$$
2^6=64
$$

GF(2) masks.

But the generator permits

$$
\binom{10}{3}=120
$$

distinct ternary parity masks. Hence at least one generator-eligible parity row lies outside the observed row span. For such a row $r$, two compatible secret completions exist with opposite values of $r\cdot s$. Both hidden parity predicates therefore remain possible, and no single witness can satisfy every compatible completion.

Thus no safe SAT certificate exists for $q\le7$.

### Theorem A — exact Alpha frontier

Combining Lemmas A1–A3,

$$
\boxed{
C_A^\star(q)
=
\frac12\frac{\binom q2}{\binom82}
\quad
(0\le q\le7).
}
$$

At $q=8$ the whole task is observed, so the structural solver certifies either side and

$$
\boxed{C_A^\star(8)=1.}
$$

---

## 3. Variant Beta

Variant Beta consists of twelve parity edges on a 12-cycle and one anchor unit on $x_0$.

The public action graph identifies the twelve cycle handles through the cycle-aggregate dependency set, so a policy may target them directly.

### Lemma B1 — fewer than twelve observations cannot certify

Any proper subset of the twelve cycle edges is a forest. Arbitrary parity values on a forest are satisfiable. Adding the anchor, when observed, only fixes the polarity of one connected component and preserves satisfiability.

Therefore no observed set with fewer than all twelve cycle edges can force closure.

Moreover, while at least one cycle edge remains hidden, its parity value may be chosen either way. The two choices toggle the total cycle XOR and therefore yield compatible completions on opposite truth sides. Hence no safe SAT witness exists either.

Thus

$$
\boxed{C_B^\star(q)=0\quad(0\le q<12).}
$$

### Lemma B2 — twelve cycle observations certify exactly the odd half

Observing all twelve cycle edges reveals

$$
\bigoplus_{i=0}^{11}b_i.
$$

If this XOR is one, the cycle-aggregate GF(2) action is a legal contradiction certificate and closes the task.

If the XOR is zero, the task is on the SAT side, but the unobserved anchor may still be either zero or one. These two anchor completions select the two complementary cycle assignments. No single witness satisfies both possible anchors.

Therefore the best twelve-query policy observes the whole cycle and certifies exactly the odd-parity half:

$$
\boxed{C_B^\star(12)=\frac12.}
$$

Any twelve-query policy that spends a query on the anchor necessarily leaves a cycle edge hidden and falls under the ambiguity of Lemma B1.

At full observation,

$$
\boxed{C_B^\star(13)=1.}
$$

---

## 4. Variant Gamma

Variant Gamma contains fourteen unit equations defining a secret assignment $s$ and one forbidden assignment $t$.

The public generator promise is

$$
t=s
$$

on UNSAT instances and

$$
t=s\oplus2^J
$$

on SAT controls, where $J$ is uniform over the fourteen coordinates.

The public action graph identifies the forbidden handle and the fourteen unit handles.

### Lemma G1 — mismatch leaves are exactly the restricted safe leaves

Suppose the forbidden assignment has been observed together with $k$ distinct unit coordinates.

If an observed unit differs from the corresponding target bit, the one-flip promise forces the SAT side and identifies the unique flipped coordinate $J$. The complete secret is then reconstructed as

$$
s=t\oplus2^J,
$$

which is a valid satisfying witness.

If no mismatch is observed and at least one unit coordinate remains hidden, two positive-probability completions remain:

- UNSAT with $s=t$;
- SAT with the unique flip located at an unobserved coordinate.

Hence no safe non-abstaining claim exists at such a leaf.

If the forbidden assignment itself is unobserved, the same two truth sides remain compatible, so no safe certificate is possible there either.

### Theorem G — exact Gamma frontier

With $q\le14$, at most $q-1$ unit coordinates can be compared against an observed target. Conditional on SAT, the flipped coordinate is uniform over fourteen locations. Therefore

$$
\Pr(\text{safe mismatch certificate})
=
\frac12\frac{q-1}{14}
=
\frac{q-1}{28}
$$

for $2\le q\le14$, while $q\le1$ certifies nothing.

Thus

$$
\boxed{
C_G^\star(q)=0
\quad(0\le q\le1),
}
$$

$$
\boxed{
C_G^\star(q)=\frac{q-1}{28}
\quad(2\le q\le14),
}
$$

and full observation gives

$$
\boxed{C_G^\star(15)=1.}
$$

Adaptivity cannot improve the restricted term because, before the mismatch is found, the unqueried unit coordinates remain exchangeable with respect to the uniform flip location.

---

## 5. Exact vector frontier

For a B2-RQ profile vector

$$
\mathbf q=(q_A,q_B,q_G),
$$

with twenty tasks per family, the optimal expected certified coverage is

$$
\boxed{
C^\star(\mathbf q)
=
\frac13
\left(
C_A^\star(q_A)
+
C_B^\star(q_B)
+
C_G^\star(q_G)
\right).
}
$$

For the v0.3.0 R1 vector

$$
\mathbf q_{R1}=(7,12,14),
$$

this gives

$$
C^\star(\mathbf q_{R1})
=
\frac13
\left(
\frac38+
\frac12+
\frac{13}{28}
\right)
=
\boxed{\frac{25}{56}}.
$$

Therefore the old R1 reference value is now promoted from a constructive lower bound to the exact safe-certification optimum.

For sixty tasks,

$$
60C^\star(\mathbf q_{R1})
=
\boxed{\frac{375}{14}}
\approx26.78571429.
$$

A two-hidden-premise vector

$$
(6,11,13)
$$

has exact optimal mean

$$
\boxed{\frac{13}{56}},
$$

while full observation

$$
(8,13,15)
$$

gives

$$
\boxed{1}.
$$

---

## 6. Information cliffs

The exact curves are strongly non-concave near complete observation.

For Alpha,

$$
C_A^\star(7)=\frac38,
\qquad
C_A^\star(8)=1,
$$

so the final observation has marginal value

$$
\boxed{\frac58}.
$$

For Beta,

$$
C_B^\star(11)=0,
\quad
C_B^\star(12)=\frac12,
\quad
C_B^\star(13)=1.
$$

For Gamma,

$$
C_G^\star(14)=\frac{13}{28},
\qquad
C_G^\star(15)=1,
$$

so the final observation contributes

$$
\boxed{\frac{15}{28}}.
$$

These jumps are not numerical artifacts. They arise from certificate geometry: the last hidden premise can carry a disproportionate amount of **certification authority** even when much of the truth side is already inferable.

---

## 7. Relation to query and certificate complexity

The framework is adjacent to classical decision-tree and certificate-complexity models, but the measured objective is different. Standard certificate complexity asks how many queried coordinates suffice to force a function value, while SDPE-BEB additionally separates truth declaration, legal route closure, witness evidence, managed observation access, and post-session audit authority.

Useful related primary sources include:

1. Guy Blanc, Caleb Koch, Jane Lange, and Li-Yang Tan, *The Query Complexity of Certification*, arXiv:2201.07736.
2. *Query Complexity with Unknowns*, arXiv:2412.06395.
3. Andrew H. H. Liu et al., *Instance Complexity of Boolean Functions*, arXiv:2309.15026.

These references provide neighboring query/certificate-complexity language. The exact three-family frontier proved here is specific to the SDPE-BEB generator and safe-certification contract.

---

## 8. Machine-checkable companions

The release includes:

- `tools/optimal_frontier.py`, which emits every exact fraction and marginal gain;
- `tools/verify_optimality_lemmas.py`, which checks finite structural lemmas used in the proof;
- `baselines/optimal_frontier_exact.json`;
- `baselines/optimality_lemma_checks.json`.

The finite checker is a consistency aid, not a substitute for the written proof.
