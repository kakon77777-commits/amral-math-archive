# SDPE-BEB v0.5.0 — Global-Budget Audit Contract

## 1. Receipt-bound budget authority

An official audit requires the pre-query start receipt. The receipt pins

$$
Q,
$$

the profile hash, corpus commitment, descriptor manifest hash, evaluator public key, and transcript genesis.

A reveal may not retroactively choose a different budget.

## 2. Global accounting invariant

Let $N_i$ be the cumulative number of successful premise observations after event $i$.

The semantic replay must satisfy

$$
N_0=0,
$$

$$
N_{i+1}-N_i\in\{0,1\},
$$

and

$$
\boxed{
N_i\le Q
}
$$

for every event.

A successful `observe_premise` event increments $N_i$ by one. Failed requests never consume hidden observations.

## 3. No over-budget leakage

If

$$
N_i=Q,
$$

then the next observation request must return an error without a predicate payload.

## 4. Task-local cap invariant

For every task $t$,

$$
q_t^{\mathrm{used}}\le m_{F(t)}.
$$

The task caps are

$$
8,
13,
15
$$

for Alpha, Beta, and Gamma respectively.

## 5. Certification invariants

The authority separation remains

$$
\boxed{
\text{label correctness}
\neq
\text{evidence support}
\neq
\text{certification authority}.
}
$$

A true claim requires a terminal legal closure; a false claim requires a witness valid against the complete hidden task.

## 6. Final summary

The final summary must report the exact

- session observation budget;
- successful observation count;
- utilization;
- certified closure count;
- certified counterexample count;
- unsupported claim count;
- per-family observation usage.

The auditor recomputes the summary from the signed transcript rather than trusting the serialized summary.
