# SDPE-BEB v0.5.0 — Shared Global-Budget Allocation Envelope

## 1. Scope

Version v0.5.0 replaces independent per-family observation caps with one session-level resource:

$$
\boxed{
\sum_{t\in T} Q_t^{\mathrm{used}}\le Q.
}
$$

Every task keeps its full local premise cap, but all successful premise observations consume the same globally committed session budget $Q$.

The mathematical objective is safe certification coverage under shared resources. The crucial distinction is between three policy classes:

1. **precommitted allocation**: each task receives a cap before any observations are seen;
2. **single-pass adaptive recycling**: after a task is selected, a local cap may be chosen, early certification returns unused observations to the global pool, and an uncertified task is abandoned after its cap;
3. **unrestricted adaptive scheduling**: a policy may interleave and revisit partially observed tasks.

This release solves the first class exactly, solves the second class by an exact finite dynamic program, and places the third class inside a rigorous lower/upper envelope. It does **not** claim that the unrestricted adaptive optimum has been solved.

Let

$$
V_{\mathrm{PC}}(Q),
\qquad
V_{\mathrm{CR}}(Q),
\qquad
V_{\mathrm{A}}^\star(Q),
\qquad
U_{\mathrm{CL}}(Q)
$$

denote respectively the precommitted optimum, capped-recycling optimum, unrestricted safe-adaptive optimum, and semantic-clairvoyant upper bound.

The main envelope is

$$
\boxed{
V_{\mathrm{PC}}(Q)
\le
V_{\mathrm{CR}}(Q)
\le
V_{\mathrm{A}}^\star(Q)
\le
U_{\mathrm{CL}}(Q),
\qquad
0\le Q\le720.
}
$$

---

## 2. Single-task exact frontiers inherited from v0.4.0

For Alpha,

$$
C_A^\star(q)
=
\frac12\frac{\binom q2}{\binom82}
\quad(0\le q\le7),
\qquad
C_A^\star(8)=1.
$$

For Beta,

$$
C_B^\star(q)=0
\quad(0\le q<12),
$$

$$
C_B^\star(12)=\frac12,
\qquad
C_B^\star(13)=1.
$$

For Gamma,

$$
C_G^\star(q)=0
\quad(0\le q\le1),
$$

$$
C_G^\star(q)=\frac{q-1}{28}
\quad(2\le q\le14),
\qquad
C_G^\star(15)=1.
$$

There are twenty independent fresh-session tasks from each family.

---

## 3. Exact precommitted frontier

Suppose task $i$ belongs to family $F_i$ and receives an observation cap $q_i$ before any hidden predicate is observed.

The expected number of certified tasks is additive:

$$
\mathbb E[N_{\mathrm{cert}}]
=
\sum_{i=1}^{60}C_{F_i}^\star(q_i).
$$

Hence

$$
\boxed{
V_{\mathrm{PC}}(Q)
=
\max_{\substack{0\le q_i\le m_{F_i}\\\sum_iq_i\le Q}}
\sum_iC_{F_i}^\star(q_i).
}
$$

This is a finite multiple-choice knapsack problem.

Define $D_i(Q)$ as the optimum after the first $i$ tasks. Then

$$
D_0(Q)=0
$$

and

$$
\boxed{
D_{i+1}(Q)
=
\max_{0\le q\le\min(Q,m_{F_{i+1}})}
\left[D_i(Q-q)+C_{F_{i+1}}^\star(q)\right].
}
$$

The release computes this recurrence using exact rational arithmetic for every

$$
Q\in\{0,1,\ldots,720\}.
$$

Therefore the precommitted curve in `baselines/shared_budget_static_and_clairvoyant.json` is exact rather than Monte Carlo.

---

## 4. Certification-time distributions

The v0.4.0 optimal within-task policies induce random stopping times when allowed to continue until safe certification.

### Alpha

For $2\le t\le7$,

$$
\Pr(T_A=t)=\frac{t-1}{56},
$$

and

$$
\Pr(T_A=8)=\frac{35}{56}.
$$

Thus

$$
\Pr(T_A\le q)=C_A^\star(q).
$$

### Beta

$$
\Pr(T_B=12)=\frac12,
\qquad
\Pr(T_B=13)=\frac12.
$$

### Gamma

For $2\le t\le14$,

$$
\Pr(T_G=t)=\frac1{28},
$$

while

$$
\Pr(T_G=15)=\frac{15}{28}.
$$

Again,

$$
\Pr(T_F\le q)=C_F^\star(q)
$$

for each family $F$.

These stopping times make global-budget recycling fundamentally different from static cap assignment: a task may certify before consuming its nominal full local budget.

---

## 5. Exact single-pass capped-recycling DP

Let

$$
R_{a,b,g}(Q)
$$

denote the optimal expected number of additional certificates when $a$ Alpha tasks, $b$ Beta tasks, $g$ Gamma tasks remain untouched and the shared budget is $Q$.

Choose a family $F$, choose a local cap $c$, run one untouched task from that family until either it certifies at stopping time $T_F\le c$ or the cap is exhausted, then permanently leave that task.

For the post-selection count vector $\mathbf n-e_F$,

$$
\boxed{
R_F(\mathbf n,Q;c)
=
\sum_{t\le c}p_F(t)
\left[1+R_{\mathbf n-e_F}(Q-t)\right]
+
\Pr(T_F>c)R_{\mathbf n-e_F}(Q-c).
}
$$

Therefore

$$
\boxed{
R_{\mathbf n}(Q)
=
\max_{F:n_F>0}
\max_{0\le c\le\min(Q,m_F)}
R_F(\mathbf n,Q;c).
}
$$

with boundary condition

$$
R_{0,0,0}(Q)=R_{\mathbf n}(0)=0.
$$

The benchmark value is

$$
\boxed{
V_{\mathrm{CR}}(Q)=R_{20,20,20}(Q).
}
$$

This recurrence is exact for the stated single-pass policy class.

### Finite full-cap lemma

`tools/global_recycling_dp.cpp` exhaustively evaluates every finite state

$$
(a,b,g,Q)
\in
\{0,\ldots,20\}^3\times\{0,\ldots,720\}
$$

that has at least one task remaining.

The number checked is

$$
\boxed{6{,}676{,}460}.
$$

For every checked state, at least one optimal action uses

$$
c=\min(Q,m_F)
$$

for its selected family. The checker found

$$
\boxed{0}
$$

states in which a strict partial cap was necessary for optimality.

Hence for this finite benchmark instance the capped-recycling value can be attained by a **nonpreemptive complete-until-certificate-or-budget-exhaustion policy**.

This is recorded as a finite computational lemma. The release does not promote it to a general stochastic-scheduling theorem.

---

## 6. Strict adaptivity gain

At global budget

$$
Q=8,
$$

the exact precommitted optimum is

$$
V_{\mathrm{PC}}(8)=1.
$$

The exact rational recycling DP gives

$$
V_{\mathrm{CR}}(8)
=
\boxed{
\frac{2521233}{2458624}
}
\approx1.02546505687734.
$$

Thus

$$
\boxed{
V_{\mathrm{CR}}(8)-V_{\mathrm{PC}}(8)
=
\frac{62609}{2458624}
>0.
}
$$

So early-stopping information has positive global resource value even before the unrestricted revisit/interleaving problem is considered.

The largest numerical gap between these two lower frontiers on the full finite curve occurs at

$$
Q=613,
$$

where

$$
V_{\mathrm{PC}}(613)=\frac{367}{7}\approx52.428571,
$$

while

$$
V_{\mathrm{CR}}(613)\approx58.483978.
$$

The absolute gain is approximately

$$
\boxed{6.055406}.
$$

The location of this maximum is a finite computed property of the present $20/20/20$ corpus size, not a universal theorem.

---

## 7. Exact semantic-clairvoyant upper bound

To bound every nonclairvoyant safe policy, give a stronger observer the full hidden semantic role information before spending any observation.

The minimal evidence costs for that observer are:

- Alpha UNSAT: $2$;
- Alpha SAT: $8$;
- Beta UNSAT: $12$;
- Beta SAT: $13$;
- Gamma SAT control: $2$;
- Gamma UNSAT: $15$.

Let

$$
U_A,U_B,S_G
\overset{\mathrm{ind}}{\sim}
\operatorname{Binomial}(20,1/2)
$$

count Alpha UNSAT instances, Beta UNSAT instances, and Gamma SAT controls.

For a realization $(u,v,w)$, form the multiset

$$
\mathcal C(u,v,w)
=
\{2^{\times(u+w)},
8^{\times(20-u)},
12^{\times v},
13^{\times(20-v)},
15^{\times(20-w)}\}.
$$

Let $K_Q(u,v,w)$ be the maximum number of smallest costs from this multiset whose sum is at most $Q$.

Then

$$
\boxed{
U_{\mathrm{CL}}(Q)
=
2^{-60}
\sum_{u=0}^{20}
\sum_{v=0}^{20}
\sum_{w=0}^{20}
\binom{20}{u}
\binom{20}{v}
\binom{20}{w}
K_Q(u,v,w).
}
$$

This finite sum is evaluated exactly with integer weights and denominator $2^{60}$.

Because the clairvoyant observer has strictly more information than an admissible participant,

$$
\boxed{
V_{\mathrm{A}}^\star(Q)
\le
U_{\mathrm{CL}}(Q).
}
$$

---

## 8. The shared-budget envelope

Combining the constructions,

$$
\boxed{
V_{\mathrm{PC}}(Q)
\le
V_{\mathrm{CR}}(Q)
\le
V_{\mathrm{A}}^\star(Q)
\le
U_{\mathrm{CL}}(Q).
}
$$

Selected values are:

| $Q$ | $V_{\mathrm{PC}}(Q)$ | $V_{\mathrm{CR}}(Q)$ | $U_{\mathrm{CL}}(Q)$ |
|---:|---:|---:|---:|
| $8$ | $1.000000$ | $1.025465$ | $4.000000$ |
| $40$ | $5.000000$ | $5.362830$ | $18.888772$ |
| $80$ | $10.000000$ | $11.032611$ | $24.624768$ |
| $120$ | $15.000000$ | $16.744612$ | $29.377420$ |
| $240$ | $26.035714$ | $28.248969$ | $39.483927$ |
| $290$ | $30.000000$ | $32.504339$ | $43.382910$ |
| $420$ | $40.000000$ | $43.310222$ | $52.866539$ |
| $570$ | $50.000000$ | $55.304439$ | $59.914382$ |
| $613$ | $52.428571$ | $58.483978$ | $59.998199$ |
| $720$ | $60.000000$ | $60.000000$ | $60.000000$ |

The envelope is intentionally widest at low-to-intermediate budgets because the clairvoyant observer knows which hidden instances possess two-query certificates before paying to discover them.

---

## 9. What remains open

The release does **not** identify

$$
V_{\mathrm{A}}^\star(Q)
$$

exactly.

An unrestricted adaptive policy may partially observe one task, switch to another, and later return to the first. Raw predicate semantics may alter posterior completion hazards, especially in Alpha.

Therefore the next mathematical problem is a finite-horizon partially observed scheduling problem rather than an ordinary knapsack problem.

A canonical Bellman form is

$$
\boxed{
V(B,\mathcal S)
=
\max_{a\in\mathcal A(\mathcal S)}
\mathbb E
\left[
 r(a)+V(B-1,\mathcal S')
\right],
}
$$

where $\mathcal S$ must retain the sufficient posterior state of every partially observed task.

This is the intended v0.6 frontier.

---

## 10. Related optimization language

The shared-budget problem is adjacent to adaptive stochastic knapsack and finite-horizon bandit/scheduling models. The comparison is conceptual only: SDPE-BEB retains its own safe-certification, evidence, route-authority, commitment, and post-session audit semantics.

Relevant neighboring primary literature includes:

1. Will Ma, *Improvements and Generalizations of Stochastic Knapsack and Markovian Bandits Approximation Algorithms*, arXiv:1306.1149.
2. Anupam Gupta et al., work on stochastic knapsack/orienteering and adaptivity gaps in the ACM-SIAM literature.
3. Daniel Blado and Alejandro Toriello, *Relaxation Analysis for the Dynamic Knapsack Problem with Stochastic Item Sizes*, SIAM Journal on Optimization.

The current release does not import approximation guarantees from those models.

---

## 11. Machine-checkable companions

The release includes:

- `tools/shared_budget_frontier.py` — exact rational precommitted curve and exact clairvoyant upper curve;
- `tools/global_recycling_dp.cpp` — full $6{,}676{,}460$-state capped-recycling DP;
- `tools/recycling_value.py` — memoized reference value and policy selector;
- `baselines/shared_budget_static_and_clairvoyant.json`;
- `baselines/global_recycling_frontier.csv`;
- `baselines/global_recycling_report.json`.

The finite computations support the stated finite-instance claims; they do not replace the policy-class definitions and inequalities above.
