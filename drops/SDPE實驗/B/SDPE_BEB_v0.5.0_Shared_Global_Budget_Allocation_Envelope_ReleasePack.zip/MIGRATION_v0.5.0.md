# Migration — v0.4.0 B2-RQ to v0.5.0 B2-GB

## Semantic change

v0.4.0 uses a vector of independent per-family caps:

$$
(q_A,q_B,q_G).
$$

v0.5.0 uses one session-wide budget:

$$
Q.
$$

Every task descriptor now exposes its full local premise cap. Resource scarcity is enforced only by the shared session counter.

## API change

Server option:

`--global-budget Q`

replaces

`--q-alpha`, `--q-beta`, `--q-gamma`.

HTTP paths move from `/v0.4/...` to `/v0.5/...`.

Successful premise responses now report both

- `remaining_task_observations`;
- `remaining_session_observations`.

## Audit change

Transcript semantic replay now maintains an independent session-wide observation counter and rejects any transcript that exceeds the committed budget.

## Mathematical change

The exact per-task frontiers from v0.4.0 become ingredients of a new global resource-allocation problem.

v0.5.0 separates:

$$
V_{\mathrm{PC}}(Q),
\quad
V_{\mathrm{CR}}(Q),
\quad
V_{\mathrm{A}}^\star(Q),
\quad
U_{\mathrm{CL}}(Q).
$$

The unrestricted adaptive optimum remains intentionally open.
