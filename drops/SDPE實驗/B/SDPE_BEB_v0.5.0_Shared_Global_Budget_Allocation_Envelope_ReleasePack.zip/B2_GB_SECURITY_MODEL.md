# SDPE-BEB v0.5.0 — Shared-Budget Security Model

## 1. Security goal

B2-GB is a managed-query benchmark profile. It aims to ensure that a participant cannot obtain more than $Q$ evaluator-mediated premise observations in one committed session.

It is not an information-theoretic secrecy system and does not claim B3 cryptographic blindness.

## 2. Fresh corpus generation

The corpus continues to use a fresh 256-bit session seed expanded by the deterministic HMAC-SHA256 counter PRF introduced in v0.4.0.

Post-session reveal publishes the seed, allowing deterministic corpus regeneration and exact comparison with the committed tasks.

## 3. Budget pinning

The global budget is part of the profile specification. The profile specification hash is included in transcript genesis and is present in the pre-query start receipt.

Thus

$$
\boxed{
Q_{\mathrm{start}}
=Q_{\mathrm{reveal}}
}
$$

is an audited condition rather than a convention.

## 4. No free action channel

The requirement

$$
D(a)\subseteq O_t
$$

continues to prevent action execution from exposing or applying hidden predicates whose premise handles were never observed.

## 5. Threats outside this reference profile

The reference implementation does not by itself solve:

- participant authentication across multiple evaluator deployments;
- network-layer rate limiting;
- compromised evaluator hosts;
- collusion between participants across separately admitted fresh sessions;
- side channels outside the JSON protocol;
- unrestricted adaptive-policy optimality.

A production deployment should place the evaluator behind an attempt coordinator that enforces admission and preserves the start receipt externally.
