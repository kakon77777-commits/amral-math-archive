# SDPE-BEB v0.5.0 — B2-GB Public Protocol

## 1. Profile

The profile identifier is

`B2-GB-Qxxxx`,

where `xxxx` is the zero-padded shared observation budget

$$
0\le Q\le720.
$$

The start receipt commits the profile specification before the first observation.

## 2. Shared observation budget

Every successful premise observation costs exactly one unit from the same session budget:

$$
\boxed{
\sum_t q_t^{\mathrm{used}}\le Q.
}
$$

The evaluator returns `remaining_session_observations` after every successful observation.

Once the shared budget reaches zero, every further premise observation is rejected with

`session-observation-budget-exhausted`

and no hidden predicate is returned.

## 3. Local task caps

A task may never reveal more than its complete premise set:

$$
m_A=8,
\qquad
m_B=13,
\qquad
m_G=15.
$$

These local caps are not resource allocations. They are only hard disclosure ceilings. The session budget determines how observations are distributed across tasks.

## 4. Action dependency rule

The v0.4.0 dependency rule remains mandatory:

$$
\boxed{
D(a)\subseteq O_t.
}
$$

Executing an action does not provide a free query channel into unobserved premises.

## 5. Submission semantics

Each task must end in exactly one of:

- `claim_true` with a legal terminal closure;
- `claim_false` with a valid satisfying witness;
- `undecided`.

Every one of the sixty committed tasks must be finalized before the session can finalize.

## 6. No truth feedback during the session

Truth labels remain hidden until finalization and reveal. The shared budget therefore cannot be adaptively allocated using evaluator-provided truth feedback.

## 7. Auditability

The final reveal contains enough material to recheck:

- generation-seed replay;
- task commitments;
- corpus root;
- descriptor manifest;
- exact Oracle semantics;
- global observation accounting;
- per-task disclosure caps;
- action dependency legality;
- transcript hash chain;
- Ed25519 signature;
- start-receipt binding.
