# SDPE-BEB v0.5.0 — Shared Global-Budget Allocation Envelope

Version v0.5.0 replaces independent per-task or per-family query caps with one session-level observation resource:

$$
\boxed{
\sum_{t\in T}Q_t^{\mathrm{used}}\le Q.
}
$$

The release separates four mathematical quantities:

$$
V_{\mathrm{PC}}(Q),
\qquad
V_{\mathrm{CR}}(Q),
\qquad
V_{\mathrm A}^{\star}(Q),
\qquad
U_{\mathrm{CL}}(Q).
$$

They satisfy the certified envelope

$$
\boxed{
V_{\mathrm{PC}}(Q)
\le
V_{\mathrm{CR}}(Q)
\le
V_{\mathrm A}^{\star}(Q)
\le
U_{\mathrm{CL}}(Q),
\qquad 0\le Q\le720.
}
$$

Here:

- $V_{\mathrm{PC}}$ is the exact precommitted multiple-choice-knapsack frontier;
- $V_{\mathrm{CR}}$ is the exact finite single-pass capped-recycling frontier;
- $V_{\mathrm A}^{\star}$ is the unrestricted adaptive safe-certification optimum and remains intentionally open;
- $U_{\mathrm{CL}}$ is an exact semantic-clairvoyant upper bound.

The finite capped-recycling DP evaluates $6{,}676{,}460$ states. It finds zero states in which a strict partial cap is required for an optimal action. This is a finite computational lemma for this benchmark, not a universal scheduling theorem.

At $Q=8$ the release proves strict positive value from recycling:

$$
V_{\mathrm{PC}}(8)=1,
$$

$$
V_{\mathrm{CR}}(8)=\frac{2521233}{2458624},
$$

and therefore

$$
\boxed{
V_{\mathrm{CR}}(8)-V_{\mathrm{PC}}(8)
=
\frac{62609}{2458624}>0.
}
$$

A frozen live evaluator run at $Q=290$ is included in Full Dev. Its DP expectation is approximately $32.504339$ certificates; the fresh realization produced $32$ certified tasks using exactly $290$ observations, with zero unsupported claims and accuracy $1$ on attempted claims. The full receipt-bound audit passes.

The package split is deliberate:

- `SDPE_BEB_B2GB_Participant_v0.5.0.zip` — participant-safe public protocol/client/baselines;
- `SDPE_BEB_B2GB_Evaluator_v0.5.0.zip` — evaluator-private runtime and auditor;
- `SDPE_BEB_B2GB_Full_Dev_v0.5.0.zip` — full source, exact-DP tools, tests, reference policy, and frozen session;
- `SDPE_BEB_v0.4.0_Exact_Optimal_Adaptive_Certification_Frontier_ReleasePack.zip` — lineage reference.

The next mathematical frontier is the exact unrestricted interleaving/revisit value $V_{\mathrm A}^{\star}(Q)$ via sufficient posterior states and finite-horizon adaptive scheduling.
