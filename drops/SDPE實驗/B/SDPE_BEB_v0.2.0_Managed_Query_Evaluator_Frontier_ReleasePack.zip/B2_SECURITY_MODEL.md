# SDPE-BEB v0.2.0 Security and Blindness Model

## Why v0.1.x cannot simply be moved behind an API

The v0.1.x Neutral Variant corpus is already public. Its exact premises have been distributed. Therefore placing those same sixty tasks behind an evaluator would not create meaningful managed-query blindness: a participant could identify an instance and solve it from the historical corpus without consuming evaluator observations.

v0.2.0 therefore uses fresh-session generation. The generator family is public, while the session seed and concrete hidden predicates remain evaluator-private until post-session reveal.

## Claimed level

The reference architecture targets B2 managed-query blindness under the operational assumption

$$
\text{participant process}\cap\text{evaluator private state}=\varnothing.
$$

The claim does not survive evaluator compromise, state-directory access, debugger access to the server process, or disclosure of the Full-Dev bundle during the measured run.

## Explicit non-claims

v0.2.0 does not claim secure multi-party computation, zero-knowledge evaluation, trusted execution, or resistance to a malicious evaluator operator. Ed25519 is used for transcript integrity and evaluator attribution; it does not by itself make the hidden mathematical state cryptographically opaque.

Thus

$$
\text{signed transcript integrity}\not\Rightarrow B3.
$$
