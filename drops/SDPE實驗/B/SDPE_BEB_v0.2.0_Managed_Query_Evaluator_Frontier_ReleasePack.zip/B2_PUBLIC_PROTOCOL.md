# SDPE-BEB v0.2.0 B2 Public Protocol

The v0.2 line changes the benchmark topology rather than repackaging the already-public v0.1 corpus.

The evaluator generates a fresh hidden corpus for each session. Task, action, and constraint identifiers are freshly rebound. Truth values are sampled independently rather than fixed to an exact within-family balance.

Before the first hidden-premise observation, the evaluator returns a corpus commitment root and a descriptor-manifest hash. The participant receives public task descriptors containing family, budgets, opaque constraint handles, the neutral action graph, and per-task commitments, but not the hidden premise predicates.

A hidden premise is obtained only through a metered `premise` query. Each task has a finite observation budget. Repeated observations consume budget again. An over-budget request is rejected without returning the predicate.

Action execution is stateful and monotone. It enforces unlock, prerequisite, step, cost, and certificate rules server-side. Execution returns terminal closure status but withholds survivor-set size and survivor assignments.

A task may be submitted once. `claim_true` is evidence-supported only by a server-verified terminal closure. `claim_false` is evidence-supported only by a satisfying integer witness. `undecided` is an abstention. After submission, the task is terminal and cannot be queried or replayed further.

Truth feedback is withheld until all tasks have been finalized. Post-session reveal publishes the hidden corpus, oracle records, nonces, transcript, transcript head, and evaluator signature for independent audit.

This realizes managed-query blindness only when evaluator-private state is operationally separated from the participant. Possession of the Evaluator or Full-Dev bundle collapses the deployment back to a development environment.
