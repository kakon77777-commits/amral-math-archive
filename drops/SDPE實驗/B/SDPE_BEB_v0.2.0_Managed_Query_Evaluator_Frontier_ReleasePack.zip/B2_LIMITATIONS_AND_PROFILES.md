# SDPE-BEB v0.2.0 Limitations and Profiles

## Current profile: B2-C

v0.2.0 implements the **B2-C complete-observation managed profile**. For every task, the observation budget equals the number of hidden premises:

$$
Q_t=|P_t|.
$$

Therefore a participant may legally observe every hidden premise exactly once if it spends the full observation budget. The benchmark does not claim information-theoretic secrecy of the premises during a completed task.

The gain over B1 is architectural rather than magical: the concrete session corpus is fresh, unavailable before the session, accessed only through a metered interface, replay telemetry is evaluator-controlled, task submission is terminal, and all activity is auditable.

Thus

$$
B2\text{-C}\neq\text{partial-information challenge}.
$$

A future B2-R profile may impose

$$
Q_t<|P_t|
$$

or differential query costs, but that changes the mathematical difficulty and should be benchmarked separately rather than silently changing v0.2.0.

## Cross-session learning

The generator families and protocol are public. Participants may learn family-level strategies across sessions. Fresh generation prevents lookup of concrete hidden predicate values, not learning of reusable mathematics.

## Evaluator trust

The corpus root prevents post-query substitution of the committed session corpus once the start receipt is preserved. Ed25519 binds the final transcript to the public key pinned in that receipt. These mechanisms do not prove that the evaluator implementation was benevolent or free of covert side channels.

## Crash behavior

The reference server maintains active survivor state in memory, writes an immutable start checkpoint, appends every event to a journal, and writes a full final checkpoint. Automatic mid-session crash recovery is not implemented in v0.2.0. A production deployment should either add deterministic journal replay recovery or treat a server crash as a voided session with a new session identifier and fresh corpus.

## Session admission

The reference server defaults to one issued session per evaluator process. This prevents participant-controlled unlimited corpus issuance within a measured attempt. Multi-user deployments should place authentication and attempt allocation in an external coordinator and isolate evaluator state per authorized attempt.
