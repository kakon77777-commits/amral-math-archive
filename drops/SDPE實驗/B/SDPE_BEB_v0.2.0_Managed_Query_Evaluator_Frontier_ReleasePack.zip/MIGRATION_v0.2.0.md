# Migration from v0.1.4 to v0.2.0

v0.1.4 remains the canonical B1 static-corpus release. v0.2.0 does not rewrite or supersede its mathematical records.

The v0.2 line introduces a new deployment topology:

1. fresh hidden corpus per session;
2. independent truth sampling rather than exact public-family balance;
3. session-random opaque task/action/constraint identifiers;
4. evaluator-side hidden premises;
5. metered premise observation;
6. stateful evaluator-side action execution;
7. terminal one-shot task submission;
8. pre-query corpus and descriptor commitments;
9. hash-chained session transcript;
10. Ed25519 final transcript signature;
11. post-session exact reveal audit.

Because the old sixty instances were already public, they remain useful for B1 regression but are not reused as the B2 challenge corpus.
