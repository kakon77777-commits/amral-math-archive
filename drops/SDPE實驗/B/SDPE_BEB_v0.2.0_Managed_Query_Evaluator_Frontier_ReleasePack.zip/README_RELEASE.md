# SDPE-BEB v0.2.0 — Managed-Query Evaluator Frontier Release

This release starts the B2 line. It preserves v0.1.4 as the B1 regression reference while introducing a fresh-session evaluator architecture.

Artifacts:

- `SDPE_BEB_B2_Participant_v0.2.0.zip`: public participant-facing client and protocol only.
- `SDPE_BEB_B2_Evaluator_v0.2.0.zip`: evaluator-private reference server and audit logic.
- `SDPE_BEB_B2_Full_Dev_v0.2.0.zip`: combined development and testing bundle; never use this as a blind participant bundle.
- `SDPE_BEB_v0.1.4_Corpus_Integrity_Canonical_Replay_and_Oracle_Sync_ReleasePack.zip`: unchanged B1 lineage reference.

B2 is claimed only for a deployment that operationally separates the participant from evaluator-private code, state, seed, and generated hidden corpus.
