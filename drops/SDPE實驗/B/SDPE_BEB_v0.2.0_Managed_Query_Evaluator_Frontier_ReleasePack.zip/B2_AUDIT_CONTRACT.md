# SDPE-BEB v0.2.0 B2 Audit Contract

For a session with opaque task set $T$, let $q_t$ be the number of hidden-premise observations consumed for task $t$, and let $Q_t$ be its observation budget. A legal managed-query session requires

$$
0\le q_t\le Q_t
$$

for every task. No rejected over-budget request may disclose the hidden predicate.

Let $R_t=(a_1,\ldots,a_k)$ be the server-executed action path. The evaluator enforces

$$
k\le B_t
$$

and

$$
\sum_{i=1}^{k} c(a_i)\le C_t.
$$

The survivor state is private evaluator state. Only terminality is exposed:

$$
\chi_t(R_t)=
\begin{cases}
1,&S_k=\varnothing,\\
0,&S_k\ne\varnothing.
\end{cases}
$$

No survivor cardinality or survivor assignment is returned during the managed session.

A task submission is terminal. Therefore

$$
\operatorname{Submit}(t)\Longrightarrow
\text{no further observe or execute operation on }t.
$$

For session commitment, each hidden task/oracle pair has commitment

$$
c_t=H(\operatorname{canon}(t,O_t)\Vert n_t),
$$

and the pre-query corpus root is

$$
C=H(\operatorname{canon}([(t,c_t)]_{t\in T})).
$$

The public descriptor manifest has hash $D$. The transcript genesis is

$$
h_0=H(\texttt{protocol}\Vert\texttt{session}\Vert C\Vert D\Vert K_{pub}),
$$

and each evaluator event extends the chain by

$$
h_i=H(h_{i-1}\Vert\operatorname{canon}(e_i)).
$$

At session start the participant preserves the returned start receipt containing $C$, $D$, $h_0$, and $K_{pub}$. At finalization the evaluator signs $h_m$ with Ed25519. Official post-session audit requires that pre-query receipt and verifies the corpus root, descriptor hash, exact finite oracle semantics, transcript chain, pinned public key, and signature.

The authority separation remains

$$
\text{label correctness}
\neq
\text{evidence support}
\neq
\text{certification authority}.
$$
