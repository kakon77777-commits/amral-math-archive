# SDPE-BEB v0.1.3 Protocol-Semantics and Relational-Integrity Release Pack

This release keeps the original v0.1.1 mathematical benchmark and v0.1.2 runtime hardening, then repairs a semantic conflation in submission/audit logic.

The key invariant is:

$$
\text{route not closed}
\not\Rightarrow
\text{public claim false}.
$$

Use `SDPE_BEB_NeutralVariant_Public_v0.1.3.zip` for blind participants. Keep Full Dev and Oracle separate until reveal.

The mathematical dataset, Oracle answers/nonces/commitments, and dataset fingerprint are unchanged.
