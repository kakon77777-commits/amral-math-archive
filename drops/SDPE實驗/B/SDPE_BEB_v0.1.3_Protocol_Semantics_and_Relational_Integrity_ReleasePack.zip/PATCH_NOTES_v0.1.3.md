# SDPE-BEB v0.1.3 Protocol-Semantics Repair

## Repaired

1. `declared_closed` is now route-only and is no longer interpreted as a truth label.
2. New required `declared_label` separates `claim_true`, `claim_false`, and `undecided`.
3. A failed route with no witness is an abstention, not an implicit SAT prediction.
4. `claim_true` requires an in-budget replayed closure; `claim_false` requires a satisfying witness.
5. Cross-reference/action-graph relational integrity is validated independently of JSON Schema.
6. Blindness claims are explicitly stratified as B0/B1/B2/B3; this local release claims B1 only.

## Preserved

- mathematical task premises/actions/budgets;
- Oracle answers/nonces/commitments;
- dataset fingerprint `226fae3dd0740f2bd6eac1c07879c8b3fdbb552fa28a71fc180081690761f34a`;
- v0.1.2 preflight budget rejection and survivor-list hiding.
