# v0.1.2 → v0.1.3 Semantic Migration

The v0.1.2 field `declared_closed` had two incompatible uses in audit logic: it described whether the selected route closed, but it was also used as the submitted truth label. This caused an unclosed route to be counted as a false-claim/SAT prediction even when the participant supplied no counterexample.

v0.1.3 repairs this by adding required `declared_label` with values `claim_true`, `claim_false`, or `undecided`.

The canonical separation is:

$$
\text{route failure}
\not\Rightarrow
\text{claim false}.
$$

$$
\text{claim true certificate}
=
\text{verified in-budget closure}.
$$

$$
\text{claim false certificate}
=
\text{verified satisfying witness}.
$$

This is a package/protocol revision only. The mathematical dataset and Oracle commitments are unchanged.
