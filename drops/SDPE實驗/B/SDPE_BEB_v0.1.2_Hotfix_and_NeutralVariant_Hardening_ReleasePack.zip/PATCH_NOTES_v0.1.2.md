# SDPE-BEB v0.1.2 Patch Notes

## Fixed

1. Neutral Public `tools/public_runner.py` no longer fails on import: `common.universe()` is present.
2. Over-budget `replay` selections are rejected before exact survivor evaluation, closing the documented public-runner ground-truth-probe bypass.
3. Replay output exposes `final_survivor_size` only; the explicit survivor assignment list is removed.
4. Public exact truth-balance metadata is withheld pre-reveal. The Alpha-family `protocol_note` no longer states that labels are balanced within family.
5. Full Dev `validate_bundle.py` now executes `inspect`, `replay`, and `verify-submission` as integration smoke tests and tests over-budget rejection.

## Preserved

- Neutral task mathematical constraints and actions;
- step and cost budgets;
- all Oracle answer records and nonces;
- all Oracle commitments;
- dataset fingerprint `226fae3dd0740f2bd6eac1c07879c8b3fdbb552fa28a71fc180081690761f34a`;
- structural benchmark result: 30 certified closures + 30 certified counterexamples, with zero false certified closures.

The dataset schema/version remains `sdpe-beb-neutral-v0.1.1`; `v0.1.2` is the package/runtime hardening revision.
