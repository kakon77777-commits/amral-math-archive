# SDPE-BEB v0.1.2 Hotfix / Neutral Variant Hardening Release Pack

This package keeps the original **Audit Integrity Repair v0.1.1** artifacts unchanged and replaces the Neutral Variant packaging/runtime with **package v0.1.2**.

The mathematical Neutral Variant dataset remains schema/version `sdpe-beb-neutral-v0.1.1`: constraints, actions, budgets, Oracle answer records, commitments, and the dataset fingerprint are unchanged. Twenty Alpha task files have only their public `protocol_note` changed to remove the family-balance disclosure.

## Blind distribution rule

For a blind participant, distribute only:

`SDPE_BEB_NeutralVariant_Public_v0.1.2.zip`

Keep the Oracle bundle separate. `Full_Dev` is for development/audit and contains non-blind material.

## v0.1.2 hardening

- repairs the missing `universe()` helper used by `public_runner.py`;
- adds preflight step/cost budget rejection before survivor evaluation;
- removes explicit `final_survivor` assignment-list output;
- removes exact pre-reveal class-balance disclosure from Public metadata and Alpha task notes;
- adds public CLI integration smoke tests and budget-bypass regression checks to Full Dev validation;
- preserves Oracle answer records and commitments.
