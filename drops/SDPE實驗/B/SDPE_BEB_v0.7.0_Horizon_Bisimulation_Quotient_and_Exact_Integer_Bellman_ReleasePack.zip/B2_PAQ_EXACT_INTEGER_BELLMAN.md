# SDPE-BEB v0.7.0 — Exact Common-Denominator Bellman Arithmetic

## 1. Motivation

The v0.6.0 reference implementation stored every Bellman value as a reduced rational number. At several million memoized states, repeated numerator/denominator normalization becomes a computational bottleneck even though every transition probability comes from a small fixed finite set.

Version v0.7.0 replaces repeated rational normalization by an exactly equivalent common-denominator recurrence.

---

## 2. Universal local denominator

Write every transition probability in lowest terms as

$$
p_j=\frac{a_j}{d_j}.
$$

For the complete released posterior kernel,

$$
\boxed{
L=\operatorname{lcm}_j d_j
=160626866400.
}
$$

Every $d_j$ divides $L$.

Define

$$
D_h=L^h.
$$

---

## 3. Integer Bellman transform

Let $V_h(x)$ be the exact Bellman value of quotient state $x$ with $h$ observations remaining. Define

$$
Z_h(x)=D_hV_h(x).
$$

Then $Z_h(x)$ is an integer for every reachable state and horizon.

Suppose action $a$ has branches $j$ with probability $a_j/d_j$, immediate reward $r_j$, and successor $x_j$. Then

$$
V_h^a(x)
=
\sum_j
\frac{a_j}{d_j}
\left(
 r_j+V_{h-1}(x_j)
\right).
$$

Multiplying by $D_h=LD_{h-1}$ gives

$$
\boxed{
Z_h^a(x)
=
\sum_j
 a_j\frac{L}{d_j}
\left(
 r_jD_{h-1}+Z_{h-1}(x_j)
\right).
}
$$

Every quantity on the right is an integer. Therefore

$$
\boxed{
Z_h(x)=\max_a Z_h^a(x)
}
$$

can be computed using only exact big-integer addition, multiplication by fixed machine-size coefficients, comparison, and memoization.

The reduced rational value is needed only at output time:

$$
V_h(x)
=
\frac{Z_h(x)/g}{D_h/g},
\qquad
 g=\gcd(Z_h(x),D_h).
$$

---

## 4. Exactness theorem

### Theorem 4.1

The common-denominator integer recurrence returns exactly the same Bellman value as direct rational arithmetic at every horizon represented by the same quotient kernel.

### Proof

The claim follows by induction on $h$. At $h=0$, both recurrences return zero. Assume

$$
Z_{h-1}(y)=D_{h-1}V_{h-1}(y)
$$

for all successor states $y$. Substitution into the branch expectation gives the displayed integer formula for every action. Multiplication by the positive constant $D_h$ preserves the ordering of action values, so the maximizing action is unchanged. Hence

$$
Z_h(x)=D_hV_h(x).
$$

$\square$

---

## 5. Independent arithmetic implementations

Full-Dev contains two exact implementations of the same recurrence:

1. `posterior_bellman_integer_boost.cpp` using Boost `cpp_int`;
2. `posterior_bellman_integer_gmp.cpp` using GMP `mpz_class`.

They independently reproduce every released fraction through

$$
Q=19.
$$

The Python `Fraction` horizon-quotient implementation independently agrees through the smaller range used for routine cross-validation. The v0.6.0 raw-state rational solver also agrees on the entire previously released prefix.

---

## 6. Certified computational boundary

The released exact baseline stops at

$$
\boxed{Q=19}.
$$

This is a release boundary, not a mathematical singularity. The same quotient and integer recurrence remain well-defined at $Q=20$, but v0.7.0 does not publish an exact $Q=20$ value because the global occupancy state count still expands sharply.

A computational limit is not promoted into a theorem.
