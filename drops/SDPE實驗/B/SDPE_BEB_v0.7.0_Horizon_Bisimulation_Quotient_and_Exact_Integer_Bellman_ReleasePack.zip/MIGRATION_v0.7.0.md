# Migration to SDPE-BEB v0.7.0

## From v0.6.0

Version v0.6.0 established posterior-state unrestricted Bellman semantics, exact values through $Q=12$, and a full-range productivity-dual envelope.

Version v0.7.0 adds two exact analysis reductions:

$$
\boxed{
\text{finite-horizon behavioral bisimulation}
}
$$

and

$$
\boxed{
\text{common-denominator integer Bellman arithmetic}.
}
$$

Together they extend the exact unrestricted prefix to

$$
\boxed{Q\le19}.
$$

The evaluator runtime and audit contract remain wire-compatible with v0.6.0.

### New public artifacts

- `B2_PAQ_HORIZON_BISIMULATION_THEOREMS.md`
- `B2_PAQ_EXACT_INTEGER_BELLMAN.md`
- `B2_PAQ_RUNTIME_COMPATIBILITY.md`
- `posterior_bellman_exact_prefix_Q0_Q19.json`
- `horizon_bisimulation_report.json`
- `integerization_report.json`
- `state_reduction_report.json`
- `horizon_bisimulation.py`
- `posterior_bellman_quotient.py`
- `posterior_bellman_integer_boost.cpp`

Full-Dev additionally contains an independent GMP big-integer implementation.

### Claim migration

Replace the v0.6.0 statement

$$
V_{\mathrm A}^{\star}(Q)\text{ is exact for }0\le Q\le12
$$

with

$$
\boxed{
V_{\mathrm A}^{\star}(Q)\text{ is exact for }0\le Q\le19.
}
$$

Do not infer an exact $Q=20$ result from this migration.
