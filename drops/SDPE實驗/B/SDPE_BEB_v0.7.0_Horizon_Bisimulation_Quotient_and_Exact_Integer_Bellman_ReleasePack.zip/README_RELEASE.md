# SDPE-BEB v0.7.0 — Horizon-Bisimulation Quotient and Exact-Integer Bellman Extension

Version v0.7.0 extends the exact unrestricted posterior-adaptive benchmark frontier without changing the managed evaluator wire protocol.

The central new results are:

$$
\boxed{
\text{finite-horizon behavioral bisimulation}
}
$$

and

$$
\boxed{
Z_h=L^hV_h,
\qquad
L=160626866400,
}
$$

which converts the Bellman recursion into exact big-integer arithmetic on a horizon-dependent quotient state space.

The certified exact unrestricted prefix is now

$$
\boxed{0\le Q\le19}.
$$

The newest point is

$$
\boxed{
V_{\mathrm A}^{\star}(19)
=
\frac{656751940350557909}{285618310742016000}
\approx2.299404189613625.
}
$$

The local horizon quotient has class counts

$$
1,29,36,38,40,42,44,45,46,47,48,49,49,\ldots
$$

and the quotient is exact Bellman lumping, not heuristic pruning.

The runtime protocol remains

```text
sdpe-beb-b2pa-v0.6.0
```

because the server, core, and auditor semantics are unchanged. The v0.7 evaluator package records byte-identical runtime-core hashes relative to v0.6.

## Inner packages

- `SDPE_BEB_B2PAQ_Participant_v0.7.0.zip` — participant-safe public mathematics, exact baseline, Boost big-integer solver, and verifier.
- `SDPE_BEB_B2PAQ_Evaluator_v0.7.0.zip` — evaluator-private v0.6-compatible managed runtime plus v0.7 analysis documentation.
- `SDPE_BEB_B2PAQ_Full_Dev_v0.7.0.zip` — complete source, both Boost and GMP exact solvers, tests, frozen lineage fixtures, and audit material.
- `SDPE_BEB_v0.6.0_Posterior_State_Bellman_and_Productivity_Envelope_ReleasePack.zip` — previous release retained for lineage comparison.

## Independent arithmetic cross-check

The Boost `cpp_int` and GMP `mpz_class` implementations independently reproduce all twenty released exact fractions for

$$
Q=0,1,\ldots,19.
$$

The public Python `Fraction` quotient solver independently cross-checks the routine prefix.

## Scope boundary

Version v0.7.0 does **not** claim an exact value for

$$
Q=20.
$$

The fresh-reservoir reduction is still valid there, but the global occupancy state explosion has not been eliminated enough to publish a validated exact $Q=20$ result in this release.
