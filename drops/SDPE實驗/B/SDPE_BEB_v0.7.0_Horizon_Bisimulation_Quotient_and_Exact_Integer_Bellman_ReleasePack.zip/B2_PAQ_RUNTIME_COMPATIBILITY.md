# SDPE-BEB v0.7.0 — Runtime Compatibility Note

Version v0.7.0 changes the public mathematical analysis layer, not the evidence or network semantics of the managed evaluator.

The normative wire/runtime protocol remains

```text
sdpe-beb-b2pa-v0.6.0
```

and v0.7.0 is analysis-compatible with that protocol.

The evaluator still enforces:

- one session-global observation budget;
- observation-backed action dependencies;
- safe `claim_true` / `claim_false` / `undecided` semantics;
- task switching and later revisiting;
- pre-query start receipt binding;
- HMAC-SHA256 counter-PRF corpus generation;
- transcript hash chaining;
- Ed25519 final signature;
- post-session deterministic generator replay and semantic audit.

No hidden premise, oracle answer, seed, reveal, or evaluator-private implementation is added to the Participant bundle by the v0.7.0 mathematical extension.

The release therefore distinguishes

$$
\boxed{
\text{runtime protocol version}
\neq
\text{analysis release version}.
}
$$

This avoids changing a security/audit protocol merely because a better exact solver was discovered.
