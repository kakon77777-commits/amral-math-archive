# SDPE-BEB v0.7.0 — Horizon-Bisimulation Quotient Theorems

## 1. Scope

Version v0.6.0 established the unrestricted posterior Bellman recurrence and computed the actual $20/20/20$ benchmark exactly through

$$
0\le Q\le12.
$$

Version v0.7.0 does not change the evaluator evidence semantics. Its mathematical contribution is an exact finite-horizon quotient of posterior states together with an exact integer Bellman representation. These two reductions extend the certified unrestricted prefix to

$$
\boxed{0\le Q\le19}.
$$

No exact value for $Q=20$ is claimed in this release.

---

## 2. Local posterior kernel

Let $\mathcal S$ be the finite local posterior state set of v0.6.0. For $s\in\mathcal S$, one legal observation has kernel

$$
K_s(r,s'),
$$

where $r\in\{0,1\}$ is the immediate certification reward and $s'$ is either another live posterior state or the absorbing certified outcome $\bot$.

Task identity is irrelevant to the mathematical Bellman objective; only the local posterior state and the remaining global horizon matter.

---

## 3. Finite-horizon behavioral equivalence

Define a sequence of partitions $\Pi_h$.

At horizon zero all live states are behaviorally indistinguishable because no further observation can be made:

$$
\Pi_0=\{\mathcal S\}.
$$

Assume $\Pi_{h-1}$ is defined. For every state $s$, define its one-step signature

$$
\Sigma_h(s)
=
\left(
[s]_{h-1},
\left\{
\sum_{s'\in C}K_s(r,s')
:\
r\in\{0,1\},\ C\in\Pi_{h-1}\cup\{\bot\}
\right\}
\right).
$$

Then

$$
s\sim_h t
\quad\Longleftrightarrow\quad
\Sigma_h(s)=\Sigma_h(t).
$$

The explicit $[s]_{h-1}$ component makes the partitions monotone refinements:

$$
\Pi_h\preceq\Pi_{h-1}.
$$

For the released SDPE-BEB posterior kernel the number of equivalence classes is

| $h$ | $|\Pi_h|$ |
|---:|---:|
| $0$ | $1$ |
| $1$ | $29$ |
| $2$ | $36$ |
| $3$ | $38$ |
| $4$ | $40$ |
| $5$ | $42$ |
| $6$ | $44$ |
| $7$ | $45$ |
| $8$ | $46$ |
| $9$ | $47$ |
| $10$ | $48$ |
| $11$ | $49$ |

and it remains $49$ through every horizon checked in this release.

At the stable partition the only nontrivial exact local bisimulation class is

$$
\boxed{
\{A_{5,2},K_1,B_K,G_{13}\}
}
$$

because each of those states certifies with probability one on the next observation.

---

## 4. Global quotient theorem

Let the remaining global horizon be $h$, and let a global Bellman state be a multiset of live local posterior states.

Replace every local state $s$ by its class $[s]_h\in\Pi_h$, and replace task labels by occupancy counts of these classes. Call the resulting quotient state $q_h(\mathbf N)$.

### Theorem 4.1 — value preservation

If two global states have the same $h$-horizon quotient occupancy, then their unrestricted Bellman values are equal:

$$
q_h(\mathbf N)=q_h(\mathbf M)
\quad\Longrightarrow\quad
V_h(\mathbf N)=V_h(\mathbf M).
$$

### Proof

The result is by induction on $h$.

For $h=0$ both values are zero.

Assume the statement holds at $h-1$. Querying any task in an $h$-class $C$ produces, by definition of $\sim_h$, the same probability mass over immediate reward and $(h-1)$-classes. Every untouched task descends from its $h$-class to a unique $(h-1)$-class because the partitions refine monotonically. Therefore every action from two quotient-identical global states has an action in the other state with exactly the same distribution over reward and quotient successor state. By the induction hypothesis the successor values agree. Taking the maximum over actions preserves equality. $\square$

Thus the exact Bellman state is not a list of task histories. It is a finite-horizon occupancy vector over behavioral equivalence classes.

---

## 5. Consequence for state-space size

The quotient is exact but materially smaller near the leaves of the Bellman tree, where most recursive calls live.

For example, using the same unrestricted recursion, cumulative memoized states through $Q=16$ change from

$$
3{,}066{,}025
$$

under the raw local-state representation to

$$
699{,}847
$$

under the horizon quotient.

This is a reduction factor of approximately

$$
4.381.
$$

The reduction is not obtained by discarding low-value actions. It follows from exact behavioral equivalence.

---

## 6. Fresh-reservoir boundary

The v0.6.0 fresh-reservoir argument remains valid. The real benchmark contains twenty tasks from each family. A policy with total budget $Q$ can touch at most $Q$ distinct tasks, so for

$$
Q\le20
$$

an unlimited fresh reservoir for each family cannot offer more fresh tasks of a family than the real benchmark can supply before the horizon expires.

Hence every exact value reported through $Q=19$ is also an exact value of the actual sixty-task $20/20/20$ benchmark.

---

## 7. Exact prefix extension

The new certified values are

| $Q$ | $V_{\mathrm A}^{\star}(Q)$ |
|---:|---:|
| $13$ | $9928764509/7228354560$ |
| $14$ | $1148247771799/758977228800$ |
| $15$ | $10153282035739/6071817830400$ |
| $16$ | $1325116328544983/637540872192000$ |
| $17$ | $1547075354727419/728618139648000$ |
| $18$ | $26208440865728831/11900762947584000$ |
| $19$ | $656751940350557909/285618310742016000$ |

In particular,

$$
\boxed{
V_{\mathrm A}^{\star}(19)
=
\frac{656751940350557909}{285618310742016000}
\approx2.299404189613625.
}
$$

Every value through $Q=19$ remains strictly above or equal to the corresponding v0.5 recycling lower policy, and the previously proved strict adaptivity separation is preserved.

---

## 8. What is not claimed

Version v0.7.0 does not claim:

- an exact unrestricted value for $Q=20$;
- an index theorem for arbitrary posterior states;
- that first-order stochastic dominance alone is sufficient for global action pruning;
- an exact frontier for $Q>20$ using the unlimited-reservoir representation.

Those are separate problems. The v0.7 quotient removes histories that are exactly behaviorally redundant; it does not silently prune actions by heuristic value.
