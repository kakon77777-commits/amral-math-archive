# Blindness and Authority Levels

SDPE-BEB v0.1.4 distinguishes the following notions.

- **B0 — Public finite solvability.** The task predicates are public; unrestricted independent solving can recover truth.
- **B1 — Procedural blindness.** Oracle answers/nonces are withheld, public metadata is neutralized, and official replay enforces budgets before telemetry. This is the level implemented by the local Public Bundle.
- **B2 — Managed-query blindness.** An evaluator additionally controls cumulative queries/telemetry across a session. A local bundle cannot enforce this against a participant who can modify code.
- **B3 — Cryptographic/opaque evaluation.** Ground-truth-relevant state is hidden behind a remote or cryptographic interface. This is not claimed by this release.

Likewise, authority is layered:

$$
\text{label correctness}
\neq
\text{evidence support}
\neq
\text{certified closure/counterexample}.
$$

Post-reveal audit may report all layers, but pre-reveal public tooling must not collapse them.
