# v0.1.3 → v0.1.4 Audit Migration

v0.1.3 correctly separated truth declaration, route closure, and counterexample evidence, but corpus-level and replay-level canonicality were still incomplete.

The v0.1.4 official corpus contract is:

$$
\text{official corpus score valid}
\Longrightarrow
\forall t\in T,\; \exists!\, s_t.
$$

Thus a benchmark submission file must contain exactly one known record for every task. Partial or duplicate corpora remain diagnostically auditable but do not receive a valid official corpus score.

Replay is also terminal at first closure:

$$
S_k=\varnothing
\Longrightarrow
k=|R|.
$$

A route may not append unverified actions after the first empty survivor set.

Finally, evidence typing is strict:

$$
\texttt{claim\_false}
\Longrightarrow
\texttt{counterexample\_assignment}\in\mathbb{Z}_{\ge 0},
$$

with JSON booleans explicitly excluded.

This is a protocol/tooling revision only; mathematical tasks and Oracle commitments are unchanged.
