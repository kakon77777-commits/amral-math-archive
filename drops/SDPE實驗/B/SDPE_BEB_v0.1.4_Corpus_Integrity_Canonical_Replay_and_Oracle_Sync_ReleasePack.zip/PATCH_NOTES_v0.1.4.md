# SDPE-BEB v0.1.4 Corpus-Integrity and Canonical-Replay Repair

## Repaired

1. **Corpus completeness/uniqueness:** official audit scoring requires one and only one submission for every task ID. Omissions, duplicates, unknown IDs, and malformed records cannot be used to inflate attempted-label accuracy.
2. **Canonical terminal replay:** once a route closes, it is terminal. Any selected-action suffix after closure is rejected instead of silently ignored.
3. **Witness typing:** JSON booleans are not accepted as integer counterexample assignments.
4. **Oracle synchronization:** Full Dev and Oracle now ship byte-identical canonical audit/common cores and the Oracle manifest reports the current package/audit versions.
5. **Schema hardening:** submission label/evidence relations are encoded structurally; task/oracle schemas reject unknown fields and malformed nested structures.
6. **Relational hardening:** action reachability is checked by legal executable fixed point, not unlock-edge reachability alone; predicate variable/assignment bounds are checked.
7. **Cross-file integrity:** task files, task index, Oracle records, manifests, commitments, and dataset fingerprint are checked as mutually consistent domains.

## Preserved

- mathematical dataset version `sdpe-beb-neutral-v0.1.1`;
- all premises/actions/budgets;
- all Oracle answers, nonces, and commitments;
- dataset fingerprint `226fae3dd0740f2bd6eac1c07879c8b3fdbb552fa28a71fc180081690761f34a`;
- v0.1.2 budget preflight/survivor hiding;
- v0.1.3 truth/route/evidence semantic separation.
8. **Reveal-time Oracle verification:** the standalone audit recomputes exact survivors from public premises and checks truth, survivor count, witness, survivor hash, and search-space size; commitments prove precommitment, while exact replay proves semantic correctness.
