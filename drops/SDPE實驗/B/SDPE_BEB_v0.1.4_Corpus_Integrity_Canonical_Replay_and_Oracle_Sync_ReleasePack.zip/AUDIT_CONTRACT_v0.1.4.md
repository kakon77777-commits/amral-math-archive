# SDPE-BEB v0.1.4 Formal Audit Contract

Let $T$ be the finite public task set and let $S$ be the multiset of submitted records. Each submission has a task identifier map

$$
\tau:S\to T.
$$

For an official corpus score, the submission corpus must be a bijective cover of the task set:

$$
\forall t\in T,\qquad |\tau^{-1}(t)|=1.
$$

Unknown task identifiers, duplicate task identifiers, malformed records without a usable task identifier, or omitted tasks invalidate the official corpus score. Individual records may still be reported diagnostically.

## Replay semantics

For task $t$, let

$$
R=(a_1,\ldots,a_k)
$$

be the selected action sequence and let $S_0=\Omega_t$ be the finite assignment universe. A verified cut applies its certified predicate; a bridge has routing authority only. The survivor sequence is

$$
S_0\supseteq S_1\supseteq\cdots\supseteq S_k.
$$

A replay is legal only if every selected action is known, unlocked when used, has satisfied prerequisites, has a valid certificate when proof authority is required, and satisfies both step and cost budgets.

Closure is terminal:

$$
S_i=\varnothing
\Longrightarrow
i=k.
$$

Thus an action suffix after first closure is not silently ignored; it makes the selected route non-canonical and invalid.

## Truth declaration and evidence

The declaration space is

$$
L=\{\texttt{claim\_true},\texttt{claim\_false},\texttt{undecided}\}.
$$

The route flag `declared_closed` describes replay status only; it is not itself a truth label.

For `claim_true`, evidence support requires a legal in-budget terminal closure:

$$
E_{\mathrm{true}}(t)
\Longleftrightarrow
S_k=\varnothing.
$$

For `claim_false`, evidence support requires an integer assignment $w$ satisfying every public premise:

$$
E_{\mathrm{false}}(t,w)
\Longleftrightarrow
w\in\Omega_t
\land
\bigwedge_{p\in P_t}p(w)=1.
$$

JSON booleans are not accepted as integer assignments. `undecided` is a genuine abstention and asserts no truth label.

## Reveal authority

Let $O_t$ be the revealed Oracle record and let $C_t$ be the public precommitment. Reveal-time authority requires both commitment integrity and exact semantic verification:

$$
\operatorname{CommitOK}(t)
\land
\operatorname{ExactOracleOK}(t).
$$

`ExactOracleOK` recomputes the finite survivor set from the public premises and checks Oracle truth, survivor count, canonical witness, survivor-set hash, and search-space size.

Therefore precommitment and correctness play different roles:

$$
\text{commitment integrity}
\neq
\text{Oracle semantic correctness}.
$$

## Certification layers

A correct label alone is not a certificate:

$$
\text{label correctness}
\neq
\text{evidence support}
\neq
\text{certification authority}.
$$

A true-claim certification requires a correct revealed truth value, valid reveal authority, a valid submission, and $E_{\mathrm{true}}$. A false-claim certification requires a correct revealed false value, valid reveal authority, a valid submission, and $E_{\mathrm{false}}$.

The official corpus score is valid only when the corpus bijection holds and the task/Oracle infrastructure used by the audit is internally valid. Participant-level malformed or unsupported submissions may then be scored as invalid records without invalidating the evaluator itself.
