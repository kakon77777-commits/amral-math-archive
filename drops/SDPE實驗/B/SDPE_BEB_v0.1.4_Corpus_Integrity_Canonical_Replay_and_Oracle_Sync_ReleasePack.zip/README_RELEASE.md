# SDPE-BEB v0.1.4 Corpus-Integrity, Canonical-Replay, and Oracle-Synchronization Release Pack

This release preserves the `sdpe-beb-neutral-v0.1.1` mathematical dataset while repairing corpus-level audit integrity, terminal replay semantics, witness typing, schema strictness, and Oracle/Full audit synchronization.

For blind participation, distribute only:

`SDPE_BEB_NeutralVariant_Public_v0.1.4.zip`

Keep Full Dev and Oracle bundles separate until reveal.

The central v0.1.4 invariants are:

$$
\forall t\in T,\qquad |\tau^{-1}(t)|=1
$$

for an official corpus score, and

$$
S_i=\varnothing\Longrightarrow i=|R|
$$

for canonical terminal replay.

Reveal-time certification verifies both the original commitment and the exact finite Oracle semantics reconstructed from the public premises.

All 60 mathematical task files and `oracle_answers.jsonl` are byte-identical to v0.1.3. The dataset fingerprint remains:

`226fae3dd0740f2bd6eac1c07879c8b3fdbb552fa28a71fc180081690761f34a`
