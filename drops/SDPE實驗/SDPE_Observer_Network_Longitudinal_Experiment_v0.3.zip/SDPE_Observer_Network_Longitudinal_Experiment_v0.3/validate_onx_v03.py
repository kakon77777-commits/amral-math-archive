#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys, hashlib
ROOT=Path(__file__).resolve().parent; issues=[]; results=[]
for ep in sorted((ROOT/'real_run_001_v03'/'phase_a').iterdir()):
 if not ep.is_dir(): continue
 for bname in ['agent_bundle_first','agent_bundle_repair']:
  bundle=ep/bname
  p=subprocess.run([sys.executable,str(ROOT/'tools'/'validate_blind_bundle_v03.py'),str(bundle)],capture_output=True,text=True)
  try: out=json.loads(p.stdout)
  except Exception: out={'ok':False,'issues':['validator output parse failed']}
  results.append({'episode':ep.name,'bundle':bname,'blind_ok':out.get('ok',False),'issues':out.get('issues',[])})
  if not out.get('ok',False): issues.append(f'blind fail {ep.name}/{bname}')
seal=json.loads((ROOT/'operator_only'/'REAL_RUN_001_SEAL_MANIFEST_v0.3.json').read_text(encoding='utf-8')); sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pub=ROOT/'real_run_001_v03'/'frozen_benchmark'/'REAL_RUN_001_PUBLIC_BENCHMARK_v0.3.json'; orc=ROOT/'operator_only'/'REAL_RUN_001_HIDDEN_ORACLE_v0.3.json'
if sha(pub)!=seal['public_benchmark_sha256']: issues.append('public benchmark hash mismatch')
if sha(orc)!=seal['hidden_oracle_sha256']: issues.append('oracle hash mismatch')
report={'ok':not issues,'issues':issues,'phase_a_blind_results':results,'public_benchmark_sha256':seal['public_benchmark_sha256'],'oracle_commitment_sha256':seal['hidden_oracle_sha256']}
(ROOT/'VALIDATION_ONX_v0.3.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps(report,ensure_ascii=False,indent=2)); sys.exit(0 if not issues else 2)
