# REAL RUN 001 Public Benchmark v0.3

## Goal

$$
\forall m\in\Omega,\qquad y(m)\leq 2x(m)+3.
$$

The full benchmark is frozen by the operator. Agents receive **phase-specific derived public views**, not this full frozen object. A listed route rule is a candidate statement, not an oracle label of soundness.

## Causal schedule

1. first-closure session;
2. precommitted dependency-lifecycle invalidation;
3. **fresh repair session for every arm**;
4. $M^+$ receives a controlled failure-memory artifact; $M^-$ does not;
5. repair and reclosure;
6. freeze ledgers before hidden-oracle scoring.
