# REAL RUN 001 v0.3 — Operator Runbook

## 0. What is now frozen

- public benchmark content and SHA-256;
- hidden-oracle content and commitment hash;
- Phase A 16-episode factor matrix;
- role output schemas;
- canonical invalidation mechanism (`affine-bound@v1` retirement);
- raw-ledger / derived-scoring separation.

Do not edit the benchmark after the first real Agent episode begins.

## 1. Fill model registry

Copy `MODEL_REGISTRY_TEMPLATE.json` to `MODEL_REGISTRY.json` and fill M1–M4 with exact provider/model/version/harness identifiers.

## 2. Execute Phase A in randomized order

Use `phase_a/RANDOMIZED_EXECUTION_ORDER_v0.3.json`.

Each episode has:
- `agent_bundle_first/` and `agent_bundle_repair/` — phase-specific directories; only the appropriate one may be mounted/indexed for Agents;
- `operator/` — authoritative ledgers, failure memory, manifests; never mount this directory into Agent retrieval/context;
- `submissions/` — save role JSON outputs here before controller ingestion.

## 3. Initialize

```bash
python tools/onx_episode_controller_v03.py init --episode-dir phase_a/A01_M1_ON_Mplus
```

The controller writes a filtered `agent_bundle_first/runtime_view/RUNTIME_VIEW.json`.

## 4. First closure

For ON episodes:
1. run Proposer using its prompt and save proposal JSON;
2. ingest proposal;
3. copy proposal to the Verifier-readable `INBOX_PROPOSAL.json` only; do not expose proposer private scratchpad;
4. run Verifier and ingest output;
5. repeat for the second initial route if needed;
6. run CoverageAuditor and BoundaryAuditor;
7. controller `commit`.

For SA episodes the same Agent identity/session produces proposal then verification artifacts, but commit remains deterministic.

## 5. Canonical invalidation

After first closure only:

```bash
python tools/onx_episode_controller_v03.py invalidate --episode-dir <episode>
```

- $M^+$: filtered runtime view includes the preserved failure-memory details.
- $M^-$: the authoritative proof reopening is visible, but route signature / detailed failure reason from prior memory are redacted from the Agent-readable view.

Never show the raw proof ledger to $M^-$ Agents after invalidation because it contains the ablated reason.

## 6. Repair

Agents may use public direct evaluation or any listed repair rule, but must verify the rule rather than trust its listing.

Repeat proposal → verification → audits → commit until reclosure or budget exhaustion.

## 7. Freeze before oracle scoring

```bash
python tools/onx_freeze_episode_v03.py --episode-dir <episode>
```

No raw-ledger changes after freeze.

## 8. Post-freeze oracle scoring

Only the operator may run:

```bash
python tools/onx_postfreeze_oracle_scorer_v03.py \
  --episode-dir <episode> \
  --oracle operator_only/REAL_RUN_001_HIDDEN_ORACLE_v0.3.json \
  --out <episode>/operator/derived_postfreeze_scoring.json
```

The scorer verifies frozen raw-ledger hashes before computing FCR. It never appends to the raw observer ledger.

## 9. Blindness validation

Before launching an Agent on any episode:

```bash
python tools/validate_blind_bundle_v03.py <episode>/agent_bundle
```

A failed blind-bundle validation invalidates that episode before execution.


## v0.3 memory-identifiability correction

Both $M^+$ and $M^-$ must use a **fresh repair session** after rollback. The repair Agent may see only `agent_bundle_repair/`. The difference is solely whether the controller-generated runtime view contains the controlled `failure_memory` object. Do not pass the first-phase transcript, scratchpad, raw ledgers, or first-phase bundle into either repair session.
