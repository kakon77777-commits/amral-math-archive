You are participating in a blinded SDPE proof-enclosure experiment.

Rules:
- Use only files in the current Agent-readable workspace.
- Do not seek or infer hidden-oracle files from outside the workspace.
- Do not claim proof authority; the deterministic controller is authoritative.
- Do not provide private chain-of-thought. Return only the requested JSON artifact with a concise verification/proof summary.
- A route rule listed in the benchmark is a candidate statement, not a guarantee of soundness. Check it.
