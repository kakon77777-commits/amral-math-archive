#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List

SCHEMA_VERSION = "sdpe-runtime-v1"


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def fingerprint(obj: Any) -> str:
    return hashlib.sha256(canonical_json(obj).encode("utf-8")).hexdigest()


def empty_state() -> Dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "problem": None,
        "environment": None,
        "epoch": 0,
        "pipeline_stage": "Detect",
        "universe": [],
        "survivor": {"mode": "finite-explicit", "members": []},
        "route_certs": {},
        "gaps": {},
        "gcc": {
            "valid": False,
            "cover_ok": False,
            "boundary_ok": False,
            "glue_mode": "RefutationOnly",
            "glue_ok": True,
            "replay_ok": False,
        },
        "proof_dag": {"nodes": {}, "edges": []},
        "compiled": {"support_index": {}, "dirty": [], "reopened": []},
        "dvi": {},
        "survivor_profile": {},
        "route_decision": None,
        "pending_actions": {},
        "last_seq": -1,
    }


def active_exclusions(state: Dict[str, Any]) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    for cid, node in state["proof_dag"]["nodes"].items():
        if node.get("status") == "active" and node.get("kind") == "exclusion":
            out[cid] = list(node.get("excluded_members", []))
    return out


def recompute_support_and_survivor(state: Dict[str, Any]) -> None:
    universe = list(state["universe"])
    support: Dict[str, List[str]] = {x: [] for x in universe}
    for cid, excluded in active_exclusions(state).items():
        for x in excluded:
            if x in support:
                support[x].append(cid)
    state["compiled"]["support_index"] = {x: sorted(v) for x, v in support.items() if v}
    state["survivor"]["members"] = [x for x in universe if not support[x]]


def require_seq(state: Dict[str, Any], event: Dict[str, Any]) -> None:
    seq = int(event["seq"])
    if seq != state["last_seq"] + 1:
        raise ValueError(f"non-contiguous event sequence: expected {state['last_seq'] + 1}, got {seq}")
    state["last_seq"] = seq


def reduce_event(state: Dict[str, Any], event: Dict[str, Any]) -> Dict[str, Any]:
    state = copy.deepcopy(state)
    require_seq(state, event)
    kind = event["kind"]
    p = event.get("payload", {})

    if kind == "ProblemInitialized":
        if state["problem"] is not None:
            raise ValueError("problem already initialized")
        state["problem"] = p["problem"]
        state["environment"] = p["environment"]
        state["universe"] = list(p.get("universe", []))
        state["survivor"] = {"mode": p.get("survivor_mode", "finite-explicit"), "members": list(state["universe"])}
        state["pipeline_stage"] = "Profile"

    elif kind == "SurvivorProfiled":
        state["survivor_profile"] = p["profile"]
        state["pipeline_stage"] = "GapExtract"

    elif kind == "GapRegistered":
        gap = p["gap"]
        state["gaps"][gap["gap_id"]] = gap
        state["pipeline_stage"] = "ActionGenerate"

    elif kind == "RouteCertified":
        cert = p["route_cert"]
        state["route_certs"][cert["route_id"]] = cert
        state["pipeline_stage"] = "Route"

    elif kind == "RouteDecisionRecorded":
        state["route_decision"] = p["decision"]
        state["pipeline_stage"] = "Propose"

    elif kind == "ActionProposed":
        action = p["action"]
        state["pending_actions"][action["action_id"]] = action
        state["pipeline_stage"] = "Verify"

    elif kind == "CertificateVerified":
        cert = p["certificate"]
        if cert["action_id"] not in state["pending_actions"]:
            raise ValueError("certificate refers to unknown proposal")
        if cert.get("verification") not in {"pass", "fail"}:
            raise ValueError("verification must be pass/fail")
        node = {
            "certificate_id": cert["certificate_id"],
            "action_id": cert["action_id"],
            "kind": cert.get("kind", "exclusion"),
            "excluded_members": list(cert.get("excluded_members", [])),
            "dependencies": list(cert.get("dependencies", [])),
            "checker_fingerprint": cert.get("checker_fingerprint", ""),
            "statement_fingerprint": cert.get("statement_fingerprint", ""),
            "status": "verified-pending" if cert["verification"] == "pass" else "failed",
            "version": cert.get("version", "v1"),
        }
        state["proof_dag"]["nodes"][cert["certificate_id"]] = node
        for dep in node["dependencies"]:
            state["proof_dag"]["edges"].append([dep, cert["certificate_id"]])
        state["pipeline_stage"] = "CoverageAudit"

    elif kind == "CoverageAudited":
        state["gcc"]["cover_ok"] = bool(p["ok"])
        state["pipeline_stage"] = "BoundaryAudit"

    elif kind == "BoundaryAudited":
        state["gcc"]["boundary_ok"] = bool(p["ok"])
        state["pipeline_stage"] = "GlueAudit"

    elif kind == "GlueAudited":
        state["gcc"]["glue_mode"] = p.get("mode", "RefutationOnly")
        state["gcc"]["glue_ok"] = bool(p["ok"])
        state["pipeline_stage"] = "Compile"

    elif kind == "TelemetryObserved":
        # Observatory data is intentionally non-authoritative.
        state["dvi"] = p.get("dvi", state["dvi"])
        state["survivor_profile"].update(p.get("survivor_profile", {}))

    elif kind == "CommitEpoch":
        ids = list(p.get("certificate_ids", []))
        for cid in ids:
            node = state["proof_dag"]["nodes"].get(cid)
            if not node or node.get("status") != "verified-pending":
                raise ValueError(f"cannot commit unverified certificate {cid}")
            node["status"] = "active"
        recompute_support_and_survivor(state)
        state["epoch"] += 1
        state["gcc"]["replay_ok"] = True
        state["gcc"]["valid"] = bool(
            not state["survivor"]["members"]
            and state["gcc"]["cover_ok"]
            and state["gcc"]["boundary_ok"]
            and state["gcc"]["glue_ok"]
        )
        state["pipeline_stage"] = "Commit"

    elif kind == "CertificateInvalidated":
        cid = p["certificate_id"]
        node = state["proof_dag"]["nodes"].get(cid)
        if node is None:
            raise ValueError("unknown certificate")
        old_survivor = set(state["survivor"]["members"])
        node["status"] = "stale"
        state["compiled"]["dirty"] = sorted(set(state["compiled"].get("dirty", [])) | {cid})
        recompute_support_and_survivor(state)
        new_survivor = set(state["survivor"]["members"])
        state["compiled"]["reopened"] = sorted(new_survivor - old_survivor)
        state["gcc"]["valid"] = False
        state["gcc"]["replay_ok"] = False
        state["pipeline_stage"] = "Detect"

    else:
        raise ValueError(f"unknown event kind: {kind}")

    return state


def replay(events: Iterable[Dict[str, Any]], initial: Dict[str, Any] | None = None) -> Dict[str, Any]:
    state = empty_state() if initial is None else copy.deepcopy(initial)
    for event in events:
        state = reduce_event(state, event)
    state["state_fingerprint"] = fingerprint({k: v for k, v in state.items() if k != "state_fingerprint"})
    return state


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            out.append(json.loads(line))
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("ledger", type=Path)
    ap.add_argument("--state-out", type=Path)
    args = ap.parse_args()
    state = replay(load_jsonl(args.ledger))
    text = json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True)
    print(text)
    if args.state_out:
        args.state_out.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
