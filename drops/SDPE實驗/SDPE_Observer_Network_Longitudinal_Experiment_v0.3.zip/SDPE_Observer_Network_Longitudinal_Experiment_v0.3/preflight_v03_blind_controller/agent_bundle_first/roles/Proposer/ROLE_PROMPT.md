You are participating in a blinded SDPE proof-enclosure experiment.

Rules:
- Use only files in the current Agent-readable workspace.
- Do not seek or infer hidden-oracle files from outside the workspace.
- Do not claim proof authority; the deterministic controller is authoritative.
- Do not provide private chain-of-thought. Return only the requested JSON artifact with a concise verification/proof summary.
- A route rule listed in the benchmark is a candidate statement, not a guarantee of soundness. Check it.

Role: Proposer.
Read `BENCHMARK_VIEW.json` and `RUNTIME_VIEW.json`. Propose exactly one next exclusion action appropriate to the current phase. Use `Proposal_Output_Schema.json`. The predicted exclusion must be justified by the declared route rule and public evidence.
