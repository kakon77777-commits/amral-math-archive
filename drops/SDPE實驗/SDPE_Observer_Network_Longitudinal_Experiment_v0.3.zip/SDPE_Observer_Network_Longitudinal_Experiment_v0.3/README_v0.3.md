# SDPE × Observer-Network Longitudinal Experiment v0.3

**Status:** Phase A blind-execution appliance ready.  
**Empirical status:** no real multi-model result is included yet.

v0.3 upgrades v0.2 from a protocol/template package to an operator/Agent separation package:

- frozen public finite benchmark with nontrivial candidate route rules;
- operator-only hidden oracle committed by SHA-256 before execution;
- 16 materialized Phase A episode directories;
- Agent-readable `agent_bundle/` separated from operator ledgers;
- role prompts + JSON output schemas;
- file-based deterministic episode controller;
- canonical rollback and $M^+$ / $M^-$ filtered memory views;
- episode freezer and post-freeze oracle scorer;
- blind-bundle leak validator + negative leak test;
- controller round-trip preflight: first closure → rollback → repair → reclosure → freeze → oracle scoring.

## Critical rule

Never mount/index an episode `operator/` directory or the package `operator_only/` directory into an Agent context. In $M^-$ episodes, the raw proof ledger itself contains the ablated invalidation reason, so Agents must receive only the controller-generated filtered runtime view.

## Phase A

$$
4\ \text{model blocks}\times 4\ \text{factorial arms}=16\ \text{episodes}.
$$

The package still requires the local operator to fill the exact M1–M4 model registry and actually invoke the models. Synthetic preflight data is instrumentation-only and must not be reported as AI evidence.
