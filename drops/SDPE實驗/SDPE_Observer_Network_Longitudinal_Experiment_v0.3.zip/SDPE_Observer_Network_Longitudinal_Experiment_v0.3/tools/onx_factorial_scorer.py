#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path

ARMS=['ON_Mplus','ON_Mminus','SA_Mplus','SA_Mminus']

def load(path): return json.loads(path.read_text(encoding='utf-8'))['summary']

def effect(vals, metric):
    y={a:vals[a].get(metric) for a in ARMS}
    if any(v is None for v in y.values()): return None
    dm=(y['ON_Mminus']+y['SA_Mminus'])/2-(y['ON_Mplus']+y['SA_Mplus'])/2
    da=(y['SA_Mplus']+y['SA_Mminus'])/2-(y['ON_Mplus']+y['ON_Mminus'])/2
    inter=(y['SA_Mminus']-y['SA_Mplus'])-(y['ON_Mminus']-y['ON_Mplus'])
    return {'memory_benefit_lower_is_better':dm,'observer_network_benefit_lower_is_better':da,'interaction':inter}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',type=Path,required=True); ap.add_argument('--out',type=Path,required=True); args=ap.parse_args()
    vals={a:load(args.root/a/'snapshot.json') for a in ARMS}
    metrics=['repair_lag_proof_seq','IRR','IPR','tokens','wall_seconds','tool_calls']
    out={'arms':vals,'effects':{m:effect(vals,m) for m in metrics},
         'interpretation':'Structural preflight only; designed values validate instrumentation and are not empirical AI effects.'}
    args.out.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
