#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
from typing import Any, Dict, List

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RUNTIME_DIR = ROOT / "reference_runtime"
sys.path.insert(0, str(RUNTIME_DIR))
import sdpe_runtime  # type: ignore


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]


def validate_contiguous(events: List[Dict[str, Any]], key: str) -> None:
    for i, e in enumerate(events):
        if int(e[key]) != i:
            raise ValueError(f"non-contiguous {key}: expected {i}, got {e[key]}")


def proof_timeline(events: List[Dict[str, Any]]) -> Dict[int, Dict[str, Any]]:
    state = sdpe_runtime.empty_state()
    out: Dict[int, Dict[str, Any]] = {}
    initial_n = None
    for ev in events:
        state = sdpe_runtime.reduce_event(state, ev)
        if initial_n is None and state.get("universe"):
            initial_n = len(state["universe"])
        n0 = max(1, initial_n or len(state.get("universe", [])) or 1)
        ns = len(state["survivor"]["members"])
        out[int(ev["seq"])] = {
            "proof_seq": int(ev["seq"]),
            "survivor_count": ns,
            "PER": 1.0 - ns / n0,
            "gcc_valid": bool(state["gcc"]["valid"]),
            "epoch": int(state["epoch"]),
            "D_resolve": state.get("dvi", {}).get("D_resolve"),
            "D_frontier": state.get("dvi", {}).get("D_frontier"),
            "W": state.get("dvi", {}).get("W"),
            "sigma": state.get("dvi", {}).get("sigma"),
        }
    return out


def observer_timeline(events: List[Dict[str, Any]]) -> Dict[int, Dict[str, Any]]:
    hypotheses: Dict[str, str] = {}
    initial = []
    proposals: Dict[str, str | None] = {}
    rejected_proposals = set()
    rejected_hypotheses = set()
    verification_count = 0
    repair_count = 0
    total_tokens = 0.0
    total_wall = 0.0
    out: Dict[int, Dict[str, Any]] = {}

    for ev in events:
        kind = ev["kind"]
        p = ev.get("payload", {})
        if kind == "ExperimentInitialized":
            initial = list(p.get("initial_hypotheses", []))
            for h in initial:
                hypotheses.setdefault(h, "active")
        elif kind == "HypothesisRegistered":
            hypotheses[p["hypothesis_id"]] = p.get("status", "active")
        elif kind == "ProposalObserved":
            proposals[p["proposal_id"]] = p.get("hypothesis_id")
        elif kind == "VerificationObserved":
            verification_count += 1
        elif kind == "HypothesisSupported":
            hypotheses[p["hypothesis_id"]] = "supported"
        elif kind == "HypothesisRejected":
            hypotheses[p["hypothesis_id"]] = "rejected"
            rejected_hypotheses.add(p["hypothesis_id"])
            if p.get("proposal_id"):
                rejected_proposals.add(p["proposal_id"])
            else:
                for pid, hid in proposals.items():
                    if hid == p["hypothesis_id"]:
                        rejected_proposals.add(pid)
        elif kind == "RepairObserved":
            repair_count += 1
        elif kind == "CostObserved":
            total_tokens += float(p.get("tokens", 0.0))
            total_wall += float(p.get("wall_seconds", 0.0))

        n0 = max(1, len(initial) or len(hypotheses) or 1)
        alive = sum(1 for s in hypotheses.values() if s != "rejected")
        out[int(ev["obs_seq"])] = {
            "obs_seq": int(ev["obs_seq"]),
            "proof_seq_ref": ev.get("proof_seq_ref"),
            "active_hypothesis_count": alive,
            "EER": 1.0 - alive / n0,
            "proposal_count": len(proposals),
            "rejected_hypothesis_count": len(rejected_hypotheses),
            "hypothesis_rejection_fraction": len(rejected_hypotheses) / n0,
            "rejected_proposal_count": len(rejected_proposals),
            "proposal_rejection_rate": len(rejected_proposals) / max(1, len(proposals)),
            "verification_count": verification_count,
            "repair_count": repair_count,
            "tokens": total_tokens,
            "wall_seconds": total_wall,
        }
    return out


def merge_timeline(proof: Dict[int, Dict[str, Any]], obs: Dict[int, Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows = []
    for obs_seq in sorted(obs):
        r = dict(obs[obs_seq])
        ps = r.get("proof_seq_ref")
        if ps is not None and int(ps) in proof:
            r.update({f"proof_{k}": v for k, v in proof[int(ps)].items() if k != "proof_seq"})
        rows.append(r)
    return rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--proof-ledger", type=Path, required=True)
    ap.add_argument("--observer-ledger", type=Path, required=True)
    ap.add_argument("--json-out", type=Path, required=True)
    ap.add_argument("--csv-out", type=Path, required=True)
    args = ap.parse_args()

    pe = load_jsonl(args.proof_ledger)
    oe = load_jsonl(args.observer_ledger)
    validate_contiguous(pe, "seq")
    validate_contiguous(oe, "obs_seq")
    pt = proof_timeline(pe)
    ot = observer_timeline(oe)
    rows = merge_timeline(pt, ot)

    final_proof = pt[max(pt)]
    final_obs = ot[max(ot)]
    snapshot = {
        "experiment_type": "observer-network-sidecar",
        "proof_authority": "unchanged-sdpe-runtime-v1",
        "hidden_oracle_runtime_access": "forbidden",
        "final": {
            "PER": final_proof["PER"],
            "EER": final_obs["EER"],
            "survivor_count": final_proof["survivor_count"],
            "active_hypothesis_count": final_obs["active_hypothesis_count"],
            "gcc_valid": final_proof["gcc_valid"],
            "verification_count": final_obs["verification_count"],
            "repair_count": final_obs["repair_count"],
            "proposal_rejection_rate": final_obs["proposal_rejection_rate"],
            "D_resolve": final_proof["D_resolve"],
            "D_frontier": final_proof["D_frontier"],
            "W": final_proof["W"],
            "sigma": final_proof["sigma"],
            "tokens": final_obs["tokens"],
            "wall_seconds": final_obs["wall_seconds"],
        },
        "timeline": rows,
    }
    args.json_out.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    fields = sorted({k for row in rows for k in row})
    with args.csv_out.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(json.dumps(snapshot["final"], ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
