#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,sys

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load_jsonl(p): return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--episode-dir',type=Path,required=True); ap.add_argument('--oracle',type=Path,required=True); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args(); ep=a.episode_dir; op=ep/'operator'
 fm=json.loads((op/'freeze_manifest.json').read_text(encoding='utf-8'))
 for f in ['proof_ledger.jsonl','observer_ledger.jsonl','run_manifest.json','phase_state.json']:
  if sha(op/f)!=fm['hashes'][f]: raise SystemExit(f'frozen hash mismatch for {f}')
 oracle=json.loads(a.oracle.read_text(encoding='utf-8')); bench_id=json.loads((op/'run_manifest.json').read_text(encoding='utf-8'))['frozen_benchmark_fingerprint']
 events=load_jsonl(op/'observer_ledger.jsonl'); passed=[]
 for e in events:
  if e.get('kind')=='VerificationObserved' and e.get('payload',{}).get('result')=='pass' and e.get('payload',{}).get('route_signature'):
   passed.append(e['payload'])
 labels=[]; false=0; scorable=0; unknown=0
 valid=oracle['route_rule_semantic_validity']; members=oracle['member_truth']
 for p in passed:
  rs=p['route_signature']; truth=None
  if rs=='DIRECT_EVAL': truth=all(bool(members.get(m,False)) for m in p.get('excluded_members',[]))
  elif rs in valid: truth=bool(valid[rs])
  else: unknown+=1
  if truth is not None:
   scorable+=1; false += int(not truth)
  labels.append({'certificate_id':p.get('certificate_id'),'route_signature':rs,'semantic_valid':truth})
 fcr=false/max(1,scorable)
 out={'episode_id':fm['episode_id'],'oracle_scored':True,'passed_verifications':len(passed),'scorable_passed_verifications':scorable,'unknown_route_count':unknown,'false_passed_verifications':false,'FCR':fcr,'labels':labels}
 a.out.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
