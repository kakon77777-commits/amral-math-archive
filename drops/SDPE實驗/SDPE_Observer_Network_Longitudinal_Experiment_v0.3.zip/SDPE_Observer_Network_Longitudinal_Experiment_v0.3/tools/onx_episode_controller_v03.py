#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, hashlib, sys, shutil
from pathlib import Path
from typing import Any, Dict, List
import jsonschema

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
RUNTIME=ROOT/'reference_runtime'
sys.path.insert(0,str(RUNTIME))
import sdpe_runtime  # type: ignore

BENCH=ROOT/'real_run_001_v03'/'frozen_benchmark'/'REAL_RUN_001_PUBLIC_BENCHMARK_v0.3.json'
SCHEMAS=ROOT/'real_run_001_v03'/'schemas'
PROMPTS=ROOT/'real_run_001_v03'/'role_prompts'

def jload(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def jwrite(p,o): Path(p).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def load_jsonl(p): return [json.loads(x) for x in Path(p).read_text(encoding='utf-8').splitlines() if x.strip()]
def append_jsonl(p,o):
    with Path(p).open('a',encoding='utf-8') as f: f.write(json.dumps(o,ensure_ascii=False,separators=(',',':'))+'\n')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def proof_state(ep):
    led=load_jsonl(ep/'operator'/'proof_ledger.jsonl')
    return sdpe_runtime.replay(led)

def next_seq(ep): return len(load_jsonl(ep/'operator'/'proof_ledger.jsonl'))
def next_obs(ep): return len(load_jsonl(ep/'operator'/'observer_ledger.jsonl'))

def obs(ep,kind,payload,actor=None,role=None,proof_seq_ref=None):
    man=jload(ep/'operator'/'run_manifest.json')
    ev={'obs_seq':next_obs(ep),'kind':kind,'payload':payload,'episode_id':man['episode_id'],'arm_id':man['arm_id'],
        'proof_seq_ref':proof_seq_ref,'actor':actor,'role':role,'model_family':None,'model_version':None,'harness_id':man.get('harness_id'),'timestamp':None,'event_fingerprint':None}
    append_jsonl(ep/'operator'/'observer_ledger.jsonl',ev); return ev

def proof(ep,kind,payload,actor):
    ev={'seq':next_seq(ep),'kind':kind,'actor':actor,'payload':payload}
    # pre-validate transition before persistence
    st=sdpe_runtime.replay(load_jsonl(ep/'operator'/'proof_ledger.jsonl'))
    sdpe_runtime.reduce_event(st,ev)
    append_jsonl(ep/'operator'/'proof_ledger.jsonl',ev); return ev

def validate_file(path,schema_name):
    data=jload(path); schema=jload(SCHEMAS/schema_name); jsonschema.validate(data,schema); return data

def public_runtime_view(ep, include_memory=False):
    man=jload(ep/'operator'/'run_manifest.json'); st=proof_state(ep); bench=jload(BENCH)
    passed=[]
    for cid,node in st['proof_dag']['nodes'].items():
        if node.get('status') in {'verified-pending','active'}:
            passed.append({'certificate_id':cid,'action_id':node.get('action_id'),'excluded_members':node.get('excluded_members',[]),'dependencies':node.get('dependencies',[]),'status':node.get('status')})
    phase=jload(ep/'operator'/'phase_state.json')['phase']; rules={k:v for k,v in bench['route_rules'].items() if phase in v.get('phase_availability',[])}
    view={'episode_id':man['episode_id'],'arm_id':man['arm_id'],'phase':phase,
          'epoch':st['epoch'],'survivor_members':st['survivor']['members'],'gcc_valid':st['gcc']['valid'],'passed_certificates':passed,
          'available_rules':rules,'repair_route_catalog':bench['repair_route_catalog'] if phase=='repair' else [],
          'notice':'This view is filtered. The raw proof ledger is operator-only.'}
    if include_memory and (ep/'operator'/'failure_memory.json').exists(): view['failure_memory']=jload(ep/'operator'/'failure_memory.json')
    return view

def emit_workspace(ep):
    man=jload(ep/'operator'/'run_manifest.json'); phase=jload(ep/'operator'/'phase_state.json')['phase']; include=man['memory_condition']=='preserved' and phase=='repair'
    bundle=ep/('agent_bundle_repair' if phase=='repair' else 'agent_bundle_first')
    w=bundle/'runtime_view'; w.mkdir(parents=True,exist_ok=True)
    jwrite(w/'RUNTIME_VIEW.json',public_runtime_view(ep,include_memory=include))
    if phase=='repair':
        inv={'certificate_invalid':True,'affected_dependency':'WITHHELD_MEMORY_ARTIFACT' if not include else 'affine-bound@v1',
             'reason_class':'WITHHELD_MEMORY_ARTIFACT' if not include else 'dependency-version-retired',
             'instruction':'Re-establish valid enclosure using current repair-phase evidence/rules. This is a fresh repair session.'}
        jwrite(w/'INVALIDATION_NOTICE.json',inv)
        jwrite(w/'SESSION_POLICY.json',{'fresh_session_required':True,'pre_invalidation_transcript_access':False,'controlled_failure_memory_injected':include})
    obs(ep,'MetaObservation',{'workspace_view_emitted':True,'phase':phase,'memory_details_included':include,'fresh_repair_session_required':phase=='repair'},actor='controller',role='MetaObserver')

def init_episode(ep):
    man=jload(ep/'operator'/'run_manifest.json'); bench=jload(BENCH)
    pl=ep/'operator'/'proof_ledger.jsonl'; ol=ep/'operator'/'observer_ledger.jsonl'
    pl.write_text('',encoding='utf-8'); ol.write_text('',encoding='utf-8')
    p0=proof(ep,'ProblemInitialized',{'problem':{'problem_id':bench['benchmark_id'],'statement':bench['theorem']['statement'],'statement_fingerprint':sha(BENCH)},
        'environment':{'runtime':'sdpe-runtime-v1','checker':'agent-verification-v03','policy':'onx-controller-v03'},'universe':bench['universe'],'survivor_mode':'finite-explicit'},'runtime')
    proof(ep,'SurvivorProfiled',{'profile':{'cardinality':len(bench['universe']),'measure_mode':'counting','exceptional_core':[]}},'observer')
    for r in bench['initial_routes']:
        proof(ep,'RouteCertified',{'route_cert':{'route_id':r['route_id'],'scope':r['scope'],'status':'active','representation':r['recommended_rule']}},'route-registry')
    proof(ep,'RouteDecisionRecorded',{'decision':{'selected':[r['route_id'] for r in bench['initial_routes']],'policy':'frozen-initial-route-pair','authority':'advisory'}},'router')
    obs(ep,'ExperimentInitialized',{'initial_hypotheses':['H-left','H-right-v1'],'benchmark_sha256':sha(BENCH)},actor='controller',role='MetaObserver',proof_seq_ref=p0['seq'])
    obs(ep,'OracleSealConfirmed',{'oracle_commitment_sha256':jload(ROOT/'operator_only'/'REAL_RUN_001_SEAL_MANIFEST_v0.3.json')['hidden_oracle_sha256'],'runtime_access':'forbidden'},actor='operator',role='MetaObserver')
    for role,model in man['role_models'].items(): obs(ep,'AgentRegistered',{'model_alias':model},actor=model,role=role)
    jwrite(ep/'operator'/'phase_state.json',{'phase':'first_closure','first_commit_done':False,'invalidation_done':False,'frozen':False})
    jwrite(ep/'operator'/'failure_memory.json',{'invalidated_routes':[],'rejection_reasons':[],'certificate_lineage':[]})
    emit_workspace(ep)

def ensure_route(ep,proposal):
    st=proof_state(ep); rid=proposal['action']['route_id']; bench=jload(BENCH)
    if rid in st['route_certs']: return
    cat={x['route_id']:x for x in bench['repair_route_catalog']}
    if rid not in cat: raise ValueError(f'route_id not in public catalog: {rid}')
    r=cat[rid]
    proof(ep,'RouteCertified',{'route_cert':{'route_id':rid,'scope':r['scope'],'status':'candidate','representation':r['candidate_rule']}},'route-registry')

def ingest_proposal(ep,path,role):
    d=validate_file(path,'Proposal_Output_Schema_v0.3.json'); ensure_route(ep,d)
    ev=proof(ep,'ActionProposed',{'action':d['action']},role)
    obs(ep,'ProposalObserved',{'proposal_id':d['proposal_id'],'hypothesis_id':d['hypothesis_id'],'route_signature':d['route_signature'],'route_id':d['action']['route_id'],
        'dependencies':d['dependencies'],'predicted_exclusion':d['action']['predicted_exclusion'],'evidence_members':d['evidence_members'],'justification_summary':d['justification_summary']},actor=role,role=role,proof_seq_ref=ev['seq'])
    return d

def ingest_verification(ep,path,role):
    d=validate_file(path,'Verification_Output_Schema_v0.3.json')
    pseq=None
    if d['result']=='pass':
        ev=proof(ep,'CertificateVerified',{'certificate':{'certificate_id':d['certificate_id'],'action_id':d['proposal_id'].replace('PROP','ACT') if False else _proposal_action_id(ep,d['proposal_id']),
             'kind':'exclusion','excluded_members':d['excluded_members'],'dependencies':d['dependencies'],'verification':'pass','checker_fingerprint':f'agent-verifier-v03:{role}',
             'statement_fingerprint':d['route_signature'],'version':'v1'}},role); pseq=ev['seq']
        obs(ep,'HypothesisSupported',{'proposal_id':d['proposal_id'],'certificate_id':d['certificate_id'],'route_signature':d['route_signature']},actor=role,role=role,proof_seq_ref=pseq)
    else:
        hyp=_proposal_hypothesis(ep,d['proposal_id']); route=_proposal_route(ep,d['proposal_id'])
        obs(ep,'HypothesisRejected',{'hypothesis_id':hyp,'proposal_id':d['proposal_id'],'route_signature':d['route_signature'] or route,'reason_class':d['reason_class'],'summary':d['verification_summary']},actor=role,role=role)
    obs(ep,'VerificationObserved',{'proposal_id':d['proposal_id'],'certificate_id':d['certificate_id'],'result':d['result'],'route_signature':d['route_signature'],
        'excluded_members':d['excluded_members'],'dependencies':d['dependencies'],'reason_class':d['reason_class'],'verification_summary':d['verification_summary'],'counterexample':d.get('counterexample')},actor=role,role=role,proof_seq_ref=pseq)
    return d

def _obs_events(ep): return load_jsonl(ep/'operator'/'observer_ledger.jsonl')
def _proposal_event(ep,pid):
    for e in reversed(_obs_events(ep)):
        if e['kind']=='ProposalObserved' and e['payload'].get('proposal_id')==pid: return e
    raise ValueError(f'unknown proposal_id {pid}')
def _proposal_action_id(ep,pid):
    e=_proposal_event(ep,pid); rid=e['payload']['route_id']
    # find latest proof ActionProposed for route matching predicted exclusion
    for x in reversed(load_jsonl(ep/'operator'/'proof_ledger.jsonl')):
        if x['kind']=='ActionProposed' and x['payload']['action']['route_id']==rid and x['payload']['action']['predicted_exclusion']==e['payload']['predicted_exclusion']:
            return x['payload']['action']['action_id']
    raise ValueError('proposal action not found')
def _proposal_hypothesis(ep,pid): return _proposal_event(ep,pid)['payload']['hypothesis_id']
def _proposal_route(ep,pid): return _proposal_event(ep,pid)['payload']['route_signature']

def ingest_audit(ep,path,role):
    d=validate_file(path,'Audit_Output_Schema_v0.3.json'); kind='CoverageAudited' if d['audit_type']=='coverage' else 'BoundaryAudited'
    ev=proof(ep,kind,{'ok':d['ok'],'certificate':d['certificate']},role)
    obs(ep,'VerificationObserved',{'audit_type':d['audit_type'],'result':'pass' if d['ok'] else 'fail','certificate_id':d['certificate'],'verification_summary':d['summary']},actor=role,role=role,proof_seq_ref=ev['seq'])

def commit(ep):
    st=proof_state(ep)
    pending=[cid for cid,node in st['proof_dag']['nodes'].items() if node.get('status')=='verified-pending']
    if not pending: raise ValueError('no verified-pending certificates')
    if not st['gcc']['cover_ok'] or not st['gcc']['boundary_ok']: raise ValueError('coverage/boundary gates not both true')
    if st['pipeline_stage']!='GlueAudit':
        # BoundaryAudited leaves GlueAudit stage.
        pass
    proof(ep,'GlueAudited',{'mode':'RefutationOnly','ok':True,'certificate':'finite-glue-not-required'},'glue-auditor')
    ev=proof(ep,'CommitEpoch',{'certificate_ids':pending},'commit-controller')
    ps=jload(ep/'operator'/'phase_state.json')
    if not ps['first_commit_done']:
        ps['first_commit_done']=True; ps['phase']='awaiting_invalidation'
    else: ps['phase']='reclosed'
    jwrite(ep/'operator'/'phase_state.json',ps); emit_workspace(ep); return ev

def invalidate(ep):
    ps=jload(ep/'operator'/'phase_state.json')
    if not ps['first_commit_done']: raise ValueError('first closure not committed')
    if ps['invalidation_done']: raise ValueError('invalidation already done')
    st=proof_state(ep); targets=[cid for cid,node in st['proof_dag']['nodes'].items() if node.get('status')=='active' and 'affine-bound@v1' in node.get('dependencies',[])]
    if not targets: raise ValueError('no active affine-bound@v1 certificate to invalidate')
    mem=jload(ep/'operator'/'failure_memory.json')
    for cid in targets:
        node=st['proof_dag']['nodes'][cid]
        ev=proof(ep,'CertificateInvalidated',{'certificate_id':cid,'reason':'dependency-version-retired'},'dependency-auditor')
        # identify proposal metadata
        prop=None
        for o in _obs_events(ep):
            if o['kind']=='VerificationObserved' and o['payload'].get('certificate_id')==cid: prop=o['payload']; break
        route=(prop or {}).get('route_signature','UNKNOWN')
        mem['invalidated_routes'].append(route); mem['rejection_reasons'].append({'certificate_id':cid,'reason_class':'dependency-version-retired','route_signature':route}); mem['certificate_lineage'].append({'old':cid,'status':'stale'})
        obs(ep,'HypothesisRejected',{'hypothesis_id':'H-invalidated-'+cid,'route_signature':route,'reason_class':'certificate-invalidated','summary':'Canonical dependency retirement invalidated a previously passed certificate.'},actor='dependency-auditor',role='MetaObserver',proof_seq_ref=ev['seq'])
    jwrite(ep/'operator'/'failure_memory.json',mem)
    ps['invalidation_done']=True; ps['phase']='repair'; jwrite(ep/'operator'/'phase_state.json',ps)
    man=jload(ep/'operator'/'run_manifest.json')
    if man['memory_condition']=='ablated-after-invalidation': obs(ep,'MemoryReset',{'scope':'failure-history-only','preserved_authoritative_state':True},actor='controller',role='MetaObserver')
    else: obs(ep,'MemorySnapshot',{'scope':'failure-history','preserved':True,'items':len(mem['rejection_reasons'])},actor='controller',role='MetaObserver')
    emit_workspace(ep)

def status(ep):
    st=proof_state(ep); ps=jload(ep/'operator'/'phase_state.json')
    return {'episode_id':jload(ep/'operator'/'run_manifest.json')['episode_id'],'phase':ps['phase'],'epoch':st['epoch'],'survivor':st['survivor']['members'],'gcc_valid':st['gcc']['valid'],
            'verified_pending':[cid for cid,n in st['proof_dag']['nodes'].items() if n.get('status')=='verified-pending'],'active':[cid for cid,n in st['proof_dag']['nodes'].items() if n.get('status')=='active'],'stale':[cid for cid,n in st['proof_dag']['nodes'].items() if n.get('status')=='stale']}

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    for c in ['init','status','emit-workspace','commit','invalidate']:
        sp=sub.add_parser(c); sp.add_argument('--episode-dir',type=Path,required=True)
    for c,schema_role in [('ingest-proposal','Proposer'),('ingest-verification','Verifier'),('ingest-audit','Auditor')]:
        sp=sub.add_parser(c); sp.add_argument('--episode-dir',type=Path,required=True); sp.add_argument('--file',type=Path,required=True); sp.add_argument('--role',required=True)
    a=ap.parse_args(); ep=a.episode_dir
    if a.cmd=='init': init_episode(ep); print(json.dumps(status(ep),ensure_ascii=False,indent=2))
    elif a.cmd=='status': print(json.dumps(status(ep),ensure_ascii=False,indent=2))
    elif a.cmd=='emit-workspace': emit_workspace(ep); print(json.dumps(status(ep),ensure_ascii=False,indent=2))
    elif a.cmd=='ingest-proposal': print(json.dumps(ingest_proposal(ep,a.file,a.role),ensure_ascii=False,indent=2))
    elif a.cmd=='ingest-verification': print(json.dumps(ingest_verification(ep,a.file,a.role),ensure_ascii=False,indent=2))
    elif a.cmd=='ingest-audit': ingest_audit(ep,a.file,a.role); print(json.dumps(status(ep),ensure_ascii=False,indent=2))
    elif a.cmd=='commit': commit(ep); print(json.dumps(status(ep),ensure_ascii=False,indent=2))
    elif a.cmd=='invalidate': invalidate(ep); print(json.dumps(status(ep),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
