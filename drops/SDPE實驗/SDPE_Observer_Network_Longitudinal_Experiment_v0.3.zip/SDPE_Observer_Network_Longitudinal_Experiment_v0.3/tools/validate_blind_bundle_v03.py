#!/usr/bin/env python3
from pathlib import Path
import argparse,json,sys
BANNED_NAMES={'REAL_RUN_001_HIDDEN_ORACLE_v0.3.json','freeze_manifest.json','proof_ledger.jsonl','observer_ledger.jsonl','failure_memory.json'}
BANNED_TOKENS=['route_rule_semantic_validity','theorem_truth','member_truth','scoring_policy','semantic_false_is_not_required_for_invalidation']
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('bundle',type=Path); a=ap.parse_args(); issues=[]
 for p in a.bundle.rglob('*'):
  if not p.is_file(): continue
  if p.name in BANNED_NAMES: issues.append(f'banned file name: {p.relative_to(a.bundle)}')
  try: text=p.read_text(encoding='utf-8')
  except Exception: continue
  for t in BANNED_TOKENS:
   if t in text: issues.append(f'banned token {t}: {p.relative_to(a.bundle)}')
 out={'ok':not issues,'issues':issues,'bundle':str(a.bundle)}; print(json.dumps(out,ensure_ascii=False,indent=2)); sys.exit(0 if not issues else 2)
if __name__=='__main__': main()
