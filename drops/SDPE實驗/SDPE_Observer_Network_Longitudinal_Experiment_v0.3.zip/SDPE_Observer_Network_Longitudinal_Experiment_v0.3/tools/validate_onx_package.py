#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, sys
from pathlib import Path

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
issues = []

# UTF-8 + canonical math delimiters for markdown.
for p in sorted(root.rglob("*.md")):
    try:
        txt = p.read_bytes().decode("utf-8")
    except Exception as e:
        issues.append(f"utf8:{p}:{e}")
        continue
    for tok in (r"\(", r"\)", r"\[", r"\]"):
        if tok in txt:
            issues.append(f"forbidden_delimiter:{p}:{tok}")
    noesc = re.sub(r"\\\$", "", txt)
    if noesc.count("$$") % 2:
        issues.append(f"unbalanced_display:{p}")
    if noesc.replace("$$", "").count("$") % 2:
        issues.append(f"unbalanced_inline:{p}")

# JSON parse.
for p in sorted(root.rglob("*.json")):
    try:
        json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        issues.append(f"json:{p}:{e}")

# JSONL parse + contiguous seq.
for p in sorted(root.rglob("*.jsonl")):
    rows=[]
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip(): rows.append(json.loads(line))
    key = "obs_seq" if rows and "obs_seq" in rows[0] else "seq"
    for i,r in enumerate(rows):
        if int(r[key]) != i:
            issues.append(f"noncontiguous:{p}:{key}:{i}->{r[key]}")

report = {"ok": not issues, "issues": issues}
(root / "VALIDATION_ONX_v0.1.json").write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
print(json.dumps(report, ensure_ascii=False, indent=2))
sys.exit(0 if not issues else 1)
