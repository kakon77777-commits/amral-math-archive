#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,datetime
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--episode-dir',type=Path,required=True); a=ap.parse_args(); ep=a.episode_dir; op=ep/'operator'
 rm=json.loads((op/'run_manifest.json').read_text(encoding='utf-8')); rm['status']='frozen'; (op/'run_manifest.json').write_text(json.dumps(rm,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 files=['proof_ledger.jsonl','observer_ledger.jsonl','run_manifest.json','phase_state.json']
 man={'episode_id':rm['episode_id'],'frozen':True,'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hashes':{f:sha(op/f) for f in files}}
 (op/'freeze_manifest.json').write_text(json.dumps(man,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps(man,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
