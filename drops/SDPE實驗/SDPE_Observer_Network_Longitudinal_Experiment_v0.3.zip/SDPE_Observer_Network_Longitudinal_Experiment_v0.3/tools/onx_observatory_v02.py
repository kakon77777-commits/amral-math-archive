#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
from typing import Any, Dict, List

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RUNTIME_DIR = ROOT / "reference_runtime"
sys.path.insert(0, str(RUNTIME_DIR))
import sdpe_runtime  # type: ignore


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]


def validate_contiguous(events, key):
    for i,e in enumerate(events):
        if int(e[key]) != i: raise ValueError(f"non-contiguous {key}: expected {i}, got {e[key]}")


def proof_series(events):
    state=sdpe_runtime.empty_state(); out={}; n0=None; invalidations=[]; reclosures=[]
    prev_gcc=False
    for ev in events:
        state=sdpe_runtime.reduce_event(state, ev)
        if n0 is None and state.get("universe"): n0=len(state["universe"])
        n0=max(1,n0 or 1); ns=len(state["survivor"]["members"])
        gcc=bool(state["gcc"]["valid"])
        if ev["kind"]=="CertificateInvalidated": invalidations.append(int(ev["seq"]))
        if gcc and not prev_gcc: reclosures.append(int(ev["seq"]))
        prev_gcc=gcc
        out[int(ev["seq"])]={
            "proof_seq":int(ev["seq"]),"survivor_count":ns,"PER":1-ns/n0,"gcc_valid":gcc,
            "epoch":int(state["epoch"]),"D_resolve":state.get("dvi",{}).get("D_resolve"),
            "D_frontier":state.get("dvi",{}).get("D_frontier"),"W":state.get("dvi",{}).get("W"),
            "sigma":state.get("dvi",{}).get("sigma")}
    return out, invalidations, reclosures, state


def observer_series(events):
    hypotheses={}; initial=[]; proposals={}; rejected=set(); pass_certs=[]; route_reintro=0; repair=0
    tokens=wall=tools=0.0; memory_resets=0; rows={}
    invalid_routes=set(); repair_period_proposals=0; post_inv=False
    for ev in events:
        k=ev["kind"]; p=ev.get("payload",{})
        if k=="ExperimentInitialized":
            initial=list(p.get("initial_hypotheses",[])); hypotheses.update({h:"active" for h in initial})
        elif k=="HypothesisRegistered": hypotheses[p["hypothesis_id"]]=p.get("status","active")
        elif k=="HypothesisRejected":
            hypotheses[p["hypothesis_id"]]="rejected"; rejected.add(p["hypothesis_id"])
            if p.get("route_signature"): invalid_routes.add(p["route_signature"])
            if p.get("reason_class") in {"certificate-invalidated","oracle-false"}: post_inv=True
        elif k=="HypothesisReopened": hypotheses[p["hypothesis_id"]]="active"
        elif k=="ProposalObserved":
            proposals[p["proposal_id"]]=p.get("hypothesis_id")
            if post_inv: repair_period_proposals += 1
        elif k=="VerificationObserved" and p.get("result")=="pass":
            if p.get("certificate_id"): pass_certs.append(p["certificate_id"])
        elif k=="RepairObserved": repair += 1
        elif k=="RouteReintroduced": route_reintro += 1
        elif k=="MemoryReset": memory_resets += 1
        elif k=="CostObserved":
            tokens += float(p.get("tokens",0)); wall += float(p.get("wall_seconds",0)); tools += float(p.get("tool_calls",0))
        n0=max(1,len(initial) or len(hypotheses) or 1); alive=sum(1 for s in hypotheses.values() if s!="rejected")
        rows[int(ev["obs_seq"])]={"obs_seq":int(ev["obs_seq"]),"proof_seq_ref":ev.get("proof_seq_ref"),
            "active_hypothesis_count":alive,"EER":1-alive/n0,"proposal_count":len(proposals),
            "verification_pass_count":len(pass_certs),"repair_count":repair,"route_reintroduction_count":route_reintro,
            "repair_period_proposals":repair_period_proposals,"memory_reset_count":memory_resets,"tokens":tokens,
            "wall_seconds":wall,"tool_calls":tools}
    return rows,{"pass_certs":pass_certs,"route_reintro":route_reintro,"repair_period_proposals":repair_period_proposals,
                 "tokens":tokens,"wall_seconds":wall,"tool_calls":tools,"memory_resets":memory_resets,"repair_count":repair}


def first_reclosure_after(invalidations,reclosures):
    if not invalidations: return None,None
    inv=invalidations[0]
    close=next((s for s in reclosures if s>inv),None)
    return inv,close


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--proof-ledger',type=Path,required=True); ap.add_argument('--observer-ledger',type=Path,required=True)
    ap.add_argument('--json-out',type=Path,required=True); ap.add_argument('--csv-out',type=Path,required=True)
    args=ap.parse_args(); pe=load_jsonl(args.proof_ledger); oe=load_jsonl(args.observer_ledger)
    validate_contiguous(pe,'seq'); validate_contiguous(oe,'obs_seq')
    pt,invs,recls,state=proof_series(pe); ot,om=observer_series(oe)
    inv,close=first_reclosure_after(invs,recls)
    invalidated_certs={e['payload']['certificate_id'] for e in pe if e['kind']=='CertificateInvalidated'}
    invalidated_passes=sum(1 for c in om['pass_certs'] if c in invalidated_certs)
    IPR=invalidated_passes/max(1,len(om['pass_certs']))
    IRR=om['route_reintro']/max(1,om['repair_period_proposals'])
    rows=[]
    for os in sorted(ot):
        r=dict(ot[os]); ps=r.get('proof_seq_ref')
        if ps is not None and int(ps) in pt: r.update({f'proof_{k}':v for k,v in pt[int(ps)].items() if k!='proof_seq'})
        rows.append(r)
    final_obs=ot[max(ot)]; final_proof=pt[max(pt)]
    summary={"PER":final_proof['PER'],"EER":final_obs['EER'],"survivor_count":final_proof['survivor_count'],
        "active_hypothesis_count":final_obs['active_hypothesis_count'],"gcc_valid":final_proof['gcc_valid'],
        "repair_lag_proof_seq":None if close is None else close-inv,"invalidation_seq":inv,"reclosure_seq":close,
        "IRR":IRR,"IPR":IPR,"FCR":None,"oracle_scored":False,"repair_count":om['repair_count'],
        "pass_verification_count":len(om['pass_certs']),"route_reintroduction_count":om['route_reintro'],
        "repair_period_proposals":om['repair_period_proposals'],"tokens":om['tokens'],"wall_seconds":om['wall_seconds'],
        "tool_calls":om['tool_calls'],"memory_resets":om['memory_resets'],"D_resolve":final_proof['D_resolve'],
        "D_frontier":final_proof['D_frontier'],"W":final_proof['W'],"sigma":final_proof['sigma'],
        "proof_state_fingerprint":sdpe_runtime.replay(pe).get('state_fingerprint')}
    snap={"summary":summary,"timeline":rows}
    args.json_out.write_text(json.dumps(snap,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    fields=sorted({k for r in rows for k in r});
    with args.csv_out.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
