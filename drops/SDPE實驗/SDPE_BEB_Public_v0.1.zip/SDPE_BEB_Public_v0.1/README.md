# SDPE Blind Enclosure Benchmark v0.1

第一批 SDPE commit–reveal 盲測工具包。

## 建議使用方式

1. **只把 `SDPE_BEB_Public_v0.1.zip` 給研究 Agent。**
2. 將 `SDPE_BEB_Oracle_v0.1.zip` 保存在另一個對話、process 或人工保管端。
3. 研究 Agent 對 public tasks 產生 submission JSONL。
4. 研究結束後才使用 Oracle Bundle 的 `audit_reveal.py` 開封、驗 commitment 與結果。

## Public runner

檢視某題初始 action：

```bash
python tools/public_runner.py inspect public/tasks/PARITY-000.json
```

重播 submission：

```bash
python tools/public_runner.py replay public/tasks/PARITY-000.json submission.json
```

## Submission minimum

```json
{
  "task_id": "PARITY-000",
  "selected_actions": ["..."],
  "declared_closed": true
}
```

## 重要限制

v0.1 是 instrumented routing benchmark。它沒有隱藏候選 theorem actions，因此主要測試 closure / routing / bridge / exceptional-core mechanics；**不應把 v0.1 的成功率當成 autonomous theorem discovery 或 Strong DVI 的證據。**

完整實驗定義見 `docs/SDPE_BEB_v0.1_Experimental_Protocol.md`。
