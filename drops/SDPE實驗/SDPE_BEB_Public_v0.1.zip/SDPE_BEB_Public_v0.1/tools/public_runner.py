#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
from common import replay, action_map, action_predicate, apply_pred, universe, verify_action_certificate, total_cost

def inspect(task):
    amap=action_map(task); surv=universe(task); rows=[]
    for aid in task['initially_unlocked']:
        a=amap[aid]; ok,_=verify_action_certificate(task,a); pred=action_predicate(task,a)
        after=surv if pred is None else apply_pred(surv,pred)
        rows.append({'action_id':aid,'type':a['action_type'],'certificate_ok':ok,'immediate_elimination':len(surv)-len(after),'model_cost':total_cost(a),'tags':a.get('tags',[]),'unlocks':a.get('unlocks',[])})
    return {'task_id':task['task_id'],'family':task['family'],'n_vars':task['n_vars'],'budget':task['budget'],'initial_survivor_size':len(surv),'initial_actions':rows,'oracle_commitment':task['oracle_commitment']}

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('inspect'); p.add_argument('task')
    p=sub.add_parser('replay'); p.add_argument('task'); p.add_argument('submission')
    args=ap.parse_args(); task=json.loads(Path(args.task).read_text(encoding='utf-8'))
    if args.cmd=='inspect': out=inspect(task)
    else:
        subm=json.loads(Path(args.submission).read_text(encoding='utf-8'))
        if subm['task_id']!=task['task_id']: raise SystemExit('task_id mismatch')
        out=replay(task,subm['selected_actions'])
        out['task_id']=task['task_id']
        out['within_budget']=len(subm['selected_actions'])<=task['budget']
    print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True))
if __name__=='__main__': main()
