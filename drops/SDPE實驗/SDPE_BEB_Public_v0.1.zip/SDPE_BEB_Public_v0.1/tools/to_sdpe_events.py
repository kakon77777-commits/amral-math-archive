#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,datetime
from pathlib import Path
from common import replay,action_map,verify_action_certificate

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('task'); ap.add_argument('submission'); ap.add_argument('--out',required=True); a=ap.parse_args()
    task=json.loads(Path(a.task).read_text(encoding='utf-8')); sub=json.loads(Path(a.submission).read_text(encoding='utf-8'))
    rr=replay(task,sub['selected_actions']); amap=action_map(task); events=[]; seq=0
    def emit(kind,payload,actor):
        nonlocal seq
        events.append({'seq':seq,'kind':kind,'payload':payload,'actor':actor,'timestamp':'benchmark-replay'}); seq+=1
    emit('ProblemInitialized',{'problem_id':task['task_id'],'benchmark_family':task['family'],'n_vars':task['n_vars'],'budget':task['budget'],'oracle_commitment':task['oracle_commitment']},'beb-adapter')
    for tr in rr['trace']:
        act=amap[tr['action_id']]
        emit('RouteDecisionRecorded',{'action_id':act['action_id'],'tags':act.get('tags',[]),'before':tr['before']},'router')
        if act['action_type']=='bridge':
            emit('TelemetryObserved',{'bridge_activated':act['action_id'],'survivor_size':tr['after'],'proof_authority':False},'observatory')
            continue
        emit('ActionProposed',{'action_id':act['action_id'],'predicate_source':act.get('predicate_source')},'proposer')
        ok,info=verify_action_certificate(task,act)
        emit('CertificateVerified',{'action_id':act['action_id'],'passed':ok,'certificate':act['certificate'],'checker_info':info},'verifier')
        if ok:
            emit('CommitEpoch',{'action_id':act['action_id'],'survivor_before':tr['before'],'survivor_after':tr['after'],'eliminated':tr['eliminated']},'commit-controller')
    emit('TelemetryObserved',{'closed':rr['closed'],'final_survivor_size':rr['final_survivor_size'],'model_cost':rr['model_cost']},'observatory')
    Path(a.out).write_text('\n'.join(json.dumps(e,ensure_ascii=False,sort_keys=True) for e in events)+'\n',encoding='utf-8')
if __name__=='__main__': main()
