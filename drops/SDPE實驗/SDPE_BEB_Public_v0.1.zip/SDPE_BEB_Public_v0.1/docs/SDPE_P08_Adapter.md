# SDPE-BEB v0.1 → `sdpe-runtime-v1` Adapter

BEB v0.1 使用 Paper 08 的核心 authority contract：只有 certificate-gated commit 可以縮 survivor；bridge / routing / observatory 不具有 proof authority。

## Mapping

| BEB field | SDPE Runtime object |
|---|---|
| Boolean assignment universe | `state.universe` |
| current finite candidates | `state.survivor.members` |
| direct/derived cut | `ActionProposed` + `CertificateVerified` |
| bridge | `RouteDecisionRecorded` / route-state update only |
| action dependencies | `proof_dag.edges` |
| selected route | `route_decision` |
| hidden answer | benchmark oracle only; never authoritative runtime state |
| commitment | benchmark audit metadata |
| finite empty survivor | candidate for `GCC.Valid` after required coverage/boundary gates |

## Runtime invariant

BEB finite tasks use exact enumeration only as a **benchmark adapter implementation** for survivor-state telemetry and certificate checking. The method being tested remains:

$$
\boxed{
\mathcal C\subseteq\Omega_t.
}
$$

The hidden oracle is never allowed to mutate $\Omega_t$.
