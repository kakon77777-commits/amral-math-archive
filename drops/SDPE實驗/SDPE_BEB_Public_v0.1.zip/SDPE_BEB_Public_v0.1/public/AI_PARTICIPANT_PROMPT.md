# SDPE-BEB v0.1 — Participant Prompt

你正在參與一個 SDPE（Spatial-Domain Proof Enclosure）blind benchmark。

你只能使用本 Public Bundle。不要要求、搜尋或取得 Oracle Bundle，也不要呼叫 unrestricted exhaustive solver 直接重新計算整題 ground truth。

## 你的目標

對 `public/tasks/*.json` 的每一題，在其 `budget` 內選擇一條 action route。

每題初始 survivor 為全部 $2^n$ 個 Boolean assignments。只有通過 certificate checker 的 `cut` action 可以縮 survivor。`bridge` action只能 unlock route，不能直接當 proof。

你可以使用：

```bash
python tools/public_runner.py inspect public/tasks/<TASK>.json
```

與你自己形成的 submission 重播：

```bash
python tools/public_runner.py replay public/tasks/<TASK>.json submission.json
```

但請保持研究語義：不要自行加入一個「枚舉所有 premises 然後直接輸出真值」的 oracle shortcut。

## 需要輸出

建立一個 `submissions.jsonl`，每行至少：

```json
{
  "task_id": "PARITY-000",
  "selected_actions": ["ACTION_1", "ACTION_2"],
  "declared_closed": true,
  "declared_counterexample": false,
  "notes": "brief route rationale"
}
```

如果 route 沒有得到 empty survivor，不要因 survivor 很小就宣告 closure。

## 建議另外保存 telemetry

對每題保存：

- selected route；
- survivor size per step；
- immediate exclusion yield；
- bridge actions；
- modeled cost；
- 是否在 budget 內 closure；
- 你為什麼選這條 route。

## 禁止偷換

$$
\boxed{
\text{tiny survivor}
\neq
\text{closed proof}
}
$$

$$
\boxed{
\text{bridge selected}
\neq
\text{theorem proved}
}
$$

$$
\boxed{
\text{oracle commitment}
\neq
\text{oracle answer}
}
$$

完成後只交回 `submissions.jsonl` 與你的研究 trace。Oracle 將由另一個 audit process 開封。
