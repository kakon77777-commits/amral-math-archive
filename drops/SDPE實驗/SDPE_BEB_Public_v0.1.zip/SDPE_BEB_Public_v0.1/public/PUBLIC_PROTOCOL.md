# SDPE-BEB v0.1 — Blind Research-Side Protocol

你現在位於 **research side**。請不要取得或要求 Oracle Bundle。

## 任務

每題的公開 claim 都是：不存在任何 Boolean assignment 同時滿足全部 premises。

你可以依 action dependency / certificate 規格選擇研究動作。每題有固定 budget。

合法 closure 只能來自：

$$
\boxed{
\Omega_T=\varnothing
}
$$

且所有使用中的 cut certificate 都通過 verifier。

## 不允許作為 closure 依據

- oracle commitment 本身；
- model confidence；
- sampled coverage；
- survivor ratio 很小；
- 未驗證 derived cut；
- bridge action 本身。

## Blind rule

本資料集是有限 problem，因此 participant 若刻意執行 unrestricted exhaustive oracle，理論上可以自行重算 ground truth。這會破壞本 trial 的方法論目的。

本輪請只使用公開 action / certificate / runner interface 完成研究路由。

## 產出

對每題輸出：

```json
{
  "task_id": "...",
  "selected_actions": ["..."],
  "declared_closed": false,
  "declared_counterexample": false,
  "notes": "optional"
}
```

`declared_closed=true` 時，選擇的 actions 重播後必須真的得到 empty survivor。
