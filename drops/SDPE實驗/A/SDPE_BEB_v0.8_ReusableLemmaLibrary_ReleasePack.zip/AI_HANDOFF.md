# AI Handoff — SDPE-BEB v0.8

Current canonical frontier: reusable lemma-schema library with cross-task transfer and provenance guards.

Do not regress these invariants:

1. Library entries are discovery hints, not target proof authority.
2. Target instantiated lemmas are re-certified.
3. Lookup signature ignores RHS and forbidden assignment values.
4. SAT and UNSAT share each structural signature.
5. Calibration library is frozen during the 57-task evaluation phase.
6. Report synthesis cost and proof-verification cost separately.
7. Preserve canonical UTF-8 source and `$...$` / `$$...$$` math delimiters.

The next research frontier is not merely a larger library. It is selective transfer under distribution shift: deciding when a library item should be trusted as a useful search prior, when it should be quarantined, and how to update the library without catastrophic proof-search pollution.
