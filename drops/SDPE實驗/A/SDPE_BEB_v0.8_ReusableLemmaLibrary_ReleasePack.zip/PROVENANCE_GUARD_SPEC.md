# Provenance Guard Specification

## 1. Purpose

Cross-task reuse creates a new failure mode: a proof fragment may be valid in its source task but stale, corrupted, or inapplicable in a target task.

v0.8 therefore separates **origin integrity** from **target semantic authority**.

## 2. Origin integrity

A library entry records a digest over its source binding and extracted template. Mutating any of the following invalidates the entry digest:

- source dataset version;
- source task hash;
- source submission hash;
- match signature;
- proof architecture;
- source proof quality.

SHA-256 is used as an engineering integrity mechanism. Collision resistance is an external cryptographic assumption, not a mathematical theorem proved by this benchmark.

## 3. Target authority

Even a provenance-valid entry is untrusted as a target theorem.

Target instantiation must satisfy all ordinary target-task invariants:

$$
\text{typed dependencies}\land\text{acyclic DAG}\land\text{fan-in bound}\land\text{certificate correctness}\land\text{budget validity}.
$$

## 4. Negative transfer

A structural match can occur on a SAT target. Such a match is permitted.

The expected behavior is:

$$
\text{library hit}\land\text{template inapplicable}\Rightarrow\text{no certified closure}.
$$

The solver may then return a verified witness or fall back to fresh discovery.
