# Cross-Task Transfer Soundness and Verification-Separation Theorem

## Theorem 1 — Non-authoritative transfer soundness

Let $t$ be a target task with public premise model set $M(P_t)$. Let a reusable library entry propose a target proof DAG with instantiated lemmas $\ell_1,\ldots,\ell_k$.

Assume the canonical target verifier accepts every lemma certificate. Then for every $j$,

$$
M(P_t)\subseteq M(\ell_j).
$$

If the final symbolic replay closes,

$$
\bigcap_{j\in J}M(\ell_j)\cap\bigcap_{i\in I}M(P_{t,i})=\varnothing,
$$

then

$$
M(P_t)=\varnothing.
$$

### Proof

The reusable library entry is not part of the semantic authority relation. Every target lemma is accepted only after the same target-task certificate checks used for freshly proposed lemmas. By induction over the verified proof DAG, every accepted target lemma contains all target premise models. Intersecting sound consequences cannot remove a genuine target model unless no genuine model exists. Therefore a certified empty replay implies target inconsistency. $\square$

## Theorem 2 — Transfer cannot discount target lemma verification

Suppose a certified target proof uses $L(t)$ target-task lemmas, and each target lemma must be individually accepted by the proposal broker before entering the fact pool. Then the number of target proposal-verification queries satisfies

$$
P_{\mathrm{target}}(t)\ge L(t).
$$

A reusable library may reduce architecture discovery or synthesis work, but it cannot reduce this authority lower bound unless the verifier itself adopts a new trusted proof rule.

## Proposition 3 — Alpha-renaming invariance of the v0.8 lookup key

For any permutation $\pi$ of the variable coordinates,

$$
\sigma(\pi\cdot t)=\sigma(t).
$$

This follows because $\sigma$ depends only on the number of variables, the multiset of parity support cardinalities, and the number of forbidden-assignment premises.

## Experimental corollary

After three calibration tasks, the frozen library contains three entries. On the 57-task evaluation phase:

$$
57/57
$$

evaluation tasks produce a structural library hit. Of these, 27 hits instantiate closing UNSAT proof fragments and 30 hits are benignly inapplicable SAT cases.

Cold architecture synthesis uses

$$
57
$$

benchmark-owned synthesis operations, while frozen-library evaluation uses

$$
0.
$$

However target proof-authority proposal verification remains exactly

$$
90\to90.
$$

Thus the measured transfer advantage is a discovery/synthesis advantage, not an authority shortcut.
