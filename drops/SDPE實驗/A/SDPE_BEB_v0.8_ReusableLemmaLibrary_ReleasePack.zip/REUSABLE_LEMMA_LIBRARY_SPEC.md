# SDPE-BEB v0.8 — Reusable Lemma-Schema Library Specification

## 1. Scope

v0.8 extends the v0.7 adaptive proof-space model from single-task growth to cross-task reuse.

The reusable object is deliberately **not** a target theorem and **not** a proof-authority token. It is a provenance-bound lemma-schema / proof-fragment template extracted from a previously certified proof.

A library entry may accelerate discovery of a target proof architecture, but every instantiated target lemma must still pass the canonical target-task verifier.

## 2. Structural lookup key

For the current benchmark family, the public lookup signature is

$$
\sigma(t)=\left(n,\operatorname{sort}\{|S_i|:P_i\text{ is parity}\},N_{\mathrm{forbid}}\right).
$$

The signature ignores:

- variable names and their permutation;
- parity right-hand sides;
- forbidden-assignment values;
- task IDs;
- constraint IDs;
- action IDs;
- premise and action order.

Therefore a signature match is an alpha-renaming-invariant structural match, not a truth label.

## 3. Entry contents

Each entry binds:

- source dataset version;
- source task ID and canonical SHA-256;
- source submission SHA-256;
- source proof quality;
- structural match signature;
- extracted proof architecture;
- certificate-kind sequence;
- dependency-arity sequence;
- entry digest and template ID.

## 4. Authority boundary

Library provenance authenticates origin only.

For a target task $t$, an instantiated lemma $\ell$ enters the certified fact pool only if the target verifier proves

$$
M(P_t)\subseteq M(\ell).
$$

A stale, malicious, or semantically inapplicable library entry can at most create a rejected proposal or wasted discovery effort. It cannot itself certify target UNSAT.

## 5. Calibration and evaluation

The fixed transfer episode contains three unscored calibration tasks and 57 evaluation tasks. Calibration is used to build and freeze a three-entry library. Evaluation then measures reuse without further library mutation.

This separation prevents evaluation answers from being folded back into the library during the measured phase.
