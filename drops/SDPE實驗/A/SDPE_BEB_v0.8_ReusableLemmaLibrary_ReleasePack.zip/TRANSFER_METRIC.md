# Transfer Metrics

v0.8 reports two deliberately separate cost families.

## Discovery / synthesis cost

Let $S_{\mathrm{arch}}$ count benchmark-owned proof-architecture synthesis operations.

A frozen-library hit may reduce $S_{\mathrm{arch}}$ because the architecture is retrieved rather than rediscovered.

## Proof-authority verification cost

Let $P_{\mathrm{target}}$ count target lemma proposals checked by the canonical proposal broker.

Library reuse does not discount this count.

The central measured pair is therefore

$$
\left(S_{\mathrm{arch}},P_{\mathrm{target}}\right).
$$

For the 57-task evaluation phase:

$$
\text{cold}=(57,90),
$$

while

$$
\text{library-assisted}=(0,90).
$$

This makes the meaning of transfer explicit: less rediscovery, unchanged proof authority.
