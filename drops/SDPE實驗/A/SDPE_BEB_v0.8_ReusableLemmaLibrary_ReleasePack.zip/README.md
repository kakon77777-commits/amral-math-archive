# SDPE-BEB v0.8 — Reusable Lemma Library and Cross-Task Transfer

v0.8 extends adaptive single-task proof-space growth into provenance-bound cross-task reuse.

A library entry is a non-authoritative lemma-schema / proof-fragment template. Every instantiated target lemma is re-certified by the canonical target verifier.

All 60 tasks are re-keyed with per-task variable permutations, fresh constraint/action IDs, and reshuffled orders. The transfer key ignores RHS and forbidden-assignment values, so SAT and UNSAT tasks within one structural family share the same lookup signature.

The fixed episode uses three calibration tasks to build a frozen three-entry library and evaluates on 57 remaining tasks.

Measured evaluation result:

$$
S_{\mathrm{arch}}:57\to0,
$$

while target proof verification remains

$$
P_{\mathrm{target}}:90\to90.
$$

See `CROSS_TASK_TRANSFER_THEOREM.md`, `REUSABLE_LEMMA_LIBRARY_SPEC.md`, `PROVENANCE_GUARD_SPEC.md`, and `TRANSFER_METRIC.md`.
