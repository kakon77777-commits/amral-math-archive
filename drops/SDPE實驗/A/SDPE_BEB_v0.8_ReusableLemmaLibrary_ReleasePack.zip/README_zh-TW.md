# SDPE-BEB v0.8 — 可重用 Lemma Library 與跨題 Transfer

v0.8 把 v0.7 的「單題內 proof space 動態長大」推到跨題累積。

核心原則是：**以前證過，不等於新題免驗證。**

Library 保存的是具有 provenance 的 lemma-schema / proof-fragment template。Target task 命中 template 後，所有 instantiated lemmas 仍必須重新通過 canonical verifier。

本版 60 題全部重新做 variable permutation、constraint/action ID 重編與順序重排。Library lookup key 忽略 RHS 與 forbidden assignment value，因此同一 template 會同時命中 SAT 與 UNSAT，不能直接當答案表。

三個 calibration tasks 建出三個 library entries。Frozen library 對其餘 57 題得到 57/57 structural hits，其中 27 題可套用為 UNSAT proof，30 題是 SAT 上的 benign inapplicable hit。

實驗結果：

$$
S_{\mathrm{arch}}:57\to0,
$$

而 target proof-authority proposal queries 保持

$$
P_{\mathrm{target}}:90\to90.
$$

因此 v0.8 測到的是「避免重複發明證明架構」，不是用舊證明繞過新題驗證。
