# Version Transition — v0.7 to v0.8

$$
v0.7:\quad \text{single-task adaptive proof-space growth}
$$

becomes

$$
v0.8:\quad \text{cross-task reusable lemma-schema transfer with provenance guards}.
$$

New elements:

1. alpha-renaming and ID rekeying of all 60 tasks;
2. fixed calibration/evaluation transfer episode;
3. provenance-bound reusable library entries;
4. structural signature lookup that ignores truth-bearing RHS and assignment values;
5. frozen-library evaluation;
6. explicit separation of synthesis cost from target proof verification;
7. negative-transfer adversarial tests.

The v0.7 proof-DAG, symbolic replay, proof-quality, and adaptive proposal authorities remain unchanged underneath the transfer layer.
