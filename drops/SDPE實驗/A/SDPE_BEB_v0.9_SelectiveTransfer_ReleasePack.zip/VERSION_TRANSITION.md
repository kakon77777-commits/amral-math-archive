# Version Transition — v0.8 to v0.9

v0.8 established that a reusable lemma-schema library can reduce repeated architecture rediscovery while preserving target proof verification.

v0.9 adds controlled distribution shift and library pollution. The same coarse key can now correspond to multiple proof mechanisms. A label-blind topology applicability signature decides whether to reuse a library entry or reset to cold synthesis.

New primary objects:

$$
\sigma(t)=\text{coarse retrieval key},
$$

$$
\rho(t)=\text{topology applicability key}.
$$

The design transition is

$$
\text{always-hit transfer}
\longrightarrow
\text{selective reuse / reject / reset / learn}.
$$
