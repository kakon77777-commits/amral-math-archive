# Reusable Lemma Library Specification v0.9

A v0.9 entry contains:

- dataset, library, entry, and calculus versions;
- source task ID and canonical source-task SHA-256;
- exact source-submission SHA-256;
- coarse structural signature $\sigma$;
- applicability topology signature $\rho$;
- reusable proof architecture;
- source proof-quality vector;
- learning order and source phase;
- canonical entry digest and template ID.

Multiple entries may share the same coarse signature. This is intentional and is the mechanism used to study library pollution.

Two entries may not share the same applicability topology signature in the canonical library. Exact applicability lookup is therefore unique.

The library is not a theorem database whose statements become target facts. It is a proof-architecture memory. Every target lemma generated from an entry is reconstructed from target premises and re-certified.
