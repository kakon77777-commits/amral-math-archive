# SDPE-BEB v0.9 — Selective Transfer under Distribution Shift

## 1. Setting

Let a task be $t$ with public premise set $P_t$. Let

$$
\sigma(t)
$$

be a coarse, alpha-renaming-invariant structural signature and let

$$
\rho(t)
$$

be a finer applicability topology signature. Neither signature contains parity right-hand-side values, forbidden assignment values, task IDs, constraint IDs, action IDs, or oracle truth.

A library entry is

$$
e=(\sigma_e,\rho_e,\Pi_e,\operatorname{prov}_e),
$$

where $\Pi_e$ is a reusable proof architecture and $\operatorname{prov}_e$ binds the entry to a certified source task and source submission.

The v0.9 selective rule is

$$
\operatorname{Reuse}(t,e)
\Longrightarrow
\rho(t)=\rho_e.
$$

If no such entry exists, the policy resets to cold architecture synthesis.

## 2. Transfer soundness theorem

Assume every instantiated target lemma is re-certified by the canonical target verifier. Then library selection is non-authoritative: an incorrect retrieval decision cannot by itself certify a false UNSAT claim.

For every accepted target lemma $\ell$,

$$
M(P_t)\subseteq M(\ell).
$$

Therefore, if the replayed target proof closes,

$$
\bigcap_j M(\ell_j)\cap\bigcap_i M(P_{t,i})=\varnothing,
$$

then necessarily

$$
M(P_t)=\varnothing.
$$

Hence selector failure can cause rejection, wasted search, or reset, but not a certified false closure.

## 3. Distribution-shift separation

The v0.9 corpus contains three coarse signatures. Each coarse signature contains two distinct topology regimes with different proof mechanisms. For every coarse signature,

$$
10\ \mathrm{SAT}+10\ \mathrm{UNSAT}.
$$

For every topology regime,

$$
5\ \mathrm{SAT}+5\ \mathrm{UNSAT}.
$$

Thus neither $\sigma(t)$ nor $\rho(t)$ is a truth label.

The calibration library contains one legacy regime per coarse signature. Among the 57 evaluation tasks, 30 belong to topology regimes absent from calibration.

## 4. Pollution separation

After online adaptation, each coarse key contains two library entries:

$$
|L_{\sigma}(t)|=2,
$$

while every applicability topology key remains unique:

$$
|L_{\rho}(t)|=1.
$$

A coarse scan must therefore inspect potentially incompatible historical entries. The topology-aware selector retrieves at most one compatible candidate.

In the released experiment:

$$
A^-_{\mathrm{frozen\ coarse}}=30,
\qquad
A^-_{\mathrm{frozen\ selective}}=0,
$$

and after online adaptation,

$$
A^-_{\mathrm{online\ coarse}}=30,
\qquad
A^-_{\mathrm{online\ selective}}=0,
$$

where $A^-$ counts wrong-template applicability attempts.

## 5. Reset-and-learn result

Let $S$ denote cold architecture-synthesis queries on evaluation tasks. The released episode gives

$$
S_{\mathrm{cold}}=57,
$$

$$
S_{\mathrm{frozen\ selective}}=30,
$$

and

$$
S_{\mathrm{online\ selective}}=3.
$$

The three online resets correspond to the first certified UNSAT encountered in each of the three novel topology regimes. Those certified sources create three new provenance-bound entries. The expanded library then contains six entries.

This is a benchmark-specific adaptation result, not a universal sample-complexity theorem.

## 6. Proof-authority cost is not discounted

Across cold, frozen selective, frozen coarse, online selective, and online coarse evaluation policies, the target proof-authority proposal count is unchanged:

$$
P_{\mathrm{target}}=90.
$$

Thus

$$
\boxed{
\text{transfer reduces rediscovery/search cost, not target proof verification}
}
$$

for the released benchmark.
