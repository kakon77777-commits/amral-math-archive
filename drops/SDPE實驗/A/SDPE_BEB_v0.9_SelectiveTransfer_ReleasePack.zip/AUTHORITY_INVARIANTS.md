# Authority Invariants — v0.7

All v0.6 proof-authority invariants remain mandatory except that no complete fixed proof-DAG candidate grammar is required for the adaptive track.

Additional v0.7 invariants:

1. The initial adaptive fact pool contains public premises only.
2. A generated lemma enters the fact pool only after canonical certificate verification.
3. A proposal may depend only on premises or already certified generated lemmas.
4. Invalid, cyclic, unknown-dependency, over-fan-in, or forged proposals never grow the fact pool.
5. Typed-semantic duplicates consume a proposal query but do not open a new region.
6. Proposal-query telemetry never substitutes for terminal proof correctness.
7. Proposal-query lower bounds are explicitly calculus- and broker-model-relative.

# v0.8 Transfer-Library Authority Addendum

The reusable library is outside target proof authority.

For every target lemma $\ell$ instantiated from a library template,

$$
\operatorname{AcceptTargetLemma}(t,\ell)
$$

requires ordinary target-task certificate verification. Source provenance never substitutes for this check.

Library lookup is keyed by an alpha-renaming-invariant structural signature that ignores truth-bearing RHS and forbidden-assignment values. A lookup hit therefore does not certify SAT or UNSAT.

The measured evaluation library is frozen after calibration. Evaluation results may not mutate the library used to score that same evaluation episode.

# v0.9 Selective-Transfer Authority Addendum

v0.9 introduces two distinct retrieval layers:

$$
\sigma(t)=\text{coarse structural key},
$$

and

$$
\rho(t)=\text{label-blind topology applicability key}.
$$

Additional invariants:

1. Coarse-key equality is never sufficient for reuse authority.
2. Canonical selective reuse requires an exact applicability-key match before template instantiation.
3. Both $\sigma$ and $\rho$ exclude parity RHS values, forbidden assignment values, IDs, and oracle truth.
4. A selector miss must reset to cold synthesis rather than guess a proof architecture.
5. Online library growth is allowed only from a certified, budget-valid UNSAT reset source with exact source-task and source-submission provenance.
6. Multiple entries may share one coarse key, but canonical libraries reject duplicate applicability keys.
7. Target-task proof and witness verification are unchanged by library reuse, reset, or online learning.
8. Wrong-template attempts are search-pollution telemetry only and cannot become proof authority.
