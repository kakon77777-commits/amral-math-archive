# Provenance Guard Specification v0.9

For every canonical library entry, provenance binds:

$$
(
\text{dataset version},
\text{source task ID},
\text{source task hash},
\text{exact source submission hash},
\sigma,
\rho,
\text{template},
\text{source proof quality},
\text{learning order},
\text{source phase}
).
$$

The entry digest is SHA-256 over the canonical serialization of these fields.

Changing a topology signature, template, source hash, source submission hash, or learning metadata invalidates the digest unless the entry is rebuilt. Canonical release validation additionally replays each entry against its actual source task and exact source submission.

Online entries bind to the exact online-reset submission used for extraction, not merely to a proof-equivalent cold submission with different non-authoritative metadata.
