# AI Handoff — SDPE-BEB v0.9

Current frontier: selective transfer under distribution shift.

Canonical claims to preserve:

1. 60 tasks, 30 UNSAT and 30 SAT.
2. Three coarse signatures, each 10 SAT + 10 UNSAT.
3. Six topology applicability regimes, each 5 SAT + 5 UNSAT.
4. Calibration library: 3 legacy entries.
5. Evaluation tasks: 57; 30 are unseen topology regimes relative to calibration.
6. Frozen selective: 27 hits, 0 wrong-template attempts, 30 cold synthesis queries.
7. Frozen coarse scan: 27 hits, 30 wrong-template attempts, 30 cold synthesis queries.
8. Online selective: 54 hits, 0 wrong-template attempts, 3 cold synthesis queries, 3 learned entries.
9. Online coarse scan: 54 hits, 30 wrong-template attempts, 3 cold synthesis queries.
10. Target proof-authority proposal queries: 90 for every evaluation policy.
11. All five full submissions audit to 30 certified UNSAT + 30 certified SAT, with zero false closures.
12. Expanded library has 6 entries: exactly two per coarse key and exactly one per topology applicability key.

Do not weaken the target verifier to improve transfer metrics. Library selection is non-authoritative.

Next likely frontier: confidence-calibrated selector under partial/noisy topology evidence, multi-library forgetting/eviction, and long-horizon memory pressure.
