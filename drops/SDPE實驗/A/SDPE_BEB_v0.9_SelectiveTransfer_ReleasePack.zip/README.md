# SDPE-BEB v0.9 — Selective Transfer under Distribution Shift

This release studies when accumulated proof-architecture memory should be reused and when a theorem-proving agent should reset to cold synthesis.

The dataset deliberately creates coarse-signature collisions: each of three coarse public signatures contains two topology regimes with different proof mechanisms, and every topology regime contains both SAT and UNSAT tasks.

Main result: topology-aware selective transfer eliminates all 30 wrong-template attempts produced by coarse-only retrieval. With online adaptation, only three cold architecture-synthesis events are needed on 57 evaluation tasks, while target proof-authority verification remains unchanged.

See `SELECTIVE_TRANSFER_THEOREM.md`, `DISTRIBUTION_SHIFT_MODEL.md`, `SELECTOR_RESET_SPEC.md`, and `LIBRARY_POLLUTION_METRIC.md`.
