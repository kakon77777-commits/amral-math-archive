# Library Pollution and Selective-Transfer Metrics

The benchmark does not collapse search behavior into one weighted scalar.

For an evaluation policy $A$, report

$$
\mathcal M(A)=
(H,A_c,A^-,S,P,Q),
$$

where:

- $H$: successful reusable-library hits;
- $A_c$: candidate applicability attempts;
- $A^-$: wrong-template attempts rejected by topology guard;
- $S$: cold architecture-synthesis queries;
- $P$: target proof-authority lemma proposal queries;
- $Q$: number of evaluation UNSAT proofs whose final proof quality equals the cold reference proof quality.

The released measurements are:

| Policy | $H$ | $A_c$ | $A^-$ | $S$ | $P$ | $Q$ |
|---|---:|---:|---:|---:|---:|---:|
| cold | 0 | 0 | 0 | 57 | 90 | 27 |
| frozen selective | 27 | 27 | 0 | 30 | 90 | 27 |
| frozen coarse scan | 27 | 57 | 30 | 30 | 90 | 27 |
| online selective | 54 | 54 | 0 | 3 | 90 | 27 |
| online coarse scan | 54 | 84 | 30 | 3 | 90 | 27 |

The key separation is

$$
P=90
$$

for every policy. Transfer changes discovery and retrieval work but never discounts target proof verification.
