# SDPE-BEB v0.9 — Distribution Shift 下的選擇性跨題轉移

v0.9 研究的不是「library 越大越好」，而是：過去的證明架構什麼時候值得重用，什麼時候應該拒絕記憶並重新 cold search。

資料集故意讓同一個 coarse signature 對應兩種不同 proof mechanism，而且每個 topology regime 都同時包含 SAT 與 UNSAT，因此 regime 辨識不是答案洩漏。

主要結果：

$$
\text{frozen coarse scan wrong-template attempts}=30,
$$

但 topology-aware selective policy 為

$$
\boxed{0}.
$$

Online adaptation 只需要三次新 regime 的 cold reset，就把 57 題 evaluation 的 architecture synthesis 從

$$
57\rightarrow3.
$$

同時所有 policy 的 target proof-authority proposal queries 都維持

$$
\boxed{90},
$$

證明 transfer 省掉的是重新發明證明架構，而不是新題的證明驗證。
