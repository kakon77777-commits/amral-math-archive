# Selector and Reset Specification

## Signatures

The coarse signature is

$$
\sigma(t)=
\left(
 n,
 \operatorname{sort}(\text{parity arities}),
 N_{\mathrm{forbid}}
\right).
$$

The applicability signature $\rho(t)$ augments this with alpha-renaming-invariant topology statistics:

- unit-premise count;
- missing-variable count;
- binary edge endpoint classes relative to unit-fixed variables;
- duplicate binary-pair excess;
- binary degree multiset;
- binary connected-component size multiset.

No RHS or assignment value enters $\rho$.

## Selective policy

For a target task $t$:

1. normalize the public topology;
2. retrieve an entry only if $\rho_e=\rho(t)$;
3. run the target applicability guard;
4. instantiate the reusable architecture;
5. re-certify every target lemma;
6. if no compatible entry exists, reset to cold synthesis.

A reset is not a benchmark failure. It is the prescribed behavior under unsupported distribution shift.

## Coarse-scan baseline

The coarse baseline retrieves entries with

$$
\sigma_e=\sigma(t)
$$

in learning order and tests them sequentially. Under library pollution this can incur wrong-template attempts even though the target verifier still prevents false closure.

## Online adaptation

A cold-reset result may extend the library only when:

- the target result is certified UNSAT;
- the proof is budget-valid;
- the source task and exact source submission are provenance-bound;
- the applicability topology is not already represented.

SAT tasks do not create proof-template entries.
