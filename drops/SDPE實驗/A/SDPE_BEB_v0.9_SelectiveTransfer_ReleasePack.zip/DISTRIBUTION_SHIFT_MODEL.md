# Distribution Shift Model

## Public shift construction

The corpus uses 12 Boolean variables and 13 premises per task: 12 parity premises and one forbidden assignment. All task IDs, constraint IDs, action IDs, premise order, action order, and variable coordinates are independently re-keyed or permuted.

There are three coarse arity signatures. Each is split into two label-blind topology regimes.

### Coarse A

Both regimes contain eight unary parity premises and four binary parity premises.

- Legacy topology: the four binary equations live entirely on the four variables not fixed by unary premises. UNSAT instances contain a short GF(2) contradiction.
- Shift topology: each missing variable is connected to a unary-fixed variable. The affine system becomes uniquely localizing; UNSAT occurs only when the unique model is the forbidden assignment.

### Coarse B

Both regimes contain twelve binary parity premises.

- Legacy topology: a 12-cycle. UNSAT is a global cycle-parity contradiction.
- Shift topology: one binary edge is duplicated. UNSAT is a short conflicting duplicate-edge contradiction.

### Coarse C

Both regimes contain eleven unary parity premises and one binary parity premise.

- Legacy topology: the binary equation connects the one missing variable to a fixed variable, producing unique localization.
- Shift topology: the binary equation connects two already-fixed variables. UNSAT is a short local GF(2) contradiction; the missing variable remains free on SAT instances.

## Label blindness

The topology selector uses only incidence information. It ignores all parity RHS values and the forbidden assignment value.

Every one of the six topology regimes is balanced:

$$
5\ \mathrm{SAT}+5\ \mathrm{UNSAT}.
$$

Therefore recognizing the regime does not reveal the oracle label.

## Episode

The calibration phase contains three legacy UNSAT tasks, one per coarse signature. The evaluation phase contains the remaining 57 tasks. Exactly 30 evaluation tasks belong to topology regimes absent from calibration.

The evaluation order places one certified-UNSAT example from each novel regime first. This allows the online-adaptation experiment to measure one-source-per-regime library expansion deterministically.
