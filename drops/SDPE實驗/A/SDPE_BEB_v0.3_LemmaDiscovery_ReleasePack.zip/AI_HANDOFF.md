# AI Handoff — SDPE-BEB v0.3

Current release target: **Participant-Proposed Lemma Discovery**.

The v0.1.x repair line and v0.2 symbolic-authority line are treated as closed unless a regression is found. v0.3 removes pre-published derived actions and asks participants to author intermediate lemmas themselves.

## Canonical authority path

1. Validate manifest and complete task corpus.
2. Validate exactly one submission per task.
3. Validate each proposed lemma contract.
4. Recompute every lemma conclusion from its structural certificate.
5. Charge all proposed lemmas.
6. Symbolically replay selected primitive actions and verified lemmas.
7. Enforce first-closure termination and exact budgets.
8. Reveal version-bound Oracle openings.
9. Certify UNSAT only for a sound closed route; certify SAT only for a valid witness.

## Do not regress

- Do not reintroduce public derived-action candidates.
- Do not use exhaustive enumeration on the public/reveal authority path.
- Do not accept declaration-only UNSAT labels.
- Do not make unused lemma proposals free.
- Do not permit duplicate, colliding, unknown-dependency, forged, or post-closure proof objects.

## Next frontier

A later v0.4 may add lemma chaining, richer proof calculi, proof-DAG normalization, and stronger mathematical families. Those extensions should occur only after preserving the v0.3 adversarial regression suite.
