# SDPE-BEB v0.3 — Participant-Proposed Lemma Authority

## 1. Semantic setting

Let the Boolean assignment space be

$$
X=\mathbb F_2^n.
$$

A task publishes premises

$$
P_1,\ldots,P_m\subseteq X,
$$

and its true model set is

$$
M=\bigcap_{i=1}^m P_i.
$$

The public verifier never needs to enumerate $X$ on the authority path.

## 2. Participant-proposed lemma

A proposed lemma is a predicate $L\subseteq X$ together with a structural certificate. The certificate is accepted only if the verifier can recompute the submitted conclusion from public premises.

### 2.1 GF(2) linear combination

Suppose the listed affine premises have equations

$$
a_i\cdot x=b_i
$$

over $\mathbb F_2$. The verifier computes

$$
a=\bigoplus_i a_i,
\qquad
b=\bigoplus_i b_i.
$$

The accepted conclusion is exactly

$$
a\cdot x=b.
$$

If $a=0$ and $b=1$, the canonical conclusion is `false`.

### 2.2 Unit aggregate

Suppose the listed dependencies are distinct unit premises

$$
x_{j_1}=c_{j_1},\ldots,x_{j_d}=c_{j_d}.
$$

Define the bit mask $Q$ and pattern $R$ by

$$
Q=\sum_{r=1}^{d}2^{j_r},
\qquad
R=\sum_{r=1}^{d}c_{j_r}2^{j_r}.
$$

The accepted conclusion is the exact mask predicate encoded by $(Q,R)$.

## 3. Lemma soundness theorem

**Theorem 1.** Every lemma accepted by either v0.3 certificate mode is a logical consequence of the listed public premise dependencies.

**Proof.** For the GF(2) certificate, XORing equations valid at $x$ preserves equality in $\mathbb F_2$, so every assignment satisfying all listed dependencies satisfies the recomputed affine conclusion. For the unit aggregate, satisfying every listed unit equality fixes exactly the bits recorded by $Q$ and $R$, so the aggregate mask predicate holds. The verifier accepts only when the submitted conclusion is byte-for-byte equal to the canonical recomputation. $\square$

## 4. Replay soundness theorem

Let the selected proof route contain primitive premise cuts and verified proposed lemmas

$$
C_1,\ldots,C_k.
$$

Because each primitive cut is one of the original premises and every accepted lemma is entailed by original premises,

$$
M\subseteq C_j
$$

for every $j$. Hence

$$
M\subseteq\bigcap_{j=1}^{k}C_j.
$$

**Theorem 2.** If exact symbolic replay closes,

$$
\bigcap_{j=1}^{k}C_j=\varnothing,
$$

then

$$
M=\varnothing.
$$

Therefore every v0.3 certified closure is a sound UNSAT certificate, subject to the dataset, submission-contract, budget, and commitment invariants enforced by the auditor. $\square$

## 5. Symbolic authority

For the supported predicate language, replay maintains

$$
\Omega=L(A,b)\setminus E,
$$

where $L(A,b)$ is an affine $\mathbb F_2$ solution set and $E$ is a finite set of excluded assignments. If the affine system is consistent with rank $r$,

$$
|\Omega|
=
2^{n-r}-|E\cap L(A,b)|.
$$

If the affine system is inconsistent, $|\Omega|=0$.

No $2^n$ assignment list is constructed by the public or reveal authority path.

## 6. Verification complexity

For a lemma with $d$ dependencies and $n$ Boolean variables, the two v0.3 certificate modes require a number of algebraic operations polynomial in $d+n$. Symbolic replay performs incremental affine elimination plus finite-exclusion checks. Thus the authority path is polynomial in the submitted proof-object size and task encoding size for the v0.3 predicate class.

This statement concerns verification, not the participant's cost of discovering the lemma.

## 7. Scope

v0.3 allows participant-authored lemmas, but dependencies refer directly to original premises. Lemma-to-lemma chaining is intentionally excluded from this release. The benchmark therefore tests a restricted but genuine transition from route selection to proof-object construction; it does not claim unrestricted autonomous theorem discovery.
