# SDPE-BEB Version Transition: v0.2 to v0.3

## v0.2

v0.2 established symbolic survivor authority. Derived actions were structurally verified, but the public task still supplied candidate derived routes.

## v0.3

v0.3 removes those candidate routes from Public tasks. Every published action is a homogeneous primitive premise action. The participant must construct any useful intermediate lemma and provide a certificate.

The authority transition is therefore

$$
\text{choose a certified derived action}
\quad\longrightarrow\quad
\text{author a certified derived lemma}.
$$

The v0.3 corpus is a semantics-preserving transformation of the 60-task v0.2 Neutral Variant corpus. Public task IDs are replaced by deterministic opaque IDs, Oracle commitments are rebound to the v0.3 dataset version, and no family field is published.

The source v0.2 release pack used for this transition has SHA-256

`a7eda5f867e465c025f74e72af2526957340ec45a8d6f0057a376025b74877a5`.

Full Dev contains `private_oracle/DEV_ORIGIN_MAP.json` for regression provenance. That file is not included in Public or Oracle participant-facing bundles.
