# SDPE-BEB v0.3 Lemma Discovery Release Pack

This release advances SDPE-BEB from symbolic route selection to participant-proposed proof objects. Public tasks contain no pre-listed derived actions or bridge graph. Participants may author structurally certified lemmas and use them in exact symbolic replay.

Key validated result: the lemma-aware structural baseline certifies 30 UNSAT closures and 30 SAT witnesses; the premise-only greedy baseline certifies only 3 UNSAT closures while retaining 30 SAT witnesses.

The pack contains separate Public, Oracle, and Full Dev archives plus theorem/source artifacts, adversarial results, source validation, and post-release smoke evidence.
