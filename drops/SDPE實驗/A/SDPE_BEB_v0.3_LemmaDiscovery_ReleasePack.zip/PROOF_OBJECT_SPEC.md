# Proof Object Specification — v0.3

A proof object is not a label and not a hint to a hidden route. It is a participant-authored lemma plus a certificate that the public verifier can recompute.

### GF(2) linear-combination certificate
For affine premises $a_i\cdot x=b_i$ and selected coefficients implicitly equal to one for listed dependencies, the verifier computes

$$
a=\bigoplus_i a_i,\qquad b=\bigoplus_i b_i.
$$

The submitted conclusion must equal $a\cdot x=b$ in canonical predicate form. In particular, $a=0,b=1$ yields the canonical `false` predicate and is a contradiction certificate.

### Unit-aggregate certificate
Distinct unit premises $x_j=c_j$ aggregate to

$$
x\operatorname{AND}M=P,
$$

where $M$ is the mask of the selected variables and $P$ stores their prescribed bits. The verifier reconstructs $M,P$ exactly.

No exhaustive truth-table entailment is part of either certificate verifier.
