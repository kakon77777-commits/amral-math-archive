# SDPE-BEB v0.3 Authority Invariants

1. **Manifest source authority**

$$
T_{\mathrm{manifest}}
=
T_{\mathrm{tasks}}
=
T_{\mathrm{oracle}}
=
T_{\mathrm{submission}}.
$$

2. **Unique submission authority**

$$
\forall t\in T_{\mathrm{manifest}},
\qquad
\#S(t)=1.
$$

3. **No public derived-route candidates**

Public task JSON contains only primitive premise actions. It contains no bridge graph, derived action, predeclared certificate dependency footprint, semantic route tag, or family-coded task identifier.

4. **Lemma certificate before lemma authority**

A proposed lemma cannot enter replay unless its structural certificate recomputes the submitted conclusion exactly.

5. **Proposal spam is not free**

Every submitted lemma is charged proposal cost whether or not it is selected in the final route.

6. **Identifier separation**

Lemma IDs must be unique and may not collide with primitive action IDs.

7. **Exact route termination**

The selected route terminates at first closure. Any later step invalidates that case.

8. **Exact decimal budget authority**

Budget comparison uses finite decimal values. Non-finite JSON values fail closed.

9. **Witness authority**

A SAT counterexample is certified only if the assignment satisfies every public premise.

10. **Version-bound Oracle commitment**

$$
H
=
\operatorname{SHA256}
(
\texttt{dataset\_version}
\Vert
\texttt{canonical\_oracle}
\Vert
\texttt{nonce}
).
$$

11. **Enumerative reference is non-authoritative**

Exhaustive enumeration exists only in Full Dev differential tests and Oracle construction checks. Public replay and reveal certification use symbolic authority only.
