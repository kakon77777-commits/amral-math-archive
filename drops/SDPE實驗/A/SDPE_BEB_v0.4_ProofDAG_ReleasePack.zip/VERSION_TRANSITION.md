# Version Transition

$$
v0.3:\ \text{participant-authored one-hop lemmas}
$$

$$
v0.4:\ \text{bounded-fan-in participant-authored proof DAGs}
$$

The new causal question is whether chaining verified intermediate statements adds measurable closure power beyond both primitive-only search and flat lemma discovery.
