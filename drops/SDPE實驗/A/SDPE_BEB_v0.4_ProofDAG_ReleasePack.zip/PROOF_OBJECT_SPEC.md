# Proof Object Specification — v0.4

## DAG semantics

A submission contains `proposed_lemmas`. Each lemma has an ID, a conclusion predicate, and a certificate with at most four dependencies. A dependency may name either a public `constraint_id` or another proposed `lemma_id`. The verifier treats the list order as non-authoritative and computes a canonical topological order. Any cycle, self-cycle, unknown dependency, namespace collision, or depth above four invalidates the proof DAG.

## GF(2) certificate

For affine dependencies

$$
a_i \cdot x=b_i,
$$

the verifier XORs the selected rows and accepts only the exact canonical conclusion

$$
\left(\bigoplus_i a_i\right)\cdot x=\bigoplus_i b_i.
$$

## Mask aggregate certificate

`mask_aggregate` accepts pairwise-disjoint unit or mask dependencies and produces their exact conjunction as one `mask_equals` predicate. Singleton parity constraints are accepted as unit equalities.

## Fan-in

Every certificate satisfies

$$
1\le |D_j|\le 4.
$$

The cap is an authority rule, not telemetry. It is what makes long-cycle contradictions require intermediate lemmas rather than a single flat certificate.
