# Authority Invariants — v0.4

1. Dataset identity: $T_M=T_{tasks}=T_{oracle}=T_{submission}$.
2. Exactly one submission per task.
3. Every proposed lemma has fan-in at most four.
4. The proposed-lemma graph is acyclic and has depth at most four.
5. Lemma list order is non-authoritative; canonical topological verification is authoritative.
6. Every lemma conclusion is recomputed from its certified dependencies.
7. Only verified lemma IDs or primitive premise-action IDs may appear in `selected_steps`.
8. Proof route terminates at first closure.
9. Exact decimal cost accounting is authoritative.
10. Public/reveal authority uses symbolic replay; exhaustive enumeration is reference-only.
