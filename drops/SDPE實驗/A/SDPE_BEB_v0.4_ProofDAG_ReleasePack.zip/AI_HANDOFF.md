# AI Handoff — SDPE-BEB v0.4

The canonical source is the UTF-8 artifact set, not rendered chat. Do not rewrite LaTeX delimiters or convert LaTeX into Unicode mathematics as source. v0.4 introduces order-independent participant proof DAGs with bounded fan-in. The next research frontier is not another evaluator repair; it is richer calculi, branching proof search, and benchmarks where useful intermediate abstractions are not predetermined by a two-calculus vocabulary.
