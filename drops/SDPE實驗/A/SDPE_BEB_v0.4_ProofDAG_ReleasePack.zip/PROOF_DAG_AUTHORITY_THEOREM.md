# Proof DAG Authority Theorem — v0.4

Let the original public premise model set be

$$
M=\bigcap_{i=1}^{m}P_i.
$$

Let proposed lemmas form a finite DAG $G=(V,E)$. For every lemma node $L_j$, the verifier checks a structural certificate whose dependencies are either public premises or predecessor lemmas, and whose semantics guarantees

$$
\bigcap_{D\in\mathrm{Dep}(L_j)}D\subseteq L_j.
$$

Because $G$ is acyclic, take any topological order. By induction on this order, every verified lemma satisfies

$$
M\subseteq L_j.
$$

Therefore every primitive premise action and every verified lemma selected by replay contains $M$. If the symbolic replay route closes,

$$
\bigcap_{C\in\mathrm{Selected}}C=\varnothing,
$$

then

$$
M\subseteq\varnothing,
$$

and hence

$$
M=\varnothing.
$$

Thus a budget-valid closed route built from verified proof-DAG nodes is sound evidence of UNSAT. The theorem does not claim completeness for arbitrary calculi.
