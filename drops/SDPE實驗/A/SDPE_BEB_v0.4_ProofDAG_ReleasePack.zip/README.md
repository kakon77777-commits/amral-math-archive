# SDPE-BEB v0.4 — Proof DAG / Lemma Chaining

This release upgrades participant-authored one-hop lemmas into bounded-fan-in proof DAGs. A proposed lemma may depend on public premises or on other participant-proposed lemmas. The verifier computes a canonical topological order, rejects cycles, checks every structural certificate, and only then permits a verified lemma to be used as a proof step.

Core public invariants: all 60 tasks have the same $n=12$, 13 premises, 13 primitive actions, budgets, and predicate-kind multiset (12 parity constraints plus one singleton exclusion). Each of the three mathematical incidence signatures contains exactly 10 SAT and 10 UNSAT cases.

The canonical authority is symbolic. Enumerative replay exists only in Full Dev as a differential reference.
