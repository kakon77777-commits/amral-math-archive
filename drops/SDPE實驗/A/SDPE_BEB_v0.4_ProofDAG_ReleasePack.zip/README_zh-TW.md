# SDPE-BEB v0.4 — Proof DAG / Lemma Chaining

本版把 v0.3 的 participant-authored 單層 lemma 升級成真正的 proof DAG。後續 lemma 可以引用公開 premise 或其他 participant-proposed lemma；lemma 在 submission 中的排列順序不具權威性，verifier 會自行建立依賴圖、做 canonical topological sort、拒絕 cycle，並逐節點驗證 structural certificate。

所有 60 題在粗 metadata 上統一為 $n=12$、13 個 premises、13 個 primitive actions、相同 budgets，以及 12 個 parity 加 1 個 singleton exclusion。三種數學 incidence signature 各自都是 10 SAT + 10 UNSAT，因此 track 可由數學結構辨識，但不能直接洩漏 label。

Canonical verifier authority 仍是 symbolic affine-exclusion engine；exhaustive enumeration 只存在 Full Dev 作 differential reference。
