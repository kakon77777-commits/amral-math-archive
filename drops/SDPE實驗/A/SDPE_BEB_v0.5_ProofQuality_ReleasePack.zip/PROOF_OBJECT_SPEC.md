# Proof Object Specification — v0.5

## Supported certificates

- `gf2_linear_combo`: exact XOR of affine dependencies over $\mathbb F_2$.
- `mask_aggregate`: exact conjunction of compatible localization masks.
- `exclusion_clash`: exactly one `forbid_assignment` plus localization dependencies whose union covers all variables and equals the forbidden assignment; the only accepted conclusion is `false`.

All certificates satisfy

$$
1\le |D_j|\le 4.
$$

## Proof quality

Only budget-valid closed UNSAT routes are quality-eligible. The verifier computes

$$
Q(\Pi)=(N,L,E,D,S,C),
$$

where $N=L+S$ is proof-node count, $L$ proposed-lemma count, $E$ is the total number of certificate dependency edges (premise-to-lemma and lemma-to-lemma), $D$ DAG depth, $S$ selected-step count, and $C$ exact model cost in cents. Lower is better under lexicographic order.

The vector is verifier-derived. Participants cannot submit their own quality score.
