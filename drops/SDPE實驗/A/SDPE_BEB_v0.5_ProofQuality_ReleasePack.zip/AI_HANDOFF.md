# AI Handoff — v0.5

Canonical authority is `tools/common.py`. Continue from proof quality toward proof-space search, richer calculi, and eventually proof-system generalization. Do not treat exhaustive enumeration as public authority.
