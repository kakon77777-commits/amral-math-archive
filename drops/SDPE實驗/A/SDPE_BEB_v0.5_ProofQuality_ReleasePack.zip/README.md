# SDPE-BEB v0.5 — Proof Quality / Alternative Proof Search

v0.5 keeps symbolic verifier authority and participant-authored proof DAGs, then adds a calculus-relative proof-quality layer. Valid UNSAT proofs are compared by a deterministic lexicographic vector rather than by a learned or subjective score.

The release also adds `exclusion_clash`, a mixed structural certificate that derives `false` when at most three localization predicates jointly determine the entire assignment forbidden by exactly one singleton exclusion.

The benchmark now includes multiple valid proof DAGs for the same UNSAT task, a branching template-search baseline, deliberately verbose valid proofs, and calculus-relative compression lower bounds.
