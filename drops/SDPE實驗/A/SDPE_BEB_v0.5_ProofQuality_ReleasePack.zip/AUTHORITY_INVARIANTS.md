# Authority Invariants — v0.5

1. Dataset identity and exactly-one-submission invariants from v0.4 remain authoritative.
2. Symbolic replay remains canonical; enumeration is reference-only.
3. Lemma dependency fan-in is at most four and DAG depth at most four.
4. `exclusion_clash` must contain exactly one singleton exclusion and full compatible localization of the same assignment.
5. Quality is computed only for budget-valid closed UNSAT routes.
6. Quality vectors are verifier-derived and compared lexicographically, lower-is-better.
7. Lemma list order and lemma ID spelling do not directly affect quality metrics.
8. Steps after first closure remain forbidden.
