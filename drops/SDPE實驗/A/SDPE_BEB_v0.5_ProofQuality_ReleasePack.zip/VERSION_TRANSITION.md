# v0.4 → v0.5

The benchmark advances from existence of proof DAGs to comparison among alternative valid DAGs. v0.5 adds `exclusion_clash`, deterministic quality vectors, branching template search, verbose/legacy controls, and calculus-relative compression lower bounds.
