# SDPE-BEB v0.5 — 證明品質／替代證明搜尋

v0.5 保留 symbolic verifier authority 與 participant-authored proof DAG，進一步加入 calculus-relative 的 proof-quality 層。合法 UNSAT 證明不再只有「過／不過」，而由 deterministic lexicographic quality vector 比較，不使用學習式或主觀分數。

本版新增 `exclusion_clash` 混合 certificate：若至多三個 localization predicates 共同唯一決定整個 assignment，且該 assignment 正好被一個 singleton exclusion 禁止，則可以結構化推出 `false`。

同一個 UNSAT task 現在可以存在多條合法 proof DAG；Full Dev 提供 branching template-search、legacy-valid、verbose-valid baseline，以及 calculus-relative compression lower-bound 驗證。
