# Proof Quality and Compression Theorem — v0.5

## Soundness of `exclusion_clash`

Suppose localization dependencies imply

$$
x=a
$$

on all $n$ Boolean variables, and another dependency is the singleton exclusion

$$
x\ne a.
$$

Their conjunction is empty, so the structural conclusion `false` is sound.

## Calculus-relative compression lower bounds

The bounds below are relative to the public v0.5 certificate language and fan-in cap $f=4$.

### Track A

The four affine premises already have an inconsistent GF(2) sum. At least one derived contradiction lemma and one selected proof step are necessary. The compact proof uses exactly one lemma.

### Track B

Twelve affine premises must contribute to the GF(2) contradiction. A fan-in-$4$ derived lemma can reduce the number of unresolved components by at most $3$. Hence the number $L$ of derived lemmas satisfies

$$
L\ge \left\lceil\frac{12-1}{4-1}\right\rceil=4.
$$

The compact proof attains $L=4$.

### Track C

The affine premises are consistent; contradiction requires the singleton exclusion. One GF(2) lemma is required to recover the missing unit fact. The resulting 12 unit facts must be compressed to at most three localization inputs for `exclusion_clash`. Every `mask_aggregate` with fan-in at most four can reduce localization-component count by at most three, so at least

$$
\left\lceil\frac{12-3}{4-1}\right\rceil=3
$$

mask aggregates are required, followed by one exclusion-clash lemma. Therefore

$$
L\ge 1+3+1=5.
$$

The compact v0.5 proof attains $L=5$.

These are proof-complexity statements inside the declared calculus, not universal lower bounds over arbitrary proof systems.
