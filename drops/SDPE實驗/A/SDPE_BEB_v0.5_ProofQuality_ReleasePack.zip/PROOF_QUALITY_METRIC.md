# Proof Quality Metric — v0.5

For every budget-valid closed UNSAT proof $\Pi$, the verifier computes

$$
Q(\Pi)=\bigl(N,L,E,D,S,C\bigr),
$$

with lower lexicographic value preferred. $E$ counts every certificate dependency, including premise-to-lemma edges. Here

$$
N=L+S.
$$

This primary component counts participant-authored lemma nodes plus applied proof steps. It makes proof compression explicit while preserving deterministic tie-breaking by lemma count, dependency edges, depth, selected steps, and exact cost.

SAT witnesses are correctness-certified but are not ranked by the UNSAT proof-quality metric.
