# SDPE-BEB v0.10 Authority Invariants

1. The v0.9 mathematical task corpus and canonical proof verifier remain the proof authority.
2. Confidence values, selector actions, library hits, cache hits, probes, and eviction decisions are non-authoritative search telemetry.
3. A transferred lemma is accepted only after target-task certificate re-verification.
4. A wrong selector decision may cause rejection, a wasted template attempt, a probe, or a cold reset; it cannot directly certify UNSAT.
5. Active-memory eviction never modifies target premises, proof rules, Oracle commitments, or immutable provenance evidence.
6. The confidence experiment and memory experiment are scored separately before any integrated policy is interpreted.
7. The confidence channel is a declared synthetic probabilistic model, not a claim about the internal uncertainty of an AI model.
8. Search-cost claims are benchmark-owned observable quantities, not hidden chain-of-thought or private model-compute claims.
