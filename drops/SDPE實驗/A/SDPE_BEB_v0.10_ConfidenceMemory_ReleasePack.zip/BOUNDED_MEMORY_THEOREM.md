# SDPE-BEB v0.10 — Bounded Active Memory and Forgetting

## 1. Active memory versus immutable provenance

Let $\mathcal A$ be the immutable provenance archive of previously certified reusable entries and let

$$
M_k\subseteq\mathcal A
$$

be the active transfer cache at time $k$.

The scored online policy has capacity

$$
|M_k|\le K.
$$

In the v0.10 bounded-memory episode,

$$
K=4.
$$

Eviction removes an entry from $M_k$ only. It does not erase the auditor's immutable provenance record and it does not alter any target-task premise or proof rule.

## 2. Soundness invariance under eviction

Proof acceptance depends on target-task certificates and replay, not on active-cache membership. Hence for any two active-memory states $M$ and $M'$,

$$
\operatorname{AcceptProof}(t,\Pi;M)
=
\operatorname{AcceptProof}(t,\Pi;M').
$$

Therefore forgetting can change discovery cost but not proof truth.

## 3. Episode-relative exact miss lower bound

For the fixed 57-task evaluation trace, define state $A_i$ as the active regime set before task $i$, with

$$
|A_i|\le4.
$$

A cache miss costs one architecture-synthesis query. On an UNSAT miss, the policy may skip learning, insert into a free slot, or evict one active entry and insert the newly certified reusable regime. On a SAT miss, no proof-template entry is learned.

Let $r_i$ denote the hidden reusable regime for task $i$. The exact dynamic program is

$$
V(i,A)
=
\mathbf 1[r_i\notin A]
+
\min_{A'\in\mathcal T_i(A)}V(i+1,A'),
$$

with

$$
V(N,A)=0.
$$

For the released episode and the three calibration entries,

$$
\boxed{V(0,A_0)=13}.
$$

This is an exact offline lower bound for this finite episode and transition model. It is not a universal online caching theorem.

## 4. Measured online policies

With capacity $K=4$:

$$
\begin{array}{c|c|c}
\text{policy} & \text{hits} & \text{misses}\\
\hline
\text{LRU} & 32 & 25\\
\text{family-balanced LRU} & 35 & 22\\
\text{FIFO} & 31 & 26\\
\text{LFU} & 29 & 28
\end{array}
$$

The exact episode lower bound is

$$
13\text{ misses}.
$$

A six-slot no-eviction reference incurs only the first three novel-regime misses:

$$
3\text{ misses}.
$$

Thus memory capacity and eviction policy introduce a measurable search penalty even when exact applicability is known.
