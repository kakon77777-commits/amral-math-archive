# AI Handoff — SDPE-BEB v0.10

Current frontier: confidence-calibrated transfer and bounded reusable-proof memory.

Do not weaken target proof verification in order to improve transfer metrics.

The mathematical task corpus is intentionally frozen from v0.9. Treat `task_corpus_version = sdpe-beb-selective-transfer-v0.9` and `benchmark_layer_version = sdpe-beb-confidence-memory-v0.10` as distinct version axes.

Primary evidence files:

- `confidence_reports/CONFIDENCE_EXPERIMENT_REPORT.json`
- `memory_reports/MEMORY_EVICTION_EXPERIMENT.json`
- `confidence_reports/INTEGRATED_CONFIDENCE_MEMORY_REPORT.json`
- `FULL_DEV_VALIDATION_REPORT_V010.json`

Primary formal sources:

- `CONFIDENCE_CALIBRATION_THEOREM.md`
- `BOUNDED_MEMORY_THEOREM.md`
- `CONFIDENCE_TRANSFER_SPEC.md`
- `MEMORY_EVICTION_SPEC.md`

Likely next frontier: nonstationary calibration, adaptive thresholds, provenance-aware consolidation, and learned memory compression without allowing learned confidence to become proof authority.
