# SDPE-BEB v0.10 — Confidence-Gated Transfer Specification

The confidence experiment starts from a six-entry reusable library and 60 target tasks. It isolates uncertainty in transfer selection from memory capacity.

Each target exposes an exact coarse bucket and three synthetic noisy sensor votes. The votes reveal only which of two proof-mechanism classes inside that bucket is more likely. They do not reveal SAT/UNSAT truth.

The available selector actions are:

- reuse class $0$;
- reuse class $1$;
- request one probe;
- reset to cold synthesis.

The public posterior implementation is `tools/confidence_model.py`.

The official confidence metrics are defined on this staged observation channel. Inspecting the full target topology before making the selector decision is outside the controlled selector-cost experiment. This is a benchmark protocol boundary, not a cryptographic secrecy claim.

The selector does not certify mathematics. After any transfer decision, target certificates are rechecked by the unchanged proof authority.
