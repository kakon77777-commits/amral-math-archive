# SDPE-BEB v0.10 — 信心校準轉移與有限證明記憶

v0.10 不再改動底層數學題，而是把 v0.9 的 60 題與 proof authority 凍結，專門研究兩個新的搜尋問題：

$$
\boxed{
\text{partial/noisy evidence}
+
\text{bounded active memory}
}
$$

也就是：

1. 看不清楚時，要多相信舊 proof memory？
2. 明明知道該用哪個 proof memory，但它已經被 eviction 掉時，要怎麼辦？

## Confidence experiment

60 題的初始 noisy observation 對 topology class 的準確率是

$$
81.7\%.
$$

加入一次高品質 probe 後變成

$$
93.3\%.
$$

激進 top-1 reuse：

$$
11\text{ 次 wrong-template attempts},
$$

但只需要 11 次 cold fallback。

保守 `probe_gate_0.85`：

$$
\boxed{0\text{ 次 wrong-template attempts}}
$$

代價是

$$
54\text{ 次 probe}+17\text{ 次 reset}.
$$

所以現在真正出現的是

$$
\boxed{
\text{wrong-transfer risk}
\times
\text{probe cost}
\times
\text{reset cost}
}
$$

的 Pareto frontier。

## Bounded-memory experiment

57 題 evaluation episode 的 active proof memory 限制為

$$
K=4.
$$

我們用 exact dynamic programming 計算出這個固定 episode 的最低 miss 數：

$$
\boxed{13}.
$$

實際線上策略：

$$
\begin{array}{c|c}
\text{策略} & \text{misses}\\
\hline
\text{LRU} & 25\\
\text{family-balanced LRU} & 22\\
\text{FIFO} & 26\\
\text{LFU} & 28
\end{array}
$$

若容量為 6、完全不 eviction，則只需要最早三個 novel regime 的

$$
3\text{ 次 miss}.
$$

## Integrated experiment

把保守 confidence gate 與 family-balanced LRU 疊起來後：

$$
\boxed{0\text{ 次 wrong-template attempt}}
$$

但出現

$$
17
$$

次「selector 很有信心選對了，可是正確 entry 已被 eviction」的情況。

因此 v0.10 得到一個很清楚的區分：

$$
\boxed{
\text{epistemic uncertainty}
\neq
\text{memory availability uncertainty}.
}
$$

而這兩種成本都只影響搜尋，不影響 proof authority。所有 target lemma、UNSAT closure 與 SAT witness 仍由原來 canonical verifier 重驗。
