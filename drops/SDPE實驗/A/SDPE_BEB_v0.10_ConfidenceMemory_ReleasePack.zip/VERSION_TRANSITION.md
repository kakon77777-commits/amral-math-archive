# Version transition: v0.9 to v0.10

v0.9 answered:

$$
\text{Which known transfer regime applies under exact structural observation?}
$$

v0.10 deliberately separates two new failure modes.

First, partial/noisy evidence:

$$
\text{What if the selector cannot perfectly observe applicability?}
$$

Second, bounded active memory:

$$
\text{What if the selector knows what it wants but no longer has that entry active?}
$$

The v0.10 benchmark layer freezes the v0.9 mathematical task corpus and proof authority. This is intentional: changes in the new experiments must come from uncertainty and memory governance, not from changing the underlying Boolean problems.

The new search-state distinction is

$$
\boxed{
\text{epistemic uncertainty}
\neq
\text{memory availability uncertainty}.
}
$$
