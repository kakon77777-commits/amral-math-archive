# SDPE-BEB v0.10 — Benchmark Limitations

1. The confidence channel is synthetic and declared. It benchmarks calibrated decision logic under a known observation model; it does not claim to measure an AI model's native subjective uncertainty.
2. The official confidence selector experiment is staged: the transfer decision is scored from the observation packet before full target-topology inspection. A static release cannot cryptographically prevent a participant from inspecting other public files, so this is a protocol boundary rather than a secrecy guarantee.
3. The exact 13-miss memory lower bound is specific to the released 57-task trace, capacity $K=4$, and the declared learning/eviction transition model.
4. Eviction removes entries from the scored active cache, not from the immutable audit archive. This models operational forgetting while preserving reproducibility.
5. All transfer, confidence, probe, and memory metrics are non-authoritative. Mathematical correctness still comes only from target-task proof/witness verification.
