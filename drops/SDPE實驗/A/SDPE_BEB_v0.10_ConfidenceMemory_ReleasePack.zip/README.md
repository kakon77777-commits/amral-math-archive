# SDPE-BEB v0.10 — Confidence-Calibrated Transfer and Bounded Proof Memory

SDPE-BEB v0.10 adds two benchmark-owned search layers on top of the frozen v0.9 mathematical corpus:

1. partial/noisy transfer evidence with Bayesian confidence and optional probes;
2. bounded active reusable-proof memory with eviction and forgetting.

The proof verifier is unchanged. Confidence and memory affect discovery cost only.

## Key confidence results

Across 60 tasks, initial noisy evidence reaches 81.7% topology-class accuracy. After the optional probe channel, class accuracy is 93.3%.

The conservative `probe_gate_0.85` policy produces 0 wrong-template attempts, 54 probe queries, and 17 architecture-synthesis resets. The aggressive top-1 policy uses no probes and only 11 resets, but incurs 11 wrong-template attempts.

This yields a genuine Pareto problem over wrong-transfer risk, probe cost, and reset cost.

## Key memory results

On the fixed 57-task evaluation episode with active-memory capacity $K=4$, exact dynamic programming proves an episode-relative minimum of 13 misses.

Measured online policies:

- LRU: 25 misses;
- family-balanced LRU: 22 misses;
- FIFO: 26 misses;
- LFU: 28 misses.

A six-slot no-eviction reference needs only 3 misses.

## Integrated result

`probe_gate_0.85 + family-balanced LRU` has 0 wrong-template attempts but 17 confident selections whose correct entry had already been evicted. This directly separates epistemic uncertainty from memory-availability uncertainty.

## Versioning

The underlying task corpus remains `sdpe-beb-selective-transfer-v0.9` so the new effects cannot be attributed to different math instances. The benchmark layer is `sdpe-beb-confidence-memory-v0.10`.
