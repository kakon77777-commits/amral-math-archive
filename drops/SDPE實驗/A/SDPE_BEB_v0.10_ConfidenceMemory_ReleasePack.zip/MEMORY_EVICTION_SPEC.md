# SDPE-BEB v0.10 — Memory Eviction and Forgetting Specification

The memory experiment isolates bounded active memory from confidence uncertainty.

The selector is assumed to know the exact applicability regime for scoring this experiment. The active transfer cache starts with the three calibration regimes and has capacity

$$
K=4.
$$

A hit avoids one architecture-synthesis query. A miss incurs cold synthesis. If that cold solve yields a certified UNSAT proof, its reusable architecture may be inserted into active memory, possibly evicting another entry.

SAT tasks do not create reusable proof-template entries.

Eviction affects active retrieval only. The immutable provenance audit archive remains intact but is unavailable to the scored online policy until the entry is relearned.

The release includes LRU, FIFO, LFU, family-balanced LRU, and an exact offline dynamic-program lower bound for the fixed episode.
