# SDPE-BEB v0.10 — Confidence Calibration Theorem

## 1. Scope

This theorem concerns the benchmark-owned transfer-selector channel only. It does not alter proof authority.

For each coarse structural bucket, let the hidden reusable-template class be

$$
Z\in\{0,1\},
$$

with prior

$$
\Pr(Z=1)=\Pr(Z=0)=\frac12.
$$

Each initial sensor is conditionally independent given $Z$. It is missing with probability $m$, and when observed it reports the correct class with probability $1-\varepsilon$ and the wrong class with probability $\varepsilon$, where

$$
0<\varepsilon<\frac12.
$$

In v0.10,

$$
m=0.15,
\qquad
\varepsilon=0.20.
$$

The optional probe sensor has error

$$
\varepsilon_p=0.05.
$$

## 2. Exact posterior

Let $n_1$ and $n_0$ be the numbers of observed initial votes equal to $1$ and $0$. Missing votes contribute equal likelihood under both classes and therefore cancel from the likelihood ratio.

Hence

$$
\frac{\Pr(Z=1\mid Y)}{\Pr(Z=0\mid Y)}
=
\left(\frac{1-\varepsilon}{\varepsilon}\right)^{n_1-n_0}.
$$

Therefore

$$
\Pr(Z=1\mid Y)
=
\frac{1}{1+\left(\frac{\varepsilon}{1-\varepsilon}\right)^{n_1-n_0}}.
$$

The selector prediction is

$$
\hat Z(Y)=\operatorname*{argmax}_{z\in\{0,1\}}\Pr(Z=z\mid Y),
$$

and its confidence is

$$
C(Y)=\max_z\Pr(Z=z\mid Y).
$$

## 3. Model calibration

For every complete observation pattern $Y=y$,

$$
\Pr(\hat Z=Z\mid Y=y)=C(y).
$$

Consequently, for any confidence value $c$ with positive probability under the declared synthetic channel,

$$
\Pr(\hat Z=Z\mid C=c)=c.
$$

Thus the posterior confidence is exactly calibrated under the declared model.

Finite benchmark samples need not have empirical accuracy exactly equal to $c$ in every confidence group. The release therefore reports empirical Brier score, log loss, and finite-sample ECE separately from the model theorem.

## 4. Probe update

If a probe vote $Y_p\in\{0,1\}$ is requested, its log-likelihood contribution is

$$
\pm\log\left(\frac{1-\varepsilon_p}{\varepsilon_p}\right),
$$

with sign determined by the probe vote. The posterior is updated by Bayes' rule and remains calibrated under the joint declared channel.

## 5. Non-authority corollary

Confidence is not a proof certificate. The UNSAT acceptance predicate contains no confidence term.

A selector may use $C$ to choose among:

$$
\text{reuse},\qquad
\text{probe},\qquad
\text{reset}.
$$

But every target-task lemma and final route is still checked by the unchanged canonical proof verifier. Therefore a miscalibrated or adversarial selector can increase search cost, but cannot by itself create a certified false closure.
