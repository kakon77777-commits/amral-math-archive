# Version Transition — v0.6 to v0.7

v0.6 fixed a finite candidate grammar $\mathcal G_t$ and studied search inside it.

v0.7 replaces that static object with a trajectory of certified fact pools

$$
F_0\to F_1\to\cdots\to F_k,
$$

where every accepted lemma changes the set of well-typed next proposals.

The central new object is therefore not a pre-enumerated proof list but the adaptive region operator

$$
\mathcal R(F_k).
$$
