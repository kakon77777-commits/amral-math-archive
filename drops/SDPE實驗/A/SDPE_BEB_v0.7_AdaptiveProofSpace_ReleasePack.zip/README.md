# SDPE-BEB v0.7 — Adaptive Proof-Space Generation

v0.7 promotes the proof space itself to a dynamic object.

A participant no longer needs a complete candidate proof-DAG grammar before search. The certified fact pool begins with the public premises. Each accepted typed lemma enters the pool and may enable later lemma constructors. Rejected or duplicate proposals do not grow the region.

Key released results:

- 30/30 UNSAT tasks closed by the adaptive reference policy;
- 30/30 SAT controls returned as verified witnesses;
- proposal-query lower bounds attained on every UNSAT task while preserving the v0.5 lexicographic-optimal proof-quality vectors;
- one-hop control closes 10/30 UNSAT tasks;
- 20/30 UNSAT tasks require a lemma that depends on an earlier generated lemma;
- forged, unknown-dependency, cyclic, and duplicate-region proposals are handled fail-closed or nonexpanding as specified.

See `ADAPTIVE_PROOF_SPACE_THEOREM.md`, `ADAPTIVE_SEARCH_MODEL.md`, and `REGION_GROWTH_SPEC.md`.
