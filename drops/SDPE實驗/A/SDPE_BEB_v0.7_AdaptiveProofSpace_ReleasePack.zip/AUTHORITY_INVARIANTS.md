# Authority Invariants — v0.7

All v0.6 proof-authority invariants remain mandatory except that no complete fixed proof-DAG candidate grammar is required for the adaptive track.

Additional v0.7 invariants:

1. The initial adaptive fact pool contains public premises only.
2. A generated lemma enters the fact pool only after canonical certificate verification.
3. A proposal may depend only on premises or already certified generated lemmas.
4. Invalid, cyclic, unknown-dependency, over-fan-in, or forged proposals never grow the fact pool.
5. Typed-semantic duplicates consume a proposal query but do not open a new region.
6. Proposal-query telemetry never substitutes for terminal proof correctness.
7. Proposal-query lower bounds are explicitly calculus- and broker-model-relative.
