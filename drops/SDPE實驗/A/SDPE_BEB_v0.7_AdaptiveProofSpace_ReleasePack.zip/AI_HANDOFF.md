# AI Handoff — SDPE-BEB v0.7

Current frontier: adaptive proof-space generation.

Canonical authority layers:

1. symbolic affine/exclusion replay;
2. bounded-fan-in typed proof-DAG certificate checking;
3. verifier-derived proof quality;
4. adaptive proposal broker;
5. certified fact-pool / region growth telemetry.

Do not infer search cost from hidden reasoning. Proposal-query counts are authoritative only when mediated by the included broker.

Natural next frontier: v0.8 compositional / cross-task lemma libraries, where previously certified reusable lemmas may be imported under explicit provenance and domain guards.
