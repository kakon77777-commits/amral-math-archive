# Adaptive Proof-Space Soundness and Proposal Complexity Theorem — v0.7

## 1. Sound adaptive growth

Let $M(P)$ be the model set of the original public premises. Suppose

$$
F_0=P
$$

and each accepted adaptive lemma $\ell_k$ is verified from dependencies in $F_k$ by a sound structural certificate.

Then for every accepted generated fact $\varphi\in F_k$,

$$
M(P)\subseteq M(\varphi).
$$

### Proof

The premise case is immediate. Assume the property holds for every fact in $F_k$. A sound certificate for $\ell_k$ proves that the conjunction of its dependencies entails its conclusion. Every original model satisfies all dependencies by the induction hypothesis, hence satisfies the new conclusion. Therefore the invariant holds in $F_{k+1}$. By induction it holds for every adaptive region.

Consequently, if a terminal symbolic replay using certified generated lemmas closes,

$$
\Omega=\varnothing,
$$

then the original premise set is UNSAT.

## 2. Proposal-query lower bound

In the v0.7 broker model, every newly introduced lemma in the final proof must have been accepted by at least one individual proposal query. Therefore a proof containing $L$ generated lemmas requires

$$
P_A(t)\ge L.
$$

The calculus-relative lemma-count lower bounds inherited from v0.5 are

$$
L_A\ge1,
$$

$$
L_B\ge4,
$$

and

$$
L_C\ge5.
$$

Hence any broker-mediated construction of a primary-optimal proof satisfies

$$
P_A(t)\ge1,
$$

$$
P_B(t)\ge4,
$$

and

$$
P_C(t)\ge5.
$$

The included adaptive reference policy submits no rejected proposals and constructs the same lexicographic-optimal proof-quality vectors certified in v0.5 while using exactly $1$, $4$, and $5$ accepted novel lemmas on tracks A, B, and C respectively. It therefore attains these proposal-query lower bounds on all 30 UNSAT tasks.

## 3. Adaptive-growth separation

The public one-hop control may derive lemmas only from premises. It closes 10 of 30 UNSAT tasks. The adaptive policy closes 30 of 30, and 20 UNSAT tasks contain at least one certified lemma whose dependency set includes an earlier generated lemma.

Thus the additional 20 closures require proof-region growth beyond the initial one-hop region under the released calculus and budgets.

## 4. Scope

These are certificate-system and broker-model statements. They are not universal lower bounds for arbitrary proof calculi, unrestricted theorem provers, hidden model reasoning, or wall-clock computation.
