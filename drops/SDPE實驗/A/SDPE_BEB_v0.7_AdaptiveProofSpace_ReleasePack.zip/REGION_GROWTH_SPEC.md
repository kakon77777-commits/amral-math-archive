# Region Growth Specification — v0.7

A region-growth event is authoritative only when all of the following hold:

1. the proposed lemma is shape-valid;
2. every dependency names a public premise or an already certified lemma;
3. the dependency graph remains acyclic and within the depth/fan-in limits;
4. the structural certificate recomputes the submitted conclusion exactly;
5. the conclusion is typed-semantically novel in the broker fact pool.

If conditions 1--4 fail, the proposal is rejected. If only condition 5 fails, the proposal is a valid duplicate but does not open a new region.

The broker records the fact-pool size and a syntactic constructor-frontier upper bound before and after each accepted novel proposal. These are search telemetry, not proof authority.
