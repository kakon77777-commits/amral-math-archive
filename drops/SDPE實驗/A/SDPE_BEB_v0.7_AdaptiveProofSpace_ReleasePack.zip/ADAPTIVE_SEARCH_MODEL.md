# Adaptive Proof-Space Generation Model — v0.7

v0.7 removes the need to declare a complete finite candidate proof-DAG grammar before search begins.

## 1. Certified fact pool

Let the public premises be the initial certified fact pool

$$
F_0=P.
$$

At adaptive stage $k$, a proposal is a typed lemma

$$
\ell_k=(\varphi_k,c_k,D_k),
$$

where $D_k\subseteq F_k$, $c_k$ names a supported structural certificate, and the certificate fan-in is at most four.

The proposal broker checks the lemma with the canonical proof-DAG verifier. A new region transition occurs only when the proposal is certificate-valid and its canonical typed conclusion has not already appeared in the fact pool:

$$
F_{k+1}=F_k\cup\{\ell_k\}.
$$

Rejected or typed-semantic-duplicate proposals consume a proposal query but do not grow the fact pool.

## 2. Adaptive region

The currently available proof region is

$$
\mathcal R(F_k)
$$

the set of well-typed next proposals whose dependencies are drawn from the current certified fact pool. Because accepted lemmas may themselves become dependencies, in general

$$
\mathcal R(F_{k+1})\neq\mathcal R(F_k).
$$

The proof space is therefore generated along the search trajectory rather than supplied as one complete candidate list.

## 3. Proposal-query complexity

One proposal query is one individual lemma passed through the adaptive proposal broker. Let

$$
P_A(t)
$$

be the number of proposal queries issued by policy $A$ before it has built a terminal certified proof for task $t$.

Terminal proof replay is counted separately. Hidden chain-of-thought, private token usage, and unrestricted internal computation are not inferred from this metric.

## 4. Typed semantic finiteness

For fixed $n$, the generated structural language is finite under typed semantic deduplication. There are at most

$$
2^{n+1}
$$

affine equations over $\mathbb F_2$ and at most

$$
3^n-1
$$

nonempty `mask_equals` predicates. Thus full typed closure is finite for fixed $n$, even though v0.7 does not enumerate that closure in advance.
