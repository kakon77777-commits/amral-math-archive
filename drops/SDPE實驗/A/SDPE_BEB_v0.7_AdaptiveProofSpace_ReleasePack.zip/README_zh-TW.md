# SDPE-BEB v0.7 — 自適應證明空間生成

v0.7 把「證明空間本身」提升成動態研究對象。

初始 fact pool 只有公開 premises。每個 participant / search policy 提出的 lemma 都必須先經 proposal broker 與 canonical verifier 驗證；只有 certificate 正確且 typed-semantic novel 的 lemma 才會進入 fact pool，並開啟後續可依賴它的新 proof region。

本版主要結果：

- adaptive reference policy：30/30 UNSAT 關閉；
- SAT control：30/30 witness 驗證成功；
- 30/30 UNSAT 全部達到 calculus-relative proposal-query lower bound，且保持 v0.5 的 lexicographic-optimal proof quality；
- one-hop control 只有 10/30 UNSAT closure；
- 其中 20/30 UNSAT 必須依賴先前生成 lemma 才能完成後續 lemma；
- forged / unknown dependency / self-cycle proposal 全部拒絕；typed semantic duplicate 可驗證但不開新 region。

核心文件：`ADAPTIVE_PROOF_SPACE_THEOREM.md`、`ADAPTIVE_SEARCH_MODEL.md`、`REGION_GROWTH_SPEC.md`。
