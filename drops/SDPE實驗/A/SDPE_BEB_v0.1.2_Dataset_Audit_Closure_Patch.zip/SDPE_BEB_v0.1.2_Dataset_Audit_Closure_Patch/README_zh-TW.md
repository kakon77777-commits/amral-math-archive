# SDPE-BEB v0.1.2 Dataset Audit Closure Patch + Symbolic Replay Prototype

本包是針對 v0.1.1 Independent Audit 發現之 dataset-level integrity gap 的直接修補與下一階段原型。

## v0.1.2 auditor 核心 invariant

正式 certification 前必須先成立：

$$
S_{\mathrm{submitted}}=T_{\mathrm{expected}},
\qquad
\forall t\in T_{\mathrm{expected}},\ \#S(t)=1.
$$

並要求 submission JSON 符合 schema、task/oracle 集合完整且 oracle ID 唯一。若整體 submission set 無效，個別 case 仍保留 `case_certified_*` 作診斷，但正式 `certified_*` 一律被 dataset gate 壓成 false。

新增完整性欄位包括：

- `missing_task_ids`
- `duplicate_task_ids`
- `unknown_task_ids`
- `submission_parse_failures`
- `submission_schema_failures`
- `duplicate_oracle_task_ids`
- `oracle_missing_task_ids`
- `oracle_extra_task_ids`
- `dataset_source_valid`
- `submission_set_valid`
- `dataset_submission_valid`

## Symbolic replay prototype

目前 replay 會 materialize $2^n$ 個 Boolean assignments。本包提供 `tools/symbolic_replay.py`，對現有 predicate class 以

$$
\text{GF}(2)\ \text{affine subspace}
+\text{finite forbidden points}
$$

精確表示 survivor state。

若 affine system rank 為 $r$，且當前 affine subspace 中有 $q$ 個不同 forbidden points，則

$$
|\Omega|=2^{n-r}-q.
$$

因此 bit/parity/mask constraints 以 Gaussian elimination 更新，而 singleton exclusion 不必枚舉全域。這使 current benchmark class 的 replay 可由 exponential universe materialization 改為 polynomial symbolic state maintenance（相對於 $n$、action rows 與 finite exclusions）。

## 定位

- v0.1.1：single-case proof authority repair
- v0.1.2 patch：dataset-set authority closure
- v0.2 prototype direction：symbolic proof-state / no-$2^n$ replay

## Fresh regression results

### Dataset-gated auditor

合法原版 structural submission：

$$
50\ \mathrm{certified\ UNSAT}+10\ \mathrm{certified\ SAT}.
$$

合法 Neutral structural submission：

$$
30\ \mathrm{certified\ UNSAT}+30\ \mathrm{certified\ SAT}.
$$

下列 adversarial inputs 全部得到 `dataset_submission_valid=false`，且正式 `certified_closures=0`、`certified_counterexamples=0`：

1. 只提交 1/60 題；
2. 同一 task 複製 60 次；
3. 缺 `selected_actions` / `declared_closed` 等 schema required fields；
4. unknown task ID；
5. malformed JSONL。

### Neutral Public runner bug

原始 v0.1.1 Neutral Public Bundle 的 `tools/public_runner.py` import `universe`，但同包 `tools/common.py` 未定義該函數，因此 participant prompt 指示的 `inspect` 命令會直接 `ImportError`。

本包 `patches/neutral_public/tools/common.py` 補入 `universe()`，並同時修正 Python `bool` 被 `isinstance(w,int)` 接受的 witness 型別邊界。Fresh smoke test：3/3 family inspect、60/60 replay、60/60 verify-submission 全通過。

### Symbolic equivalence

原版 v0.1.1：

- 240 條既有 submission routes；
- 730 個 cut predicates；
- mismatch = 0。

Neutral v0.1.1：

- 120 條既有 submission routes；
- 800 個 cut predicates；
- mismatch = 0。

合計：

$$
360\ \text{routes}+1530\ \text{predicate checks},
\qquad
\boxed{0\ \text{mismatch}}.
$$

Synthetic scaling smoke（單一 affine cut）顯示 enumerative replay 隨 $2^n$ 成長，而 symbolic replay 在此範圍保持近乎固定的小量代數成本；$n=20$ 的本機單次測試約呈現 $2.3\times10^3$ 倍速度差。此數值只作 implementation smoke evidence，不應視為跨硬體 benchmark 常數。
