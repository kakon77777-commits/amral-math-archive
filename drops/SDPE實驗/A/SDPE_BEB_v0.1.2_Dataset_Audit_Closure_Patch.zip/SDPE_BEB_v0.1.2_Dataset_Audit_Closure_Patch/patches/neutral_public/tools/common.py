#!/usr/bin/env python3
from __future__ import annotations
import json,hashlib

def canon(o): return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha_text(s): return hashlib.sha256(s.encode('utf-8')).hexdigest()
def sat_pred(a,p):
    k=p['kind']
    if k=='bit_equals': return ((a>>p['var'])&1)==p['value']
    if k=='parity': return (sum((a>>v)&1 for v in p['vars'])&1)==p['value']
    if k=='mask_equals': return (a&p['mask'])==p['pattern']
    if k=='forbid_assignment': return a!=p['assignment']
    if k=='true': return True
    if k=='false': return False
    raise ValueError(k)
def premise_map(t): return {x['constraint_id']:x['predicate'] for x in t['premises']}
def action_map(t): return {x['action_id']:x for x in t['actions']}
def affine_row(p,n):
    k=p['kind']
    if k=='bit_equals': return 1<<p['var'],p['value']
    if k=='parity':
        m=0
        for v in p['vars']: m ^= 1<<v
        return m,p['value']
    raise ValueError('non-affine predicate')
def row_pred(mask,rhs):
    if mask==0: return {'kind':'true'} if rhs==0 else {'kind':'false'}
    if mask & (mask-1)==0: return {'kind':'bit_equals','var':mask.bit_length()-1,'value':rhs}
    return {'kind':'parity','vars':[i for i in range(mask.bit_length()) if (mask>>i)&1],'value':rhs}
def derived_predicate(t,rule):
    pm=premise_map(t); kind=rule['rule']; deps=rule['dependencies']
    if kind=='gf2_xor_sum':
        m=0;r=0
        for d in deps:
            mi,ri=affine_row(pm[d],t['n_vars']); m^=mi; r^=ri
        return row_pred(m,r)
    if kind in ('unit_assignment','unit_subset_assignment'):
        mask=0;pattern=0
        for d in deps:
            p=pm[d]
            if p['kind']!='bit_equals': raise ValueError('unit aggregate requires bit_equals')
            b=1<<p['var']; mask|=b
            if p['value']: pattern|=b
        return {'kind':'mask_equals','mask':mask,'pattern':pattern}
    raise ValueError(kind)
def action_predicate(t,a):
    ps=a.get('predicate_source')
    if ps is None:return None
    if ps['kind']=='premise':return premise_map(t)[ps['constraint_id']]
    if ps['kind']=='inline':return ps['predicate']
    if ps['kind']=='derived':return derived_predicate(t,ps)
    raise ValueError(ps)
def verify_action_certificate(t,a):
    if a['action_type']=='bridge': return True,{'mode':'bridge-no-proof-authority'}
    cert=a['certificate']; pred=action_predicate(t,a); k=cert['kind']
    if k=='premise_identity':
        d=cert['dependencies'][0]; return pred==premise_map(t)[d],{'mode':k}
    if k=='gf2_linear_combo':
        exp=derived_predicate(t,{'rule':'gf2_xor_sum','dependencies':cert['dependencies']}); return exp==pred,{'mode':k,'operations':len(cert['dependencies'])}
    if k=='unit_aggregate':
        exp=derived_predicate(t,{'rule':cert.get('rule','unit_assignment'),'dependencies':cert['dependencies']}); return exp==pred,{'mode':k,'operations':len(cert['dependencies'])}
    return False,{'mode':'unknown'}
def total_cost(a): return sum(float(v) for v in a.get('cost',{}).values())
def witness_valid(t,w): return isinstance(w,int) and not isinstance(w,bool) and 0<=w<(1<<t['n_vars']) and all(sat_pred(w,p['predicate']) for p in t['premises'])
def universe(task): return list(range(1<<task['n_vars']))
def apply_pred(s,p): return [x for x in s if sat_pred(x,p)]
def replay(t,selected_actions,strict=True):
    amap=action_map(t); unlocked=set(t['initially_unlocked']); used=set(); surv=list(range(1<<t['n_vars'])); trace=[]; cost=0.0
    for step,aid in enumerate(selected_actions,1):
        if aid not in amap: raise ValueError(f'unknown action {aid}')
        if aid in used: raise ValueError(f'repeated action {aid}')
        if aid not in unlocked: raise ValueError(f'locked action {aid}')
        a=amap[aid]
        if any(x not in used for x in a.get('requires',[])): raise ValueError(f'prerequisites not satisfied for {aid}')
        ok,ci=verify_action_certificate(t,a)
        if strict and not ok: raise ValueError(f'certificate failed {aid}: {ci}')
        before=len(surv); p=action_predicate(t,a)
        if p is not None and ok: surv=apply_pred(surv,p)
        after=len(surv); used.add(aid); unlocked.update(a.get('unlocks',[])); c=total_cost(a); cost+=c
        trace.append({'step':step,'action_id':aid,'type':a['action_type'],'before':before,'after':after,'eliminated':before-after,'certificate_ok':ok,'certificate_mode':ci.get('mode'),'model_cost':c})
        if after==0: break
    step_ok=len(selected_actions)<=t['budget']; cost_ok=cost<=t['cost_budget']+1e-12
    return {'closed':not surv,'final_survivor_size':len(surv),'final_survivor':surv,'trace':trace,'model_cost':cost,'step_budget_ok':step_ok,'cost_budget_ok':cost_ok,'within_budget':step_ok and cost_ok,'used':sorted(used),'unlocked':sorted(unlocked)}
