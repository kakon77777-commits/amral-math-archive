#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from common import replay,action_map,action_predicate,apply_pred,universe,verify_action_certificate,total_cost,witness_valid

def inspect(task):
    amap=action_map(task); surv=universe(task); rows=[]
    for aid in task['initially_unlocked']:
        a=amap[aid]; ok,_=verify_action_certificate(task,a); pred=action_predicate(task,a); after=surv if pred is None else apply_pred(surv,pred)
        rows.append({'action_id':aid,'type':a['action_type'],'certificate_ok':ok,'immediate_elimination':len(surv)-len(after),'model_cost':total_cost(a),'unlocks':a.get('unlocks',[])})
    return {'task_id':task['task_id'],'family':task['family'],'n_vars':task['n_vars'],'step_budget':task['budget'],'cost_budget':task['cost_budget'],'initial_survivor_size':len(surv),'initial_actions':rows,'oracle_commitment':task['oracle_commitment']}

def verify_submission(task,s):
    out={'task_id':task['task_id'],'replay_ok':False,'declaration_consistent':False,'witness_valid':False}
    try: rr=replay(task,s['selected_actions']); out['replay_ok']=True
    except Exception as e: out['error']=str(e); out['submission_valid']=False; return out
    dc=(bool(s.get('declared_closed',False))==bool(rr['closed']))
    wv=witness_valid(task,s.get('counterexample_assignment')) if s.get('declared_counterexample',False) else False
    ce_consistent=(not s.get('declared_counterexample',False)) or (wv and not rr['closed'])
    out.update(rr); out['declaration_consistent']=dc; out['witness_valid']=wv; out['counterexample_declaration_consistent']=ce_consistent
    out['submission_valid']=bool(rr['within_budget'] and dc and ce_consistent)
    out['unsupported_closure_claim']=bool(s.get('declared_closed',False) and not rr['closed'])
    return out

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('inspect'); p.add_argument('task')
    p=sub.add_parser('replay'); p.add_argument('task'); p.add_argument('submission')
    p=sub.add_parser('verify-submission'); p.add_argument('task'); p.add_argument('submission')
    args=ap.parse_args(); task=json.loads(Path(args.task).read_text(encoding='utf-8'))
    if args.cmd=='inspect': out=inspect(task)
    else:
        s=json.loads(Path(args.submission).read_text(encoding='utf-8'))
        if s['task_id']!=task['task_id']: raise SystemExit('task_id mismatch')
        out=replay(task,s['selected_actions']) if args.cmd=='replay' else verify_submission(task,s)
        out['task_id']=task['task_id']
    print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True))
if __name__=='__main__': main()
