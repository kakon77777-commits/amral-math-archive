#!/usr/bin/env python3
from __future__ import annotations
import importlib.util,json,time,statistics,argparse
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument('--common',required=True); ap.add_argument('--symbolic',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
spec=importlib.util.spec_from_file_location('common',a.common); common=importlib.util.module_from_spec(spec); spec.loader.exec_module(common)
spec2=importlib.util.spec_from_file_location('sym',a.symbolic); sym=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(sym)

def task(n):
 aid='A0'; return {'n_vars':n,'premises':[{'constraint_id':'K0','predicate':{'kind':'bit_equals','var':0,'value':1}}], 'actions':[{'action_id':aid,'action_type':'cut','requires':[],'unlocks':[],'predicate_source':{'kind':'premise','constraint_id':'K0'},'certificate':{'kind':'premise_identity','dependencies':['K0']},'cost':{'discover':1,'verify':1}}], 'initially_unlocked':[aid], 'budget':1,'cost_budget':10.0}
rows=[]
for n in [8,10,12,14,16,18,20]:
 t=task(n); reps=5 if n<=16 else 3
 et=[]; st=[]
 for _ in range(reps):
  q=time.perf_counter(); e=common.replay(t,['A0']); et.append(time.perf_counter()-q)
  q=time.perf_counter(); z=sym.symbolic_replay(t,['A0'],common); st.append(time.perf_counter()-q)
 assert e['final_survivor_size']==z['final_survivor_size']==(1<<(n-1))
 rows.append({'n_vars':n,'universe_size':1<<n,'enumerative_median_s':statistics.median(et),'symbolic_median_s':statistics.median(st),'speedup':statistics.median(et)/max(statistics.median(st),1e-12)})
Path(a.out).write_text(json.dumps({'rows':rows},indent=2)+'\n')
print(json.dumps({'rows':rows},indent=2))
