#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json, random
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument('--common',required=True); ap.add_argument('--symbolic',required=True); ap.add_argument('--trials',type=int,default=10000); ap.add_argument('--seed',type=int,default=202608142104); ap.add_argument('--out',required=True); a=ap.parse_args()
spec=importlib.util.spec_from_file_location('common',a.common); common=importlib.util.module_from_spec(spec); spec.loader.exec_module(common)
spec2=importlib.util.spec_from_file_location('sym',a.symbolic); sym=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(sym)
r=random.Random(a.seed); mism=[]; step_checks=0

def pred(n):
 k=r.choice(['bit_equals','parity','mask_equals','forbid_assignment','true','false'])
 if k=='bit_equals': return {'kind':k,'var':r.randrange(n+2),'value':r.randrange(2)}
 if k=='parity': return {'kind':k,'vars':[r.randrange(n+2) for _ in range(r.randrange(0,n+3))],'value':r.randrange(2)}
 if k=='mask_equals':
  mask=r.randrange(1<<(n+2)); pattern=r.randrange(1<<(n+2)); return {'kind':k,'mask':mask,'pattern':pattern}
 if k=='forbid_assignment': return {'kind':k,'assignment':r.randrange(1<<(n+2))}
 return {'kind':k}
for tr in range(a.trials):
 n=r.randrange(1,9); enum=list(range(1<<n)); st=sym.GF2State(n); seq=[]
 for j in range(r.randrange(1,13)):
  p=pred(n); seq.append(p); enum=[x for x in enum if common.sat_pred(x,p)]; st.add_pred(p); step_checks+=1; got=st.survivor_size()
  if len(enum)!=got:
   mism.append({'trial':tr,'step':j+1,'n':n,'sequence':seq,'enum_size':len(enum),'symbolic_size':got}); break
out={'seed':a.seed,'trials':a.trials,'step_checks':step_checks,'mismatch_count':len(mism),'first_mismatches':mism[:20]}
Path(a.out).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n'); print(json.dumps(out,indent=2,sort_keys=True))
