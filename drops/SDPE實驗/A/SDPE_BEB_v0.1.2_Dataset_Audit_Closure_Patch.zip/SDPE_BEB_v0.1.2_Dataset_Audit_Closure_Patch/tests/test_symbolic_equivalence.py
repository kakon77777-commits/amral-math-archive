#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json, sys
from pathlib import Path

ap=argparse.ArgumentParser(); ap.add_argument('--dataset',required=True); ap.add_argument('--submissions',action='append',default=[]); ap.add_argument('--symbolic',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
D=Path(a.dataset)
spec=importlib.util.spec_from_file_location('dataset_common', D/'tools/common.py'); common=importlib.util.module_from_spec(spec); spec.loader.exec_module(common)
spec2=importlib.util.spec_from_file_location('sym', Path(a.symbolic)); sym=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(sym)

def load_tasks(): return {p.stem:json.load(open(p)) for p in sorted((D/'public/tasks').glob('*.json'))}
def load_sub(path):
 out=[]
 for line in Path(path).read_text().splitlines():
  if line.strip(): out.append(json.loads(line))
 return out

tasks=load_tasks(); mism=[]; route_checks=0; predicate_checks=0
for sp in a.submissions:
 for s in load_sub(sp):
  t=tasks[s['task_id']]
  try: e=common.replay(t,s.get('selected_actions',[]))
  except Exception as ee:
   try: sym.symbolic_replay(t,s.get('selected_actions',[]),common)
   except Exception: continue
   mism.append({'kind':'route-exception','task_id':t['task_id'],'submission':sp,'enum_error':str(ee),'symbolic_error':None}); continue
  try: z=sym.symbolic_replay(t,s.get('selected_actions',[]),common)
  except Exception as ze:
   mism.append({'kind':'route-exception','task_id':t['task_id'],'submission':sp,'enum_error':None,'symbolic_error':str(ze)}); continue
  route_checks+=1
  keys=['closed','final_survivor_size','within_budget','step_budget_ok','cost_budget_ok','model_cost']
  for k in keys:
   if e[k]!=z[k]: mism.append({'kind':'route-final','task_id':t['task_id'],'submission':sp,'key':k,'enum':e[k],'symbolic':z[k]})
  et=[(q['before'],q['after'],q['eliminated'],q['certificate_ok']) for q in e['trace']]
  zt=[(q['before'],q['after'],q['eliminated'],q['certificate_ok']) for q in z['trace']]
  if et!=zt: mism.append({'kind':'trace','task_id':t['task_id'],'submission':sp,'enum':et,'symbolic':zt})

# Predicate-level exact count checks for every cut predicate, independent of lock state.
for t in tasks.values():
 for act in t['actions']:
  p=common.action_predicate(t,act)
  if p is None: continue
  predicate_checks+=1
  enum=sum(1 for x in range(1<<t['n_vars']) if common.sat_pred(x,p))
  st=sym.GF2State(t['n_vars']); st.add_pred(p); got=st.survivor_size()
  if enum!=got: mism.append({'kind':'predicate-count','task_id':t['task_id'],'action_id':act['action_id'],'predicate':p,'enum':enum,'symbolic':got})

out={'dataset':D.name,'task_count':len(tasks),'route_checks':route_checks,'predicate_checks':predicate_checks,'mismatch_count':len(mism),'mismatches':mism}
Path(a.out).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
