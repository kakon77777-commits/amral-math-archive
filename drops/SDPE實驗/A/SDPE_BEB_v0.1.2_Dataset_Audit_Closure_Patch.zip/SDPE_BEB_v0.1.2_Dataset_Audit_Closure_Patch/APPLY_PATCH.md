# SDPE-BEB v0.1.2 Patch Application Notes

## A. Oracle / Full-Dev auditor

以本包：

`tools/audit_reveal.py`

取代 Original 與 Neutral Variant 的 `tools/audit_reveal.py`，並保留各自原有 `tools/common.py`。

新 auditor 保持原 CLI 必要參數：

```bash
python tools/audit_reveal.py \
  --tasks-dir <PUBLIC>/public/tasks \
  --oracles private_oracle/oracle_answers.jsonl \
  --submissions submissions.jsonl \
  --out audit.json
```

它會自動從 `<PUBLIC>/schemas/` 偵測 submission/task/oracle schemas；亦可用 `--submission-schema`、`--task-schema`、`--oracle-schema` 明確指定。

## B. Neutral Public runtime

將：

`patches/neutral_public/tools/common.py`

取代 Neutral Public / Neutral Full-Dev 的 `tools/common.py`。`public_runner.py` 本身不需語義修改；缺失的是 `common.universe()`。

## C. Required release regression

正式重新打包前至少必跑：

1. checksum regeneration；
2. valid 60/60 structural audit；
3. one-task rejection；
4. duplicate-task rejection；
5. schema-missing rejection；
6. unknown-task rejection；
7. malformed JSONL rejection；
8. Neutral Public runner import + inspect smoke；
9. canonical package excludes `__pycache__` / `*.pyc`。

## D. v0.2 candidate

`tools/symbolic_replay.py` 是下一版原型，不建議直接 silent-replace v0.1.2 canonical replay；應先作一版 dual-run validator：enumerative 與 symbolic 同時執行，要求所有 trace survivor counts 完全一致，再把 symbolic 升為 canonical authority。
