#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys, importlib.util
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument('--bundle-root',required=True); ap.add_argument('--submissions'); ap.add_argument('--out'); a=ap.parse_args()
R=Path(a.bundle_root); tools=R/'tools'; sys.path.insert(0,str(tools))
errors=[]
try:
 import common
 spec=importlib.util.spec_from_file_location('public_runner',tools/'public_runner.py'); runner=importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
except Exception as e:
 out={'task_count':0,'inspect_ok':0,'replay_ok':0,'verify_ok':0,'errors':[{'command':'import','error':repr(e)}],'pass':False}; txt=json.dumps(out,indent=2,sort_keys=True)+'\n';
 if a.out: Path(a.out).write_text(txt)
 print(txt,end=''); raise SystemExit(1)
tasks={p.stem:json.loads(p.read_text()) for p in sorted((R/'public/tasks').glob('*.json'))}; inspect_ok=replay_ok=verify_ok=0
# Run inspect once per family; import path and full function stack are exercised.
seen=set()
for tid,t in tasks.items():
 fam=t['family']
 if fam in seen: continue
 seen.add(fam)
 try:
  x=runner.inspect(t); json.dumps(x); inspect_ok+=1
 except Exception as e: errors.append({'command':'inspect','task':tid,'error':repr(e)})
if a.submissions:
 byid={}
 for line in Path(a.submissions).read_text(encoding='utf-8').splitlines():
  if line.strip():
   x=json.loads(line); byid[x['task_id']]=x
 for tid,s in byid.items():
  if tid not in tasks: continue
  t=tasks[tid]
  try: common.replay(t,s['selected_actions']); replay_ok+=1
  except Exception as e: errors.append({'command':'replay','task':tid,'error':repr(e)})
  try: runner.verify_submission(t,s); verify_ok+=1
  except Exception as e: errors.append({'command':'verify-submission','task':tid,'error':repr(e)})
out={'task_count':len(tasks),'family_inspect_smokes':inspect_ok,'replay_ok':replay_ok,'verify_ok':verify_ok,'errors':errors,'pass':not errors}
txt=json.dumps(out,indent=2,sort_keys=True)+'\n'
if a.out: Path(a.out).write_text(txt)
print(txt,end='')
