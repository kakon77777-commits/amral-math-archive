#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from collections import Counter, defaultdict
from pathlib import Path
from common import canon, sha_text, replay, witness_valid

try:
    from jsonschema import Draft202012Validator
except Exception:
    Draft202012Validator = None


def read_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def schema_errors(obj, schema):
    if schema is None:
        errs=[]
        if not isinstance(obj, dict): return ['submission must be an object']
        for k in ('task_id','selected_actions','declared_closed'):
            if k not in obj: errs.append(f"missing required property: {k}")
        if 'task_id' in obj and not isinstance(obj['task_id'], str): errs.append('task_id must be string')
        if 'selected_actions' in obj and (not isinstance(obj['selected_actions'], list) or any(not isinstance(x,str) for x in obj['selected_actions'])): errs.append('selected_actions must be array[string]')
        if 'declared_closed' in obj and not isinstance(obj['declared_closed'], bool): errs.append('declared_closed must be boolean')
        if 'declared_counterexample' in obj and not isinstance(obj['declared_counterexample'], bool): errs.append('declared_counterexample must be boolean')
        if 'counterexample_assignment' in obj:
            w=obj['counterexample_assignment']
            if w is not None and (not isinstance(w,int) or isinstance(w,bool) or w<0): errs.append('counterexample_assignment must be nonnegative integer or null')
        for k in ('notes','policy'):
            if k in obj and not isinstance(obj[k],str): errs.append(f'{k} must be string')
        return errs
    if Draft202012Validator is None:
        return schema_errors(obj, None)
    return [e.message for e in sorted(Draft202012Validator(schema).iter_errors(obj), key=lambda e: list(e.path))]


def load_tasks(tasks_dir: Path, task_schema=None):
    tasks={}; errors=[]; duplicate_internal=[]
    for p in sorted(tasks_dir.glob('*.json')):
        try: t=read_json(p)
        except Exception as e:
            errors.append({'file':p.name,'error':f'json parse: {e}'}); continue
        se=schema_errors(t, task_schema) if task_schema else []
        if se: errors.append({'file':p.name,'error':'schema','details':se})
        tid=t.get('task_id') if isinstance(t,dict) else None
        if not isinstance(tid,str):
            errors.append({'file':p.name,'error':'missing/invalid task_id'}); continue
        if p.stem != tid: errors.append({'file':p.name,'error':f'filename/task_id mismatch: {tid}'})
        if tid in tasks: duplicate_internal.append(tid)
        else: tasks[tid]=t
    return tasks, errors, sorted(set(duplicate_internal))


def load_oracles(path: Path, oracle_schema=None):
    rows=[]; counts=Counter(); parse_fail=[]; schema_fail=[]
    for ln,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip(): continue
        try: x=json.loads(line)
        except Exception as e:
            parse_fail.append({'line':ln,'error':str(e)}); continue
        se=schema_errors(x, oracle_schema) if oracle_schema else []
        if se: schema_fail.append({'line':ln,'task_id':x.get('task_id') if isinstance(x,dict) else None,'errors':se})
        tid=x.get('task_id') if isinstance(x,dict) else None
        if isinstance(tid,str): counts[tid]+=1
        rows.append((ln,x))
    mapping={}
    for ln,x in rows:
        tid=x.get('task_id') if isinstance(x,dict) else None
        if isinstance(tid,str) and counts[tid]==1: mapping[tid]=x
    duplicates=sorted(t for t,c in counts.items() if c>1)
    return mapping, rows, parse_fail, schema_fail, duplicates


def load_submissions(path: Path, submission_schema=None):
    rows=[]; parse_fail=[]; schema_fail=[]; counts=Counter()
    for ln,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip(): continue
        try: s=json.loads(line)
        except Exception as e:
            parse_fail.append({'line':ln,'error':str(e)}); rows.append({'line':ln,'obj':None,'schema_ok':False,'schema_errors':[str(e)]}); continue
        se=schema_errors(s, submission_schema)
        tid=s.get('task_id') if isinstance(s,dict) else None
        if se: schema_fail.append({'line':ln,'task_id':tid,'errors':se})
        if isinstance(tid,str): counts[tid]+=1
        rows.append({'line':ln,'obj':s,'schema_ok':not se,'schema_errors':se})
    return rows, parse_fail, schema_fail, counts


def autodetect_schema(tasks_dir: Path, name: str):
    p=tasks_dir.parent.parent/'schemas'/name
    return read_json(p) if p.exists() else None


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--tasks-dir',required=True)
    ap.add_argument('--oracles',required=True)
    ap.add_argument('--submissions',required=True)
    ap.add_argument('--out')
    ap.add_argument('--submission-schema')
    ap.add_argument('--task-schema')
    ap.add_argument('--oracle-schema')
    a=ap.parse_args()
    tasks_dir=Path(a.tasks_dir)
    submission_schema=read_json(Path(a.submission_schema)) if a.submission_schema else autodetect_schema(tasks_dir,'submission.schema.json')
    task_schema=read_json(Path(a.task_schema)) if a.task_schema else autodetect_schema(tasks_dir,'task.schema.json')
    oracle_schema=read_json(Path(a.oracle_schema)) if a.oracle_schema else autodetect_schema(tasks_dir,'oracle.schema.json')

    tasks, task_errors, task_dups = load_tasks(tasks_dir, task_schema)
    oracles, oracle_rows, oracle_parse_fail, oracle_schema_fail, oracle_dups = load_oracles(Path(a.oracles), oracle_schema)
    sub_rows, sub_parse_fail, sub_schema_fail, sub_counts = load_submissions(Path(a.submissions), submission_schema)

    expected=set(tasks)
    submitted_known={tid for tid in sub_counts if tid in expected}
    submitted_all=set(sub_counts)
    missing=sorted(expected-submitted_known)
    unknown=sorted(submitted_all-expected)
    duplicates=sorted(tid for tid,c in sub_counts.items() if c>1)
    oracle_ids=set(oracles)
    oracle_missing=sorted(expected-oracle_ids)
    oracle_extra=sorted(oracle_ids-expected)

    dataset_source_valid=not (task_errors or task_dups or oracle_parse_fail or oracle_schema_fail or oracle_dups or oracle_missing or oracle_extra)
    submission_set_valid=not (sub_parse_fail or sub_schema_fail or missing or unknown or duplicates)
    dataset_submission_valid=bool(dataset_source_valid and submission_set_valid)

    results=[]
    for row in sub_rows:
        ln=row['line']; s=row['obj']
        if not isinstance(s,dict):
            results.append({'line':ln,'task_id':None,'schema_valid':False,'known_task':False,'case_submission_valid':False,'case_error':'unparseable/non-object submission','case_certified_closure':False,'case_certified_counterexample':False,'certified_closure':False,'certified_counterexample':False})
            continue
        tid=s.get('task_id'); known=isinstance(tid,str) and tid in tasks and tid in oracles
        if not known:
            results.append({'line':ln,'task_id':tid,'schema_valid':row['schema_ok'],'known_task':False,'case_submission_valid':False,'case_error':'unknown task or missing unique oracle','case_certified_closure':False,'case_certified_counterexample':False,'certified_closure':False,'certified_counterexample':False})
            continue
        task=tasks[tid]; o=oracles[tid]
        try:
            commit=sha_text(canon(o['oracle'])+'|'+o['nonce'])
            commit_ok=commit==task['oracle_commitment']['commitment']==o['commitment']
        except Exception:
            commit_ok=False
        replay_ok=True; replay_error=None
        try: rr=replay(task,s.get('selected_actions',[]))
        except Exception as e:
            replay_ok=False; replay_error=str(e)
            rr={'closed':False,'final_survivor_size':1<<task['n_vars'],'model_cost':0.0,'trace':[],'within_budget':False,'step_budget_ok':False,'cost_budget_ok':False}
        declared_closed=bool(s.get('declared_closed',False)); oracle_truth=bool(o['oracle']['claim_truth'])
        unsupported=bool(declared_closed and not rr['closed'])
        declaration_consistent=bool(declared_closed==rr['closed'])
        declared_ce=bool(s.get('declared_counterexample',False)); w=s.get('counterexample_assignment')
        wv=witness_valid(task,w) if declared_ce else False
        ce_consistent=(not declared_ce) or (wv and not rr['closed'])
        unique_row=(isinstance(tid,str) and sub_counts[tid]==1)
        case_submission_valid=bool(row['schema_ok'] and unique_row and replay_ok and rr['within_budget'] and declaration_consistent and ce_consistent)
        label_correct=(declared_closed==oracle_truth) if not declared_ce else (not oracle_truth and wv)
        case_certified_closure=bool(commit_ok and case_submission_valid and rr['closed'] and declared_closed and oracle_truth)
        case_false_certified_closure=bool(commit_ok and case_submission_valid and rr['closed'] and declared_closed and not oracle_truth)
        case_certified_counterexample=bool(commit_ok and case_submission_valid and declared_ce and wv and not oracle_truth)
        # Official certification is dataset-gated. Diagnostics remain visible via case_certified_*.
        certified_closure=bool(dataset_submission_valid and case_certified_closure)
        false_certified_closure=bool(dataset_submission_valid and case_false_certified_closure)
        certified_counterexample=bool(dataset_submission_valid and case_certified_counterexample)
        results.append({'line':ln,'task_id':tid,'family':task.get('family'),'schema_valid':row['schema_ok'],'schema_errors':row['schema_errors'],'known_task':True,'unique_submission_for_task':unique_row,'commitment_ok':commit_ok,'replay_ok':replay_ok,'replay_error':replay_error,'route_closed':rr['closed'],'declared_closed':declared_closed,'declared_counterexample':declared_ce,'witness_valid':wv,'oracle_claim_truth':oracle_truth,'label_correct':label_correct,'declaration_consistent':declaration_consistent,'case_submission_valid':case_submission_valid,'unsupported_closure_claim':unsupported,'case_certified_closure':case_certified_closure,'case_false_certified_closure':case_false_certified_closure,'case_certified_counterexample':case_certified_counterexample,'certified_closure':certified_closure,'false_certified_closure':false_certified_closure,'certified_counterexample':certified_counterexample,'within_budget':rr['within_budget'],'step_budget_ok':rr.get('step_budget_ok',False),'cost_budget_ok':rr.get('cost_budget_ok',False),'steps':len(rr['trace']),'final_survivor_size':rr['final_survivor_size'],'model_cost':rr['model_cost']})

    integrity={
        'expected_task_count':len(expected),
        'submission_row_count':len(sub_rows),
        'unique_submitted_task_count':len(submitted_all),
        'missing_task_ids':missing,
        'duplicate_task_ids':{tid:sub_counts[tid] for tid in duplicates},
        'unknown_task_ids':unknown,
        'submission_parse_failures':sub_parse_fail,
        'submission_schema_failures':sub_schema_fail,
        'task_integrity_errors':task_errors,
        'duplicate_internal_task_ids':task_dups,
        'oracle_parse_failures':oracle_parse_fail,
        'oracle_schema_failures':oracle_schema_fail,
        'duplicate_oracle_task_ids':oracle_dups,
        'oracle_missing_task_ids':oracle_missing,
        'oracle_extra_task_ids':oracle_extra,
        'dataset_source_valid':dataset_source_valid,
        'complete_submission_set':not missing and len(sub_rows)==len(expected),
        'unique_submission_set':not duplicates,
        'schema_valid_submission_set':not sub_parse_fail and not sub_schema_fail,
        'submission_set_valid':submission_set_valid,
        'dataset_submission_valid':dataset_submission_valid,
    }
    summary={
        'cases':len(results),
        'expected_cases':len(expected),
        'dataset_submission_valid':dataset_submission_valid,
        'commitment_failures':sum(1 for r in results if r.get('known_task') and not r.get('commitment_ok',False)),
        'label_correct':sum(bool(r.get('label_correct')) for r in results),
        'route_closures':sum(bool(r.get('route_closed')) for r in results),
        'provisional_case_certified_closures':sum(bool(r.get('case_certified_closure')) for r in results),
        'provisional_case_certified_counterexamples':sum(bool(r.get('case_certified_counterexample')) for r in results),
        'certified_closures':sum(bool(r.get('certified_closure')) for r in results),
        'false_certified_closures':sum(bool(r.get('false_certified_closure')) for r in results),
        'certified_counterexamples':sum(bool(r.get('certified_counterexample')) for r in results),
        'unsupported_closure_claims':sum(bool(r.get('unsupported_closure_claim')) for r in results),
        'invalid_case_submissions':sum(1 for r in results if not r.get('case_submission_valid',False)),
        'within_budget':sum(bool(r.get('within_budget')) for r in results),
    }
    out={'audit_version':'sdpe-beb-auditor-v0.1.2-dataset-closure','integrity':integrity,'summary':summary,'results':results}
    txt=json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+'\n'
    if a.out: Path(a.out).write_text(txt,encoding='utf-8')
    print(txt,end='')

if __name__=='__main__': main()
