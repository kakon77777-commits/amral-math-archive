#!/usr/bin/env python3
from __future__ import annotations
# Exact symbolic survivor replay for the current SDPE-BEB Boolean predicate class.
# State = GF(2) affine system + finite forbidden points. No 2^n universe materialization.

class GF2State:
    def __init__(self,n):
        self.n=n; self.rows={}  # pivot -> (mask,rhs)
        self.inconsistent=False
        self.forbidden=set()
    def copy(self):
        z=GF2State(self.n); z.rows=dict(self.rows); z.inconsistent=self.inconsistent; z.forbidden=set(self.forbidden); return z
    def add_row(self,mask,rhs):
        if self.inconsistent: return
        mask=int(mask); rhs=int(rhs)&1
        while mask:
            p=mask.bit_length()-1
            if p in self.rows:
                m,r=self.rows[p]; mask^=m; rhs^=r
            else:
                # New pivot. Eliminate this pivot from existing rows for canonical RREF-like state.
                self.rows[p]=(mask,rhs)
                for q,(m,r) in list(self.rows.items()):
                    if q!=p and ((m>>p)&1): self.rows[q]=(m^mask,r^rhs)
                return
        if rhs: self.inconsistent=True
    def add_pred(self,p):
        k=p['kind']
        if k=='true': return
        if k=='false': self.inconsistent=True; return
        if k=='bit_equals':
            v=int(p['var']); val=int(p['value'])&1
            if v<0: raise ValueError('negative var')
            if v>=self.n:
                if val: self.inconsistent=True
                return
            self.add_row(1<<v,val); return
        if k=='parity':
            m=0
            for v in p['vars']:
                v=int(v)
                if v<0: raise ValueError('negative var')
                if v<self.n: m ^= 1<<v
            self.add_row(m,p['value']); return
        if k=='mask_equals':
            mask=int(p['mask']); pat=int(p['pattern']); i=0
            if mask<0 or pat<0: raise ValueError('negative mask/pattern')
            valid=(1<<self.n)-1
            if pat & ~mask or pat & ~valid:
                self.inconsistent=True; return
            mask &= valid; pat &= valid
            while mask:
                if mask&1: self.add_row(1<<i,(pat>>i)&1)
                i+=1; mask>>=1
            return
        if k=='forbid_assignment': self.forbidden.add(int(p['assignment'])); return
        raise ValueError(k)
    def satisfies_affine(self,a):
        if self.inconsistent: return False
        for m,r in self.rows.values():
            if ((a&m).bit_count()&1)!=r: return False
        return True
    @property
    def rank(self): return len(self.rows)
    def survivor_size(self):
        if self.inconsistent: return 0
        base=1<<(self.n-self.rank)
        q=sum(1 for a in self.forbidden if 0<=a<(1<<self.n) and self.satisfies_affine(a))
        return max(0,base-q)
    def closed(self): return self.survivor_size()==0


def total_cost(a): return sum(float(v) for v in a.get('cost',{}).values())


def symbolic_replay(t,selected_actions, common_module, strict=True):
    amap=common_module.action_map(t); unlocked=set(t['initially_unlocked']); used=set(); state=GF2State(t['n_vars']); trace=[]; cost=0.0
    for step,aid in enumerate(selected_actions,1):
        if aid not in amap: raise ValueError(f'unknown action {aid}')
        if aid in used: raise ValueError(f'repeated action {aid}')
        if aid not in unlocked: raise ValueError(f'locked action {aid}')
        a=amap[aid]
        if any(x not in used for x in a.get('requires',[])): raise ValueError(f'prerequisites not satisfied for {aid}')
        ok,ci=common_module.verify_action_certificate(t,a)
        if strict and not ok: raise ValueError(f'certificate failed {aid}: {ci}')
        before=state.survivor_size(); p=common_module.action_predicate(t,a)
        if p is not None and ok: state.add_pred(p)
        after=state.survivor_size(); used.add(aid); unlocked.update(a.get('unlocks',[])); c=total_cost(a); cost+=c
        trace.append({'step':step,'action_id':aid,'type':a['action_type'],'before':before,'after':after,'eliminated':before-after,'certificate_ok':ok,'certificate_mode':ci.get('mode'),'model_cost':c})
        if after==0: break
    step_ok=len(selected_actions)<=t['budget']; cost_ok=cost<=t['cost_budget']+1e-12
    return {'closed':state.closed(),'final_survivor_size':state.survivor_size(),'trace':trace,'model_cost':cost,'step_budget_ok':step_ok,'cost_budget_ok':cost_ok,'within_budget':step_ok and cost_ok,'used':sorted(used),'unlocked':sorted(unlocked),'rank':state.rank,'forbidden_count':len(state.forbidden)}
