# Proof-Space Search Complexity Theorem — v0.6

## 1. Setup

Fix a finite proof grammar $\mathcal G_t$ for task $t$. A black-box verifier query reveals whether a candidate is a budget-valid closed proof and, when eligible, its verifier-derived quality $Q(\Pi)$.

Let

$$
Q_t^*=\min_{\Pi\in\mathcal G_t}Q(\Pi).
$$

## 2. Black-box certification lower bound

Suppose a search procedure has queried a strict subset

$$
S\subsetneq\mathcal G_t
$$

and possesses no sound lower-bound information about the unqueried candidates beyond black-box verifier access.

Then, in the worst case, it cannot certify that its current incumbent is globally optimal.

### Proof

Choose any unqueried candidate

$$
\Pi'\in\mathcal G_t\setminus S.
$$

The observed query transcript is compatible with two black-box worlds: one in which $\Pi'$ is invalid or no better than the incumbent, and another in which $\Pi'$ is a valid proof with strictly smaller quality. Since the transcript is identical in both worlds, no exact optimality certificate follows from the transcript alone. Therefore worst-case exact certification requires querying every candidate not eliminated by additional sound information. Hence

$$
C_{\mathrm{blackbox}}(t)=|\mathcal G_t|
$$

in the worst case.

## 3. Lower-bound collapse of certification cost

Assume a sound grammar-relative lower bound

$$
Q(\Pi)\ge_{\mathrm{lex}}LB_t
$$

for every eligible candidate $\Pi\in\mathcal G_t$.

If a verified candidate $\widehat\Pi$ satisfies

$$
Q(\widehat\Pi)=LB_t,
$$

then

$$
Q(\widehat\Pi)=Q_t^*,
$$

and exact optimality is certified immediately.

For the v0.6 grammar, the proved lower-bound vectors are

$$
LB_A=(2,1,4,1,1,145),
$$

$$
LB_B=(5,4,15,2,1,500),
$$

and

$$
LB_C=(6,5,18,3,1,615).
$$

The compact constructors attain these vectors. Thus the included bound-guided policy has

$$
D_A(t)=C_A(t)=1
$$

for all 30 UNSAT tasks in this release.

## 4. Co-optimal output-size distinction

Exact certification of **one** optimal proof is not the same as enumerating **all** optimal proofs.

In the declared grammar, the number of distinct optimal proofs is

$$
M_A=1,
$$

$$
M_B=5775,
$$

and

$$
M_C=5775.
$$

Any explicit enumeration of all optimal proofs has output-size lower bound

$$
\Omega(M_t).
$$

Therefore lower-bound reasoning can collapse one-optimum certification to one verifier query while all-optima enumeration remains large.

## 5. Scope

These are grammar-relative search-complexity statements. They do not claim lower bounds on unrestricted theorem proving, human cognition, or hidden AI chain-of-thought.
