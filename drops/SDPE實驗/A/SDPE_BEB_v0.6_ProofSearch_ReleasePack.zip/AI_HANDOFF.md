# AI Handoff — SDPE-BEB v0.6

Current frontier: proof-space search complexity under an auditable verifier-query model.

Do not infer participant hidden reasoning cost from the final proof. Keep the following layers separate:

1. proof correctness authority;
2. verifier-derived proof quality;
3. declared proof-space grammar;
4. mediated verifier-query search telemetry;
5. benchmark-owned baseline expansion telemetry.

Main theorem source: `PROOF_SEARCH_COMPLEXITY_THEOREM.md`.
Main experiment: `search_reports/SEARCH_EXPERIMENT_REPORT.json`.

Natural next frontier: v0.7 adaptive proof-space generation where the grammar itself is not fixed in advance, with sound proposal typing and search-space growth accounting.
