# Anytime and Pareto Evaluation — v0.6

For a search run, record the incumbent after every verifier query:

$$
(b,Q_A(t,b)).
$$

A point $(b_1,Q_1)$ dominates $(b_2,Q_2)$ when

$$
b_1\le b_2
$$

and

$$
Q_1\le_{\mathrm{lex}}Q_2,
$$

with at least one strict inequality.

The nondominated points form the anytime Pareto frontier.

This keeps search effort and proof quality separate instead of collapsing them into a single arbitrary scalar score.

For the included architecture-order baseline, the canonical budget curves are:

- Track A: three successive incumbent levels before the compact optimum.
- Track B: one larger proof followed by the compact optimum.
- Track C: verbose proof, legacy proof, then compact optimum.

The bound-guided policy reaches the grammar-relative optimum in one verifier query and therefore dominates these specific baselines. This is an experimental statement about the included policies, not a universal claim about all search algorithms.
