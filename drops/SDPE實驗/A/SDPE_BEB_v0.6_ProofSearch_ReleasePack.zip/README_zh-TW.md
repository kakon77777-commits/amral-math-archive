# SDPE-BEB v0.6 — 證明空間搜尋複雜度

v0.6 保留 v0.5 的 proof-quality authority，新增一層可稽核的搜尋複雜度模型。

核心區分是：找到最優證明，與證明「它確實是最優」不是同一件事。

本版正式定義有限 proof-space grammar、verifier-query complexity、anytime quality、Pareto frontier、代表性完整枚舉，以及 lower-bound certificate 如何把 exact optimality certification 從整個候選空間壓縮到一次 verifier query。

這些數字只描述 benchmark-owned search model；不把 AI 的隱藏思考、Token、內部 chain-of-thought 或硬體時間冒充成可驗證量。
