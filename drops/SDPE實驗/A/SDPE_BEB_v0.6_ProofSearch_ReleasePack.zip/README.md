# SDPE-BEB v0.6 — Proof-Space Search Complexity

v0.6 retains v0.5 proof-quality authority and adds a controlled, auditable search-complexity layer.

The central distinction is between finding an optimal proof and certifying that it is optimal. The release defines a finite proof-space grammar, a verifier-query model, anytime quality curves, Pareto evaluation, representative exhaustive enumeration, and a theorem showing how sound lower bounds collapse exact optimality certification cost.

No claim is made that final proof artifacts reveal hidden AI reasoning cost.
