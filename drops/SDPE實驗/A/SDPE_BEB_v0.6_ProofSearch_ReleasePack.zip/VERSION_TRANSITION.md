# Version Transition — v0.5 to v0.6

v0.5 asked which valid proof is structurally better.

v0.6 asks how much controlled proof-space search is required to find and certify such a proof.

New objects:

$$
\mathcal G_t,
$$

$$
D_A(t),
$$

$$
C_A(t),
$$

and

$$
Q_A(t,b).
$$

The key conceptual repair is that search cost is defined only under an auditable harness; it is not reconstructed from a final answer.
