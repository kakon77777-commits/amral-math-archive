# Authority Invariants — v0.6

The v0.5 proof-authority invariants remain mandatory.

Additional v0.6 search invariants:

1. Search telemetry never substitutes for proof correctness.
2. Participant self-reported hidden reasoning cost is non-authoritative.
3. A verifier-query is counted only when the canonical verifier evaluates a complete candidate proof DAG.
4. Search-complexity claims name the exact proof-space grammar version.
5. Grammar-relative lower bounds must be proved independently of search-policy output.
6. Discovery complexity and optimality-certification complexity are reported separately.
7. All-optima enumeration claims include explicit candidate-space and co-optimal multiplicity counts.
