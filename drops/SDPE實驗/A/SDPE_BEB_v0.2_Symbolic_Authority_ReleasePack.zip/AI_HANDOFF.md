# AI Handoff — SDPE-BEB v0.2

## Canonical status

v0.2 should be treated as an authority-layer release over the v0.1.1 neutral 60-task corpus. Do not reintroduce enumerative replay into Public or Oracle certification code.

## Non-negotiable invariants

- Public/reveal replay = symbolic affine system plus finite exclusions.
- Full Dev enumeration = reference regression only.
- Manifest exact task IDs anchor dataset completeness.
- Exactly one oracle opening and one submission per manifest task.
- Routes end at first closure; trailing actions are invalid.
- Certified counts are dataset-gated.
- Structural certificates remain the only cut proof authority.

## Next mathematical frontier

The next benchmark version should increase discovery hardness without weakening the verifier. Candidate direction: hide route salience while retaining polynomially checkable certificate objects; e.g. larger affine modules, multiple equivalent derived lemmas, decoy dependency footprints, and participant-proposed certificate objects rather than pre-listed closure lemmas.
