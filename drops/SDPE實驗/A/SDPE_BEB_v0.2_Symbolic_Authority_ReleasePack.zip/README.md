# SDPE-BEB v0.2 Symbolic Authority Release Pack

This release promotes the neutral benchmark's exact symbolic state to canonical verifier authority and closes the remaining dataset-level integrity boundary from v0.1.2.

Artifacts:

- `SDPE_BEB_NeutralVariant_Public_v0.2.zip` — participant bundle; no oracle and no enumerative reference engine.
- `SDPE_BEB_NeutralVariant_Oracle_v0.2.zip` — reveal bundle; symbolic auditor plus version-bound openings.
- `SDPE_BEB_NeutralVariant_Full_Dev_v0.2.zip` — complete research/development bundle including enumerative differential reference tests.
- `SDPE_BEB_v0.2_RELEASE_REPORT.json` — machine-readable release summary.

Canonical mathematical invariant:

$$
\Omega=L(A,b)\setminus E,
$$

with exact cardinality

$$
|\Omega|=2^{n-\operatorname{rank}(A)}-|E\cap L(A,b)|
$$

for a consistent affine system.
