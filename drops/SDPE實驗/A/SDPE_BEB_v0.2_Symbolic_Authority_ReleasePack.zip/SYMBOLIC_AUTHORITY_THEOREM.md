# Exact Symbolic Replay Theorem — SDPE-BEB v0.2

## Theorem

Let the initial Boolean universe be $\Omega_0=\mathbb F_2^n$. Consider any finite sequence of verified cuts whose predicates are drawn from:

- affine bit equations;
- affine parity equations;
- coordinate-mask equalities;
- singleton exclusions;
- `true` and `false`.

Then after every prefix $k$ there exist an affine system $A_kx=b_k$ and a finite set $E_k\subseteq\mathbb F_2^n$ such that the exact enumerative survivor set equals

$$
\Omega_k=\{x:A_kx=b_k\}\setminus E_k.
$$

If $A_kx=b_k$ is inconsistent, $|\Omega_k|=0$. Otherwise, with $r_k=\operatorname{rank}(A_k)$,

$$
|\Omega_k|=2^{n-r_k}-|E_k\cap\{x:A_kx=b_k\}|.
$$

## Proof

Proceed by induction on the route prefix. The empty prefix has $A_0$ empty and $E_0=\varnothing$. An affine bit/parity cut intersects the current affine set with one affine hyperplane, which is represented by appending one row to $A_kx=b_k$. A mask equality is the conjunction of finitely many coordinate equations and is therefore the same operation repeated finitely many times. A singleton exclusion removes exactly one point and is represented by inserting that point into $E_k$. `true` changes nothing; `false` makes the affine system inconsistent. Therefore the representation is exact after every prefix.

For a consistent affine system over $\mathbb F_2$, rank-nullity gives exactly $2^{n-r_k}$ affine solutions. Removing the distinct forbidden points that lie in that affine solution set gives the stated cardinality. QED.

## Complexity consequence

For the current certificate and predicate class, proof replay requires polynomial-time $\mathbb F_2$ row operations plus membership checks for the finite exclusion set. The canonical verifier does not require $2^n$ universe materialization. This statement concerns replay/certificate verification; private benchmark-generation code may still use exhaustive enumeration as a reference oracle.
