# Canonical Authority Invariants

1. **Certificate invariant** — every cut predicate is accepted only after its structural certificate verifies.
2. **Bridge invariant** — a bridge must have null predicate source and an empty `route_bridge` certificate.
3. **Symbolic invariant** — canonical survivor state is exact and never obtained by public full-universe enumeration.
4. **Termination invariant** — a submitted route ends at its first closure.
5. **Budget invariant** — all submitted actions are validated and charged; step and exact-decimal cost budgets must both hold.
6. **Witness invariant** — a declared SAT counterexample is checked against every premise.
7. **Manifest invariant** — the exact public task set is committed by the Public Manifest and its dataset fingerprint.
8. **Cardinality invariant** — exactly one submission and one oracle opening exist for each manifest task ID.
9. **Certification invariant** — failure of any dataset-level integrity gate forces all official `certified_*` values to zero.
10. **Reference separation** — enumerative code is regression evidence only and cannot be imported by Public or Oracle authority tools.
