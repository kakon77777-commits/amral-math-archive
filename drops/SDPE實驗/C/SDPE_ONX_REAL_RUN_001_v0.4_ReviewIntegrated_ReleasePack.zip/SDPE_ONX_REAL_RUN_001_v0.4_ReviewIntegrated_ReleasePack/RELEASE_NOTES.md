# SDPE × Observer-Network REAL RUN 001 — v0.4 Review-Integrated Release Pack

日期：2026-08-14

## Release purpose

本包將 v0.3 pre-real-run review packet 與一次獨立 hostile AI review 整合成 v0.4。

v0.4 的主要目標不是增加 protocol 複雜度，而是把 REAL RUN 001 真正能辨識的 causal estimands、可觀察 metrics、blindness boundary 與 run-integrity requirements 說清楚。

## Most important changes

1. $M^-$ 改成 matched-neutral control artifact。
2. H3 改寫為 $ON_{pkg}$ vs $SA_{pkg}$ package effect，不再把它直接寫成 pure role-separation effect。
3. $IRR$ 改為 pre-gate semantic reopening metric。
4. EER 改為可觀察的 $EER_t^{\mathrm{declared}}$。
5. FCR 必須與 FAR / TCR / Coverage 一起報告。
6. canonical invalidation 加入 exogeneity rule。
7. 新增 Episode Manifest precommit，防 silent rerun / selective retention。
8. 新增 frozen route ontology / semantic equivalence classes。
9. REAL RUN 001 明確定位為 instrumented causal pilot。
10. 新增 semantic-transfer discriminator，用來區分 literal negative cache 與較強 epistemic enclosure。

## Files

- `SDPE_ONX_REAL_RUN_001_AI_REVIEW_PACKET_v0.4.md` — v0.4 canonical review packet source。
- `INDEPENDENT_AI_REVIEW_ROUND_2026-08-14.md` — 本輪獨立審查完整紀錄。
- `CHANGELOG_v0.3_to_v0.4.md` — 變更摘要。
- `provenance/SDPE_ONX_REAL_RUN_001_AI_REVIEW_PACKET_v0.3_original.md` — 原始 v0.3，不覆寫。
- `provenance/v0.3_to_v0.4.diff` — machine-generated unified diff。
- `templates/episode_manifest.schema.json` — Episode Manifest JSON Schema。
- `templates/episode_manifest.template.jsonl` — 最小 manifest record template。
- `templates/route_ontology.schema.json` — route ontology JSON Schema。
- `templates/route_ontology.template.json` — route ontology template。
- `templates/memory_artifact.schema.json` — memory / matched-neutral artifact shared schema。
- `templates/PREREGISTRATION_MINIMAL_TEMPLATE.md` — minimal preregistration template。
- `tools/verify_release.py` — UTF-8 / math delimiter / JSON / schema / checksum verifier。
- `validation.json` — release-level source validation result。
- `CHECKSUMS.sha256` — release payload SHA-256 checksums。

## Authority boundary

本包不包含 hidden oracle，也不授予 proof authority。

`v0.4` 是 design-level repair，不代表新增 runtime controls 已完成 preflight，更不代表 H1 / H2 / H3a 已被 empirical data 支持。

開始 REAL RUN 001 前，必須完成 v0.4 文件第 29 節 Go / No-Go Checklist。
