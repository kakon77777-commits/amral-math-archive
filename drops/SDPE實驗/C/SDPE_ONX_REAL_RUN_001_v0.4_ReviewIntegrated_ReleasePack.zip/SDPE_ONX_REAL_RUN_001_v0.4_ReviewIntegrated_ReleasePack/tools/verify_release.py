#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def check_utf8(path: Path, errors):
    raw = path.read_bytes()
    if b'\x00' in raw:
        errors.append(f'NUL byte: {path.relative_to(ROOT)}')
    try:
        raw.decode('utf-8')
    except UnicodeDecodeError as e:
        errors.append(f'UTF-8 decode failure: {path.relative_to(ROOT)}: {e}')


def check_math_markdown(path: Path, errors, warnings):
    text = path.read_text(encoding='utf-8')
    if '\\[' in text or '\\]' in text or '\\(' in text or '\\)' in text:
        errors.append(f'Forbidden alternate math delimiter in {path.relative_to(ROOT)}')
    if text.count('$$') % 2:
        errors.append(f'Unbalanced display-math delimiter in {path.relative_to(ROOT)}')

    # Remove display blocks before checking inline $ pairs.
    tmp = re.sub(r'\$\$.*?\$\$', '', text, flags=re.S)
    # Ignore escaped dollar signs.
    tmp = tmp.replace('\\$', '')
    if tmp.count('$') % 2:
        errors.append(f'Unbalanced inline-math delimiter in {path.relative_to(ROOT)}')

    # Guard against accidental unicode-escape source transport.
    if re.search(r'\\u[0-9a-fA-F]{4}', text):
        warnings.append(f'Literal unicode escape sequence found in {path.relative_to(ROOT)}')


def check_json(path: Path, errors):
    try:
        json.loads(path.read_text(encoding='utf-8'))
    except Exception as e:
        errors.append(f'JSON parse failure: {path.relative_to(ROOT)}: {e}')


def check_jsonl(path: Path, errors):
    for i, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            json.loads(line)
        except Exception as e:
            errors.append(f'JSONL parse failure: {path.relative_to(ROOT)}:{i}: {e}')


def check_schemas(errors):
    try:
        import jsonschema
    except Exception as e:
        errors.append(f'jsonschema unavailable: {e}')
        return

    tdir = ROOT / 'templates'
    manifest_schema = json.loads((tdir / 'episode_manifest.schema.json').read_text(encoding='utf-8'))
    manifest_record = json.loads((tdir / 'episode_manifest.template.jsonl').read_text(encoding='utf-8'))
    route_schema = json.loads((tdir / 'route_ontology.schema.json').read_text(encoding='utf-8'))
    route_record = json.loads((tdir / 'route_ontology.template.json').read_text(encoding='utf-8'))

    try:
        jsonschema.validate(manifest_record, manifest_schema)
    except Exception as e:
        errors.append(f'Episode manifest template fails schema: {e}')
    try:
        jsonschema.validate(route_record, route_schema)
    except Exception as e:
        errors.append(f'Route ontology template fails schema: {e}')


def check_checksums(errors):
    cpath = ROOT / 'CHECKSUMS.sha256'
    if not cpath.exists():
        errors.append('CHECKSUMS.sha256 missing')
        return
    for line in cpath.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        digest, rel = line.split('  ', 1)
        p = ROOT / rel
        if not p.exists():
            errors.append(f'Checksum target missing: {rel}')
            continue
        actual = sha256(p)
        if actual != digest:
            errors.append(f'Checksum mismatch: {rel}')


def main():
    errors = []
    warnings = []
    files = [p for p in ROOT.rglob('*') if p.is_file() and p.name != 'CHECKSUMS.sha256']

    for p in files:
        check_utf8(p, errors)
        if p.suffix.lower() == '.md':
            check_math_markdown(p, errors, warnings)
        elif p.suffix.lower() == '.json':
            check_json(p, errors)
        elif p.suffix.lower() == '.jsonl':
            check_jsonl(p, errors)

    check_schemas(errors)
    if (ROOT / 'CHECKSUMS.sha256').exists():
        check_checksums(errors)

    result = {
        'root': ROOT.name,
        'files_checked': len(files),
        'errors': errors,
        'warnings': warnings,
        'status': 'PASS' if not errors else 'FAIL'
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == '__main__':
    sys.exit(main())
