# REAL RUN 001 — Minimal Preregistration Template

## Protocol

- Protocol version:
- Protocol SHA-256:
- Benchmark ID:
- Benchmark SHA-256:
- Hidden oracle SHA-256 commitment:
- Route ontology SHA-256:
- Invalidation schedule SHA-256:
- Episode Manifest SHA-256:

## Primary Hypothesis Family

$$
\mathcal H_P
=
\{H1,H2,H3a\}.
$$

### H1

Primary endpoint:

$$
L_{\mathrm{repair}}^{\mathrm{prop}}.
$$

Contrast:

$$
M^+
\text{ vs }
M^-.
$$

### H2

Primary endpoint:

$$
IRR_{\sim}^{\mathrm{pre}}.
$$

Contrast:

$$
M^+
\text{ vs }
M^-.
$$

### H3a

Primary endpoint family:

$$
(
FCR,
FAR,
TCR,
Coverage
).
$$

Contrast:

$$
ON_{pkg}
\text{ vs }
SA_{pkg}.
$$

Interpretation guardrail: this is a system-package effect, not a pure role-separation effect.

## Pilot Status

REAL RUN 001 first 16 cells are pilot only.

## Resource Envelope

- Total model-generated token budget per episode:
- Total tool-call budget per episode:
- Maximum raw proposal count per episode:
- Wall time policy:

## Sampling

- Model IDs / versions:
- Temperature / sampling parameters:
- Seed policy:
- Run-order policy:

## Multiplicity Policy for Later Confirmatory Round

Choose one before confirmatory execution:

- hierarchical testing;
- Holm correction;
- other explicitly documented policy.

## Deviations

All deviations, crashes, aborts and retries must remain in the run manifest and observer sidecar ledger.
