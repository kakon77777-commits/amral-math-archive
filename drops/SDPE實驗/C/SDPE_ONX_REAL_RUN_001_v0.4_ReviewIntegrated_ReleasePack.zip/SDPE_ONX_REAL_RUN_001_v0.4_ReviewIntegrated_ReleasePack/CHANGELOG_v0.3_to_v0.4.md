# CHANGELOG — SDPE × Observer-Network REAL RUN 001

## v0.4 — 2026-08-14

來源：v0.3 independent review packet + independent AI hostile review round。

### Causal design

- H3 改為 $ON_{pkg}$ vs $SA_{pkg}$ system-package estimand。
- 明確聲明 pure role-separation effect 不由原始 Phase A 直接辨識。
- Phase A 正式標記為 instrumented causal pilot。
- 新增 frozen total resource envelope：token / tool / proposal budget。
- 新增 run-order / model-version / sampling-policy 記錄規則。

### Memory ablation

- $M^-$ 從空白附加內容改為 matched-neutral control artifact。
- 新增 artifact schema / token bracket / wrapper matching。
- 新增 failure-memory compiler 與 neutral compiler 的 hidden-oracle permission firewall。
- 新增 deterministic negative-cache diagnostic baseline 規格，但不強制擴張 primary $2\times2$ pilot。

### Route identity and IRR

- primary IRR 改為 pre-gate semantic route reopening rate：$IRR_{\sim}^{\mathrm{pre}}$。
- 新增 raw proposal capture ordering。
- 新增 frozen route ontology、canonical route signature、semantic equivalence classes。
- 新增 ambiguous-route data-quality metric。

### Epistemic measurement

- 原 EER 改為可觀察的 $EER_t^{\mathrm{declared}}$。
- route state 固定為 admissible / invalid / unknown。
- 明確區分 declared-state hysteresis 與不可直接觀察的完整內部 epistemic state。

### False certification metrics

- 保留 FCR。
- 新增 FAR、TCR、Coverage。
- 明確規定零 accepted certificate 時 $FCR=\mathrm{undefined}$。
- 禁止只靠極端 abstention 得到表面低 FCR。

### Invalidation and run integrity

- canonical invalidation 加入 exogeneity 要求。
- 新增 Episode Manifest precommit。
- 新增 crash / abort / retry 永久留痕規則。
- 新增 hash 不能單獨防 selective retention 的明示說明。

### Blindness

- hidden-oracle prohibition 擴張到 memory compiler、neutral compiler、Meta-Observer。
- 新增 derived-artifact taint rule。
- 新增 filesystem / cache / provider-memory residual-confound 檢查。
- 新增 arm-blind filename / metadata / wrapper 要求。

### Statistics and interpretation

- 16 Phase-A cells 明確標記為 pilot only。
- 正式 repeats 留待 pilot variance 後 power simulation。
- primary hypothesis family 明確為 H1 / H2 / H3a。
- H4 semantic-transfer 為 exploratory。
- 新增 causal interpretation guardrails，防止 package effect 被寫成 pure role effect。

### Operational additions

- 新增 Go / No-Go Checklist。
- 新增 machine-readable Episode Manifest schema/template。
- 新增 route ontology schema/template。
- 新增 minimal preregistration template。
- 新增 release validation / checksum / diff。

## v0.3

保留原始檔於 `provenance/`，不覆寫。
