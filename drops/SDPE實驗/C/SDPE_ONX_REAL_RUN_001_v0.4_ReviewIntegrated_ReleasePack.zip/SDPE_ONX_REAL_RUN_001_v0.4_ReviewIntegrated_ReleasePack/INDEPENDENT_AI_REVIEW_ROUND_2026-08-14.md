# Independent AI Review — SDPE × Observer-Network REAL RUN 001

日期：2026-08-14  
被審文件：`SDPE_ONX_REAL_RUN_001_AI_REVIEW_PACKET_v0.3`  
審查目的：在 REAL RUN 001 前，針對 causal identifiability、metric validity、blindness、route identity、run integrity 與 extrapolation risk 進行 hostile review。  
結果：已整合至 `SDPE_ONX_REAL_RUN_001_AI_REVIEW_PACKET_v0.4.md`。

---

## A. Verdict

**MAJOR DESIGN FIXES REQUIRED** for causal interpretation of the v0.3 design.

這不是否定 runtime / preflight 骨架。v0.3 已經正確處理多個高風險污染來源，包括 fresh repair session、proof / observer authority separation、hidden oracle post-freeze scoring 與 canonical invalidation 原則。

問題在於：若 REAL RUN 001 要把差異解讀成 failure-memory content effect 或純 role-separation effect，v0.3 仍有幾個未隔離的替代解釋。

v0.4 完成必要 design repair 後，目標 verdict 可上升為：

**READY FOR PILOT**，前提是 v0.4 新增 runtime controls 重新通過 preflight。

---

## B. Critical Issues

### 1. H3 尚未 isolate 純 role-separation effect

v0.3 Phase A 已排除 model heterogeneity，但仍同時改變：

$$
\boxed{
\text{role separation}
+
\text{agent count}
+
\text{independent sampling}
+
\text{context independence}
+
\text{communication topology}
}.
$$

因此：

$$
FCR^{ON}<FCR^{SA}
$$

只能支持 Observer-Network system package 相對於 Single-Agent package 的差異，不能直接歸因於 role separation。

**修正：** v0.4 將 H3 改寫為 H3a package effect，並把 pure role-separation effect 留給後續 agent-count × role-separation decomposition。

### 2. 原始 EER 不是充分可觀察量

$$
EER_t
=
1-
\frac{|\mathcal A_t^{AI}|}{|\mathcal A_0^{AI}|}
$$

中的完整內部 admissible epistemic space 無法由 ledger 直接讀取。

**修正：** v0.4 改用 frozen finite route universe 與 structured declared state：

$$
\{
\text{admissible},
\text{invalid},
\text{unknown}
\},
$$

並將 primary observable 明確命名為：

$$
EER_t^{\mathrm{declared}}.
$$

### 3. v0.3 的 $M^+$ / $M^-$ 可能只測到「額外 structured prompt」

若：

$$
M^+
=
\text{failure-memory artifact}
$$

而：

$$
M^-
=
\varnothing,
$$

則 memory content 與 prompt length、format、attention cue 混雜。

**修正：** v0.4 的 $M^-$ 改成 matched-neutral artifact，同 schema、同 token bracket、同 wrapper，但沒有 failure identity 或 validity information。

### 4. IRR 可能被 deterministic blacklist 機械性做低

若 IRR 在 schema gate / blacklist 之後才計算，則：

$$
IRR\downarrow
$$

不代表 Agent search policy 改變。

**修正：** v0.4 primary metric 改為 raw proposal capture 後、deterministic gate 前的：

$$
IRR_{\sim}^{\mathrm{pre}}.
$$

並保留 deterministic negative-cache baseline 作 diagnostic extension。

### 5. Route identity 不能靠字串相等

語義等價 route 可以用不同自然語言表述重新出現。

**修正：** v0.4 要求 run 前 freeze route ontology：

$$
\rho(r)
=
(
\text{operators},
\text{dependencies},
\text{boundary assumptions},
\text{certificate class},
\text{target enclosure}
),
$$

以及 semantic equivalence relation：

$$
r_i\sim r_j.
$$

### 6. FCR 會被極端 abstention 操縱

若 ON 幾乎不 certify，單看：

$$
FCR
=
\frac{N_{\mathrm{false\ passed}}}{N_{\mathrm{passed}}}
$$

可能得到表面很漂亮的結果。

**修正：** v0.4 同時要求：

$$
FCR,
\quad
FAR,
\quad
TCR,
\quad
Coverage.
$$

且當：

$$
N_{\mathrm{passed}}=0,
$$

則：

$$
FCR=\mathrm{undefined}.
$$

### 7. Canonical invalidation 需要明確 exogeneity

只寫 deterministic / precommitted 還不夠；若 shock 的實際選擇依 Agent output 改變，仍可能內生。

**修正：** 優先使用：

$$
I_e
=
f(
\text{benchmark seed},
\text{predetermined event index}
).
$$

### 8. Hash 不防 selective retention

hash 可以防止留下來的 artifact 被修改，但不能防止不喜歡的 episode 被整個丟掉。

**修正：** v0.4 新增 complete Episode Manifest precommit，並要求 crash / abort / retry 也永久留痕。

### 9. Phase A 的 16 episodes 只能是 pilot

$$
4\text{ model families}
\times
4\text{ cells}
=
16
$$

可用來測 runtime、effect direction、variance 與 failure modes，但不是一般化推論的充分樣本。

真正 experimental unit 是 episode，不是 ON 內四個 Agent roles。

**修正：** v0.4 正式標記 REAL RUN 001 為 instrumented causal pilot；正式 repeats 由 pilot variance 再做 power simulation。

---

## C. Confound Matrix

| Factor | Possible confound | Recommended control |
|---|---|---|
| $M^+$ vs $M^-$ | 額外 tokens / attention | matched neutral artifact |
| $M^+$ | solution-adjacent leakage | memory compiler allow-list + oracle permission denial |
| $M^+$ | literal blacklist | pre-gate IRR + semantic transfer test |
| ON vs SA | Agent count | package-effect interpretation; later decomposition |
| ON vs SA | independent sampling | package-effect interpretation; later control |
| ON vs SA | token / tool advantage | frozen total resource envelope |
| invalidation | performance dependence | exogenous frozen invalidation function |
| repeated run | model / provider drift | model version record + frozen/randomized run order |
| IRR | paraphrase escape | frozen route ontology and equivalence classes |
| FCR | abstention | risk–coverage metrics |
| EER | latent-state inference | declared finite route-state metric |
| run retention | selective rerun | complete precommitted Episode Manifest |
| Meta-Observer | hidden intervention | preregister intervention policy and log every action |

---

## D. Metric Audit

### $PER$

**PASS WITH DEFINITION FIX.**

Primary measure $\mu$ 必須在 run 前 freeze；finite benchmark 優先用 deterministic combinatorial measure。

### $EER$

**MAJOR FIX.**

改為：

$$
EER_t^{\mathrm{declared}}
$$

並保留 invalid / unknown companion counts。

### $L_{\mathrm{repair}}$

**MINOR FIX.**

Primary 建議使用 raw repair proposal count；wall time 保留為 engineering secondary metric。

### $IRR$

**MAJOR FIX.**

必須同時滿足：

$$
\boxed{
\text{pre-gate}
+
\text{semantic canonicalization}
}.
$$

### $FCR$

**MAJOR FIX.**

保留 FCR，但必須和 FAR / TCR / Coverage 一起報告。

### $\sigma$

v0.3 operational definition 不足。

v0.4 將：

$$
W_t
$$

定義為 verification / audit stage generated tokens，將：

$$
D_t
$$

定義為 proposal / search stage generated tokens，形成：

$$
\sigma_t^{tok}
=
\frac{W_t}{D_t+W_t}.
$$

Tool allocation 另計，不混單位。

---

## E. Blindness Audit

除直接 hidden-oracle read 外，需特別檢查：

1. failure-memory compiler 是否曾讀 oracle；
2. neutral-artifact compiler 是否曾讀 oracle；
3. rollback error message 是否洩漏 hidden consequence；
4. validator diagnostics 是否帶 oracle-only information；
5. route ID 是否暗示 validity；
6. filename / path / metadata 是否洩漏 arm；
7. shared filesystem / cache / tool history；
8. provider-side persistent memory；
9. first-session derived summaries；
10. benchmark seed 是否可以反推出 ground truth；
11. scorer 是否在所有 run freeze 前寫回共享狀態；
12. aborted episode 是否能被靜默丟棄。

---

## F. Minimal Changes Required Before REAL RUN 001

1. H3 改成 architecture package estimand。
2. $M^-$ 使用 matched-neutral artifact。
3. IRR 改為 pre-gate semantic IRR。
4. freeze route ontology / fingerprints / equivalence classes。
5. 將 EER operationalize 為 declared finite route-state metric。
6. FCR 加 risk–coverage companion metrics。
7. commit exogenous invalidation schedule + complete Episode Manifest。
8. 正式標記 REAL RUN 001 為 pilot。

v0.4 已把以上八項寫回 protocol；但 runtime 尚需重新 preflight。

---

## G. Optional Improvements / Later Phase

### Deterministic Negative-Cache Baseline

比較：

$$
M^{AI\ trace}
\quad\text{vs}\quad
M^{cache}
\quad\text{vs}\quad
M^{neutral}.
$$

用來區分 AI failure-memory 與普通 negative cache。

### Role-Separation Decomposition

$$
\text{Agent Count}
\in
\{1,4\}
\times
\text{Role Separation}
\in
\{0,1\}.
$$

用來估 pure role effect。

### Anchoring Stress Test

未來可以加入少量已知錯誤的 failure-memory，測 persistent memory 是否造成 epistemic poisoning / fixation。

### Semantic Transfer Test

若 memory 只列出 $r_i$，但 Agent 同時避開未列出的 $r_j$，且：

$$
r_i\sim r_j,
$$

才開始有 evidence 超過 literal blacklist。

---

## Long-Range Claim Audit

長程命題：

$$
\boxed{
\text{Persistent verified failure traces can reduce the effective future
search space even when authoritative proof state rolls back.}
}
$$

### Weak version

REAL RUN 001 可以測：

$$
\text{failure traces reduce repeated invalid-route exploration / repair cost}.
$$

### Strong version

若要支持較強 semantic epistemic enclosure，至少需要：

$$
IRR_{\sim}^{M^+}
<
IRR_{\sim}^{M^-},
$$

$$
L_{\mathrm{repair}}^{M^+}
<
L_{\mathrm{repair}}^{M^-},
$$

且：

$$
Coverage^{M^+}
\not\ll
Coverage^{M^-},
$$

以及未直接列入 memory 的 semantic-equivalent dead routes 也顯著減少。

如果只有 exact-route recurrence 下降，最保守結論仍是：

$$
\boxed{
\text{persistent negative cache effect}.
}
$$

---

## Final Review Position

這個研究已從「多 AI 是否比較會糾錯」推進到接近可反駁的實驗框架。

下一個真正需要分辨的不是單純：

$$
\text{memory helps or not},
$$

而是：

$$
\boxed{
\text{extra prompt}
\neq
\text{deterministic cache}
\neq
\text{semantic epistemic enclosure}.
}
$$

v0.4 的主要工作，就是把這三層拆開，並禁止 REAL RUN 001 對目前不能辨識的純 role-separation effect 或未知數學外推做過度宣稱。
