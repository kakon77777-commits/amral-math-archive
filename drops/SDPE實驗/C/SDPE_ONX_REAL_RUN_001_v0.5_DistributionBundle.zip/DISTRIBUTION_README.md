# SDPE × ONX REAL RUN 001 v0.5 — Distribution Guide

## Packages

1. `SDPE_ONX_REAL_RUN_001_v0.5_MASTER_OPERATOR_ONLY.zip`
   - Complete source, benchmark, private oracle, evaluator semantic map, operator future state, scorer, tests and provenance.
   - **Never mount this ZIP directly into an Agent session.**

2. `SDPE_ONX_REAL_RUN_001_v0.5_PUBLIC_RUNTIME_KIT.zip`
   - Public protocol/runtime development resources and prebuilt first-closure role bundles.
   - Contains no hidden oracle, evaluator semantic map, operator-only repair state, or future invalidation schedule.
   - Still do not dump the whole kit into a model context; mount only the role/phase bundle needed by the controller.

3. `SDPE_ONX_REAL_RUN_001_v0.5_OPERATOR_PRIVATE.zip`
   - Controller/scorer custody resources: hidden oracle, semantic equivalence map, repair state, invalidation schedule and private-side tooling.
   - Never expose to Agents.

## Current status

Deterministic executable core: PASS.
Provider-connected REAL RUN 001: PENDING / data collection not yet authorized.

Mock examples are instrumentation fixtures only and are not empirical AI evidence.
