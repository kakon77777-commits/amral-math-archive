#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
from common import canon,sha_text,replay

def load_oracles(path):
    out={}
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        if line.strip():
            x=json.loads(line); out[x['task_id']]=x
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--tasks-dir',required=True); ap.add_argument('--oracles',required=True); ap.add_argument('--submissions',required=True); ap.add_argument('--out')
    a=ap.parse_args(); oracles=load_oracles(a.oracles); results=[]
    for line in Path(a.submissions).read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        s=json.loads(line); task=json.loads((Path(a.tasks_dir)/f"{s['task_id']}.json").read_text(encoding='utf-8'))
        o=oracles[s['task_id']]
        commit=sha_text(canon(o['oracle'])+'|'+o['nonce'])
        commit_ok=commit==task['oracle_commitment']['commitment']==o['commitment']
        rr=replay(task,s['selected_actions'])
        predicted_closed=bool(s.get('declared_closed',rr['closed']))
        oracle_truth=o['oracle']['claim_truth']
        results.append({'task_id':s['task_id'],'family':task['family'],'commitment_ok':commit_ok,'route_closed':rr['closed'],'declared_closed':predicted_closed,'oracle_claim_truth':oracle_truth,'correct_closure_claim':predicted_closed==oracle_truth if predicted_closed else (not oracle_truth if s.get('declared_counterexample') else None),'false_closure':predicted_closed and not oracle_truth,'true_closure':predicted_closed and oracle_truth,'within_budget':len(s['selected_actions'])<=task['budget'],'steps':len(rr['trace']),'final_survivor_size':rr['final_survivor_size'],'model_cost':rr['model_cost']})
    summary={'cases':len(results),'commitment_failures':sum(not r['commitment_ok'] for r in results),'false_closures':sum(r['false_closure'] for r in results),'true_closures':sum(r['true_closure'] for r in results),'within_budget':sum(r['within_budget'] for r in results)}
    out={'summary':summary,'results':results}
    txt=json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+'\n'
    if a.out: Path(a.out).write_text(txt,encoding='utf-8')
    print(txt,end='')
if __name__=='__main__': main()
