#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json
from pathlib import Path


def canon(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def sha_text(s):
    return hashlib.sha256(s.encode('utf-8')).hexdigest()

def parity(x):
    return x.bit_count() & 1

def sat_pred(a:int,pred:dict)->bool:
    k=pred['kind']
    if k=='bit_equals': return ((a>>pred['var'])&1)==pred['value']
    if k=='mask_equals': return (a & pred['mask'])==pred['pattern']
    if k=='parity': return (sum((a>>v)&1 for v in pred['vars']) & 1)==pred['value']
    if k=='forbid_assignment': return a!=pred['assignment']
    if k=='false': return False
    if k=='true': return True
    raise ValueError(f'unknown predicate kind: {k}')

def premise_map(task):
    return {p['constraint_id']:p['predicate'] for p in task['premises']}

def action_map(task):
    return {a['action_id']:a for a in task['actions']}

def action_predicate(task, action):
    ps=action.get('predicate_source')
    if ps is None: return None
    if ps['kind']=='premise': return premise_map(task)[ps['constraint_id']]
    if ps['kind']=='inline': return ps['predicate']
    raise ValueError(ps)

def universe(task): return list(range(1<<task['n_vars']))
def apply_pred(survivor,pred): return [x for x in survivor if sat_pred(x,pred)]
def entailment_holds(task, deps, pred):
    pm=premise_map(task)
    dep_preds=[pm[d] for d in deps]
    for x in range(1<<task['n_vars']):
        if all(sat_pred(x,p) for p in dep_preds) and not sat_pred(x,pred):
            return False,x
    return True,None

def verify_action_certificate(task, action):
    if action['action_type']=='bridge':
        return True, {'mode':'bridge-no-proof-authority'}
    pred=action_predicate(task,action)
    cert=action['certificate']
    k=cert['kind']
    if k=='premise_identity':
        cid=cert['dependencies'][0]
        ok=(pred==premise_map(task)[cid])
        return ok, {'mode':k,'constraint_id':cid}
    if k=='finite_entailment':
        ok,w=entailment_holds(task,cert['dependencies'],pred)
        return ok, {'mode':k,'counterexample_to_entailment':w}
    return False, {'mode':'unknown-certificate-kind'}

def total_cost(action):
    return sum(float(v) for v in action.get('cost',{}).values())

def replay(task, selected_actions, *, strict=True):
    amap=action_map(task)
    unlocked=set(task['initially_unlocked'])
    used=set(); surv=universe(task); trace=[]
    total_model_cost=0.0
    for step,aid in enumerate(selected_actions,1):
        if aid not in amap: raise ValueError(f'unknown action {aid}')
        if aid in used: raise ValueError(f'repeated action {aid}')
        if aid not in unlocked: raise ValueError(f'locked action {aid}')
        act=amap[aid]
        if any(req not in used for req in act.get('requires',[])):
            raise ValueError(f'prerequisites not satisfied for {aid}')
        ok,cert_info=verify_action_certificate(task,act)
        if strict and not ok: raise ValueError(f'certificate failed for {aid}: {cert_info}')
        before=len(surv); pred=action_predicate(task,act)
        if pred is not None and ok: surv=apply_pred(surv,pred)
        after=len(surv)
        used.add(aid); unlocked.update(act.get('unlocks',[]))
        c=total_cost(act); total_model_cost+=c
        trace.append({'step':step,'action_id':aid,'type':act['action_type'],'certificate_ok':ok,'before':before,'after':after,'eliminated':before-after,'model_cost':c,'tags':act.get('tags',[])})
        if after==0: break
    return {'closed':len(surv)==0,'final_survivor_size':len(surv),'final_survivor':surv,'trace':trace,'model_cost':total_model_cost,'used':sorted(used),'unlocked':sorted(unlocked)}
