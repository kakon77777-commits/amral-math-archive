# SDPE-BEB v0.1 — Oracle Bundle

不要在 blind research run 結束前把本資料夾交給研究 Agent。

開封後使用：

```bash
python tools/audit_reveal.py \
  --tasks-dir public/tasks \
  --oracles private_oracle/oracle_answers.jsonl \
  --submissions submissions.jsonl \
  --out audit.json
```

Audit 會：

1. 重算每題 commitment；
2. 驗證 oracle opening；
3. 重播 participant selected actions；
4. 檢查 false closure / true closure / budget；
5. 對照 hidden ground truth。
