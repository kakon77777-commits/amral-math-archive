# SDPE-BEB v0.1.1 Release Pack

包含兩套：

1. **Audit Integrity Repair v0.1.1**：保持 v0.1 的題目骨架，修復 authority/audit/submission/packaging/budget contract。
2. **Neutral Variant v0.1.1**：真值平衡、公開 shape 平衡、中性 action IDs、移除答案型 tags，並用 GF(2) / unit-aggregate structural certificates 取代 decisive derived cut 的 full truth-table entailment verification。

盲測時只把對應的 `Public` ZIP 給研究 Agent；`Oracle` ZIP 分離保管。`Full_Dev` 只供開發與稽核。
