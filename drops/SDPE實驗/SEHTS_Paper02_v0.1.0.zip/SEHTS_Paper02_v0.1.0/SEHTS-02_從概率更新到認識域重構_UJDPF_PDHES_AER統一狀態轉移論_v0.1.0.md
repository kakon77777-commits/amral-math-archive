---
title: "從概率更新到認識域重構：UJDPF、PDHES 與 AER 的統一狀態轉移論"
english_title: "From Probability Updating to Epistemic-Domain Reconstruction: A Unified State-Transition Theory for UJDPF, PDHES, and Active Epistemic Reconstruction"
series: "自指認識與歷史痕跡研究系列"
series_english: "Self-Referential Epistemics and Historical Trace Series"
series_id: "SEHTS"
paper_id: "SEHTS-02"
author: "Neo.K"
organization: "EveMissLab"
version: "0.1.0"
status: "Research Draft / Bridge Paper"
date: "2026-08-14"
language: "zh-TW"
---

# 從概率更新到認識域重構

## UJDPF、PDHES 與 AER 的統一狀態轉移論

### From Probability Updating to Epistemic-Domain Reconstruction

**作者：** Neo.K  
**機構：** EveMissLab  
**系列：** 自指認識與歷史痕跡研究系列（SEHTS），Paper 02  
**版本：** v0.1.0  
**日期：** 2026-08-14

---

# 摘要

本文完成三條先前研究線的正式橋接：

1. UJDPF（Unified Judgment-Domain Probability Framework）；
2. PDHES（Probabilistic–Deterministic Hybrid Epistemic System）；
3. AER（Active Epistemic Reconstruction）。

UJDPF 處理概率陳述的型別問題：一個 probability object 必須位於明示 reference、scale、time、context 與 probability order 的判定結構中，跨域推論需要 transport witness。PDHES 則把 Agent 拆成 probabilistic generator、tools、external environment、persistent state、verifier 與 control policy，主張「概率 proposal」與「外部／確定性 judgment」具有不同 operational role。AER 更進一步讓 Agent 維持假說空間、主動選擇實驗、取得 fresh evidence，並重構未知 representation、semantics 與 judgment rules。SEHTS-01 又補上第四個缺口：一個實驗與反駁若要在長時研究中持續有效，必須形成可保存的 historical trace，而不能只存在於瞬時 context。

本文把四者統一成 **Epistemic–Probability State**：

$$
\boxed{
\mathcal S_t
=
(
\jmath_t,
\mathcal H_t,
P_t,
K_t,
G_t
).
}
$$

其中：

- $\jmath_t=(\rho_t,s_t,t,c_t)$：當前 judgment index；
- $\mathcal H_t$：當前 hypothesis space；
- $P_t\in\mathsf P(\mathcal H_t)$：對假說空間的一階 probability / belief state；
- $K_t$：evidence-backed canonical epistemic state；
- $G_t$：provenance / historical-trace graph。

Agent 可依目前狀態選擇 action：

$$
a_t\sim\pi_t(\cdot\mid\mathcal S_t),
$$

環境返回 observation：

$$
o_{t+1}
\sim
\mathcal E_{\Theta^\ast}
(
\cdot\mid a_t,\jmath_t
),
$$

verifier 產生：

$$
v_{t+1}
=
V_t(
\mathcal H_t,
a_t,
o_{t+1}
),
$$

並形成 evidence packet：

$$
e_{t+1}
=
(
a_t,o_{t+1},v_{t+1},\Pi_{t+1}
).
$$

最後由：

$$
\boxed{
\mathcal S_{t+1}
=
\mathcal U(
\mathcal S_t,
e_{t+1};
\mathcal W_t
)
}
$$

完成更新。

本文的核心不是發明另一種 Bayesian rule，而是將 epistemic update 分成三種數學上不同的模式。

第一類為 **Fixed-Domain Reweighting**：$\jmath_t$ 與 $\mathcal H_t$ 固定，只更新 $P_t$。標準 Bayesian update 是此類的特例。

第二類為 **Support Contraction / Exact Falsification**：外部 verifier 直接淘汰部分假說。本文證明，若 surviving set：

$$
S_e
=
\{
h:
V(h,e)\neq\mathrm{fail}
\}
$$

具有：

$$
P_t(S_e)>0,
$$

則 exact elimination 等價於使用 $0/1$ likelihood 的 Bayesian conditioning：

$$
P_{t+1}(A)
=
\frac{
P_t(A\cap S_e)
}{
P_t(S_e)
}.
$$

因此 deterministic falsification 可以被 probability representation 表示，但這不抹去 verifier 在 operational semantics 中的獨立來源。

第三類為 **Epistemic-Domain Reconstruction**：fresh evidence 不只是改變既有 hypothesis weights，而是改變 hypothesis vocabulary、semantic partition、event algebra、carrier 或 judgment domain 本身。此時：

$$
\mathcal H_{t+1}
\not\equiv
\mathcal H_t
$$

甚至：

$$
\mathfrak D_{t+1}
\not\simeq
\mathfrak D_t.
$$

本文證明 Domain-Reconstruction Non-Uniqueness：若新 hypothesis space 包含 old space 之外的新假說，而沒有明示 extension / transport witness，舊 $P_t$ 一般不能唯一決定 $P_{t+1}$。因此：

$$
\boxed{
\text{Bayesian reweighting}
}
$$

只能處理「固定可表達假說空間內」的 uncertainty redistribution；當 evidence 迫使研究者承認原先假說空間本身錯誤或不完備時，需要 UJDPF 所要求的 domain transport witness。

本文進一步定義 **Zero-Support Epistemic Crisis**。如果 observed evidence：

$$
e
$$

在所有舊假說下 likelihood 都為零：

$$
P(e\mid h)=0
\qquad
\forall h\in\mathcal H_t,
$$

則 fixed-domain Bayes denominator 為零，無法在原 hypothesis class 內形成 posterior。這不是 Bayes theorem 的錯誤，而是 model-class failure / domain inadequacy 的信號。AER 在此扮演的角色，就是透過新實驗、representation search、semantic reconstruction 與 hypothesis generation建立新的可判定域。

本文再引入 **Evidence-to-Witness Construction**：AER 的 action、observation、verifier contract、scope 與 provenance 可以構成 UJDPF transport witness 的 empirical component。也就是：

$$
\boxed{
\text{AER produces evidence that can discharge UJDPF witness obligations}.
}
$$

最後，SEHTS-01 的 historical trace 使 update 不只存在於單次 session：

$$
e_{t+1}
\rightarrow
\mathcal T(e_{t+1})
\rightarrow
G_{t+1}
\rightarrow
K_{t+1}.
$$

由此形成本文的最終閉環：

$$
\boxed{
P_t
\rightarrow
\mathcal H_t
\rightarrow
a_t
\rightarrow
o_{t+1}
\rightarrow
V_t
\rightarrow
\mathcal T_{t+1}
\rightarrow
K_{t+1}
\rightarrow
\mathfrak D_{t+1}
\rightarrow
P_{t+1}.
}
$$

Bayesian update 因此不是被否定，而是被定位為這個更大系統中的 **fixed-domain probability-update fragment**。AER 不是 Bayesian inference 的替代，而是當 evidence acquisition、hypothesis-space change 與 domain reconstruction 都成為 Agent action 時，所需要的外層認識動力學。

**關鍵詞：** Bayesian Updating, Active Epistemic Reconstruction, Judgment Domain, Hypothesis Space, Falsification, External Verifier, Active Learning, Bayesian Experimental Design, Scientific Agents, Historical Trace, Probability Transport, Model-Class Failure

---

# 1. 接點不是「概率 vs 確定性」

先前兩套研究看起來像從不同方向出發。

概率側問：

> 一個概率究竟是哪個 domain、scale、time、context 中的概率？

認識重構側問：

> AI 在不知道真實 semantics 的情況下，如何靠 action、evidence 與 verifier 逐步知道自己原本猜錯？

真正的接點不是：

$$
\boxed{
\text{probability}
\quad
\text{vs}
\quad
\text{determinism}.
}
$$

而是：

$$
\boxed{
\text{probability state}
\rightarrow
\text{evidence-producing action}
\rightarrow
\text{epistemic state transformation}.
}
$$

---

# 2. 四條研究線的功能分工

## 2.1 UJDPF

回答：

> 概率主張在哪個判定域中成立？如何合法跨域？

核心：

$$
\jmath=(\rho,s,t,c),
$$

$$
P_\jmath,
$$

$$
\mathcal W=(\tau,T,\Gamma,\Pi).
$$

## 2.2 PDHES

回答：

> 一個 Agent-level research system 為什麼不應只用 generator probability 來描述？

核心：

$$
\mathcal A
=
(
M,\mathcal T,E,S,V,\Pi
).
$$

其中 generator、tool、world、persistent state、verifier 與 scheduler 是不同 functional roles。

## 2.3 AER

回答：

> Agent 如何主動產生新 evidence 並重構未知 semantics？

核心：

$$
U:
(
\mathcal H_t,
K_t,
a_t,
o_{t+1}
)
\rightarrow
(
\mathcal H_{t+1},
K_{t+1}
).
$$

## 2.4 SEHTS

回答：

> evidence 為何能在下一輪仍然存在？

核心：

$$
e_t
\rightarrow
\mathcal T_t(e_t)
\rightarrow
G_{t+1}.
$$

---

# 3. 現有科學 Agent 已經在做「假說—實驗—更新」閉環

本文不宣稱主動科學循環是新概念。

Bayesian optimal experimental design 已長期研究：

$$
\boxed{
\text{選哪個 experiment 可以最大化 expected information gain？}
}
$$

Walsh、Wildey 與 Jakeman 的 consistent Bayesian OED 直接以 prior-to-posterior expected information gain 選擇 observation [1]。

2024 年 The AI Scientist 已將 idea generation、code execution、experiment、result analysis 與 paper generation串成 agentic workflow [2]。

2025 年 AlphaEvolve 使用 LLM proposal 與一個或多個 automated evaluators 形成反覆改進的 evolutionary loop [3]。

2026 年 Robin 則已實際整合 literature-grounded hypothesis generation、experiment proposal、experimental data analysis 與 updated hypothesis generation [4]。

因此本文的 novelty 不在：

$$
\boxed{
\text{AI can propose experiments}.
}
$$

而在：

$$
\boxed{
\text{how probability update, falsification, domain reconstruction, and historical evidence become one typed transition system}.
}
$$

---

# 4. Unified Epistemic–Probability State

### 定義 4.1

定義時間 $t$ 的 Epistemic–Probability State：

$$
\boxed{
\mathcal S_t
=
(
\jmath_t,
\mathcal H_t,
P_t,
K_t,
G_t
).
}
$$

其中：

## Judgment Index

$$
\jmath_t
=
(
\rho_t,
s_t,
t,
c_t
).
$$

## Hypothesis Space

$$
\mathcal H_t
=
\{
h_i
\}.
$$

## Probability State

$$
P_t
\in
\mathsf P(
\mathcal H_t
).
$$

## Canonical Epistemic State

$$
K_t
$$

保存：

- verified claims；
- invalidated claims；
- unknowns；
- exclusions；
- current frontier；
- evidence pointers。

## Historical / Provenance Graph

$$
G_t.
$$

保存：

- raw evidence；
- experiment relation；
- contradiction；
- revision；
- provenance；
- historical traces。

---

# 5. 真實 Target 不等於 Agent 的 Hypothesis Space

令未知 target semantic structure：

$$
\Theta^\ast
=
(
\rho^\ast,
\delta^\ast,
J^\ast
).
$$

Agent 維持：

$$
\mathcal H_t
=
\{
h_1,\ldots,h_n
\}.
$$

這兩者不必滿足：

$$
\Theta^\ast
\in
\mathcal H_t.
$$

這一點非常重要。

若：

$$
\Theta^\ast
\notin
\mathcal H_t,
$$

再完美的 fixed-model Bayesian updating 也不能把 posterior 放到一個 hypothesis space 中不存在的 truth 上。

這就是本文所稱：

$$
\boxed{
\text{hypothesis-space incompleteness}.
}
$$

---

# 6. Proposal Policy

Agent 選擇下一個 research action：

$$
a_t
\in
\mathcal A_t.
$$

它可以是 deterministic：

$$
a_t
=
\pi(
\mathcal S_t
),
$$

也可以是 probabilistic：

$$
\boxed{
a_t
\sim
\pi_t(
\cdot
\mid
\mathcal S_t
).
}
$$

所以：

$$
\boxed{
\text{probabilistic proposal}
}
$$

完全可以存在於主動科學系統中。

本文沒有要求 Agent 的 experiment choice 必須 deterministic。

---

# 7. Environment Response

action：

$$
a_t
$$

作用於 target：

$$
\Theta^\ast.
$$

環境返回：

$$
\boxed{
o_{t+1}
\sim
\mathcal E_{\Theta^\ast}
(
\cdot
\mid
a_t,\jmath_t
).
}
$$

如果 environment deterministic：

$$
o_{t+1}
=
E(
\Theta^\ast,a_t
).
$$

如果 environment stochastic：

$$
o_{t+1}
$$

仍可帶 noise：

$$
\xi_t.
$$

因此：

$$
\boxed{
\text{external evidence}
}
$$

不等於：

$$
\boxed{
\text{deterministic evidence}.
}
$$

---

# 8. Verifier

Verifier：

$$
V_t
$$

接受：

$$
(
h,
a_t,
o_{t+1}
)
$$

並輸出：

$$
\boxed{
V_t
\in
\{
\mathrm{pass},
\mathrm{fail},
\mathrm{unknown}
\}
}
$$

或 score。

Verifier 可以是：

- exact equality；
- compiler；
- unit test；
- formal proof checker；
- checksum；
- statistical test；
- physical measurement criterion；
- human judgment。

所以 verifier 也是 typed object。

---

# 9. Evidence Packet

定義：

$$
\boxed{
e_{t+1}
=
(
a_t,
o_{t+1},
V_t,
\sigma_t,
\Pi_{t+1}
).
}
$$

其中：

- $a_t$：action；
- $o_{t+1}$：observation；
- $V_t$：verifier result / contract；
- $\sigma_t$：scope / version；
- $\Pi_{t+1}$：provenance。

只保存：

$$
o_{t+1}
$$

往往不夠。

因為未來研究需要知道：

> 這個 observation 是在什麼 action、version、scope、verifier 下形成的？

---

# 10. Unified Update Operator

定義：

$$
\boxed{
\mathcal S_{t+1}
=
\mathcal U(
\mathcal S_t,
e_{t+1};
\mathcal W_t
).
}
$$

$\mathcal W_t$ 為跨 state / domain 的 transition witness。

本文不假設：

$$
\mathcal U
$$

一定是一條 Bayesian formula。

而先辨識：

$$
\boxed{
\text{到底是哪一種 update？}
}
$$

---

# 11. Update Type I：Fixed-Domain Reweighting

第一種情況：

$$
\jmath_{t+1}
=
\jmath_t,
$$

$$
\mathcal H_{t+1}
=
\mathcal H_t.
$$

只改：

$$
P_t
\rightarrow
P_{t+1}.
$$

這就是最典型的：

$$
\boxed{
\text{probability reweighting}.
}
$$

若 likelihood：

$$
L(
e_{t+1}
\mid
h,a_t
)
$$

已知，則：

$$
\boxed{
P_{t+1}(h)
=
\frac{
L(
e_{t+1}
\mid
h,a_t
)
P_t(h)
}{
\int_{\mathcal H_t}
L(
e_{t+1}
\mid
h',a_t
)
\,dP_t(h')
}.
}
$$

這是 standard Bayesian fragment。

---

# 12. 定理一：Fixed-Domain Bayesian Reduction

### 命題 12.1

若：

1. $\jmath_t=\jmath_{t+1}$；
2. $\mathcal H_t=\mathcal H_{t+1}=\mathcal H$；
3. observation likelihood 在 $\mathcal H$ 上已定義；
4. evidence 不改變 event ontology；
5. denominator 為正；

則 unified update $\mathcal U$ 可以退化為 ordinary Bayesian conditioning。

### 證明

以上條件保證 source 與 target probability objects 位於同一 hypothesis carrier：

$$
\mathcal H.
$$

因此不需要跨-domain transport。

以 observation likelihood $L$ 作 Radon–Nikodym reweighting 後 normalize，即得標準 posterior。

$$
\boxed{\square}
$$

---

# 13. 這表示 Bayes 不是被替代，而是被嵌入

本文不提出：

$$
\boxed{
\text{AER > Bayes}.
}
$$

更精確：

$$
\boxed{
\text{Bayesian updating}
\subset
\text{fixed-domain epistemic reconstruction}.
}
$$

AER 只在：

- evidence acquisition 是 action-dependent；
- hypothesis support 被 exact verifier 改變；
- domain / semantics / ontology 改變；

時多出額外結構。

---

# 14. Update Type II：Support Contraction

令 exact verifier 定義 survivor set：

$$
\boxed{
S_e
=
\{
h\in\mathcal H_t:
V(h,e)\neq\mathrm{fail}
\}.
}
$$

此時：

$$
\mathcal H_{t+1}
=
S_e
\subseteq
\mathcal H_t.
$$

這是一種：

$$
\boxed{
\text{hypothesis-space contraction}.
}
$$

---

# 15. 定理二：Exact Falsification 等價於 0/1 Likelihood Conditioning

### 命題 15.1

若：

$$
P_t(S_e)>0,
$$

定義：

$$
L_e(h)
=
\mathbf 1_{S_e}(h).
$$

則 Bayesian posterior：

$$
P_{t+1}(A)
=
\frac{
\int_A
L_e(h)
\,dP_t(h)
}{
\int
L_e(h)
\,dP_t(h)
}
$$

等於：

$$
\boxed{
P_{t+1}(A)
=
\frac{
P_t(
A\cap S_e
)
}{
P_t(S_e)
}.
}
$$

### 證明

因：

$$
L_e(h)
=
1
$$

恰好在 $S_e$ 上成立，

分子為：

$$
P_t(A\cap S_e),
$$

分母為：

$$
P_t(S_e).
$$

故成立。

$$
\boxed{\square}
$$

---

# 16. 這個定理的真正意義

它告訴我們：

$$
\boxed{
\text{deterministic falsification}
}
$$

確實可以**表示**成 degenerate likelihood。

所以不能說：

> deterministic verifier 在數學上絕對不能被概率表示。

但這不代表 verifier 的功能角色因此消失。

因為：

$$
\boxed{
\text{0/1 likelihood 從哪裡來？}
}
$$

仍然需要：

- compiler；
- theorem checker；
- hash；
- world experiment；
- exact equality；

等外部 operation 提供。

因此：

$$
\boxed{
\text{representability}
\neq
\text{operational explanatory sufficiency}.
}
$$

---

# 17. Probability Representation 與 Evidence Production 要分開

在事後，我們可以把：

$$
V(h,e)\in\{0,1\}
$$

轉成 likelihood。

但 experiment 前：

$$
e
$$

尚未存在。

所以：

$$
\boxed{
\text{Bayesian update rule}
}
$$

不會替 Agent 自動完成：

$$
\boxed{
\text{experiment selection + execution + evidence production}.
}
$$

這正是 AER 的 active layer。

---

# 18. Zero-Support Epistemic Crisis

考慮更強的情況。

對所有：

$$
h\in\mathcal H_t,
$$

都有：

$$
\boxed{
L(e\mid h)=0.
}
$$

則 Bayes denominator：

$$
Z
=
\int_{\mathcal H_t}
L(e\mid h)
\,dP_t(h)
=
0.
$$

所以 fixed-domain posterior 無法定義。

本文稱：

$$
\boxed{
\text{Zero-Support Epistemic Crisis}.
}
$$

---

# 19. Zero-Support Crisis 不是 Bayes theorem 失效

問題不是 Bayes theorem 錯。

而是：

$$
\boxed{
\text{目前 model class 對已觀察 evidence 沒有任何可接受解釋}.
}
$$

這可以表示：

- model misspecification；
- hypothesis space incomplete；
- event ontology wrong；
- representation domain wrong；
- scope wrong；
- verifier / measurement contract wrong。

所以正確 response 不是硬造 posterior。

而是：

$$
\boxed{
\text{reconstruct the epistemic domain}.
}
$$

---

# 20. Update Type III：Epistemic-Domain Reconstruction

現在允許：

$$
\boxed{
\mathcal H_{t+1}
\not=
\mathcal H_t.
}
$$

更強甚至：

$$
X_{t+1}\neq X_t,
$$

$$
\Sigma_{t+1}\neq\Sigma_t,
$$

$$
\jmath_{t+1}\neq\jmath_t.
$$

例如原本 hypothesis：

> byte $x$ 是整數 Stress。

fresh evidence 卻顯示：

> byte $x$ 其實是一組 flags。

這不是：

$$
P(\mathrm{Stress}=100)
\rightarrow
P(\mathrm{Stress}=0).
$$

而是：

$$
\boxed{
\text{舊 semantic carrier 被推翻}.
}
$$

---

# 21. Domain Reconstruction 可以包含哪些操作？

至少包括：

## Representation Replacement

$$
\rho_t
\rightarrow
\rho_{t+1}.
$$

## Semantic Repartition

同一 raw carrier 被重新劃分 semantic classes。

## Hypothesis Expansion

$$
\mathcal H_t
\subsetneq
\mathcal H_{t+1}.
$$

## Hypothesis Replacement

$$
\mathcal H_t
\not\subseteq
\mathcal H_{t+1},
\qquad
\mathcal H_{t+1}
\not\subseteq
\mathcal H_t.
$$

## Event-Algebra Change

$$
\Sigma_t
\rightarrow
\Sigma_{t+1}.
$$

## Judgment-Rule Change

$$
J_t
\rightarrow
J_{t+1}.
$$

---

# 22. 定理三：Domain-Reconstruction Non-Uniqueness

### 命題 22.1

令：

$$
\mathcal H'
=
\mathcal H
\sqcup
N,
$$

其中：

$$
N\neq\varnothing.
$$

給定舊 probability：

$$
P\in\mathsf P(\mathcal H).
$$

若未指定：

- 新 hypothesis mass；
- extension rule；
- transport kernel；
- selection principle；

則 $P$ 一般不能唯一決定：

$$
Q\in\mathsf P(\mathcal H').
$$

### 證明

對任意：

$$
\alpha\in(0,1],
$$

與任意：

$$
R\in\mathsf P(N),
$$

定義：

$$
\boxed{
Q_{\alpha,R}
=
\alpha P
+
(1-\alpha)R.
}
$$

其中兩個 measure 支撐於 disjoint components：

$$
\mathcal H,
N.
$$

所有：

$$
Q_{\alpha,R}
$$

在條件於舊 hypothesis region：

$$
\mathcal H
$$

時都恢復：

$$
P.
$$

但不同：

$$
\alpha,R
$$

給出不同 $Q$。

所以舊 $P$ 不唯一決定新-domain probability。

$$
\boxed{\square}
$$

---

# 23. 這就是 UJDPF 的 Witnessed Transport 在 AER 中真正出現的地方

domain reconstruction 後：

$$
P_t
$$

與：

$$
P_{t+1}
$$

位於不同 carriers。

所以不能裸寫：

$$
P_t
\rightarrow
P_{t+1}
$$

而必須指定：

$$
\boxed{
\mathcal W_t
=
(
\tau_t,
T_t,
\Gamma_t,
\Pi_t
).
}
$$

其中：

- $\tau_t$：old semantics 到 new semantics 的 mapping；
- $T_t$：probability extension / kernel / projection；
- $\Gamma_t$：domain-reconstruction assumptions；
- $\Pi_t$：fresh evidence / verifier provenance。

---

# 24. Evidence-to-Witness Construction

本文定義一個 AER evidence witness：

$$
\boxed{
\mathcal E\mathcal W_t
=
(
a_t,
o_{t+1},
V_t,
\sigma_t,
\Pi_t
).
}
$$

若它能支持：

1. source judgment domain；
2. target judgment domain；
3. event / semantic correspondence；
4. falsification or validation rule；
5. reproducible provenance；

則可將：

$$
\mathcal E\mathcal W_t
$$

嵌入 UJDPF witness 的：

$$
\Gamma_t,
\Pi_t.
$$

所以：

$$
\boxed{
\text{AER produces empirical components of UJDPF transport witnesses}.
}
$$

---

# 25. Witness 不是只有一個 observation

單一：

$$
o
$$

可能有多個 interpretations。

所以一個強 witness 至少需要：

$$
\boxed{
\text{Action}
+
\text{Observation}
+
\text{Scope}
+
\text{Verifier}
+
\text{Provenance}.
}
$$

例如：

> byte 變成 `0x64`

本身不能證明：

> 這是 Stress=100。

還需要：

- 修改 protocol；
- reload；
- visible behavior；
- version；
- alternative hypothesis rejection。

這正是 AER Paper 02–04 的共同結論。

---

# 26. 主動實驗選擇

現在 Agent 面對 action set：

$$
\mathcal A_t.
$$

最經典 Bayesian OED 可以選：

$$
a_t^\ast
\in
\arg\max_a
\mathbb E[
D_{\mathrm{KL}}(
P_{t+1}
\Vert
P_t
)
].
$$

本文保留這個成熟接口。

但 AER 中 gain 不一定只來自 probability reweighting。

一個 experiment 可能直接發現：

$$
\boxed{
\text{舊 hypothesis vocabulary 錯了}.
}
$$

---

# 27. Structural Epistemic Gain

因此定義一個一般 gain functional：

$$
\boxed{
\mathcal G(
\mathcal S_t,e
)
}
$$

其值可以綜合：

- entropy reduction；
- eliminated hypothesis mass；
- domain ambiguity reduction；
- representation discrimination；
- falsification strength；
- new semantic structure；
- evidence reproducibility。

本文不宣稱存在唯一最佳 $\mathcal G$。

它是一個 task-dependent objective。

---

# 28. Cost-Normalized Experiment Selection

加入 cost：

$$
C(a)>0.
$$

則：

$$
\boxed{
a_t^\ast
\in
\arg\max_{a\in\mathcal A_t}
\frac{
\mathbb E[
\mathcal G(
\mathcal S_t,e_{t+1}
)
\mid a
]
}{
C(a)
}.
}
$$

這延續 Bayesian experimental design 的 expected information gain，又允許 structural domain gain。

---

# 29. AER 不是 Brute Force

Brute force：

$$
\text{大量 action}
\rightarrow
\text{大量 observation}.
$$

AER：

$$
\boxed{
\text{current uncertainty}
\rightarrow
\text{discriminating experiment}.
}
$$

所以重要的不是 action 數量，而是：

$$
\boxed{
\text{hypothesis separation per cost}.
}
$$

---

# 30. 2026 Scientific Agents 與本文的接點

Robin 已經能：

- literature search；
- generate hypotheses；
- propose experiments；
- analyze experimental results；
- generate updated hypotheses [4]。

Co-Scientist 也使用多個 specialized agents 生成、反思、排名與演化 hypotheses [5]。

這些實際系統證明：

$$
\boxed{
\text{hypothesis state itself can be a runtime object}.
}
$$

本文進一步問：

> 當 hypothesis state 改變時，其 probability domain 如何合法遷移？

---

# 31. AlphaEvolve 與 External Evaluator

AlphaEvolve 的關鍵之一是：

$$
\boxed{
\text{LLM proposal}
+
\text{one or more evaluators}.
}
$$

候選不是由 generator 自己宣告「更好」就成立。

這正對應：

$$
\boxed{
\text{proposal}
\neq
\text{judgment}.
}
$$

UJDPF bridge 則再加：

$$
\boxed{
\text{judgment result must be scoped and transportable}.
}
$$

---

# 32. Intrinsic Self-Correction 不足以取代 External Evidence

既有研究已指出，LLM intrinsic self-correction 在缺乏 external feedback 時不一定可靠 [6]。

因此：

$$
\boxed{
\text{model changes its answer}
}
$$

不等於：

$$
\boxed{
\text{world falsified the previous hypothesis}.
}
$$

這正是 PDHES verifier 與 AER external environment 必須保留的原因。

---

# 33. Evidence State $K_t$ 為什麼不能只等於 Posterior $P_t$？

posterior：

$$
P_t
$$

保存：

$$
\boxed{
\text{目前 uncertainty distribution}.
}
$$

但：

$$
K_t
$$

還需要保存：

- why a hypothesis was eliminated；
- exact counterexample；
- version scope；
- verifier contract；
- excluded experiments；
- raw evidence pointer；
- current unknowns。

所以：

$$
\boxed{
K_t
\neq
P_t.
}
$$

即使：

$$
P_t
$$

已包含所有 hypothesis weights。

---

# 34. 同 Posterior 可以有不同 Evidence History

存在兩個 histories：

$$
H_1,H_2
$$

最後形成相同：

$$
P_t.
$$

但：

$$
G_t^{(1)}
\neq
G_t^{(2)}.
$$

例如：

- 一條路徑靠 exact compiler failure 淘汰假說；
- 另一條路徑靠 statistical evidence 降低同一假說。

最後 posterior weight 可能相同。

但 future trust / replayability / scope 不同。

所以：

$$
\boxed{
\text{same posterior}
\not\Rightarrow
\text{same epistemic state}.
}
$$

---

# 35. Historical Trace 是 Update 的長期記憶層

SEHTS-01 定義：

$$
\mathcal T(e)
$$

為 persistent historical trace。

本文將：

$$
\boxed{
G_{t+1}
=
G_t
\cup
\mathcal T(e_{t+1}).
}
$$

因此 update 不只是：

$$
P_t
\rightarrow
P_{t+1}.
$$

還有：

$$
\boxed{
G_t
\rightarrow
G_{t+1}.
}
$$

---

# 36. Contradiction Persistence

若：

$$
V(h,e)=\mathrm{fail},
$$

則：

$$
(h,e,V)
$$

應進入：

$$
G_{t+1}.
$$

否則 future Agent 可能因 context loss 又重新提出：

$$
h
$$

而不知道它曾被 exact evidence 淘汰。

因此：

$$
\boxed{
\text{epistemic update requires contradiction persistence}.
}
$$

---

# 37. No-Cost Resurrection Principle

本文延續 AER Paper 04 的精神：

若 hypothesis：

$$
h
$$

曾在 scope：

$$
\sigma
$$

下被 strong verifier 淘汰，

則 future state 不應在沒有：

- new evidence；
- scope change；
- verifier invalidation；
- model revision；

的情況下無成本恢復：

$$
h.
$$

這不是形而上的永遠禁止。

它是：

$$
\boxed{
\text{provenance-aware hypothesis lifecycle}.
}
$$

---

# 38. Evidence Recompression

長時研究的 raw evidence：

$$
R_{0:t}
$$

會爆炸。

因此 canonical epistemic state：

$$
K_t
=
C_E(
R_{0:t}
)
$$

需要做 semantic recompression。

但壓縮必須保留：

- evidence pointers；
- contradictions；
- status；
- scope；
- dependency graph。

所以：

$$
\boxed{
\text{compression may remove prose, not epistemic justification}.
}
$$

---

# 39. Epistemic Sufficient State

若：

$$
K_t
$$

能在容許誤差：

$$
\varepsilon
$$

內，對所有下一步 decision class：

$$
\mathcal D
$$

保留使用 raw evidence 所需要的 decision-relevant information，

則可稱：

$$
\boxed{
K_t
}
$$

為 task-relative Epistemic Sufficient State。

這與 probability flattening 的 Barycentric Sufficiency 有結構類比，但不是同一 theorem。

---

# 40. 橋接後的完整 State Transition

最終：

$$
\boxed{
\begin{aligned}
\mathcal S_t
&=
(
\jmath_t,
\mathcal H_t,
P_t,
K_t,
G_t
)
\\
a_t
&\sim
\pi_t(
\cdot
\mid
\mathcal S_t
)
\\
o_{t+1}
&\sim
\mathcal E_{\Theta^\ast}
(
\cdot
\mid
a_t,\jmath_t
)
\\
e_{t+1}
&=
(
a_t,o_{t+1},V_t,\sigma_t,\Pi_t
)
\\
\mathcal S_{t+1}
&=
\mathcal U(
\mathcal S_t,
e_{t+1};
\mathcal W_t
).
\end{aligned}
}
$$

---

# 41. 三種 Update Mode 的統一表

| Mode | $\mathcal H$ | $\jmath$ | $P$ | 需要 UJDPF 跨域 witness？ |
|---|---|---|---|---|
| Reweight | 固定 | 固定 | 改變 | 否 |
| Contract | 縮小 | 通常固定 | restriction + renormalization | 通常不需新域，但需 verifier provenance |
| Reconstruct | 改寫／擴張 | 可改變 | 需 extension / transport | 是 |

這是本文最重要的橋接表。

---

# 42. Probability Update Failure 與 Epistemic Failure 要分開

如果：

$$
P_{t+1}
$$

無法定義，原因可能不同。

## Numerical Failure

計算問題。

## Zero-Support Failure

所有 old hypotheses 給 evidence 零 likelihood。

## Type Failure

old/new event spaces 不相容。

## Model-Class Failure

truth 不在 hypothesis class。

## Verifier Failure

measurement / checker contract 錯。

## Provenance Failure

evidence scope 無法確定。

所以：

$$
\boxed{
\text{posterior failure}
}
$$

不應全部稱為「Bayesian failure」。

---

# 43. Domain Reconstruction Trigger

本文提出第一版 trigger：

若至少一項成立：

1. posterior denominator $=0$；
2. strong verifier 淘汰所有 current hypotheses；
3. repeated evidence 系統性落在 model predictive support 外；
4. representation tests 不可由 current semantic mapping 解釋；
5. event ontology 無法容納新 observation；
6. scope mutation 被確認；

則 Agent 應標記：

$$
\boxed{
\mathrm{RECONSTRUCT\_DOMAIN}.
}
$$

這是一個 framework rule，不是 universal statistical theorem。

---

# 44. Unknown 是合法狀態

若 evidence 不足：

$$
V(h,e)=\mathrm{unknown},
$$

則 Agent 不應被迫：

- pass；
- fail；
- invent a posterior collapse。

所以：

$$
\boxed{
\mathrm{Unknown}
}
$$

是 epistemic state 的合法值。

這也是 PDHES/AER 和普通「總要輸出答案」Agent 的重要差異。

---

# 45. 新 Hypothesis 從哪裡來？

domain reconstruction 後的新 hypotheses 可以來自：

- generator；
- historical prior；
- analogy；
- external literature；
- program synthesis；
- human intervention；
- representation enumeration；
- counterexample-driven synthesis。

因此：

$$
\boxed{
\mathcal H_{t+1}
}
$$

本身可以是生成產物。

其 proposal process 可以概率化。

但新 hypothesis 的 admissibility 仍需 validation。

---

# 46. Hypothesis Generation Probability 不等於 Hypothesis Truth Probability

若 generator：

$$
G
$$

高概率提出某個：

$$
h,
$$

這只代表：

$$
\boxed{
P_{\mathrm{proposal}}(h)
}
$$

高。

不等於：

$$
\boxed{
P_{\mathrm{truth}}(h)
}
$$

高。

這兩種 probability 必須位於不同 judgment domains / semantics。

這是 UJDPF typing 在 AER 中另一個直接用途。

---

# 47. Proposal Prior 與 Epistemic Prior

因此至少分：

## Generator Proposal Law

$$
Q_{\mathrm{gen}}(h).
$$

## Epistemic Prior

$$
P_t(h).
$$

## Experiment-Conditioned Posterior

$$
P_{t+1}(h\mid e).
$$

不能因 model 很常生成某 hypothesis，就把它當成 prior credibility。

---

# 48. Fresh Evidence 的必要性

若 Agent 只從既有語料重新組合：

$$
h,
$$

而沒有產生：

$$
e_{\mathrm{new}},
$$

則可能只是：

$$
\boxed{
\text{latent retrieval / recombination}.
}
$$

AER 的 stronger claim 需要：

$$
\boxed{
\text{action-conditioned fresh observation}.
}
$$

---

# 49. Fresh Evidence Criterion

可將 evidence：

$$
e_{t+1}
$$

稱為 fresh，若它的內容在 protocol 開始前不是 Agent 可直接讀取的 target-local fact，而必須透過：

$$
a_t
$$

作用於 environment 後才能取得。

這是半黑箱 benchmark 能測 research reconstruction 的核心。

---

# 50. 世界會改變 probability domain，而不只 posterior

這是本文最重要的一句：

$$
\boxed{
\text{Fresh evidence can update probabilities;}
}
$$

但更強：

$$
\boxed{
\text{fresh evidence can update what the probabilities are probabilities over}.
}
$$

當：

$$
\mathcal H_t
\rightarrow
\mathcal H_{t+1},
$$

probability carrier 本身變了。

這就是 AER 與 UJDPF 真正合流的位置。

---

# 51. Law–Evidence–Domain Triangle

本文將三者整理為：

$$
\boxed{
\begin{array}{ccc}
P_t
&
\longrightarrow
&
\text{Predictions}
\\
\uparrow
&&
\downarrow
\\
\mathfrak D_t
&
\longleftarrow
&
E_t
\end{array}
}
$$

probability law 依賴 domain。

domain 產生 predictions。

evidence 驗證 predictions。

evidence 又可能迫使 domain 改變。

所以不是單向：

$$
\mathfrak D
\rightarrow
P.
$$

而是動態閉環。

---

# 52. Active Judgment-Domain Reconstruction

因此本文提出一個新術語候選：

$$
\boxed{
\text{Active Judgment-Domain Reconstruction}.
}
$$

它表示：

> Agent 透過主動 experiment 與 external evidence，不只更新 domain 內 probability，而主動確認、縮小、替換或擴張 probability judgment domain。

這是 AER 在 UJDPF 語言中的最直接重寫。

---

# 53. Evidence-Driven Domain Transport

如果 fresh evidence 建立 mapping：

$$
\tau:
\mathfrak D_t
\rightarrow
\mathfrak D_{t+1},
$$

則 probability transport：

$$
T
$$

必須說明：

- old hypotheses 如何映射；
- invalid hypotheses 如何消失；
- new hypotheses 如何取得 mass；
- event semantics 如何對齊；
- uncertainty 如何保留。

所以：

$$
\boxed{
\text{domain transport}
}
$$

也是 epistemic modeling problem。

---

# 54. Bayesian Model Expansion 是其中一個可能實作，不是唯一形式

當：

$$
\mathcal H_t
\subset
\mathcal H_{t+1},
$$

可以使用 hierarchical prior / model selection 等標準 Bayesian machinery。

但如果連：

$$
X,
\Sigma,
J
$$

都改變，就不只是「新增一個模型 index」。

因此本文不把所有 domain reconstruction 都壓成普通 Bayesian model selection。

---

# 55. Same Probability, Different Epistemic Meaning

例如：

$$
P_t(h)=0.5
$$

與：

$$
P_{t+1}(h')=0.5
$$

數字相同。

但若：

$$
h
$$

是「這個 byte 是 Stress」，

而：

$$
h'
$$

是「這個 byte 是 bit mask」，

兩個 $0.5$ 不具有同一 semantic type。

因此：

$$
\boxed{
\text{same scalar probability}
\not\Rightarrow
\text{same epistemic statement}.
}
$$

---

# 56. External Verifier 可以讓 Probability Support 變成可審計對象

對每個：

$$
h_i,
$$

保存：

```text
hypothesis_id
prior_mass
predictions
test_protocol
verifier_contract
evidence_pointer
status
posterior_mass
scope
```

此時：

$$
P_t
$$

不再只有一列 numbers。

它連到：

$$
G_t
$$

中的 evidence graph。

這形成：

$$
\boxed{
\text{provenance-backed probability state}.
}
$$

---

# 57. Epistemic Probability Ledger

本文建議最小 ledger：

```text
state_id:
time:

judgment_domain:
  reference_scope:
  scale:
  context:
  carrier:
  event_ontology:

hypothesis_space:
  version:
  hypotheses:

probability_state:
  prior_or_posterior:
  measure:
  normalization_status:

action:
  experiment_id:
  selection_rule:
  expected_gain:
  cost:

observation:
  raw_evidence_pointer:
  scope:

verifier:
  contract:
  result:
  strength:

update:
  mode:
    reweight
    contract
    reconstruct
  transport_witness:
  eliminated_hypotheses:
  added_hypotheses:
  domain_changes:

history:
  provenance_graph:
  contradiction_ledger:
```

---

# 58. 一個簡單 Running Example

初始 hypotheses：

$$
\mathcal H_0
=
\{
h_1,h_2
\}.
$$

其中：

$$
h_1:
\text{byte is integer Stress},
$$

$$
h_2:
\text{byte is percentage-like value}.
$$

先驗：

$$
P_0(h_1)=0.7,
$$

$$
P_0(h_2)=0.3.
$$

Agent 修改 byte 並 reload。

world observation：

$$
o_1.
$$

若：

$$
V(h_1,o_1)=fail,
$$

$$
V(h_2,o_1)=fail,
$$

則：

$$
S_e=\varnothing.
$$

此時不是：

$$
P_1(h_1)=P_1(h_2)=0.
$$

因為那不是 normalized probability。

正確狀態是：

$$
\boxed{
\mathrm{MODEL\ CLASS\ FAILURE}.
}
$$

---

# 59. Reconstruction Example

Agent 新增：

$$
h_3:
\text{byte is a bit field}.
$$

所以：

$$
\mathcal H_1
=
\{
h_3,h_4,\ldots
\}.
$$

新 space 與舊 space 不只是 reweight。

因此需要：

$$
\mathcal W_{0\rightarrow1}.
$$

fresh experiments 再區分：

- 哪個 bit；
- 哪個 visible state；
- reload 是否持久；
- version 是否一致。

這就是 AER。

---

# 60. 何時可以安全退回普通 Bayes？

若經 reconstruction 後：

- representation 已穩定；
- semantic ontology 已穩定；
- hypothesis class 已固定；
- likelihood model 可接受；
- evidence scope 固定；

則可以重新進入：

$$
\boxed{
\text{ordinary Bayesian phase}.
}
$$

所以一個 research trajectory 可以在：

$$
\boxed{
\text{Bayesian phase}
}
$$

與：

$$
\boxed{
\text{domain-reconstruction phase}
}
$$

之間切換。

---

# 61. Epistemic Regime Switching

定義 regime：

$$
R_t
\in
\{
\mathrm{REWEIGHT},
\mathrm{CONTRACT},
\mathrm{RECONSTRUCT}
\}.
$$

Agent 的真正高階任務之一是辨識：

$$
\boxed{
\text{現在應該做哪一種 update？}
}
$$

如果每次 evidence 都只做 reweight，可能在錯誤 model class 中越算越精確。

---

# 62. 「越算越精確」可能是一種錯誤

若：

$$
\Theta^\ast
\notin
\mathcal H_t,
$$

Agent 仍在：

$$
\mathcal H_t
$$

內做更精細 posterior estimation，

可能得到：

$$
\boxed{
\text{high-confidence wrong-domain inference}.
}
$$

這是判定域錯誤比普通 probability error 更危險的原因。

---

# 63. Domain Adequacy

本文因此提出：

$$
\boxed{
A_D(t)
}
$$

作為 domain adequacy 的研究量。

它不一定是一個 scalar。

至少應回答：

- observed evidence 是否落在 predictive support；
- verifier contradiction 是否大量累積；
- unknown class 是否持續增加；
- current ontology 是否能解釋 interventions；
- reconstruction triggers 是否持續出現。

---

# 64. Probability Calibration 不等於 Domain Calibration

一個 Agent 在錯誤 hypothesis space 內可以非常 calibration-like。

但：

$$
\boxed{
\text{well-calibrated beliefs within wrong ontology}
}
$$

仍然可能錯。

因此未來需要區分：

$$
\boxed{
\text{probability calibration}
}
$$

與：

$$
\boxed{
\text{domain adequacy}.
}
$$

---

# 65. 這對 AI Research Benchmark 的直接意義

AER-Bench 不應只問：

> Agent 最後答對了嗎？

還可以問：

1. 初始 domain 猜錯時能否發現？
2. exact contradiction 後是否淘汰？
3. zero-support crisis 後是否 rebuild？
4. 是否設計 discriminating experiment？
5. 是否保存 evidence pointer？
6. 是否在 domain change 後正確重建 probability state？

這比 final-answer accuracy 更接近真實研究能力。

---

# 66. 這對自指系列的意義

SEHTS-01 說：

$$
\boxed{
\text{artifact can become future evidence}.
}
$$

SEHTS-02 進一步說：

$$
\boxed{
\text{future evidence can change the domain on which future probabilities are defined}.
}
$$

因此兩篇接成：

$$
\boxed{
\text{Generation}
\rightarrow
\text{History}
\rightarrow
\text{Domain Reconstruction}.
}
$$

---

# 67. 歷史文件也可以觸發 Zero-Support Crisis

例如 future Agent 讀到一篇舊 paper：

$$
D.
$$

其中包含一個經 exact verifier 支持的 counterexample。

若 Agent 當前：

$$
\mathcal H_t
$$

所有 hypotheses 都與 counterexample 衝突，

則 historical artifact 也可以觸發：

$$
\boxed{
\mathrm{RECONSTRUCT\_DOMAIN}.
}
$$

所以 fresh evidence 不必永遠是「剛剛才測出的」。

對新 Agent 而言，可靠 historical evidence 也可以是 fresh-to-agent。

---

# 68. Fresh-to-World 與 Fresh-to-Agent

本文分：

## Fresh-to-World

新 experiment 第一次產生的 evidence。

## Fresh-to-Agent

evidence 過去已存在，但目前 Agent 此前不可讀取。

兩者 epistemic role 不完全相同。

benchmark 若要防 memorization，通常更偏好 fresh-to-world 或 target-local mutation。

---

# 69. Probability of Hypotheses 與 Probability of Evidence

需要區分：

$$
P_t(h)
$$

和：

$$
P(e\mid h,a).
$$

前者是 belief state。

後者是 predictive model。

如果 hypothesis domain 變了：

$$
h
rightarrow
h',
$$

兩者都可能需要重建。

所以 domain reconstruction 不只改 posterior support。

它也可能改 likelihood model。

---

# 70. Probability of Actions

Agent policy：

$$
\pi_t(a\mid\mathcal S_t)
$$

又是第三種概率。

因此至少有：

$$
\boxed{
P_{\mathrm{belief}},
\quad
P_{\mathrm{evidence}},
\quad
P_{\mathrm{action}}.
}
$$

它們不能因都叫 probability 就混為同一個 random variable。

這正是 UJDPF typing 的價值。

---

# 71. Probability 的功能分工

本文因此把 probability roles 分成：

## Belief Probability

對 hypotheses。

## Predictive Probability

對 observations。

## Proposal Probability

對 candidate hypotheses / actions。

## Sampling Probability

對 generator outputs。

## Success Probability

對 task outcomes。

UJDPF 負責使這些 probability statements 不因 notation 相似而失去 domain type。

---

# 72. Deterministic Verifier 的功能分工

Verifier 不一定「產生真理」。

它只在 contract：

$$
\Gamma_V
$$

內回答：

$$
\boxed{
\text{某 claim 是否通過某判定規則}.
}
$$

所以：

$$
\boxed{
\text{exact}
\neq
\text{domain-complete}.
}
$$

例如：

> file hash 相等。

可以 exact。

但不表示：

> 文件理論正確。

---

# 73. World Evidence 的功能分工

environment observation 提供：

$$
\boxed{
\text{generator cannot freely choose}.
}
$$

這種 constraint。

但 interpretation：

$$
o
\rightarrow
\text{semantic claim}
$$

仍可能需要 model。

因此：

$$
\boxed{
\text{external world}
\neq
\text{self-interpreting truth}.
}
$$

---

# 74. Human 仍是可能的 Verifier / Domain Editor

統一系統沒有要求：

$$
\boxed{
\text{完全自動}.
}
$$

human 可以：

- 提供新 hypothesis；
- 重定義 scope；
- 修 verifier；
- reject ontology；
- accept reconstruction；
- change study universe。

所以：

$$
\boxed{
\text{human-in-the-loop}
}
$$

是 unified state-transition system 的合法特例。

---

# 75. Autonomous Scientific Agents 的真正提升點

真正「更自主」不只代表：

$$
\boxed{
\text{模型自己多做幾個 tool calls}.
}
$$

更強是：

$$
\boxed{
\text{能判斷何時 current domain 已經不值得繼續 reweight}.
}
$$

也就是：

$$
\boxed{
\text{model-class self-revision under external evidence}.
}
$$

這才接近 AER 的核心。

---

# 76. 新穎性邊界

本文不宣稱首次提出：

- Bayesian update；
- Bayesian experimental design；
- active learning；
- hypothesis testing；
- falsification；
- model selection；
- scientific agents；
- external verifiers；
- agent memory；
- provenance；
- model-class misspecification；
- hypothesis-space expansion。

本文提出的橋接是：

$$
\boxed{
\text{Fixed-Domain Bayes}
+
\text{Exact Falsification}
+
\text{Domain Reconstruction}
+
\text{UJDPF Witness}
+
\text{Historical Evidence State}.
}
$$

主要新結構候選包括：

1. Unified Epistemic–Probability State $\mathcal S_t$；
2. 三類 update regime；
3. Zero-Support Epistemic Crisis 作為 reconstruction trigger；
4. Evidence-to-Witness Construction；
5. Active Judgment-Domain Reconstruction；
6. provenance-backed probability state；
7. probability–history–domain closed loop。

---

# 77. 本文不證明的事情

本文不證明：

$$
\boxed{
\text{Bayesian inference 無法處理 model expansion}.
}
$$

Bayesian model selection、nonparametrics、hierarchical models 都能處理許多擴張問題。

本文只說：

> 當新 domain / hypothesis structure 未被預先包含或沒有 extension rule 時，舊 $P_t$ 本身不唯一決定新 $P_{t+1}$。

本文也不證明：

$$
\boxed{
\text{deterministic verifier 比 probability 更 fundamental}.
}
$$

只說它在 operational system 中可能具有不同 functional role。

---

# 78. 本文的 Reduction Principle

如果：

- hypothesis space 固定；
- judgment domain 固定；
- likelihood 已知；
- evidence 只重分配 hypothesis weights；

則：

$$
\boxed{
\text{Use Bayes}.
}
$$

不要為了 UJDPF / AER 而把普通 inference 搞複雜。

如果 exact verifier 只淘汰部分 hypotheses：

$$
\boxed{
\text{Use restriction + renormalization}.
}
$$

只有當：

$$
\boxed{
\text{probability carrier / semantics / hypothesis ontology itself changes}
}
$$

才啟用 domain reconstruction。

---

# 79. Bridge Principle

本文最終將接點濃縮成：

$$
\boxed{
\text{Bayes updates probabilities inside a domain;}
}
$$

$$
\boxed{
\text{verifiers can contract the admissible support;}
}
$$

$$
\boxed{
\text{fresh evidence can force reconstruction of the domain itself.}
}
$$

UJDPF 的作用是：

$$
\boxed{
\text{規範 domain change 如何被 typed 與 witnessed}.
}
$$

AER 的作用是：

$$
\boxed{
\text{主動取得足以改變或確認 domain 的 evidence}.
}
$$

PDHES 的作用是：

$$
\boxed{
\text{把 proposal、tool、world、verifier、state 的 functional roles 分開}.
}
$$

SEHTS 的作用是：

$$
\boxed{
\text{讓這些 evidence 與 contradictions 能跨時間持久存在}.
}
$$

---

# 80. 最終閉環

至此，完整 research loop 為：

$$
\boxed{
\begin{array}{c}
\mathfrak D_t
\\
\downarrow
\\
\mathcal H_t,P_t,K_t
\\
\downarrow
\\
\text{Choose Experiment}
\\
\downarrow
\\
a_t
\\
\downarrow
\\
\text{External World}
\\
\downarrow
\\
o_{t+1}
\\
\downarrow
\\
V_t
\\
\downarrow
\\
\mathcal T(e_{t+1})
\\
\downarrow
\\
K_{t+1}
\\
\downarrow
\\
\begin{cases}
\text{Reweight}\\
\text{Contract}\\
\text{Reconstruct}
\end{cases}
\\
\downarrow
\\
\mathfrak D_{t+1},P_{t+1}
\end{array}
}
$$

---

# 81. 結論

本文正式找到 UJDPF 與 AI 認識重構系列之間的數學接點。

它不是一句：

> Probability 之外還有 determinism。

而是：

$$
\boxed{
\text{probability update itself has a domain of validity}.
}
$$

當：

$$
\mathcal H_t,
\mathfrak D_t
$$

固定時，

標準 Bayesian update 完全成立。

當 exact external verifier 淘汰：

$$
\mathcal H_t
$$

的一部分時，

若 survivor mass 為正，

可以表示成：

$$
\boxed{
\text{0/1 likelihood conditioning}.
}
$$

但當 fresh evidence 使所有舊 hypotheses 都失效，

或迫使 representation、semantic partition、event algebra、judgment rules 改變時，

問題就不再只是：

$$
P_t
\rightarrow
P_{t+1}.
$$

而是：

$$
\boxed{
(
\mathfrak D_t,
\mathcal H_t,
P_t
)
\rightarrow
(
\mathfrak D_{t+1},
\mathcal H_{t+1},
P_{t+1}
).
}
$$

此時舊 probability law 一般不唯一決定新-domain probability。

所以需要：

$$
\boxed{
\mathcal W_t.
}
$$

也就是 UJDPF transport witness。

而 AER 的 action、experiment、observation、verifier 與 provenance，

正可以提供：

$$
\boxed{
\mathcal W_t
}
$$

的 empirical basis。

最後，SEHTS-01 讓 evidence 不只是一次性的 observation：

$$
e_t
$$

而可以成為：

$$
\boxed{
\mathcal T_t(e_t)
}
$$

的 persistent historical trace，

進入：

$$
G_{t+1},
K_{t+1}.
$$

所以整個系統最後不是：

$$
\boxed{
P_t
\rightarrow
P_{t+1}.
}
$$

而是：

$$
\boxed{
P_t
\rightarrow
\mathcal H_t
\rightarrow
a_t
\rightarrow
o_{t+1}
\rightarrow
V_t
\rightarrow
\mathcal T_{t+1}
\rightarrow
K_{t+1}
\rightarrow
\mathfrak D_{t+1}
\rightarrow
P_{t+1}.
}
$$

這就是兩套研究真正接上的地方。

**概率負責在當前可表達域中分配 uncertainty。**

**世界與 verifier 負責提供不可由 proposal layer 任意指定的約束。**

**AER 負責主動取得足以區分、淘汰或重構 hypotheses 的 evidence。**

**UJDPF 負責規範 probability 在 domain 變動時如何合法搬運。**

**SEHTS 負責讓這些 epistemic events 形成可跨時間重新使用的歷史。**

因此最終得到的不是：

$$
\boxed{
\text{Probability vs Determinism}.
}
$$

而是：

$$
\boxed{
\text{Dynamic Epistemic–Probabilistic Reconstruction}.
}
$$

這才是下一階段可以繼續展開的真正中樞。

---

# 參考文獻

[1] Walsh, S. N., Wildey, T. M., & Jakeman, J. D. (2018). Optimal Experimental Design Using a Consistent Bayesian Approach. *ASCE-ASME Journal of Risk and Uncertainty in Engineering Systems, Part B: Mechanical Engineering*, 4(1). DOI: 10.1115/1.4037457. Preprint: arXiv:1705.09395.

[2] Lu, C., Lu, C., Lange, R. T., Foerster, J., Clune, J., & Ha, D. (2024). *The AI Scientist: Towards Fully Automated Open-Ended Scientific Discovery*. arXiv:2408.06292.

[3] Novikov, A., et al. (2025). *AlphaEvolve: A coding agent for scientific and algorithmic discovery*. arXiv:2506.13131.

[4] Ghareeb, A. E., et al. (2026). A multi-agent system for automating scientific discovery. *Nature*, 655, 497–505. DOI: 10.1038/s41586-026-10652-y.

[5] Gottweis, J., et al. (2026). Accelerating scientific discovery with Co-Scientist. *Nature*, 655, 487–496. DOI: 10.1038/s41586-026-10644-y.

[6] Huang, J., Chen, X., Mishra, S., Zheng, H. S., Yu, A. W., Song, X., & Zhou, D. (2024). Large Language Models Cannot Self-Correct Reasoning Yet. *ICLR 2024*. arXiv:2310.01798.

[7] Neo.K. (2026). *AI 不只是「概率模型」：從條件生成到概率—確定性混合認識系統*. AI Epistemic Reconstruction Series, Paper 01.

[8] Neo.K. (2026). *同一個 01 並不是同一個語義 01：位元、表示域、定義域與判定域*. AI Epistemic Reconstruction Series, Paper 02.

[9] Neo.K. (2026). *從先驗到未知語義：AI 在半黑箱環境中的主動認識重構*. AI Epistemic Reconstruction Series, Paper 03.

[10] Neo.K. (2026). *世界會反駁 AI：外部約束推理、假說淘汰與可證偽 Agent*. AI Epistemic Reconstruction Series, Paper 04.

[11] Neo.K. (2026). *從十二小時到幾 KB：Evidence Explosion 與 Long-Horizon AI Research 的語義再壓縮*. AI Epistemic Reconstruction Series, Paper 05.

[12] Neo.K. (2026). *超概率統一框架：判定域、尺度、時間、遞歸階與傳輸見證的公理化*. JDPSP-09 / UJDPF.

[13] Neo.K. (2026). *被概率描述的存在書寫概率：自指生成、歷史固化與認識域重構*. SEHTS-01.

---

# Appendix A. Unified State Schema

```text
epistemic_probability_state:
  state_id:
  time:

  judgment_domain:
    reference_scope:
    scale:
    context:
    carrier:
    event_ontology:

  hypothesis_space:
    version:
    hypotheses:

  probability_state:
    measure:
    role:
      belief
      predictive
      proposal
      action
    normalization_status:

  canonical_epistemic_state:
    verified:
    invalidated:
    unknown:
    excluded:
    current_frontier:

  history:
    provenance_graph:
    contradiction_ledger:
    evidence_store:
```

# Appendix B. Transition Schema

```text
transition:
  source_state:
  target_state:

  action:
    id:
    selection_policy:
    expected_gain:
    cost:

  observation:
    raw_pointer:
    scope:
    environment:

  verifier:
    contract:
    result:
    strength:

  update_mode:
    reweight
    contract
    reconstruct

  probability_update:
    likelihood:
    posterior:
    surviving_mass:

  domain_change:
    hypothesis_space_changed:
    carrier_changed:
    event_ontology_changed:
    semantic_mapping_changed:
    judgment_rule_changed:

  transport_witness:
    judgment_translation:
    formal_transport:
    assumptions:
    provenance:

  historical_trace:
    evidence_hash:
    timestamp_status:
    contradiction_pointer:
```

# Appendix C. Reconstruction Triggers

```text
RECONSTRUCT_DOMAIN if any:
  - posterior_normalizer_is_zero
  - strong_verifier_eliminates_all_current_hypotheses
  - repeated_observations_outside_predictive_support
  - representation_tests_incompatible_with_current_semantics
  - event_ontology_cannot_type_new_observation
  - confirmed_scope_or_version_mutation
```

# Appendix D. Bridge Map

```text
UJDPF:
  contributes:
    judgment typing
    probability integrity
    witnessed transport
    globality
    probability order

PDHES:
  contributes:
    probabilistic generator
    tool system
    external environment
    persistent state
    verifier
    control policy

AER:
  contributes:
    hypothesis space
    action selection
    fresh evidence
    discriminating experiment
    epistemic update
    domain reconstruction

SEHTS:
  contributes:
    historical trace
    provenance persistence
    contradiction persistence
    cross-session evidence

Unified loop:
  probability
  -> hypothesis
  -> action
  -> world observation
  -> verifier
  -> historical trace
  -> epistemic state
  -> judgment domain
  -> probability
```
