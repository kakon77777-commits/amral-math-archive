# SDPE Blind Enclosure Benchmark v0.1
## Instrumented Commit–Reveal Trial for Spatial-Domain Proof Enclosure

**Version:** v0.1  
**Date:** 2026-08-14  
**Status:** Phase-I benchmark / instrumented routing trial  
**Compatible runtime:** `sdpe-runtime-v1`

---

## 1. 目的

SDPE-BEB v0.1 不直接測試「AI 是否能自行發明未知數學定理」。第一輪先隔離並測試下列較底層命題：

1. survivor envelope 是否只由可驗證 cut 收縮；
2. bridge / representation route 是否能在有限 budget 下改變 closure efficiency；
3. immediate bulk yield 是否會在 global-cycle / exceptional-core 類問題上失敗；
4. blind oracle commitment 是否能在研究結束後獨立開封；
5. false closure 是否能保持為零；
6. routing policy 的差異是否能被可重播地量測。

因此 v0.1 是 **instrumented blind trial**，不是 Strong-DVI 或 autonomous theorem-discovery 的最終實驗。

---

## 2. Blindness 模型

每個 task 都有 hidden oracle payload：

$$
O_i
=
\langle
truth_i,
count_i,
witness_i,
hash_i
\rangle.
$$

生成時另外建立 private nonce $r_i$，公開：

$$
\boxed{
C_i
=
SHA256(
CanonicalJSON(O_i)
\Vert
r_i
).
}
$$

研究側只取得：

- public problem；
- action interface；
- cost / dependency metadata；
- oracle commitment $C_i$。

研究完成後才取得 $O_i,r_i$，並驗證 commitment。

### 重要限制

v0.1 的 blindness 是**程序性隔離**，不是對惡意 participant 的 cryptographic secrecy。有限 instance 本身公開，因此一個刻意繞過協議、直接執行 unrestricted exhaustive solver 的 participant 仍可能重新算出答案。

正確使用方式是：

$$
\boxed{
\text{Public Bundle 給研究 Agent；Oracle Bundle 由另一個 process / 人保管。}
}
$$

---

## 3. 問題語義

每個 Boolean task 有 premise family：

$$
\mathcal P_i
=
\{P_{i,1},\ldots,P_{i,m}\}.
$$

公開 claim 為：

$$
\boxed{
\neg\exists x\in\{0,1\}^{n_i}
\quad
\bigwedge_jP_{i,j}(x).
}
$$

因此 counterexample set 為：

$$
\boxed{
\mathcal C_i
=
\{x:\forall j,
P_{i,j}(x)
\}.
}
$$

研究 runtime 從：

$$
\Omega_0
=
\{0,1\}^{n_i}
$$

開始。合法 cut $H_a$ 必須是所有真 counterexamples 的必要條件，並更新：

$$
\boxed{
\Omega_{t+1}
=
\Omega_t\cap H_a.
}
$$

若：

$$
\Omega_T=\varnothing,
$$

則 public route 本身已形成 finite closure certificate；hidden oracle 只負責事後獨立核對 ground truth，而不是賦予 closure 合法性。

---

## 4. 三個 family

### 4.1 Easy Debug

20 題。

用途：

- 基本 direct cut；
- contradiction closure；
- SAT-control 防止 false closure；
- runner / certificate / commitment debugging。

### 4.2 Structured Parity Cycle

20 題。

核心為 inconsistent parity cycle。local parity edges 本身看似一致，但整個 cycle 具有 global obstruction。

除 direct edge cuts 外，另提供：

$$
\boxed{
\text{bridge}
\to
\text{cycle-global derived closure cut}.
}
$$

budget 為 3，因此純 immediate-yield routing 通常無法完成全部 local cuts；bridge-aware lookahead 則可用 global route 在 budget 內 closure。

此 family 對應 SDPE 的：

- local-to-global；
- gluing / cycle obstruction；
- bridge theorem value；
- routing complementarity。

### 4.3 Exceptional-Core Trap

20 題。

大量 bulk constraints 將候選域導向一個極小 core；真正 closure 還需要 core-killer。

另提供：

$$
\boxed{
\text{representation bridge}
\to
\text{aggregate theorem}
\to
\text{core killer}.
}
$$

其中 bridge 本身 immediate exclusion yield 為零，而 core-killer 在完整初始域上的 global yield 極小。

此 family 專門測試：

$$
\boxed{
\text{largest immediate volume cut}
\not\Rightarrow
\text{highest closure value}.
}
$$

---

## 5. Action authority

v0.1 action 分成：

### Direct cut

直接引用 problem premise，certificate 為 `premise_identity`。

### Derived cut

不是原始 premise，而攜帶 dependency list，使用 finite entailment checker 驗證：

$$
\boxed{
\bigwedge_{d\in Deps(a)}d
\Longrightarrow
H_a.
}
$$

### Bridge

bridge 本身沒有 proof authority，也不直接縮 survivor：

$$
\boxed{
\Omega_{t+1}=\Omega_t.
}
$$

它只改變 route graph，unlock 後續 derived action。

因此：

$$
\boxed{
\text{route update}
\neq
\text{proof-state contraction}.
}
$$

---

## 6. 第一批資料集

固定 dataset fingerprint：

`682829c39270d69336f174b286e5e24a38013bff0179254daf0f5553aae70a08`

總數：60。

公開 bundle 不揭露逐題真值，也不揭露 truth distribution。

Oracle reveal 後，本批資料為：

- 50 個 true UNSAT claims；
- 10 個 SAT controls。

SAT controls 的主要任務不是要求 router 在 budget 內找到 witness，而是確認 sound cut system 不會產生 false closure。

---

## 7. Baseline policies

### Random

從目前 unlocked actions 隨機選擇。

### Myopic Yield

選擇：

$$
\boxed{
\frac{
|\Omega_t|-|\Omega_t\cap H_a|
}{
C(a)
}
}
$$

最大的 action。

bridge immediate yield 為零，因此此 policy 天生可能忽略 route-unlocking action。

### Lookahead-3

在 depth 3 action tree 上，以 closure 為最高優先，否則比較最終 survivor size 與 modeled cost。

這不是聲稱「lookahead-3 是 SDPE 最佳 router」，它只是第一個用來測試 bridge / complementarity 的 control policy。

---

## 8. 第一輪 baseline 結果

### True-closure rate on 50 UNSAT cases

- Random: $16/50=32\%$；
- Myopic Yield: $15/50=30\%$；
- Lookahead-3: $50/50=100\%$。

所有 policies：

$$
\boxed{
\text{false closure}=0/10
}
$$

於 SAT controls 上均未錯誤宣告 closure。

### Family breakdown

#### Easy Debug

三者皆：

$$
15/15
$$

true UNSAT cases closure。

#### Structured Parity Cycle

- Random: $1/20$；
- Myopic Yield: $0/20$；
- Lookahead-3: $20/20$。

#### Exceptional-Core Trap

- Random: $0/15$；
- Myopic Yield: $0/15$；
- Lookahead-3: $15/15$。

這個結果是**benchmark construction 的 sanity test**，不能外推為「lookahead 一般數學研究優於 greedy」。它只證明 v0.1 已成功製造出預期的 bridge / exceptional-core routing stress regime，且 instrumentation 能捕捉差異。

---

## 9. v0.1 能證什麼／不能證什麼

### 能測

- certificate-gated contraction；
- route dependency；
- bridge value；
- global-cycle closure；
- exceptional-core trap；
- budgeted routing；
- commitment opening；
- false-closure rate；
- deterministic replay。

### 不能測

v0.1 **不能**直接證明：

$$
\boxed{
D_t^{\rm frontier}\downarrow.
}
$$

因為 derived action family 已由 benchmark 提供，沒有要求研究 Agent 從 statement-only 狀態自己發明 theorem language。

因此下一版本的自然升級為：

$$
\boxed{
\textbf{BEB v0.2 — Hidden-Action / Theorem-Discovery Track}.
}
$$

屆時只提供 problem statement、verifier interface 與 route budget；derived cuts 必須由 participant 自行提出，經 checker 接受後才能進入 action pool。
