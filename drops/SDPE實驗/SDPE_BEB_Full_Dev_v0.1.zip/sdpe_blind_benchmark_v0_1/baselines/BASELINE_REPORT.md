# SDPE-BEB v0.1 Baseline Report

**Dataset:** `sdpe-beb-v0.1`  
**Fingerprint:** `682829c39270d69336f174b286e5e24a38013bff0179254daf0f5553aae70a08`

## Oracle reveal composition

- True UNSAT claims: 50
- SAT controls: 10

## Closure results under task budget

| Policy | True closures / 50 UNSAT | Rate | False closures / 10 SAT controls |
|---|---:|---:|---:|
| Random | 16 | 32% | 0 |
| Myopic Yield | 15 | 30% | 0 |
| Lookahead-3 | 50 | 100% | 0 |

## Family breakdown

| Family | UNSAT cases | Random | Myopic Yield | Lookahead-3 |
|---|---:|---:|---:|---:|
| Easy Debug | 15 | 15 | 15 | 15 |
| Structured Parity Cycle | 20 | 1 | 0 | 20 |
| Exceptional-Core Trap | 15 | 0 | 0 | 15 |

## Interpretation boundary

This result is a benchmark-construction sanity check. The structured and exceptional-core families were intentionally designed so that a zero-immediate-yield bridge can unlock a short closure route. Therefore the result demonstrates that the instrumentation distinguishes myopic bulk-yield routing from bounded lookahead on the intended stress cases.

It does **not** establish that lookahead-3 is generally optimal, that SDPE accelerates unknown theorem discovery, or that Strong DVI holds in open mathematics.
