#!/usr/bin/env python3
from __future__ import annotations
from common import sat_pred,sha_text,canon

def exact_oracle(task):
    preds=[p['predicate'] for p in task['premises']]
    surv=[x for x in range(1<<task['n_vars']) if all(sat_pred(x,p) for p in preds)]
    return {'claim_truth':not surv,'survivor_count':len(surv),'witness':None if not surv else surv[0],'survivors_sha256':sha_text(canon(surv))}
