#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,random
from pathlib import Path
from functools import lru_cache
from common import action_map,action_predicate,sat_pred,total_cost,replay
CLOSURE_BONUS=10**12

def compile_task(task):
    amap=action_map(task); n=task['n_vars']; full=(1<<(1<<n))-1
    masks={}
    for aid,a in amap.items():
        pred=action_predicate(task,a)
        if pred is None:
            masks[aid]=full
        else:
            m=0
            for x in range(1<<n):
                if sat_pred(x,pred): m |= 1<<x
            masks[aid]=m
    return amap,masks,full

def available(amap, used, unlocked):
    return [a for aid,a in amap.items() if aid not in used and aid in unlocked and all(r in used for r in a.get('requires',[]))]

def transition(surv,used,unlocked,a,masks):
    ns=surv & masks[a['action_id']]
    nu=frozenset(set(used)|{a['action_id']})
    nl=frozenset(set(unlocked)|set(a.get('unlocks',[])))
    return ns,nu,nl

def choose_myopic(amap,masks,surv,used,unlocked):
    acts=available(amap,used,unlocked); scored=[]; before=surv.bit_count()
    for a in acts:
        after=(surv & masks[a['action_id']]).bit_count(); gain=before-after
        scored.append((gain/max(total_cost(a),1e-9),gain,-total_cost(a),a['action_id']))
    return amap[max(scored)[-1]] if scored else None

def best_seq(amap,masks,surv,used,unlocked,depth):
    @lru_cache(None)
    def rec(surv_i, used_t, unlocked_t, d):
        used=frozenset(used_t); unlocked=frozenset(unlocked_t)
        if surv_i==0: return (CLOSURE_BONUS,())
        if d==0: return (-surv_i.bit_count(),())
        best=(-10**30,())
        for a in available(amap,used,unlocked):
            ns,nu,nl=transition(surv_i,used,unlocked,a,masks)
            cs,seq=rec(ns,tuple(sorted(nu)),tuple(sorted(nl)),d-1)
            score=cs-0.001*total_cost(a)
            if score>best[0]: best=(score,(a['action_id'],)+seq)
        return best
    return rec(surv,tuple(sorted(used)),tuple(sorted(unlocked)),depth)

def run_policy(task,policy,seed):
    rng=random.Random(seed); amap,masks,surv=compile_task(task); used=frozenset(); unlocked=frozenset(task['initially_unlocked']); selected=[]
    for _ in range(task['budget']):
        if surv==0: break
        acts=available(amap,used,unlocked)
        if not acts: break
        if policy=='random': a=rng.choice(acts)
        elif policy=='myopic_yield': a=choose_myopic(amap,masks,surv,used,unlocked)
        elif policy=='lookahead3':
            _,seq=best_seq(amap,masks,surv,used,unlocked,3)
            a=amap[seq[0]] if seq else None
        else: raise ValueError(policy)
        if a is None: break
        selected.append(a['action_id']); surv,used,unlocked=transition(surv,used,unlocked,a,masks)
    rr=replay(task,selected)
    return {'task_id':task['task_id'],'policy':policy,'selected_actions':selected,'declared_closed':rr['closed'],'declared_counterexample':False,'final_survivor_size':rr['final_survivor_size'],'model_cost':rr['model_cost']}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--tasks-dir',required=True); ap.add_argument('--out-dir',required=True); a=ap.parse_args(); td=Path(a.tasks_dir); od=Path(a.out_dir); od.mkdir(parents=True,exist_ok=True)
    tasks=[json.loads(p.read_text(encoding='utf-8')) for p in sorted(td.glob('*.json'))]
    for pol in ['random','myopic_yield','lookahead3']:
        with (od/f'submissions_{pol}.jsonl').open('w',encoding='utf-8') as f:
            for i,t in enumerate(tasks): f.write(json.dumps(run_policy(t,pol,100000+i),ensure_ascii=False,sort_keys=True)+'\n')
if __name__=='__main__': main()
