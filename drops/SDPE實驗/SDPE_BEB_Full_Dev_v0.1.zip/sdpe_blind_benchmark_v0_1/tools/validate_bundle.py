#!/usr/bin/env python3
from __future__ import annotations
import json,hashlib,sys
from pathlib import Path
from jsonschema import Draft202012Validator
from common import canon,sha_text,verify_action_certificate
from oracle_utils import exact_oracle
ROOT=Path(__file__).resolve().parents[1]

def loadj(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def main():
    task_schema=loadj(ROOT/'schemas/task.schema.json'); sub_schema=loadj(ROOT/'schemas/submission.schema.json'); oracle_schema=loadj(ROOT/'schemas/oracle.schema.json')
    vt=Draft202012Validator(task_schema); vo=Draft202012Validator(oracle_schema)
    tasks={}; errors=[]
    for p in sorted((ROOT/'public/tasks').glob('*.json')):
        t=loadj(p); tasks[t['task_id']]=t
        for e in vt.iter_errors(t): errors.append(f'{p.name}: {e.message}')
        ids=[a['action_id'] for a in t['actions']]
        if len(ids)!=len(set(ids)): errors.append(f'{p.name}: duplicate action ids')
        cids=[c['constraint_id'] for c in t['premises']]
        if len(cids)!=len(set(cids)): errors.append(f'{p.name}: duplicate constraint ids')
        for a in t['actions']:
            ok,info=verify_action_certificate(t,a)
            if not ok: errors.append(f"{p.name}: action cert failed {a['action_id']} {info}")
    oracle_lines=[]
    for line in (ROOT/'private_oracle/oracle_answers.jsonl').read_text(encoding='utf-8').splitlines():
        if line.strip(): oracle_lines.append(json.loads(line))
    for o in oracle_lines:
        for e in vo.iter_errors(o): errors.append(f"oracle {o.get('task_id')}: {e.message}")
        t=tasks[o['task_id']]
        com=sha_text(canon(o['oracle'])+'|'+o['nonce'])
        if com!=o['commitment'] or com!=t['oracle_commitment']['commitment']: errors.append(f"commit mismatch {o['task_id']}")
        ex=exact_oracle(t)
        for k in ['claim_truth','survivor_count','witness','survivors_sha256']:
            if ex[k]!=o['oracle'][k]: errors.append(f"oracle mismatch {o['task_id']} {k}")
    report={'dataset_version':'sdpe-beb-v0.1','task_count':len(tasks),'oracle_count':len(oracle_lines),'errors':errors,'pass':not errors,'validated_action_certificates':sum(len(t['actions']) for t in tasks.values()),'commitments_verified':len(oracle_lines)}
    (ROOT/'VALIDATION_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2)); return 0 if not errors else 1
if __name__=='__main__': raise SystemExit(main())
