#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, random, secrets, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / 'public'
ORACLE = ROOT / 'private_oracle'
TASKS = PUBLIC / 'tasks'
SCHEMAS = ROOT / 'schemas'
BASELINES = ROOT / 'baselines'

MASTER_SEED = 2026081401
DATASET_VERSION = 'sdpe-beb-v0.1'


def canon(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def sha_text(s: str) -> str:
    return hashlib.sha256(s.encode('utf-8')).hexdigest()


def parity(x: int) -> int:
    return x.bit_count() & 1


def sat_pred(a: int, pred: dict) -> bool:
    k = pred['kind']
    if k == 'bit_equals':
        return ((a >> pred['var']) & 1) == pred['value']
    if k == 'mask_equals':
        return (a & pred['mask']) == pred['pattern']
    if k == 'parity':
        mask = 0
        for v in pred['vars']:
            mask |= 1 << v
        return parity(a & mask) == pred['value']
    if k == 'forbid_assignment':
        return a != pred['assignment']
    if k == 'false':
        return False
    if k == 'true':
        return True
    raise ValueError(k)


def solve_task(task: dict) -> dict:
    n = task['n_vars']
    premises = [p['predicate'] for p in task['premises']]
    survivors = [a for a in range(1 << n) if all(sat_pred(a, p) for p in premises)]
    payload = {
        'task_id': task['task_id'],
        'claim': 'UNSAT',
        'claim_truth': len(survivors) == 0,
        'survivor_count': len(survivors),
        'witness': None if not survivors else survivors[0],
        'survivors_sha256': sha_text(canon(survivors)),
        'oracle_method': 'exact_enumeration',
        'search_space_size': 1 << n,
    }
    return payload


def mk_direct_action(cid, idx, tag='direct'):
    return {
        'action_id': f'A_DIRECT_{idx:02d}',
        'action_type': 'cut',
        'requires': [],
        'unlocks': [],
        'predicate_source': {'kind': 'premise', 'constraint_id': cid},
        'certificate': {'kind': 'premise_identity', 'dependencies': [cid]},
        'cost': {'discover': 1.0, 'verify': 1.0, 'coverage': 0.1, 'maintain': 0.05},
        'tags': [tag],
    }


def make_easy(rng: random.Random, idx: int, sat_control: bool) -> dict:
    n = 10
    secret = rng.randrange(1 << n)
    premises = []
    used = []
    vars_ = list(range(n)); rng.shuffle(vars_)
    for j, v in enumerate(vars_[:5]):
        val = (secret >> v) & 1
        cid = f'C{len(premises):02d}'
        premises.append({'constraint_id': cid, 'predicate': {'kind': 'bit_equals', 'var': v, 'value': val}})
        used.append((v, val))
    # two parity constraints consistent with secret
    for _ in range(2):
        vs = sorted(rng.sample(range(n), 3))
        val = parity(sum(((secret >> v) & 1) << k for k, v in enumerate(vs)))
        # parity() above is on compacted bits; easier compute directly
        val = sum((secret >> v) & 1 for v in vs) & 1
        cid = f'C{len(premises):02d}'
        premises.append({'constraint_id': cid, 'predicate': {'kind': 'parity', 'vars': vs, 'value': val}})
    if not sat_control:
        v, val = used[0]
        cid = f'C{len(premises):02d}'
        premises.append({'constraint_id': cid, 'predicate': {'kind': 'bit_equals', 'var': v, 'value': 1-val}})
    actions = [mk_direct_action(p['constraint_id'], i, 'debug') for i, p in enumerate(premises)]
    rng.shuffle(actions)
    return {
        'schema_version': DATASET_VERSION,
        'task_id': f'EASY-{idx:03d}',
        'family': 'easy_debug',
        'n_vars': n,
        'public_claim': 'No Boolean assignment satisfies all listed premises.',
        'premises': premises,
        'actions': actions,
        'initially_unlocked': [a['action_id'] for a in actions],
        'budget': len(actions),
        'telemetry_mode': 'exact_finite_survivor',
        'protocol_note': 'Instrumented SDPE routing task. Do not use a separate exact oracle during the blind run.',
    }


def make_structured(rng: random.Random, idx: int) -> dict:
    n = 12
    bits = [rng.randint(0,1) for _ in range(n-1)]
    last = (sum(bits) & 1) ^ 1  # odd XOR around cycle => inconsistent
    bits.append(last)
    premises = []
    for i in range(n):
        j = (i+1) % n
        cid = f'C{i:02d}'
        premises.append({'constraint_id': cid, 'predicate': {'kind': 'parity', 'vars': [i,j], 'value': bits[i]}})
    actions = [mk_direct_action(p['constraint_id'], i, 'cycle-edge') for i,p in enumerate(premises)]
    bridge_id = 'A_BRIDGE_CYCLE'
    close_id = 'A_DERIVED_CYCLE_CLOSE'
    actions += [
        {
            'action_id': bridge_id,
            'action_type': 'bridge',
            'requires': [],
            'unlocks': [close_id],
            'predicate_source': None,
            'certificate': {'kind': 'route_bridge', 'dependencies': []},
            'cost': {'discover': 1.5, 'verify': 0.5, 'coverage': 0.0, 'maintain': 0.1},
            'tags': ['bridge', 'global-cycle'],
        },
        {
            'action_id': close_id,
            'action_type': 'cut',
            'requires': [bridge_id],
            'unlocks': [],
            'predicate_source': {'kind': 'inline', 'predicate': {'kind': 'false'}},
            'certificate': {'kind': 'finite_entailment', 'dependencies': [p['constraint_id'] for p in premises]},
            'cost': {'discover': 2.0, 'verify': 4.0, 'coverage': 0.2, 'maintain': 0.1},
            'tags': ['derived', 'global-cycle', 'closure-critical'],
        }
    ]
    return {
        'schema_version': DATASET_VERSION,
        'task_id': f'PARITY-{idx:03d}',
        'family': 'structured_parity_cycle',
        'n_vars': n,
        'public_claim': 'No Boolean assignment satisfies all parity-cycle premises.',
        'premises': premises,
        'actions': actions,
        'initially_unlocked': [a['action_id'] for a in actions if not a['requires']],
        'budget': 3,
        'telemetry_mode': 'exact_finite_survivor',
        'protocol_note': 'Bridge action models a global-cycle theorem route; the derived cut must pass finite entailment checking.',
    }


def make_exceptional(rng: random.Random, idx: int, sat_control: bool) -> dict:
    n = 14
    secret = rng.randrange(1 << n)
    premises = []
    unit_ids = []
    for v in range(n):
        cid = f'C{v:02d}'
        unit_ids.append(cid)
        premises.append({'constraint_id': cid, 'predicate': {'kind': 'bit_equals', 'var': v, 'value': (secret >> v) & 1}})
    core_id = None
    if not sat_control:
        core_id = f'C{len(premises):02d}'
        premises.append({'constraint_id': core_id, 'predicate': {'kind': 'forbid_assignment', 'assignment': secret}})
    actions = [mk_direct_action(cid, i, 'bulk-bit') for i,cid in enumerate(unit_ids)]
    if core_id:
        core_action = mk_direct_action(core_id, len(actions), 'exceptional-core')
        core_action['action_id'] = 'A_CORE_KILLER'
        core_action['cost'] = {'discover': 2.5, 'verify': 2.5, 'coverage': 0.2, 'maintain': 0.1}
        core_action['tags'] = ['exceptional-core', 'closure-critical', 'tiny-global-yield']
        actions.append(core_action)
    bridge_id = 'A_BRIDGE_AGGREGATE'
    agg_id = 'A_DERIVED_AGGREGATE'
    full_mask = (1 << n) - 1
    actions += [
        {
            'action_id': bridge_id,
            'action_type': 'bridge',
            'requires': [],
            'unlocks': [agg_id],
            'predicate_source': None,
            'certificate': {'kind': 'route_bridge', 'dependencies': []},
            'cost': {'discover': 1.5, 'verify': 0.5, 'coverage': 0.0, 'maintain': 0.1},
            'tags': ['bridge', 'representation-refinement'],
        },
        {
            'action_id': agg_id,
            'action_type': 'cut',
            'requires': [bridge_id],
            'unlocks': [],
            'predicate_source': {'kind': 'inline', 'predicate': {'kind': 'mask_equals', 'mask': full_mask, 'pattern': secret}},
            'certificate': {'kind': 'finite_entailment', 'dependencies': unit_ids},
            'cost': {'discover': 2.0, 'verify': 3.0, 'coverage': 0.2, 'maintain': 0.1},
            'tags': ['derived', 'aggregate', 'core-localizer'],
        }
    ]
    return {
        'schema_version': DATASET_VERSION,
        'task_id': f'CORE-{idx:03d}',
        'family': 'exceptional_core_trap',
        'n_vars': n,
        'public_claim': 'No Boolean assignment satisfies all listed premises.',
        'premises': premises,
        'actions': actions,
        'initially_unlocked': [a['action_id'] for a in actions if not a['requires']],
        'budget': 3,
        'telemetry_mode': 'exact_finite_survivor',
        'protocol_note': 'The aggregate theorem is locked behind a representation bridge. Myopic bulk-yield routing is expected to be vulnerable.',
    }


def add_commitment(task: dict, payload: dict, rng: random.Random) -> tuple[dict,dict]:
    # Deterministic nonce for reproducible dataset generation; kept only in private oracle bundle.
    nonce = ''.join(f'{rng.getrandbits(8):02x}' for _ in range(32))
    commitment = sha_text(canon(payload) + '|' + nonce)
    pub = dict(task)
    pub['oracle_commitment'] = {
        'scheme': 'sha256(canonical_oracle_json|nonce)',
        'commitment': commitment,
    }
    priv = {'task_id': task['task_id'], 'oracle': payload, 'nonce': nonce, 'commitment': commitment}
    return pub, priv


def main():
    rng = random.Random(MASTER_SEED)
    TASKS.mkdir(parents=True, exist_ok=True)
    ORACLE.mkdir(parents=True, exist_ok=True)
    tasks=[]; oracles=[]
    # 20 easy: 15 UNSAT + 5 SAT controls
    sat_easy = set(rng.sample(range(20),5))
    for i in range(20):
        t=make_easy(rng,i,i in sat_easy); o=solve_task(t); t,o2=add_commitment(t,o,rng); tasks.append(t); oracles.append(o2)
    # 20 parity, all UNSAT
    for i in range(20):
        t=make_structured(rng,i); o=solve_task(t); t,o2=add_commitment(t,o,rng); tasks.append(t); oracles.append(o2)
    # 20 core: 15 UNSAT + 5 SAT controls
    sat_core = set(rng.sample(range(20),5))
    for i in range(20):
        t=make_exceptional(rng,i,i in sat_core); o=solve_task(t); t,o2=add_commitment(t,o,rng); tasks.append(t); oracles.append(o2)
    for t in tasks:
        (TASKS/f"{t['task_id']}.json").write_text(json.dumps(t,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    with (PUBLIC/'task_index.jsonl').open('w',encoding='utf-8') as f:
        for t in tasks:
            f.write(canon({'task_id':t['task_id'],'family':t['family'],'budget':t['budget'],'n_vars':t['n_vars'],'commitment':t['oracle_commitment']['commitment']})+'\n')
    with (ORACLE/'oracle_answers.jsonl').open('w',encoding='utf-8') as f:
        for o in oracles: f.write(canon(o)+'\n')
    truth_counts={}
    for o in oracles:
        key='UNSAT' if o['oracle']['claim_truth'] else 'SAT_CONTROL'
        truth_counts[key]=truth_counts.get(key,0)+1
    manifest={
        'dataset_version':DATASET_VERSION,
        'task_count':len(tasks),
        'families':{fam:sum(t['family']==fam for t in tasks) for fam in sorted(set(t['family'] for t in tasks))},
        'commitment_scheme':'sha256(canonical_oracle_json|nonce)',
        'sdpe_runtime_compatibility':'sdpe-runtime-v1',
        'protocol_warning':'Blindness is procedural, not cryptographic against a participant that deliberately runs an unrestricted exact solver on the finite public instance.',
    }
    manifest['dataset_fingerprint']=sha_text(canon([t['oracle_commitment']['commitment'] for t in tasks]))
    (PUBLIC/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    om={'dataset_version':DATASET_VERSION,'dataset_fingerprint':manifest['dataset_fingerprint'],'task_count':len(oracles),'opening_file':'oracle_answers.jsonl','truth_counts_after_reveal':truth_counts,'dev_generator_seed':MASTER_SEED}
    (ORACLE/'ORACLE_MANIFEST.json').write_text(json.dumps(om,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
