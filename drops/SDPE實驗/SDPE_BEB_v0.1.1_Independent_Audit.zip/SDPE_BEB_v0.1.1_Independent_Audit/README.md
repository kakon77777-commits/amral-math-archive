# SDPE-BEB v0.1.1 Independent Audit Evidence

Independent checks performed against the supplied v0.1.1 Repair and NeutralVariant release pack.

Key result: the v0.1 single-case authority bugs are repaired, and the Neutral Variant removes the old coarse label leakage. A remaining evaluator-level integrity gap exists: `audit_reveal.py` does not enforce exactly one schema-valid submission for every expected task. Missing tasks, duplicate task IDs, and schema-required-field omissions are therefore not rejected at the dataset-set level.

The evidence directory contains fresh audit outputs and minimal submissions reproducing the remaining issue.
