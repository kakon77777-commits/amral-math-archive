# SDPE-BEB Public v0.1 Structural Research Report

## 1. Executive result

This public bundle is internally coherent as an **instrumented routing / enclosure benchmark**, but it is not yet a hard theorem-discovery benchmark. A structure-aware participant can solve the entire public set without an unrestricted exhaustive ground-truth oracle.

The 60 public tasks decompose as

$$
20\;\text{{EASY}}+20\;\text{{CORE}}+20\;\text{{PARITY}}.
$$

Structural classification gives

$$
\text{{EASY}}=15\;\mathrm{{UNSAT}}+5\;\mathrm{{SAT}},
$$

$$
\text{{CORE}}=15\;\mathrm{{UNSAT}}+5\;\mathrm{{SAT}},
$$

$$
\text{{PARITY}}=20\;\mathrm{{UNSAT}}.
$$

Hence

$$
\boxed{{50\;\mathrm{{UNSAT}}+10\;\mathrm{{SAT}}}}.
$$

The structure-aware SDPE route closes all 50 UNSAT instances within action budget and produces validated witnesses for all 10 SAT instances.

## 2. Mathematical skeleton

### 2.1 EASY family

All predicates are affine equations over $\mathbb F_2$: `bit_equals` and `parity`.

For every one of the 15 UNSAT EASY instances, the contradiction is already a two-constraint core:

$$
x_j=0,\qquad x_j=1.
$$

Concretely, the contradictory pair is always `C00` versus `C07`. Therefore a two-action direct-cut route is sufficient.

The five SAT EASY tasks are:

`EASY-000`, `EASY-008`, `EASY-010`, `EASY-012`, `EASY-019`.

For them, Gaussian elimination over $\mathbb F_2$ yields explicit satisfying assignments, which are independently checked against every public premise.

### 2.2 PARITY family

Each task is a parity cycle

$$
x_i\oplus x_{{i+1}}=b_i.
$$

XOR all cycle equations. Every variable occurs exactly twice, so the left side cancels:

$$
\bigoplus_i(x_i\oplus x_{{i+1}})=0.
$$

In all 20 public PARITY tasks,

$$
\bigoplus_i b_i=1,
$$

hence

$$
0=1,
$$

and every instance is UNSAT. The legal benchmark route is

`A_BRIDGE_CYCLE -> A_DERIVED_CYCLE_CLOSE`.

This is the strongest conceptual success of v0.1: a zero-immediate-yield bridge is necessary to expose a global closure route under the small action budget.

### 2.3 CORE family

The first 14 `bit_equals` premises fix all 14 Boolean variables, hence isolate exactly one assignment $p$:

$$
\Omega_{\mathrm{{core}}}=\{{p\}}.
$$

The bridge plus aggregate cut performs this localization:

`A_BRIDGE_AGGREGATE -> A_DERIVED_AGGREGATE`.

For 15 instances there is one additional premise

$$
a\neq p,
$$

represented by `forbid_assignment` and exposed as `A_CORE_KILLER`; these tasks close in the third action. Five tasks omit the killer and are SAT:

`CORE-002`, `CORE-008`, `CORE-012`, `CORE-014`, `CORE-018`.

This family correctly demonstrates why tiny **global** exclusion yield can have maximal **conditional** closure value after localization.

## 3. What v0.1 genuinely demonstrates

The important invariant is sound:

$$
\boxed{{\text{{bridge has routing authority, not proof authority}}}}.
$$

Only certificate-verified cut actions shrink the survivor set. A bridge can unlock a derived route but cannot itself establish closure. This separation is mathematically and architecturally useful.

The benchmark also succeeds at illustrating two non-greedy phenomena:

1. **Bridge value:** an action with zero immediate exclusion can be indispensable to global closure.
2. **Exceptional-core value:** an action with exclusion yield $1/2^n$ can become closure-critical after a representation/localization step.

A local immediate-yield greedy policy closes all 15 UNSAT EASY tasks, but closes **0/20 PARITY** and **0/15 UNSAT CORE** tasks within budget. Thus the benchmark does separate local exclusion greediness from route-aware reasoning.

## 4. Main weaknesses found

### 4.1 Label leakage

The SAT/UNSAT distribution is recoverable from superficial public structure:

- EASY: budget/action count 8 corresponds to the 15 contradictory instances; 7 corresponds to the five SAT instances.
- CORE: presence of `A_CORE_KILLER` corresponds exactly to UNSAT; its absence corresponds exactly to SAT.
- PARITY: all public instances are UNSAT.

Therefore answer classification itself is not blind to metadata, even without solving predicates.

### 4.2 Route leakage

Action names and tags expose intended proof roles almost directly:

- `A_DERIVED_CYCLE_CLOSE`
- `closure-critical`
- `A_CORE_KILLER`
- `core-localizer`
- `A_BRIDGE_AGGREGATE`

This is acceptable for a v0.1 conformance/instrumentation trial, but too strong for a research-routing benchmark.

### 4.3 Finite-entailment verifier is exhaustive

`finite_entailment` currently verifies an entailment by looping over the entire Boolean universe. At $n=12$ or $14$ this is harmless, but it means the compact global proof route is **simulated at the action layer while the verifier still performs exhaustive finite checking**.

For a scalable SDPE benchmark, the certificate should itself be structural. For parity, a certificate can give coefficients $\lambda_i\in\mathbb F_2$ and the verifier checks

$$
\sum_i\lambda_i A_i=0,
\qquad
\sum_i\lambda_i b_i=1,
$$

in polynomial time. For CORE aggregation, the verifier can check that the bit equalities determine the claimed mask/pattern directly.

### 4.4 Action budget and modeled cost are uncoupled

`within_budget` is defined from the number of selected actions, while `model_cost` is only telemetry. Thus the vectors `discover`, `verify`, `maintain`, and `coverage` do not constrain route legality.

This is not necessarily a bug if the two quantities are intentionally different, but v0.2 should explicitly define either

$$
\sum_{{a\in R}} c(a)\le B
$$

or a genuinely multi-resource budget, rather than presenting cost geometry that cannot affect admissibility.

### 4.5 Public runner does not validate declaration semantics

The runner replays selected actions and reports closure, but does not itself reject a mismatch between `declared_closed` and replay result, nor does it validate `declared_counterexample` / `counterexample_assignment`. That may be delegated to the Oracle audit side, but a public `verify-submission` command would make the contract safer and easier to test.

### 4.6 Packaging defects

The fresh archive passes all 73 listed SHA-256 checksums. However:

- `README.md` refers to `docs/SDPE_BEB_v0.1_Experimental_Protocol.md`, which is absent from the bundle.
- the archive includes `tools/__pycache__/common.cpython-313.pyc`; importing the module can regenerate this file and invalidate its checksum. `.pyc` / `__pycache__` should not be shipped in the canonical source package.

## 5. Recommended v0.2 design

The most important upgrade is to separate **conformance**, **routing**, and **discovery** tiers.

### Tier A — Conformance

Keep something close to v0.1. Named actions and obvious tags are acceptable. Goal: verify proof authority, bridge semantics, replay, certificate gates, and telemetry.

### Tier B — Blind routing

Neutralize action IDs/tags, equalize action counts and budgets across SAT/UNSAT instances, add distractor bridges/cuts, and vary graph topology. A route should have to be inferred from dependencies, predicted conditional yield, and certificate structure.

### Tier C — Lemma discovery

Do not provide the decisive derived action. Let the participant propose a derived predicate plus certificate. The verifier checks the certificate. This moves the benchmark from selecting a theorem action to actually discovering a useful lemma.

## 6. Scalable certificate proposal

For affine Boolean constraints, represent each premise as

$$
a_i\cdot x=b_i
\qquad (a_i\in\mathbb F_2^n).
$$

A derived affine cut

$$
a\cdot x=b
$$

can be certified by a coefficient vector $\lambda$ satisfying

$$
a=\sum_i\lambda_i a_i,
\qquad
b=\sum_i\lambda_i b_i.
$$

A contradiction certificate is simply

$$
a=0,
\qquad
b=1.
$$

Verification is polynomial and does not enumerate $2^n$ assignments. This is the natural next bridge between SDPE's route semantics and proof-carrying algebra.

## 7. Final assessment

v0.1 is **not a failure**. Its strongest interpretation is:

$$
\boxed{{\text{{SDPE runtime conformance + non-greedy routing mechanics smoke test}}}}.
$$

Under that interpretation, it works and the two central examples—global parity closure and exceptional-core localization—are well chosen.

But it is too instrumented to support a stronger claim about autonomous theorem discovery, strong blind research routing, or scalable proof compression. The next mathematically meaningful frontier is therefore:

$$
\boxed{{\text{{BEB v0.2: metadata-neutral routing + structural certificates + lemma proposal}}}}.
$$
