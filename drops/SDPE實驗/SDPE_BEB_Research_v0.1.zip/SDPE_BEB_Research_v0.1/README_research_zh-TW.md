# SDPE-BEB Public v0.1 結構研究報告

## 1. 結論

這個 Public Bundle 作為 **instrumented routing / enclosure benchmark** 是成立的，但目前還不是強度足夠的 theorem-discovery blind benchmark。

不使用 unrestricted exhaustive ground-truth oracle，只利用公開約束的代數結構與合法 action route，就可以完整分類 60 題：

$$
20\,\text{EASY}+20\,\text{CORE}+20\,\text{PARITY}.
$$

其中

$$
\text{EASY}=15\,\mathrm{UNSAT}+5\,\mathrm{SAT},
$$

$$
\text{CORE}=15\,\mathrm{UNSAT}+5\,\mathrm{SAT},
$$

$$
\text{PARITY}=20\,\mathrm{UNSAT}.
$$

因此總計

$$
\boxed{50\,\mathrm{UNSAT}+10\,\mathrm{SAT}}.
$$

本研究包中的 structure-aware route 對 50 個 UNSAT instance 全部在 action budget 內得到 empty survivor，並對 10 個 SAT instance 全部產生並重新驗證 satisfying assignment。

## 2. 三個 family 的數學骨架

### 2.1 EASY

`bit_equals` 與 `parity` 都是 $\mathbb F_2$ 上的仿射線性方程。

15 個 UNSAT EASY instance 全部具有相同的二約束最小矛盾骨架：`C00` 與 `C07` 對同一個 bit 指定相反值，因此存在

$$
x_j=0,
\qquad
x_j=1.
$$

所以只需要兩個 direct cut 就能 closure。

五個 SAT EASY instance 為：

`EASY-000`, `EASY-008`, `EASY-010`, `EASY-012`, `EASY-019`。

對這五題，使用 $\mathbb F_2$ Gaussian elimination 可直接構造 satisfying assignment，再逐 premise 驗證。

### 2.2 PARITY

每題是一個 cycle：

$$
x_i\oplus x_{i+1}=b_i.
$$

把整個 cycle 的方程 XOR 起來。每個變數在左側恰好出現兩次，因此完全抵消：

$$
\bigoplus_i\left(x_i\oplus x_{i+1}\right)=0.
$$

而 20 題全部滿足

$$
\bigoplus_i b_i=1.
$$

所以得到

$$
0=1,
$$

全部 UNSAT。

合法 benchmark route 為：

`A_BRIDGE_CYCLE -> A_DERIVED_CYCLE_CLOSE`。

這一組是 v0.1 最清楚的概念成功：bridge 的 immediate exclusion yield 是零，但沒有 bridge，就無法在小 budget 下取得 global closure。

### 2.3 CORE

前 14 個 `bit_equals` constraints 固定全部 14 個 Boolean variables，因此把 survivor 精確壓到一個 singleton：

$$
\Omega_{\mathrm{core}}=\{p\}.
$$

對應 route：

`A_BRIDGE_AGGREGATE -> A_DERIVED_AGGREGATE`。

15 題另外存在

$$
a\neq p,
$$

也就是 `forbid_assignment(p)`，並由 `A_CORE_KILLER` 表示。第三步執行 killer 後 closure。

五個沒有 killer 的 SAT CORE instance 為：

`CORE-002`, `CORE-008`, `CORE-012`, `CORE-014`, `CORE-018`。

這一組成功捕捉一個很重要的路由現象：一個在全域只排除單點、看起來幾乎沒有 yield 的 action，在 localization 後可以具有 100% conditional closure value。

## 3. v0.1 真正證明自己有測到什麼

核心 authority invariant 是清楚而且合理的：

$$
\boxed{\text{bridge has routing authority, not proof authority}}.
$$

只有 certificate-verified `cut` 可以縮小 survivor；`bridge` 只能 unlock route，不能自己成為 theorem proof。

我另外實作了一個 local immediate-yield greedy baseline。對 UNSAT instance 的 closure 結果為：

- EASY：$15/15$；
- PARITY：$0/20$；
- CORE：$0/15$。

因此 v0.1 確實能區分：

$$
\text{local exclusion greediness}
\neq
\text{route-aware proof enclosure}.
$$

這不是空的 benchmark 結果。

## 4. 目前最重要的弱點

### 4.1 Label leakage

SAT/UNSAT label 可以從表面 metadata 完全推斷：

- EASY：budget / action count 為 8 的 15 題全部 UNSAT；為 7 的五題全部 SAT。
- CORE：存在 `A_CORE_KILLER` 就是 UNSAT；不存在就是 SAT。
- PARITY：20 題全部 UNSAT。

所以「答案分類」本身並不是真盲。

### 4.2 Route leakage

action 名稱與 tag 幾乎直接描述 intended proof route，例如：

- `A_DERIVED_CYCLE_CLOSE`
- `closure-critical`
- `A_CORE_KILLER`
- `core-localizer`
- `A_BRIDGE_AGGREGATE`

這很適合 v0.1 conformance / instrumentation test，但不足以測真正的研究路由能力。

### 4.3 `finite_entailment` 的 verifier 仍然做全域枚舉

目前 `finite_entailment` 是透過枚舉 $2^n$ 個 assignment 驗證 entailment。

所以在 action graph 上雖然出現了「compact global theorem route」，proof checker 本身仍然是 finite exhaustive checking。$n=12,14$ 時完全可行，但無法自然擴展。

對 parity 類型更合理的 certificate 是直接提供 $\mathbb F_2$ 線性組合係數 $\lambda_i$。若 premise 為

$$
a_i\cdot x=b_i,
$$

則 verifier 只需驗證

$$
a=\sum_i\lambda_i a_i,
\qquad
b=\sum_i\lambda_i b_i.
$$

若要證 contradiction，只需驗證

$$
a=0,
\qquad
b=1.
$$

這是 polynomial-time certificate verification，不需要枚舉 $2^n$。

### 4.4 action budget 與 `model_cost` 尚未耦合

`public_runner.py` 的 `within_budget` 只檢查 selected action 數量；`discover / verify / maintain / coverage` 加總出的 `model_cost` 只做 telemetry。

因此目前成本幾何不會改變 route admissibility。

若 v0.2 要正式測 cost-aware routing，應明確採用例如

$$
\sum_{a\in R}c(a)\le B,
$$

或明確的 multi-resource budget。

### 4.5 Public runner 沒有完整驗證 submission declaration

runner 會重播 route 並回傳真實 closure，但不會直接拒絕：

- `declared_closed` 與 replay 結果不一致；
- `declared_counterexample=true` 但 witness 無效；
- `counterexample_assignment` 不滿足全部 premises。

這些可能原本打算由 Oracle audit 端處理，但 Public Bundle 最好增加 `verify-submission` 命令，讓 research-side contract 本身就完整。

## 5. 包裝層發現

fresh extraction 後，`CHECKSUMS.sha256` 中列出的 73 個 SHA-256 全部正確。

但有兩個 packaging 問題：

1. `README.md` 指向 `docs/SDPE_BEB_v0.1_Experimental_Protocol.md`，實際 Public Bundle 中沒有這個檔案。
2. 包內包含 `tools/__pycache__/common.cpython-313.pyc`。Python import 後 `.pyc` 可能被重建，造成 checksum 改變，因此 canonical source package 應排除 `__pycache__` 與 `.pyc`。

## 6. 建議把 v0.2 分成三層

### Tier A — Conformance

保留現在 v0.1 的風格。action 名稱與 tag 可以明示角色，目標只測：proof authority、bridge semantics、certificate gate、replay 與 telemetry 是否正確。

### Tier B — Blind Routing

- action ID 全部中性化；
- 移除 `closure-critical` 等答案型 tag；
- SAT / UNSAT instance 的 action count、budget、表面 schema 分布做平衡；
- 加入 distractor bridge / cut；
- route graph 採不同深度與 topology；
- 讓 immediate yield 與 conditional yield 有真正 trade-off。

這一層才測研究路由。

### Tier C — Lemma Discovery

不要直接給 decisive derived action。

讓 participant 自己提出：

$$
(\text{derived predicate},\text{certificate},\text{dependencies}).
$$

verifier 只驗 certificate。

這才把問題從「選中已存在 theorem action」推進到「生成有用 lemma」。

## 7. 下一個真正值得死扣的 frontier

v0.1 最合理的定位是：

$$
\boxed{\text{SDPE runtime conformance + non-greedy routing smoke test}}.
$$

在這個定位下，它是成功的。

但下一步不應繼續增加同類小題，而是直接推：

$$
\boxed{\text{BEB v0.2 = metadata-neutral routing + structural certificates + lemma proposal}}.
$$

尤其是 structural certificate。只要這一步完成，SDPE 才真正從「有限枚舉 verifier 包住 route」變成「route 本身攜帶可擴展的 proof object」。這是目前最有數學價值的一刀。
