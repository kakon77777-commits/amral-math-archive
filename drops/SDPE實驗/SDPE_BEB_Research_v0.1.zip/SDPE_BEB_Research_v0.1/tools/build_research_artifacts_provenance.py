from __future__ import annotations
import json, csv, hashlib, itertools, pathlib, shutil, sys, statistics, collections

BUNDLE = pathlib.Path('/mnt/data/sdpe_fresh/SDPE_BEB_Public_v0.1')
OUT = pathlib.Path('/mnt/data/SDPE_BEB_Research_v0.1')
shutil.rmtree(OUT, ignore_errors=True)
(OUT/'tools').mkdir(parents=True)

# Avoid mutating the checked bundle by pyc regeneration.
sys.dont_write_bytecode = True
sys.path.insert(0, str(BUNDLE/'tools'))
from common import replay, verify_action_certificate, action_predicate, apply_pred, universe, total_cost, sat_pred

# ---------- helpers ----------
def jd(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def gf2_one_solution(n, premises):
    """Solve bit_equals/parity affine equations over GF(2); return integer assignment or None."""
    rows=[]
    for p in premises:
        pr=p['predicate']; k=pr['kind']
        if k=='bit_equals': mask=1<<pr['var']; rhs=pr['value']
        elif k=='parity':
            mask=0
            for v in pr['vars']: mask ^= 1<<v
            rhs=pr['value']
        else:
            raise ValueError(f'nonlinear predicate for GF2 solver: {k}')
        rows.append([mask, rhs])
    pivot_row=0; pivots=[]
    for col in range(n):
        sel=None
        for r in range(pivot_row, len(rows)):
            if (rows[r][0]>>col)&1:
                sel=r; break
        if sel is None: continue
        rows[pivot_row],rows[sel]=rows[sel],rows[pivot_row]
        pm,prhs=rows[pivot_row]
        for r in range(len(rows)):
            if r!=pivot_row and ((rows[r][0]>>col)&1):
                rows[r][0]^=pm; rows[r][1]^=prhs
        pivots.append((pivot_row,col)); pivot_row+=1
    for m,rhs in rows:
        if m==0 and rhs: return None
    # free vars = 0, pivot vars determined from reduced rows
    x=0
    for r,col in reversed(pivots):
        m,rhs=rows[r]
        other=m & ~(1<<col)
        val=rhs ^ ((x & other).bit_count() & 1)
        if val: x |= 1<<col
    return x

def easy_conflict_pair(task):
    ps=task['premises']
    for a,b in itertools.combinations(ps,2):
        pa,pb=a['predicate'],b['predicate']
        if pa['kind']==pb['kind']=='bit_equals' and pa['var']==pb['var'] and pa['value']!=pb['value']:
            return a['constraint_id'],b['constraint_id'],pa['var']
    return None

def action_for_constraint(task, cid):
    for a in task['actions']:
        ps=a.get('predicate_source')
        if ps and ps.get('kind')=='premise' and ps.get('constraint_id')==cid:
            return a['action_id']
    raise KeyError(cid)

def structural_truth_and_route(task):
    fam=task['family']
    if fam=='easy_debug':
        pair=easy_conflict_pair(task)
        if pair:
            c1,c2,var=pair
            route=[action_for_constraint(task,c1), action_for_constraint(task,c2)]
            return False, route, None, f'direct contradiction on x_{var}: {c1} vs {c2}'
        x=gf2_one_solution(task['n_vars'], task['premises'])
        assert x is not None
        route=[a['action_id'] for a in task['actions']]
        return True, route, x, 'GF(2) affine system is consistent; validated witness'
    if fam=='structured_parity_cycle':
        rhs_xor=0
        for p in task['premises']:
            rhs_xor ^= p['predicate']['value']
        assert rhs_xor==1
        route=['A_BRIDGE_CYCLE','A_DERIVED_CYCLE_CLOSE']
        return False, route, None, 'XOR of all cycle equations gives 0 = 1'
    if fam=='exceptional_core_trap':
        pattern=0
        bit_count=0
        killers=[]
        for p in task['premises']:
            pr=p['predicate']
            if pr['kind']=='bit_equals':
                bit_count+=1
                if pr['value']: pattern |= 1<<pr['var']
            elif pr['kind']=='forbid_assignment': killers.append(pr['assignment'])
        assert bit_count==task['n_vars']
        route=['A_BRIDGE_AGGREGATE','A_DERIVED_AGGREGATE']
        if killers:
            assert killers==[pattern]
            route.append('A_CORE_KILLER')
            return False, route, None, f'bit constraints isolate {pattern}, then forbid_assignment kills it'
        return True, route, pattern, f'bit constraints isolate unique surviving assignment {pattern}'
    raise ValueError(fam)

def greedy_route(task):
    surv=universe(task); unlocked=set(task['initially_unlocked']); used=set(); route=[]
    while len(route)<task['budget'] and surv:
        choices=[]
        for a in task['actions']:
            aid=a['action_id']
            if aid in used or aid not in unlocked: continue
            if any(req not in used for req in a.get('requires',[])): continue
            ok,_=verify_action_certificate(task,a)
            if not ok: continue
            pred=action_predicate(task,a)
            after=surv if pred is None else apply_pred(surv,pred)
            elim=len(surv)-len(after)
            choices.append((elim,-total_cost(a),aid,a,after))
        if not choices: break
        elim,negc,aid,a,after=max(choices,key=lambda z:(z[0],z[1],z[2]))
        route.append(aid); used.add(aid); surv=after; unlocked.update(a.get('unlocks',[]))
    return route

# Checksum validation on pristine bundle.
checksum_bad=[]; checksum_entries=0
for line in (BUNDLE/'CHECKSUMS.sha256').read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    checksum_entries+=1
    h,rel=line.split(None,1); rel=rel.strip().lstrip('*'); p=BUNDLE/rel
    got=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
    if got!=h: checksum_bad.append({'path':rel,'expected':h,'got':got})

records=[]; submissions=[]; traces=[]; greedy=[]
for f in sorted((BUNDLE/'public/tasks').glob('*.json')):
    task=json.loads(f.read_text(encoding='utf-8'))
    sat,route,witness,rationale=structural_truth_and_route(task)
    rr=replay(task,route)
    assert len(route)<=task['budget']
    assert rr['closed'] == (not sat), (task['task_id'], sat, rr)
    if witness is not None:
        assert all(sat_pred(witness,p['predicate']) for p in task['premises'])
    derived_certs={a['action_id']:verify_action_certificate(task,a)[0] for a in task['actions'] if a['action_id'].startswith('A_DERIVED')}
    sub={
        'task_id':task['task_id'],
        'policy':'structural-gf2-sdpe-v0.1',
        'selected_actions':route,
        'declared_closed':not sat,
        'declared_counterexample':sat,
        'counterexample_assignment':witness,
        'notes':rationale,
    }
    submissions.append(sub)
    traces.append({'task_id':task['task_id'],'submission':sub,'replay':rr})
    rec={
        'task_id':task['task_id'],'family':task['family'],'n_vars':task['n_vars'],'budget':task['budget'],
        'premises':len(task['premises']),'actions':len(task['actions']),
        'truth':'SAT' if sat else 'UNSAT','route_steps':len(route),'route':' > '.join(route),
        'final_survivor_size':rr['final_survivor_size'],'model_cost':rr['model_cost'],
        'counterexample_assignment':witness if witness is not None else '',
        'rationale':rationale,'all_derived_certificates_ok':all(derived_certs.values()) if derived_certs else True,
    }
    records.append(rec)

    gr=greedy_route(task); grr=replay(task,gr)
    greedy.append({'task_id':task['task_id'],'family':task['family'],'truth':'SAT' if sat else 'UNSAT','route':gr,'closed':grr['closed'],'final_survivor_size':grr['final_survivor_size']})

# Write artifacts.
(OUT/'submissions_structural.jsonl').write_text('\n'.join(jd(x) for x in submissions)+'\n',encoding='utf-8')
(OUT/'trace_structural.jsonl').write_text('\n'.join(jd(x) for x in traces)+'\n',encoding='utf-8')
(OUT/'task_analysis.jsonl').write_text('\n'.join(jd(x) for x in records)+'\n',encoding='utf-8')

with (OUT/'benchmark_metrics.csv').open('w',encoding='utf-8',newline='') as fp:
    w=csv.DictWriter(fp,fieldnames=list(records[0].keys())); w.writeheader(); w.writerows(records)

truth_counts=collections.Counter((r['family'],r['truth']) for r in records)
greedy_unsat=collections.Counter(); greedy_unsat_total=collections.Counter()
for g in greedy:
    if g['truth']=='UNSAT':
        greedy_unsat_total[g['family']]+=1
        if g['closed']: greedy_unsat[g['family']]+=1

sat_ids=[r['task_id'] for r in records if r['truth']=='SAT']
missing_doc=not (BUNDLE/'docs/SDPE_BEB_v0.1_Experimental_Protocol.md').exists()

summary={
    'bundle_checksum_entries':checksum_entries,
    'bundle_checksum_failures':checksum_bad,
    'task_count':len(records),
    'truth_counts':{f'{fam}:{truth}':n for (fam,truth),n in sorted(truth_counts.items())},
    'total_unsat':sum(1 for r in records if r['truth']=='UNSAT'),
    'total_sat':sum(1 for r in records if r['truth']=='SAT'),
    'sat_task_ids':sat_ids,
    'structure_aware_unsat_closure':sum(1 for r in records if r['truth']=='UNSAT' and r['final_survivor_size']==0),
    'structure_aware_sat_witnesses':sum(1 for r in records if r['truth']=='SAT' and r['counterexample_assignment']!=''),
    'greedy_unsat_closure_by_family':{fam:{'closed':greedy_unsat[fam],'unsat_total':greedy_unsat_total[fam]} for fam in sorted(greedy_unsat_total)},
    'readme_missing_experimental_protocol_reference':missing_doc,
    'budget_uses_action_count_not_model_cost':True,
}
(OUT/'baseline_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

report=r'''# SDPE-BEB Public v0.1 Structural Research Report

## 1. Executive result

This public bundle is internally coherent as an **instrumented routing / enclosure benchmark**, but it is not yet a hard theorem-discovery benchmark. A structure-aware participant can solve the entire public set without an unrestricted exhaustive ground-truth oracle.

The 60 public tasks decompose as

$$
20\;\text{{EASY}}+20\;\text{{CORE}}+20\;\text{{PARITY}}.
$$

Structural classification gives

$$
\text{{EASY}}=15\;\mathrm{{UNSAT}}+5\;\mathrm{{SAT}},
$$

$$
\text{{CORE}}=15\;\mathrm{{UNSAT}}+5\;\mathrm{{SAT}},
$$

$$
\text{{PARITY}}=20\;\mathrm{{UNSAT}}.
$$

Hence

$$
\boxed{{50\;\mathrm{{UNSAT}}+10\;\mathrm{{SAT}}}}.
$$

The structure-aware SDPE route closes all 50 UNSAT instances within action budget and produces validated witnesses for all 10 SAT instances.

## 2. Mathematical skeleton

### 2.1 EASY family

All predicates are affine equations over $\mathbb F_2$: `bit_equals` and `parity`.

For every one of the 15 UNSAT EASY instances, the contradiction is already a two-constraint core:

$$
x_j=0,\qquad x_j=1.
$$

Concretely, the contradictory pair is always `C00` versus `C07`. Therefore a two-action direct-cut route is sufficient.

The five SAT EASY tasks are:

`EASY-000`, `EASY-008`, `EASY-010`, `EASY-012`, `EASY-019`.

For them, Gaussian elimination over $\mathbb F_2$ yields explicit satisfying assignments, which are independently checked against every public premise.

### 2.2 PARITY family

Each task is a parity cycle

$$
x_i\oplus x_{{i+1}}=b_i.
$$

XOR all cycle equations. Every variable occurs exactly twice, so the left side cancels:

$$
\bigoplus_i(x_i\oplus x_{{i+1}})=0.
$$

In all 20 public PARITY tasks,

$$
\bigoplus_i b_i=1,
$$

hence

$$
0=1,
$$

and every instance is UNSAT. The legal benchmark route is

`A_BRIDGE_CYCLE -> A_DERIVED_CYCLE_CLOSE`.

This is the strongest conceptual success of v0.1: a zero-immediate-yield bridge is necessary to expose a global closure route under the small action budget.

### 2.3 CORE family

The first 14 `bit_equals` premises fix all 14 Boolean variables, hence isolate exactly one assignment $p$:

$$
\Omega_{\mathrm{{core}}}=\{{p\}}.
$$

The bridge plus aggregate cut performs this localization:

`A_BRIDGE_AGGREGATE -> A_DERIVED_AGGREGATE`.

For 15 instances there is one additional premise

$$
a\neq p,
$$

represented by `forbid_assignment` and exposed as `A_CORE_KILLER`; these tasks close in the third action. Five tasks omit the killer and are SAT:

`CORE-002`, `CORE-008`, `CORE-012`, `CORE-014`, `CORE-018`.

This family correctly demonstrates why tiny **global** exclusion yield can have maximal **conditional** closure value after localization.

## 3. What v0.1 genuinely demonstrates

The important invariant is sound:

$$
\boxed{{\text{{bridge has routing authority, not proof authority}}}}.
$$

Only certificate-verified cut actions shrink the survivor set. A bridge can unlock a derived route but cannot itself establish closure. This separation is mathematically and architecturally useful.

The benchmark also succeeds at illustrating two non-greedy phenomena:

1. **Bridge value:** an action with zero immediate exclusion can be indispensable to global closure.
2. **Exceptional-core value:** an action with exclusion yield $1/2^n$ can become closure-critical after a representation/localization step.

A local immediate-yield greedy policy closes all 15 UNSAT EASY tasks, but closes **0/20 PARITY** and **0/15 UNSAT CORE** tasks within budget. Thus the benchmark does separate local exclusion greediness from route-aware reasoning.

## 4. Main weaknesses found

### 4.1 Label leakage

The SAT/UNSAT distribution is recoverable from superficial public structure:

- EASY: budget/action count 8 corresponds to the 15 contradictory instances; 7 corresponds to the five SAT instances.
- CORE: presence of `A_CORE_KILLER` corresponds exactly to UNSAT; its absence corresponds exactly to SAT.
- PARITY: all public instances are UNSAT.

Therefore answer classification itself is not blind to metadata, even without solving predicates.

### 4.2 Route leakage

Action names and tags expose intended proof roles almost directly:

- `A_DERIVED_CYCLE_CLOSE`
- `closure-critical`
- `A_CORE_KILLER`
- `core-localizer`
- `A_BRIDGE_AGGREGATE`

This is acceptable for a v0.1 conformance/instrumentation trial, but too strong for a research-routing benchmark.

### 4.3 Finite-entailment verifier is exhaustive

`finite_entailment` currently verifies an entailment by looping over the entire Boolean universe. At $n=12$ or $14$ this is harmless, but it means the compact global proof route is **simulated at the action layer while the verifier still performs exhaustive finite checking**.

For a scalable SDPE benchmark, the certificate should itself be structural. For parity, a certificate can give coefficients $\lambda_i\in\mathbb F_2$ and the verifier checks

$$
\sum_i\lambda_i A_i=0,
\qquad
\sum_i\lambda_i b_i=1,
$$

in polynomial time. For CORE aggregation, the verifier can check that the bit equalities determine the claimed mask/pattern directly.

### 4.4 Action budget and modeled cost are uncoupled

`within_budget` is defined from the number of selected actions, while `model_cost` is only telemetry. Thus the vectors `discover`, `verify`, `maintain`, and `coverage` do not constrain route legality.

This is not necessarily a bug if the two quantities are intentionally different, but v0.2 should explicitly define either

$$
\sum_{{a\in R}} c(a)\le B
$$

or a genuinely multi-resource budget, rather than presenting cost geometry that cannot affect admissibility.

### 4.5 Public runner does not validate declaration semantics

The runner replays selected actions and reports closure, but does not itself reject a mismatch between `declared_closed` and replay result, nor does it validate `declared_counterexample` / `counterexample_assignment`. That may be delegated to the Oracle audit side, but a public `verify-submission` command would make the contract safer and easier to test.

### 4.6 Packaging defects

The fresh archive passes all 73 listed SHA-256 checksums. However:

- `README.md` refers to `docs/SDPE_BEB_v0.1_Experimental_Protocol.md`, which is absent from the bundle.
- the archive includes `tools/__pycache__/common.cpython-313.pyc`; importing the module can regenerate this file and invalidate its checksum. `.pyc` / `__pycache__` should not be shipped in the canonical source package.

## 5. Recommended v0.2 design

The most important upgrade is to separate **conformance**, **routing**, and **discovery** tiers.

### Tier A — Conformance

Keep something close to v0.1. Named actions and obvious tags are acceptable. Goal: verify proof authority, bridge semantics, replay, certificate gates, and telemetry.

### Tier B — Blind routing

Neutralize action IDs/tags, equalize action counts and budgets across SAT/UNSAT instances, add distractor bridges/cuts, and vary graph topology. A route should have to be inferred from dependencies, predicted conditional yield, and certificate structure.

### Tier C — Lemma discovery

Do not provide the decisive derived action. Let the participant propose a derived predicate plus certificate. The verifier checks the certificate. This moves the benchmark from selecting a theorem action to actually discovering a useful lemma.

## 6. Scalable certificate proposal

For affine Boolean constraints, represent each premise as

$$
a_i\cdot x=b_i
\qquad (a_i\in\mathbb F_2^n).
$$

A derived affine cut

$$
a\cdot x=b
$$

can be certified by a coefficient vector $\lambda$ satisfying

$$
a=\sum_i\lambda_i a_i,
\qquad
b=\sum_i\lambda_i b_i.
$$

A contradiction certificate is simply

$$
a=0,
\qquad
b=1.
$$

Verification is polynomial and does not enumerate $2^n$ assignments. This is the natural next bridge between SDPE's route semantics and proof-carrying algebra.

## 7. Final assessment

v0.1 is **not a failure**. Its strongest interpretation is:

$$
\boxed{{\text{{SDPE runtime conformance + non-greedy routing mechanics smoke test}}}}.
$$

Under that interpretation, it works and the two central examples—global parity closure and exceptional-core localization—are well chosen.

But it is too instrumented to support a stronger claim about autonomous theorem discovery, strong blind research routing, or scalable proof compression. The next mathematically meaningful frontier is therefore:

$$
\boxed{{\text{{BEB v0.2: metadata-neutral routing + structural certificates + lemma proposal}}}}.
$$
'''
(OUT/'README_research.md').write_text(report,encoding='utf-8')

# Copy the reproducible analyzer itself.
shutil.copy2('/mnt/data/build_sdpe_research.py', OUT/'tools/analyze_sdpe_beb.py')

# Validation.
validation={
    'utf8_files_ok':True,
    'jsonl_parse_ok':True,
    'task_count':len(records),
    'all_routes_within_budget':all(r['route_steps']<=r['budget'] for r in records),
    'all_unsat_closed':all(r['final_survivor_size']==0 for r in records if r['truth']=='UNSAT'),
    'all_sat_witnesses_validated':sum(1 for r in records if r['truth']=='SAT' and r['counterexample_assignment']!='')==10,
    'pristine_bundle_checksum_failures':checksum_bad,
    'canonical_math_delimiters':'$...$ and $$...$$ only in report source',
}
# Parse JSONL files as validation.
for name in ['submissions_structural.jsonl','trace_structural.jsonl','task_analysis.jsonl']:
    for line in (OUT/name).read_text(encoding='utf-8').splitlines(): json.loads(line)
(OUT/'VALIDATION.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

# Checksums for generated artifact excluding checksum file itself.
lines=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p.name!='CHECKSUMS.sha256':
        h=hashlib.sha256(p.read_bytes()).hexdigest(); rel=p.relative_to(OUT).as_posix(); lines.append(f'{h}  {rel}')
(OUT/'CHECKSUMS.sha256').write_text('\n'.join(lines)+'\n',encoding='utf-8')

# Zip package.
zipbase='/mnt/data/SDPE_BEB_Research_v0.1'
shutil.make_archive(zipbase,'zip',root_dir=OUT.parent,base_dir=OUT.name)
print(json.dumps(summary,ensure_ascii=False,indent=2))
print('OUT',OUT)
print('ZIP',zipbase+'.zip')
