#!/usr/bin/env python3
from __future__ import annotations
import argparse, itertools, json, pathlib, sys


def gf2_one_solution(n: int, premises: list[dict]) -> int | None:
    rows: list[list[int]] = []
    for item in premises:
        pred = item['predicate']
        if pred['kind'] == 'bit_equals':
            mask = 1 << pred['var']
            rhs = pred['value']
        elif pred['kind'] == 'parity':
            mask = 0
            for v in pred['vars']:
                mask ^= 1 << v
            rhs = pred['value']
        else:
            raise ValueError(f"Unsupported GF(2) predicate: {pred['kind']}")
        rows.append([mask, rhs])

    pivot_row = 0
    pivots: list[tuple[int, int]] = []
    for col in range(n):
        sel = next((r for r in range(pivot_row, len(rows)) if (rows[r][0] >> col) & 1), None)
        if sel is None:
            continue
        rows[pivot_row], rows[sel] = rows[sel], rows[pivot_row]
        pm, prhs = rows[pivot_row]
        for r in range(len(rows)):
            if r != pivot_row and ((rows[r][0] >> col) & 1):
                rows[r][0] ^= pm
                rows[r][1] ^= prhs
        pivots.append((pivot_row, col))
        pivot_row += 1

    if any(mask == 0 and rhs == 1 for mask, rhs in rows):
        return None

    x = 0
    for r, col in reversed(pivots):
        mask, rhs = rows[r]
        other = mask & ~(1 << col)
        value = rhs ^ ((x & other).bit_count() & 1)
        if value:
            x |= 1 << col
    return x


def satisfies(x: int, pred: dict) -> bool:
    kind = pred['kind']
    if kind == 'bit_equals':
        return ((x >> pred['var']) & 1) == pred['value']
    if kind == 'parity':
        return (sum((x >> v) & 1 for v in pred['vars']) & 1) == pred['value']
    if kind == 'forbid_assignment':
        return x != pred['assignment']
    if kind == 'mask_equals':
        return (x & pred['mask']) == pred['pattern']
    if kind == 'false':
        return False
    if kind == 'true':
        return True
    raise ValueError(kind)


def action_for_constraint(task: dict, cid: str) -> str:
    for action in task['actions']:
        src = action.get('predicate_source')
        if src and src.get('kind') == 'premise' and src.get('constraint_id') == cid:
            return action['action_id']
    raise KeyError(cid)


def easy_conflict_pair(task: dict):
    for a, b in itertools.combinations(task['premises'], 2):
        pa, pb = a['predicate'], b['predicate']
        if (pa['kind'] == pb['kind'] == 'bit_equals'
                and pa['var'] == pb['var']
                and pa['value'] != pb['value']):
            return a['constraint_id'], b['constraint_id'], pa['var']
    return None


def analyze(task: dict) -> dict:
    fam = task['family']
    if fam == 'easy_debug':
        conflict = easy_conflict_pair(task)
        if conflict:
            c1, c2, var = conflict
            return {
                'truth': 'UNSAT',
                'selected_actions': [action_for_constraint(task, c1), action_for_constraint(task, c2)],
                'counterexample_assignment': None,
                'reason': f'direct contradiction on x_{var}: {c1} vs {c2}',
            }
        witness = gf2_one_solution(task['n_vars'], task['premises'])
        if witness is None:
            raise RuntimeError(f"Unexpected inconsistent EASY task: {task['task_id']}")
        assert all(satisfies(witness, p['predicate']) for p in task['premises'])
        return {
            'truth': 'SAT',
            'selected_actions': [a['action_id'] for a in task['actions']],
            'counterexample_assignment': witness,
            'reason': 'consistent GF(2) affine system; witness validated',
        }

    if fam == 'structured_parity_cycle':
        rhs_xor = 0
        for p in task['premises']:
            rhs_xor ^= p['predicate']['value']
        truth = 'UNSAT' if rhs_xor else 'SAT'
        if truth != 'UNSAT':
            raise RuntimeError(f"Unexpected SAT parity cycle in v0.1: {task['task_id']}")
        return {
            'truth': truth,
            'selected_actions': ['A_BRIDGE_CYCLE', 'A_DERIVED_CYCLE_CLOSE'],
            'counterexample_assignment': None,
            'reason': 'XOR of cycle RHS values is 1, so summing all equations gives 0=1',
        }

    if fam == 'exceptional_core_trap':
        pattern = 0
        killers = []
        bit_constraints = 0
        for p in task['premises']:
            pred = p['predicate']
            if pred['kind'] == 'bit_equals':
                bit_constraints += 1
                if pred['value']:
                    pattern |= 1 << pred['var']
            elif pred['kind'] == 'forbid_assignment':
                killers.append(pred['assignment'])
        if bit_constraints != task['n_vars']:
            raise RuntimeError('CORE task does not fix every variable')
        route = ['A_BRIDGE_AGGREGATE', 'A_DERIVED_AGGREGATE']
        if killers:
            if killers != [pattern]:
                raise RuntimeError('CORE killer does not target localized singleton')
            return {
                'truth': 'UNSAT',
                'selected_actions': route + ['A_CORE_KILLER'],
                'counterexample_assignment': None,
                'reason': f'bit constraints localize singleton {pattern}; killer excludes it',
            }
        assert all(satisfies(pattern, p['predicate']) for p in task['premises'])
        return {
            'truth': 'SAT',
            'selected_actions': route,
            'counterexample_assignment': pattern,
            'reason': f'bit constraints localize the valid singleton {pattern}',
        }

    raise ValueError(f'Unknown family: {fam}')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('bundle_dir', type=pathlib.Path, help='Path to SDPE_BEB_Public_v0.1 directory')
    ap.add_argument('-o', '--output', type=pathlib.Path, default=pathlib.Path('submissions_structural.jsonl'))
    args = ap.parse_args()

    out = []
    for path in sorted((args.bundle_dir / 'public' / 'tasks').glob('*.json')):
        task = json.loads(path.read_text(encoding='utf-8'))
        r = analyze(task)
        out.append({
            'task_id': task['task_id'],
            'policy': 'structural-gf2-sdpe-v0.1',
            'selected_actions': r['selected_actions'],
            'declared_closed': r['truth'] == 'UNSAT',
            'declared_counterexample': r['truth'] == 'SAT',
            'counterexample_assignment': r['counterexample_assignment'],
            'notes': r['reason'],
        })

    args.output.write_text(
        '\n'.join(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')) for x in out) + '\n',
        encoding='utf-8',
    )
    print(f'wrote {len(out)} submissions to {args.output}')


if __name__ == '__main__':
    main()
