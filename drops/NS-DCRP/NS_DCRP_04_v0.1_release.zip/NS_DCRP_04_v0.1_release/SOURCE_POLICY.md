# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Dissipation-wavenumber height alone is not treated as a contradiction; recurrence residence is explicit.
- The logarithmic FAR result is a selected-time scale-dependent floor, not a fixed-share time-persistent atom.
- Asymptotic propagated inheritance is not one actual atomic chain without compatibility/shadowing.
- Positive local commutator/Young taxes are not promoted to global finite budgets.
- External finite-chain and moving-window reductions are not promoted beyond their stated hypotheses.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
