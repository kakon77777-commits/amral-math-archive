---
title: "Navier–Stokes Diffuse Carrier Rigidity Program 04：Impulsive Residence、Logarithmic Far-Field Atomic Floors、Defect-Work Recurrence、WORK/RES Intersection 與 Cycle-VIII Closure Audit"
short_title: "NS-DCRP 04"
series: "Navier–Stokes Diffuse Carrier Rigidity Program"
cycle: "VIII"
version: "v0.1"
date: "2026-08-16"
author: "Neo.K / EveMissLab"
language: "zh-TW"
status: "Cycle-VIII temporal closure audit / impulsive diffuse recurrence normal form"
epistemic_status: "Closes Cycle VIII as a diffuse-carrier routing/partial-rigidity cycle. Uses the universal Cheskidov-Shvydkoy dissipation-wavenumber bound Lambda in L_t^1 to prove that any pairwise-disjoint recurrent shell-span episodes must have summable height-residence numbers rho_n=L_n|I_n| and hence rho_n->0. Combining this with the corrected ANP causal dual ledger yields a Short-Residence Renewal Amplification theorem: on episodes with a fixed inheritance deficit, the normalized fresh-source rate divided by the dissipation-wavenumber height diverges like 1/rho_n; shell-span recurrence is therefore reclassified as almost-complete propagated inheritance or super-height source impulses. For the far-field branch, removes the prior uniform-annular-reservoir assumption. From the exact filtered annular inequality, the global finite-energy bound on the filtered-vorticity spacetime norm, and a weighted l2-to-linfinity sequence lemma, proves a logarithmic annular-output atom floor. Combining that with the core time-profile gives a universal scale-dependent selected-time critical cell floor of order [1+log(C/r_k)]^{-2/3} for order-one annular far-field output, modulo the stated filter/annular geometry constants. Thus FAR cannot become arbitrarily diffuse faster than logarithmically, but the floor still tends to zero and does not give a fixed-share reprofile. For the commutator branch, formalizes a defect-work recurrence dichotomy: bounded unresolved increment mass plus fixed positive commutator defect work gives a positive defect-work efficiency ratio; unbounded increment mass is an amplitude-escape branch. Under full Young representation, vanishing strict-convexity tax collapses microstructure to a Dirac profile, while positive tax lacks a known global packing budget. The WORK/RES branch is compared with recent finite-chain counting and combined-invisible defect reductions: current primary results route persistent badness into explicit concentration/leakage/pressure/PFE costs or a cleaned scale-critical combined-invisible cascade, but do not exclude that recurrent object. Cycle VIII therefore does not exclude the minimal diffuse obstruction. The final surviving object is a time-recurrent diffuse/invisible carrier whose spatial-scale complexity is repeatedly compressed into impulsive inheritance/source bursts, logarithmically weak far-field atoms, coherent increment microstructure, or PFET/WORK/RES invisibility. No Forest Coercive Budget, Finite Forest Obstruction, atomic CN3, or Navier-Stokes regularity is proved."
canonical_source: "UTF-8 Markdown"
---

# Navier–Stokes Diffuse Carrier Rigidity Program 04

# Impulsive Residence、Logarithmic Far-Field Atomic Floors、Defect-Work Recurrence、WORK/RES Intersection 與 Cycle-VIII Closure Audit

## 0. 本文定位

DCRP-03 reduced the surviving minimal diffuse recurrence to:

$$
\boxed{
SR
\vee
FA
\vee
CM
\vee
WR.
}
$$

Here:

- $SR$ is shell-span with summably short residence;
- $FA$ is far-field annular/core amplitude or exterior-tail escape;
- $CM$ is recurrent increment microstructure/defect work or representation failure;
- $WR$ is WORK/RES pressure-flux-energy-trace/invisible residual recurrence.

The present paper audits whether these are independent terminal mechanisms.

The main conclusion is:

$$
\boxed{
\textbf{
the remaining diffuse obstruction is primarily temporal and impulsive.
}
}
$$

---

# 1. Universal dissipation-wavenumber budget

Let:

$$
\Lambda(t)
$$

be the Cheskidov--Shvydkoy dissipation wavenumber.

For every Leray--Hopf solution:

$$
\boxed{
\Lambda\in L^1(0,T).
}
$$

Their framework also proves regularity under the stronger:

$$
\boxed{
\Lambda\in L^{5/2}(0,T).
}
$$

### Status

$$
\boxed{
\mathrm{EXTERNAL/PROVED}.
}
$$

---

# 2. Disjoint shell-span episodes

Let:

$$
I_n
$$

be pairwise disjoint shell-span/driver episodes.

Define:

$$
\boxed{
L_n
=
\essinf_{t\in I_n}
\Lambda(t),
}
$$

$$
\boxed{
\delta_n
=
|I_n|,
}
$$

and the height-residence number:

$$
\boxed{
\rho_n
=
L_n\delta_n.
}
$$

---

# 3. CIV/VIII-4.1 — Impulsive Residence Theorem

## Theorem 3.1

For every pairwise-disjoint family:

$$
\{I_n\},
$$

$$
\boxed{
\sum_n
\rho_n
=
\sum_n
L_n\delta_n
\le
\int_0^T
\Lambda(t)dt
<
\infty.
}
$$

Consequently:

$$
\boxed{
\rho_n\to0.
}
$$

### Meaning

An infinite sequence of increasingly high shell-span episodes can coexist with Leray--Hopf energy only by becoming asymptotically impulsive in the height-residence product.

$\square$

---

# 4. Corrected causal cut ledger

Let one dangerous child on:

$$
I_n=[a_n,b_n]
$$

have normalized dual causal ledger:

$$
\boxed{
1
=
\iota_n
+
q_n,
}
$$

where:

$$
\iota_n
$$

is the normalized propagated/inherited signed contribution and:

$$
q_n
$$

is the normalized fresh source contribution.

The corrected ANP source estimate gives:

if:

$$
\boxed{
\iota_n
\le
1-\sigma,
}
$$

then:

$$
\boxed{
\frac1{
\delta_n
}
\int_{I_n}
\frac{
|
\langle
F_n(t),
\Phi_n(t)
\rangle
|
}{
A_n
}
dt
\ge
\frac{
\sigma
}{
\delta_n
}.
}
$$

This is an INTERNAL prior-program theorem.

---

# 5. Fresh-source rate

Define:

$$
\boxed{
\mathfrak R_n^{fresh}
=
\frac1{
\delta_n
}
\int_{I_n}
\frac{
|
\langle
F_n,
\Phi_n
\rangle
|
}{
A_n
}
dt.
}
$$

Then a fixed inheritance deficit implies:

$$
\boxed{
\mathfrak R_n^{fresh}
\ge
\sigma/\delta_n.
}
$$

---

# 6. CIV/VIII-4.2 — Short-Residence Renewal Amplification

## Theorem 6.1

Let:

$$
I_n
$$

be shell-span episodes satisfying Theorem 3.1.

If along an infinite subsequence:

$$
\boxed{
\iota_n
\le
1-\sigma
}
$$

for one fixed:

$$
\sigma>0,
$$

then:

$$
\boxed{
\frac{
\mathfrak R_n^{fresh}
}{
L_n
}
\ge
\frac{
\sigma
}{
L_n\delta_n
}
=
\frac{
\sigma
}{
\rho_n
}
\to
\infty.
}
$$

### Meaning

A short-residence high-shell episode with nontrivial fresh renewal must be driven at a rate asymptotically larger than its own dissipation-wavenumber height.

$\square$

---

# 7. Shell-span temporal dichotomy

Therefore an infinite shell-span recurrence satisfies:

$$
\boxed{
\text{ASYMPTOTIC INHERITANCE}
}
$$

where:

$$
\iota_n\to1
$$

along the relevant subsequence, or:

$$
\boxed{
\text{SUPER-HEIGHT SOURCE IMPULSE}
}
$$

where:

$$
\mathfrak R_n^{fresh}/L_n\to\infty.
$$

Thus:

$$
\boxed{
SR
}
$$

is no longer an independent purely spatial/spectral escape description.

It becomes a temporal propagation/source-impulse normal form.

---

# 8. Safety of the inheritance branch

Asymptotic inheritance across selected episodes does not automatically construct one actual infinite atomic lineage.

Compatibility of the selected propagated carriers remains subject to the ANP actual-branch/shadowing distinctions.

Thus:

$$
\boxed{
\text{asymptotic inheritance}
\neq
CN3_{\rm Atomic}.
}
$$

---

# 9. Filtered vorticity energy bound

Let:

$$
\Omega_k
=
\nabla\times
(
\varphi_{\ell_k}*u
),
$$

with:

$$
\boxed{
\ell_k
=
\sigma_f r_k,
\qquad
0<\sigma_f<1.
}
$$

Since:

$$
\|\nabla\varphi_{\ell_k}*u\|_2
\le
C_\varphi
\ell_k^{-1}
\|u\|_2,
$$

and:

$$
|I_k|
=
r_k^2,
$$

the finite-energy bound:

$$
\sup_t
\|u(t)\|_2
\le
E_2
$$

gives:

$$
\boxed{
\int_{I_k}
\|\Omega_k(t)\|_2^2dt
\le
C_{\varphi,\sigma_f}
E_2^2.
}
$$

This estimate is uniform in:

$$
k.
$$

---

# 10. Exact annular reservoirs

Use the filtered far-field annular variables:

$$
\boxed{
A_{m,k}
=
\mathfrak A_{k-m,k},
}
$$

with:

$$
m\ge0.
$$

Then:

$$
\boxed{
A_{m,k}^2
(2^mr_k)
=
\iint_{
I_k
\times
\widetilde A_{k-m}
}
|\Omega_k|^2.
}
$$

The stationary annuli have bounded overlap.

Hence Section 9 gives:

$$
\boxed{
\sum_{m\ge0}
2^m
r_k
A_{m,k}^2
\le
C_A
E_2^2.
}
$$

---

# 11. Core profile

Let:

$$
Q_k
$$

be the external filtered core time-profile appearing in the exact annular inequality.

The far-field output satisfies:

$$
\boxed{
\mu_k^{far,ann}
\le
C_0
Q_k
\sum_{m\ge0}
2^{-m}
A_{m,k}.
}
$$

Assume:

$$
\boxed{
\mu_k^{far,ann}
\ge
\sigma>0.
}
$$

---

# 12. Annular output variables

Define:

$$
\boxed{
b_{m,k}
=
2^{-m}
A_{m,k}
Q_k.
}
$$

Then:

$$
\boxed{
\sum_m
b_{m,k}
\ge
s_0
:=
\sigma/C_0.
}
$$

Moreover Section 10 implies:

$$
\boxed{
\sum_m
2^{3m}
b_{m,k}^2
\le
R_k
:=
C_A
\frac{
E_2^2
Q_k^2
}{
r_k
}.
}
$$

---

# 13. Weighted sequence lemma

## Lemma 13.1

Let:

$$
b_m\ge0,
$$

$$
\sum_mb_m\ge s>0,
$$

and:

$$
\sum_m
2^{3m}
b_m^2
\le
R.
$$

Then:

$$
\boxed{
\beta
:=
\sup_m
b_m
\ge
c
\frac{
s
}{
1+
\log_+
(
CR/s^2
)
}.
}
$$

### Proof

Choose:

$$
M
$$

such that:

$$
C
R^{1/2}
2^{-3M/2}
\le
s/2.
$$

For the tail:

$$
\sum_{m\ge M}
b_m
\le
\left(
\sum_{m\ge M}
2^{3m}b_m^2
\right)^{1/2}
\left(
\sum_{m\ge M}
2^{-3m}
\right)^{1/2}
\le
s/2.
$$

Thus:

$$
\sum_{m<M}
b_m
\ge
s/2.
$$

Since there are:

$$
M
$$

terms:

$$
M\beta
\ge
s/2.
$$

The selected:

$$
M
$$

is bounded by the displayed logarithm.

$\square$

---

# 14. Core critical atom

Let:

$$
E_k^{core}(t)
=
\int_{B_{2r_k}}
\chi_k
|\Omega_k(x,t)|^2dx.
$$

By definition:

$$
\boxed{
Q_k
=
\left(
\int_{I_k}
E_k^{core}(t)^2dt
\right)^{1/2}.
}
$$

Hence some:

$$
t_k^{core}\in I_k
$$

satisfies:

$$
\boxed{
E_k^{core}
(
t_k^{core}
)
\ge
Q_k/r_k.
}
$$

The core ball is covered by finitely many:

$$
r_k
$$

wavelength cells.

Therefore one cell:

$$
Q_k^{core}
$$

has:

$$
\boxed{
r_k
\int_{
Q_k^{core}
}
|\Omega_k(x,t_k^{core})|^2dx
\ge
c
Q_k.
}
$$

---

# 15. Annular output atom

Choose:

$$
m_\ast
$$

with:

$$
b_{m_\ast,k}=\beta_k.
$$

The corresponding annulus is covered by:

$$
O(2^{3m_\ast})
$$

wavelength cells.

Repeating the space/time averaging of DCRP-03 yields one cell:

$$
Q_k^{ann}
$$

and:

$$
t_k^{ann}\in I_k
$$

such that:

$$
\boxed{
r_k
\int_{
Q_k^{ann}
}
|\Omega_k(x,t_k^{ann})|^2dx
\ge
c
\left(
\frac{
\beta_k
}{
Q_k
}
\right)^2.
}
$$

---

# 16. CIV/VIII-4.3 — Logarithmic Far-Field Atomic Floor

## Theorem 16.1

Assume Sections 9--15 and:

$$
\mu_k^{far,ann}
\ge
\sigma>0.
$$

Then there exists a selected-time:

$$
r_k
$$

wavelength cell:

$$
Q_k^\ast
$$

such that:

$$
\boxed{
r_k
\int_{Q_k^\ast}
|\Omega_k(x,t_k^\ast)|^2dx
\ge
c
\frac{
\sigma^{2/3}
}{
\left[
1+
\log_+
\left(
\frac{
C
E_2^2
}{
\sigma^2
r_k
}
\right)
\right]^{2/3}
}.
}
$$

The constant depends on the filter/annular geometry and the external far-field constant.

### Proof

If:

$$
Q_k\ge1,
$$

the core atom from Section 14 is already bounded below by a fixed constant.

Assume:

$$
0<Q_k<1.
$$

Then:

$$
R_k
\le
C_A
E_2^2/r_k.
$$

Lemma 13.1 gives:

$$
\beta_k
\ge
c
\frac{
\sigma
}{
L_k
},
$$

where:

$$
L_k
=
1+
\log_+
\left(
\frac{
CE_2^2
}{
\sigma^2r_k
}
\right).
$$

Hence the selected critical cell is bounded below by:

$$
c
\max
\left\{
Q_k,
\frac{
\sigma^2
}{
Q_k^2
L_k^2
}
\right\}.
$$

The minimum of the right-hand side over:

$$
Q_k>0
$$

occurs when:

$$
Q_k^3
\asymp
\sigma^2/L_k^2.
$$

Therefore:

$$
\boxed{
\max
\left\{
Q_k,
\frac{
\sigma^2
}{
Q_k^2L_k^2
}
\right\}
\gtrsim
\sigma^{2/3}
L_k^{-2/3}.
}
$$

$\square$

---

# 17. Meaning of the logarithmic floor

DCRP-03 proved a fixed atomic floor under uniformly bounded annular/core reservoirs.

Theorem 16.1 removes that bounded-reservoir assumption at the cost of a weaker scale-dependent floor:

$$
\boxed{
p_k^{atom}
\gtrsim
[\log(C/r_k)]^{-2/3}.
}
$$

Thus order-one FAR output cannot diffuse arbitrarily fast.

But:

$$
\boxed{
[\log(C/r_k)]^{-2/3}
\to0.
}
$$

Therefore this is **not** a fixed-share atomic reprofile theorem.

---

# 18. FAR temporal barrier

A selected-time atomic floor which tends to zero may disappear in the MORP spacetime/trace limit unless:

- it has a fixed lower bound;
- it persists for a positive normalized time thickness;
- or the trace normalization is renormalized by another native theorem.

Thus the FAR problem has also become temporal.

---

# 19. FAR multiplicity ceiling

Theorem 16.1 implies that an order-one far-field output requires at least one selected carrier of size:

$$
\gtrsim
L_k^{-2/3}.
$$

Therefore its effective cell multiplicity cannot grow faster than:

$$
\boxed{
O(
L_k^{2/3}
)
}
$$

at the selected output scale, up to the chosen carrier normalization.

This is a logarithmic complexity ceiling, not a contradiction.

---

# 20. External commutator defect work

The filtered theory defines a positive commutator defect-work channel:

$$
(W_{\rm com}^{def})_+,
$$

an unresolved critical increment mass:

$$
S_{\rm def}^{(3)},
$$

and the efficiency ratio:

$$
\boxed{
\mathfrak E_{\rm com}
=
\frac{
(W_{\rm com}^{def})_+
}{
S_{\rm def}^{(3)}+\varepsilon
}.
}
$$

The external interpretation is:

-:
  $$
  \mathfrak E_{\rm com}\to0
  $$
  means the unresolved microstructure is asymptotically harmless for positive commutator work;
- a positive lower bound identifies recurrent positive defect work.

### Status

$$
\boxed{
\mathrm{EXTERNAL/DIAGNOSTIC}.
}
$$

---

# 21. CIV/VIII-4.4 — Defect-Work Recurrence Dichotomy

## Theorem 21.1

Suppose on recurrent COM windows:

$$
\boxed{
(W_{{\rm com},n}^{def})_+
\ge
\sigma>0.
}
$$

Then either:

### bounded defect mass

If:

$$
\boxed{
S_{{\rm def},n}^{(3)}
\le
S_\ast
}
$$

along a subsequence, then:

$$
\boxed{
\mathfrak E_{{\rm com},n}
\ge
\frac{
\sigma
}{
S_\ast+\varepsilon
}
>0.
}
$$

### amplitude escape

or:

$$
\boxed{
S_{{\rm def},n}^{(3)}
\to\infty
}
$$

along a subsequence.

$\square$

---

# 22. Meaning for COM

A COM channel which genuinely supplies order-one positive defect work cannot remain simultaneously:

- bounded in unresolved critical defect mass;
- asymptotically zero in defect-work efficiency.

Thus COM recurrence becomes:

$$
\boxed{
\text{POSITIVE DEFECT-WORK RECURRENCE}
\vee
\text{CRITICAL DEFECT AMPLITUDE ESCAPE}.
}
$$

This does not yet provide a global tax.

---

# 23. Full Young tax update

Under the full generalized Young representation from DCRP-03:

$$
\boxed{
\mathfrak T_{uc}=0
\Longrightarrow
\text{Dirac increment profile}.
}
$$

Therefore persistent unresolved COM microstructure satisfies:

$$
\boxed{
\mathfrak T_{uc}>0.
}
$$

But current primary theory does not prove:

$$
\sum_n
\mathfrak T_{uc,n}
<
\infty
$$

or a depletion identity charging this tax.

Thus a positive local strict tax may recur in summably short windows.

This is another temporal-packing gap.

---

# 24. Small-tax limit

Assume the full representation and a uniform fourth-moment bound.

Uniform convexity implies:

if:

$$
\mathfrak T_{uc,n}\to0,
$$

then the Young profiles approach their barycentric Dirac states in the topology controlled by the modulus of convexity.

Hence a vanishing microstructure tax routes COM back toward a resolved increment carrier.

### Safety

No quantitative universal rate is asserted here.

---

# 25. External finite-chain bad-scale counting

Recent finite-chain CKN-bad-scale counting bounds the weighted number of bad scales by explicit nonnegative standard-PDE channels:

- vertical one-component concentration;
- annular leakage;
- pressure-tail terms;
- pressure--flux--energy residuals.

It deliberately uses a canonical amended detector rather than identifying an abstract detector with all PDE channels.

### Status

$$
\boxed{
\mathrm{EXTERNAL/FINITE\mbox{-}CHAIN}.
}
$$

---

# 26. DCRP interpretation of finite-chain counting

Inside a minimal diffuse class:

- fixed-share local concentration routes to atomic reprofile;
- bounded-reservoir annular FAR routes to atomic reprofile;
- pure interior dissipation defect is already removed by MORP;
- remaining finite-chain badness must increasingly rely on diffuse leakage, pressure tails, PFE residuals, or another unresolved carrier.

Thus the external counting theorem reinforces:

$$
\boxed{
WR
}
$$

as the remaining standard-PDE container.

It does not exclude WR on an infinite horizon chain.

---

# 27. External combined-invisible reduction

The moving-window invisible-defect framework proves, under its structural hypotheses, that persistent non-CKN badness leads to:

$$
\boxed{
\text{non-effective moving-window observability}
}
$$

or:

$$
\boxed{
\text{NS-realizable cleaned scale-critical combined-invisible defect cascade}.
}
$$

The combined observation channels include:

- active pressure;
- flux;
- positive energy;
- selected-time adjoint trace.

### Status

$$
\boxed{
\mathrm{EXTERNAL/CONDITIONAL\ REDUCTION}.
}
$$

---

# 28. WORK/RES intersection

DCRP has removed/reprofiled many concentration mechanisms.

However a diffuse carrier may still survive through the same combined-invisible residual kernel identified externally.

Neither carrier entropy nor interaction multiplicity alone excludes such an object.

Therefore:

$$
\boxed{
WR
}
$$

is not closed by Cycle VIII.

---

# 29. Temporal diffuse recurrence normal form

Collect the surviving branches.

### IDR-P

Asymptotically propagated high-shell recurrence with:

$$
\rho_n\to0.
$$

### IDR-S

Super-height fresh-source impulses:

$$
\mathfrak R_n^{fresh}/L_n\to\infty.
$$

### IDR-F

Order-one FAR output with only a logarithmically vanishing selected atomic floor or an exterior/secondary compactness escape.

### IDR-C

Positive recurrent commutator defect work, critical defect amplitude escape, positive Young microstructure tax, or representation failure.

### IDR-W

Non-effective PFET moving-window observability or a combined-invisible WORK/RES defect cascade.

These are all temporal/recurrent forms.

---

# 30. CIV/VIII-4.5 — Temporalization Theorem

## Theorem 30.1

Relative to the internal DCRP-01--03 routing theorems and the external finite-scale modules cited above, every surviving minimal diffuse dangerous recurrence can be represented by at least one IDR-P/S/F/C/W branch.

In particular, bounded-locality spatial complexity, bounded-reservoir FAR recurrence, and pure interior dissipation defects are not independent terminal mechanisms.

### Safety

The theorem is a classification/reduction statement, not an exclusion theorem.

$\square$

---

# 31. Why Cycle VIII cannot close the diffuse obstruction

Every remaining branch has a temporal escape.

### IDR-P

selected propagated carriers may be incompatible across scales and need not form one actual atomic chain.

### IDR-S

source rates may diverge on windows whose durations shrink fast enough that standard weak forcing budgets remain finite.

### IDR-F

selected atomic floors may decay logarithmically and vanish in a time-slice limit.

### IDR-C

positive local microstructure taxes or defect work lack a known global packing budget.

### IDR-W

combined-invisible recurrence is precisely the external unresolved obstruction.

Thus another purely spatial carrier argument cannot close the problem.

---

# 32. Strongest new FAR statement

The far-field branch is nevertheless significantly narrower than before.

Without any uniform annular-reservoir bound, order-one annular output forces:

$$
\boxed{
p_k^{atom}
\gtrsim
[
1+\log(C/r_k)
]^{-2/3}.
}
$$

Therefore a surviving FAR carrier is at most logarithmically diffuse in the selected critical-cell sense.

This may be useful for future trace-persistence or moving-window arguments.

---

# 33. Strongest new SR statement

An infinite shell-span recurrence cannot merely be "high and short."

It is forced into:

$$
\boxed{
\text{almost-complete propagation}
\vee
\text{source rate}\gg\text{shell height}.
}
$$

This makes SR a causal temporal recurrence problem rather than a free spectral escape.

---

# 34. Strongest new COM statement

Order-one positive commutator defect work forces:

$$
\boxed{
\text{positive defect-work efficiency}
}
$$

when unresolved defect mass is bounded.

Under full Young representation, unresolved microstructure also carries a positive strict-convexity tax unless it collapses to a Dirac profile.

The missing theorem is a temporal packing/depletion law for those positive quantities.

---

# 35. Cycle-VIII final surviving object

Define:

$$
\boxed{
\mathcal K_{\rm IDR}
}
$$

as the normalized minimal obstruction class whose recurrence is sustained only through IDR-P/S/F/C/W channels.

Then the Cycle-VIII reduction is:

$$
\boxed{
\text{minimal diffuse obstruction}
\Longrightarrow
\mathcal K_{\rm IDR}.
}
$$

This is the **Impulsive Diffuse Recurrence normal form**.

---

# 36. Cycle-VIII final status

### local concentration recovery

$$
\boxed{
\mathrm{PROVED}.
}
$$

### bounded-locality CROSS

$$
\boxed{
\mathrm{ROUTED/CLOSED\ AS\ PRIMITIVE}.
}
$$

### bounded-reservoir FAR

$$
\boxed{
\mathrm{REPROFILED}.
}
$$

### general FAR

$$
\boxed{
\mathrm{LOGARITHMIC\ ATOMIC\ FLOOR;\ OPEN\ TEMPORALLY}.
}
$$

### shell-span

$$
\boxed{
\mathrm{IMPULSIVE\ PROPAGATION/SOURCE\ DICHOTOMY}.
}
$$

### COM

$$
\boxed{
\mathrm{LOCAL\ RIGIDITY\ TAX;\ GLOBAL\ PACKING\ OPEN}.
}
$$

### WORK/RES

$$
\boxed{
\mathrm{OPEN/COMBINED\mbox{-}INVISIBLE}.
}
$$

---

# 37. Next research program

The surviving problem is now temporal enough that a new program is appropriate.

Define:

$$
\boxed{
\textbf{
NS-IDRP —
Navier--Stokes Impulsive Defect Recurrence Program
}
}
$$

The first paper should be:

$$
\boxed{
\textbf{
NS-IDRP 01 —
Impulse Persistence、
Trace Thickening、
Burst Packing、
Moving-Window Visibility
與 Recurrent Defect Normal Forms
}.
}
$$

Primary tasks:

1. prove persistence/thickening of selected-time logarithmic/fixed atoms;
2. convert source impulses into spacetime packets;
3. quantify whether:
   $$
   \mathfrak R^{fresh}\gg\Lambda
   $$
   forces PFET/model-cone/filtered visibility;
4. derive burst-packing inequalities for recurrent commutator defect work;
5. connect logarithmic FAR atom floors with the sharp moving-window temporal threshold from FCBP;
6. test whether combined-invisible recurrence can remain compatible with impulsive source/trace packets;
7. either recover a non-summable temporal coercive budget or isolate a canonical impulsive ancient/defect object.

---

# 38. Cycle-VIII closure theorem

## Theorem 38.1

Cycle VIII proves that the MORP surviving diffuse carrier cannot remain a purely spatial/scale-fragmentation object.

Under the stated internal/external modules, persistent dangerous support is forced into the Impulsive Diffuse Recurrence class:

$$
\boxed{
\mathcal K_{\rm IDR}.
}
$$

Cycle VIII does **not** prove:

$$
\boxed{
\mathcal K_{\rm IDR}
=
\varnothing.
}
$$

$\square$

---

# 39. Formal status ledger

$$
\boxed{
\begin{aligned}
\text{Impulsive Residence}
&:\ \mathrm{PROVED},\\
\text{Short-Residence Renewal Amplification}
&:\ \mathrm{PROVED},\\
\text{general FAR logarithmic atomic floor}
&:\ \mathrm{PROVED},\\
\text{fixed FAR atomic reprofile without time persistence}
&:\ \mathrm{NOT\ PROVED\ IN\ GENERAL},\\
\text{Defect-Work Recurrence Dichotomy}
&:\ \mathrm{PROVED},\\
\text{strict Young local tax}
&:\ \mathrm{PROVED\ CONDITIONAL},\\
\text{global COM tax/burst packing}
&:\ \mathrm{OPEN},\\
\text{WORK/RES combined-invisible recurrence}
&:\ \mathrm{OPEN},\\
\text{Impulsive Diffuse Recurrence exclusion}
&:\ \mathrm{OPEN},\\
\text{minimal diffuse obstruction exclusion}
&:\ \mathrm{OPEN},\\
\text{Forest Coercive Budget}
&:\ \mathrm{OPEN},\\
\text{Finite Forest Obstruction}
&:\ \mathrm{OPEN},\\
CN3_{\rm Atomic}
&:\ \mathrm{OPEN},\\
\text{Navier--Stokes regularity}
&:\ \mathrm{NOT\ PROVED}.
\end{aligned}
}
$$

---

# 40. Conclusion

DCRP-04 closes Cycle VIII by showing that the diffuse carrier problem has become a temporal recurrence problem.

Shell-span recurrence is forced to have summably small height-residence products.

If inheritance is not asymptotically complete on such episodes, the fresh-source rate must outrun the dissipation-wavenumber height by an unbounded factor.

Far-field recurrence is also more rigid than a generic spatial tail.

Using the exact annular bound and only the global finite-energy filtered-vorticity estimate, order-one annular far-field output produces a selected-time critical atom whose size can decay at worst at a logarithmic power:

$$
\boxed{
[\log(C/r_k)]^{-2/3}.
}
$$

Thus FAR cannot become arbitrarily diffuse, but the atom floor still vanishes and requires a temporal persistence theorem before MORP atomic reprofiling can be invoked with a fixed native lower bound.

The commutator branch has the same temporal character.

Positive defect work either has positive efficiency against bounded unresolved defect mass or is accompanied by critical defect amplitude escape.

Under a full Young representation, unresolved microstructure also carries a strict positive convexity tax unless it collapses to a Dirac profile.

No known theorem packs those positive quantities over an infinite singular horizon.

Finally, finite-chain bad-scale counting and combined-observability theory confirm that persistent badness can still be routed into leakage, pressure tails, PFE residuals, non-effective moving windows, or a cleaned combined-invisible defect cascade.

Therefore the remaining obstruction is no longer well described as "diffuse in space or scale."

It is:

$$
\boxed{
\textbf{
impulsive + recurrent + diffuse/invisible in time.
}
}
$$

That is the next problem.

---

# References

1. A. Cheskidov, R. Shvydkoy, *A unified approach to regularity problems for the 3D Navier--Stokes and Euler equations: the use of Kolmogorov's dissipation range*, arXiv:1102.1944.
2. R. Yu, *Filtered Vortex Stretching and Subgrid Defects for the Three-Dimensional Navier--Stokes Equations*, arXiv:2606.27560.
3. R. Yu, *Finite-Chain CKN-Bad Scale Counting for Navier--Stokes: Standard PDE Closure and Canonical Detector Realization*, arXiv:2606.21783.
4. R. Yu, *Invisible Defect Cascades for Navier--Stokes Regularity*, arXiv:2606.12756.
5. R. Yu, *Critical Ledgers and Scale-Defect Cascades for Navier--Stokes*, arXiv:2606.13887.
6. R. Yu, *Coarse-Grained Resolution and Pressure--Flux Work Depletion for Navier--Stokes CKN Badness*, arXiv:2606.25322.
7. R. Yu, *A Structural Audit of Navier--Stokes Obstruction Calculus*, arXiv:2606.25341.
8. `NS_DCRP_01_CarrierEntropy_ConcentrationRecovery_v0.1.md`.
9. `NS_DCRP_02_InteractionGraph_SupplyMigration_v0.1.md`.
10. `NS_DCRP_03_Packing_YoungRigidity_v0.1.md`.
11. `NS_MORP_CYCLE_VII_HANDOFF_v1.0.md`.
