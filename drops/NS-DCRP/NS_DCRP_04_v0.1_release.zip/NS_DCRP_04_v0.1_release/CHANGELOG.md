# CHANGELOG

## v0.1 — 2026-08-16

- Closes Cycle VIII as a diffuse-carrier routing and temporalization cycle.
- Uses universal Lambda in L1 to prove shell-span height-residence numbers are summable and tend to zero.
- Combines the shell-span residence law with the corrected causal dual ledger.
- Proves fixed inheritance deficit on shrinking shell-span episodes forces fresh-source rate to outrun shell height by an unbounded factor.
- Reclassifies SR as asymptotic propagated inheritance or super-height source impulse.
- Proves a uniform filtered-vorticity spacetime bound from finite kinetic energy at relative filter scale.
- Removes the prior uniform annular-reservoir assumption from the FAR analysis.
- Proves a weighted annular l2-to-max lemma and a logarithmic annular-output atom lower bound.
- Combines core and annular atom channels to obtain the [log(C/r)]^{-2/3} selected-time FAR atomic floor.
- Shows general FAR diffuseness is at most logarithmic in this critical-cell sense, but remains a temporal persistence problem.
- Reclassifies order-one commutator defect work as positive defect-work efficiency or critical defect amplitude escape.
- Integrates finite-chain bad-scale counting and combined-invisible moving-window reductions into the final WORK/RES branch.
- Defines the Impulsive Diffuse Recurrence normal form K_IDR.
- Launches the Navier-Stokes Impulsive Defect Recurrence Program.
