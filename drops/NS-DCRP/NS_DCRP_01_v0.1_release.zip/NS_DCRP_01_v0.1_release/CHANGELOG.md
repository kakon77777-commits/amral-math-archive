# CHANGELOG

## v0.1 — 2026-08-16

- Launches the Navier-Stokes Diffuse Carrier Rigidity Program.
- Defines Shannon carrier entropy, Renyi concentration, and nonlinear effective multiplicity.
- Proves entropy divergence alone is not a dynamical tax under a linear carrier ledger.
- Proves a generic superlinear-output concentration-recovery theorem.
- Builds wavelength-scale spatial cells for a dyadic vorticity shell.
- Proves a pseudolocal L-infinity bound for same-shell strain from enlarged-cell vorticity mass plus Schwartz leakage.
- Proves diffuse atom collapse suppresses normalized gross same-shell diagonal stretching.
- Proves a fixed normalized positive same-shell diagonal stretching fraction forces a fixed-share enlarged wavelength atom.
- Gives the first quantitative atomic reprofiling threshold p >= c sigma^2.
- Proves a diffuse source-migration compiler: persistent dangerous output must leave the same-shell diagonal channel and enter cross-scale/far-field/commutator/work/residual channels.
- Connects the new carrier-rigidity problem to profile decomposition, flux locality, filtered stretching, and finite-chain bad-scale counting.
- Moves the next frontier to the interaction graph of migrated supply.
