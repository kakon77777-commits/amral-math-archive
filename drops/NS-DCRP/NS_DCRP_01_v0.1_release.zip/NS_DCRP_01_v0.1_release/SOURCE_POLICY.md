# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Shannon entropy divergence is not treated as a PDE contradiction.
- Same-shell concentration recovery is not promoted to the full vortex-stretching/source term.
- Pseudolocal leakage remains explicit and is controlled only after choosing a fixed enlargement factor.
- External flux locality is not imported outside its stated inertial-range hypotheses.
- Atomic recovery is not promoted to actual infinite-branch shadowing.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
