# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Interaction multiplicity divergence is not treated as a contradiction without a geometric/packing tax.
- Abstract graph sharpness is not treated as a Navier-Stokes realization.
- Same-shell spatial multiplicity and distinct-shell source multiplicity remain separate.
- Comparable-annulus recovery is not promoted to unweighted Carleson packing.
- The commutator coherence theorem is conditional on a carrier-resolved increment decomposition.
- Young covariance/stress invisibility is not promoted to trivial microstructure.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
