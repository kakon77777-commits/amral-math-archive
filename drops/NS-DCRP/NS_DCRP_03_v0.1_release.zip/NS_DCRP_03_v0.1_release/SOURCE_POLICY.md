# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Dissipation-wavenumber height alone is not treated as a strict obstruction; residence is explicit.
- FAR atom recovery uses the same-scale exact annular reservoir and bounded reservoir hypotheses.
- Conditional Carleson closure is not promoted to an unconditional far-field packing theorem.
- Strict Young rigidity requires full representation for the strict uniformly-convex functional.
- Covariance zero remains insufficient for Dirac rigidity.
- A positive local microstructure tax is not promoted to a global finite budget.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
