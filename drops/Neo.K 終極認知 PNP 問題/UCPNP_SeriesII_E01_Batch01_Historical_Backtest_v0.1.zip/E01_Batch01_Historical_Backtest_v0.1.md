# UCPNP Series II — E01 Historical Cognitive Backtest Corpus
## Batch 01：Dijkstra Shortest Path、Four Color Theorem、AlexNet / ImageNet

**Series:** Neo.K Ultimate Cognitive P/NP — Series II Experiments  
**Experiment:** E01 — Historical Cognitive Backtest Corpus  
**Batch:** 01  
**Version:** v0.1  
**Author:** Neo.K  
**Collaborative analysis:** Aletheia  
**Date:** 2026-08-16  
**Status:** Historical documentary backtest with Evidence Passports. This batch estimates phase-specific upper bounds and unresolved regions; it does not claim exact earliest possible years unless explicitly proved.

---

# 0. Purpose

UCPNP Series I 提出：

$$
\boxed{
\mathbf Y^{(s)}(x)
=
(
Y_R^{(s)},
Y_D^{(s)},
Y_C^{(s)},
Y_E^{(s)},
Y_V^{(s)},
Y_{\mathrm{Cert}}^{(s)}
)
}
$$

並要求區分：

$$
\text{representation},
\text{discovery},
\text{construction},
\text{execution},
\text{verification},
\text{certification}.
$$

本 Batch 不以「哪一年科技變強」作結論，而問：

> 三種結構完全不同的突破，是否真的產生不同 historical tractability signatures？

選取三個案例：

1. Dijkstra shortest path algorithm；
2. Appel–Haken Four Color Theorem；
3. AlexNet / ImageNet large-scale visual recognition。

它們分別用來檢驗：

$$
\text{method-dominant},
$$

$$
\text{proof/certification-lag},
$$

$$
\text{mixed data–hardware–method convergence}.
$$

---

# 1. Method

## 1.1 Frontier date semantics

本文不把日期欄位自動視為「歷史上絕對最早」。

使用三種日期狀態：

### `UB(y)` — documented upper bound

最遲到年份 $y$，該 phase 已經實際達成。

例如：

$$
Y_D\le1959.
$$

### `LB(y)` — necessary lower bound

在年份 $y$ 前，某明示必要條件尚未存在。

只有在來源足以支持時才使用。

### `UNRESOLVED[a,b]`

目前資料不足以判定最早年份，但已知落在某區間或只有上界。

---

## 1.2 Counterfactual scenarios

延續 Paper 04：

$$
\mathsf S_0
=
\text{Endogenous History},
$$

$$
\mathsf S_1
=
\text{Method Transport},
$$

$$
\mathsf S_2
=
\text{Artifact Transport},
$$

$$
\mathsf S_3
=
\text{Result / Certificate Transport}.
$$

本 Batch 主要比較：

$$
\mathsf S_0
\quad\text{vs}\quad
\mathsf S_1.
$$

---

## 1.3 Mechanism labels

主要 mechanism 只標：

$$
K,\Sigma,\Gamma,H,M,N,E,\kappa.
$$

其中：

- $K$：新知識／數學事實；
- $\Sigma$：可重用知識凝結；
- $\Gamma$：task-semantics-preserving representation transformation；
- $H$：硬體／物理計算；
- $M$：算法／軟體／工具；
- $N$：集體／協作；
- $E$：外部資料／環境資訊；
- $\kappa$：proof / certification contract。

若 evidence 只支援類比，不把 $\Gamma$ 寫成 exact identification。

---

# 2. Case A — Dijkstra shortest path

## 2.1 Task contract

固定問題：

> 給定具有非負／正 edge lengths 的 connected weighted graph，求兩個指定 vertices 間的最短路徑。

Dijkstra 在 1959 年的 *Numerische Mathematik* 論文 *A note on two problems in connexion with graphs* 中正式提出兩個 graph problems，其中 Problem 2 即是求兩個指定 nodes 間的 minimal-length path。

因此：

$$
\boxed{
Y_D^{(\mathsf S_0)}
\le1959.
}
$$

這是 publication-level documented upper bound，不宣稱 1959 是思想首次出現的精確日期。

---

## 2.2 Phase vector

### Representation

weighted graph 與 path-length 語義在論文中已明確。

$$
Y_R^{(\mathsf S_0)}
\le1959.
$$

### Discovery

方法在 1959 論文中給出。

$$
Y_D^{(\mathsf S_0)}
\le1959.
$$

### Construction

algorithmic procedure 本身已可由論文描述實作。

$$
Y_C^{(\mathsf S_0)}
\le1959.
$$

### Execution under method transport

本 Batch 沒有找到足以證明「絕對最早 machine execution year」的 primary historical record。

因此只給：

$$
Y_E^{(\mathsf S_1)}
\le1959,
$$

因為到 publication 時 algorithm 已具 operational procedure。

更早年份：

$$
\boxed{
Y_E^{(\mathsf S_1)}<1959
}
$$

是否成立，標記：

`UNRESOLVED`.

### Verification / certification

1959 paper 本身提供數學 algorithm publication，但本 Batch 不把 peer-reviewed publication 等同 machine-checked certification。

所以：

$$
Y_V\le1959
$$

只標為 mathematical-publication verification upper bound；

machine-formal certification：

`UNRESOLVED / NOT REQUIRED BY ORIGINAL TASK`.

---

## 2.3 Dominant mechanism attribution

最保守 attribution：

$$
\boxed{
M\text{-dominant}.
}
$$

理由：任務語義沒有被改寫成不同問題；核心突破是新的 shortest-path method。

可能存在 representation insight，但本 Batch 不把它升格成 $\Gamma$ theorem。

---

## 2.4 UCPNP signature

Dijkstra case 顯示：

$$
\boxed{
\text{execution resource was not the only or clearly dominant historical frontier}.
}
$$

我們至少已知：

$$
Y_D\le1959,
\qquad
Y_E^{(\mathsf S_1)}\le1959.
$$

因此目前沒有證據支持「先有長期硬體可執行能力、很久以後才有方法」或相反的大 gap。

這個 case 被歸為：

$$
\boxed{
\textbf{Method-Dominant / Low-Certification-Lag Case}.
}
$$

---

# 3. Case B — Four Color Theorem

## 3.1 Task contract

固定 theorem：

> 每一個 planar map 都可以用至多四種顏色著色，使相鄰 regions 顏色不同。

Appel 與 Haken 在 1976 年發表 proof announcement，並明確表示其成功有 electronic computers 的 substantial help；1977 年完整工作以兩部分刊於 *Illinois Journal of Mathematics*。

因此：

$$
Y_D^{(\mathsf S_0)}
\le1976.
$$

---

## 3.2 Representation / construction

Appel–Haken 路線將無限 planar maps 的問題轉換為：

- unavoidable configurations；
- reducibility checks；
- computer-assisted finite checking。

對 UCPNP 而言，這至少是：

$$
\boxed{
M+H
}
$$

的明確混合介入。

其 finite configuration reduction 具有 representation-transformative 特徵，因此標：

$$
\Gamma\text{-candidate / proxy},
$$

但本 Batch 不宣稱它與 Paper 03 的一般 $\Gamma$ 完全同構。

---

## 3.3 Phase vector

### Discovery

1976 announcement：

$$
Y_D^{(\mathsf S_0)}
\le1976.
$$

### Construction / execution

computer-assisted reducibility calculation 已完成，proof 才能被宣布。

因此：

$$
Y_C^{(\mathsf S_0)}
\le1976,
$$

$$
Y_E^{(\mathsf S_0)}
\le1976.
$$

### Journal-level verification / certification

完整兩部 proof 於 1977 發表，並附大量 supplementary material。

以：

$$
\kappa_{\mathrm{journal}}
$$

表示當時 mathematical-publication / community contract：

$$
Y_{\mathrm{Cert}}^{\kappa_{\mathrm{journal}}}
\le1977.
$$

### Formal machine-checked certification

Georges Gonthier 與 Benjamin Werner 在 2005 年完成 Coq fully computer-checked proof。

令：

$$
\kappa_{\mathrm{formal}}
=
\text{proof-assistant checked contract}.
$$

則：

$$
\boxed{
Y_{\mathrm{Cert}}^{\kappa_{\mathrm{formal}}}
\le2005.
}
$$

---

## 3.4 Certification-lag signature

此 case 因此明確出現：

$$
\boxed{
Y_D
\le1976
<
Y_{\mathrm{Cert}}^{\kappa_{\mathrm{formal}}}
\le2005.
}
$$

注意這不表示 theorem 在 1976–2005 是「假」的。

它表示：

$$
\boxed{
\text{truth/proof result}
\neq
\text{formal proof-assistant certification contract}.
}
$$

這正是 Paper 02 / Paper 05 的 Truth–Evidence–Certification distinction 在真實數學史上的一個強案例。

---

## 3.5 Mechanism attribution

1976：

$$
\boxed{
\Gamma_{\mathrm{proxy}}
+
M
+
H.
}
$$

2005：

$$
\boxed{
M
+
\Sigma
+
\kappa.
}
$$

其中 Coq formalization 同時需要 formal proof language、proof engineering 與大量 reusable formal structures，因此 $\Sigma$ 只標 candidate，而不是精確 measured scalar。

---

## 3.6 UCPNP signature

$$
\boxed{
\textbf{Discovery/Execution Early + Formal-Certification Lag}.
}
$$

這個案例直接否定單一：

$$
Y_{\mathrm{solved}}
$$

足以描述完整歷史狀態的做法。

---

# 4. Case C — AlexNet / ImageNet

## 4.1 Task contract

本 Batch 固定成：

> 在 ImageNet / ILSVRC large-scale object-classification task 上，以 AlexNet 類 deep convolutional architecture 完成 1000-class classification，達到 2012 paper 報告的 performance regime。

AlexNet paper 報告：

- 約 1.2 million ILSVRC-2010 training images；
- 1000 classes；
- 60 million parameters；
- GPU-optimized convolution；
- ReLU；
- dropout；
- 兩張 GTX 580 3GB GPUs；
- training 約 five to six days；
- ILSVRC-2012 top-5 test error 15.3%，second-best entry 26.2%。

---

## 4.2 Environment / data frontier

ImageNet 2009 paper 報告當時已有：

$$
3.2\text{ million images}
$$

與：

$$
5247\text{ synsets}
$$

的 database state。

ILSVRC 從 2010 起提供 standardized 1000-category large-scale challenge。

因此：

$$
Y_E^{\mathrm{data}}
\le2009
$$

對 ImageNet database availability 成立；

而 AlexNet 所對應 challenge environment：

$$
Y_E^{\mathrm{ILSVRC}}
\le2010.
$$

---

## 4.3 Hardware / method frontier

AlexNet 原論文明確指出：

> large high-resolution CNNs 此前仍 prohibitively expensive，但 contemporary GPUs 加 highly optimized 2D convolution 已足以訓練 large CNNs。

其 final network：

$$
\boxed{
5\text{--}6\text{ days}
}
$$

訓練於：

$$
\boxed{
2\times\mathrm{GTX\ 580\ 3GB}.
}
$$

因此實證上：

$$
Y_H^{\mathrm{demonstrated}}
\le2012,
$$

$$
Y_M^{\mathrm{demonstrated}}
\le2012,
$$

$$
Y_E^{(\mathsf S_0)}
\le2012.
$$

---

## 4.4 Discovery / verification

AlexNet method and result publication：

$$
Y_D^{(\mathsf S_0)}
\le2012.
$$

Held-out challenge evaluation：

$$
Y_V^{(\mathsf S_0)}
\le2012.
$$

Competition/publication certification contract：

$$
Y_{\mathrm{Cert}}^{\kappa_{\mathrm{benchmark}}}
\le2012.
$$

---

## 4.5 The unresolved counterfactual

最重要的是，本 Batch **不**宣稱：

$$
Y_E^{(\mathsf S_1)}=2012.
$$

因為要判定：

> 如果把 2012 AlexNet method 送回 2008、2009、2010 或 2011，最早哪一年 hardware/software stack 真能在合理成本內重現？

需要：

- historical GPU architecture；
- CUDA/toolchain；
- exact memory constraints；
- implementation portability；
- training-time tolerance；
- dataset availability；
- architecture-aware replay。

本 Batch 尚未做 emulator / hardware-faithful reproduction。

因此：

$$
\boxed{
Y_E^{(\mathsf S_1)}
=
\mathrm{UNRESOLVED}
\quad
\text{with documented upper bound }2012.
}
$$

這正是 HCTF 應該保留的「不知道」。

---

## 4.6 Mechanism attribution

AlexNet 不是單一 $H$-type breakthrough。

至少有：

$$
\boxed{
E
+
M
+
H
}
$$

明確共同作用：

- $E$：ImageNet / ILSVRC large labeled data；
- $M$：GPU convolution implementation、ReLU、dropout、training method；
- $H$：GPU memory / throughput。

其 deep learned representations 可視為：

$$
\Gamma\text{-candidate},
$$

但 Paper 03 的 $\Gamma$ 要求 task-semantic-preserving representation intervention 與可測 lifecycle attribution；本 Batch 沒有完成 pure-$\Gamma$ ablation，因此只標 proxy/analogy。

---

## 4.7 UCPNP signature

$$
\boxed{
\textbf{Mixed Convergence Case}
}
$$

其結構為：

$$
E_{\mathrm{data}}
\text{ 先出現}
\rightarrow
(M+H+\text{architecture})
\text{ 匯流}
\rightarrow
\text{2012 breakthrough}.
$$

所以「只是 GPU 變快」與「只是 neural network idea」都不足以描述整個 frontier shift。

---

# 5. Cross-case phase matrix

| Case | Documented discovery UB | Demonstrated execution UB | Certification structure | Dominant UCPNP signature |
|---|---:|---:|---|---|
| Dijkstra shortest path | 1959 | 1959 | ordinary mathematical publication; formal-machine cert not required | Method-dominant |
| Four Color Theorem | 1976 | 1976 | journal/community by 1977; formal Coq by 2005 | Certification-lag |
| AlexNet / ImageNet | 2012 | 2012 | benchmark/publication by 2012 | Mixed E+M+H convergence |

這張表最重要的不是年份，而是三個 shape 不同。

---

# 6. First backtest result

## Result R6.1 — One-year narratives are lossy

三個案例都無法被單一：

$$
Y_{\mathrm{solved}}
$$

完整描述。

Dijkstra 的主資訊在 method 出現；

Four Color 的：

$$
Y_D
$$

與 formal：

$$
Y_{\mathrm{Cert}}
$$

差近三十年；

AlexNet 則需要至少：

$$
E+M+H
$$

共同出現。

因此第一批資料支持：

$$
\boxed{
\text{phase-specific historical frontier}
}
$$

比：

$$
\boxed{
\text{single breakthrough year}
}
$$

提供更多結構資訊。

這是 descriptive result，不是統計顯著性 claim。

---

# 7. Result R7.1 — HCTF can preserve uncertainty without collapse

Batch 01 有意保留：

$$
Y_E^{(\mathsf S_1)}(\mathrm{AlexNet})
=
\mathrm{UNRESOLVED}.
$$

這不是缺點。

若 HCTF 為了產生完整表格而強迫填一個年份，就會把：

$$
\text{model estimate}
$$

偷換成：

$$
\text{historical fact}.
$$

所以 Batch 01 第一個 epistemic test 也算通過：

$$
\boxed{
\text{the framework can represent ignorance explicitly}.
}
$$

---

# 8. Mechanism discrimination result

三案例形成：

$$
\boxed{
\begin{aligned}
\text{Dijkstra}&:\ M,\\
\text{Four Color 1976}&:\ \Gamma_{\mathrm{proxy}}+M+H,\\
\text{Four Color 2005}&:\ M+\Sigma_{\mathrm{candidate}}+\kappa,\\
\text{AlexNet}&:\ E+M+H+\Gamma_{\mathrm{candidate}}.
\end{aligned}
}
$$

因此第一批案例沒有被 UCPNP 強迫解釋成：

$$
\text{more compute}.
$$

---

# 9. Evidence Passport summary

## P-A — Dijkstra 1959

- Claim Type: E / historical documentary；
- Scope: shortest-path method publication；
- Evidence: original journal article；
- Reproduction: not required for publication fact；
- Strong claim allowed: method documented by 1959；
- Strong claim forbidden: exact earliest execution year。

## P-B1 — Four Color 1976/1977

- Claim Type: E；
- Scope: first Appel–Haken computer-assisted proof；
- Evidence: original announcement + original publication；
- Strong claim allowed: computer assistance was essential to published route；
- Strong claim forbidden: formal proof-assistant certification already existed。

## P-B2 — Four Color 2005

- Claim Type: E；
- Scope: fully computer-checked Coq proof；
- Evidence: Gonthier formalization record；
- Strong claim allowed: formal-machine certification by 2005；
- Strong claim forbidden: 1976 proof therefore lacked mathematical truth。

## P-C — AlexNet 2012

- Claim Type: E；
- Scope: reported ImageNet/ILSVRC training/evaluation regime；
- Evidence: original NeurIPS paper + ImageNet primary paper；
- Strong claim allowed: 2012 execution demonstrated on two GTX 580 3GB GPUs；
- Strong claim forbidden: exact earliest counterfactual execution year before 2012。

---

# 10. Falsification check

Batch 01 would weaken HCTF if all three cases collapsed into the same explanation.

They do not.

However, this batch is still too small to establish:

$$
\boxed{
\text{HCTF has predictive validity}.
}
$$

It only establishes:

$$
\boxed{
\text{HCTF has nontrivial descriptive discrimination on three cases}.
}
$$

The next requirement is out-of-sample expansion.

---

# 11. Batch 02 selection rule

下一批不能只選與 Batch 01 相似的成功史。

建議加入：

1. **FFT / algorithmic rediscovery**：測 historical idea vs modern computational method；
2. **SAT solver / CDCL**：測 $\Sigma$-like learned clauses、heuristics、software stack；
3. **public-key cryptography / RSA**：測 mathematical discovery、hardware practicality、standards/deployment；
4. **formal proof system case**：測 verification/certification；
5. **database / search indexing**：測 precomputation / lifecycle cost。

Batch 02 至少應有一個案例讓 UCPNP 的初始 attribution 判錯，才有校準價值。

---

# 12. Conclusion

Series II 的第一批實例得到三種不同的 historical tractability signatures：

$$
\boxed{
\text{Method-Dominant}
}
$$

$$
\boxed{
\text{Certification-Lag}
}
$$

$$
\boxed{
\text{Mixed-Convergence}.
}
$$

因此目前最有價值的結論不是：

> UCPNP 被證明了。

而是：

$$
\boxed{
\text{UCPNP 至少能在三個已知歷史案例中，
保留不同瓶頸、不同證據契約與不同未知區間。}
}
$$

這使下一步可以從「理論套案例」轉成真正的：

$$
\boxed{
\text{cross-case backtesting}
+
\text{prediction / attribution error analysis}.
}
$$

---

# References

## Dijkstra

1. E. W. Dijkstra. *A note on two problems in connexion with graphs*. Numerische Mathematik 1, 269–271 (1959). DOI: 10.1007/BF01386390.

## Four Color Theorem

2. K. Appel and W. Haken. *A proof of the four color theorem*. Discrete Mathematics 16(2), 179–180 (1976). DOI: 10.1016/0012-365X(76)90147-3.
3. K. Appel and W. Haken. *Every planar map is four colorable, I: Discharging*. Illinois Journal of Mathematics 21(3), 429–490 (1977).
4. K. Appel, W. Haken, and J. Koch. *Every planar map is four colorable, II: Reducibility*. Illinois Journal of Mathematics 21(3), 491–567 (1977).
5. Georges Gonthier. *A Computer-Checked Proof of the Four Colour Theorem* / Coq formalization, completed 2005; later exposition *Formal Proof—The Four-Color Theorem*, Notices AMS (2008).

## ImageNet / AlexNet

6. Jia Deng, Wei Dong, Richard Socher, Li-Jia Li, Kai Li, Li Fei-Fei. *ImageNet: A Large-Scale Hierarchical Image Database*. CVPR 2009. DOI: 10.1109/CVPR.2009.5206848.
7. Alex Krizhevsky, Ilya Sutskever, Geoffrey E. Hinton. *ImageNet Classification with Deep Convolutional Neural Networks*. NeurIPS 2012.
