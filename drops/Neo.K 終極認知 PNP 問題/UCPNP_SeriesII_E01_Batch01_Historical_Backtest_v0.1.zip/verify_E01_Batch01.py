import csv, json
from pathlib import Path

base=Path(__file__).parent
rows=list(csv.DictReader((base/"E01_Batch01_Phase_Matrix_v0.1.csv").open(encoding="utf-8")))
assert len(rows)==3
ids={r["case_id"] for r in rows}
assert ids=={"A_Dijkstra","B_FourColor","C_AlexNet"}

# Ensure unresolved counterfactual is retained rather than silently assigned.
alex=next(r for r in rows if r["case_id"]=="C_AlexNet")
assert "UNRESOLVED" in alex["Y_E_S1"]

# Four-color must preserve certification contract split.
fc=next(r for r in rows if r["case_id"]=="B_FourColor")
assert "1977" in fc["Y_Cert"] and "2005" in fc["Y_Cert"]

# Mechanism signatures must not all collapse.
sigs={r["signature"] for r in rows}
assert len(sigs)==3

p=json.loads((base/"E01_Batch01_Evidence_Passports_v0.1.json").read_text(encoding="utf-8"))
assert len(p["passports"])==5
assert any(x["reproduction_status"]=="unresolved" for x in p["passports"])

print("UCPNP E01 Batch01 consistency checks: PASS")
