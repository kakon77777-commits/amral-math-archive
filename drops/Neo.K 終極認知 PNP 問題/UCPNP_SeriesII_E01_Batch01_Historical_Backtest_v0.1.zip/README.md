# UCPNP Series II E01 — Batch 01

This release contains the first historical backtest instances for the Neo.K Ultimate Cognitive P/NP framework.

Files:
- `E01_Batch01_Historical_Backtest_v0.1.md`
- `E01_Batch01_Phase_Matrix_v0.1.csv`
- `E01_Batch01_Evidence_Passports_v0.1.json`
- `verify_E01_Batch01.py`
- `E01_Batch01_Source_Integrity_v0.1.json`
- `CHECKSUMS.sha256`

Cases:
1. Dijkstra shortest path — method-dominant.
2. Four Color Theorem — discovery/execution vs formal-certification lag.
3. AlexNet/ImageNet — mixed data/method/hardware convergence.

Important:
Dates are documented upper bounds unless explicitly marked otherwise. `UNRESOLVED` is an intentional output state.
