# Paper 01 Claim Matrix — Agent-Relative Tractability v0.1

**Parent paper:** `01_UCPNP_Agent_Relative_Tractability_v0.1.md`  
**Purpose:** separate Definition / Theorem / Conjecture / Empirical / Normative claims before later experimental use.

| ID | Type | Claim | Dependency | Current evidence |
|---|---|---|---|---|
| D2.1 | D | Verification-bearing task semantic contract $\mathfrak T$ | Paper 00 | Definition |
| D3.1 | D | Operational agent model $\mathfrak A_\Xi$ | Paper 00 | Definition |
| D3.2 | D | Admissible policy requires declared information/tool access and cost accounting | D2.1, D3.1 | Definition |
| D7.1 | D | Cognitive-P-like iff $\rho_C\le1$ under a fixed contract | D2.1–D6 | Definition |
| D7.2 | D | Cognitive-NP-like iff $\rho_V\le1<\rho_C$ | D2.1–D6 | Definition |
| D12.1 | D | Uniform family-level cognitive tractability requires one meta-policy generator plus declared advice budget | D2–D7 | Definition |
| D13.1 | D | Tractability transition is a legal state change crossing $\rho_C=1$ | D7.1 | Definition |
| T9.1 | T | Resource monotonicity | D6 | Direct inequality proof |
| T9.2 | T | Capability-extension monotonicity | D3, D6 | Feasible-set inclusion proof |
| T9.3 | T | Operationally equivalent agent states have identical tractability | D3, D5, D6 | Extensional equality proof |
| T9.4 | T | Cost-preserving semantics-preserving re-encoding preserves tractability | D2, D3, D5 | Policy-bijection proof |
| T9.5 | T | No-free-precomputation accounting | Cost additivity contract | Accounting identity |
| T9.6 | T | Oracle improvement must be attributed to the augmented state unless oracle cost/provenance is included | D3.2 | State-accounting consequence |
| C19.1 | C/E | $\Delta\rho_C$ may admit stable decomposition across $\Delta\Sigma,\Delta\Gamma,\Delta H,\Delta M,\Delta N,\Delta E$ | Future Papers 03–06 | Open |
| C19.2 | C | Some semantics-preserving $\Gamma$ transformations yield gains not reproducible by pure hardware scaling | Paper 05 candidate | SDPE-BEB finite candidate only |
| C19.3 | C | Agent states may admit useful task-relative quotient by policy-cost kernels | T9.3 | Open |
| C19.4 | E | Historical cognitive tractability model can beat simple hardware-trend baselines | Paper 04 | Not tested |
| N-boundary | N | Capability rank does not imply dignity rank | Paper 00 / Paper 08 | Normative axiom, not derived here |

## Prohibited inference table

| Observed fact | Invalid inference |
|---|---|
| One tested solver fails | No admissible solver exists |
| One run succeeds | A reliable policy exists |
| Candidate verification is cheap | Discovery is cheap |
| Online lookup is $O(1)$ | Total cognition was $O(1)$ |
| New representation is shorter | It is a genuine $\Gamma$ gain without translation/precompute cost |
| Oracle access makes task easy | Internal intelligence improved by the same amount |
| Agent A dominates Agent B on benchmark $D$ | A is globally superior |
| Agent A has greater capability | A has greater dignity or ontological rank |

## Release gate

A later revision may promote a C/E claim to T only if it supplies explicit assumptions, a proof object or independently checkable derivation, and a migration note. No empirical result may silently rewrite D7.1 or D7.2.
