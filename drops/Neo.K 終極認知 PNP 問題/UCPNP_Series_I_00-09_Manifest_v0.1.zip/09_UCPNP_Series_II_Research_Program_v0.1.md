# UCPNP Series II — Experimental Research Program v0.1

Series I is now definition- and methodology-complete enough to stop adding foundational vocabulary by default.

## E01 — Historical Cognitive Backtest Corpus
Goal: test whether phase-specific historical frontiers explain known algorithmic/engineering transitions better than hardware-only narratives.

## E02 — Sigma/Gamma Factorial Benchmark
Goal: perform 2x2 knowledge/representation ablations under fixed task semantics and lifecycle accounting.

## E03 — Collective Cognitive Matrix
Goal: compare single vs multi-agent systems under equal aggregate budgets; vary diversity, memory, communication, and aggregation.

## E04 — Long-Horizon and Self-Modification Audit
Goal: measure autonomy horizon, persistence, feedback incorporation, self-modification revalidation, and cost-normalized improvement.

## E05 — UCPNP Open Benchmark and Evidence Passport Registry
Goal: release a machine-readable task/agent/resource/evidence/provenance registry enabling independent reproduction.

## Stop rule
Do not create a new foundational UCPNP variable unless:
1. an existing variable provably cannot represent the observed distinction;
2. at least one controlled example requires the new distinction;
3. the new variable has an operational measurement or audit contract.
