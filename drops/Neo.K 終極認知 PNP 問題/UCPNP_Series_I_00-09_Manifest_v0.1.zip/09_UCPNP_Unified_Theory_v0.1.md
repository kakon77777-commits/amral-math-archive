# Neo.K 終極認知 P/NP 統一論：智能體相對可解性、認知歷史、集體智能、未來智慧與反僭越邊界

**English title:** *The Neo.K Ultimate Cognitive P/NP: A Unified Theory of Agent-Relative Tractability, Cognitive History, Collective Intelligence, Future Agents, and Anti-Overclaim Boundaries*  
**Series:** Neo.K Ultimate Cognitive P/NP Problem  
**Paper:** 09 / Series I Unified Synthesis  
**Version:** v0.1  
**Author:** Neo.K  
**Collaborative formalization:** Aletheia  
**Date:** 2026-08-15  
**Status:** Series-I unified synthesis. It integrates Papers 00–08; it does not claim to solve classical $P$ vs. $NP$, prove a universal law of cognition, or establish any AGI/ASI/ultimate-being existence claim.

---

# Canonical non-identity statement

$$
\boxed{
\mathrm{UCPNP}_{\mathrm{Neo.K}}
\neq
(P\stackrel{?}{=}NP)_{\mathrm{classical}}.
}
$$

本文所稱「Neo.K 終極認知 P/NP 問題」是由 Neo.K 定義的智能體—認知—計算研究問題。

它借用標準 P/NP 中「求解／構造與驗證可能具有顯著不對稱」的直覺，但不重定義標準 complexity classes，也不宣稱：

$$
P=NP
$$

或：

$$
P\neq NP.
$$

本文的「終極」修飾的是：

$$
\boxed{
\text{problem scope}
}
$$

而不是：

$$
\boxed{
\text{being rank}.
}
$$

因此：

$$
\boxed{
\text{Ultimate Cognitive P/NP}
\not\Rightarrow
\text{Ultimate Being}.
}
$$

---

# 摘要

本文完成 Neo.K Ultimate Cognitive P/NP Series I 的第一次統一。系列前九個模組已依序建立：Paper 00 的正典問題與非同一性；Paper 01 的 agent-relative tractability；Paper 02 的 Representation–Discovery–Construction–Execution–Verification–Certification 成本分解與 Truth–Evidence–Certification 分離；Paper 03 的 Knowledge Condensation $\boldsymbol\Sigma$ 與 Representation Generation $\boldsymbol\Gamma$；Paper 04 的 Historical Cognitive Tractability Frontier；Paper 05 的 SDPE-BEB controlled micro-model；Paper 06 的 collective cognitive tractability；Paper 07 的 posthuman / AGI / ASI future-agent envelope；Paper 08 的 Capability–Epistemic Authority–Qualification–Responsibility–Dignity separation。

本文提出 UCPNP Master State：

$$
\boxed{
\mathfrak U_t
=
(
\mathfrak T,
\Psi_t,
\mathcal N_t,
\mathbf B_t,
\mathcal O_t,
\mathbf C_t,
\eta_t,
\boldsymbol\Sigma_t,
\boldsymbol\Gamma_t,
\mathcal F_t,
\Lambda_t,
\mathfrak N_t
).
}
$$

它不被解讀為宇宙的單一「智能方程」，而是一個研究帳本：固定任務語義、智能體 profile、集體網路、資源、合法操作、成本、認知證據狀態、可重用知識、表示變換、tractability frontier、歷史 lineage 與規範接口。

在此基礎上，Neo.K 終極認知 P/NP 問題可以形式化為一種**受約束的 tractability transition problem**。若任務 $x$ 在狀態 $\mathfrak U_t$ 下具有：

$$
\rho_V(x\mid\mathfrak U_t)\le1<\rho_C(x\mid\mathfrak U_t),
$$

亦即可驗證但 completion 不可在當前 budget 內達成，則研究目標是尋找合法、可記帳、語義保持的 intervention $I_t$，使：

$$
\mathfrak U_{t+1}
=
\mathcal G(\mathfrak U_t,I_t),
$$

且：

$$
\rho_C(x\mid\mathfrak U_{t+1})\le1.
$$

intervention 可能來自：

$$
K,\boldsymbol\Sigma,\boldsymbol\Gamma,H,M,N,E,\tau,\mu,\kappa
$$

的改變，而非單純「更多算力」。

本文進一步建立三個統一原則。第一，**Multi-Frontier Principle**：completion、verification、certification、historical discovery、collective tractability、future-agent capability 與 normative admissibility 不是同一 frontier。第二，**No Universal Scalar Collapse**：UCPNP 的核心狀態在多維資源、跨 domain 能力、error correlation、evidence scope 與 normative standing 上存在結構性交叉，因此任何單一 scalar intelligence score 都只能是明示 projection，而不能作為普適排序。第三，**Evidence Passport Principle**：任何 theorem、empirical result、historical estimate、forecast 或 normative claim 必須同時附帶 Claim Type、Scope、Evidence Level、Contract、Reproduction Status 與 Dependencies。

本文最終將 UCPNP 壓縮為一個問題：

> 對有限但可變的智能體，在固定任務語義與明示資源、歷史、合作、證據與規範條件下，哪些可審計介入能把「可驗證但目前難以可靠取得」的任務轉化為「可發現、可生成、可執行、可驗證、可認證」，其成本被移到哪裡，其證據支撐到哪裡，而這種能力變化又不應被偷換成何種本體或尊嚴結論？

這使 UCPNP 從早期「認知 P/NP」直覺，轉化為一個可進行 exact finite theorem、benchmark experiment、historical backtest、multi-agent ablation、future-agent forecasting 與 normative audit 的研究綱領。

---

# 1. Series I 的問題譜系

Series I 的依賴鏈為：

$$
\boxed{
\begin{aligned}
&\text{Paper 00: Canonical Definition}\\
&\downarrow\\
&\text{Paper 01: Agent-Relative Tractability}\\
&\downarrow\\
&\text{Paper 02: Cost + Evidence / Certification}\\
&\downarrow\\
&\text{Paper 05: Controlled Micro-Model}\\
&\searrow\\
&\text{Paper 03: }\boldsymbol\Sigma/\boldsymbol\Gamma\\
&\downarrow\\
&\text{Paper 04: Historical Frontier}\\
&\downarrow\\
&\text{Paper 06: Collective Frontier}\\
&\downarrow\\
&\text{Paper 07: Future-Agent Envelope}\\
&\downarrow\\
&\text{Paper 08: Capability / Authority / Dignity}\\
&\downarrow\\
&\text{Paper 09: Unified Synthesis}
\end{aligned}
}
$$

Paper 05 被提前，是刻意的方法論決定：先用 exact finite benchmark 檢驗語言能否 operationalize，再回頭正式定義 $\boldsymbol\Sigma$ 與 $\boldsymbol\Gamma$。

---

# 2. Neo.K 終極認知 P/NP 的正式總問題

固定：

- task contract $\mathfrak T$；
- 智能體／系統狀態 $\Psi_t$；
- aggregate resource budget $\mathbf B_t$；
- admissible information / oracle / advice contract；
- reliability threshold；
- verification / certification contract $\kappa$。

若：

$$
\boxed{
\rho_V(x\mid\mathfrak U_t)\le1<\rho_C(x\mid\mathfrak U_t),
}
$$

則稱 $x$ 在該明示 contract 下呈：

$$
\boxed{
NP_{\mathrm{cog}}\text{-like}
}
$$

操作狀態。

UCPNP 的核心問題不是問：

> $x$ 本體上是不是 NP？

而是問：

$$
\boxed{
\exists I_t:
\mathfrak U_t
\xrightarrow{I_t}
\mathfrak U_{t+1}
}
$$

使：

$$
\boxed{
\rho_C(x\mid\mathfrak U_{t+1})\le1
}
$$

且同時滿足：

1. task semantics 未偷改；
2. external information 已記帳；
3. precomputation / training / index build 未消失；
4. success contract 未降低；
5. evidence scope 未被擴寫；
6. 若研究的是 deployable policy，normative admissibility 另行檢查。

這就是：

$$
\boxed{
\text{UCPNP Tractability Transition}.
}
$$

---

# 3. Master State

定義：

$$
\boxed{
\mathfrak U_t
=
(
\mathfrak T,
\Psi_t,
\mathcal N_t,
\mathbf B_t,
\mathcal O_t,
\mathbf C_t,
\eta_t,
\boldsymbol\Sigma_t,
\boldsymbol\Gamma_t,
\mathcal F_t,
\Lambda_t,
\mathfrak N_t
).
}
$$

各分量如下。

## 3.1 Task Contract $\mathfrak T$

固定：

- input / output；
- valid completion；
- success threshold；
- verification；
- certification；
- error allowance；
- task semantics。

## 3.2 Agent Profile $\Psi_t$

延續 Paper 07：

$$
\Psi_t
=
(
\Xi_t,
\tau_t,
\alpha_t,
\mu_t,
\omega_t,
\pi_t,
\kappa_t
),
$$

其中：

$$
\Xi_t
=
(A_t,K_t,\boldsymbol\Sigma_t,\boldsymbol\Gamma_t,H_t,M_t,N_t,E_t).
$$

## 3.3 Collective Network $\mathcal N_t$

若為單體，$\mathcal N_t$ 可退化為單節點。

若為多智能體：

$$
\mathcal N_t
=
(
V,E,W,\mathcal M_{\mathrm{mem}},
\mathcal P_{\mathrm{perm}},
\mathcal G_{\mathrm{agg}},
\mathcal L_{\mathrm{prov}},
\mathcal C_{\mathrm{coord}}
).
$$

## 3.4 Resource Budget $\mathbf B_t$

為多維向量，不壓成單一 FLOPS：

$$
\mathbf B_t
=
(
B_T,B_E,B_M,B_Q,B_C,B_{\mathrm{comm}},B_{\mathrm{risk}},\ldots
).
$$

## 3.5 Legal Operators $\mathcal O_t$

可包含：

$$
\boxed{
\{
\mathsf{Represent},
\mathsf{Find},
\mathsf{Ask},
\mathsf{Generate},
\mathsf{Create},
\mathsf{Bypass},
\mathsf{Execute},
\mathsf{Verify},
\mathsf{Certify}
\}.
}
$$

## 3.6 Cost Ledger $\mathbf C_t$

$$
\boxed{
\mathbf C_t
=
(
C_R,C_D,C_C,C_E,C_V,C_{\mathrm{Cert}},C_O
).
}
$$

## 3.7 Epistemic State $\eta_t$

最小形式：

$$
\boxed{
\eta_t=(T,E,C)
}
$$

分別表示：

- truth；
- admissible evidence；
- certification。

## 3.8 Knowledge Condensation $\boldsymbol\Sigma_t$

在固定 representation class 內，由可重用 theorem、policy、certificate、memory、index 等帶來的淨成本改善 Pareto frontier。

## 3.9 Representation Generation $\boldsymbol\Gamma_t$

在 task semantics 保持下，由非平凡 representation / state / proof-language transformation 帶來的淨成本改善 Pareto frontier。

## 3.10 Tractability Frontiers $\mathcal F_t$

至少分：

$$
\mathcal F_C,
\quad
\mathcal F_V,
\quad
\mathcal F_{\mathrm{Cert}}.
$$

若涉及 collective / historical / future scenario，再加對應索引。

## 3.11 Lineage $\Lambda_t$

$$
\Lambda_t
=
(
\mathfrak U_0,I_0,\mathfrak U_1,\ldots,I_{t-1},\mathfrak U_t
).
$$

它保存 build cost、外部 transport、發現史與證據來源。

## 3.12 Normative Interface $\mathfrak N_t$

包含：

$$
(
\mathcal C,
\mathcal E,
\mathcal Q^D,
\mathcal R,
\mathcal D,
\mathsf{Mandate},
\mathsf{Review},
\mathsf{Revoke},
\mathsf{Handoff}
).
$$

它不改寫數學 truth，但可以限制哪些 action / deployment 被視為合法。

---

# 4. Descriptive、Epistemic、Normative 三層

UCPNP 的統一並不是把所有層混成一層。

## 4.1 Descriptive layer

研究：

$$
\boxed{
\text{Can it be done?}
}
$$

對應：

- completion；
- execution；
- memory；
- query；
- compute；
- representation；
- collective structure。

## 4.2 Epistemic layer

研究：

$$
\boxed{
\text{What is actually supported?}
}
$$

對應：

- evidence；
- verification；
- proof；
- certification；
- claim scope。

## 4.3 Normative layer

研究：

$$
\boxed{
\text{What may be done, by whom, under what authority?}
}
$$

對應：

- qualification；
- mandate；
- rights；
- responsibility；
- review；
- dignity；
- reversibility。

因此：

$$
\boxed{
\text{Can}
\neq
\text{Know}
\neq
\text{May}.
}
$$

這是 Series I 的第一個總分離式。

---

# 5. T5.1 — Three-Layer Non-Collapse

存在三個有限構造使 descriptive、epistemic、normative frontier 彼此不可互推。

### Case A — Capability without certification

solver 得到正確答案，但沒有指定 proof / evidence contract：

$$
C=1,
\qquad
\mathrm{Cert}=0.
$$

### Case B — Certification without new discovery

外部提供合法 proof，agent 可驗證，但沒有自行 discovery：

$$
V=1,
\qquad
D=0.
$$

### Case C — Capability without permission

agent 技術上可執行高風險操作，但制度 contract 禁止未授權執行：

$$
\mathrm{Can}=1,
\qquad
\mathrm{May}=0.
$$

因此不存在普遍等價：

$$
\boxed{
\mathrm{Can}
\Longleftrightarrow
\mathrm{Know}
\Longleftrightarrow
\mathrm{May}.
}
$$

$\square$

注意：Case C 的 normative gate 是制度定義，不是自然科學 theorem。

---

# 6. Transition Operator

定義 intervention vector：

$$
\boxed{
I_t
=
(
I_K,
I_\Sigma,
I_\Gamma,
I_H,
I_M,
I_N,
I_E,
I_\tau,
I_\mu,
I_\kappa
).
}
$$

狀態更新：

$$
\boxed{
\mathfrak U_{t+1}
=
\mathcal G(
\mathfrak U_t,
I_t
).
}
$$

$\mathcal G$ 不是宣稱存在單一普適「智慧物理定律」。

它是一個 bookkeeping transition operator：任何具體研究都必須給出其實作、估計或模型。

---

# 7. UCPNP Transition Indicator

定義：

$$
\operatorname{UCPT}
(
x;\mathfrak U_t,I_t
)
=
1
$$

若且唯若：

1. before：

$$
\rho_V(x\mid\mathfrak U_t)\le1<\rho_C(x\mid\mathfrak U_t);
$$

2. after：

$$
\rho_C(x\mid\mathfrak U_{t+1})\le1;
$$

3. task semantics preserved；
4. lifecycle cost accounted；
5. external information / oracle disclosed；
6. claim status 未超過 evidence。

否則：

$$
\operatorname{UCPT}=0
$$

或標記 unresolved。

這是 UCPNP 對「cognitive-NP-like $\to$ cognitive-P-like」最窄的正典 transition。

---

# 8. Transition Mechanism Taxonomy

UCPNP 不假設所有進步都是算力。

## 8.1 $K$-type

取得新 facts / theorem / information。

## 8.2 $\Sigma$-type

凝結成可重用 structure：

$$
\text{future recomputation}\downarrow.
$$

## 8.3 $\Gamma$-type

改 representation / effective state geometry：

$$
R\equiv_{\mathfrak T}R',
\qquad
R\not\equiv_{\mathrm{op}}R'.
$$

## 8.4 $H$-type

硬體／能源／memory／physical compute 提升。

## 8.5 $M$-type

算法、library、compiler、formal tool、runtime 進步。

## 8.6 $N$-type

多智能體 specialization、communication、shared memory、aggregation 改善。

## 8.7 $E$-type

新 sensor、data、network / oracle access。

## 8.8 $\tau$-type

long-horizon autonomy 提升。

## 8.9 $\mu$-type

可驗證 self-modification reach 提升。

## 8.10 $\kappa$-type

proof / certification language 或 authority contract 改善。

真正的歷史或未來 breakthrough 通常是 mixed intervention。

---

# 9. T9.1 — Mechanism Non-Identifiability from Performance Alone

存在不同 intervention：

$$
I_\Sigma,
\qquad
I_\Gamma,
\qquad
I_H
$$

使同一 scalar performance metric 產生相同提升。

因此只觀察：

$$
\Delta P=p
$$

不能唯一識別：

$$
I_t.
$$

**Proof.** 構造三個 systems：一個查表降低 discovery cost；一個 quotient 降低 state space；一個只提高 compute speed。調整其參數，使指定 benchmark wall-clock 都由 $2$ 降至 $1$。observed scalar performance 相同，但機制不同。$\square$

因此：

$$
\boxed{
\text{performance gain}
\not\Rightarrow
\text{mechanism identification}.
}
$$

---

# 10. No Universal Scalar Intelligence

Paper 02 已證明多維 resource feasibility 無法由固定正線性權重普遍保持；Paper 03 將 $\boldsymbol\Sigma,\boldsymbol\Gamma$ 保留為 Pareto frontier；Paper 06 證明 Agent 數與 collective gain 非單調；Paper 07 證明 domain-wise dominance 可交叉；Paper 08 再分離 capability 與 dignity。

因此 UCPNP 的正典立場為：

$$
\boxed{
I(A)\in\mathbb R
}
$$

只能是：

$$
\boxed{
\text{explicit projection under a declared purpose}.
}
$$

不能被當作整個智能體的普適全序。

---

# 11. T11.1 — No Universal Scalar Order under Crossed Domains

若存在兩個 domains：

$$
A\succ_{D_1}B,
$$

且：

$$
B\succ_{D_2}A,
$$

則任何單一 scalar $s$ 若強制給出：

$$
s(A)>s(B)
$$

或：

$$
s(B)>s(A)
$$

都必然丟失至少一個 domain-relative ordering；若：

$$
s(A)=s(B),
$$

又丟失兩個 strict local differences。

故沒有單一 scalar 能同時等價保存所有 domain-wise strict orders。$\square$

這不禁止為明示目的使用 score。

---

# 12. $\boldsymbol\Sigma$ 與 $\boldsymbol\Gamma$ 的統一位置

Series I 的一個核心收斂是：

$$
\boxed{
\boldsymbol\Sigma
\neq
\boldsymbol\Gamma
\neq
H
\neq
M.
}
$$

### $\boldsymbol\Sigma$

在既有 representation 內：

> 已知結構變得更可重用。

### $\boldsymbol\Gamma$

改變 representation：

> 問題被放到新的可操作座標／商空間／proof language。

### $H$

只是物理資源。

### $M$

是方法與工具。

它們可混合：

$$
I
=
I_\Sigma
+
I_\Gamma
+
I_H
+
I_M
+\cdots
$$

但 attribution 必須透過 ablation、lineage 或 causal design，而不是語義猜測。

---

# 13. Historical Cognitive Tractability

Paper 04 把「哪一年能算」改成：

$$
\boxed{
\mathbf Y^{(s)}(x)
=
(
Y_R^{(s)},
Y_D^{(s)},
Y_C^{(s)},
Y_E^{(s)},
Y_V^{(s)},
Y_{\mathrm{Cert}}^{(s)}
).
}
$$

其中 scenario 至少分：

$$
\mathsf S_0
=
\text{Endogenous History},
$$

$$
\mathsf S_1
=
\text{Method Transport},
$$

$$
\mathsf S_2
=
\text{Artifact Transport},
$$

$$
\mathsf S_3
=
\text{Result / Certificate Transport}.
$$

因此：

$$
\boxed{
Y_{\mathrm{discover}}^{(\mathsf S_0)}
\neq
Y_{\mathrm{execute}}^{(\mathsf S_1)}
}
$$

一般不應混寫。

---

# 14. Import Conservation

若未來 artifact $g$ 被送回過去：

$$
\mathbf C_{\mathrm{local}}
=
\mathbf C_{\mathrm{use}}(g)
$$

不代表：

$$
\mathbf C_{\mathrm{world}}
=
\mathbf C_{\mathrm{use}}(g).
$$

完整 ledger：

$$
\boxed{
\mathbf C_{\mathrm{world}}
=
\mathbf C_{\mathrm{build}}(g)
+
\mathbf C_{\mathrm{transport}}(g)
+
\mathbf C_{\mathrm{use}}(g).
}
$$

UCPNP 因而禁止：

> 把未來算法送回去，然後宣稱那個年代已經「自行解決」問題。

---

# 15. Collective Cognitive Tractability

Paper 06 的統一結果不是：

$$
n\uparrow
\Rightarrow
\mathrm{Intelligence}\uparrow.
$$

而是：

$$
\boxed{
\text{Collective gain}
=
\text{benefits}
-
\text{coordination/correlation costs},
}
$$

其中 benefits 可能來自：

- specialization；
- parallelism；
- evidence diversity；
- shared verified memory；
- independent correction。

costs 可能來自：

- communication；
- synchronization；
- duplicate work；
- correlated error；
- stale shared memory；
- consensus lock-in。

正典比較必須分：

$$
\boxed{
\text{resource-normalized gain}
}
$$

與：

$$
\boxed{
\text{resource-expansion gain}.
}
$$

---

# 16. Future Cognitive Tractability Envelope

Paper 07 將「AGI」「ASI」「Posthuman」降為 scenario labels。

真正 forecast：

$$
\boxed{
\mathfrak F_{t+\Delta}^{(s)}
=
\{
\mathcal F(\Psi):
\Psi\in\mathcal U_{t+\Delta}^{(s)}
\}.
}
$$

而不是：

$$
\boxed{
\text{ASI arrives at exact year }Y.
}
$$

核心變量包括：

$$
K,\Sigma,\Gamma,H,M,N,E,\tau,\mu,\omega,\pi,\kappa.
$$

因此：

$$
\boxed{
\text{future capability forecasting}
\neq
\text{future being ranking}.
}
$$

---

# 17. Current external calibration

UCPNP 與既有研究的關係可簡述如下。

## 17.1 Bounded optimality

bounded optimality 已指出智能體的最佳程序必須相對其 architecture 與 task environment 評估。

UCPNP 在此基礎上再顯式追蹤：

$$
\text{history},
\text{knowledge},
\text{representation},
\text{evidence},
\text{certification},
\text{collective topology}.
$$

## 17.2 Representation control

人類 planning 研究已顯示 task representation 並非固定背景；人類可以在有限 cognitive resources 下平衡 representation complexity 與 planning utility。

這與 $\boldsymbol\Gamma$ 相鄰，但 UCPNP 的 $\boldsymbol\Gamma$ 是更廣的 task-semantic-preserving representation-transformative capacity，不宣稱與人類心理機制同構。

## 17.3 Future agent measurement

當前 agent evaluation 已開始量 long-task time horizon；AGI taxonomy 亦將 performance、generality、autonomy 分離。

UCPNP 接受此多軸方向，但不從任何單一 benchmark 直接推出：

$$
\text{AGI},
\text{ASI},
\text{omniscience},
\text{ultimate being}.
$$

---

# 18. Normative Interface：能力不自動產生尊嚴階級

Paper 08 的核心型別分離：

$$
\boxed{
\mathcal C_A
\neq
\mathcal E_A
\neq
\mathcal Q_A^D
\neq
\mathcal R_A
\neq
\mathcal D_A.
}
$$

因此：

$$
A\succ_D B
$$

只表示：

$$
\text{domain-relative capability difference}.
$$

不推出：

$$
\mathrm{Worth}(A)>\mathrm{Worth}(B).
$$

對自然人類，Series I 保留既有人權秩序中的 human dignity floor。

對未來非自然候選主體，Series I 提出的是：

$$
\boxed{
\text{substrate-open review}
}
$$

而不是預先宣布完整人格。

---

# 19. Raw Feasibility、Certifiable Feasibility、Normative Admissibility

為了使三層接口可操作，定義：

## 19.1 Raw feasible set

$$
\mathcal F_{\mathrm{raw}}
$$

技術上可完成。

## 19.2 Certifiable feasible set

$$
\mathcal F_{\mathrm{cert}}
$$

可以依指定 evidence / proof contract 合法認證。

## 19.3 Normatively admissible set

$$
\mathcal F_{\mathrm{adm}}
$$

依指定法律／倫理／治理 contract 可部署或可執行。

一般不保證：

$$
\mathcal F_{\mathrm{raw}}
=
\mathcal F_{\mathrm{cert}}
=
\mathcal F_{\mathrm{adm}}.
$$

例如：

- 技術上可做但不可合法部署；
- 能證明某 action works，但仍缺 mandate；
- 有 permission，但硬體做不到；
- 能做也合法，但沒有足夠 evidence 宣稱 universally safe。

---

# 20. T20.1 — Frontier Separation

存在 task/action $a,b,c$ 使：

$$
a\in
\mathcal F_{\mathrm{raw}}
\setminus
\mathcal F_{\mathrm{cert}},
$$

$$
b\in
\mathcal F_{\mathrm{cert}}
\setminus
\mathcal F_{\mathrm{adm}},
$$

$$
c\in
\mathcal F_{\mathrm{adm}}
\setminus
\mathcal F_{\mathrm{raw}}.
$$

**Construction.**

- $a$：solver 產生答案但沒有 required proof；
- $b$：已有完整 proof 證明某高風險 technique 有效，但 policy 禁止未授權執行；
- $c$：制度允許某操作，但當前 agent / hardware resource 不足。

故三 frontier 不相等。$\square$

---

# 21. Evidence Passport

Paper 00 的 D/T/C/E/N、Paper 01/02 的 Proven/Observed/Unresolved、Paper 04 的 H0–H4、Paper 07 的 F0–F7 在本文統一為：

$$
\boxed{
\mathfrak P(q)
=
(
\tau_q,
S_q,
L_q,
\kappa_q,
R_q,
D_q
).
}
$$

其中：

- $\tau_q$：Claim Type；
- $S_q$：Claim Scope；
- $L_q$：Evidence Level；
- $\kappa_q$：Contract / verifier；
- $R_q$：Reproduction Status；
- $D_q$：Dependencies。

---

# 22. D22.1 Claim Type

$$
\tau_q
\in
\{
D,T,C,E,N
\}.
$$

- D — Definition；
- T — Theorem / proven structural proposition；
- C — Conjecture；
- E — Empirical / historical observation；
- N — Normative Axiom。

---

# 23. D23.1 Evidence Scope

$$
S_q
=
\text{the exact domain / quantifier range supported by the evidence}.
$$

核心原則：

$$
\boxed{
\operatorname{ClaimScope}(q)
\subseteq
\operatorname{EvidenceScope}(q).
}
$$

---

# 24. D24.1 Reproduction Status

可標：

- Exact verified；
- Independently reproduced；
- Cold rebuilt；
- Controlled empirical；
- Historical documentary；
- Model-estimated；
- Unresolved；
- Superseded；
- Refuted；
- Normative proposal。

因此一段數學式的排版外觀不再決定其 epistemic status。

---

# 25. T25.1 — Passport Non-Interchangeability

兩個 claim 即使文字／公式相同，只要其：

$$
L_q,
\quad
R_q,
\quad
S_q
$$

不同，就不能在 UCPNP audit 中視為同一 epistemic object。

**Example.**

$$
\Gamma>0
$$

若一個是 finite exact quotient 的 measured proxy，另一個是 future ASI conjecture，兩者 equation surface 可以相似，但 evidence passport 不同，因此不得互換。$\square$

---

# 26. SDPE-BEB：Series I 的受控微觀閉環

SDPE-BEB 的作用不是「證明一般智能就是 Bellman MDP」。

它提供一個 exact finite mechanism-existence laboratory。

已被 UCPNP 使用的結構包括：

1. posterior state matters；
2. same elapsed query count 不等於 same decision state；
3. adaptive allocation 在固定 query budget 下可嚴格改善 value；
4. exact behavioral quotient 可壓縮 state space；
5. reusable dual certificates 可安全剪枝；
6. 33-breakpoint basis 形成 knowledge condensation candidate；
7. local scalar priority 可選錯 global action；
8. proof-carrying architecture 分離 untrusted discovery 與 exact certification；
9. heavy exact certification 可集中於極小 residual boundary set。

因此 SDPE-BEB 支持：

$$
\boxed{
\text{controlled mechanism existence}
}
$$

但不支持：

$$
\boxed{
\text{universal cognitive law}.
}
$$

---

# 27. Series-I Meta-Theorem：No Single Source of Tractability

## T27.1

在 UCPNP 的明示模型類中，不存在單一機制：

$$
Z\in\{
H,
M,
K,
\Sigma,
\Gamma,
N,
E,
\tau,
\mu
\}
$$

可由 Series I 的 definitions/theorems 推出：

$$
Z\uparrow
\Rightarrow
\mathcal F_C\uparrow
$$

對所有 tasks、budgets、agents、histories 都成立。

**Proof sketch by existing counterexamples.**

- 更多 Agent 可因同步 overhead 降低 tractability；
- self-modification 可改壞系統；
- more compute 不補 missing information；
- representation change 若不 semantics-preserving 不算 gain；
- shared memory 可增加 correlated error；
- knowledge artifact build cost 可能在短 reuse horizon 下得不償失。

故不存在已由 Series I 支持的 universal monotone master variable。$\square$

---

# 28. Research Method：五層驗證管線

## 28.1 Layer A — Exact micro-model

用途：

- existence theorem；
- counterexample；
- finite lower bound；
- proof-carrying certificate。

## 28.2 Layer B — Controlled agent experiment

用途：

- AI / human / multi-agent empirical estimates；
- factorial ablation；
- mechanism attribution。

## 28.3 Layer C — Historical backtest

用途：

- 檢查 HCTF 是否能重建已知 technology / algorithm transitions。

## 28.4 Layer D — Future forecasting

用途：

- near-term calibrated scenario；
- long-range uncertainty envelope。

## 28.5 Layer E — Normative / institutional simulation

用途：

- qualification；
- authority；
- review；
- rights；
- reversibility；
- failure / capture modes。

任何 Layer A 結果不得直接升成 Layer D/E 結論。

---

# 29. Series II：從理論系列轉入實驗系列

Paper 09 完成後，不建議立刻再擴寫十幾個定義論文。

下一階段應優先完成五個實驗工程。

## Experiment I — Historical Cognitive Backtest Corpus

選取已知歷史突破：

- shortest-path / graph algorithms；
- SAT / theorem proving；
- cryptanalysis；
- numerical linear algebra；
- symbolic algebra；
- scientific computing；
- database / information retrieval。

對每個 case 重建：

$$
Y_R,Y_D,Y_E,Y_V,Y_{\mathrm{Cert}}.
$$

## Experiment II — $\Sigma/\Gamma$ Factorial Benchmark

同一 task family 跑：

$$
00,\quad10,\quad01,\quad11
$$

即：

- baseline；
- knowledge only；
- representation only；
- both。

## Experiment III — Collective Cognition Matrix

控制：

- Agent count；
- diversity；
- memory；
- communication；
- aggregation；
- equal aggregate budget。

測：

$$
\mathcal G_{\mathrm{coll}},
\quad
\mathcal L_{\mathrm{coll}}.
$$

## Experiment IV — Long-Horizon / Self-Modification Audit

測：

- $\tau$；
- persistence；
- feedback integration；
- self-modification revalidation；
- cost-normalized improvement。

## Experiment V — UCPNP Open Benchmark + Evidence Passport Registry

建立 machine-readable：

- task contract；
- agent state；
- resources；
- cost ledger；
- evidence；
- claim passport；
- provenance；
- reproduction status。

這應成為 Series II 的工程中心。

---

# 30. Minimal machine-readable UCPNP record

一筆研究至少包含：

```text
task_id
task_contract_version
agent_or_network_id
agent_profile
history_or_scenario
resource_budget
legal_operators
cost_ledger
information_sources
precomputation
oracle_or_advice
Sigma_artifacts
Gamma_transformations
completion_status
verification_status
certification_status
raw_feasible
normatively_admissible
claim_type
claim_scope
evidence_level
reproduction_status
dependencies
uncertainty
```

---

# 31. Falsification principles

UCPNP 不是靠把所有結果都解讀成自己正確來生存。

## F31.1 Historical failure

若 HCTF 對已知歷史 case 長期無法產生比「硬體越新越強」更好的解釋或回測，歷史模組應降級或重構。

## F31.2 $\Sigma/\Gamma$ failure

若 representation / knowledge ablation 無法穩定區分，應縮小 $\Sigma/\Gamma$ 的 operational scope。

## F31.3 Collective failure

若 equal-budget collective protocols 長期不產生 collective-only region：

$$
\mathcal G_{\mathrm{coll}},
$$

則「collective tractability」應被視為 narrow phenomenon，不得預設廣泛存在。

## F31.4 Future forecasting failure

若 future-agent model 不能校準短期或歷史 frontier shifts，不得升級 ASI extrapolation evidence。

## F31.5 Normative implementation failure

若 procedural precaution / functional authority contract 產生嚴重 capture、paternalism 或不可操作成本，制度提案須修改；不能因其 normative origin 而免於工程反例。

---

# 32. UCPNP 與 classical complexity theory 的永久邊界

即使某一天 UCPNP 得到大量 empirical support，仍有：

$$
\boxed{
P_{\mathrm{cog}}
\neq
P,
\qquad
NP_{\mathrm{cog}}
\neq
NP.
}
$$

Cognitive-P-like / Cognitive-NP-like 是：

$$
\boxed{
\text{agent-relative operational regimes}.
}
$$

它們可以因：

- knowledge；
- representation；
- tool；
- hardware；
- historical state；
- collaboration；
- external information

而改變。

標準 complexity classes 則是另一套形式對象。

兩者可以對話，但不得偷換。

---

# 33. UCPNP 的真正研究對象：Frontier Geometry

從 Series I 回頭看，真正反覆出現的不是 $P$ 或 $NP$ 兩個字，而是：

$$
\boxed{
\text{frontier}.
}
$$

包括：

- resource frontier；
- completion frontier；
- verification frontier；
- certification frontier；
- $\Sigma$ frontier；
- $\Gamma$ frontier；
- historical frontier；
- collective frontier；
- future-agent envelope；
- qualification / authority boundary。

因此 UCPNP 更成熟的幾何讀法是：

> 智能研究不是替存在打一個總分，而是研究多個可解、可證、可行、可允許集合的邊界如何移動、交叉與被重構。

---

# 34. The Neo.K Ultimate Cognitive P/NP Master Question

本文最終給出正典母問題：

$$
\boxed{
\begin{minipage}{0.92\linewidth}
給定固定任務語義 $\mathfrak T$、有限智能體或智能網路狀態 $\Psi_t/\mathcal N_t$、有限資源 $\mathbf B_t$、明示資訊與證據契約，以及可審計歷史 lineage，哪些合法介入 $I_t$ 能在不偷改任務、不隱藏成本、不擴張證據量詞的條件下，使一個目前 completion-intractable but verification-feasible 的任務轉入 completion-feasible regime？這種轉換由何種 $K,\Sigma,\Gamma,H,M,N,E,\tau,\mu,\kappa$ 機制造成？它是否可重用、可歷史回測、可跨智能體重現？其 completion、verification、certification、部署權限與尊嚴結論又分別停在哪一個 frontier？
\end{minipage}
}
$$

若 Markdown renderer 不支援 `minipage`，其自然語言版本仍為正文正典；該公式不作 machine parsing dependency。

---

# 35. Series I 的最終收斂句

$$
\boxed{
\begin{aligned}
\text{Problem difficulty}
&\neq
\text{single static label},
\\
\text{Intelligence}
&\neq
\text{single scalar},
\\
\text{Search}
&\neq
\text{Execution}
\neq
\text{Verification},
\\
\text{Truth}
&\neq
\text{Evidence}
\neq
\text{Certification},
\\
\boldsymbol\Sigma
&\neq
\boldsymbol\Gamma
\neq
H
\neq
M,
\\
\text{Historical execution}
&\neq
\text{Historical discovery},
\\
\text{Collective size}
&\neq
\text{Collective gain},
\\
\text{Future capability}
&\neq
\text{Ultimate being},
\\
\mathcal C
&\neq
\mathcal E
\neq
\mathcal Q^D
\neq
\mathcal R
\neq
\mathcal D.
\end{aligned}
}
$$

這些「不等號」不是悲觀主義。

它們的目的恰恰相反：

> 只有先把不同問題拆開，智能體真正跨越 frontier 時，我們才知道它究竟跨越了什麼。

---

# 36. 結論

Neo.K 終極認知 P/NP 問題並不是把傳統 P/NP 擴大到「一切都算 P/NP」。

它是一個刻意受限的研究綱領：

$$
\boxed{
\text{fixed semantics}
+
\text{agent-relative resources}
+
\text{explicit cognition costs}
+
\text{knowledge / representation dynamics}
+
\text{history}
+
\text{collective structure}
+
\text{evidence / certification}
+
\text{future-agent uncertainty}
+
\text{normative type separation}.
}
$$

它允許研究一個非常實際、也非常長期的問題：

> 智能體為什麼會突然「會了」？

答案可能是：

- 知道了新事實；
- 凝結了知識；
- 換了 representation；
- 發明了算法；
- 換了硬體；
- 學會使用工具；
- 組成了更有效的群體；
- 得到了新的外部資訊；
- 可以維持更久的 autonomous search；
- 建立了新的 proof / certificate language。

也可能只是：

- 偷看答案；
- 把成本搬到預訓練；
- 使用更多資源；
- 改了 success definition；
- 讓錯誤彼此複製；
- benchmark 過擬合；
- 把「所有模型同意」誤寫成證明。

UCPNP 的任務，就是把這些可能性拆開、記帳、驗證，再判斷 frontier 是否真的移動。

當研究推到後人類與 ASI，這個原則仍不變。

一個未來智能體可以比今天的人類：

$$
10^3,
\quad
10^6,
\quad
\text{甚至更巨大}
$$

地擴張某些 task frontiers。

這仍然只首先告訴我們：

$$
\boxed{
\text{它在那些明示 domain 中具有巨大的能力位差。}
}
$$

它不自動告訴我們：

$$
\boxed{
\text{它是全知、全能、絕對善、終極存在，
或其他存在應失去基本尊嚴。}
}
$$

因此 Series I 最後的總原則是：

$$
\boxed{
\text{能力可以無界擴張；
主張必須受證據限制；
權力必須受可糾正性限制；
尊嚴不能只按能力排序。}
}
$$

而真正「終極」的，是我們願意把問題一路推到未知未來，仍拒絕把未知偷寫成已知。

---

# 參考文獻

## External primary / canonical research

1. Russell, S. J., & Subramanian, D. (1995). *Provably Bounded-Optimal Agents*. Journal of Artificial Intelligence Research, 2, 575–609.
2. Griffiths, T. L., Lieder, F., & Goodman, N. D. (2015). *Rational Use of Cognitive Resources: Levels of Analysis Between the Computational and the Algorithmic*. Topics in Cognitive Science, 7(2), 217–229.
3. Lieder, F., & Griffiths, T. L. (2020). *Resource-rational analysis: Understanding human cognition as the optimal use of limited computational resources*. Behavioral and Brain Sciences, 43, e1.
4. Correa, C. G., Ho, M. K., Callaway, F., & Griffiths, T. L. (2020). *Resource-rational Task Decomposition to Minimize Planning Costs*. arXiv:2007.13862.
5. Ho, M. K., Abel, D., Correa, C. G., Littman, M. L., Cohen, J. D., & Griffiths, T. L. (2022). *People construct simplified mental representations to plan*. Nature 606, 129–136.
6. Necula, G. C. (1997). *Proof-Carrying Code*. POPL 1997.
7. Morris, M. R. et al. (2024). *Levels of AGI for Operationalizing Progress on the Path to AGI*. ICML 2024.
8. METR. (2026). *Task-Completion Time Horizons of Frontier AI Models — Time Horizon 1.1*.
9. United Nations. *Convention on the Rights of Persons with Disabilities*.
10. UNESCO. *Recommendation on the Ethics of Artificial Intelligence*.
11. Council of Europe. *Framework Convention on Artificial Intelligence and Human Rights, Democracy and the Rule of Law*.
12. Long, R. et al. (2024). *Taking AI Welfare Seriously*. arXiv:2411.00986.

## Internal canonical lineage

13. Neo.K. *動態速率理論與 P vs. NP 問題的結構連續模型 2.0*.
14. Neo.K. *P vs. NP 問題的動態可解性理論 2.5*.
15. Neo.K. *動態速率理論 2.9：認知與計算的解耦*.
16. Neo.K with Aletheia. UCPNP Paper 00 — *Canonical Definition, Scope, and Research Program*.
17. Neo.K with Aletheia. UCPNP Paper 01 — *Agent-Relative Tractability*.
18. Neo.K with Aletheia. UCPNP Paper 02 — *Cognitive Cost Decomposition and the Evidence–Certification Matrix*.
19. Neo.K with Aletheia. UCPNP Paper 03 — *Knowledge Condensation and Representation Generation*.
20. Neo.K with Aletheia. UCPNP Paper 04 — *Historical Cognitive Tractability Frontier*.
21. Neo.K with Aletheia. UCPNP Paper 05 — *SDPE-BEB as a Controlled Micro-Model of UCPNP*.
22. Neo.K with Aletheia. UCPNP Paper 06 — *Collective Cognitive P/NP*.
23. Neo.K with Aletheia. UCPNP Paper 07 — *Future Cognitive Tractability Envelopes for Posthuman and ASI Scenarios*.
24. Neo.K with Aletheia. UCPNP Paper 08 — *Capability, Epistemic Authority, and Dignity*.
25. SDPE-BEB v1.0.0 — *Proof-Carrying Bellman Certification & Exact Q21 Closure*.

---

# Appendix A. Master Symbol Table

| Symbol | Meaning |
|---|---|
| $\mathrm{UCPNP}_{\mathrm{Neo.K}}$ | Neo.K Ultimate Cognitive P/NP Problem |
| $\mathfrak T$ | fixed task semantics contract |
| $\mathfrak U_t$ | UCPNP Master State |
| $\Psi_t$ | future/general agent profile |
| $\mathcal N_t$ | collective cognitive network |
| $\mathbf B_t$ | resource budget |
| $\mathcal O_t$ | legal operator set |
| $\mathbf C_t$ | cost ledger |
| $\eta_t$ | Truth–Evidence–Certification state |
| $\boldsymbol\Sigma_t$ | knowledge-condensation frontier |
| $\boldsymbol\Gamma_t$ | representation-generation frontier |
| $\mathcal F_C$ | completion frontier |
| $\mathcal F_V$ | verification frontier |
| $\mathcal F_{\mathrm{Cert}}$ | certification frontier |
| $\Lambda_t$ | historical/provenance lineage |
| $\mathfrak N_t$ | normative interface |
| $\rho_C$ | normalized completion bottleneck |
| $\rho_V$ | normalized verification bottleneck |
| $\operatorname{UCPT}$ | UCPNP tractability-transition indicator |
| $\mathfrak P(q)$ | Evidence Passport |

---

# Appendix B. Minimal Unified Audit

任何 UCPNP claim 至少回答：

1. task semantics 是否固定？
2. 是 instance 還是 family claim？
3. agent / network 是誰？
4. resource budget 是什麼？
5. external information / oracle / advice 是什麼？
6. training / precomputation / build cost 在哪裡？
7. $C_R,C_D,C_C,C_E,C_V,C_{\mathrm{Cert}},C_O$ 各是多少或如何估？
8. Truth、Evidence、Certification 是否分開？
9. improvement 是 $K,\Sigma,\Gamma,H,M,N,E,\tau,\mu,\kappa$ 哪一類？
10. 是否有 mixed-intervention ablation？
11. 歷史比較是哪種 transport scenario？
12. collective comparison 是否 equal aggregate budget？
13. future forecast 是哪個 evidence level？
14. capability claim 是否超過 domain scope？
15. claim 是否附 Evidence Passport？
16. normative conclusion 是否被錯當 descriptive theorem？
17. capability 是否被偷換成 dignity？
18. 是否存在 reproduction / cold rebuild / independent verification？
19. 哪些結果目前 unresolved？
20. 什麼證據會使目前結論降級或被推翻？
