# Neo.K Ultimate Cognitive P/NP — Series I Index v0.1

| Paper | Short title | Primary role |
|---|---|---|
| 00 | Canonical Definition | name, scope, non-identity, research constitution |
| 01 | Agent-Relative Tractability | formal cognitive-P-like / cognitive-NP-like regimes |
| 02 | Cognitive Cost + Evidence Matrix | six-phase costs; Truth/Evidence/Certification |
| 03 | Knowledge Condensation / Representation Generation | Sigma/Gamma separation and lifecycle measurement |
| 04 | Historical Cognitive Tractability Frontier | discovery/execution/history counterfactuals |
| 05 | SDPE-BEB Controlled Micro-Model | exact operational micro-model |
| 06 | Collective Cognitive P/NP | multi-agent gain/loss, correlation, memory |
| 07 | Future Posthuman/ASI Tractability | future-agent envelopes and anti-overclaim |
| 08 | Capability, Authority, Dignity | normative type separation |
| 09 | Unified Synthesis | master state, transition system, evidence passport, Series-II handoff |

Series-I closure rule:
- Definitions are frozen as v0.1 canonical candidates.
- Future changes should be versioned and motivated by experiment/audit.
- New work should preferentially enter Series II as experiments, datasets, replications, and falsification attempts.
