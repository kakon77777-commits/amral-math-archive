# UCPNP Paper 06 v0.1 Release Pack

Main paper:
- `06_UCPNP_Collective_Cognitive_PNP_v0.1.md`

Supporting artifacts:
- `06_UCPNP_Claim_Matrix_v0.1.md`
- `06_UCPNP_Collective_Benchmark_Protocol_v0.1.json`
- `verify_p06_theorems.py`
- `06_UCPNP_Source_Integrity_v0.1.json`
- `CHECKSUMS.sha256`

Scope:
Formal methodology for collective cognitive tractability. The paper separates normalized collective gain from resource expansion, models coordination overhead and error correlation, and defines a future factorial multi-agent benchmark.

Important:
The paper does not claim that multi-agent systems necessarily outperform single agents or constitute a single higher-order subject.
