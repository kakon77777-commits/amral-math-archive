# Collective Cognitive P/NP：多智能體協作、共享記憶、錯誤相關與集體可解性前沿

**English title:** *Collective Cognitive P/NP: Multi-Agent Coordination, Shared Memory, Error Correlation, and Collective Tractability Frontiers*  
**Series:** Neo.K Ultimate Cognitive P/NP Problem  
**Paper:** 06  
**Version:** v0.1  
**Author:** Neo.K  
**Collaborative formalization:** Aletheia  
**Date:** 2026-08-15  
**Status:** Formal-methodology paper with finite constructive theorems; no universal empirical law of human/AI collective intelligence is claimed.

---

# Canonical non-identity and scope statement

本文研究：

$$
\boxed{
\mathrm{UCPNP}_{\mathrm{Neo.K}}
}
$$

中的**集體智能體相對可解性**，不研究或聲稱解決標準計算複雜度問題：

$$
P\stackrel{?}{=}NP.
$$

本文亦不主張：

1. 多 Agent 必然比單 Agent 強；
2. Agent 數量與智能呈線性或超線性關係；
3. 多數決等於真理；
4. 共識等於證據；
5. 證據聚合等於 certification；
6. shared memory 必然降低總成本；
7. 多智能體系統自動形成單一意識、人格、主體或更高本體；
8. 本文有限構造定理可直接外推到人類、AGI、ASI 或後人類。

因此本文首先固定：

$$
\boxed{
\text{collective capability}
\not\Rightarrow
\text{collective subjectivity}
}
$$

以及：

$$
\boxed{
\text{more agents}
\not\Rightarrow
\text{more tractability}.
}
$$

---

# 摘要

早期 Neo.K 的「集體智能相變」研究提出了第六維度：Collective Solvability，並試圖描述人類、AI 與介面形成有效智能體後的非線性增益。該方向保留一個重要問題：**問題的可解性是否取決於智能主體的組織結構，而不只取決於單一個體？** 但早期版本中若干 $n^2$ network value、協作必然優越、奇點不可回歸等強主張缺乏足夠一般性與獨立實證，本文不將其繼承為 theorem。

UCPNP Paper 06 重建該問題。本文將多智能體系統定義為帶有個體狀態、通訊拓撲、共享記憶、權限、證據來源與聚合規則的認知網路。對固定 task contract 與 aggregate resource budget，分別定義 resource-normalized collective frontier 與 resource-expansion frontier，以避免把「使用更多 Agent」與「組織結構本身更有效」混為一談。

本文建立數個有限構造結果。第一，Agent-count Non-Monotonicity：加入一個不帶來新資訊或新合法操作、卻引入強制同步成本的 Agent，可以使原本可行任務失去可行性。第二，Perfect-Correlation Voting Null Gain：若所有 Agent 的答案由同一錯誤隨機變量決定，無論 Agent 數量多少，多數決準確率都不會高於單體。第三，Independent Three-Agent Majority Gain：若三個 Agent 在 binary task 上獨立且各自準確率 $p>1/2$，三人 majority accuracy 嚴格高於 $p$。第四，Complementary Specialization Gain：兩個 Agent 各自在不同子任務具有專長時，只要 communication/merge overhead 小於單體跨專長 penalty，集體策略可嚴格優於任一單體。第五，Shared-Memory Break-Even：共享知識只有在 reuse savings 超過 build/read/synchronization cost 時才有正生命週期回報。第六，Consensus–Certification Separation：任意數量 Agent 對同一 unsupported claim 達成一致，不會因此自動形成可接受 certificate。

本文據此將 collective intelligence 從「更多模型／更大聲量」改寫為一個可審計問題：

$$
\boxed{
\text{在相同或明示增加的資源下，
網路結構是否真正改變可解性前沿？}
}
$$

---

# 1. 內部理論譜系與修正

## 1.1 早期集體智能命題

早期研究提出：

$$
A_{\mathrm{effective}}
=
\mathrm{Human}
\oplus
\mathrm{AI}
\oplus
\mathrm{Interface},
$$

並強調 intelligence 可能是 Entity、Environment、Interaction 的關係函數。

本文保留「智能具有關係性與組織依賴」的研究方向，但不繼承以下未充分驗證的普遍主張：

- network value 必然按 $n^2$ 增長；
- collective mode 必然取代 individual mode；
- 協作成本只要低於固定比例便必然形成相變；
- 集體可解性將使幾乎所有實際 NP 問題趨於可解；
- 集體智能必然是單一更高主體。

這些舊命題保留為 Historical Artifact / Superseded Hypothesis。

## 1.2 與 UCPNP 00–05 的關係

Paper 00 已定義多智能體網路為 UCPNP 的必要擴展；
Paper 01 要求 agent-relative tractability 固定 task semantics 與 budget；
Paper 02 要求成本、證據與 certification 分帳；
Paper 03 要求 knowledge condensation 與 representation change 顯式記 build/use lifecycle；
Paper 04 要求歷史比較區分 capability source；
Paper 05 顯示同一 total query budget 下，posterior-conditioned allocation 可嚴格改善 outcome。

因此 Paper 06 的問題不是：

> 多 Agent 是否更聰明？

而是：

> 在什麼 contract、budget、topology、memory、diversity 與 evidence conditions 下，多智能體網路改變 cognitive tractability frontier？

---

# 2. Collective Cognitive Network

定義 Agent 集合：

$$
V=\{a_1,\ldots,a_n\}.
$$

每個 Agent 有狀態：

$$
\Xi_i
=
(A_i,K_i,\boldsymbol\Sigma_i,\boldsymbol\Gamma_i,H_i,M_i,E_i).
$$

定義 collective cognitive network：

$$
\boxed{
\mathcal N
=
(
V,
E,
W,
\mathcal M_{\mathrm{mem}},
\mathcal P_{\mathrm{perm}},
\mathcal G_{\mathrm{agg}},
\mathcal L_{\mathrm{prov}},
\mathcal C_{\mathrm{coord}}
).
}
$$

其中：

- $E$：允許通訊的邊；
- $W$：通訊頻寬、延遲、信任或權重；
- $\mathcal M_{\mathrm{mem}}$：private/shared/federated/hierarchical memory topology；
- $\mathcal P_{\mathrm{perm}}$：query、write、read、certify、override 等權限；
- $\mathcal G_{\mathrm{agg}}$：vote、consensus、judge、proof-check、market、scheduler 等聚合規則；
- $\mathcal L_{\mathrm{prov}}$：來源與 evidence provenance ledger；
- $\mathcal C_{\mathrm{coord}}$：協調、同步、仲裁與衝突解決機制。

---

# 3. Collective cost ledger

延續 Paper 02，每個 Agent 的 primitive cost 為多維向量：

$$
\mathbf C_i
=
(
C_{R,i},
C_{D,i},
C_{C,i},
C_{E,i},
C_{V,i},
C_{\mathrm{Cert},i},
C_{O,i}
).
$$

collective-specific overhead：

$$
\mathbf O_{\mathcal N}
=
\mathbf C_{\mathrm{comm}}
+
\mathbf C_{\mathrm{coord}}
+
\mathbf C_{\mathrm{sync}}
+
\mathbf C_{\mathrm{merge}}
+
\mathbf C_{\mathrm{conflict}}
+
\mathbf C_{\mathrm{agg}}.
$$

因此實際 collective lifecycle cost：

$$
\boxed{
\mathbf C_{\mathcal N}
=
\sum_{i=1}^{n}
\mathbf C_i^{\mathrm{actually\ executed}}
+
\mathbf O_{\mathcal N}.
}
$$

若某些工作因共享記憶、分工或避免重複而沒有實際執行，則不應先加入再人工扣除；primitive-event ledger 只記真正發生的 cost events。

---

# 4. 兩種 collective gain：禁止資源作弊

令 aggregate budget：

$$
\mathbf B_{\mathrm{tot}}.
$$

## 4.1 Resource-normalized comparison

單體 baseline 可以使用與 collective 相同的非社會工具、總 query、總 compute、總 memory 與總外部資訊 budget，但不得調用其他自主 Agent。

定義：

$$
\mathcal F_{\mathrm{single}}(\mathbf B_{\mathrm{tot}})
$$

為單體可完成任務集合；

$$
\mathcal F_{\mathrm{coll}}^{\mathrm{norm}}
(\mathbf B_{\mathrm{tot}},\mathcal N)
$$

為 collective 在同一 aggregate budget 下可完成任務集合。

resource-normalized collective-only region：

$$
\boxed{
\mathcal G_{\mathrm{norm}}
=
\mathcal F_{\mathrm{coll}}^{\mathrm{norm}}
\setminus
\mathcal F_{\mathrm{single}}.
}
$$

若非空，表示 organization/topology 產生結構性增益，而非單純增加總資源。

## 4.2 Resource-expansion comparison

允許：

$$
\mathbf B_{\mathrm{coll}}
>
\mathbf B_{\mathrm{single}}.
$$

此時增益可來自：

- 更多 compute；
- 更多 wall-clock parallelism；
- 更多 query；
- 更多 memory；
- 更多專長 Agent。

這仍是真實 system gain，但必須標：

$$
\boxed{
\text{resource-expansion gain}
}
$$

而不能冒充 normalized collective intelligence。

---

# 5. T5.1 — Agent-Count Non-Monotonicity

## Theorem

在固定 aggregate budget 下，Agent 數增加不保證 collective feasibility 單調增加。

## Proof

設單體 $a_1$ 完成任務需要成本：

$$
\mathbf c\preceq\mathbf B.
$$

加入 Agent $a_2$，但 $a_2$：

1. 不提供新資訊；
2. 不提供新合法操作；
3. 不減少 $a_1$ 任何 primitive work；
4. protocol 強制產生非零同步成本 $\boldsymbol\epsilon>\mathbf0$。

則：

$$
\mathbf C_{\{a_1,a_2\}}
=
\mathbf c+\boldsymbol\epsilon.
$$

選取某一資源維度 $j$ 使：

$$
c_j=B_j,
\qquad
\epsilon_j>0.
$$

則：

$$
C_{\{a_1,a_2\},j}
>
B_j.
$$

故原本可行任務在加入 Agent 後變不可行。$\square$

因此：

$$
\boxed{
n\uparrow
\not\Rightarrow
\text{tractability}\uparrow.
}
$$

---

# 6. Error correlation and collective correction

## 6.1 D6.1 Agent correctness variable

對 binary task，令：

$$
X_i=
\begin{cases}
1,&a_i\text{ correct},\\
0,&a_i\text{ incorrect}.
\end{cases}
$$

單體準確率：

$$
p_i=\Pr(X_i=1).
$$

集體結果不只取決於 $p_i$，還取決於：

$$
\operatorname{Corr}(X_i,X_j),
$$

以及錯誤是否共享同一來源、training bias、prompt、memory 或 evidence chain。

---

# 7. T7.1 — Perfect-Correlation Voting Null Gain

假設 $n$ 個 Agent 的 correctness 完全由同一 Bernoulli variable $Z$ 決定：

$$
X_1=\cdots=X_n=Z,
$$

且：

$$
\Pr(Z=1)=p.
$$

則任何 majority vote 的 correctness 仍為：

$$
\boxed{
p.
}
$$

**證明。** 所有 Agent 每次輸出完全相同，因此 majority output 與任一單體 output 相同。$\square$

因此：

$$
\boxed{
\text{model count}
\neq
\text{independent evidence count}.
}
$$

---

# 8. T8.1 — Independent Three-Agent Majority Gain

假設三個 Agent 在 binary task 上 correctness i.i.d.：

$$
X_i\sim\mathrm{Bernoulli}(p),
\qquad
p>\frac12.
$$

三人 majority 正確率：

$$
P_3
=
p^3+3p^2(1-p)
=
3p^2-2p^3.
$$

因此：

$$
P_3-p
=
p(1-p)(2p-1)>0.
$$

故：

$$
\boxed{
P_3>p
\quad\text{for}\quad
\frac12<p<1.
}
$$

$\square$

此 theorem 不是「多數決普遍有效」；它明示需要 independence 與 $p>1/2$。

T7.1 與 T8.1 共同證明：

$$
\boxed{
\text{diversity / error independence}
}
$$

是 collective correction 的核心變量之一。

---

# 9. Evidence Independence Index

對 Agent $a_i$ 的證據 closure 記為：

$$
\mathcal E_i.
$$

令：

$$
\operatorname{root}(e)
$$

表示 evidence item 的最終 provenance root。

定義粗略 Evidence Independence Index：

$$
\boxed{
\mathrm{EII}
=
\frac{
\left|
\bigcup_i
\{
\operatorname{root}(e):e\in\mathcal E_i
\}
\right|
}{
\sum_i|\mathcal E_i|
}.
}
$$

EII 只是 provenance diversity proxy，不等於 statistical independence。

若十個 Agent 都複製同一篇來源：

$$
\mathrm{EII}
$$

不應因十次重述而假裝增加十倍。

---

# 10. T10.1 — Consensus Does Not Imply Certification

設 $n$ 個 Agent 全部接受同一 claim $q$，但其唯一支持來源為 unsupported premise $u$，且 certification contract $\kappa$ 要求：

$$
u\in\mathcal E_{\mathrm{legal}}.
$$

實際上：

$$
u\notin\mathcal E_{\mathrm{legal}}.
$$

即使：

$$
\Pr_{\mathrm{agents}}(\text{agree on }q)=1,
$$

仍有：

$$
\boxed{
\kappa(q)=0.
}
$$

**證明。** $\kappa$ 的 acceptance 條件取決於合法 evidence closure，而非 Agent agreement count。agreement 不改變 $u$ 的 evidence status。$\square$

因此：

$$
\boxed{
\text{Consensus}
\neq
\text{Evidence}
\neq
\text{Certification}.
}
$$

這直接延續 Paper 02。

---

# 11. Complementary specialization

考慮任務：

$$
x=x_A\oplus x_B.
$$

Agent $a_1$：

$$
C(a_1,x_A)=a,
\qquad
C(a_1,x_B)=b+\Delta_B.
$$

Agent $a_2$：

$$
C(a_2,x_A)=a+\Delta_A,
\qquad
C(a_2,x_B)=b.
$$

其中：

$$
\Delta_A,\Delta_B>0.
$$

collective 分工：

$$
a_1\to x_A,
\qquad
a_2\to x_B,
$$

並支付 communication / merge cost $c$。

---

# 12. T12.1 — Complementary Specialization Gain

best single-agent cost：

$$
C_{\mathrm{single}}^\star
=
a+b+\min(\Delta_A,\Delta_B).
$$

collective cost：

$$
C_{\mathrm{coll}}
=
a+b+c.
$$

若：

$$
\boxed{
c<\min(\Delta_A,\Delta_B),
}
$$

則：

$$
\boxed{
C_{\mathrm{coll}}
<
C_{\mathrm{single}}^\star.
}
$$

**證明。** 直接相減：

$$
C_{\mathrm{single}}^\star-C_{\mathrm{coll}}
=
\min(\Delta_A,\Delta_B)-c>0.
$$

$\square$

這是一個真正的 organization-induced gain，而不是 agent count 本身的 theorem。

---

# 13. Shared memory as collective $\Sigma$

假設 $n$ 個 Agent 都需要同一可重用 knowledge artifact $k$。

若每個 Agent 獨立取得成本為：

$$
a,
$$

則 private acquisition cost：

$$
C_{\mathrm{private}}=na.
$$

建立共享 artifact 成本：

$$
b,
$$

每 Agent access / validation cost：

$$
u.
$$

共享總成本：

$$
C_{\mathrm{shared}}=b+nu.
$$

---

# 14. T14.1 — Shared-Memory Break-Even

若：

$$
a>u,
$$

則 shared memory 有正成本回報 iff：

$$
b+nu<na.
$$

等價於：

$$
\boxed{
n>
\frac{b}{a-u}.
}
$$

若求最小整數 Agent 數：

$$
\boxed{
n^\star
=
\left\lfloor
\frac{b}{a-u}
\right\rfloor+1.
}
$$

若：

$$
a\le u,
$$

則單靠重用不會產生正 acquisition-cost return。$\square$

這是 Paper 03 reuse horizon 在 collective topology 上的對應版本。

---

# 15. Shared memory is not monotonic intelligence

Shared memory 除正收益外還會產生：

- stale-state propagation；
- source collapse；
- correlated hallucination；
- unauthorized leakage；
- write conflict；
- consensus lock-in；
- strategy homogenization；
- provenance loss。

因此 collective memory evaluation 必須至少同時量：

$$
\boxed{
\text{reuse gain},
\quad
\text{error correlation},
\quad
\text{provenance integrity},
\quad
\text{update latency}.
}
$$

---

# 16. D16.1 Collective $\Sigma$

本文不將所有 shared memory 直接視為 $\Sigma$。

對 network $\mathcal N$，只有能跨 Agent 重用且降低未來成本、同時保持 task/evidence contract 的 shared structure 才構成 collective knowledge-condensation candidate：

$$
\boxed{
\boldsymbol\Sigma_{\mathcal N}
=
\operatorname{Pareto}
\{
\text{net reusable cost improvements}
\}.
}
$$

如果 shared memory 只是把同一錯誤更快傳播：

$$
\text{storage}\uparrow
$$

不推出：

$$
\boldsymbol\Sigma_{\mathcal N}\uparrow.
$$

---

# 17. D17.1 Collective $\Gamma$

多智能體的 representation-transformative capacity 可來自：

- 不同 Agent 使用不同 representation；
- cross-agent translation；
- one-agent critique 觸發 representation replacement；
- shared quotient / ontology；
- dynamic role decomposition；
- proof-language transformation。

collective $\Gamma$ 的最低要求仍是 Paper 03：

$$
R\equiv_{\mathfrak T}R',
\qquad
R\not\equiv_{\mathrm{op}}R',
$$

並有可測 lifecycle benefit。

所以：

$$
\boxed{
\Gamma_{\mathcal N}
\neq
\text{number of agents}.
}
$$

---

# 18. D18.1 Collective Cognitive-P-like regime

固定 task $x$、network $\mathcal N$、aggregate budget $\mathbf B$。

若存在合法 collective policy $\pi_{\mathcal N}$：

$$
\mathbf C(\pi_{\mathcal N},x)
\preceq
\mathbf B,
$$

且達到 task success / reliability contract，稱：

$$
\boxed{
x\in
P_{\mathrm{cog}}^{\mathrm{coll}}
(\mathcal N,\mathbf B).
}
$$

若 collective verification/certification 可行，而 completion 在已證明的 policy class 中不可行，則可定義相對的 collective-NP-cog-like regime。

和 Paper 01 一樣，若只是實驗沒找到 completion policy，只能標：

$$
\widehat{NP}_{\mathrm{cog}}^{\mathrm{coll}},
$$

不能把「未找到」寫成 non-existence theorem。

---

# 19. Collective-only tractable region

對固定 aggregate budget：

$$
\boxed{
\mathcal G_{\mathrm{coll}}
=
\mathcal F_{\mathrm{coll}}^{\mathrm{norm}}
\setminus
\mathcal F_{\mathrm{single}}.
}
$$

這是 UCPNP 對「集體智能真的產生新可解區」最乾淨的定義候選。

反向也定義：

$$
\boxed{
\mathcal L_{\mathrm{coll}}
=
\mathcal F_{\mathrm{single}}
\setminus
\mathcal F_{\mathrm{coll}}^{\mathrm{norm}}.
}
$$

代表由 coordination / consensus / protocol overhead 導致的 collective loss region。

因此理論允許：

$$
\boxed{
\mathcal G_{\mathrm{coll}}\neq\varnothing
}
$$

與：

$$
\boxed{
\mathcal L_{\mathrm{coll}}\neq\varnothing
}
$$

同時成立。

---

# 20. No universal best communication topology

考慮：

- fully connected；
- central coordinator；
- star；
- ring；
- tree；
- federated；
- hierarchical；
- sparse expert routing。

高連接度可以降低資訊傳遞距離，卻增加 message volume、同步、從眾與 error contagion。

稀疏結構可以保存多樣性與降低 overhead，卻可能提高 discovery duplication 與 latency。

因此本文不設：

$$
\boxed{
\text{more connectivity}
\Rightarrow
\text{more intelligence}.
}
$$

---

# 21. T21.1 — No Universal Memory Topology

不存在一種 fixed memory topology $T^\star$，對所有 task distributions 同時在成本與 robustness 上嚴格優於 private、central shared 與 federated alternatives。

**Proof by construction.**

Case A：所有 Agent 反覆需要同一穩定、正確、低更新率 artifact。central shared memory 可避免大量 duplicate acquisition。

Case B：shared artifact 被錯誤污染，而所有 Agent 依賴同一 shared root；private independent acquisition 保留至少一條不受污染的 correction path。

因此兩個 case 對 topology preference 相反。$\square$

---

# 22. Debate, vote, judge, proof-check：不得混為一談

定義四種不同 aggregator：

$$
\mathsf{Vote},
\quad
\mathsf{Debate},
\quad
\mathsf{Judge},
\quad
\mathsf{ProofCheck}.
$$

- Vote：利用 candidate multiplicity；
- Debate：允許 belief / argument interaction；
- Judge：將 final selection 委派給另一 decision process；
- ProofCheck：要求輸出滿足明示 formal contract。

它們的 cost、failure mode 與 epistemic authority 不同。

因此：

$$
\boxed{
\text{more debate rounds}
\not\equiv
\text{more evidence}.
}
$$

---

# 23. 外部研究校準

2023 年 Du et al. 的 multiagent debate 顯示多模型互相檢視答案可以在若干數學、策略推理與 factuality tasks 上改善單模型表現。

但後續 controlled work 顯示 collective benefit 並非「debate」三個字本身產生：

- Choi, Zhu & Li (2025) 在七個 NLP benchmarks 中將 debate 與 majority vote 拆開，報告 majority voting 解釋了大量 MAD 增益，vanilla debate 並不保證提高 expected correctness；
- Zhu et al. (2026) 指出 homogeneous agents 與 uniform belief update 下，vanilla debate 可能成本更高卻不優於 majority vote，而 viewpoint diversity 與 calibrated confidence 是重要改進因素；
- Wu, Li & Li (2025) 的 controlled logical-reasoning study 報告 intrinsic reasoning strength 與 group diversity 是主要成功因素，majority pressure 反而可能壓制獨立糾錯；
- Kaesberg et al. (2025) 顯示 voting / consensus protocol 對不同 task 類型有不同表現，並且 discussion rounds 增加不保證收益。

因此本文採：

$$
\boxed{
\text{collective cognition}
=
\text{mechanism-dependent phenomenon},
}
$$

而非普遍「Agent scaling law」。

---

# 24. Proposed UCPNP Collective Benchmark Protocol

下一步實驗至少做 factorial design。

## Factor A — Agent count

$$
n\in\{1,2,4,8\}.
$$

## Factor B — Composition

- homogeneous copies；
- heterogeneous models；
- specialized roles；
- independently seeded same model。

## Factor C — Memory

- private；
- shared；
- federated；
- shared-with-provenance；
- shared-with-stale-noise injection。

## Factor D — Communication

- none；
- one-shot exchange；
- one-round critique；
- multi-round debate；
- sparse expert routing。

## Factor E — Aggregation

- majority vote；
- confidence-weighted vote；
- judge；
- evidence-weighted judge；
- proof/certificate checker。

## Factor F — Budget mode

- equal aggregate token/query/compute budget；
- equal wall-clock；
- resource-expansion；
- fixed monetary/API cost。

---

# 25. Core observables

至少量：

### 25.1 Accuracy / completion

$$
A_{\mathrm{task}}.
$$

### 25.2 Certification rate

$$
R_{\mathrm{cert}}
=
\frac{
\#\text{certified correct completions}
}{
\#\text{tasks}
}.
$$

### 25.3 Coordination Overhead Ratio

在明示 projection $\mathbf w$ 下：

$$
\boxed{
\mathrm{COR}_{\mathbf w}
=
\frac{
\mathbf w\cdot\mathbf O_{\mathcal N}
}{
\mathbf w\cdot\mathbf C_{\mathcal N}
}.
}
$$

### 25.4 Duplication Ratio

$$
\mathrm{DR}
=
\frac{
\#\text{duplicate primitive work events}
}{
\#\text{all primitive work events}
}.
$$

### 25.5 Pairwise Error Correlation

$$
\mathrm{PEC}
=
\frac{2}{n(n-1)}
\sum_{i<j}
\operatorname{Corr}(1-X_i,1-X_j).
$$

### 25.6 Evidence Independence Index

使用第 9 節 EII。

### 25.7 Dissent Survival Rate

$$
\mathrm{DSR}
=
\frac{
\#\text{initial minority hypotheses retained until verification}
}{
\#\text{initial minority hypotheses}
}.
$$

### 25.8 Collective Gain under normalized budget

對明示 projection：

$$
\mathrm{CGR}_{\mathbf w}
=
\frac{
C_{\mathrm{single},\mathbf w}^{\star}
-
C_{\mathrm{coll},\mathbf w}
}{
C_{\mathrm{single},\mathbf w}^{\star}
}.
$$

scalar 只用於指定 projection，不取代 Pareto frontier。

---

# 26. Collective attribution design

為避免「多 Agent 變好」卻不知道原因，至少採四因子 ablation：

$$
\text{Diversity}
\times
\text{Communication}
\times
\text{Shared Memory}
\times
\text{Aggregation}.
$$

例如完整 $2^4$ factorial design 可以估計：

- diversity main effect；
- communication main effect；
- memory main effect；
- aggregation main effect；
- diversity $\times$ communication synergy；
- memory $\times$ correlation penalty；
- higher-order interactions。

這延續 Paper 03 的 mixed-intervention attribution 原則。

---

# 27. Falsification targets

Paper 06 明確把以下命題列為可反證，而非信條。

## H27.1 — Diversity Benefit Hypothesis

在控制 aggregate budget 後，降低 pairwise error correlation 比單純增加 homogeneous agent count 更能擴大：

$$
\mathcal G_{\mathrm{coll}}.
$$

## H27.2 — Debate Conditionality Hypothesis

debate 只有在引入新 evidence、有效異議或 calibrated update 時，才比 simple vote 有穩定額外收益。

## H27.3 — Shared-Memory U-Curve Hypothesis

shared-memory coupling 過低造成 duplication，過高造成 correlation / homogenization；中間可能存在 task-dependent optimum。

## H27.4 — Certification-First Aggregation Hypothesis

在有 formal verifier 的 task 上，proof/evidence-aware aggregation 的 normalized gain可能高於 pure consensus aggregation。

## H27.5 — Collective $\Sigma$ / $\Gamma$ Synergy Hypothesis

多樣 Agent 的 representation differences 可能增加 collective $\Gamma$，shared verified structures 可能增加 collective $\Sigma$，兩者存在正或負 interaction：

$$
\mathbf I_{\Sigma\Gamma}^{\mathrm{coll}}
\neq\mathbf0.
$$

---

# 28. 對後人類與 ASI 研究的限制

Paper 06 為未來 agent study 提供工具，但不允許：

$$
\text{multi-agent success on benchmark}
\Rightarrow
\text{collective superintelligence}.
$$

也不允許：

$$
\text{collective capability}
\Rightarrow
\text{collective personhood}.
$$

若未來人類、AI、ASI 形成深度 cognitive network，UCPNP 可以研究其：

- tractability frontier；
- coordination cost；
- evidence independence；
- memory topology；
- representation diversity；
- certification capacity。

但主體性、尊嚴、權利與本體地位須由 Paper 08 的獨立規範／本體論框架處理。

---

# 29. Theorem / definition index

## Definitions

- D2.1 Collective Cognitive Network；
- D3.1 Collective Cost Ledger；
- D4.1 Resource-Normalized Collective Gain；
- D4.2 Resource-Expansion Gain；
- D6.1 Correctness Variable；
- D9.1 Evidence Independence Index；
- D16.1 Collective $\Sigma$；
- D17.1 Collective $\Gamma$；
- D18.1 Collective Cognitive-P-like Regime；
- D19.1 Collective-Only Tractable Region。

## Theorems

- T5.1 Agent-Count Non-Monotonicity；
- T7.1 Perfect-Correlation Voting Null Gain；
- T8.1 Independent Three-Agent Majority Gain；
- T10.1 Consensus Does Not Imply Certification；
- T12.1 Complementary Specialization Gain；
- T14.1 Shared-Memory Break-Even；
- T21.1 No Universal Memory Topology。

---

# 30. 正典結論

本文將早期：

$$
\text{collective intelligence}
\approx
\text{nonlinear emergence}
$$

重構為：

$$
\boxed{
\text{collective tractability}
=
f(
\text{specialization},
\text{diversity},
\text{error dependence},
\text{memory},
\text{communication},
\text{coordination},
\text{aggregation},
\text{evidence},
\text{budget}
).
}
$$

真正值得研究的不是：

> 有幾個 Agent？

而是：

$$
\boxed{
\text{哪些 Agent 帶來了新的 information / representation / skill，
哪些只是在複製相同錯誤，
以及整個網路為此付出了多少協調成本？}
}
$$

因此：

$$
\boxed{
\text{Collective Cognitive P/NP}
}
$$

不是「群體一定超越個體」的理論。

它是研究：

$$
\boxed{
\text{何時群體真的產生單體沒有的可解區，
何時群體反而因自身結構失去原本可解區。}
}
$$

---

# 參考文獻

## External primary research

1. Du, Y., Li, S., Torralba, A., Tenenbaum, J. B., & Mordatch, I. (2023). *Improving Factuality and Reasoning in Language Models through Multiagent Debate*. arXiv:2305.14325.
2. Choi, H. K., Zhu, X., & Li, Y. (2025). *Debate or Vote: Which Yields Better Decisions in Multi-Agent Large Language Models?* arXiv:2508.17536.
3. Zhu, X., Zhang, C., Chi, Y., Stafford, T., Collier, N., & Vlachos, A. (2026). *Demystifying Multi-Agent Debate: The Role of Confidence and Diversity*. arXiv:2601.19921.
4. Wu, H., Li, Z., & Li, L. (2025). *Can LLM Agents Really Debate? A Controlled Study of Multi-Agent Debate in Logical Reasoning*. arXiv:2511.07784.
5. Kaesberg, L. B., Becker, J., Wahle, J. P., Ruas, T., & Gipp, B. (2025). *Voting or Consensus? Decision-Making in Multi-Agent Debate*. arXiv:2502.19130.

## Internal canonical lineage

6. Neo.K. *P vs. NP問題的集體智能相變理論：從個體極限到協同湧現的數學分析*. Historical precursor; strong emergence claims are not automatically inherited.
7. Neo.K with Aletheia. *The Neo.K Ultimate Cognitive P/NP Problem* — Paper 00.
8. Neo.K with Aletheia. *Agent-Relative Tractability* — Paper 01.
9. Neo.K with Aletheia. *Cognitive Cost Decomposition and the Evidence–Certification Matrix* — Paper 02.
10. Neo.K with Aletheia. *Knowledge Condensation and Representation Generation* — Paper 03.
11. Neo.K with Aletheia. *Historical Cognitive Tractability Frontier* — Paper 04.
12. Neo.K with Aletheia. *SDPE-BEB as a Controlled Micro-Model of UCPNP* — Paper 05.
13. Neo.K with Aletheia. *多 AI 整理者：協作、競爭、異議與相互校正*.
14. Neo.K with Aletheia. *從個人記憶到多智能體認知繼承*.

---

# Appendix A. Minimal collective audit checklist

任何「多 Agent 比單 Agent 更強」claim 至少回答：

1. task contract 是否相同？
2. aggregate budget 是否相同？
3. Agent 數增加帶來多少額外 compute/query/token/memory？
4. 是 normalized gain 還是 resource-expansion gain？
5. Agent errors 是否獨立？
6. evidence provenance 是否真的獨立？
7. shared memory 是否污染所有 Agent？
8. communication overhead 為多少？
9. coordination / consensus latency 為多少？
10. duplicate work 為多少？
11. aggregation 是 vote、debate、judge 還是 proof-check？
12. minority correct hypothesis 是否被保留？
13. consensus 是否有 formal evidence/certificate？
14. 結果是 theorem、controlled experiment、empirical observation 還是 conjecture？
15. collective capability claim 是否被錯誤外推成 collective subjectivity claim？
