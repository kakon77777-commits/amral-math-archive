from fractions import Fraction

def majority3(p):
    return 3*p*p - 2*p*p*p

# T8.1 samples for rational p > 1/2
for p in [Fraction(3,5), Fraction(2,3), Fraction(3,4), Fraction(9,10)]:
    assert majority3(p) > p
    assert majority3(p)-p == p*(1-p)*(2*p-1)

# T7.1: perfect correlation -> majority same random variable, symbolic probability stays p.
for p in [Fraction(1,3), Fraction(1,2), Fraction(3,5), Fraction(9,10)]:
    majority_perfect_corr = p
    assert majority_perfect_corr == p

# T12.1 specialization
cases = [
    (2,3,5,7,1),
    (10,20,4,6,3),
]
for a,b,da,db,c in cases:
    single = a+b+min(da,db)
    coll = a+b+c
    assert c < min(da,db)
    assert coll < single

# T14.1 shared memory break-even
def break_even(b,a,u):
    assert a > u
    return b//(a-u)+1

for b,a,u in [(10,5,1),(20,8,2),(7,3,1)]:
    n = break_even(b,a,u)
    assert b+n*u < n*a
    if n > 1:
        assert not (b+(n-1)*u < (n-1)*a)

print("UCPNP Paper 06 finite theorem checks: PASS")
