# UCPNP Series II — E01 Historical Cognitive Backtest Corpus
## Batch 04：FGCS、LIGO、Foldit、METR Time Horizon 1.1

**Series:** Neo.K Ultimate Cognitive P/NP — Series II Experiments  
**Experiment:** E01 — Historical Cognitive Backtest Corpus  
**Batch:** 04  
**Version:** v0.1  
**Author:** Neo.K  
**Collaborative analysis:** Aletheia  
**Date:** 2026-08-16  
**Status:** Mixed historical/current empirical backtest. This batch tests route redirection, observation-frontier expansion, human–computer hybrid cognition, and scope-bounded modern agent measurement.

---

# 0. Batch 04 purpose

前三批主要研究「成功突破如何發生」。

Batch 04 開始測：

$$
\boxed{
\text{frontier advancement}
\neq
\text{single monotone success path}.
}
$$

本批加入四種不同狀態：

- `REDIRECT`：技術路線取得成果，但 ecosystem / portability frontier 迫使後續轉向；
- `OBSERVATION-ADVANCE`：新儀器使原本不可直接取得的 evidence 進入可觀測域；
- `HYBRIDIZE`：人與機器形成互補 search / representation system；
- `MEASUREMENT-BOUNDED`：現代 agent capability 指標本身具有明示 domain 與 reliability boundary。

這些只是 Batch-level status labels，不新增 UCPNP foundational primitive。

---

# 1. Case K — Japanese Fifth Generation Computer Systems (FGCS)

## 1.1 Initial hypothesis correction

Batch 04 原先想把 FGCS 當：

> failure / abandoned paradigm.

Primary official sources 不支持這個簡化。

官方 museum / final project materials record：

- 1982–1992/93 長期 FGCS project；
- 64-processor experimental parallel inference machine during middle stage；
- final stage built prototype systems at roughly 1000-processor scale；
- KL1 / PIMOS / parallel inference and knowledge-processing systems；
- follow-on project explicitly aimed to disseminate the technology.

因此本 Batch 撤回：

$$
\boxed{
\text{FGCS}=\text{simple failure}.
}
$$

---

# 2. The actual redirection

官方 FGCS archive 明確說明：

> many final software systems could run only on the Parallel Inference Machines.

這形成：

$$
\boxed{
\text{dedicated-platform success}
+
\text{portability bottleneck}.
}
$$

1993–1994/95 follow-on project 因而改成：

- KLIC；
- compile KL1 into C；
- run on Unix-based sequential / parallel machines；
- port major knowledge-processing systems；
- distribute ICOT Free Software；
- use FTP / WWW for dissemination.

Follow-on report 甚至把目標之一稱為：

$$
\boxed{
\text{soft-landing}.
}
$$

---

# 3. FGCS UCPNP interpretation

原路線：

$$
\boxed{
H_{\mathrm{PIM}}
+
M_{\mathrm{KL1/PIMOS}}
}
$$

確實形成 technical capability。

但：

$$
\boxed{
\text{capability on dedicated substrate}
\not\Rightarrow
\text{ecosystem diffusion}.
}
$$

後續 KLIC 介入可標：

$$
\boxed{
M+\Gamma_{\mathrm{portability\ candidate}}.
}
$$

因為同一 KL1/knowledge-processing semantics 被重新映射到 Unix/C/general-purpose MIMD environment。

---

# 4. FGCS signature

Route state：

$$
\boxed{
\texttt{REDIRECT}
}
$$

Signature：

$$
\boxed{
\textbf{Dedicated-Platform Capability}
\rightarrow
\textbf{Portability / Diffusion Redirection}.
}
$$

這不是：

$$
\text{failure}.
$$

也不是：

$$
\text{unchanged success}.
$$

它表示 historical tractability 可以先在專用域打開，之後為了：

$$
\text{portability},
\text{cost},
\text{ecosystem},
\text{reuse}
$$

改變技術路徑。

---

# 5. Case L — LIGO / GW150914

## 5.1 Fixed epistemic task

固定：

> 從地面實驗資料取得足以支持「直接觀測到 gravitational waves from a binary black-hole merger」的 evidence。

這裡不是重新求解 Einstein equations。

真正 historical frontier 是：

$$
\boxed{
E
=
\text{observation / sensor access}.
}
$$

---

# 6. Direct observation

Advanced LIGO 兩個 detectors 於：

$$
\boxed{
2015\text{-}09\text{-}14\ 09{:}50{:}45\ UTC
}
$$

同時觀測到 transient gravitational-wave signal。

LIGO publication records：

- signal frequency sweeps roughly 35–250 Hz；
- matched-filter SNR 24；
- false-alarm rate below 1 event per 203,000 years；
- significance above $5.1\sigma$；
- waveform matches general-relativistic binary-black-hole inspiral/merger/ringdown；
- first direct detection of gravitational waves；
- first observation of binary black-hole merger.

因此：

$$
\boxed{
Y_E^{(\mathrm{direct\ GW\ evidence})}
\le2015.
}
$$

public certification/publication：

$$
Y_{\mathrm{Cert}}^{(\mathrm{scientific\ publication})}
\le2016.
$$

---

# 7. LIGO mechanism attribution

主要：

$$
\boxed{
E+H+M.
}
$$

- $E$：previously unavailable direct detector evidence；
- $H$：Advanced LIGO instrument sensitivity / physical detector；
- $M$：filtering, calibration, statistical inference, waveform comparison.

其最重要 UCPNP result：

$$
\boxed{
\text{more reasoning}
\not\Rightarrow
\text{missing observation}.
}
$$

在 detector evidence 取得之前，內部推理可以支持 prediction，但不能把未觀測訊號變成 observation。

這是 Paper 02 information obstruction 的自然科學實例。

---

# 8. LIGO signature

Route state：

$$
\boxed{
\texttt{OBSERVATION-ADVANCE}
}
$$

Signature：

$$
\boxed{
\textbf{Observation-Frontier Shift}.
}
$$

---

# 9. Case M — Foldit

## 9.1 Fixed task

固定：

> 對 difficult protein-structure prediction / refinement problem，藉互動式人機系統產生可改善 computational search 的 protein models。

Foldit 不是：

$$
\text{human only}
$$

也不是：

$$
\text{computer only}.
$$

玩家透過 game interface 使用來自 Rosetta 的 computational tools 操作 protein structures。

---

# 10. Human + algorithmic complementarity

2010 Nature paper reports：

- thousands of non-scientists；
- multiplayer competition and collaboration；
- direct protein manipulation；
- Rosetta-derived computational tools；
- top players excelled on difficult refinement tasks；
- players collectively developed new strategies and algorithms；
- humans explored not only conformational space, but search-strategy space.

因此：

$$
\boxed{
N+M+\Gamma_{\mathrm{strategy\ candidate}}.
}
$$

其中：

- $N$：many human participants / collaboration；
- $M$：Rosetta computational operators；
- $\Gamma_{\mathrm{strategy}}$：players transform effective search strategy / representation of promising moves.

---

# 11. Strong real-world follow-up

2011 protein-structure paper reports：

> after a wide range of attempts to solve the M-PMV retroviral protease crystal structure by molecular replacement failed, Foldit players were challenged to generate models.

Players produced models sufficient for successful molecular replacement and subsequent structure determination.

因此：

$$
\boxed{
\text{human-computer hybrid}
}
$$

不只是 benchmark entertainment；至少存在一個 real scientific result where hybrid search produced a structure-enabling artifact after prior approaches had failed.

---

# 12. What Foldit does not prove

不能由此推出：

$$
\boxed{
\text{crowdsourcing always beats automation}.
}
$$

也不能推出：

$$
\boxed{
\text{human intuition universally provides }\Gamma.
}
$$

只可說：

$$
\boxed{
\text{hybrid complementarity exists in at least this controlled/scientific setting}.
}
$$

---

# 13. Foldit signature

Route state：

$$
\boxed{
\texttt{HYBRIDIZE}
}
$$

Signature：

$$
\boxed{
\textbf{Human–Computer Complementarity / Strategy-Space Expansion}.
}
$$

---

# 14. Case N — METR Time Horizon 1.1 (2026)

## 14.1 Why this is a different kind of case

這不是 classical historical breakthrough。

它是：

$$
\boxed{
\text{current capability-measurement frontier}.
}
$$

所以 task 是：

> 如何對 frontier AI agents 的長任務能力給出可校準、可更新、scope-bounded 的 operational metric？

---

# 15. Current measurement contract

截至：

$$
\boxed{
2026\text{-}05\text{-}08
}
$$

METR Time Horizon 1.1 defines：

> human-expert task duration at which an AI agent is predicted to succeed with a specified probability.

例如 50%-time horizon：

$$
\tau_{50}
=
\text{human-task duration at predicted 50% AI success}.
$$

它以超過一百個 software tasks 建模，主要來自：

- software engineering；
- machine learning；
- cybersecurity.

---

# 16. Scope boundary

METR 明確標示：

$$
\boxed{
\text{measurements above 16 hours are unreliable with the current task suite}.
}
$$

因此：

$$
\boxed{
\tau_{50}>16h
}
$$

在 current suite 下不能被當作高可信 absolute capability estimate。

這是一個非常乾淨的 Evidence Passport 範例：

$$
\boxed{
\text{metric scope}
<
\text{all-world autonomy claim}.
}
$$

---

# 17. Time horizon is not literal autonomous runtime

METR FAQ 明確澄清：

> time horizon does not mean an AI can literally act autonomously for that duration.

它量的是：

$$
\boxed{
\text{task difficulty indexed by human completion time}.
}
$$

不是：

$$
\boxed{
\text{AI wall-clock autonomous duration}.
}
$$

因此 Paper 07 的 $\tau$ 需要更細分：

- task-difficulty horizon proxy；
- actual persistent autonomy runtime。

Batch 04 不新增 primitive；只在 measurement contract 中加明示 tag。

---

# 18. Measurement revision is part of the science

METR page 的 update history includes：

- 2026-03-03：corrected a regularization mistake affecting measurements；
- 2026-05-08：added current models and explicit >16h unreliability notice.

因此：

$$
\boxed{
\text{capability metric}
}
$$

本身也有：

$$
\text{version},
\text{bug correction},
\text{scope revision}.
$$

這正好支持 UCPNP Evidence Passport / versioned measurement。

---

# 19. METR signature

Route state：

$$
\boxed{
\texttt{MEASUREMENT-BOUNDED}
}
$$

Signature：

$$
\boxed{
\textbf{Scope-Limited Agent Capability Measurement}.
}
$$

---

# 20. Cross-case matrix

| Case | Main frontier event | Route state | Signature |
|---|---|---|---|
| FGCS | dedicated parallel knowledge-processing capability later ported to Unix/general MIMD ecosystem | REDIRECT | Dedicated-Platform → Portability/Diffusion Redirection |
| LIGO | new detector evidence makes direct gravitational-wave observation available | OBSERVATION-ADVANCE | Observation-Frontier Shift |
| Foldit | humans + Rosetta/game interface produce complementary search strategies and a real structure-solving artifact | HYBRIDIZE | Human–Computer Complementarity |
| METR TH1.1 | modern agent capability measured with explicit task-domain/reliability boundaries | MEASUREMENT-BOUNDED | Scope-Limited Capability Measurement |

---

# 21. Result R21.1 — Technical success and historical route success are different

FGCS shows：

$$
\boxed{
\text{prototype capability success}
\not\Rightarrow
\text{unchanged ecosystem trajectory}.
}
$$

A route can achieve strong local technical goals yet later require portability / diffusion redirection.

Thus E01 should not use a binary：

$$
\text{success/failure}.
$$

Route state is multi-valued.

---

# 22. Result R22.1 — Observation is a first-class tractability input

LIGO supports：

$$
\boxed{
E
}
$$

as genuinely irreducible in some scientific tasks.

If the world has not supplied the signal：

$$
\text{internal computation}
\not\Rightarrow
\text{direct observation}.
$$

This is an empirical counterpart to Paper 02's information obstruction.

---

# 23. Result R23.1 — Hybrid cognition can expand strategy space

Foldit supplies an existence example where：

$$
\boxed{
\mathcal F_{\mathrm{hybrid}}
}
$$

contains useful scientific outputs not obtained by the preceding attempted route.

But resource-normalized superiority remains unresolved.

Therefore Batch 04 labels：

$$
\text{hybrid gain existence}
$$

without claiming：

$$
\text{equal-budget dominance}.
$$

---

# 24. Result R24.1 — Measurement frontiers are themselves versioned objects

METR shows modern AI capability measurements require：

- metric definition；
- task distribution；
- human baseline；
- reliability threshold；
- version；
- methodological corrections；
- explicit invalid/unreliable range.

Therefore：

$$
\boxed{
\text{AI capability number}
}
$$

without measurement passport is not a stable epistemic object.

---

# 25. No new primitive test

Batch 04 exposes possible concepts：

- route-state；
- observation frontier；
- hybrid cognition；
- metric-version frontier.

Do they require new foundational variables?

Current answer：

$$
\boxed{
\text{No}.
}
$$

They fit existing：

- $E$ for observation；
- $N,M,\Gamma$ for hybrid cognition；
- $\Lambda$ / Evidence Passport for metric versions；
- route-state as historical metadata rather than core state variable.

Series-I Stop Rule passes again.

---

# 26. E01 signature inventory after Batch 04

Fourteen cases now exist:

1. Dijkstra — Method-Dominant；
2. Four Color — Certification-Lag；
3. AlexNet — Mixed-Convergence；
4. FFT — Lineage-Recovery / Method-Generalization；
5. GRASP/CDCL — Knowledge-Condensation-with-Overhead；
6. RSA — Concept–Method–Deployment-Contract Lag；
7. Coppersmith–Winograd — Asymptotic-Theorem / Practicality-Unresolved；
8. Deep Blue — Hardware-Amplified Search + Knowledge Support；
9. CompCert — Certification-Frontier Shift；
10. Google/PageRank — Offline-Precomputation / Online-Query Shift；
11. FGCS — Dedicated-Platform → Portability/Diffusion Redirection；
12. LIGO — Observation-Frontier Shift；
13. Foldit — Human–Computer Complementarity；
14. METR Time Horizon — Scope-Limited Capability Measurement。

---

# 27. First route-state vocabulary

E01 now uses, as metadata：

- `ADVANCE`
- `REDIRECT`
- `HYBRIDIZE`
- `OBSERVATION-ADVANCE`
- `CERTIFICATION-ADVANCE`
- `MEASUREMENT-BOUNDED`
- `PLATEAU`
- `REPLACED`
- `UNRESOLVED`

These are not ontological categories.

They are historical audit labels.

---

# 28. Batch 04 falsifies four simplistic stories

$$
\boxed{
\text{national project}
=
\text{failure or success only}
}
$$

No.

$$
\boxed{
\text{scientific theory}
+
\text{more reasoning}
=
\text{observation}
}
$$

No.

$$
\boxed{
\text{human vs computer}
}
$$

is not always the right comparison; hybrid systems can be the actual unit.

$$
\boxed{
\text{one AI benchmark number}
=
\text{general autonomy}
}
$$

No.

---

# 29. E01 next step

After 14 cases, pure case accumulation begins to have diminishing returns.

The next useful step is not immediately Batch 05.

We should first build：

$$
\boxed{
\text{E01 Interim Meta-Analysis v0.1}
}
$$

across Batches 01–04：

- signature taxonomy；
- mechanism-frequency matrix；
- unresolved-rate；
- attribution-revision count；
- stop-rule pressure points；
- whether HCTF adds information beyond a single-year narrative；
- which variables are overused；
- which variables have not yet been empirically exercised.

Only then choose Batch 05 adversarial cases targeted at the weak spots.

---

# 30. Conclusion

Batch 04 is the first E01 batch where the best result is not a breakthrough date.

It establishes four higher-order distinctions：

$$
\boxed{
\text{local technical success}
\neq
\text{unchanged route success},
}
$$

$$
\boxed{
\text{theory}
\neq
\text{observation},
}
$$

$$
\boxed{
\text{single-agent dichotomy}
\neq
\text{hybrid cognition},
}
$$

$$
\boxed{
\text{metric value}
\neq
\text{metric scope}.
}
$$

This means UCPNP historical backtesting is starting to model not merely:

> when did humans become able to do X?

but also:

> what kind of frontier changed, what remained blocked, and did the route itself survive?

---

# References

1. ICOT / AIST historical archive. *Fifth Generation Computer Systems Project* conference and project records.
2. Shunichi Uchida. *General Report of the FGCS Follow-on Project*. FGCS'94.
3. B. P. Abbott et al. (LIGO Scientific Collaboration and Virgo Collaboration). *Observation of Gravitational Waves from a Binary Black Hole Merger*. Physical Review Letters 116, 061102 (2016); signal observed 14 September 2015.
4. Seth Cooper et al. *Predicting protein structures with a multiplayer online game*. Nature 466, 756–760 (2010).
5. Firas Khatib et al. *Crystal structure of a monomeric retroviral protease solved by protein folding game players*. Nature Structural & Molecular Biology 18, 1175–1177 (2011).
6. METR. *Task-Completion Time Horizons of Frontier AI Models — Time Horizon 1.1*. Last updated May 8, 2026.
