import csv, json
from pathlib import Path
base=Path(__file__).parent
rows=list(csv.DictReader((base/"E01_Batch04_Phase_Matrix_v0.1.csv").open(encoding="utf-8")))
assert len(rows)==4
assert {r["case_id"] for r in rows}=={"K_FGCS","L_LIGO","M_Foldit","N_METR_TH11"}
assert len({r["route_state"] for r in rows})==4

fg=next(r for r in rows if r["case_id"]=="K_FGCS")
assert fg["route_state"]=="REDIRECT"
assert "failure" in fg["unresolved"]

li=next(r for r in rows if r["case_id"]=="L_LIGO")
assert "E + H + M" in li["mechanism"]

fo=next(r for r in rows if r["case_id"]=="M_Foldit")
assert "resource-normalized" in fo["unresolved"]

me=next(r for r in rows if r["case_id"]=="N_METR_TH11")
assert "16h" in me["unresolved"]
assert "not literal" in me["unresolved"]

p=json.loads((base/"E01_Batch04_Evidence_Passports_v0.1.json").read_text(encoding="utf-8"))
assert len(p["passports"])==6
assert any("binary claim" in x.get("uncertainty","") for x in p["passports"])
assert any("16 hours" in x["claim"] for x in p["passports"])

print("UCPNP E01 Batch04 consistency checks: PASS")
