# 認知成本分解與證據—認證矩陣：從 Search–Execution–Verification 到 Truth–Evidence–Certification

**English title:** *Cognitive Cost Decomposition and the Evidence–Certification Matrix: From Search–Execution–Verification to Truth–Evidence–Certification*  
**Series:** Neo.K Ultimate Cognitive P/NP  
**Canonical parent:** Paper 00 — *The Neo.K Ultimate Cognitive P/NP Problem*  
**Direct dependency:** Paper 01 — *Agent-Relative Tractability*  
**Paper:** 02  
**Definition origin:** Neo.K  
**Formalization:** Neo.K with Aletheia  
**Research organization:** EveMissLab  
**Version:** v0.1  
**Date:** 2026-08-15  
**Status:** Formal foundational draft; all theorem claims are internal consequences of the stated task, information, cost, and certification contracts, not claims about classical $P$ versus $NP$.

---

# Canonical non-identity statement

$$
\boxed{
\mathrm{UCPNP}_{\mathrm{Neo.K}}
\neq
(P\stackrel{?}{=}NP)_{\mathrm{classical}}
}
$$

本文研究的是有限智能體在固定任務語義、有限資訊、有限資源與明示證據契約下的**認知成本結構**。本文使用 search / verification asymmetry 作為研究直覺，但不把本文的 cost phases、epistemic states 或 cognitive-P-like / cognitive-NP-like regimes 認作標準 complexity classes。

---

# 摘要

Neo.K 終極認知 P/NP 研究綱領將「問題是否容易」改寫為一個智能體相對、歷史相對且資源顯式的可解性問題。Paper 01 已經以固定任務契約、合法策略集、多維資源向量與 completion / verification frontier 封閉「任意相對主義」；本文進一步處理下一個核心問題：**一個智能體完成任務時究竟把成本花在哪裡，而「結果為真」、「持有證據」與「具有可提交認證」又如何彼此分離？**

本文提出六相認知成本分解：Representation、Discovery、Construction、Execution、Verification、Certification，分別記為

$$
(C_R,C_D,C_C,C_E,C_V,C_{\mathrm{Cert}}).
$$

為避免 phase accounting 重複計費，本文以 primitive-event ledger 為基礎，將每個可計費事件唯一歸屬於一個 phase 或明示 shared-overhead account，得到成本守恆式。本文同時建立三層 epistemic state：Truth、Evidence、Certification。Truth 是任務語義下的客觀正確性；Evidence 是智能體可合法引用的支持物；Certification 是在指定 contract 下對 evidence 與 claim 的可提交認證狀態。三者不等價：真結果可以沒有可用證據；證據可以存在但尚未通過認證；認證只有在 certifier soundness 假設下才可推出其 scope 內的真值支持。

本文證明三類不可替代性結果。第一，若兩個 completion worlds 對智能體目前全部可用資訊不可區分，卻要求互斥答案，則純內部計算無法產生 zero-error completion；此為 **information obstruction**。第二，若 certification contract 要求一個目前 evidence closure 中不存在的 witness / trace / provenance artifact，則「答案為真」不能替代缺失 evidence；此為 **evidence obstruction**。第三，若 contract 要求指定 proof checker、signature、authority 或 provenance policy，則持有語義上充分的 evidence 不等於具有 certification；此為 **certification obstruction**。

本文亦建立 representation / precomputation 的攤銷守恆、phase projection 的樂觀偏差定理，以及 certification scope 原則。最後提出一個 coarse $3\times3$ process–epistemic matrix 與 refined $6\times3$ cost–epistemic incidence matrix，作為後續 SDPE-BEB、AI agent、歷史可解性、多智能體與 ASI 研究的共同測量介面。

**關鍵詞：** cognitive cost decomposition、Truth–Evidence–Certification、metareasoning、proof-carrying computation、information obstruction、verification asymmetry、certification authority、representation cost、precomputation accounting、agent-relative tractability

---

# 0. Claim typing

本文沿用 Paper 00 的五類主張型別：

- **D** — Definition；
- **T** — Theorem；
- **C** — Conjecture；
- **E** — Empirical Hypothesis；
- **N** — Normative Axiom。

本文主要是 **D/T** 論文。以下敘述必須嚴格區分：

$$
\boxed{
\text{formal obstruction under a declared contract}
\neq
\text{empirical difficulty in an open-world AI system}
}
$$

若無完整 policy space、lower bound、indistinguishability certificate 或其他 non-existence 證明，則不得把「目前模型沒有找到方法」寫成「不存在方法」。

---

# 1. 問題：一個「難」字同時壓扁了太多東西

早期動態速率研究已經區分「尋找解」與「執行解」，並指出單純增加物理算力未必能補償導航能力缺失。Paper 01 又把完整 completion 與外部給定候選後的 verification 分離。然而若我們仍只使用單一成本 $C(x)$，至少會混淆以下情況：

1. 問題表示很差，因此智能體花大量成本理解輸入；
2. 表示已清楚，但不知道去哪裡找解；
3. 已經知道大致路徑，但仍需建造 proof、program、tool 或 artifact；
4. 路徑已確定，只剩大量機器執行；
5. 結果已產生，但驗證仍昂貴；
6. 結果與證據都足夠，但特定制度要求額外 provenance、signature、formal proof 或 audit 才能提交。

這六種困難具有不同的改善方式。用 GPU 提升 $C_E$ 的效率，未必改變 $C_D$；增加記憶可能壓低 $C_D$，卻提高 maintenance cost；proof generator 可以增加 $C_C$，同時大幅降低下游 verifier 的 $C_V$；更換 representation 可能先增加 $C_R$，但降低後續所有成本。

因此本文的核心不是尋找一個「真正的單一複雜度」，而是建立一個可審核的成本 ledger：

$$
\boxed{
\text{Difficulty}
\rightsquigarrow
\text{resource- and phase-resolved cost structure}.
}
$$

---

# 2. 任務、世界與資訊狀態

本文承接 Paper 01 的任務契約：

$$
\mathfrak T
=
(\mathcal X,\mathcal Y,\mathsf{Goal},\mathsf{Ver},\mathsf{Cert},\equiv_{\mathfrak T},\mathcal I_{\mathrm{adm}}).
$$

## 2.1 Completion worlds

**D2.1（completion world）**  
對實例 $x$，令 $\Omega_x$ 為所有符合 public task description、generator promise、已知物理／數學規則與合法外部資訊契約的可能世界集合。

智能體在時間 $t$ 的資訊狀態記為 $z_t$。令：

$$
\boxed{
\mathcal K(z_t)
=
\{\omega\in\Omega_x:\omega\text{ 與 }z_t\text{ 相容}\}
}
$$

稱為當前 **completion set**。

它不必是 Bayesian posterior；它首先是一個可能性集合。若研究另有 probability model $\mu$，可再定義：

$$
\mu(\omega\mid z_t),
\qquad \omega\in\mathcal K(z_t).
$$

## 2.2 Information closure

**D2.2（合法資訊閉包）**  
令 $\mathsf{Info}(z_t)$ 為智能體在契約下可合法使用的 observation、memory、tool output、query response、proof artifact、provenance record 與 public prior 的閉包。

不得把：

- hidden benchmark truth；
- 未授權 oracle；
- 未記帳 human intervention；
- 未揭露 precomputation；
- test-time leakage

自動放入 $\mathsf{Info}(z_t)$。

---

# 3. Primitive-event cost ledger

六相成本若直接從 wall-clock time 估計，容易重複計費。例如 tool call 同時具有 communication time、execution time 與 verification time。本文先建立 primitive ledger，再做 phase attribution。

## 3.1 Primitive events

**D3.1（primitive cost event）**  
一次完整 task trace 表示為：

$$
\tau=(e_1,e_2,\ldots,e_m),
$$

每個 $e_j$ 是不可再拆或研究者選擇不再拆的可計費事件。每個事件具有 $d$ 維資源成本：

$$
\mathbf c(e_j)\in\mathbb R_+^d.
$$

例如：

$$
\mathbf c(e_j)
=
(c_T,c_E,c_M,c_Q,c_C,c_{\mathrm{comm}},c_{\mathrm{risk}},\ldots).
$$

## 3.2 Phase label

定義 phase 集：

$$
\boxed{
\mathcal P
=
\{R,D,C,E,V,\mathrm{Cert},O\}
}
$$

其中 $O$ 為 shared overhead / metareasoning / coordination account。

phase labeling function：

$$
\phi:e_j\mapsto\mathcal P.
$$

每個 primitive event 在一次 accounting pass 中**只能有一個主歸屬 phase**。若研究需要 fractional attribution，必須事先定義權重 $w_{j,p}\ge0$ 且：

$$
\sum_{p\in\mathcal P}w_{j,p}=1.
$$

## 3.3 Ledger conservation theorem

**T3.1（成本 ledger 守恆）**  
若所有 primitive events 均被唯一歸屬或以 partition-of-unity fractional attribution 歸屬，則：

$$
\boxed{
\mathbf C_{\mathrm{total}}(\tau)
=
\sum_{p\in\mathcal P}\mathbf C_p(\tau)
}
$$

其中：

$$
\mathbf C_p(\tau)
=
\sum_j w_{j,p}\mathbf c(e_j).
$$

**證明。** 交換有限求和順序：

$$
\sum_p\mathbf C_p
=
\sum_p\sum_j w_{j,p}\mathbf c(e_j)
=
\sum_j\left(\sum_p w_{j,p}\right)\mathbf c(e_j)
=
\sum_j\mathbf c(e_j)
=
\mathbf C_{\mathrm{total}}.
\qquad\square
$$

此定理的目的不是數學深度，而是阻止 empirical paper 在 phase decomposition 中「一份成本算兩次」或「不利成本消失」。

---

# 4. 六相認知成本

以下六類是 canonical phase labels，不表示所有任務必須經過六相，也不表示 phase 必須線性排列。

## 4.1 Representation Cost $C_R$

**D4.1**  
$C_R$ 是將原始問題轉換為智能體可操作表示的成本，包括：

- parsing；
- embedding / encoding；
- coordinate transform；
- state abstraction；
- quotient construction；
- ontology alignment；
- schema induction；
- task decomposition；
- lossless / declared-lossy compression。

若 representation 在多個 instances 間重用，其 build cost 不得隱藏，應進入 amortized accounting。

## 4.2 Discovery Cost $C_D$

**D4.2**  
$C_D$ 是從目前資訊狀態定位「哪條路徑／策略／候選值得採用」的成本，包括：

- search；
- exploration；
- experiment selection；
- observation acquisition；
- query allocation；
- hypothesis selection；
- policy discovery；
- navigation through solution space。

$C_D$ 對應早期 2.9 中最接近 $T_{search}$ 的部分，但本文把 representation 與 construction 另外拆出。

## 4.3 Construction Cost $C_C$

**D4.3**  
$C_C$ 是把已辨識的方向具體建造成可執行／可驗證 artifact 的成本，例如：

- proof generation；
- code synthesis；
- tool creation；
- data structure build；
- experiment apparatus construction；
- certificate generation；
- intermediate lemma construction。

Discovery 告訴我們「往哪裡走」；Construction 則支付「把那條路建出來」的成本。

## 4.4 Execution Cost $C_E$

**D4.4**  
$C_E$ 是已經選定 procedure / path 後，實際執行所需成本：

- arithmetic；
- simulation；
- program execution；
- physical actuation；
- matrix / tensor computation；
- data movement explicitly attributed to execution。

此 phase 最接近傳統工程上常說的 compute throughput，但不代表全部認知成本。

## 4.5 Verification Cost $C_V$

**D4.5**  
$C_V$ 是判定候選結果與其 evidence 是否滿足 task verifier 的成本：

$$
\mathsf{Ver}(x,y,e)=1.
$$

它可以包括：

- proof checking；
- test execution；
- constraint checking；
- independent recomputation；
- adversarial validation；
- consistency checking。

Verification 不等於 Certification。

## 4.6 Certification Cost $C_{\mathrm{Cert}}$

**D4.6**  
$C_{\mathrm{Cert}}$ 是把已存在 candidate + evidence 轉成指定 contract 下可提交 certified claim 的成本，包括：

- formal proof normalization；
- proof checker compatibility；
- provenance construction；
- signature / attestation；
- audit transcript generation；
- authority-policy compliance；
- zero-error completion-set checks；
- packaging / reproducibility checks explicitly demanded by the contract。

因此：

$$
\boxed{
C_V\neq C_{\mathrm{Cert}}
}
$$

一般不應假設兩者相等。

## 4.7 Shared overhead $C_O$

meta-reasoning、scheduler、coordination、memory maintenance 與 phase-switching overhead 若不能自然歸入六相，記入 $C_O$：

$$
\boxed{
\mathbf C_{\mathrm{total}}
=
\mathbf C_R+\mathbf C_D+\mathbf C_C+\mathbf C_E+\mathbf C_V+\mathbf C_{\mathrm{Cert}}+\mathbf C_O.
}
$$

若研究宣稱 $C_O=0$，必須說明理由；不得默認。

---

# 5. Truth–Evidence–Certification 三層 epistemic state

六相回答「成本花在哪裡」；本節回答「智能體現在到底擁有什麼 epistemic status」。

## 5.1 Truth

**D5.1（Truth）**  
對固定任務契約 $\mathfrak T$，候選 $y$ 的 truth / correctness status 定義為：

$$
\boxed{
\theta_{\mathfrak T}(x,y)
=
\mathbf 1[\mathsf{Goal}(x,y)]
}
$$

或在 stochastic / physical task 中使用預先聲明的 truth functional。

Truth 是 task semantics 的屬性，不因智能體「相信」而改變。

## 5.2 Evidence

**D5.2（Evidence）**  
令 $e$ 為合法資訊閉包中的 artifact。若：

$$
\mathsf{Ver}(x,y,e)=1,
$$

則稱 $e$ 對 claim $(x,y)$ 是 contract-admissible supporting evidence。

令：

$$
\mathcal E_t(x,y)
=
\{e\in\mathsf{Info}(z_t):\mathsf{Ver}(x,y,e)=1\}.
$$

注意：

$$
\theta(x,y)=1
$$

不推出：

$$
\mathcal E_t(x,y)\neq\varnothing.
$$

## 5.3 Certification

**D5.3（Certification）**  
給定 certification contract $\kappa$，定義：

$$
\boxed{
\mathsf{Cert}_{\kappa}(x,y,e,a)=1
}
$$

表示 claim、evidence、attestation / authority object $a$ 通過 $\kappa$ 的所有要求。

例如 $\kappa$ 可以要求：

- proof checker acceptance；
- signature；
- provenance chain；
- independent witness；
- reproducible transcript；
- zero unsupported claims；
- specified error bound；
- specified authority scope。

因此 Evidence 與 Certification 再次分離：

$$
\boxed{
\mathcal E_t(x,y)\neq\varnothing
\not\Rightarrow
\exists e,a:\mathsf{Cert}_{\kappa}(x,y,e,a)=1.
}
$$

---

# 6. Epistemic state lattice

定義最小 epistemic state：

$$
\eta_t(x,y)
=
(T,E,C)
\in\{0,1\}^3,
$$

其中：

$$
T=\theta(x,y),
$$

$$
E=\mathbf 1[\mathcal E_t(x,y)\neq\varnothing],
$$

$$
C=\mathbf 1[\exists e,a:\mathsf{Cert}_{\kappa}(x,y,e,a)=1].
$$

在 sound verifier / certifier contract 下，部分狀態被排除；例如 perfect soundness 下：

$$
C=1\Rightarrow E=1\Rightarrow T=1.
$$

但若 verifier / certifier 有 error，這些 implication 必須改寫成 probabilistic soundness statements。

## 6.1 三個最重要的合法狀態

### True but unsupported

$$
\boxed{(T,E,C)=(1,0,0)}
$$

例：智能體幸運猜中答案，但沒有合法證據。

### Evidenced but uncertified

$$
\boxed{(T,E,C)=(1,1,0)}
$$

例：具有有效 proof artifact，但尚未轉換成指定 checker format、缺 provenance 或沒有 contract-required attestation。

### Certified

在 perfect soundness contract 下：

$$
\boxed{(T,E,C)=(1,1,1)}.
$$

這三個狀態是 SDPE-BEB Truth–Evidence–Certification 分離在 UCPNP 中的抽象化。

---

# 7. Certification soundness 與 scope

## 7.1 Soundness

**D7.1（$\varepsilon$-sound certifier）**  
certifier $\mathcal C_{\kappa}$ 為 $\varepsilon$-sound，若：

$$
\Pr[
\mathsf{Cert}_{\kappa}=1
\wedge
\theta=0
]
\le\varepsilon.
$$

當 $\varepsilon=0$ 時稱 zero-error / perfectly sound。

## 7.2 Scope

certification 永遠相對於 claim language 與 policy scope $\mathcal L_{\kappa}$。

**T7.1（Certification Scope Theorem）**  
即使 $\mathsf{Cert}_{\kappa}(q)=1$，也只能對 $q\in\mathcal L_{\kappa}$ 及 $\kappa$ 明示閉包規則下的 consequences 提供 certification support；不能自動推出 scope 外命題 $r$。

形式上，若：

$$
r\notin\mathrm{Cl}_{\kappa}(q),
$$

則：

$$
\mathsf{Cert}_{\kappa}(q)=1
\not\Rightarrow
\mathsf{Cert}_{\kappa}(r)=1.
$$

**證明。** 由 certification contract 的 domain restriction 直接成立。若能推出 scope 外 $r$，則 $r$ 已隱含成為 $\mathrm{Cl}_{\kappa}$ 的一部分，與假設矛盾。$\square$

這是下列原則的形式版本：

$$
\boxed{
\text{Claim scope}
\le
\text{evidence / certification scope}.
}
$$

---

# 8. 2.9 的 coarse $3\times3$ process–epistemic matrix

為保留舊動態速率 2.9 的直覺，先使用 coarse process phases：

$$
\mathcal P_3
=
\{\mathsf{Search},\mathsf{Execute},\mathsf{Verify}\}.
$$

與 epistemic layers：

$$
\mathcal E_3
=
\{\mathsf{TruthAccess},\mathsf{Evidence},\mathsf{Certification}\}.
$$

定義 incidence：

$$
M_{ij}=1
$$

表示 process $i$ 在某些合法 task contract 下可以改變 epistemic coordinate $j$；$M_{ij}=0$ 表示在本文 canonical semantics 下該 phase 本身不具有此 authority。

一個保守的 canonical coarse matrix 為：

| Process | Truth access / candidate status | Evidence state | Certification state |
|---|---:|---:|---:|
| Search / Discovery | 1 | 1 | 0 |
| Execute | 1 | 1 | 0 |
| Verify / Assure | 0* | 1 | 1* |

其中 `*` 代表需進一步解釋：

- Verification 不創造 objective truth；它只增加對 truth 的可判定／可支持狀態；
- Verification 只有在 certification contract 把 verifier acceptance 視為足夠條件時，才能直接造成 certified state；否則仍需獨立 $C_{\mathrm{Cert}}$。

因此 $3\times3$ 矩陣是一個**認知作用圖**，不是「每格都等價」的代數矩陣。

---

# 9. Refined $6\times3$ cost–epistemic incidence matrix

六相模型可以更細地表示哪些 phase 通常能改變哪些 epistemic coordinates。

| Phase | Truth / candidate access | Evidence accumulation | Certification transition |
|---|---:|---:|---:|
| $R$ Representation | indirect | indirect | 0 |
| $D$ Discovery | direct | direct | 0 |
| $C$ Construction | direct | direct | indirect |
| $E$ Execution | direct | direct / trace | 0 |
| $V$ Verification | no truth creation | direct | contract-dependent |
| $\mathrm{Cert}$ Certification | no truth creation | evidence normalization | direct |

此表不是 universal empirical law。它是 canonical semantic guardrail：

1. $R$ 不能因為改寫表示就改變原任務 truth；
2. $D$ 可以取得候選與觀察，因此可能增加 truth access 與 evidence；
3. $C$ 可以建造 result / proof / certificate precursor；
4. $E$ 可以把已知 procedure 實現並產生 trace；
5. $V$ 判定 evidence 是否支持 claim；
6. $\mathrm{Cert}$ 把支持狀態轉成指定制度／形式契約下的可提交狀態。

---

# 10. Information obstruction：算力不能創造缺失資訊

這是 Paper 02 最重要的形式結果之一。

## 10.1 Indistinguishable worlds

**D10.1**  
對資訊狀態 $z$，若 $\omega_0,\omega_1\in\mathcal K(z)$，且任何不新增 observation / external information 的 admissible internal computation 都不能區分兩者，稱其對當前智能體 **computationally observationally equivalent**：

$$
\omega_0\equiv_z\omega_1.
$$

## 10.2 Zero-error information obstruction theorem

**T10.1（資訊阻塞定理）**  
若存在：

$$
\omega_0,\omega_1\in\mathcal K(z)
$$

滿足：

$$
\omega_0\equiv_z\omega_1,
$$

但其合法 zero-error outputs 集合互斥：

$$
Y^*(\omega_0)\cap Y^*(\omega_1)=\varnothing,
$$

則任何從 $z$ 出發、且不新增外部資訊的 deterministic internal-computation policy 都不能保證 zero-error completion。

**證明。** 由 $\omega_0\equiv_z\omega_1$，policy 在兩個世界看到相同資訊歷史，因此輸出相同 $y$。但合法答案集合互斥，故 $y$ 至少在其中一個世界錯誤。$\square$

### Corollary 10.1

增加純內部 execution throughput：

$$
H\uparrow
$$

若不改變 $\mathsf{Info}(z)$、observation channel、representation distinction 或 admissible oracle，則不能消除上述 zero-error obstruction。

這是「算力補償謬誤」的一個有限資訊、可證版本。

## 10.3 Randomized version

若要求 success probability 而非 zero-error，randomization 可以改變 expected performance，但它仍不能憑空取得兩世界間不存在的資訊。其最優 success rate 受 prior / minimax contract 限制，而不是由內部 FLOPS 無限增長自動趨近 $1$。

---

# 11. Evidence obstruction：真答案不能替代證據

**T11.1（Evidence Obstruction）**  
若：

$$
\theta(x,y)=1
$$

但：

$$
\mathcal E_t(x,y)=\varnothing,
$$

且 certification contract $\kappa$ 要求至少一個 $e\in\mathcal E_t(x,y)$，則不能只由 truth status 推出 certified completion：

$$
\theta(x,y)=1
\not\Rightarrow
C=1.
$$

**證明。** $\kappa$ 的 acceptance predicate 明確要求存在 evidence；在 evidence set 為空時 existential condition 為假。$\square$

這涵蓋：

- lucky guess；
- model answer without trace under a trace-required contract；
- theorem statement correct but proof unavailable；
- experimental result correct but provenance absent。

---

# 12. Certification obstruction：證據不能替代認證契約

**T12.1（Certification Obstruction）**  
若存在有效 evidence：

$$
\mathcal E_t(x,y)\neq\varnothing,
$$

但所有 admissible $(e,a)$ 均不滿足：

$$
\mathsf{Cert}_{\kappa}(x,y,e,a)=1,
$$

則目前 state 是 evidenced-but-uncertified：

$$
(T,E,C)=(1,1,0)
$$

在 sound verifier 情況下，且必須支付額外 $C_{\mathrm{Cert}}$ 或改變 admissible authority / artifact 才可能進入 certified state。

典型原因：

- proof format 不兼容；
- 缺 signature；
- 缺 provenance；
- contract 要求 independent replication；
- evidence scope 比 claim scope 窄；
- proof checker 未接受；
- safety policy 與 evidence 無法對接。

---

# 13. Phase non-substitutability

上述三類 obstruction 說明六相成本不是任意可替代貨幣。

## 13.1 No universal scalar substitution

**T13.1（無普適線性 scalarization 的可行性保持）**  
當資源維度 $d\ge2$ 時，不存在一組固定且有限的正權重 $\alpha_i>0$，使單一標量

$$
S_{\alpha}(\mathbf c)=\sum_i\alpha_i c_i
$$

對**所有**成本向量 $\mathbf c$ 與 componentwise 預算 $\mathbf B$ 都能以某個只依 $\mathbf B$ 的 scalar threshold 完全等價地判定：

$$
\mathbf c\preceq\mathbf B.
$$

**證明。** 只需考慮兩維。固定任意 $\alpha_1,\alpha_2>0$ 與預算 $\mathbf B=(1,1)$。令

$$
\mathbf c^{(1)}=(1+\varepsilon,0),
\qquad
\mathbf c^{(2)}=(0,1+\delta),
$$

兩者都 componentwise infeasible。另一方面存在大量 feasible vectors $\mathbf f=(u,v)$、$0\le u,v\le1$，其 scalar 值可大於其中一個 infeasible vector；例如令 $\varepsilon>0$ 足夠小並取 $\mathbf f=(1,1)$，則

$$
S_{\alpha}(\mathbf f)=\alpha_1+\alpha_2
>
\alpha_1(1+\varepsilon)=S_{\alpha}(\mathbf c^{(1)})
$$

只要 $\varepsilon<\alpha_2/\alpha_1$。因此不存在單一 threshold 能同時把所有 feasible vectors 與所有 infeasible vectors 依此 fixed scalar 完全分離。$\square$

這個結果不是說 scalar utility 沒有用途，而是說它需要被明示為研究者／智能體的 utility choice。對 UCPNP 的 feasibility 判定，componentwise budget、Pareto frontier 與 information/certification constraints 不能被一個固定權重總分普遍取代。

---

# 14. Representation 與 precomputation 的攤銷守恆

representation / memory compilation 的價值常表現在「前期很貴、後期便宜」。若忽略 build cost，就會製造假的 P-like transition。

## 14.1 Build-use decomposition

令 reusable structure $g$ 的建造成本為：

$$
\mathbf C_{\mathrm{build}}(g),
$$

instance $i$ 使用它的增量成本為：

$$
\mathbf C_{\mathrm{use}}(x_i\mid g).
$$

對 $n$ 個 instances，總成本：

$$
\boxed{
\mathbf C^{(n)}(g)
=
\mathbf C_{\mathrm{build}}(g)
+
\sum_{i=1}^n\mathbf C_{\mathrm{use}}(x_i\mid g).
}
$$

平均攤銷成本：

$$
\boxed{
\overline{\mathbf C}^{(n)}(g)
=
\frac{\mathbf C_{\mathrm{build}}(g)}{n}
+
\frac1n\sum_{i=1}^n\mathbf C_{\mathrm{use}}(x_i\mid g).
}
$$

## 14.2 Amortization theorem

**T14.1（Precomputation Conservation）**  
若比較 protocol 要求 total-lifecycle accounting，則任何 reusable preprocessing / representation / compiled memory 的成本不能因 test-time lookup 近似 $O(1)$ 而被刪除；它只能被一次計費或依事先聲明規則攤銷。

**證明。** 由 ledger conservation，build events 已發生且資源已消耗。將其從 test trace 移到 precomputation phase 不會令 primitive cost 消失。$\square$

這條對未來比較：

- 人類教育；
- AI pretraining；
- retrieval index；
- theorem database；
- compiled proof graph；
- world model；
- ASI long-term memory

尤其重要。

---

# 15. Projection theorem：忽略成本只能讓系統看起來更容易

給定完整資源向量：

$$
\mathbf c\in\mathbb R_+^d,
$$

令 $P_J$ 為保留 coordinates $J\subseteq\{1,\ldots,d\}$ 的 projection。

**T15.1（Projection Optimism）**  
若：

$$
\mathbf c\preceq\mathbf B,
$$

則：

$$
P_J\mathbf c\preceq P_J\mathbf B.
$$

反向不成立。

因此若研究只量 wall-clock time、忽略 memory / communication / precomputation / evidence / certification，得到的 tractability classification 至多是完整模型的**樂觀投影**。

換句話說：

$$
\boxed{
\text{projected feasible}
\not\Rightarrow
\text{fully accounted feasible}.
}
$$

---

# 16. Completion / Verification / Certification 三條 frontier

Paper 01 定義 completion 與 verification frontier；本文加入 certification frontier。

令：

$$
\mathcal F_C(x\mid\Xi),
\qquad
\mathcal F_V(x\mid\Xi),
\qquad
\mathcal F_{\mathrm{Cert}}(x\mid\Xi,\kappa)
$$

分別為 completion、verification、certification 的 Pareto-minimal resource vectors。

定義 normalized bottleneck ratios：

$$
\rho_C
=
\inf_{\mathbf c\in\mathcal F_C}
\max_i\frac{c_i}{B_i},
$$

$$
\rho_V
=
\inf_{\mathbf c\in\mathcal F_V}
\max_i\frac{c_i}{B_i},
$$

$$
\boxed{
\rho_{\mathrm{Cert}}
=
\inf_{\mathbf c\in\mathcal F_{\mathrm{Cert}}}
\max_i\frac{c_i}{B_i}.
}
$$

這樣可以區分：

### Fully tractable

$$
\rho_C\le1.
$$

### Verification-easy but completion-hard

$$
\rho_V\le1<\rho_C.
$$

即 Paper 01 的 cognitive-NP-like。

### Evidence-easy but certification-hard

可能出現：

$$
\rho_V\le1,
\qquad
\rho_{\mathrm{Cert}}>1.
$$

### Certification-ready external artifact

若外部已提供完整 evidence + attestation，則 $\rho_{\mathrm{Cert}}$ 可很小；但其上游 construction / provenance cost 必須由 source accounting 承擔。

---

# 17. Cognitive asymmetry profile

不以一個 scalar 取代全部成本，而記錄 profile：

$$
\boxed{
\mathfrak A(x\mid\Xi,\mathbf B)
=
(\rho_R,\rho_D,\rho_C^{\mathrm{build}},\rho_E,\rho_V,\rho_{\mathrm{Cert}}).
}
$$

注意此處 $\rho_C^{\mathrm{build}}$ 使用 build / construction 語義，避免和 completion ratio $\rho_C$ 混淆；正式實作建議將 completion ratio 改記 $\rho_{\mathrm{comp}}$。

Paper 03 之後可研究：

- $\Sigma$ 型進步主要壓低哪些 coordinates；
- $\Gamma$ 型 representation change 是否先提高 $\rho_R$，再壓低 $\rho_D$ / $\rho_V$；
- multi-agent coordination 是否降低 discovery 但提高 communication / certification；
- historical hardware improvement 是否主要壓低 execution，而非 information obstruction。

---

# 18. Metareasoning：分配成本本身也有成本

智能體不只執行 object-level operations，還要決定「下一步值得做什麼」。這是 metareasoning。

令 meta-state 為 $s$、剩餘 budget 為 $b$，則可寫：

$$
V(s,b)
=
\max_{a\in\mathcal O(s)}
\mathbb E
\left[
R(s,a,s')
+
V(s',b-c(a))
\right].
$$

但求解或近似這個 Bellman policy 本身也消耗成本，因此：

$$
\boxed{
C_O
\supseteq
C_{\mathrm{meta}}.
}
$$

若一個理論宣稱「智能體永遠選擇最佳下一個 computation」，卻不記錄找到這個最佳 computation 的成本，就可能形成第二階 metareasoning regress。

本文暫不求 universal closure；在 controlled finite model 中可精確求解，在 open-world agent 中則應以 bounded / heuristic meta-policy 實驗處理。

---

# 19. 與 Proof-Carrying 思想的關係

在 proof-carrying code 中，不可信 producer 可以攜帶一個符合預先定義 safety policy 的 proof，而 host 只需執行相對簡單的 proof validation。這提供一個經典例子：

$$
\boxed{
\text{proof / certificate construction cost}
\neq
\text{proof checking cost}.
}
$$

UCPNP 不把 proof-carrying code 等同於一般認知 certification，但借用其結構性教訓：**將昂貴的生成工作移到 producer，並不能使成本消失；它改變了成本由誰支付、何時支付，以及 verifier 的 trust base。**

因此任何「AI 已經提供 certificate，所以人類驗證很便宜」的比較都必須問：

1. certificate 是誰建造的？
2. 建造成本在哪裡？
3. checker soundness / policy scope 是什麼？
4. proof artifact 是否與 claim 綁定？
5. 是否可重放？

---

# 20. SDPE-BEB 作為 controlled micro-model 的直接映射

本文不在這裡重述 SDPE-BEB v0.1–v1.0 全部技術細節，只記錄其對 UCPNP Paper 02 的方法論位置。

| UCPNP Paper 02 | SDPE-BEB micro-model |
|---|---|
| $C_R$ | task semantic normalization、posterior-state / quotient representation |
| $C_D$ | hidden-premise observation、query allocation、adaptive switching |
| $C_C$ | proof / counterexample / policy / certificate construction |
| $C_E$ | deterministic evaluator / strategy execution |
| $C_V$ | claim / witness checking |
| $C_{\mathrm{Cert}}$ | safe certification、receipt、transcript、signature、audit contract |
| Truth | hidden semantic truth |
| Evidence | observed premises / valid witness dependencies |
| Certification | zero-unsupported contract 下可提交 claim |

最重要的不是「SDPE-BEB 證明一般智能都如此」，而是它提供一個 **L2–L3 controlled mechanism existence proof**：

$$
\boxed{
\text{Truth}
\neq
\text{Evidence}
\neq
\text{Certification}
}
$$

可以在有限、可重放、可完全審核的環境中產生非平凡後果。

---

# 21. Counterexample suite

## 21.1 Lucky-answer counterexample

智能體隨機輸出正確 $y$：

$$
T=1,
\qquad
E=0,
\qquad
C=0.
$$

結論：accuracy realization 不等於 evidence possession。

## 21.2 Free-oracle counterexample

把 oracle answer 當 $C_D=0$，會製造假的 tractability gain。正確作法是：

$$
C_D^{\mathrm{agent}}
\downarrow,
$$

但新增：

$$
C_{\mathrm{Ask}}
+
C_{\mathrm{oracle-source}}
+
C_{\mathrm{verification}}
$$

或按研究契約明示 oracle 為 exogenous capability。

## 21.3 Hidden-pretraining counterexample

若模型在 pretraining 已見過 exact instance，test-time $C_D$ 可能近似 lookup。若研究問題是「從未知狀態發現」，則必須把 leakage / memorization 排除或標記；否則量到的是 recall，不是 discovery。

## 21.4 Representation-cheating counterexample

將 hard instance 映射成「附帶正確答案的表示」不是免費 representation improvement：answer embedding 必須記入 information / precomputation source。

## 21.5 Verification-is-certification counterexample

unit tests 全 pass 不等於 formal proof；formal proof valid 也不等於特定 regulator / protocol contract 已認證。$C_V$ 與 $C_{\mathrm{Cert}}$ 需分離。

## 21.6 Compute-compensates-information counterexample

hidden bit $b\in\{0,1\}$ 對內部 state 完全不可觀測，task 要輸出 $b$。若不允許 query，無論 execution throughput 多大，zero-error completion 皆不可能。這是 T10.1 的最小實例。

## 21.7 Evidence-scope overreach

證據只支持命題 $q$，智能體卻宣稱「因此整個領域理論正確」。若：

$$
r\notin\mathrm{Cl}_{\kappa}(q),
$$

則 certification 不得外推到 $r$。

## 21.8 Human-AI cost hiding

若 AI 找答案、人類驗證，不能只報「人類只花 10 分鐘」。完整系統成本至少要區分：

$$
C_D^{\mathrm{AI}},
C_E^{\mathrm{AI}},
C_V^{\mathrm{human}},
C_{\mathrm{comm}},
C_{\mathrm{Cert}}.
$$

---

# 22. Experimental protocol for Paper 05 and later agent studies

本文提供統一測量 schema。

## 22.1 Required fields

每次 run 至少記錄：

1. task contract hash / version；
2. agent / model / tool configuration；
3. available knowledge / memory policy；
4. representation supplied to agent；
5. external query policy；
6. resource budget vector；
7. primitive event ledger；
8. phase attribution rule；
9. candidate output；
10. evidence artifacts；
11. verification result；
12. certification result；
13. confidence / error contract；
14. precomputation / training / index provenance where relevant。

## 22.2 Minimum ablations

對同一 task family，至少比較：

$$
\text{base}
$$

$$
\text{base}+\text{memory}
$$

$$
\text{base}+\text{tools}
$$

$$
\text{base}+\text{representation transform}
$$

$$
\text{base}+\text{external search / ask}
$$

$$
\text{base}+\text{multi-agent}
$$

在可行時再分離：

$$
\Sigma\text{-gain}
\quad\text{vs.}\quad
\Gamma\text{-gain}.
$$

## 22.3 Do not overclaim

controlled task 上的 exact theorem 可以標 L2；完整 benchmark replication 可達 L3；跨模型／跨任務才進 L4。不得由單一 toy model 直接支持 ASI-level L7 claim。

---

# 23. 後續可研究的定量問題

本文留下以下 empirical / mathematical frontiers。

## C23.1 Phase elasticity

對 capability parameter $u$，研究：

$$
\epsilon_p
=
\frac{\partial\log C_p}{\partial\log u}.
$$

例如硬體提升對 $C_E$ 的 elasticity 是否遠高於對 $C_D$？

## C23.2 Representation return on cost

定義 representation transformation $g$ 的 lifecycle gain：

$$
G_R^{(n)}(g)
=
\frac{
\sum_{i=1}^n C_{\mathrm{downstream}}(x_i\mid\text{old})
-
\sum_{i=1}^n C_{\mathrm{downstream}}(x_i\mid g)
}{
C_{\mathrm{build}}(g)
}.
$$

當：

$$
G_R^{(n)}(g)>1
$$

時，representation build 在該 horizon 上產生正 lifecycle return。

## C23.3 Evidence amplification

研究一個 artifact $e$ 能支持多少 claims：

$$
A_E(e)
=
|\mathrm{Cl}_{\kappa}(e)|
$$

以及這個 closure 是否因 proof language / checker / ontology 改變而增加。

## C23.4 Certification bottleneck transition

未來強 AI 可能出現：

$$
C_D,C_C,C_E\downarrow
$$

但：

$$
C_V,C_{\mathrm{Cert}}
$$

成為主瓶頸。這不是本文 theorem，而是後續 agent / historical research 的重要 empirical hypothesis。

---

# 24. 與既有外部研究的定位

本文與三類既有研究相鄰但不等同。

第一，bounded optimality 將 agent quality 約束在其 computational architecture 與 task environment 中，這與 Paper 01 的 agent-relative feasibility 接近。

第二，resource-rational / metareasoning 研究有限資源下如何選擇 computation、decomposition 與 planning procedure，對本文的 $C_D$、$C_O$ 與 representation accounting 有直接方法論關聯。

第三，proof-carrying code 顯示 proof construction 與 proof checking 可以被明確拆開，且 checker 可以根據預先定義 policy 驗證不可信 producer 所提供的 proof。本文將此視為 $C_C/C_V/C_{\mathrm{Cert}}$ 分離的一個經典計算系統案例，而不是將 PCC 當成一般智能認識論的同義詞。

UCPNP Paper 02 的新增研究對象是把上述元素與：

- historical state；
- knowledge / memory；
- representation change；
- external information；
- Truth–Evidence–Certification；
- agent-relative tractability

放入同一個顯式 cost-and-evidence ledger。

---

# 25. 內部理論譜系

本文的主要內部依賴順序：

$$
\boxed{
\text{Dynamic Rate 2.9}
\rightarrow
\text{UCPNP Paper 00}
\rightarrow
\text{Paper 01}
\rightarrow
\text{Paper 02}
}
$$

並以 SDPE-BEB v0.1–v1.0 作為後續 Paper 05 的 controlled micro-model。

本文刻意不繼承早期任何未經獨立 audit 的 classical $P=NP$ / $P\neq NP$ proof claim。

---

# 26. 本文定理／定義清單

## Definitions

- D2.1 Completion World；
- D2.2 Legal Information Closure；
- D3.1 Primitive Cost Event；
- D4.1–D4.6 六相成本；
- D5.1 Truth；
- D5.2 Evidence；
- D5.3 Certification；
- D7.1 $\varepsilon$-sound certifier。

## Theorems

- T3.1 Ledger Conservation；
- T7.1 Certification Scope；
- T10.1 Zero-error Information Obstruction；
- T11.1 Evidence Obstruction；
- T12.1 Certification Obstruction；
- T13.1 No Universal Phase Substitution；
- T14.1 Precomputation Conservation；
- T15.1 Projection Optimism。

這些 theorem 都是在本文明示 contract 下成立的形式結果；不是關於人類、AI 或 ASI 實際行為的普遍經驗定律。

---

# 27. 正典結論

本文把 Neo.K 終極認知 P/NP 的第二個核心模組固定為兩條互補軸。

第一條是**成本軸**：

$$
\boxed{
R
\rightarrow
D
\rightarrow
C
\rightarrow
E
\rightarrow
V
\rightarrow
\mathrm{Cert}
}
$$

但此箭頭不是強制線性 pipeline；智能體可回返、並行、跳躍或重構。

第二條是**epistemic 軸**：

$$
\boxed{
\text{Truth}
\neq
\text{Evidence}
\neq
\text{Certification}.
}
$$

兩條軸交叉後，得到一個比「會不會解」更細緻的智能計算狀態空間。

本文最核心的三個 obstruction 是：

$$
\boxed{
\text{Computation}
\not\Rightarrow
\text{Missing Information}
}
$$

$$
\boxed{
\text{Truth}
\not\Rightarrow
\text{Evidence}
}
$$

$$
\boxed{
\text{Evidence}
\not\Rightarrow
\text{Certification}.
}
$$

因此，未來比較人類、AI、多 AI、後人類或 ASI 時，不能只問：

> 每秒能做多少運算？

而至少要問：

> 它是否取得了必要資訊？使用什麼 representation？如何找到候選？如何建造解法？執行花多少成本？證據是否充分？誰能驗證？在什麼 contract 下可以認證？哪些成本其實在訓練、歷史或外部系統中提前支付？

這些問題共同構成 UCPNP 後續可實驗、可歷史回測、可形式化的成本語言。

---

# 參考文獻

## External primary / canonical research

1. Russell, S. J., & Subramanian, D. (1995). *Provably Bounded-Optimal Agents*. arXiv:cs/9505103.
2. Correa, C. G., Ho, M. K., Callaway, F., & Griffiths, T. L. (2020). *Resource-rational Task Decomposition to Minimize Planning Costs*. arXiv:2007.13862.
3. Necula, G. C. (1997). *Proof-Carrying Code*. Proceedings of POPL '97, pp. 106–119. DOI: 10.1145/263699.263712.

## Internal canonical lineage

4. Neo.K. *動態速率理論與 P vs. NP 問題的結構連續模型 2.0：一種認知與數學整合框架（完整修正版）*.
5. Neo.K. *P vs. NP 問題的動態可解性理論 2.5：計算機歷史的實證框架*.
6. Neo.K. *動態速率理論 2.9：認知與計算的解耦——P vs. NP 問題的終極動力學解構*.
7. Neo.K with Aletheia. *The Neo.K Ultimate Cognitive P/NP Problem: Canonical Definition, Scope, and Research Program* (Paper 00, v0.1).
8. Neo.K with Aletheia. *Agent-Relative Tractability: Formalizing Cognitive-P-like and Cognitive-NP-like Operational Regimes* (Paper 01, v0.1).
9. Neo.K with Aletheia. *SDPE-BEB v1.0.0 — Proof-Carrying Bellman Certification & Exact Q21 Closure*.

---

# Appendix A. Canonical symbol table

| Symbol | Meaning |
|---|---|
| $\mathfrak T$ | task semantics contract |
| $\Omega_x$ | completion worlds for instance $x$ |
| $\mathcal K(z)$ | worlds compatible with current information state |
| $\mathsf{Info}(z)$ | legal information closure |
| $\mathcal P$ | phase set |
| $C_R$ | representation cost |
| $C_D$ | discovery cost |
| $C_C$ | construction cost |
| $C_E$ | execution cost |
| $C_V$ | verification cost |
| $C_{\mathrm{Cert}}$ | certification cost |
| $C_O$ | shared overhead / metareasoning cost |
| $\theta(x,y)$ | truth/correctness predicate |
| $\mathcal E_t(x,y)$ | admissible evidence set |
| $\mathsf{Cert}_{\kappa}$ | certification predicate under contract $\kappa$ |
| $\eta=(T,E,C)$ | minimal epistemic state |
| $\mathcal F_C$ | completion Pareto resource frontier |
| $\mathcal F_V$ | verification Pareto resource frontier |
| $\mathcal F_{\mathrm{Cert}}$ | certification Pareto resource frontier |
| $\rho_C$ | completion normalized bottleneck ratio |
| $\rho_V$ | verification normalized bottleneck ratio |
| $\rho_{\mathrm{Cert}}$ | certification normalized bottleneck ratio |

---

# Appendix B. Evidence-level status

本文建議所有後續 UCPNP experiments 對 regime claims 附加：

- **Proven / exact**：具有 exhaustive proof、lower bound、indistinguishability certificate、formal verifier 或等價保證；
- **Empirical / observed**：在已測 agents / policies / seeds / tasks 下成立；
- **Unresolved**：尚無充分證據支持 existence 或 non-existence。

不得將第二項或第三項自動改寫成第一項。

