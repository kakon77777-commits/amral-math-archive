# UCPNP Paper 02 Release Pack v0.1

Contents:

- `02_UCPNP_Cognitive_Cost_and_Epistemic_Certification_Matrix_v0.1.md` — canonical paper source.
- `02_UCPNP_Claim_Matrix_v0.1.md` — D/T/C/E/N claim typing and non-claims.
- `DEPENDENCY_HASHES.json` — SHA-256 bindings to Paper 00 and Paper 01 used as canonical parents.
- `SOURCE_INTEGRITY_REPORT_v0.1.json` — UTF-8, control-byte, CRLF, math-delimiter and checksum gate.

Canonical mathematical delimiters are `$...$` and `$$...$$` only.

This paper is about Neo.K's UCPNP framework and does not assert a solution to the classical $P$ versus $NP$ problem.
