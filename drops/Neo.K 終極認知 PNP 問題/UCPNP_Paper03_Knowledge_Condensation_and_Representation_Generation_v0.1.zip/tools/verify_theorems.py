from fractions import Fraction


def check_mixed_identity():
    # vector-valued exact identity for arbitrary integer examples
    examples = [
        ((10, 20, 30), (7, 19, 28), (8, 14, 31), (4, 11, 25)),
        ((100, 2), (90, 3), (70, 1), (50, 2)),
        ((5,), (5,), (4,), (3,)),
    ]
    for c00, c10, c01, c11 in examples:
        e_sigma = tuple(a-b for a,b in zip(c00,c10))
        e_gamma = tuple(a-b for a,b in zip(c00,c01))
        inter = tuple(b+c-a-d for a,b,c,d in zip(c00,c10,c01,c11))
        lhs = tuple(a-d for a,d in zip(c00,c11))
        rhs = tuple(a+b+c for a,b,c in zip(e_sigma,e_gamma,inter))
        assert lhs == rhs, (lhs, rhs)


def check_break_even():
    cases = [
        (Fraction(10), Fraction(3), 4),
        (Fraction(9), Fraction(3), 4),
        (Fraction(1), Fraction(2), 1),
        (Fraction(0), Fraction(5), 1),
        (Fraction(7,2), Fraction(1,2), 8),
    ]
    for b, s, expected in cases:
        n_star = int(b // s) + 1
        assert n_star == expected, (b,s,n_star,expected)
        assert n_star*s - b > 0
        if n_star > 1:
            assert (n_star-1)*s - b <= 0


def check_nonidentifiability_constructive():
    # Same observed costs can be produced by pure Sigma, pure Gamma, or mixed intervention.
    baseline = Fraction(2)
    sigma_after = Fraction(1)
    gamma_after = Fraction(1)
    mixed_after = Fraction(1)
    assert (baseline, sigma_after) == (baseline, gamma_after) == (baseline, mixed_after)


def check_sdpe_proxy_arithmetic():
    quotient_ratio = Fraction(3066025, 699847)
    quotient_reduction = 1 - Fraction(699847, 3066025)
    assert 4.38 < float(quotient_ratio) < 4.39
    assert 0.771 < float(quotient_reduction) < 0.772

    pruning_fraction = Fraction(7512427, 15722611)
    assert 0.477 < float(pruning_fraction) < 0.479


def main():
    check_mixed_identity()
    check_break_even()
    check_nonidentifiability_constructive()
    check_sdpe_proxy_arithmetic()
    print('UCPNP Paper 03 theorem/arithmetic checks: PASS')


if __name__ == '__main__':
    main()
