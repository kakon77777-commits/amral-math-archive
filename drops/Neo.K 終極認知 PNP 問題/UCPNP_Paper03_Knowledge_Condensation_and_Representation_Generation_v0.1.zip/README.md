# UCPNP Paper 03 v0.1 Release Pack

This package contains the canonical v0.1 draft of Paper 03 in the Neo.K Ultimate Cognitive P/NP series.

## Main contribution

Paper 03 replaces scalar-like $\Sigma$ / $\Gamma$ language with two lifecycle, multi-resource frontier-valued objects:

- $\boldsymbol\Sigma$: reusable validated structure gains under a fixed operational representation class;
- $\boldsymbol\Gamma$: gains from nontrivial semantics-preserving representation changes.

It introduces:

- task-semantic vs operational-representation equivalence;
- exact separation examples;
- performance-only non-identifiability;
- $2\times2$ mixed-intervention attribution;
- lifecycle build/use accounting;
- context-dependent scalar projections only;
- SDPE-BEB v0.7–v1.0 proxy calibration.

## Canonical dependencies

- Paper 00 v0.1
- Paper 01 v0.1
- Paper 02 v0.1
- Paper 05 v0.1

Hashes are recorded in `DEPENDENCIES.sha256`.
