import csv, json
from pathlib import Path
base=Path(__file__).parent
rows=list(csv.DictReader((base/"E01_Batch03_Phase_Matrix_v0.1.csv").open(encoding="utf-8")))
assert len(rows)==4
assert {r["case_id"] for r in rows}=={
    "G_Coppersmith_Winograd","H_DeepBlue","I_CompCert","J_Google_PageRank"
}

cw=next(r for r in rows if r["case_id"]=="G_Coppersmith_Winograd")
assert "UNRESOLVED" in cw["Y_E_S0"]
assert "Practicality-Unresolved" in cw["signature"]

db=next(r for r in rows if r["case_id"]=="H_DeepBlue")
assert "H + M" in db["mechanism"]
assert "hardware" in db["stress_test"].lower()

cc=next(r for r in rows if r["case_id"]=="I_CompCert")
assert "Certification-Frontier" in cc["signature"]

g=next(r for r in rows if r["case_id"]=="J_Google_PageRank")
assert "Offline-Precomputation" in g["signature"]

assert len({r["signature"] for r in rows})==4

p=json.loads((base/"E01_Batch03_Evidence_Passports_v0.1.json").read_text(encoding="utf-8"))
assert len(p["passports"])==7
assert any(x["reproduction_status"]=="unresolved" for x in p["passports"])
assert any("hardware-only" in x.get("uncertainty","") for x in p["passports"])

print("UCPNP E01 Batch03 consistency checks: PASS")
