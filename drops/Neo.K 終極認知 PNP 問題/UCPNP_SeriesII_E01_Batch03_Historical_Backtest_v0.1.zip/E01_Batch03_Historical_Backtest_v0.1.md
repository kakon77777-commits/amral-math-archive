# UCPNP Series II — E01 Historical Cognitive Backtest Corpus
## Batch 03：Coppersmith–Winograd、IBM Deep Blue、CompCert、Google/PageRank

**Series:** Neo.K Ultimate Cognitive P/NP — Series II Experiments  
**Experiment:** E01 — Historical Cognitive Backtest Corpus  
**Batch:** 03  
**Version:** v0.1  
**Author:** Neo.K  
**Collaborative analysis:** Aletheia  
**Date:** 2026-08-16  
**Status:** Historical/documentary backtest. The batch deliberately tests asymptotic-vs-practical gaps, hardware-amplified search, formal certification, and offline-precomputation/online-query separation.

---

# 0. Batch 03 purpose

Batch 01–02 已經產生六種 signatures，但仍主要來自「最後形成成功方法」的歷史。

Batch 03 專門測四個新問題：

1. **理論 asymptotic improvement 是否等於有限規模 practicality？**
2. **硬體大幅提升時，能否把方法／knowledge support 分離？**
3. **formal verification 是否主要移動 certification frontier，而不是 raw capability frontier？**
4. **大量 offline build 是否能讓 online query 看起來極便宜，並且必須依 lifecycle accounting 還原成本？**

選取：

- Coppersmith–Winograd matrix multiplication；
- IBM Deep Blue；
- CompCert；
- Google / PageRank / inverted indexing。

---

# 1. Audit vocabulary

沿用：

- `UB(y)`：documented upper bound；
- `UNRESOLVED`：現有 evidence 不足；
- `NO-INFERENCE`：來源只支援較窄 claim，不允許自動外推；
- `PROXY`：UCPNP mechanism proxy，不宣稱完全同構。

本 Batch 特別禁止：

$$
\boxed{
\text{asymptotic improvement}
\Rightarrow
\text{finite practical dominance}
}
$$

以及：

$$
\boxed{
\text{fast online answer}
\Rightarrow
\text{low total lifecycle cost}.
}
$$

---

# 2. Case G — Coppersmith–Winograd matrix multiplication

## 2.1 Fixed task

固定：

> 對 $n\times n$ matrices 進行 matrix multiplication，研究其 arithmetic-operation asymptotic exponent。

Coppersmith 與 Winograd 的 1990 *Journal of Symbolic Computation* 論文明確說明：

> 提出一種 asymptotically accelerating matrix multiplication 的新方法，得到 exponent：

$$
\boxed{
\omega<2.376
}
$$

的當時結果。

因此：

$$
Y_D^{(\mathrm{asymptotic\ method})}
\le1990.
$$

---

## 2.2 What the source does and does not establish

原始來源明確證明的是：

$$
\boxed{
\text{asymptotic arithmetic exponent improvement}.
}
$$

它不是：

- finite-$n$ benchmark paper；
- hardware implementation report；
- wall-clock comparison；
- production numerical library study。

因此 Batch 03 刻意標：

$$
\boxed{
Y_E^{(\mathrm{practical})}
=
\mathrm{UNRESOLVED}
}
$$

而不是由：

$$
\omega=2.376
$$

推導：

> 1990 實機上已比 classical / Strassen methods 更快。

這不是宣稱它「不實用」。

這只是：

$$
\boxed{
\text{asymptotic theorem}
\not\Rightarrow
\text{documented finite-scale practical frontier}.
}
$$

---

## 2.3 Mechanism attribution

主要為：

$$
\boxed{
M+\Gamma_{\mathrm{candidate}}.
}
$$

- $M$：新的 algebraic algorithm；
- $\Gamma_{\mathrm{candidate}}$：使用 trilinear forms、tensor-like reformulation 與 arithmetic-progression combinatorics 重構 matrix multiplication 的有效表示。

但 $\Gamma$ 仍標 candidate。

---

## 2.4 Signature

$$
\boxed{
\textbf{Asymptotic-Theorem / Practicality-Unresolved}.
}
$$

這是 Series II 第一個刻意拒絕把 theoretical frontier 與 practical frontier 合併的案例。

---

# 3. Case H — IBM Deep Blue

## 3.1 Fixed task

固定：

> 在 standard tournament chess 條件下達到並擊敗當時 reigning World Chess Champion 的 chess-playing system capability。

Deep Blue 在 1997 年六局 rematch 擊敗 Garry Kasparov。

因此：

$$
Y_E^{(\mathrm{championship\ capability})}
\le1997.
$$

---

# 4. Hardware contribution

IBM 的 1999 *IEEE Micro* 論文記錄：

$$
\boxed{
480
}
$$

顆 custom chess chips 被用於 1997 Deep Blue，且這些 chips 提供了 Deep Blue 的大部分 computational power。

IBM 研究史料亦記錄其約可探索：

$$
\boxed{
200\text{ million chess positions / second}.
}
$$

因此 Deep Blue 是一個很強的：

$$
H\text{-type}
$$

案例。

但不能因此標成：

$$
H\text{-only}.
$$

---

# 5. Method and knowledge support

IBM 的完整 Deep Blue system paper 同時列出成功因素：

- single-chip chess search engine；
- massively parallel system with multiple levels of parallelism；
- search extensions；
- complex evaluation function；
- effective use of a Grandmaster game database。

因此更正確 attribution：

$$
\boxed{
H+M+\Sigma_{\mathrm{proxy}}.
}
$$

其中 Grandmaster game database / tuned evaluation knowledge 可以視為 $\Sigma$-like reusable knowledge support，但不宣稱它等同 Paper 03 的 exact $\Sigma$ measure。

---

# 6. Deep Blue phase vector

### Representation

computer-chess game tree / evaluation representation 早於 Deep Blue 很久。

Batch 03 不重建完整 Shannon-to-Deep-Blue chronology：

$$
Y_R=\mathrm{UNRESOLVED\ in\ this\ batch}.
$$

### Discovery / construction

Deep Blue specific system architecture 在 1995 ICS papers 已有公開 overview：

$$
Y_D^{(\mathrm{DeepBlue\ architecture})}
\le1995.
$$

### Execution

World Champion victory：

$$
Y_E\le1997.
$$

### Verification

match outcome 是外部公開 task verification：

$$
Y_V^{(\mathrm{match})}
\le1997.
$$

### Certification

沒有類似 CompCert 的 formal proof contract。

因此：

$$
Y_{\mathrm{Cert}}^{(\mathrm{formal})}
=
\mathrm{NOT\ APPLICABLE}.
$$

---

# 7. Deep Blue signature

$$
\boxed{
\textbf{Hardware-Amplified Search + Knowledge Support}.
}
$$

這個 case 的負面結論：

$$
\boxed{
\text{large }H
\not\Rightarrow
H\text{-only explanation}.
}
$$

---

# 8. Case I — CompCert

## 8.1 Fixed task

固定：

> 將 C source program 編譯成 target assembly / machine-oriented code，並對 compiler transformation 提供 machine-checked semantic-preservation guarantee。

ordinary C compilation 在 CompCert 前早已實用。

所以 CompCert 的核心 historical shift 不是：

$$
\text{first ability to compile C}.
$$

而是：

$$
\boxed{
\text{compiler correctness certification frontier}.
}
$$

---

# 9. Formal semantic preservation

Xavier Leroy 的 2009 *Communications of the ACM* paper 與 CompCert 官方 proof development記錄：

- CompCert 是 realistic optimizing C compiler；
- 使用 Coq proof assistant；
- compiler correctness 以 semantic preservation theorem 形式證明；
- source-level safety properties 可以藉 verified compilation preserved 到 generated executable behavior 的相應 scope。

因此：

$$
\boxed{
Y_{\mathrm{Cert}}^{(\mathrm{compiler\ semantic\ preservation})}
\le2009.
}
$$

這裡的年份是 published realistic-compiler documentation upper bound，不宣稱 2009 是 CompCert project 最早內部成功日期。

---

# 10. Certification scope is not end-to-end omniscience

CompCert 官方文件也明確保留 trust boundary：

- verified compilation proper 被 formally proved；
- preprocessing、部分 elaboration、assembling / linking 等並非全部包含在相同 proof scope；
- current compiler documentation仍清楚標示 verified與未 verified部分。

因此 CompCert 同時是一個：

$$
\boxed{
\text{certification gain}
}
$$

與：

$$
\boxed{
\text{certification scope boundary}
}
$$

案例。

這直接支持 Paper 02 / Paper 07：

$$
\boxed{
\text{certificate}
\neq
\text{universal correctness claim}.
}
$$

---

# 11. Raw performance vs certification

CompCert 官方手冊目前仍描述 generated code：

> decent but not outstanding，

並在特定 ARM64 benchmark comparison 中約為 GCC `-O1` performance 的 90%。

此數值是 2026 current implementation calibration，**不回填 2009 歷史效能**。

它只說明概念上：

$$
\boxed{
\text{higher certification}
\not\Rightarrow
\text{maximum raw performance}.
}
$$

Batch 03 不把此 current metric 當歷史 2009 benchmark。

---

# 12. Mechanism attribution

CompCert：

$$
\boxed{
M+\Gamma_{\mathrm{proof}}+\Sigma_{\mathrm{formal}}+\kappa.
}
$$

其中：

- $M$：realistic compiler construction；
- $\Gamma_{\mathrm{proof}}$：formal semantics / intermediate languages / proof structure；
- $\Sigma_{\mathrm{formal}}$：reusable lemmas / verified passes；
- $\kappa$：Coq machine-checking certification contract。

---

# 13. CompCert signature

$$
\boxed{
\textbf{Certification-Frontier Shift without Raw-Capability Origin}.
}
$$

也就是：

> 「能 compile」早就存在；CompCert 移動的是「能用什麼證據信任 compiler」的 frontier。

---

# 14. Case J — Google / PageRank / Web indexing

## 14.1 Fixed task

固定：

> 對大規模 Web document collection 建立可持續 crawl、index、link ranking 與快速 query-response 的 search system。

Brin 與 Page 1998 的 Google paper 報告 prototype：

$$
\boxed{
\ge24\text{ million pages}
}
$$

full-text + hyperlink database。

---

# 15. Offline build phases

Google architecture 將 query 前的大量工作分離：

1. crawl pages；
2. parse documents；
3. generate hits；
4. write forward-index barrels；
5. parse anchors；
6. URL resolve；
7. build link database；
8. compute PageRank；
9. sort barrels；
10. construct inverted index；
11. build lexicon。

原始 paper 明確記錄：

- 26 million pages 的 PageRank 可在 medium-size workstation 上幾小時算完；
- crawler / indexer / sorter 建立 substantial Web index；
- 24 million pages index 可在不到一週內建立；
- searcher 之後使用 lexicon、inverted index 與 PageRanks 回答 query。

因此這是一個非常乾淨的：

$$
\boxed{
\text{offline build}
\rightarrow
\text{online query}
}
$$

分離。

---

# 16. PageRank / indexing as $\Sigma$ and precomputation

在 UCPNP lifecycle 語言：

$$
\mathbf C_{\mathrm{world}}
=
\mathbf C_{\mathrm{crawl}}
+
\mathbf C_{\mathrm{index}}
+
\mathbf C_{\mathrm{PageRank}}
+
\mathbf C_{\mathrm{sort}}
+
\sum_q
\mathbf C_{\mathrm{query}}(q).
$$

如果只量：

$$
C_{\mathrm{query}}
$$

就會把整個 offline knowledge / index construction 隱藏掉。

因此：

$$
\boxed{
\text{fast query}
\not\Rightarrow
\text{cheap total knowledge system}.
}
$$

其：

- PageRank vector；
- lexicon；
- inverted index；
- anchor-derived structures

都可視為：

$$
\Sigma_{\mathrm{index}}\text{-proxy}.
$$

---

# 17. Representation component

Google 不只是「預先把文件存起來」。

它還使用：

- hyperlink graph；
- PageRank；
- anchor text propagation；
- forward/inverted index；
- weighted hit structures。

因此也包含：

$$
\Gamma_{\mathrm{IR}}\text{-candidate}.
$$

因為 raw Web documents 被轉成不同 decision/query representation。

Batch 03 不做 pure representation ablation，所以只標 candidate。

---

# 18. Resource constraints are explicit

原始 Google paper 報告其 bottlenecks 包括：

- CPU；
- memory access；
- memory capacity；
- disk seeks；
- disk throughput；
- disk capacity；
- network I/O。

這是對 UCPNP 多維 resource budget 的直接實例。

它還特別指出 disk seek 約 10ms，因此 data structure design 強烈受 I/O reality 影響。

所以：

$$
\boxed{
\text{query tractability}
}
$$

並不是由一個 FLOPS scalar 決定。

---

# 19. Google/PageRank phase vector

### Representation

hypertext/link-based ranking + indexing architecture：

$$
Y_R\le1998.
$$

### Discovery / construction

Google prototype architecture：

$$
Y_D\le1998,
\qquad
Y_C\le1998.
$$

### Offline execution

24M-page crawling/indexing/PageRank demonstrated：

$$
Y_E^{(\mathrm{offline})}
\le1998.
$$

### Online execution

prototype publicly queryable：

$$
Y_E^{(\mathrm{online})}
\le1998.
$$

### Verification

system-quality evaluation is empirical, not formal certificate。

formal certification：

`NOT APPLICABLE`.

---

# 20. Google/PageRank signature

$$
\boxed{
\textbf{Offline-Precomputation / Online-Query Shift}.
}
$$

這是目前最強的 real-world lifecycle accounting case。

---

# 21. Cross-case matrix

| Case | Historical shift | What did not move equivalently | Signature |
|---|---|---|---|
| Coppersmith–Winograd | asymptotic exponent improved by 1990 | finite practical wall-clock frontier unresolved | Asymptotic-Theorem / Practicality-Unresolved |
| Deep Blue | massive specialized search + parallelism reached champion-level execution by 1997 | not a pure hardware-only explanation | Hardware-Amplified Search + Knowledge Support |
| CompCert | machine-checked semantic-preservation certification by 2009 | ordinary compilation capability already existed | Certification-Frontier Shift |
| Google/PageRank | huge offline crawl/index/ranking transformed online query tractability by 1998 | total lifecycle cost did not become cheap | Offline-Precomputation / Online-Query Shift |

---

# 22. Result R22.1 — Theoretical complexity improvement is not automatically practical tractability

Coppersmith–Winograd forces UCPNP to separate:

$$
\boxed{
\text{asymptotic complexity frontier}
}
$$

from:

$$
\boxed{
\text{finite-resource operational frontier}.
}
$$

This is important because UCPNP must not commit the inverse error of conflating cognitive tractability with formal complexity classes.

---

# 23. Result R23.1 — Hardware dominance can be real without being exclusive

Deep Blue establishes a documented case where specialized hardware provides most computational power.

But IBM's own system description simultaneously identifies search extensions, evaluation and game database.

Thus:

$$
\boxed{
H\text{-dominant contribution}
\not\Rightarrow
H\text{-only cause}.
}
$$

---

# 24. Result R24.1 — Certification can be the primary frontier shift

CompCert is a clean counterexample to:

> every important computing breakthrough must primarily increase raw task capability.

The raw task：

$$
\text{compile C}
$$

already existed.

The key shift：

$$
\boxed{
\text{machine-checked compiler semantic preservation}.
}
$$

Hence:

$$
\boxed{
\Delta\mathcal F_{\mathrm{Cert}}>0
}
$$

can be historically central even without originating：

$$
\Delta\mathcal F_{\mathrm{raw}}>0.
$$

---

# 25. Result R25.1 — Precomputation must be first-class in historical cognition

Google's architecture provides a large-scale real system in which:

$$
\boxed{
C_{\mathrm{offline}}\gg0
}
$$

is deliberately paid so that repeated：

$$
C_{\mathrm{online}}
$$

becomes tractable.

This supports Paper 02 Import/Precomputation Conservation and Paper 03 reuse horizon.

---

# 26. New-variable test

Batch 02 exposed possible deployment cost：

$$
C_{\mathrm{Deploy}}.
$$

Batch 03 exposes offline-build lifecycle：

$$
C_{\mathrm{offline}}.
$$

Do these require new primitive costs?

Current answer：

$$
\boxed{
\text{No, not yet}.
}
$$

Both can still be represented using existing：

$$
C_R+C_C+C_E+C_V+C_{\mathrm{Cert}}+C_O
$$

plus scope / timing / contract tags：

$$
\kappa_{\mathrm{interop}},
\qquad
\text{offline/online phase}.
$$

Series-I Stop Rule remains unbroken.

---

# 27. Batch 01–03 signature inventory

We now have ten cases and ten useful historical shapes:

1. Dijkstra — Method-Dominant；
2. Four Color — Certification-Lag；
3. AlexNet — Mixed-Convergence；
4. FFT — Lineage-Recovery / Method-Generalization；
5. GRASP/CDCL — Knowledge-Condensation-with-Overhead；
6. RSA — Concept–Method–Deployment-Contract Lag；
7. Coppersmith–Winograd — Asymptotic-Theorem / Practicality-Unresolved；
8. Deep Blue — Hardware-Amplified Search + Knowledge Support；
9. CompCert — Certification-Frontier Shift；
10. Google/PageRank — Offline-Precomputation / Online-Query Shift。

The framework is increasingly constrained by cases rather than terminology.

---

# 28. What Batch 03 falsifies

This batch rejects four simplistic statements:

$$
\boxed{
\text{better asymptotics}
=
\text{better practical runtime}
}
$$

No.

$$
\boxed{
\text{Deep Blue}
=
\text{just brute force}
}
$$

Too simple.

$$
\boxed{
\text{formal verification}
=
\text{more raw performance}
}
$$

No.

$$
\boxed{
\text{fast search query}
=
\text{cheap search system}
}
$$

No.

---

# 29. Batch 04 direction

Batch 04 should now include at least one:

- **failure / abandoned architecture**；
- **scientific instrument / sensor frontier**；
- **human–machine hybrid workflow**；
- **large-language-model or modern agent case with current preserved artifacts**。

Candidate set：

1. Fifth Generation Computer Systems / logic programming；
2. Hubble or LIGO data pipeline；
3. AlphaGo / AlphaZero；
4. GitHub Copilot / coding agent or frontier long-horizon agent benchmark；
5. seL4 formal verification as comparison against CompCert。

The next batch should deliberately include a case where the framework's initial mechanism label changes after source inspection.

---

# 30. Conclusion

Batch 03 creates four distinctions that Series I predicted but had not yet historically stress-tested together：

$$
\boxed{
\text{Asymptotic}
\neq
\text{Practical},
}
$$

$$
\boxed{
\text{Hardware contribution}
\neq
\text{Hardware-only causation},
}
$$

$$
\boxed{
\text{Raw capability}
\neq
\text{Certification capability},
}
$$

$$
\boxed{
\text{Online cost}
\neq
\text{Lifecycle cost}.
}
$$

This is the strongest E01 batch so far because each case constrains a different possible overclaim.

The current UCPNP historical program therefore moves from merely classifying breakthroughs to auditing：

$$
\boxed{
\text{where the apparent ease was actually purchased}.
}
$$

---

# References

1. Don Coppersmith & Shmuel Winograd. *Matrix Multiplication via Arithmetic Progressions*. Journal of Symbolic Computation 9(3), 251–280 (1990). DOI: 10.1016/S0747-7171(08)80013-2.
2. Feng-Hsiung Hsu. *IBM's Deep Blue Chess Grandmaster Chips*. IEEE Micro (1999).
3. Murray Campbell, A. Joseph Hoane Jr., Feng-Hsiung Hsu. *Deep Blue*. Artificial Intelligence (2002).
4. Xavier Leroy. *Formal Verification of a Realistic Compiler*. Communications of the ACM 52(7), 107–115 (2009).
5. CompCert Project. *The CompCert C Verified Compiler* — proof development and user's manual.
6. Sergey Brin & Lawrence Page. *The Anatomy of a Large-Scale Hypertextual Web Search Engine*. Computer Networks and ISDN Systems 30, 107–117 (1998).
