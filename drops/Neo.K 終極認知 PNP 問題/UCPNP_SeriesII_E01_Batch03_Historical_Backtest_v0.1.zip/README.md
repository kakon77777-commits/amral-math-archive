# UCPNP Series II E01 — Batch 03

Cases:
1. Coppersmith–Winograd — asymptotic theorem vs practical frontier.
2. IBM Deep Blue — hardware-amplified search with non-hardware knowledge/method support.
3. CompCert — certification-frontier shift.
4. Google/PageRank — offline precomputation and indexing vs online query cost.

Main discipline:
- Do not infer finite practical speed from asymptotic exponent alone.
- Do not call Deep Blue hardware-only.
- Do not treat formal certification as raw-performance gain.
- Do not hide offline indexing/build costs behind fast online queries.
