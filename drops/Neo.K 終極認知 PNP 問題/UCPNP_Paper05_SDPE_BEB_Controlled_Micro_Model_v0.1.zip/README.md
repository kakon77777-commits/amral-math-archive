# UCPNP Paper 05 v0.1 Release Pack

This pack contains the controlled SDPE-BEB mapping experiment for the Neo.K Ultimate Cognitive P/NP research program.

Canonical scope:

$$
\boxed{
\text{SDPE-BEB is used as an L2--L3 controlled micro-model, not as a proof of universal cognition.}
}
$$

Contents:

- `05_UCPNP_SDPE_BEB_Controlled_Micro_Model_v0.1.md` — paper;
- `05_UCPNP_Claim_Matrix_v0.1.md` — typed claim register;
- `05_UCPNP_SDPE_Mapping_Experiment_Report_v0.1.json` — machine-readable benchmark mapping and exact metrics;
- `05_UCPNP_Lineage_Verification_v0.1.json` — build-time verification against committed SDPE lineage reports;
- `05_UCPNP_Source_Integrity_v0.1.json` — canonical-source validation;
- `tools/verify_p05_arithmetic.py` — independent exact arithmetic/count sanity checker;
- `DEPENDENCIES.sha256` — hashes of Paper 00–02 and SDPE-BEB v1.0.0;
- `CHECKSUMS.sha256` — release file checksums.

The numerical values in the machine-readable report are derived only from committed SDPE-BEB lineage reports and theorem artifacts. No new hidden benchmark run is claimed in Paper 05.
