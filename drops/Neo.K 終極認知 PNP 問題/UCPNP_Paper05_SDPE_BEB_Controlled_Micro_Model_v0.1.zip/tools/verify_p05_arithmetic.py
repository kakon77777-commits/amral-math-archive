from fractions import Fraction

# v0.6 exact adaptive gap
assert Fraction(319, 2940) - Fraction(85, 784) == Fraction(1, 11760)

# v0.7 state reduction
raw_q16 = 3_066_025
quot_q16 = 699_847
assert raw_q16 > quot_q16
assert abs(raw_q16 / quot_q16 - 4.3809932742442275) < 1e-15

# v0.8 action pruning
considered = 15_722_611
pruned = 7_512_427
assert 0 < pruned < considered
assert abs(pruned / considered - 0.47781039675916426) < 1e-15

# v0.8 local-index counterexample
assert Fraction(3, 16) > Fraction(123, 731)
assert Fraction(81_766, 77_175) - Fraction(1_961_999, 1_852_200) == Fraction(11, 52_920)

# v1.0 proof ladder totals
states = [6_043_713, 6_192_984, 3_862_888, 5_460_612]
policy_dag = [3_995, 4_789, 4_023, 2_716]
actions = [42_612_798, 43_556_455, 27_934_591, 38_592_093]
dyadic_strict = [33_755_427, 34_532_701, 22_058_743, 30_655_064]
exact_ties = [1_487_173, 1_523_484, 916_151, 1_222_512]
dyadic_dual = [7_370_067, 7_500_139, 4_959_640, 6_714_453]
heavy = [131, 131, 57, 64]

assert sum(states) == 21_560_197
assert sum(policy_dag) == 15_523
assert sum(actions) == 152_695_937
assert sum(dyadic_strict) == 121_001_935
assert sum(exact_ties) == 5_149_320
assert sum(dyadic_dual) == 26_544_299
assert sum(heavy) == 383
assert sum(dyadic_strict) + sum(exact_ties) + sum(dyadic_dual) + sum(heavy) == sum(actions)

# Q21 value parses as a positive rational and Alpha strict gaps are positive.
q_a = Fraction(612_987_177_912_779_627_539, 239_919_381_023_293_440_000)
q_b = Fraction(72_433_806_985_597_946_597, 29_989_922_627_911_680_000)
q_g = Fraction(312_445_909_249_459_003_187, 127_957_003_212_423_168_000)
assert q_a > q_b
assert q_a > q_g

print('UCPNP Paper 05 arithmetic checks: PASS')
