# SDPE-BEB 作為 UCPNP 的受控微觀模型：認知成本、證據狀態、$\Sigma$／$\Gamma$ 代理量與 Proof-Carrying 計算的操作化實驗

**English title:** *SDPE-BEB as a Controlled Micro-Model of UCPNP: Operationalizing Cognitive Costs, Epistemic States, $\Sigma$/$\Gamma$ Proxies, and Proof-Carrying Computation*  
**Series:** Neo.K Ultimate Cognitive P/NP Problem  
**Paper:** 05  
**Version:** v0.1  
**Author:** Neo.K  
**Collaborative formalization:** Aletheia  
**Date:** 2026-08-15  
**Status:** Controlled finite-benchmark experiment; L2–L3 evidence only.

---

# Canonical non-identity and scope statement

本文研究 $\mathrm{UCPNP}_{\mathrm{Neo.K}}$ 的受控操作化，不研究或聲稱解決標準計算複雜度問題

$$
P\stackrel{?}{=}NP.
$$

本文亦不主張 SDPE-BEB 與人類認知、一般人工智能、後人類或 ASI 完全同構、同效或同尺度。本文的證據範圍限定為：在一個有限、可重放、可稽核、具有明確 hidden truth / observation / claim / certification contract 的微觀系統中，檢查 UCPNP Paper 00–02 所提出的若干區分是否能被真正操作化。

因此本文核心立場為：

$$
\boxed{
\text{controlled mechanism existence}
\neq
\text{universal cognitive law}
}
$$

以及：

$$
\boxed{
L2\text{--}L3
\not\Rightarrow
L7.
}
$$

---

# 摘要

本文將 SDPE-BEB v0.6.0–v1.0.0 視為 $\mathrm{UCPNP}_{\mathrm{Neo.K}}$ 的受控微觀實驗平台，檢查三類核心結構是否可操作化：第一，Paper 02 的六相成本分解 $C_R,C_D,C_C,C_E,C_V,C_{\mathrm{Cert}}$；第二，Truth–Evidence–Certification 三層 epistemic state；第三，Paper 00 預留的知識凝結 $\Sigma$ 與表示／維度生成 $\Gamma$ 的候選代理量。

本文採取嚴格 mapping contract，將對應分為四級：E（exact operational mapping）、P（measurable proxy）、A（structural analogy）、U（unsupported）。只有在 benchmark contract 中具有同一操作語義的量才標 E；$\Sigma$、$\Gamma$ 目前僅允許標 P，不將有限 benchmark 的 representation gain 直接等同一般智能的「維度生成」。

實驗得到六個主要結果。第一，v0.6.0 證明相同 query age 不是充分狀態：$V_1(A_{0,1})=0$ 而 $V_1(A_{1,0})=1/42$，說明可用 evidence / posterior structure 會改變後續決策價值。第二，在同一 global query budget 下，posterior-adaptive scheduling 在 $Q=4$ 嚴格勝過 nonpreemptive recycling，差值為 $1/11760$，提供 context-sensitive metareasoning 具有正價值的 finite existence proof。第三，v0.7.0 的 finite-horizon behavioral bisimulation 在不改變任務語義與 Bellman value 的條件下，將 $Q=16$ cumulative memoized states 從 $3,066,025$ 降為 $699,847$，約 $4.381\times$；本文將其列為強 $\Gamma$-proxy 候選。第四，v0.8.0 的 dual-sandwich certificate 在相同 exact frontier 下，將 $Q=19$ cumulative states 從 $4,033,965$ 降至 $2,067,881$，並在 recursion 前安全剪除 $47.781\%$ candidate actions；v0.9.0 進一步將 local parametric dual 凝結為 horizon 12 後永久固定的 33 個 rational breakpoints，列為強 $\Sigma$-proxy 候選。第五，v0.8.0 的 exact counterexample 證明 context-free scalar local productivity index 不足以決定 global optimal action，說明 UCPNP 不應把「智能程度」壓成單一局部分數。第六，v1.0.0 建立 untrusted numerical discovery $\rightarrow$ exact evaluation $\rightarrow$ layered certification 的 proof-carrying Bellman architecture：四個 horizon-20 proof graphs 共含 $21,560,197$ guide states 與 $152,695,937$ alternative actions，其中只有 383 個 boundary actions 需要 heavy arbitrary-precision exact dual；同時 exact closure 得到 $V_A^\star(21)$。

本文因此得到一個有限範圍的操作結論：UCPNP 的 Search/Discovery、Representation、Verification、Certification、reusable knowledge 與 representation change 可以在同一個 micro-model 中被拆開測量；但 $\Sigma$／$\Gamma$ 的一般化、歷史智能體映射與 ASI 預測仍需 Paper 03、04、06、07 的跨任務與歷史驗證。

**關鍵詞：** UCPNP、SDPE-BEB、agent-relative tractability、cognitive cost decomposition、Truth–Evidence–Certification、posterior state、behavioral bisimulation、knowledge condensation、representation change、proof-carrying Bellman、metareasoning

---

# 0. Claim typing

本文使用 Paper 00 的五類 claim typing：

- **D** — Definition；
- **T** — Theorem / exact finite consequence；
- **C** — Conjecture；
- **E** — Empirical / benchmark result；
- **N** — Normative axiom。

本文不新增任何關於 classical $P$ vs. $NP$ 的 theorem claim。

本文主要證據等級：

$$
\boxed{L2\text{--}L3.}
$$

其中 exact finite theorem 屬 L2；完整可 replay benchmark / release lineage 屬 L3。本文不將這些結果直接升格為跨模型 L4、歷史 L5、跨領域 L6 或 future-agent L7。

---

# 1. 研究問題

Paper 00–02 已提出一個比「問題難不難」更細的研究語言：

$$
\Xi_t=(A_t,K_t,\Sigma_t,\Gamma_t,H_t,M_t,N_t,E_t),
$$

以及六相成本：

$$
\mathbf C
=
(C_R,C_D,C_C,C_E,C_V,C_{\mathrm{Cert}}).
$$

然而，一套概念如果不能進入可控系統，就很容易只剩漂亮分類。本文因此不再新增高階哲學命題，而問四個低階問題：

1. Truth、Evidence、Certification 能否在同一 benchmark 內被明確分離？
2. Representation、Discovery、Execution、Verification、Certification 是否真的呈現不可互換成本？
3. 是否存在可測量的 $\Sigma$-type 與 $\Gamma$-type intervention？
4. 是否可以在不相信 heuristic / floating discovery 的情況下，只相信 exact certification？

本文選 SDPE-BEB，是因為其 runtime semantics 從 v0.6.0 至 v1.0.0 保持同一 wire protocol，後續版本主要改變 analysis representation、search、pruning 與 proof architecture，而不是改寫 hidden task semantics。這使部分版本差異可以作為受控或準受控 intervention 分析。

---

# 2. 實驗材料與 mapping contract

## 2.1 Canonical artifacts

本文固定使用以下 dependency：

- UCPNP Paper 00 v0.1；
- UCPNP Paper 01 v0.1；
- UCPNP Paper 02 v0.1；
- SDPE-BEB v1.0.0 outer release pack；
- v1.0.0 lineage 中的 v0.6.0、v0.7.0、v0.8.0、v0.9.0 reports。

本文不從自然語言回憶重建數值；所有 benchmark 數字均來自 lineage 內 committed theorem/report artifacts。

## 2.2 Mapping status vocabulary

為避免「看起來很像」被寫成「就是同一件事」，定義：

### E — Exact operational mapping

兩個概念在 benchmark contract 中具有同一操作角色，且可由 runtime / audit semantics 直接判定。

### P — Measurable proxy mapping

benchmark quantity 可測量、可重現，且滿足 UCPNP 概念的一部分必要性質，但尚未證明跨任務普遍等價。

### A — Structural analogy

只有結構相似性，不用來建立定量 claim。

### U — Unsupported

目前沒有足夠 mapping，不宣稱。

本文對 $\Sigma,\Gamma$ 最多使用 P，不使用 E。

## 2.3 Protocol invariance

從 SDPE-BEB v0.6.0 到 v1.0.0，runtime protocol 維持：

```text
sdpe-beb-b2pa-v0.6.0
```

v1.0.0 並報告 canonical runtime core 與 v0.9.0 byte-identical。故 v0.7–v1.0 的主要數學提升不能解釋成「benchmark 任務被改簡單」。

但這仍不是完美的單因子實驗：一個版本可能同時加入多個 analysis optimization。本文因此把證據再分：

- **Ablation-A**：同一 recursion / 同一 value，只有一個明確 representation / pruning intervention；
- **Ablation-B**：runtime semantics 不變，但 analysis layer 同時有多個變化；
- **Structural**：只證明某個機制存在，不解釋總 runtime 因果。

---

# 3. Object-level Truth–Evidence–Certification：E 級映射

在 SDPE-BEB 的 task layer，可直接建立：

| UCPNP Paper 02 | SDPE-BEB object-level object | Mapping |
|---|---|---|
| Truth | hidden task semantic truth | E |
| Evidence | participant 已合法 observation 的 premises、witness dependencies、transcript facts | E |
| Certification | 指定 zero-unsupported contract 下可提交且通過的 claim | E |

這裡最重要的是：

$$
\boxed{
\text{Truth}\neq\text{Evidence}\neq\text{Certification}.
}
$$

一個 task 的 hidden truth 可以已經固定，但 participant 尚未取得支持 claim 的 evidence；participant 也可能已有足夠局部 evidence，卻仍不滿足 contract 對 witness scope、dependency closure 或 universal completion 的要求。

這個 mapping 不需要把 benchmark 類比成人類心理。它只是 contract-level identity，因此標 E。

---

# 4. 六相成本在 SDPE-BEB 的操作化

本文不主張每一個 CPU instruction 都能唯一對應「認知心理階段」，而是用 Paper 02 的 primitive-event ledger 觀點對 analysis pipeline 分類。

| Cost | SDPE-BEB observable | Status |
|---|---|---|
| $C_R$ | raw descriptor $\rightarrow$ posterior state；posterior $\rightarrow$ quotient；common-denominator integer representation | E/P |
| $C_D$ | query selection、Bellman state exploration、numerical policy discovery | E |
| $C_C$ | witness / policy artifact / dual certificate / proof graph 建造 | E/P |
| $C_E$ | chosen policy execution、exact recurrence evaluation | E |
| $C_V$ | witness validity、transition / action bound / proof artifact checking | E |
| $C_{\mathrm{Cert}}$ | task claim admission；analysis-level Bellman optimality acceptance；audit acceptance | E |
| $C_O$ | memoization、hashing、scheduler bookkeeping、proof graph traversal | E |

其中 $C_R$ 與 $C_C$ 最容易混淆：建立一個新 representation 的一次性工作應記入 $C_R$；在該 representation 內建造某一個 instance-specific proof / witness 則主要進 $C_C$。

---

# 5. Experiment I：query age 不是 cognition state

SDPE-BEB v0.6.0 給出兩個 Alpha histories，兩者都只做過一次 query：

$$
A_{0,1},
\qquad
A_{1,0}.
$$

但其一 query continuation values 不同：

$$
V_1(A_{0,1})=0,
$$

$$
V_1(A_{1,0})=\frac{1}{42}.
$$

因此：

$$
\boxed{
\text{same elapsed query count}
\not\Rightarrow
\text{same decision state}.
}
$$

## Interpretation

這個結果對 UCPNP 的價值不是「人類也一定如此」，而是提供一個 exact finite counterexample，反駁把 cognition / progress 壓成單一 elapsed-cost coordinate 的做法。

在 Paper 01 的語言中，兩個 agent states 消耗了同樣的 $B_Q$，但其 information closure 不同；故未來的 tractability model 必須至少保留對 decision-relevant evidence 的 sufficient state。

**Mapping status:** E for evidence-state difference；A for general cognition.

---

# 6. Experiment II：context-sensitive metareasoning 具有嚴格正值

v0.6.0 在 actual sixty-task benchmark 上得到：

$$
V_A^\star(4)=\frac{319}{2940},
$$

$$
V_{\mathrm{CR}}(4)=\frac{85}{784},
$$

因此：

$$
\boxed{
V_A^\star(4)-V_{\mathrm{CR}}(4)
=
\frac{1}{11760}>0.
}
$$

兩者使用同一 total observation budget。差異不是多給硬體或多給 query，而是 unrestricted policy 能根據 posterior state switch / revisit。

## UCPNP reading

這是一個有限 existence proof：

$$
\boxed{
\text{how resources are allocated}
\text{ can matter even when total query resource is fixed.}
}
$$

換言之，metareasoning / scheduling 本身可改變 certification yield。這支持 Paper 02 將 $C_D$、$C_O$ 與 $C_E$ 分開，而不是把所有成本壓成「總算力」。

**Mapping status:** E within benchmark；A outside benchmark.

---

# 7. Experiment III：v0.7 behavioral quotient 作為 $\Gamma$-proxy

Paper 00 暫定：

$$
\Sigma=\text{在既有 representation 中知道更多},
$$

$$
\Gamma=\text{改變 representation / effective state space}.
$$

v0.7.0 提供第一個非常乾淨的候選。

## 7.1 Exact behavioral quotient

raw local posterior states 共 52 個；finite-horizon behavioral bisimulation 依 horizon 形成 exact quotient。從 $h=11$ 起穩定為 49 classes。

最重要的是：quotient theorem 證明，如果兩個 global states 在 horizon-$h$ occupancy quotient 下相同，則 Bellman value 相同。

因此這不是 heuristic clustering，而是：

$$
\boxed{
\text{representation compression}
+
\text{semantic/value preservation}.
}
$$

## 7.2 Controlled state-space ablation

在同一 unrestricted recursion、$Q=16$：

$$
N_{\mathrm{raw}}=3{,}066{,}025,
$$

$$
N_{\mathrm{quot}}=699{,}847.
$$

所以：

$$
\boxed{
G_{\Gamma,\mathrm{state}}
:=
\frac{N_{\mathrm{raw}}}{N_{\mathrm{quot}}}
\approx4.381.
}
$$

亦即 cumulative state count 降低約 $77.174\%$。

## 7.3 Why this is only a proxy

本文將此標為 **P: strong $\Gamma$-proxy candidate**，而不是 E，理由如下：

1. 它確實改變了問題的有效 state representation；
2. 它保持 task semantics 與 exact Bellman value；
3. 它降低後續 search/evaluation state burden；
4. 但「一般智能的維度生成」比 finite-state quotient 廣得多。

因此本文只證明：

$$
\boxed{
\exists\text{ a semantics-preserving representation intervention with measurable tractability gain.}
}
$$

不證明所有 $\Gamma$ 都可被 quotient 表示。

---

# 8. Experiment IV：v0.8–v0.9 reusable certificate structure 作為 $\Sigma$-proxy

如果 $\Gamma$ 是換 representation，那麼 $\Sigma$ 最適合用「在 representation 不變時累積可重用結構」測量。

## 8.1 v0.8 dual-sandwich reuse

在 $Q=19$，v0.7 cumulative memo states 為：

$$
4{,}033{,}965.
$$

加入 exact dual-sandwich action pruning 後：

$$
2{,}067{,}881.
$$

減少：

$$
\boxed{48.738\%}.
$$

同時 candidate actions：

$$
15{,}722{,}611,
$$

其中在 recursive expansion 前安全剪除：

$$
7{,}512{,}427,
$$

即：

$$
\boxed{47.781\%}.
$$

這裡的 gain 不是多取得 hidden premise，而是加入可重用的 upper/lower certificate knowledge。

因此本文把它標為：

$$
\boxed{\Sigma_{\mathrm{cert}}\text{-proxy}.}
$$

## 8.2 v0.9 parametric dual fixed point

v0.9.0 更進一步證明，對全部 52 posterior states 與所有 $\lambda\ge1/7$：

$$
J_{\lambda,12}(s)=J_{\lambda,13}(s),
$$

因同一 Bellman operator 重複作用，故：

$$
\boxed{
J_{\lambda,h}(s)=J_{\lambda,12}(s),
\qquad
\forall h\ge12.
}
$$

永久 dual basis 只需 33 個 rational breakpoints；每個 state 最多 3 個 linear pieces。

這提供了一種非常接近「知識凝結」的 finite mechanism：原本 horizon 持續增加可能帶來的新計算，被一個有限 exact theorem basis 封閉。

本文因此定義 provisional proxy：

$$
\Sigma_{\mathrm{condensed}}
:=
\text{a reusable exact structure whose future applicability exceeds the horizon at which it was derived}.
$$

這仍不是一般智能的 $\Sigma$ 定義，但它比「記得更多資料」更接近 Paper 00 原本想描述的 reusable structural knowledge。

---

# 9. Experiment V：單一 local scalar index 不足

如果 UCPNP 未來要比較不同智能體，很容易誘惑人建立一個單一 intelligence / productivity score。SDPE-BEB v0.8.0 給出一個 exact 反例。

在 horizon $h=7$，global state：

$$
S=\{A_{0,2},A_{1,0}\}.
$$

local productivity indices：

$$
\gamma_7(A_{0,2})=\frac{3}{16},
$$

$$
\gamma_7(A_{1,0})=\frac{123}{731}.
$$

因此 local scalar ranking 偏好 $A_{0,2}$。

但 exact global action values：

$$
Q(A_{0,2})=\frac{1961999}{1852200},
$$

$$
Q(A_{1,0})=\frac{81766}{77175},
$$

且：

$$
\boxed{
Q(A_{1,0})-Q(A_{0,2})
=
\frac{11}{52920}>0.
}
$$

也就是 global optimum 先做 local index 較低的 task。

## UCPNP implication

本文只能推出 finite benchmark theorem：

$$
\boxed{
\text{context-free local scalar productivity is insufficient here.}
}
$$

但它提供一個重要的方法論警告：未來若以單一 IQ、FLOPS、parameter count、benchmark average 或「智慧等級」代表 agent-relative tractability，必須先證明 context invariance；否則 global task ecology 可能改變局部能力的價值。

這與 Paper 01 的多維 resource vector、Paper 02 的 no-universal-linear-scalarization 結果方向一致。

---

# 10. Experiment VI：v1.0 proof-carrying Bellman 與 discovery–certification 解耦

v1.0.0 的主要方法論為：

$$
\boxed{
\text{untrusted numerical discovery}
\rightarrow
\text{exact policy evaluation}
\rightarrow
\text{layered exact certification}.
}
$$

numerical guide 可以錯。correctness 不依賴它的 floating values；錯誤 guide 只能導致 certification 失敗或得到較差 policy。

## 10.1 Four proof graphs

四個 horizon-20 successor proof graphs 合計：

$$
N_{\mathrm{guide}}=21{,}560{,}197
$$

guide states，及：

$$
N_{\mathrm{alt}}=152{,}695{,}937
$$

alternative actions。

其 proof ladder 分布：

| Certificate layer | count | fraction |
|---|---:|---:|
| outward dyadic strict | 121,001,935 | 79.2437% |
| fixed-width exact ties | 5,149,320 | 3.3723% |
| outward parametric dual | 26,544,299 | 17.3838% |
| heavy exact dual | 383 | 0.0002508% |

四層合計恰好覆蓋全部 alternatives，且 committed reports 為：

$$
\boxed{\text{bad}=0,\qquad \text{heavy_fail}=0.}
$$

## 10.2 Policy execution representation vs proof landscape

四個 chosen-policy DAG states 合計：

$$
N_{\mathrm{policy}}=15{,}523.
$$

相對 guide states：

$$
\frac{15{,}523}{21{,}560{,}197}
\approx0.000720.
$$

即約 $0.072\%$；guide-to-policy DAG ratio 約 $1388.9\times$。

但本文**不**將此宣稱為「完整 proof compression 1388.9 倍」，因為 optimality certification 仍需處理大量 non-chosen alternatives。這個比例只說明：

$$
\boxed{
\text{the artifact needed to execute one chosen policy}
\ll
\text{the landscape needed to certify its optimality}.
}
$$

這正是 $C_E$、$C_D$、$C_V$、$C_{\mathrm{Cert}}$ 不應混在一起的 concrete example。

## 10.3 Exact closure

v1.0.0 最終得到：

$$
\boxed{
V_A^\star(21)
=
\frac{612987177912779627539}{239919381023293440000}.
}
$$

這個數值的重要性在本文中反而次於 proof architecture：同一候選策略可以由便宜但不可信的 discovery 提出，再由與 discovery correctness 解耦的 exact certifier 決定是否接受。

---

# 11. Certification tower：物件層與方法層不能坍縮

SDPE-BEB v1.0 同時存在至少兩個 certification contract。

## 11.1 Object-level task certification

$$
\kappa^{(0)}_{\mathrm{task}}
$$

判定 participant 對某 hidden task 的 claim 是否有合法 evidence / witness / dependency closure。

## 11.2 Meta-level policy-optimality certification

$$
\kappa^{(1)}_{\mathrm{analysis}}
$$

判定一個 numerical guide 提出的 policy 是否真的達到 Bellman optimum。

兩者 scope 完全不同。

### T11.1 — Certification Layer Non-Collapse

在上述 contracts 下：

$$
\boxed{
\kappa^{(0)}_{\mathrm{task}}\text{-certified}
\not\Rightarrow
\kappa^{(1)}_{\mathrm{analysis}}\text{-optimal},
}
$$

且：

$$
\boxed{
\kappa^{(1)}_{\mathrm{analysis}}\text{-certified}
\not\Rightarrow
\text{arbitrary task claim is certified}.
}
$$

**Proof.** 第一個 contract 的 language 是 object-level claim validity；第二個 contract 的 language 是 scheduler / Bellman policy optimality。兩者的 claim language 與 admissible evidence 不同，故由 Paper 02 Certification Scope 原理，一個 contract 的 acceptance 不蘊含另一 contract scope 外的 claim。$\square$

這個有限例子支持一個重要 UCPNP 設計原則：未來研究「AI 說自己已證明某事」、「AI 說自己具有某能力」時，必須問的是哪一層 certifier、哪一種 evidence、哪一個 claim language。

---

# 12. $\Sigma$ / $\Gamma$ provisional operational criteria

Paper 03 尚未正式定義 $\Sigma$ 與 $\Gamma$。本文只提出從 SDPE-BEB 反推的 provisional test criteria。

## 12.1 $\Sigma$-type intervention candidate

一個 intervention $I$ 若主要滿足：

1. task semantics 不變；
2. state representation identity 基本不變；
3. 新增可重用 theorem / policy / certificate / memory structure；
4. 後續同類 decision/search/certification cost 降低；

則可標：

$$
I\in\Sigma\text{-proxy}.
$$

v0.8 dual certificates 與 v0.9 permanent 33-breakpoint basis 是目前最強候選。

## 12.2 $\Gamma$-type intervention candidate

一個 intervention $I$ 若主要滿足：

1. task semantics 不變；
2. 改變 state / representation / proof language；
3. transformation 可重建；
4. semantics / value preservation 可驗證；
5. intervention 後有效 search/evaluation complexity 可測量下降；

則可標：

$$
I\in\Gamma\text{-proxy}.
$$

v0.7 behavioral quotient 是最乾淨候選；v1.0 proof-carrying architecture 則是 mixed $\Gamma$-proxy：它改變「如何表示一張最優性證明」，但目前沒有單因子 wall-clock ablation，因此不以 speedup theorem 表述。

## 12.3 Mixed interventions

實際智能進步通常可能是：

$$
\Delta\Sigma\neq0,
\qquad
\Delta\Gamma\neq0.
$$

因此 Paper 03 不應強迫所有 intervention 二分。真正需要的是 decomposition / attribution protocol。

---

# 13. Result matrix

| Result | UCPNP concept | Mapping | Evidence |
|---|---|---|---|
| hidden truth vs observed evidence vs accepted claim | Truth–Evidence–Certification | E | runtime / audit contract |
| $V_1(A_{0,1})\neq V_1(A_{1,0})$ | information state matters | E | exact theorem |
| $Q=4$ adaptive gain $1/11760$ | metareasoning / $C_D,C_O$ | E | exact theorem |
| v0.7 quotient $4.381\times$ state reduction | $\Gamma$ candidate | P | exact value-preserving ablation |
| v0.8 dual pruning 47.781% actions | $\Sigma$ candidate | P | exact pruning report |
| v0.9 33-breakpoint fixed point | $\Sigma$ condensation | P | exact theorem |
| scalar local index counterexample | no context-free one-number priority | E | exact finite counterexample |
| v1.0 proof-carrying architecture | discovery/certification split | E/P | exact certification + architecture mapping |
| ASI / human cognition | general intelligence dynamics | U in this paper | not tested |

---

# 14. What the experiment falsifies

本文不是只有「找到相似」。至少排除五種過度簡化。

## 14.1 Progress is not elapsed compute alone

Experiment I 排除「同樣花一個 query 就代表相同進度」。

## 14.2 More compute does not replace missing evidence

SDPE-BEB 的 zero-unsupported contract 與 Paper 02 information obstruction 一致：participant 不能用內部 computation 合法引用未觀察 premise。

## 14.3 A single local intelligence/productivity scalar is not sufficient

Experiment V 給 exact counterexample。

## 14.4 Fast discovery need not be trusted

v1.0 numerical guide 明確不在 correctness trust base。

## 14.5 Verification and certification are different

能重算 action value不等於已滿足指定 proof / audit contract；反之，task-level certificate 也不代表 scheduler optimality。

---

# 15. What the experiment does NOT establish

本文刻意保留以下非結論：

1. 不證明 $\Sigma$ 是人類或 AI cognition 的單一真實物理量；
2. 不證明 $\Gamma$ 可被單一 quotient ratio 完整測量；
3. 不證明 SDPE-BEB 的 Bellman policy 等同人類 metareasoning；
4. 不證明所有 AI cognition 都能寫成 finite posterior MDP；
5. 不證明後人類或 ASI 會遵循相同 phase ratios；
6. 不證明 representation gain 必然使所有問題變 P-cog-like；
7. 不證明 proof-carrying computation 必然降低 total lifecycle cost；
8. 不證明 $P_{\mathrm{cog}}$ / $NP_{\mathrm{cog}}$ 與 classical $P$ / $NP$ 同構。

---

# 16. 對 Paper 03 的直接約束

Paper 03 原本預定直接定義 $\Sigma$ 與 $\Gamma$。本實驗顯示至少應加入以下要求。

## Requirement 1 — semantics-preserving test

任何宣稱 $\Gamma$ gain 的 representation change，必須先問：

$$
\text{task semantics preserved?}
$$

若改題、刪 constraint 或偷加 oracle，不算 $\Gamma$ gain。

## Requirement 2 — build/use accounting

quotient、index、proof language、knowledge base 都有 build cost：

$$
C_R^{\mathrm{build}}
$$

不能因為後續查得快就被抹掉。

## Requirement 3 — reuse horizon

$\Sigma$ 應包含 reuse dimension。一個只對單一 instance 生效的一次性 hint，和能封閉所有 $h\ge12$ 的 33-breakpoint theorem basis，不應被視為同等 knowledge condensation。

## Requirement 4 — mixed attribution

允許：

$$
I=I_{\Sigma}+I_{\Gamma}+I_M+I_H.
$$

不要強迫二分。

## Requirement 5 — exact / empirical distinction

finite benchmark 可有 exact proxy theorem；真實 AI agent 多半只能 empirical estimate。Paper 03 必須保留 proven / observed / unresolved 三分。

---

# 17. 對 Historical Cognitive Tractability 的啟示

本文沒有做歷史 backtest，但提供 Paper 04 一個重要 decomposition。

當我們問：

> 1986 年的人能不能算出某個結果？

不能只問 $H_{1986}$。

至少應分：

$$
C_R(y),
C_D(y),
C_C(y),
C_E(y),
C_V(y),
C_{\mathrm{Cert}}(y).
$$

例如一個 1986 系統也許已能負擔 final policy 的 $C_E$，但無法負擔 2026 才發明的 $C_R$ representation design 或 $C_D$ search architecture；也可能相反，一個數學表示早已可寫，但 memory / arbitrary-precision execution 還不實用。

因此 Paper 04 應至少區分：

$$
Y_{\mathrm{representation}},
Y_{\mathrm{discovery}},
Y_{\mathrm{execution}},
Y_{\mathrm{verification}},
Y_{\mathrm{certification}}.
$$

這比單一「可算年代」更接近 UCPNP 的歷史研究目標。

---

# 18. 與外部研究的定位

本文與 bounded optimality / metareasoning 的相鄰點，是有限資源智能體需要決定哪些 computation 值得做；Russell 與 Wefald 的 metareasoning 研究把 computation selection 本身視為決策問題，Russell 與 Subramanian 的 bounded optimality 則把 agent performance 約束在具體 computational architecture 與 task environment。

resource-rational task decomposition 進一步將「如何分解 / 表示 task」視為有限認知資源下的 representation problem。這與本文 $\Gamma$-proxy 的方向相鄰，但本文只在 finite exact benchmark 中研究 semantics-preserving quotient / proof representation，不主張人類心理最優性。

Proof-Carrying Code 則提供一個經典相鄰思想：untrusted producer 可以攜帶 proof，host 依指定 safety policy 驗證，而不是因為 producer 自稱安全就信任。SDPE-BEB v1.0 的 proof-carrying Bellman 與其不是同一技術，但共享「discovery / producer 不需被信任，acceptance 由獨立 verifier contract 決定」的設計哲學。

---

# 19. 新的可證偽假說

本文不把 proxy 當 theory completion，而是產生下一輪可測 hypothesis。

## H19.1 — $\Gamma$ representation return hypothesis

對 semantics-preserving representation intervention $g$，定義：

$$
\mathrm{RRC}(g)
=
\frac{\Delta C_D+\Delta C_E+\Delta C_V+\Delta C_{\mathrm{Cert}}}{C_R^{\mathrm{build}}(g)}.
$$

若長期 reuse 後 $\mathrm{RRC}(g)>1$，representation build 有正 lifecycle return。

## H19.2 — $\Sigma$ reuse-depth hypothesis

可重用 knowledge artifact 的價值不只由 artifact size 決定，而受其 reuse horizon $h_{\mathrm{reuse}}$ 控制。

## H19.3 — Certification sparsity hypothesis

在具有良好 screening hierarchy 的 proof-carrying system 中，heavy exact certification 可能集中在極小 boundary set，而大多數 alternatives 可由廉價 safe certificate 關閉。

v1.0 的 383 / 152,695,937 只是一個 existence example，不是 universality proof。

## H19.4 — Context dependence hypothesis

若 agent / task ecology 具有 competing unfinished tasks，局部能力 scalar 的全域排序可能頻繁失效；此假說需跨 benchmark replication。

---

# 20. Methodological consequence：先 discover，再 certify

SDPE-BEB v1.0 對 UCPNP 最有價值的可能不是 $Q=21$，而是一個 research architecture：

$$
\boxed{
\text{cheap / approximate / AI-assisted discovery}
\rightarrow
\text{explicit artifact}
\rightarrow
\text{independent exact or bounded verification}
\rightarrow
\text{scope-limited certification}.
}
$$

這提供未來 AI research 一個比「相信模型輸出」更穩健的方向：允許高生成性、啟發式、甚至不可信 discovery layer；但把 claim acceptance 放在另一個證據 contract。

這種 architecture 和 UCPNP 的本體論平等／非僭越原則也相容：能力強不等於 claim authority 無限。更強的 discovery system 可以提出更多候選，但仍須在其 evidence scope 內接受 certification。

本文只把這一點作為方法論連接，不將規範性 dignity claim 當成 benchmark theorem。

---

# 21. Evidence-level conclusion

本研究目前可支持：

### L2

1. posterior state noncollapse；
2. adaptive scheduling strict gain；
3. exact semantics-preserving quotient；
4. exact dual pruning；
5. exact local-index counterexample；
6. proof-carrying Bellman optimality certification。

### L3

1. runtime / audit replay；
2. cross-version lineage；
3. deterministic release verification；
4. complete Q21 proof reports。

目前不能支持：

### L4+

- 跨不同 AI model 的 cognition invariance；
- 人類 cognitive cost decomposition 的普遍性；
- 歷史智能體預測準確度；
- ASI / posthuman frontier extrapolation。

---

# 22. 結論

本文第一次把 $\mathrm{UCPNP}_{\mathrm{Neo.K}}$ 的部分核心語言放入一個 exact controlled system 中，而不是繼續停留在概念層。

主要結果可壓縮為：

$$
\boxed{
\begin{aligned}
&\text{Truth}\neq\text{Evidence}\neq\text{Certification},\\
&\text{elapsed cost}\neq\text{sufficient cognitive state},\\
&\text{resource allocation policy matters},\\
&\text{semantics-preserving representation change can reduce effective state burden},\\
&\text{reusable exact structure can prune future search},\\
&\text{local scalar priority need not determine global optimum},\\
&\text{untrusted discovery can be separated from exact certification}.
\end{aligned}
}
$$

其中最重要的限制同樣要一起保留：

$$
\boxed{
\text{SDPE-BEB is evidence for mechanism existence, not for universal cognitive equivalence.}
}
$$

因此 Paper 03 現在有比原來更清楚的任務：不是抽象宣告「$\Sigma$ 是知識、$\Gamma$ 是維度」，而是建立可跨 benchmark 比較的 semantics-preserving、cost-accounted、reuse-aware proxy definitions，並設計 $\Sigma$-only、$\Gamma$-only、mixed intervention 的 ablation protocol。

---

# 參考文獻

## External primary / canonical research

1. Russell, S., & Wefald, E. (1991). *Principles of metareasoning*. Artificial Intelligence, 49(1–3), 361–395.
2. Russell, S. J., & Subramanian, D. (1995). *Provably Bounded-Optimal Agents*. Journal of Artificial Intelligence Research, 2, 575–609.
3. Correa, C. G., Ho, M. K., Callaway, F., & Griffiths, T. L. (2020). *Resource-rational Task Decomposition to Minimize Planning Costs*. arXiv:2007.13862.
4. Necula, G. C. (1997). *Proof-Carrying Code*. POPL '97, 106–119.

## Internal canonical lineage

1. Neo.K with Aletheia. *Neo.K Ultimate Cognitive P/NP Problem: Canonical Definition, Scope, and Research Program*, Paper 00 v0.1.
2. Neo.K with Aletheia. *Agent-Relative Tractability: Formalizing Cognitive-P-like and Cognitive-NP-like Operational Regimes*, Paper 01 v0.1.
3. Neo.K with Aletheia. *Cognitive Cost Decomposition and the Evidence–Certification Matrix*, Paper 02 v0.1.
4. Neo.K with Aletheia. *SDPE-BEB v0.6.0 — Posterior-State Bellman and Productivity Envelope*.
5. Neo.K with Aletheia. *SDPE-BEB v0.7.0 — Horizon-Bisimulation Quotient and Exact-Integer Bellman*.
6. Neo.K with Aletheia. *SDPE-BEB v0.8.0 — Dual-Sandwich Action Pruning and Q20 Boundary Closure*.
7. Neo.K with Aletheia. *SDPE-BEB v0.9.0 — Context-Sensitive Occupancy Duality and Certified Action Dominance*.
8. Neo.K with Aletheia. *SDPE-BEB v1.0.0 — Proof-Carrying Bellman Certification and Exact Q21 Closure*.

---

# Appendix A. Dependency hashes

```text
Paper 00
29681bb4ee8195d8d7b82a6ba92b15724bb678a6d9d7e761bbcb266abad86356

Paper 01
f202916f6326570ea1d6d9bd28bd8bb28846cba630cd168526fe8dcf659138ef

Paper 02
33b6b6630a9ed789535c074a11df456cc483ac8c5c86f0194d01a65f9179e4e3

SDPE-BEB v1.0.0 outer release
834b99eaa24b073fdf62208c54ed2a8490a8adaa7b554446b79a6e725759e179
```

# Appendix B. Machine-readable companion

本文 machine-readable experiment summary：

`05_UCPNP_SDPE_Mapping_Experiment_Report_v0.1.json`

其數值只重述 canonical lineage artifacts，不另創 benchmark result。
