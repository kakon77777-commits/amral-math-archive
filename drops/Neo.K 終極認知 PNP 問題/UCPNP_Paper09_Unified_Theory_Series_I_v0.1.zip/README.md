# UCPNP Paper 09 v0.1 — Series I Unified Synthesis

Main paper:
- `09_UCPNP_Unified_Theory_v0.1.md`

Supporting artifacts:
- `09_UCPNP_Claim_Matrix_v0.1.md`
- `09_UCPNP_Master_Schema_v0.1.json`
- `09_UCPNP_Evidence_Passport_Schema_v0.1.json`
- `09_UCPNP_Series_I_Index_v0.1.md`
- `09_UCPNP_Series_II_Research_Program_v0.1.md`
- `09_UCPNP_Lineage_SHA256_v0.1.json`
- `verify_p09_structure.py`
- `09_UCPNP_Source_Integrity_v0.1.json`
- `CHECKSUMS.sha256`

Status:
Series I unified synthesis and handoff. The next default phase is experimental Series II, not unconstrained expansion of foundational terminology.
