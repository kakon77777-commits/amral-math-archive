# UCPNP Paper 09 structural checks

# T5.1: three layers can vary independently.
capability_without_cert = {"can":1,"cert":0,"may":1}
cert_without_discovery = {"discover":0,"verify":1,"cert":1}
capability_without_permission = {"can":1,"cert":1,"may":0}
assert capability_without_cert["can"] != capability_without_cert["cert"]
assert cert_without_discovery["discover"] != cert_without_discovery["cert"]
assert capability_without_permission["can"] != capability_without_permission["may"]

# T9.1: same performance gain can arise from different mechanisms.
systems = {
    "Sigma":{"before":2,"after":1},
    "Gamma":{"before":2,"after":1},
    "Hardware":{"before":2,"after":1},
}
gains = {k:v["before"]-v["after"] for k,v in systems.items()}
assert len(set(gains.values())) == 1
assert len(systems) == 3

# T11.1: crossed domain ordering cannot be faithfully represented by one strict total order.
A = {"D1":2,"D2":1}
B = {"D1":1,"D2":2}
assert A["D1"] > B["D1"]
assert B["D2"] > A["D2"]

# T20.1: distinct raw/cert/admissible sets.
raw = {"a","b"}
cert = {"b","c"}
adm = {"c"}
assert "a" in raw and "a" not in cert
assert "b" in cert and "b" not in adm
# c is admissible in policy vocabulary but can be unavailable to current agent in a separate instance.
policy_adm = {"c"}
current_raw = set()
assert "c" in policy_adm and "c" not in current_raw

# Evidence passport non-interchangeability.
p1 = {"formula":"Gamma>0","scope":"finite exact benchmark","level":"exact","status":"verified"}
p2 = {"formula":"Gamma>0","scope":"future ASI scenario","level":"forecast","status":"unresolved"}
assert p1["formula"] == p2["formula"]
assert (p1["scope"],p1["level"],p1["status"]) != (p2["scope"],p2["level"],p2["status"])

print("UCPNP Paper 09 structural checks: PASS")
