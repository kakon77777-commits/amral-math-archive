# Historical Cognitive Tractability Frontier：智能體、算法、表示與硬體的歷史可解性邊界

**English title:** *Historical Cognitive Tractability Frontier: Separating Discovery, Method Transport, Execution, Verification, and Certification Across Computing History*  
**Series:** Neo.K Ultimate Cognitive P/NP Problem  
**Paper:** 04  
**Version:** v0.1  
**Author:** Neo.K  
**Collaborative formalization:** Aletheia  
**Date:** 2026-08-15  
**Status:** Formal-methodology paper with documentary historical calibration. Historical case-study claims are bounded estimates unless explicitly marked as reproduced.

---

# Canonical non-identity and scope statement

本文研究的是：

$$
\boxed{
\mathrm{UCPNP}_{\mathrm{Neo.K}}
}
$$

中的歷史智能體可解性，不研究或聲稱解決標準計算複雜度問題：

$$
P\stackrel{?}{=}NP.
$$

本文亦不主張：

1. 歷史硬體性能與歷史智能能力完全同構；
2. FLOPS 可以代表一般認知能力；
3. 一台機器「能執行」某演算法，等於當代人類「能自行發現」該演算法；
4. 將未來算法、索引、模型、proof graph 或答案送回過去，不需要記錄其外部建造成本；
5. 由一個有限案例直接預測後人類、AGI 或 ASI 的一般認知發展。

本文研究的是更窄而可稽核的問題：

> 對固定任務、固定成功條件與明示反事實場景，某一歷史年代的智能體—知識—表示—方法—硬體組合，能否完成某一特定認知／計算階段？

因此本文核心原則為：

$$
\boxed{
\text{historical executable}
\neq
\text{historically discoverable}
\neq
\text{historically practical}.
}
$$

---

# 摘要

UCPNP Paper 00 將智能體歷史狀態寫為：

$$
\Xi_y
=
(A_y,K_y,\Sigma_y,\Gamma_y,H_y,M_y,N_y,E_y),
$$

並預留：

$$
Y_{\mathrm{idea}},
\quad
Y_{\mathrm{discover}},
\quad
Y_{\mathrm{execute}},
\quad
Y_{\mathrm{practical}},
\quad
Y_{\mathrm{commodity}}.
$$

Paper 02 進一步把成本拆為 Representation、Discovery、Construction、Execution、Verification、Certification 等階段；Paper 03 又把知識凝結 $\boldsymbol\Sigma$ 與表示轉換 $\boldsymbol\Gamma$ 分離。本文據此建立 **Historical Cognitive Tractability Frontier, HCTF**。

HCTF 的核心不是為每一個問題指定單一「可算年份」，而是在固定 task contract 與 counterfactual import contract 下，分別估計各 phase 的最早可行年份。本文正式區分 endogenous history、method transport、precomputed-artifact transport 與 result/certificate transport；證明不同 transport scenario 不可互換，並建立 Import Conservation 原則：未來知識或 artifact 被送回過去，只能將成本移出歷史智能體的內部 ledger，而不能把成本從完整研究生命週期中刪除。

本文亦證明：單一 FLOPS 標量不足以決定歷史可解性；對具有記憶體、I/O、通訊、精度或 branch-heavy bottleneck 的 workload，兩台 peak FLOPS 相同的機器可以具有相反的可行性。故 HCTF 採多維 workload signature 與 historical machine envelope。

最後，本文以 SDPE-BEB v1.0 的 proof-carrying Bellman 計算作第一個 calibrated case study。根據 committed lineage，該方法涉及約 $21.56$ million guide states、$152.70$ million alternative actions、數百 MB 級可再生 numerical guide artifacts、固定寬度最高 1024-bit exact tie arithmetic，以及僅 383 個 heavy arbitrary-precision residual cases。歷史硬體資料顯示：1976 Cray-1 的主記憶上限約為 $1,048,576$ 個 64-bit words，僅約 8 MiB，故在「全部 guide 必須 in-core」的實作模型下形成直接容量下界；1985 Cray-2 的大型配置已達約 2 GB memory 與約 1.9 GFLOP/s peak，首次進入「容量上可能裝得下」的 sampled milestone；1997 ASCI Red 已達 1.068 TFLOP/s Linpack、約 1.212 TB distributed memory；2002 Earth Simulator 更達 35.86 TFLOP/s、約 10 TB memory。這些數據只支持 method-transport 的硬體可行性區間，不支持把 v1.0 的實際發現年代倒推到 1980 年代。

本文因此提出一個更一般的結論：

$$
\boxed{
\text{歷史認知可解性是一個多軸、分階段、反事實依賴的 frontier，
而不是單一硬體年份。}
}
$$

---

# 1. 從 Dynamic Solvability 2.5 到 HCTF

早期《P vs. NP 問題的動態可解性理論 2.5》已提出：與其只問「是否存在算法」，也可以問「何時、何地、何種智能體達到實用可解狀態」。

本文保留該問題意識，但做四項修正。

## 1.1 不繼承未重現的歷史準確率宣稱

早期 2.5 曾提出基於歷史案例的高解釋率與未來預測。本文不直接繼承該數值；除非原始資料、標註規則、模型與重算流程重新建立，否則這些舊數字只作思想史來源，不作 HCTF 實證結論。

## 1.2 不把「技術進步」壓成單一時間函數

歷史能力至少包含：

$$
H_y,\quad
M_y,\quad
K_y,\quad
\boldsymbol\Sigma_y,\quad
\boldsymbol\Gamma_y,\quad
N_y,\quad
E_y.
$$

硬體、算法、表示、知識、協作與環境並不以同一速率增長。

## 1.3 把「發現」與「執行」分開

即使某時代的硬體足以執行未來算法，也不表示當時已有足夠：

$$
K_y+\boldsymbol\Sigma_y+\boldsymbol\Gamma_y+M_y
$$

自行發現該算法。

## 1.4 把反事實輸入列入 ledger

「把未來演算法送回過去」不是普通歷史問題，而是 intervention。

因此必須明示：

$$
\boxed{
\text{what is transported?}
}
$$

---

# 2. 歷史狀態與任務契約

固定任務契約：

$$
\mathfrak T
=
(X,Y,\mathsf{Valid},\mathsf{Verify},\mathsf{Cert},\delta),
$$

其中 $\delta$ 是成功可靠度／誤差規則。

歷史年份 $y$ 的智能體狀態：

$$
\boxed{
\Xi_y
=
(A_y,K_y,\boldsymbol\Sigma_y,\boldsymbol\Gamma_y,H_y,M_y,N_y,E_y).
}
$$

另定義該年代對研究任務可投入的資源 budget：

$$
\mathbf B_y
=
(B_T,B_E,B_M,B_Q,B_C,B_{\mathrm{comm}},B_{\mathrm{risk}},\ldots).
$$

HCTF 不把 $H_y$ 等同 $\Xi_y$。

---

# 3. 四種 counterfactual transport scenario

定義 scenario 變量：

$$
s\in
\{
\mathsf S_0,\mathsf S_1,\mathsf S_2,\mathsf S_3
\}.
$$

## 3.1 $\mathsf S_0$ — Endogenous History

只允許在年份 $y$ 已實際可取得的：

$$
(A_y,K_y,\Sigma_y,\Gamma_y,H_y,M_y,N_y,E_y).
$$

不從未來注入算法或 artifact。

這是最接近「當時的人自己能不能做到」的問題。

## 3.2 $\mathsf S_1$ — Method Transport

允許從未來輸入：

- 算法說明；
- source-level method；
- representation design；
- theorem statement；
- proof strategy；

但**不輸入 instance-specific precomputed state table、guide、index、最終答案或 final certificate**。

此 scenario 主要回答：

> 如果當代人已經知道「怎麼做」，當代硬體與軟體工程能不能把它實作並跑完？

## 3.3 $\mathsf S_2$ — Precomputed Artifact Transport

除 method 外，允許輸入：

- 預計算索引；
- lookup table；
- compiled policy；
- numerical guide；
- proof DAG；
- certificate library。

但不直接輸入目標 instance 的 final answer/certificate。

此 scenario 主要測：

> 當 expensive discovery/build cost 被外部化後，當代系統能不能使用這些 artifact？

## 3.4 $\mathsf S_3$ — Result / Certificate Transport

直接輸入：

- final answer；
- witness；
- final proof；
- final certificate。

此 scenario 幾乎只測：

$$
C_V+C_{\mathrm{Cert}},
$$

不能被稱為歷史 discovery 或 solving frontier。

---

# 4. Import Conservation

令 $\mathbf I_s$ 為 scenario $s$ 中由外部時間點輸入的 information/artifact set。

若 artifact $g$ 的建造成本為：

$$
\mathbf C_{\mathrm{build}}(g),
$$

而歷史智能體只支付使用成本：

$$
\mathbf C_{\mathrm{use}}(g),
$$

則 local historical ledger 可寫成：

$$
\mathbf C_{\mathrm{local}}
=
\mathbf C_{\mathrm{use}}(g),
$$

但完整 counterfactual lifecycle ledger 必須是：

$$
\boxed{
\mathbf C_{\mathrm{world}}
=
\mathbf C_{\mathrm{build}}(g)
+
\mathbf C_{\mathrm{transport}}(g)
+
\mathbf C_{\mathrm{use}}(g).
}
$$

## T4.1 — Import Conservation Theorem

若一個 transported object $g$ 在歷史時點 $y$ 尚不存在，而其生成需要非零成本：

$$
\mathbf C_{\mathrm{build}}(g)>\mathbf 0,
$$

則將 $g$ 注入 $y$ 最多能使歷史智能體的 local cost 降低；不能推出完整 lifecycle cost 中該建造成本為零。

**證明。** transported artifact 改變的是成本歸屬位置，而不是 artifact 的因果生成史。若從完整 ledger 刪除 $\mathbf C_{\mathrm{build}}(g)$，則同一 artifact 在 $\mathsf S_2$ 中會被錯誤視為無因生成，違反 Paper 02 的 precomputation conservation。$\square$

---

# 5. Phase-specific historical frontiers

定義 phase set：

$$
\mathcal P
=
\{
R,D,C,E,V,\mathrm{Cert}
\},
$$

分別代表 Representation、Discovery、Construction、Execution、Verification、Certification。

對 phase $p$ 與 scenario $s$：

$$
\boxed{
Y_p^{(s)}(x)
=
\inf
\left\{
y:
\rho_p(x\mid\Xi_y,\mathbf B_y,s)\le1
\right\}.
}
$$

因此歷史 tractability 不再是一個年份，而是：

$$
\boxed{
\mathbf Y^{(s)}(x)
=
(
Y_R^{(s)},
Y_D^{(s)},
Y_C^{(s)},
Y_E^{(s)},
Y_V^{(s)},
Y_{\mathrm{Cert}}^{(s)}
).
}
$$

摘要年份可另外定義：

$$
Y_{\mathrm{idea}},
\quad
Y_{\mathrm{discover}},
\quad
Y_{\mathrm{execute}},
\quad
Y_{\mathrm{practical}},
\quad
Y_{\mathrm{commodity}},
$$

但它們必須由 phase vector 投影而來，不得取代 phase vector。

---

# 6. 歷史日期沒有普適全序

直覺上常有人假設：

$$
Y_{\mathrm{idea}}
<
Y_{\mathrm{discover}}
<
Y_{\mathrm{execute}}
<
Y_{\mathrm{practical}}.
$$

這不是普遍定理。

## T6.1 — No Universal Temporal Ordering

不存在對所有任務都成立的固定全序：

$$
Y_{\mathrm{discover}}
\stackrel{?}{\le}
Y_{\mathrm{execute}}^{(\mathsf S_1)}
$$

或其反序。

**證明。**

構造 A：算法在硬體足夠前被理論發現。則：

$$
Y_{\mathrm{discover}}
<
Y_{\mathrm{execute}}.
$$

構造 B：硬體已足以執行某未來算法，但算法多年後才被發現；在 method-transport counterfactual 下：

$$
Y_{\mathrm{execute}}^{(\mathsf S_1)}
<
Y_{\mathrm{discover}}^{(\mathsf S_0)}.
$$

故無普適全序。$\square$

這也是為什麼：

$$
\boxed{
\text{「哪一年能算？」}
}
$$

必須先問是哪一種 scenario。

---

# 7. Cumulative historical capability envelope

某一台歷史機器退役，不代表文明失去其全部方法。

定義截至年份 $y$ 的可恢復文明能力集合：

$$
\mathcal R_{\le y}
=
\bigcup_{\tau\le y}
\mathcal R_\tau,
$$

其中只納入可由 archive、source、文件或 surviving practice 恢復的能力。

## T7.1 — Cumulative Envelope Monotonicity under Retention

若：

$$
\mathcal R_{\le y}
\subseteq
\mathcal R_{\le y+1},
$$

且資源 availability 不下降到使舊方法物理不可重建，則累積可行任務集合：

$$
\mathcal F_{\le y}
\subseteq
\mathcal F_{\le y+1}.
$$

**證明。** $y+1$ 的 cumulative repertoire 至少包含 $y$ 的全部可恢復策略與資源，因此任何 $y$ 可行策略仍是 $y+1$ 的候選。$\square$

注意：這是 **retention model** 下的 theorem，不是聲稱現實文明永不遺失知識。

---

# 8. Hardware envelope 不能壓成 FLOPS

定義 workload signature：

$$
\boxed{
\mathcal W
=
(
M_{\mathrm{peak}},
B_{\mathrm{mem}},
O_{\mathrm{int}},
O_{\mathrm{fp}},
W_{\mathrm{int}},
I/O,
B_{\mathrm{branch}},
D_{\mathrm{dep}},
P_{\mathrm{par}},
C_{\mathrm{comm}}
).
}
$$

其中至少包括：

- peak live memory；
- memory bandwidth / access pattern；
- integer operations；
- floating-point operations；
- exact integer width；
- I/O；
- branch irregularity；
- dependency depth；
- parallelizability；
- communication cost。

## T8.1 — FLOPS Insufficiency

不存在只依賴 peak FLOPS $F$ 的函數：

$$
\chi(F)\in\{0,1\}
$$

可以對所有 workload 正確判斷歷史可行性。

**證明。** 取兩台 peak FLOPS 相同的機器 $H_1,H_2$，但：

$$
M(H_1)<M_{\mathrm{req}}\le M(H_2).
$$

對要求全部 active state in-core 的 workload，$H_1$ 不可行而 $H_2$ 可行。由於兩者 $F$ 相同，任何只看 $F$ 的分類器給出相同輸出，必錯至少一個。$\square$

因此 TOP500 Linpack 可作 optimistic compute-capacity marker，但不能單獨決定 SDPE-BEB 這種 irregular memoized workload 的真實 runtime。

---

# 9. Necessary lower bounds and feasibility certificates

HCTF 將歷史判定分成「必要條件」與「充分／實證條件」。

## 9.1 In-core memory lower bound

若固定實作模型要求：

$$
M_{\mathrm{live}}>M(H_y),
$$

則：

$$
\boxed{
\text{該 in-core implementation 在 }H_y\text{ 上不可能。}
}
$$

這不代表所有 out-of-core / recomputation algorithms 不可能。

## 9.2 Throughput optimism bound

若不可省略的 operation count 為 $O_{\min}$，而 machine optimistic peak throughput 為 $P_y$：

$$
T_{\min}
\ge
\frac{O_{\min}}{P_y}.
$$

但對 branch-heavy、memory-bound、通信密集 workload，peak Linpack/FLOPS 只能作非常樂觀的下界。

## 9.3 Architecture-aware plausibility

只有當 workload 的：

$$
(M,B,W,I/O,P_{\mathrm{par}},C_{\mathrm{comm}})
$$

和 historical architecture 一起考慮後，才可以提升到「plausible execution」。

## 9.4 Reproduction

最高實證等級是：

- historical hardware；
- cycle-accurate / architecture-faithful emulator；
- source port；
- preserved toolchain；

真正完成 replay。

---

# 10. HCTF evidence ladder

本文定義歷史可計算性證據階梯：

### H0 — Documentary

只有硬體、軟體、算法史料。

### H1 — Necessary-resource bound

例如 memory lower bound、address-space bound、precision bound。

### H2 — Architecture-aware simulation

把 workload signature 映射到 historical architecture，估算 memory traffic、branching、communication 與 parallelism。

### H3 — Historical-code port / emulator reproduction

將 source port 到可信歷史 emulator 或相當環境。

### H4 — Historical-hardware reproduction

在實際歷史硬體或保存系統上重現。

因此：

$$
\boxed{
H0/H1
\not\Rightarrow
H4.
}
$$

---

# 11. 第一批歷史硬體 calibration anchors

以下數據只作 documentary anchors，不代表已實際 port SDPE-BEB。

## 11.1 Cray-1 — 1976

CRAY-1 Hardware Reference Manual 記載：

$$
1{,}048{,}576
$$

個 64-bit data words 的最大 main memory。

換算約：

$$
8\ \mathrm{MiB}.
$$

Smithsonian 保存的 Cray-1 brochure 則記載其可執行超過 80 million floating-point operations per second；其他歷史資料常列更高的 peak vector figure。本文不依賴哪一個 FLOPS 數字，因為 case study 的第一個障礙是 memory。

## 11.2 Cray-2 — 1985

歷史博物館／保存資料記載大型 Cray-2 configuration 可達約：

$$
2\ \mathrm{GB}
$$

memory，peak 約：

$$
1.9\ \mathrm{GFLOP/s}.
$$

它因此成為本文 sampled milestones 中第一個「數百 MB guide artifacts 在容量上可 in-core」的候選。

但 Cray-2 是 vector supercomputer；SDPE-BEB 的 irregular state hashing、branching、memoization 與 big-integer workload 並非其最自然 workload。故只能標：

$$
\boxed{
\text{capacity-positive candidate}
}
$$

而非已證可實用重現。

## 11.3 GNU MP — 1991

GNU MP 官方資料指出第一版 GMP 發布於 1991 年。arbitrary-precision arithmetic 在此之前當然可以自行實作，但 GMP 類 library 降低了 research engineering cost。

這說明：

$$
Y_{\mathrm{execution}}
$$

不只依賴硬體，也依賴：

$$
M_y=\text{available software/method stack}.
$$

## 11.4 Beowulf — 1994–1997

NASA 記錄第一個 Beowulf Linux commodity cluster 在 1994 年於 Goddard 建成；NASA 後續教程與 1997 年 kit/distribution 使 commodity cluster practice 更容易複製。

這個節點的意義主要不是 peak performance，而是：

$$
\boxed{
\text{HPC access cost下降}
}
$$

因此對：

$$
Y_{\mathrm{practical}},
\quad
Y_{\mathrm{commodity}}
$$

比對純技術 $Y_{\mathrm{execute}}$ 更重要。

## 11.5 ASCI Red — 1997

TOP500 記錄 ASCI Red 在 1997 年以：

$$
1.068\ \mathrm{TFLOP/s}
$$

Linpack 成為第一台 teraflop-class TOP500 #1 系統。

其初始配置約有：

$$
1{,}212\ \mathrm{GB}
$$

distributed memory。

因此對數百 MB 級 state artifacts，memory capacity 已具有數千倍量級的 headroom；真正問題轉為 distributed-memory layout、communication 與 software implementation。

## 11.6 Earth Simulator — 2002

TOP500 記錄 Earth Simulator：

$$
5120\ \text{processors},
$$

$$
R_{\max}=35.86\ \mathrm{TFLOP/s},
$$

並有約：

$$
10\ \mathrm{TB}
$$

memory。

到這一節點，對本文 SDPE-BEB v1.0 case study，硬體容量本身已不是主要不確定性；representation、software engineering 與 irregular workload mapping 才是。

---

# 12. Case study：SDPE-BEB v1.0 的歷史逆向

本文採用 SDPE-BEB v1.0 committed lineage 的以下 workload facts：

$$
N_{\mathrm{guide\ states}}
=
21{,}560{,}197,
$$

$$
N_{\mathrm{alternative\ actions}}
=
152{,}695{,}937.
$$

四個 numerical guide build products 合計為數百 MB 級，未被收進 canonical release，因為它們可由 source 重建。

proof-carrying verification 分層：

$$
121{,}001{,}935
$$

個 dyadic strict separations，

$$
5{,}149{,}320
$$

個 fixed-width exact ties，

$$
26{,}544{,}299
$$

個 parametric-dual closures，

以及：

$$
383
$$

個 heavy arbitrary-precision residual cases。

固定寬度 tie certificate 的 arithmetic envelope 為 1024-bit，而被證明的 numerator magnitude bound 低於 1024 bits。

---

# 13. SDPE-BEB v1.0 的四種歷史問題

## 13.1 問題 A：1976 是否能執行「現代 final method」？

若要求 numerical guide 全部 in-core，Cray-1 約 8 MiB memory 明顯小於數百 MB artifact。

因此：

$$
\boxed{
\text{Cray-1 fails the in-core guide-capacity condition.}
}
$$

這是 H1 necessary-resource result。

它**不證明**不存在重新計算、分批、磁碟外存或不同 representation 的 1976 implementation。

## 13.2 問題 B：1985 Cray-2 呢？

2 GB memory 已大於數百 MB guide size。

所以 sampled historical milestone 首次進入：

$$
\boxed{
M(H_y)\ge M_{\mathrm{guide}}.
}
$$

但我們尚未把 branch-heavy hash/memo workload port 到 Cray-2，也沒有 cycle-accurate benchmark。

因此正確結論是：

$$
\boxed{
\text{1985 is a capacity-positive plausibility point, not a reproduction date.}
}
$$

## 13.3 問題 C：1997 ASCI Red 呢？

1.212 TB distributed memory 與 teraflop-class performance 表示 pure capacity headroom 已非常大。

因此在 $\mathsf S_1$ Method Transport 下，可以給出更強的 upper plausibility statement：

> 若有合適的 distributed implementation，SDPE-BEB v1.0 final method 的 resource scale 不再顯示明顯硬體容量障礙。

仍不能說：

> 1997 的研究者會自然發現 posterior quotient、parametric dual、proof-carrying Bellman 這整條方法。

## 13.4 問題 D：2002 Earth Simulator 呢？

10 TB memory 與 35.86 TFLOP/s 使 raw hardware capacity 更寬裕。

但 Earth Simulator 是 vector architecture，故對 irregular workloads，Linpack 數字不能直接換算 wall-clock。

---

# 14. 第一個 sampled historical bracket

在本文只取 Cray-1、Cray-2、ASCI Red、Earth Simulator 這四個 sampled anchors 的前提下，可以形成：

### In-core capacity lower observation

1976 Cray-1：

$$
M_{\max}\ll M_{\mathrm{guide}}.
$$

### First sampled capacity-positive candidate

1985 Cray-2：

$$
M_{\max}>M_{\mathrm{guide}}.
$$

### Strong national-HPC plausibility anchor

1997 ASCI Red：

$$
M_{\max}\gg M_{\mathrm{guide}}.
$$

### Capacity-abundant anchor

2002 Earth Simulator。

因此本文**不**宣稱精確：

$$
Y_{\mathrm{execute}}=1985.
$$

而只宣稱：

$$
\boxed{
\text{在本次 sampled milestones 中，
method-transport 的 in-core capacity transition 發生在 Cray-1 與 Cray-2 之間。}
}
$$

若要求真正 $Y_{\mathrm{execute}}$，必須補完 1976–1985 間其他系統與 architecture-aware reproduction。

---

# 15. Discovery frontier 為何不能由硬體倒推

對 SDPE-BEB v1.0：

$$
Y_E^{(\mathsf S_1)}
$$

問的是「final method 已知時，歷史系統能不能執行」。

但：

$$
Y_D^{(\mathsf S_0)}
$$

問的是歷史智能體能不能自己完成：

$$
\text{posterior-state modeling}
\rightarrow
\text{Bellman}
\rightarrow
\text{bisimulation quotient}
\rightarrow
\text{exact integerization}
\rightarrow
\text{dual pruning}
\rightarrow
\text{context-sensitive occupancy}
\rightarrow
\text{proof-carrying certification}.
$$

這些是：

$$
K+\Sigma+\Gamma+M
$$

的歷史問題，不是 FLOPS 問題。

Sherry 與 Thompson 對 113 個 algorithm families 的歷史分析顯示，algorithmic improvement 本身具有高度異質、跳躍式的進步；對部分問題，其改善幅度可與甚至超過 hardware improvement。這支持 HCTF 將：

$$
\boxed{
\text{algorithmic/method progress}
}
$$

與：

$$
\boxed{
\text{hardware progress}
}
$$

分開記錄，而不是全部折成「計算機變快」。

---

# 16. Historical discovery dataset schema

未來每個 case 建議保存：

```text
task_id
task_contract_version
input_scale
year
scenario
agent_population
knowledge_sources
available_algorithms
available_representations
available_software
available_hardware
network_collaboration
external_information
phase_cost_R
phase_cost_D
phase_cost_C
phase_cost_E
phase_cost_V
phase_cost_Cert
workload_signature
evidence_level_H0_H4
result_status
uncertainty
sources
```

---

# 17. 認知歷史不是「英雄排行榜」

HCTF 的研究單位是：

$$
\boxed{
(x,\Xi_y,\mathbf B_y,s)
}
$$

而不是：

$$
\boxed{
\text{Person }A\text{ has intelligence score }z.
}
$$

同一人物、AI、團隊或文明可以在不同問題域具有不同 frontier。

因此：

$$
\boxed{
Y^\star(x,A)
<
Y^\star(x,B)
}
$$

只表示在明示 task / resource contract 下 $A$ 較早達到該 tractability threshold。

它不推出：

$$
\operatorname{Dignity}(A)>
\operatorname{Dignity}(B),
$$

也不推出：

$$
A
\text{ 是更高階存在}.
$$

這使 HCTF 可以研究後人類與 ASI 的能力邊界，而不必建立存在論階級。

---

# 18. 對未來智能體預判的規則

未來 agent forecasting 必須先通過歷史 backtest。

本文提出：

## Rule F1 — Backtest before extrapolation

若模型不能在已知歷史 case 中區分：

$$
Y_D,\quad Y_E,\quad Y_V,\quad Y_{\mathrm{Cert}},
$$

則不得直接拿它預測 ASI 的 general tractability frontier。

## Rule F2 — Scenario lock

所有未來 prediction 必須明示：

$$
\mathsf S_0,\mathsf S_1,\mathsf S_2,\mathsf S_3
$$

或新的 import contract。

## Rule F3 — Capability claim scope

由某一領域的 frontier expansion，只能推出該領域的能力變化。

不能推出：

$$
\boxed{
\text{local capability superiority}
\Rightarrow
\text{global ontological superiority}.
}
$$

---

# 19. 可證偽研究假說

## H19.1 — Transport Gap Hypothesis

對大量非平凡研究任務：

$$
\left|
Y_D^{(\mathsf S_0)}
-
Y_E^{(\mathsf S_1)}
\right|
$$

可能是顯著且具領域差異的。

## H19.2 — Representation-Lag Hypothesis

某些任務的主要歷史瓶頸不是 $H_y$，而是：

$$
Y_R
\quad\text{或}\quad
Y_\Gamma.
$$

也就是硬體早已存在，但有效 representation 尚未出現。

## H19.3 — Software-Stack Threshold Hypothesis

arbitrary precision library、compiler、parallel runtime、debugger、version control 等工具可能使：

$$
Y_{\mathrm{practical}}
-
Y_{\mathrm{execute}}
$$

大幅縮短，即使硬體峰值變化不大。

## H19.4 — Collaboration Frontier Hypothesis

Beowulf / open-source / networked collaboration 類基礎設施的主要影響可能落在：

$$
N_y+M_y
$$

而不只是 $H_y$。

## H19.5 — Discovery Cost Dominance Hypothesis

對高抽象研究任務：

$$
C_D+C_R
$$

可能遠大於 final：

$$
C_E+C_V.
$$

SDPE-BEB v1.0 是候選 existence example，但尚不是跨領域證明。

---

# 20. 與外部研究的定位

本文與 algorithmic progress history 相鄰。Sherry 與 Thompson 的研究重建數十年算法家族的改進史，明確顯示 hardware progress 並不是 computing progress 的唯一來源。

本文與 supercomputing history 亦相鄰，但目的不同：TOP500、NASA、Computer History Museum 等來源提供的是 hardware / software capability anchors；HCTF 研究的是這些 anchors 如何與 task-specific cognition / method / representation phases 對齊。

本文與 bounded optimality / resource-rationality 的差異，在於 HCTF 額外加入歷史年份、transport counterfactual、knowledge condensation、representation generation 與 certification phase。

---

# 21. 本文 theorem / definition 清單

## Definitions

- D2.1 Historical Agent State $\Xi_y$；
- D3.1–D3.4 Four Transport Scenarios；
- D5.1 Phase-specific Historical Frontier；
- D7.1 Cumulative Historical Capability Envelope；
- D8.1 Workload Signature；
- D10.1 HCTF Evidence Ladder。

## Theorems

- T4.1 Import Conservation；
- T6.1 No Universal Temporal Ordering；
- T7.1 Cumulative Envelope Monotonicity under Retention；
- T8.1 FLOPS Insufficiency。

## Necessary-bound propositions

- P9.1 In-core Memory Lower Bound；
- P9.2 Throughput Optimism Bound。

---

# 22. 正典結論

本文將「某年代的人能不能算出某結果」拆成至少四個不同問題：

$$
\boxed{
\begin{aligned}
&\text{當時是否能想到／表示？}\\
&\text{當時是否能自行發現方法？}\\
&\text{若方法已知，當時是否能執行？}\\
&\text{若結果已知，當時是否能驗證／認證？}
\end{aligned}
}
$$

因此：

$$
\boxed{
\text{historical cognition}
\neq
\text{historical hardware}.
}
$$

而：

$$
\boxed{
\text{historical execution}
\neq
\text{historical discovery}.
}
$$

HCTF 的研究價值不在於替每個年代打一個「智能分數」，而是重建：

$$
\boxed{
\text{哪些 bottleneck 在什麼時候被什麼機制解除。}
}
$$

這使我們能在不宣稱人類、AI、後人類、ASI 完全同構的前提下，研究智能體能力前沿如何被：

$$
H,\quad
M,\quad
K,\quad
\boldsymbol\Sigma,\quad
\boldsymbol\Gamma,\quad
N,\quad
E
$$

共同推動。

這也是 UCPNP 從「認知 P/NP」走向真正 **智能體計算與認知歷史科學** 的第一個方法論版本。

---

# 參考文獻

## External primary / authoritative sources

1. Sherry, Y., & Thompson, N. C. (2021). *How Fast Do Algorithms Improve?* Proceedings of the IEEE, 109(11), 1768–1777. DOI: 10.1109/JPROC.2021.3107219.
2. Cray Research, Inc. *CRAY-1 Hardware Reference Manual*, document 2240004. Maximum memory: 1,048,576 64-bit data words.
3. Smithsonian National Museum of American History. *Cray-1 Computer System Brochure*. Historical brochure metadata records execution above 80 million floating-point operations per second.
4. Computer History Museum. *Smaller and Faster: The Cray-2 and 3*. Historical Cray-2 documentation.
5. GNU MP Project. *The GNU MP Bignum Library*. Official project history: first GMP release in 1991.
6. NASA Goddard / NASA Advanced Supercomputing. Historical documentation of the first Beowulf commodity Linux cluster (1994) and subsequent dissemination.
7. TOP500. *ASCI Red: Sandia National Laboratory*. 1997 system record: 1.068 TFLOP/s Linpack; 1,212 GB distributed memory.
8. TOP500. *The Earth Simulator*. 2002 system record: 5,120 processors; 35.86 TFLOP/s Linpack; approximately 10 TB memory.

## Internal canonical lineage

9. Neo.K. *P vs. NP 問題的動態可解性理論 2.5：計算機歷史的實證框架*.
10. Neo.K with Aletheia. *The Neo.K Ultimate Cognitive P/NP Problem: Canonical Definition, Scope, and Research Program* (Paper 00, v0.1).
11. Neo.K with Aletheia. *Agent-Relative Tractability* (Paper 01, v0.1).
12. Neo.K with Aletheia. *Cognitive Cost Decomposition and the Evidence–Certification Matrix* (Paper 02, v0.1).
13. Neo.K with Aletheia. *Knowledge Condensation and Representation Generation* (Paper 03, v0.1).
14. Neo.K with Aletheia. *SDPE-BEB as a Controlled Micro-Model of UCPNP* (Paper 05, v0.1).
15. SDPE-BEB v1.0.0 — *Proof-Carrying Bellman Certification & Exact Q21 Closure*.

---

# Appendix A. Canonical symbols

| Symbol | Meaning |
|---|---|
| $\Xi_y$ | historical agent state |
| $\mathbf B_y$ | historical resource budget |
| $\mathsf S_0$ | endogenous-history scenario |
| $\mathsf S_1$ | method-transport scenario |
| $\mathsf S_2$ | precomputed-artifact transport |
| $\mathsf S_3$ | result/certificate transport |
| $Y_p^{(s)}$ | earliest feasible year for phase $p$ under scenario $s$ |
| $\mathbf Y^{(s)}$ | phase-frontier vector |
| $\mathcal W$ | workload signature |
| $\mathcal R_{\le y}$ | cumulative recoverable civilizational repertoire |
| H0–H4 | historical tractability evidence levels |

---

# Appendix B. Minimal HCTF audit checklist

任何「某年代已能完成任務 $x$」的 claim，至少回答：

1. 任務版本與 input scale 是什麼？
2. 是 $\mathsf S_0,\mathsf S_1,\mathsf S_2$ 還是 $\mathsf S_3$？
3. 從未來 transport 了哪些資訊？
4. transported object 的 build cost 放在哪裡？
5. workload signature 是什麼？
6. peak live memory 是多少？
7. historical hardware memory / address / I/O / precision 是否足夠？
8. FLOPS 是否只是 optimistic proxy？
9. 當時是否有 compiler / arbitrary-precision / parallel-runtime 等必要工具？
10. claim 是 H0、H1、H2、H3 或 H4？
11. 是「能執行」還是「能自行發現」？
12. uncertainty 與尚未排除的 alternative implementation 是什麼？
