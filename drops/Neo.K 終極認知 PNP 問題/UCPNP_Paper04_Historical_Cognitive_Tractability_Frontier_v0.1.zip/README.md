# UCPNP Paper 04 v0.1 Release Pack

Contents:
- `04_UCPNP_Historical_Cognitive_Tractability_Frontier_v0.1.md`
- `04_UCPNP_Claim_Matrix_v0.1.md`
- `04_UCPNP_Historical_Anchors_v0.1.csv`
- `04_UCPNP_Source_Integrity_v0.1.json`
- `CHECKSUMS.sha256`

Scope:
Historical Cognitive Tractability Frontier (HCTF), with explicit transport scenarios, phase-specific historical frontiers, multi-resource workload signatures, and a documentary SDPE-BEB v1.0 calibration case.

Important:
This paper does not assert that SDPE-BEB v1.0 was historically discoverable in 1985/1997/2002. Historical hardware anchors calibrate method-transport execution plausibility only unless stronger reproduction evidence is provided.
