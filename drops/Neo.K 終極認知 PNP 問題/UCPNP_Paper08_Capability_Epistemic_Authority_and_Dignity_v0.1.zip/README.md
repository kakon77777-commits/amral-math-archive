# UCPNP Paper 08 v0.1 Release Pack

Main paper:
- `08_UCPNP_Capability_Epistemic_Authority_and_Dignity_v0.1.md`

Supporting artifacts:
- `08_UCPNP_Claim_Matrix_v0.1.md`
- `08_UCPNP_Procedural_Precaution_Ladder_v0.1.json`
- `verify_p08_structure.py`
- `08_UCPNP_Source_Integrity_v0.1.json`
- `CHECKSUMS.sha256`

Role:
Normative companion to UCPNP. It explicitly separates descriptive capability, epistemic authority, domain qualification, responsibility, and dignity.

Important:
- Human dignity floor is grounded in existing human-rights norms.
- Cross-subject / artificial-subject extension is a normative proposal, not current law.
- AI moral status is treated as uncertain; precaution is not equivalent to full personhood.
