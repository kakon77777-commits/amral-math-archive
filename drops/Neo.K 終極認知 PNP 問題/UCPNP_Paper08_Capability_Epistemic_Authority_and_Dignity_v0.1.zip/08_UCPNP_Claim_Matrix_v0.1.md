# UCPNP Paper 08 Claim Matrix v0.1

| ID | Type | Claim | Scope |
|---|---|---|---|
| D2.1 | D | Capability $\mathcal C$ | Descriptive, domain-relative |
| D2.2 | D | Epistemic authority $\mathcal E$ | Evidence/certification-relative |
| D2.3 | D | Domain qualification $\mathcal Q^D$ | Functional/institutional |
| D2.4 | D | Responsibility $\mathcal R$ | Control/role/foreseeability-relative |
| D2.5 | D | Dignity $\mathcal D$ | Normative standing |
| N3.1 | N | Human dignity floor is not capability-ranked | Human-rights normative floor |
| N4.1 | N | Capability differences do not automatically imply dignity differences | Recognized subjects |
| N5.1 | N | No capability caste | Normative civilization principle |
| D7.1 | D | Qualification–Dignity Orthogonality model | Institutional model |
| P8.1 | T | Single capability score underdetermines full normative/institutional state | Constructive structural proposition |
| N10.1 | N | Epistemic authority must be scope-limited | Normative/epistemic |
| N12.1 | N | Greater controllable impact warrants stronger accountability requirements | Governance axiom |
| N14.1 | N | Substrate-Open Review | Proposed cross-subject principle, not current law |
| D15.1 | D | Moral-status evidence vector | Non-final research scaffold |
| D17.1 | D | Procedural Precaution Ladder P0–P3 | Normative proposal |
| N18.1 | N | Procedure may precede ultimate ontology under uncertainty | Precaution principle |
| N19.1 | N | Prefer reversibility under serious moral-status uncertainty, ceteris paribus | Precaution principle |
| N20.1 | N | Preserve dissent/appeal position under capability asymmetry | Coexistence principle |
| N21.1 | N | Capability expansion does not grant definition monopoly | Anti-usurpation principle |
| C22.1 | C | Capability-power coupling may be a major future concentration risk | Future hypothesis |
| D23.1 | D | Functional Authority Contract | Institutional model |
| N24.1 | N | Right Not to Rule | Normative principle |
| N25.1 | N | Replacement and Handoff | Institutional principle |
| E29.1 | E | CRPD protects inherent dignity independently of disability/capability | Current human-rights source |
| E29.2 | E | UNESCO/CoE AI frameworks center human rights/dignity, not AI personhood | Current governance sources |
| E29.3 | E | AI moral status remains scientifically/philosophically unsettled | Current research literature |
