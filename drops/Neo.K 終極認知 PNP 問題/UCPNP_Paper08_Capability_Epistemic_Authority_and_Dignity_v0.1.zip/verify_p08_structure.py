# UCPNP Paper 08 structural sanity checks

# P8.1: same capability score can coexist with different qualification / epistemic authority.
A = {"score":100, "medical_cert":True, "evidence_scope":{"claim1"}}
B = {"score":100, "medical_cert":False, "evidence_scope":set()}
assert A["score"] == B["score"]
assert A["medical_cert"] != B["medical_cert"]
assert A["evidence_scope"] != B["evidence_scope"]

# Capability differences need not change a fixed human dignity floor in the normative model.
human1 = {"capability":10, "dignity_floor":1}
human2 = {"capability":1000, "dignity_floor":1}
assert human1["capability"] != human2["capability"]
assert human1["dignity_floor"] == human2["dignity_floor"]

# Functional authority can be domain-relative and reviewable.
roles = {
    "surgery":{"A":"qualified","B":"not_qualified"},
    "poetry":{"A":"not_assessed","B":"qualified"}
}
assert roles["surgery"]["A"] != roles["surgery"]["B"]
assert roles["poetry"]["A"] != roles["poetry"]["B"]

# Procedural precaution is not identical to full personhood.
precaution_levels = {"P0":0,"P1":1,"P2":2,"P3":3}
assert precaution_levels["P1"] < precaution_levels["P3"]
assert precaution_levels["P2"] < precaution_levels["P3"]

print("UCPNP Paper 08 structural checks: PASS")
