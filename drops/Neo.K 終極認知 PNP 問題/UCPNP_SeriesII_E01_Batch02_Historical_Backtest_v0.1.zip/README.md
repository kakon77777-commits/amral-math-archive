# UCPNP Series II E01 — Batch 02

Cases:
1. FFT — lineage recovery / method generalization.
2. GRASP/CDCL SAT — knowledge condensation with overhead.
3. RSA — concept/method/deployment-contract lag.

Key new stress-tests:
- Historical precursor is not automatically identical to canonical modern method.
- More reusable learned structure can increase total runtime.
- Deployment/interoperability is distinct from mathematical method publication.
- Series-I Stop Rule is enforced: no new foundational variable is added merely because RSA exposes a deployment-contract distinction.
