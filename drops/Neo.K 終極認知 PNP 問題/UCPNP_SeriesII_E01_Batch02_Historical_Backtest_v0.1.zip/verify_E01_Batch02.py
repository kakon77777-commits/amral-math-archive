import csv, json
from pathlib import Path
base=Path(__file__).parent

rows=list(csv.DictReader((base/"E01_Batch02_Phase_Matrix_v0.1.csv").open(encoding="utf-8")))
assert len(rows)==3
assert {r["case_id"] for r in rows}=={"D_FFT","E_GRASP_CDCL","F_RSA"}

# Must preserve unresolved historical execution for FFT and RSA.
fft=next(r for r in rows if r["case_id"]=="D_FFT")
rsa=next(r for r in rows if r["case_id"]=="F_RSA")
assert "UNRESOLVED" in fft["Y_E_S1"]
assert "UNRESOLVED" in rsa["Y_E_S1"]

# Learned-knowledge overhead reversal must be retained.
sat=next(r for r in rows if r["case_id"]=="E_GRASP_CDCL")
assert "increase CPU time" in sat["new_issue"]

# Signatures should remain discriminative.
assert len({r["signature"] for r in rows})==3

p=json.loads((base/"E01_Batch02_Evidence_Passports_v0.1.json").read_text(encoding="utf-8"))
assert len(p["passports"])==7
assert any("equivalence" in x.get("uncertainty","") for x in p["passports"])
assert any("not a preserved" in x.get("uncertainty","") for x in p["passports"])

print("UCPNP E01 Batch02 consistency checks: PASS")
