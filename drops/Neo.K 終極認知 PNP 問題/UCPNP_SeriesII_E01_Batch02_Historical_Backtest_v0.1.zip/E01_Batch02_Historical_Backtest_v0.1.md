# UCPNP Series II — E01 Historical Cognitive Backtest Corpus
## Batch 02：FFT、GRASP/CDCL SAT、RSA

**Series:** Neo.K Ultimate Cognitive P/NP — Series II Experiments  
**Experiment:** E01 — Historical Cognitive Backtest Corpus  
**Batch:** 02  
**Version:** v0.1  
**Author:** Neo.K  
**Collaborative analysis:** Aletheia  
**Date:** 2026-08-16  
**Status:** Historical documentary backtest with explicit ambiguity and Evidence Passports.

---

# 0. Why Batch 02 is harder than Batch 01

Batch 01 得到三種相對乾淨的 signature：

$$
\text{Method-Dominant},
\qquad
\text{Certification-Lag},
\qquad
\text{Mixed-Convergence}.
$$

Batch 02 刻意挑三個更容易破壞簡單歸因的案例：

1. FFT：現代廣泛傳播的 1965 method 並非從零出現，之前已有 Fourier fast-method antecedents；
2. GRASP/CDCL：learned clauses 類似 $\Sigma$，但 knowledge accumulation 本身會產生 overhead；
3. RSA：public-key concept、RSA method、engineering feasibility、protocol standardization 並非同一年。

本 Batch 的主要測試是：

$$
\boxed{
\text{UCPNP 能否保留 lineage、reuse overhead 與 deployment lag？}
}
$$

---

# 1. Common audit rules

所有日期均標：

- `UB(y)`：documented upper bound；
- `LB(y)`：有明確必要條件證據的 lower bound；
- `UNRESOLVED`：現有資料不足；
- `PRECURSOR(y)`：與後來方法結構相關，但本 Batch 不宣稱完全等價。

所有 mechanism attribution 分：

- exact operational；
- proxy/candidate；
- historical analogy。

---

# 2. Case D — Fast Fourier Transform lineage

## 2.1 Fixed task

固定現代 task：

> 對長度 $N$ 的 complex discrete Fourier series / DFT 計算全部 Fourier coefficients。

Cooley–Tukey 1965 paper 的第一頁明確比較：

$$
N^2
$$

straightforward operations，

與其 algorithm：

$$
\boxed{
<2N\log_2 N
}
$$

operations，且不要求超過原 $N$ 個 data locations 的 storage。

因此：

$$
\boxed{
Y_M^{\mathrm{modern\ generic}}
\le1965.
}
$$

---

## 2.2 Pre-1965 lineage

Danielson 與 Lanczos 在 1942 年已發表 *Some improvements in practical Fourier analysis and their application to X-ray scattering from liquids*。

本 Batch 將它標：

$$
\boxed{
\mathrm{PRECURSOR}(1942),
}
$$

而不是直接宣稱：

$$
Y_D(\text{full Cooley--Tukey})=1942.
$$

理由是：

- historical structural antecedence 明確；
- 但本文尚未對兩篇算法的 domain、factorization generality、storage model 與 exact operational equivalence 做 line-by-line formal comparison。

因此 FFT case 第一個結果是：

$$
\boxed{
\text{historical precursor}
\neq
\text{canonical modern general method}.
}
$$

---

## 2.3 Phase vector

### Representation

DFT / complex Fourier-series calculation task 在 1965 paper 明確固定：

$$
Y_R\le1965.
$$

更早的 equivalent representation history：

`UNRESOLVED in Batch 02`.

### Discovery / method

modern generic factorization method：

$$
Y_D^{(\mathsf S_0)}
\le1965.
$$

### Execution

1965 paper 明確針對 machine calculation、binary computers、storage locality 設計。

因此：

$$
Y_E^{\mathrm{engineering\ feasibility}}
\le1965.
$$

但 preserved historical machine execution record 的最早年份：

`UNRESOLVED`.

---

## 2.4 Mechanism attribution

最安全：

$$
\boxed{
M+\Gamma_{\mathrm{candidate}}.
}
$$

其中：

- $M$：factorized FFT algorithm；
- $\Gamma_{\mathrm{candidate}}$：將 full $N^2$ interaction matrix 重構為 sparse factor sequence，具有 representation-transformative 特徵。

但 $\Gamma$ 不升為 exact UCPNP theorem，因為 Batch 02 尚未做 Paper 03 所要求的 controlled same-task lifecycle ablation。

---

## 2.5 FFT signature

$$
\boxed{
\textbf{Lineage-Recovery / Method-Generalization}.
}
$$

此 case 反對：

> 一個著名 publication year 就等於整個 idea birth year。

---

# 3. Case E — GRASP / Conflict-Driven Clause Learning

## 3.1 Fixed task

固定：

> 對 CNF propositional SAT instance，找 satisfying assignment 或證明 unsatisfiable。

Marques-Silva 與 Sakallah 的 GRASP 在 1996 conference version 已公開；1999 *IEEE Transactions on Computers* archival paper 進一步完整描述 conflict analysis、nonchronological backtracking 與 conflict-induced clause recording。

因此：

$$
Y_D^{\mathrm{GRASP}}
\le1996.
$$

journal archival upper bound：

$$
Y_{\mathrm{pub}}\le1999.
$$

---

## 3.2 Learned clauses as $\Sigma$ candidate

GRASP 將 conflict occurrence 視為：

> augmented problem description 的機會。

其 conflict-induced clauses 會加入 clause database；之後 solver 可：

- backtrack nonchronologically；
- recognize similar conflict；
- preempt recurrence；
- derive necessary assignments。

在 UCPNP 語言裡，這非常接近：

$$
\boxed{
\Sigma_{\mathrm{intra-instance}}
}
$$

也就是：

> 在 fixed CNF representation 中，把失敗搜索凝結成可重用結構，以降低後續同一 instance 的 discovery/search cost。

注意：

$$
\Sigma_{\mathrm{intra-instance}}
\neq
\Sigma_{\mathrm{cross-task}}.
$$

learned clause 通常是該 formula / search lineage 的知識，不應被自動寫成通用 SAT knowledge。

---

# 4. The important negative result: more learned structure is not monotonically better

GRASP 1999 paper 直接做 clause-database growth experiment。

隨最大 learned-clause size 增加：

$$
\text{backtracks}\downarrow,
$$

且前期：

$$
\text{CPU time}\downarrow.
$$

但到某點後：

$$
\text{backtracks still}\downarrow,
$$

同時：

$$
\boxed{
\text{CPU time}\uparrow.
}
$$

作者將其歸因於 larger clause database 帶來額外 search overhead，並在其 SSA/BF benchmark 上觀察到約 30 左右的實驗 optimum bound。

因此得到 UCPNP historical empirical result：

$$
\boxed{
\text{reusable knowledge amount}\uparrow
\not\Rightarrow
\text{net lifecycle tractability}\uparrow.
}
$$

這是 Paper 03 build/use/reuse accounting 的真實 solver case。

---

# 5. GRASP phase vector

### Representation

CNF clause database：

$$
Y_R\le1996.
$$

### Discovery

GRASP conflict-analysis method：

$$
Y_D\le1996.
$$

### Construction

conflict-induced clause generation 是 runtime construction：

$$
C_C>0.
$$

### Execution

1996/1999 papers report implemented solver experiments：

$$
Y_E\le1996
$$

作為 conference-system implementation upper bound。

### Verification

SAT solution correctness / unsat search correctness 由 algorithmic correctness/completeness argument 支持；1999 paper appendix formally proves GRASP correct and complete under stated algorithm.

因此：

$$
Y_V^{\mathrm{algorithmic}}
\le1999.
$$

---

# 6. Mechanism attribution

GRASP/CDCL case：

$$
\boxed{
M+\Sigma_{\mathrm{proxy}}.
}
$$

更精確地：

$$
\boxed{
\Sigma_{\mathrm{proxy}}
=
\text{failure-derived reusable clause structure}.
}
$$

但因 overhead reversal：

$$
\boxed{
\Delta\Sigma_{\mathrm{useful}}
\text{ 必須按 net lifecycle return 衡量，不能按 clause count 衡量。}
}
$$

---

# 7. GRASP signature

$$
\boxed{
\textbf{Knowledge-Condensation-with-Overhead}.
}
$$

這是 Batch 02 最直接的新 signature。

---

# 8. Case F — RSA

## 8.1 Fixed task

固定 task：

> 建立可公開 encryption key、保留 private decryption key，並支援 public verification of digital signatures 的 public-key cryptosystem。

Diffie–Hellman 1976 *New Directions in Cryptography* 提出 public-key cryptography 的核心概念。

RSA 原論文自己明確指出：

> Diffie–Hellman 提出了 public-key concept，但未提供 practical implementation；RSA 的工作提供一個 implementation。

因此對 RSA task lineage：

$$
\boxed{
Y_R^{\mathrm{concept}}
\le1976.
}
$$

而 RSA specific method：

$$
\boxed{
Y_D^{\mathrm{RSA}}
\le1978.
}
$$

---

## 8.2 Method / execution feasibility

RSA 1978 paper 提供：

- modular exponentiation；
- repeated squaring and multiplication；
- prime generation / primality testing；
- key construction。

論文估計：

- 高速電腦加密 200-digit message 約數秒；
- 100-digit primality check 約數秒；
- prime search 約一兩分鐘。

因此：

$$
\boxed{
Y_E^{\mathrm{paper\ feasibility}}
\le1978.
}
$$

但這些是 paper-level engineering estimates / algorithm descriptions。

Batch 02 尚未取得：

- preserved 1977/1978 machine implementation；
- exact machine model；
- raw timing log。

因此：

$$
Y_E^{\mathrm{historical\ replay}}
=
\mathrm{UNRESOLVED}.
$$

---

# 9. Protocol / deployment layer

RSA method publication 不等於 interoperable implementation contract。

RFC 2313 的 PKCS #1 revision history 記錄：

- versions 1.0–1.3 在 1991 年 2–3 月 standards meetings 分發；
- version 1.4 是 1991-06-03 的 initial public release of PKCS；
- RFC 2313 在 1998 年發布 PKCS #1 v1.5。

因此可以安全標：

$$
\boxed{
Y_{\mathrm{interop\ spec}}
\le1991
}
$$

作為 public PKCS #1 specification upper bound。

而：

$$
Y_{\mathrm{RFC\ publication}}
\le1998.
$$

這不是說 1991 前沒有 RSA deployment；只是說可引用的公開 interoperability artifact 最遲到 1991 已存在。

---

# 10. RSA signature

RSA 因此不是單一日期：

$$
\boxed{
\begin{aligned}
\text{public-key concept}&\le1976,\\
\text{RSA method}&\le1978,\\
\text{paper-level practical feasibility}&\le1978,\\
\text{public PKCS interoperability artifact}&\le1991,\\
\text{RFC publication of PKCS 1.5}&\le1998.
\end{aligned}
}
$$

signature：

$$
\boxed{
\textbf{Concept--Method--Deployment-Contract Lag}.
}
$$

---

# 11. Cross-case matrix

| Case | Earliest strong documentary point | Key internal gap | UCPNP signature |
|---|---:|---|---|
| FFT | 1965 modern generic FFT; 1942 precursor | precursor vs exact general-method equivalence | Lineage-Recovery / Method-Generalization |
| GRASP/CDCL | 1996 method | learned structure saves search but can add more overhead than it saves | Knowledge-Condensation-with-Overhead |
| RSA | 1976 concept / 1978 method | concept, method, practical execution, interoperable spec separate | Concept–Method–Deployment-Contract Lag |

---

# 12. Batch 02 result R12.1 — A publication year is not an origin operator

FFT and RSA both show:

$$
\boxed{
Y_{\mathrm{publication}}
}
$$

can correspond to different phase meanings.

FFT 1965 is a canonical method-generalization/dissemination landmark with earlier antecedents.

RSA 1978 is a method implementation after a 1976 concept landmark.

Thus:

$$
\boxed{
\text{publication date}
\neq
\text{idea birth}
\neq
\text{deployment readiness}.
}
$$

---

# 13. Batch 02 result R13.1 — $\Sigma$ needs net-return accounting

GRASP provides the strongest Series-II historical support so far for Paper 03:

$$
\boxed{
\text{more reusable structure}
\neq
\text{monotonically better system}.
}
$$

A knowledge artifact can reduce future search while simultaneously increasing:

$$
C_E+C_O.
$$

Therefore operational $\Sigma$ should be measured by:

$$
\boxed{
\text{net reusable Pareto improvement}
}
$$

rather than raw memory / clause / theorem count.

---

# 14. Batch 02 result R14.1 — Deployment is a distinct frontier

RSA demonstrates that:

$$
\boxed{
\text{mathematically specified method}
\neq
\text{interoperable protocol artifact}.
}
$$

UCPNP Series I did not explicitly name a deployment/interoperability phase in the six-phase cognition ledger.

Batch 02 therefore discovers a candidate new distinction:

$$
C_{\mathrm{Deploy}}
\quad\text{or}\quad
\kappa_{\mathrm{interop}}.
$$

However, according to the Series-I Stop Rule，**本 Batch 不直接新增 foundational variable**。

優先策略是先嘗試把 deployment 表示為：

$$
C_C+C_V+C_{\mathrm{Cert}}+C_O
$$

加上一個 explicit interoperability contract：

$$
\kappa_{\mathrm{interop}}.
$$

只有後續更多 cases 證明這種表示不夠，才新增 $C_{\mathrm{Deploy}}$。

這是 Series II 第一次真正觸發「新變數候選」，但暫不擴詞。

---

# 15. Attribution conflicts preserved

Batch 02 有三個 deliberate unresolved points：

1. Danielson–Lanczos 1942 與 full Cooley–Tukey generality 的 exact equivalence：`UNRESOLVED`；
2. earliest preserved machine execution of modern FFT：`UNRESOLVED`；
3. earliest preserved real machine RSA execution/timing：`UNRESOLVED`。

這些不由自然語言補洞。

---

# 16. Evidence Passport summary

## FFT-1

- Type: E
- Claim: Cooley–Tukey 1965 gives modern machine algorithm with under $2N\log_2N$ operations.
- Scope: paper-defined complex Fourier-series calculation.
- Evidence: original 1965 paper.
- Reproduction: documentary.
- Excluded claim: exact first invention year.

## FFT-2

- Type: E
- Claim: Danielson–Lanczos 1942 is a fast/practical Fourier-analysis antecedent.
- Scope: historical precursor.
- Evidence: original 1942 article record.
- Excluded claim: operational equivalence to full 1965 algorithm.

## SAT-1

- Type: E
- Claim: GRASP conflict recording reuses conflict-induced clauses to preempt similar future conflicts.
- Scope: intra-instance SAT search.
- Evidence: 1996/1999 GRASP publications.
- UCPNP mapping: $\Sigma$ proxy.

## SAT-2

- Type: E
- Claim: increasing learned-clause growth can eventually increase CPU time despite continued backtrack reduction.
- Scope: reported SSA/BF benchmark experiment.
- Evidence: GRASP 1999.
- UCPNP implication: raw knowledge count is not net $\Sigma$ value.

## RSA-1

- Type: E
- Claim: Diffie–Hellman public-key concept predates RSA practical method.
- Scope: public cryptography lineage.
- Evidence: 1976 IEEE paper + RSA authors' own account.
- Excluded claim: RSA method existed publicly in 1976.

## RSA-2

- Type: E
- Claim: RSA paper provides efficient operation algorithms and 1978 feasibility estimates.
- Scope: paper-level engineering feasibility.
- Reproduction: documentary, not historical replay.

## RSA-3

- Type: E
- Claim: PKCS #1 initial public release existed by 1991.
- Scope: interoperability specification artifact.
- Evidence: RFC 2313 revision history.
- Excluded claim: first RSA deployment occurred in 1991.

---

# 17. Batch 01 + Batch 02 signature set

目前六個案例：

$$
\boxed{
\begin{aligned}
\text{Dijkstra}&:\text{ Method-Dominant},\\
\text{Four Color}&:\text{ Certification-Lag},\\
\text{AlexNet}&:\text{ Mixed-Convergence},\\
\text{FFT}&:\text{ Lineage-Recovery / Method-Generalization},\\
\text{GRASP/CDCL}&:\text{ Knowledge-Condensation-with-Overhead},\\
\text{RSA}&:\text{ Concept--Method--Deployment-Contract Lag}.
\end{aligned}
}
$$

這仍不是 predictive validity。

但 descriptive discrimination 已從 3 種擴大到 6 種。

---

# 18. Batch 03 target

下一批應開始加入：

1. 一個**失敗／被取代方法**；
2. 一個**硬體真的主導**的案例；
3. 一個**formal verification** 案例；
4. 一個**database / indexing / precomputation** 案例。

建議候選：

- Strassen matrix multiplication / practical dense linear algebra；
- IBM Deep Blue / chess search；
- CompCert / seL4；
- PageRank / web indexing；
- AlphaGo / AlphaZero 作 representation + compute + self-play 比較。

---

# 19. Conclusion

Batch 02 的最重要結果不是多三個案例，而是第一次讓 UCPNP 自己碰到三種不舒服的狀態：

$$
\boxed{
\text{lineage ambiguity},
}
$$

$$
\boxed{
\text{knowledge overhead reversal},
}
$$

$$
\boxed{
\text{deployment-contract lag}.
}
$$

也因此第一次真正測到 Series-I Stop Rule：

> 遇到新現象時先嘗試用現有結構表達，不要立刻創造新名詞。

目前：

$$
\kappa_{\mathrm{interop}}
$$

足以暫時吸收 RSA 的 deployment contract。

如果 Batch 03–05 持續證明 deployment / interoperability 無法由既有 $C_C,C_V,C_{\mathrm{Cert}},C_O,\kappa$ 表示，再考慮正式升級。

這表示 UCPNP 開始從「理論框架」進入：

$$
\boxed{
\text{會被案例反向約束的研究程序}.
}
$$

---

# References

1. J. W. Cooley and J. W. Tukey. *An Algorithm for the Machine Calculation of Complex Fourier Series*. Mathematics of Computation 19(90), 297–301 (1965).
2. G. C. Danielson and C. Lanczos. *Some Improvements in Practical Fourier Analysis and Their Application to X-Ray Scattering from Liquids*. Journal of the Franklin Institute 233 (1942), Parts I–II.
3. J. P. Marques-Silva and K. A. Sakallah. *GRASP — A New Search Algorithm for Satisfiability*. ICCAD 1996.
4. J. P. Marques-Silva and K. A. Sakallah. *GRASP: A Search Algorithm for Propositional Satisfiability*. IEEE Transactions on Computers 48(5), 506–521 (1999).
5. W. Diffie and M. E. Hellman. *New Directions in Cryptography*. IEEE Transactions on Information Theory 22(6), 644–654 (1976).
6. R. L. Rivest, A. Shamir, and L. Adleman. *A Method for Obtaining Digital Signatures and Public-Key Cryptosystems*. Communications of the ACM 21(2), 120–126 (1978).
7. B. Kaliski. *PKCS #1: RSA Encryption Version 1.5*. RFC 2313 (1998); revision history records the initial public PKCS release of June 3, 1991.
