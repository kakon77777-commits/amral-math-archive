# CHANGELOG

## v0.1 — 2026-08-16

- Closes Cycle VI as a critical-lift construction/audit cycle.
- Factorizes Causal-to-Audit Realization into CAR0 coordinate realization, CAR1 native separation, CAR2 anti-phantom transfer, and CAR3 moving-window uniformity.
- Records CAR0 as externally constructed and CAR2 as externally conditional.
- Proves the Copied-Gate No-Go to prevent tautological detector closure.
- Proves a Native CAR Detector Compiler.
- Proves a Type-I normalized local endpoint kinetic-energy cap from weak-L3.
- Shows the endpoint cap does not solve backscatter variation.
- Proves the Paid-Side Absorption Compiler combining geometric/sign-coherent backscatter with caloric leakage absorption.
- Audits the external NS-realizable combined-invisible left-singular cascade and separates it from ANP causal dual provenance.
- Adds model-cone and filtered-increment mechanism channels as conditional augmentations of the combined detector.
- Defines the full conditional Forest-Coercive Compiler.
- Compresses the final obligations to XTR, UNI, RIG, and SIGN.
- Launches the Navier-Stokes Minimal Obstruction Rigidity Program.
