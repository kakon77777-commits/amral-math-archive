# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- A copied dangerous mark is not accepted as a native coercive detector coordinate.
- NS-generated coordinate realization is not promoted to dangerous quotient separation.
- Fixed-window anti-phantom gaps are not promoted to scale-uniform moving-window coercivity.
- ANP causal dual provenance is not promoted to finite-window selected-time trace visibility without a compatibility theorem.
- Paid-side backscatter/leakage estimates are conditional and are not assumed.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
