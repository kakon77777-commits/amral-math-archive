# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- The comparable-annulus result is a ledger sufficiency no-go, not a Navier-Stokes counterexample.
- Harmonic/affine structure is not treated as positive-work cancellation without a signed-work theorem.
- Cylindrical Young-measure extraction is not treated as a full nonlinear defect representation.
- External filtered results are used only within their explicit hypotheses and residual classes.
- No Critical Lift, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
