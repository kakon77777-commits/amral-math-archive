---
title: "Navier–Stokes Forest Coercive Budget Program：Cycle-VI Roadmap"
version: "v0.2"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-FCBP Cycle-VI Roadmap v0.2

## FCBP-01 — Critical Forest Coercivity

Established:

- exact one-derivative energy/critical forcing gap;
- scale-critical renormalized cut duality;
- summable-weight critical-lift no-go;
- structural-cancellation modules as the only credible lift route.

## FCBP-02 — Filtered Stretching Critical Lift

### Near-field

At fixed:

$$
\ell=\sigma r,
$$

positive singular near-field filtered stretching is externally absorbed by diffusion up to lower-order enstrophy.

Status:

$$
\boxed{
CL\mbox{-}DER
\text{ closed on the near-field branch}.
}
$$

### Principal localization

A filtered backward adjoint cutoff cancels the principal cutoff residual exactly.

Residual shell/localization budgets remain explicit.

### Annular far-field

External reassignment gives:

$$
\mu_k^{far,ann}
\lesssim
\sum_{j\le k}
2^{-(k-j)}
\mathfrak A_j
\mathcal Q_k.
$$

External Carleson closure:

$$
\mathfrak A\in\ell^p,
\qquad
\mathcal Q\in\ell^q,
\qquad
1/p+1/q=1
$$

implies an unweighted bound independent of chain length.

### Comparable-Annulus Barrier

The diagonal:

$$
j=k
$$

has no scale-decay factor.

Therefore off-diagonal gap decay or harmonic remainder gains cannot create global unweighted packing from merely bounded scale-invariant reservoir sequences.

### Harmonic affine route

Fixed exterior annuli produce harmonic strain in finer cores and admit affine Taylor jets plus scale-separated remainders.

However:

$$
\boxed{
\text{harmonic/affine}
\not\Rightarrow
\text{positive-work cancellation}.
}
$$

A signed formulation is necessary.

### Signed-to-positive lift

If signed affine work has bounded cumulative telescope and finite negative/backscatter mass, then its positive part is summable.

This gives a precise conditional far-field lift criterion.

### Commutator branch

Derivative-compatible increments replace a scale-worse commutator estimate by a scale-invariant defect:

$$
\widetilde{\mathcal S}_k^{(p)}.
$$

Status:

$$
\boxed{
CL\mbox{-}DER
\text{ locally recovered on the commutator branch}.
}
$$

But bounded critical defects are not automatically:

$$
\ell^1
$$

in scale.

Persistent post-near-field surplus forces persistent critical increment defect.

### Conditional filtered closure

External filtered theory proves:

$$
\boxed{
\text{FAR-PACK}
+
\text{COM-PACK}
+
\text{LOC-PACK}
\Longrightarrow
\mathfrak S_k\to0.
}
$$

Thus a complete conditional compiler exists.

### Current no-go

Current unconditional filtered estimates do not imply:

$$
\sup_N
\sum_{k\le N}
\mathfrak S_k
<
\infty.
$$

The dominant gap is:

$$
\boxed{
CL\mbox{-}PACK.
}
$$

## FCBP-03 — Signed Work / Pressure-Flux / Model-Cone Lift

Targets:

1. define signed affine-jet work before positive-part extraction;
2. bridge it to pressure--flux finite-chain telescoping;
3. seek a finite backscatter/negative-work budget;
4. test comparable-annulus diagonal telescoping;
5. combine model-cone coercivity with signed work recurrence;
6. test commutator defect-work recurrence;
7. decide whether a non-summable critical lift exists.

## Current obligations

$$
CL\mbox{-}DER
:
\mathrm{PARTIALLY\ CLOSED}.
$$

$$
CL\mbox{-}REM
:
\mathrm{OPEN/PARTIAL}.
$$

$$
CL\mbox{-}PACK
:
\mathrm{OPEN/DOMINANT}.
$$

## Hard rules

- Off-diagonal scale decay does not control comparable-scale diagonal packing.
- Harmonicity alone does not cancel a positive-part work functional.
- Any affine cancellation argument must preserve signs or add an orientation hypothesis.
- Scale-invariant commutator control is not global scale summability.
- Cylindrical Young profiles are not full nonlinear defect representations without additional hypotheses.
- No regularity claim is made.
