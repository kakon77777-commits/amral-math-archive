# CHANGELOG

## v0.1 — 2026-08-16

- Audits the filtered-vorticity coercive route as the first concrete Critical Lift attempt.
- Records near-field singular stretching as structurally closed by diffusion at fixed relative filter scale.
- Records exact cancellation of the principal localization residual by a filtered adjoint cutoff.
- Imports the annular reassignment and conditional unweighted Carleson closure.
- Proves the Comparable-Annulus Barrier: off-diagonal decay cannot resolve the undamped j=k channel.
- Proves harmonic/affine structure alone cannot cancel positive-part stretching work.
- Proves a Signed-to-Positive Lift lemma and a conditional signed affine-jet far-field lift.
- Records the derivative-compatible commutator estimate as local recovery of the scale loss.
- Proves bounded critical commutator defects do not imply unweighted scale packing.
- Records that persistent defect surplus forces persistent critical p=3 increment defect.
- Identifies cylindrical Young profiles as recurrence objects rather than finite budgets.
- Compresses the filtered critical-lift frontier to comparable-annulus signed packing, commutator recurrence/packing, exterior tails, and residual localization.
- Moves the next paper to the signed pressure-flux/model-cone bridge.
