---
title: "Navier–Stokes Forest Coercive Budget Program：Cycle-VI Roadmap"
version: "v0.5"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-FCBP Cycle-VI Roadmap v0.5

## FCBP-01--04

Established:

- exact one-derivative energy/critical forcing gap;
- filtered structural derivative recovery;
- comparable-annulus and packing barriers;
- variable-radius signed telescope;
- non-summable scale schedules;
- moving-filter compatibility;
- horizon time-thickness barrier.

## FCBP-05 — Temporal Observability / Combined Anti-Phantom

### Single-channel no-go

For:

$$
\mathcal N
=
-\mathbb P\nabla\cdot(u\otimes u),
$$

$$
\langle\mathcal N,u\rangle=0
$$

for every smooth finite-energy divergence-free velocity.

There are explicit Schwartz examples with:

$$
\nabla\times\mathcal N\neq0.
$$

Thus fresh vorticity source cannot be universally coerced into one global signed kinetic-energy-work channel.

The target is combined observability.

### Combined detector

External moving-window theory uses:

$$
O^{comb}
=
(
P,F,E,T
)
$$

and branch observability:

$$
M_n
=
\sup
\|d\|/\mathsf O_n(d).
$$

Depletion-effective observability requires:

$$
\sum
\lambda_nM_n^{-q}
=
\infty.
$$

### Sharp horizon schedule theorem

For every decreasing:

$$
r_k
$$

with:

$$
\sum r_k^2<\infty,
$$

set:

$$
d_k
=
1-(r_{k+1}/r_k)^2.
$$

Then:

$$
\boxed{
\sum
r_kd_k^a
<
\infty
\quad
\forall a>1/2.
}
$$

The exponent:

$$
a=1/2
$$

is sharp.

A logarithmic schedule:

$$
r_k
\sim
[k(\log k)^{2b}]^{-1/2},
\qquad
1/2<b\le1,
$$

has finite:

$$
\sum r_k^2
$$

but divergent:

$$
\sum r_kd_k^{1/2}.
$$

### Thin-window observability threshold

If:

$$
M_k
\lesssim
d_k^{-\gamma},
$$

and the depletion exponent is:

$$
q,
$$

then:

$$
\boxed{
\gamma q=1/2
}
$$

is the sharp schedule-level temporal threshold.

-:
  $$
  \gamma q<1/2
  $$
  admits power schedules;

-:
  $$
  \gamma q=1/2
  $$
  admits logarithmic borderline schedules;

-:
  $$
  \gamma q>1/2
  $$
  cannot be forced depletion-effective from this growth law alone by any finite-time monotone schedule.

### Combined Horizon Depletion Compiler

If:

- causal packages are realized as NS finite-window defects;
- anti-phantom residuals are controlled;
-:
  $$
  M_k\lesssim d_k^{-\gamma};
  $$
-:
  $$
  \gamma q\le1/2;
  $$
- no combined-invisible cascade survives;
- paid-side recurrence is summable;

then the horizon branch is impossible.

### Long-age state propagation

Tao's external strong:

$$
L_t^\infty L_x^3
$$

theory gives iterated back propagation:

$$
N_1
\sim_A
T_1^{-1/2},
$$

with spatial drift:

$$
O_A(T_1^{1/2}).
$$

Thus long-age state observability is possible in that strong critical subbranch, with parabolic scale migration.

This does not apply automatically to weak:

$$
L^{3,\infty}.
$$

### Paid-side no-go

Bounded signed endpoint budgets do not control total negative/backscatter variation.

Weighted backscatter closure needs an additional sign/variation/recurrence theorem.

## FCBP-06 — Causal-to-Audit / Invisible Cascade / Cycle-VI Audit

Targets:

1. prove Causal-to-Audit Realization;
2. instantiate finite-window clean-gap/anti-phantom hypotheses on ANP canonical nodes;
3. compare causal fresh-source and defect source coordinates;
4. exclude or classify NS-realizable combined-invisible cascades;
5. prove weighted backscatter/leakage sign coherence or retain them as final recurrence objects;
6. decide whether Cycle VI yields a Forest Coercive Budget.

## Current obligations

Scale/filter compatibility:

$$
\boxed{
\mathrm{SUBSTANTIALLY\ CLOSED}.
}
$$

Temporal schedule geometry:

$$
\boxed{
\mathrm{SHARP\ THRESHOLD\ PROVED}.
}
$$

CAR:

$$
\boxed{
\mathrm{OPEN}.
}
$$

Moving-window combined observability:

$$
\boxed{
\mathrm{CONDITIONAL/EXTERNAL}.
}
$$

Invisible cascade:

$$
\boxed{
\mathrm{OPEN}.
}
$$

Paid-side sign control:

$$
\boxed{
\mathrm{OPEN}.
}
$$

## Hard rules

- Fresh vorticity source is not identified with one signed energy-work detector.
- Combined detector effectiveness is a weighted-series statement, not a uniform pointwise lower bound.
- The temporal exponent 1/2 concerns normalized horizon thickness and finite-time schedules.
- Tao's LAO module is strong-L3, not weak-L3 endpoint.
- Signed telescoping does not bound total backscatter variation.
- No regularity claim is made.
