# CHANGELOG

## v0.1 — 2026-08-16

- Proves global Navier-Stokes nonlinear kinetic-energy orthogonality and gives an explicit Schwartz field with nonzero vorticity forcing.
- Replaces the single-channel renewal-to-work target by combined causal-renewal observability.
- Imports the pressure/flux/positive-energy/adjoint-trace moving-window framework as an external conditional detector module.
- Proves the Sharp Half-Exponent Schedule Theorem for all finite-time monotone horizon schedules.
- Constructs explicit logarithmic schedules showing sharpness at exponent 1/2.
- Derives the thin-window observability phase threshold gamma*q=1/2.
- Proves a conditional Combined Horizon Depletion Compiler.
- Defines Causal-to-Audit Realization as the missing bridge from ANP/CFOP packages to the finite-window quotient detector.
- Imports Tao's strong-L3 iterated back propagation as a Long-Age State Propagation module with parabolic scale migration.
- Proves signed endpoint energy does not control total backscatter variation.
- Defines Backscatter Recurrence and Leakage Recurrence.
- Compresses the temporal frontier to CAR, moving-window growth, combined-invisible cascade exclusion, and paid-side sign control.
