# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- A nonzero vorticity source is not identified with one signed kinetic-energy-work observable.
- External combined-observability/anti-phantom results are retained as conditional modules under their stated structural hypotheses.
- Tao's long-age propagation is used only in the strong L^3 critical subbranch.
- The half-exponent threshold is a theorem about finite-time monotone horizon schedules and polynomial window-thickness deterioration.
- Signed endpoint telescoping is not treated as a total-variation/backscatter bound.
- No Critical Lift, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
