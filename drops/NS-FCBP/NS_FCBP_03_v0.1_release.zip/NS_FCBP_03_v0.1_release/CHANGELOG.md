# CHANGELOG

## v0.1 — 2026-08-16

- Audits the exact pressure-flux finite-chain theorem and isolates the algebra actually used by endpoint telescoping.
- Generalizes the endpoint/work telescope from geometric radii to arbitrary strictly decreasing radii for one common coarse package.
- Introduces slow power-law radii r_k=r_0(k+1)^(-beta), 1/2<beta<=1.
- Proves finite total parabolic time together with divergent telescope weight sum.
- Establishes the first genuine non-summable Schedule Lift in FCBP.
- Proves a conditional non-summable pressure-flux depletion criterion.
- Identifies weighted backscatter/leakage as the paid-side closure needed on the slow schedule.
- Proves a fixed common filter cannot remain scale relative along an infinite shrinking chain.
- Derives the exact moving-filter telescope with an explicit positive filter-switch endpoint defect.
- Defines Filter-Switch Packing.
- Adds a finite-chain finest-scale common-filter strategy and isolates its uniform-in-N observability problem.
- Defines Active Observability Bridge and Active-Slab Density.
- Proves a scale-invariant Model-Cone Growth Packet from the strain balance.
- Defines Affine-to-Pressure-Flux observability as an open cross-observable bridge.
- Moves the frontier to moving-filter endpoint compatibility and borderline slow-scale observability.
