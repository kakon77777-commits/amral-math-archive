# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- The published Yu pressure-flux theorem remains attributed only in its geometric/common-filter form.
- Variable-radius and moving-filter telescopes are internal deductions from the local endpoint identity.
- Non-summable schedule generation is not promoted to a full Critical Lift without residual/observability closure.
- Coarse CKN visibility is not treated as signed-work observability.
- No Critical Lift, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
