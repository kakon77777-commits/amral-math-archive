---
title: "Navier–Stokes Forest Coercive Budget Program：Cycle-VI Roadmap"
version: "v0.3"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-FCBP Cycle-VI Roadmap v0.3

## FCBP-01

Established:

- one-derivative critical forcing gap;
- local critical renormalization;
- summable-weight no-go;
- structural cancellation as the only credible lift route.

## FCBP-02

Established:

- filtered near-field coercivity;
- local derivative recovery for commutators;
- comparable-annulus barrier;
- signed-work necessity;
- conditional filtered packing compiler.

## FCBP-03 — Signed Work / Slow-Scale Telescoping

### External pressure--flux theorem

Published form:

$$
r_k=\theta^kr_0,
$$

$$
w_k=r_k/r_0,
$$

with one common physical filter:

$$
\ell.
$$

Exact weighted telescope:

$$
\sum
w_k
(
W_k^+
+
D_k
)
\le
E_0^-
+
\sum
w_k|L_k|
+
\sum
w_kW_k^-.
$$

### Variable-radius theorem

The telescope algebra only needs:

$$
w_kr_k^{-1}=r_0^{-1}
$$

and:

$$
\chi_k\le\chi_{k-1}.
$$

Therefore the same endpoint telescope holds for arbitrary strictly decreasing radii.

Status:

$$
\boxed{
\mathrm{PROVED}.
}
$$

### Slow-scale lift

Choose:

$$
r_k=r_0(k+1)^{-\beta},
\qquad
1/2<\beta\le1.
$$

Then:

$$
\boxed{
\sum r_k^2<\infty,
}
$$

but:

$$
\boxed{
\sum r_k/r_0=\infty.
}
$$

Thus a finite-time parabolic chain carries a non-summable pressure--flux telescope weight.

Status:

$$
\boxed{
\mathrm{PROVED}.
}
$$

### Slow-scale conditional obstruction

If:

- forward active weighted demand diverges;
- weighted leakage is finite;
- weighted backscatter is finite;

then the chain is impossible.

This is the first conditional FCBP theorem using an intrinsically non-summable schedule.

### Filter compatibility problem

One common fixed physical filter gives exact telescoping but:

$$
\ell/r_k\to\infty.
$$

Scale-relative filtering requires:

$$
\ell_k=\sigma r_k.
$$

### Moving-filter telescope

Changing filters introduces:

$$
\Delta_k^{filt}
=
K_{\chi_{k-1}}^{\ell_k}(\tau_k)
-
K_{\chi_{k-1}}^{\ell_{k-1}}(\tau_k).
$$

Then:

$$
\sum
w_k(E_k^--E_k^+)
\le
E_0^-
+
r_0^{-1}
\sum
[\Delta_k^{filt}]_+.
$$

Thus moving-filter Critical Lift requires Filter-Switch Packing.

### Finest-scale common-filter strategy

For each finite chain:

$$
\ell^{(N)}=\sigma r_N.
$$

This preserves exact telescope and:

$$
\ell^{(N)}/r_k\le\sigma.
$$

But the package depends on:

$$
N.
$$

Need uniform-in-$N$ observability, leakage, backscatter, and residual control.

### Active work bridge

External coarse resolution gives:

$$
\text{CKN BAD}
\Rightarrow
\text{COARSE VISIBLE}
\vee
\text{SUBFILTER RESIDUAL}.
$$

But:

$$
\text{COARSE VISIBLE}
\Rightarrow
\text{ACTIVE PRESSURE--FLUX WORK}
$$

remains an external/open observability problem.

### Slow active density

Need a forward active set:

$$
\mathcal I_{\rm act}
$$

with:

$$
\sum_{k\in\mathcal I_{\rm act}}
w_k
=
\infty
$$

or the more general divergent weighted active demand.

### Model-cone packet

Strain growth satisfies a scale-invariant packet lower bound through:

$$
(\chi_{SV}-1)_+
\|-\Delta S\|_2^2.
$$

This supplies an independent critical recurrence coordinate.

## FCBP-04 — Moving Filters / Borderline Critical Lift

Targets:

1. control filter-switch defects;
2. test localized BV in filter length;
3. compare moving-filter and finest-common-filter routes;
4. obtain uniform coarse observability;
5. control slow-schedule weighted leakage/backscatter;
6. prove weighted active-slab density or a recurrence alternative;
7. decide the Slow-Scale Critical-Lift Compiler.

## Current obligations

$$
CL\mbox{-}DER:
\mathrm{PARTIALLY\ CLOSED}.
$$

$$
CL\mbox{-}REM:
\mathrm{OPEN/PARTIAL}.
$$

$$
CL\mbox{-}PACK:
\mathrm{PARTIALLY\ OPEN}
$$

with a new non-summable schedule already proved.

## Hard rules

- The published pressure--flux theorem is geometric; the variable-radius extension is an internal theorem derived from its local identity/telescope proof.
- A non-summable schedule is not enough without active-work density and paid-residual closure.
- One fixed filter cannot remain scale-relative on an infinite shrinking chain.
- Moving filters must pay explicit endpoint switch defects.
- Finite-chain common-filter approximations require uniform-in-chain-length constants.
- Coarse CKN visibility is not signed-work observability.
- No regularity claim is made.
