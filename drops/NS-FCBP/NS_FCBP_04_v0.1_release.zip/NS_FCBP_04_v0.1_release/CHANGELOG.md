# CHANGELOG

## v0.1 — 2026-08-16

- Proves a uniform L2 derivative estimate with respect to compact mollifier length.
- Derives the exact continuously moving-filter coarse Navier-Stokes equation.
- Shows slow full-thickness relative-filter motion has square-integrable filter speed.
- Proves the total weighted filter-drift work is paid by the Leray energy/dissipation budget.
- Bypasses discrete Filter-Switch Packing on the full-thickness slow schedule.
- Corrects the interpretation of Schedule Lift by proving uniform parabolic horizon alignment forces summable radii.
- Defines Long-Age Observability for the off-horizon full-thickness slow route.
- Introduces a co-moving heat-semigroup filter s(t)=a(T*-t) which absorbs filter motion into reduced positive viscosity.
- Proves an exact horizon-aligned heat-filter pressure-flux telescope.
- Proves the universal time-thickness bound sum w_k delta_k <= 2c.
- Shows bounded normalized work rate cannot exploit a non-summable scale weight on horizon-aligned thin slabs.
- Proves a conditional inverse-thickness Borderline Horizon Work Compiler.
- Defines the Causal-Renewal to Work Bridge.
- Connects the remaining observability frontier to recent combined moving-window pressure/flux/energy/trace reductions.
- Moves the frontier from filter compatibility to temporal observability and paid-side recurrence.
