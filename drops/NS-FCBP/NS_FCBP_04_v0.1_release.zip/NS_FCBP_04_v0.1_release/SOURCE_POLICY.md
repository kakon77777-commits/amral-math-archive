# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- FCBP-03 Schedule Lift is not promoted to Horizon Critical Lift.
- The compact-mollifier continuous-drift theorem and heat-semigroup co-moving-filter theorem are internal deductions.
- The heat-semigroup module is restricted to the global R3 finite-energy setting used in this program.
- Moving-window/invisible-defect results are not promoted beyond their stated external hypotheses.
- Bounded thin-slab work rate is explicitly insufficient for a horizon obstruction.
- No Critical Lift, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
