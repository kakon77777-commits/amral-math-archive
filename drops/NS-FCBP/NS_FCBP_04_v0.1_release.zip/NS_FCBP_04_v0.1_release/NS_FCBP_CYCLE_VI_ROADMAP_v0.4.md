---
title: "Navier–Stokes Forest Coercive Budget Program：Cycle-VI Roadmap"
version: "v0.4"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-FCBP Cycle-VI Roadmap v0.4

## FCBP-01

Established:

- one-derivative critical forcing gap;
- summable-weight no-go;
- structural cancellation requirement.

## FCBP-02

Established:

- filtered near-field coercivity;
- comparable-annulus barrier;
- critical commutator recurrence;
- signed-work necessity.

## FCBP-03

Established:

- variable-radius pressure--flux telescope;
- non-summable slow-scale schedule;
- moving-filter endpoint defect formula;
- conditional slow-scale work-depletion compiler.

## FCBP-04 — Horizon Filter / Temporal Criticality

### Continuous compact-filter drift

For the mollifier:

$$
S_\ell f=\rho_\ell*f,
$$

$$
\boxed{
\|\partial_\ell S_\ell f\|_2
\lesssim
\|\nabla f\|_2.
}
$$

A continuously moving filter adds:

$$
\dot\ell\partial_\ell U
$$

to the coarse equation.

On:

$$
r_k=r_0(k+1)^{-\beta},
\qquad
1/2<\beta\le1,
$$

with full parabolic slabs and:

$$
\ell_k=\sigma r_k,
$$

$$
\boxed{
\int|\dot\ell|^2dt<\infty.
}
$$

Therefore the weighted filter-drift cost is paid by the Leray energy/dissipation budget.

Discrete FSP is bypassed on this off-horizon/full-thickness route.

### Parabolic alignment no-go

If:

$$
\tau_{k+1}-\tau_k=r_k^2,
$$

$$
\tau_k\uparrow T_\ast,
$$

and:

$$
T_\ast-\tau_k
\le
Cr_k^2,
$$

then:

$$
\boxed{
\sum_kr_k<\infty.
}
$$

Thus a non-summable full-thickness schedule cannot remain within bounded local parabolic age of the horizon.

For the slow power schedule:

$$
\boxed{
(T_\ast-\tau_k)/r_k^2
\asymp k.
}
$$

This creates:

$$
\boxed{
LAO
=
\text{Long-Age Observability}.
}
$$

### Horizon-aligned thin slabs

Set:

$$
\tau_k=T_\ast-cr_k^2.
$$

Then:

$$
\delta_k
=
(\tau_{k+1}-\tau_k)/r_k^2
=
c[1-(r_{k+1}/r_k)^2].
$$

### Co-moving heat filter

Use:

$$
S_s=e^{s\Delta},
$$

$$
s(t)=a(T_\ast-t),
\qquad
0<a<\nu.
$$

Then:

$$
\boxed{
\partial_tU
-
(\nu-a)\Delta U
+
\nabla\cdot(U\otimes U)
+
\nabla P
=
-\nabla\cdot R.
}
$$

The changing filter is absorbed into positive effective viscosity.

At horizon-aligned scales:

$$
\ell/r
$$

remains fixed.

This yields an exact horizon-aligned moving-filter pressure--flux telescope with no switch debt.

### Time-thickness barrier

For every decreasing horizon-aligned radius sequence:

$$
\boxed{
\sum_k
w_k\delta_k
\le
2c.
}
$$

Therefore bounded normalized work-rate signals remain summable even if:

$$
\sum_kw_k=\infty.
$$

### Borderline horizon compiler

To exploit the non-summable scale weight one needs:

$$
\boxed{
\mathcal W_k^+/\delta_k
\gtrsim
\delta_k^{-1}
}
$$

on a set with divergent:

$$
w_k
$$

weight, equivalently order-one work per thin slab.

This motivates:

$$
\boxed{
CRW
=
\text{Causal-Renewal to Work Bridge}.
}
$$

### External moving-window calibration

Recent combined pressure/flux/energy/trace theory defines depletion-effective observability by:

$$
\sum
\lambda_nM_n^{-q}
=
\infty.
$$

A persistent non-CKN branch under its hypotheses forces:

$$
\boxed{
\text{non-effective moving-window observability}
\vee
\text{NS-realizable combined-invisible defect cascade}.
}
$$

This independently confirms the moving-window/observability frontier.

## FCBP-05 — Temporal Criticality / Paid-Side Closure

Targets:

1. Long-Age Observability;
2. Causal-Renewal to Work Bridge;
3. weighted backscatter recurrence;
4. localization leakage cancellation/packing;
5. combined pressure--flux--energy--trace observability;
6. horizon-aligned Critical Lift.

## Current obligations

Filter endpoint compatibility:

$$
\boxed{
\mathrm{SUBSTANTIALLY\ CLOSED}.
}
$$

Scale-weight lift:

$$
\boxed{
\mathrm{PROVED}.
}
$$

Temporal horizon lift:

$$
\boxed{
LAO\vee CRW
:
\mathrm{OPEN}.
}
$$

Paid-side closure:

$$
\boxed{
\mathrm{OPEN}.
}
$$

Combined-invisible cascade:

$$
\boxed{
\mathrm{OPEN}.
}
$$

## Hard rules

- Schedule Lift is not Horizon Critical Lift.
- Full-parabolic slow slabs lose fixed parabolic horizon alignment.
- Horizon-aligned slow slabs become thin in normalized time.
- Non-summable scale weights can be neutralized by summable time thickness.
- Heat-semigroup moving filters are an internal global-R3 module, not attributed to the compact-mollifier pressure-flux theorem.
- A bounded normalized work rate is insufficient on thin slabs.
- No regularity claim is made.
