# CHANGELOG

## v0.1 — 2026-08-16

- Launches the Navier-Stokes Forest Coercive Budget Program.
- Derives exact Sobolev scaling laws for velocity and vorticity nonlinear forcing.
- Proves the energy-class forcing bounds miss criticality by exactly one spatial derivative at p=4/3.
- Introduces critical renormalizations of the H^{-2} forcing packet and H^2 dual congestion.
- Proves their cut-product is scale invariant.
- Proves globally finite weak forcing still gives only a summably weighted critical-packet bound.
- Proves a general summable-weight Critical-Lift no-go.
- Defines the non-summable Critical Lift Problem and forest criticality index.
- Audits Miller strain-vorticity orthogonality as exact structural cancellation.
- Audits 2026 filtered vortex-stretching diffusion absorption as scale-uniform near-field coercivity.
- Audits 2026 pressure-flux work depletion as signed weighted finite-chain telescoping.
- Compresses the next obligations to CL-DER, CL-REM, and CL-PACK.
- Moves the frontier to filtered far-field/Carleson critical lift.
