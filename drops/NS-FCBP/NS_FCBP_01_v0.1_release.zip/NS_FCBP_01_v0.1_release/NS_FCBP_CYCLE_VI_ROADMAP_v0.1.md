---
title: "Navier–Stokes Forest Coercive Budget Program：Cycle-VI Roadmap"
version: "v0.1"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-FCBP Cycle-VI Roadmap v0.1

## Starting point

CFOP Cycle V found the final forest budget residual:

$$
R_{F\mbox{-}HCONG}
\vee
R_{F\mbox{-}CAP}
\vee
R_{F\mbox{-}DENSE}.
$$

Known universal finite energy-class budgets are summable across geometric dangerous scales.

The missing theorem is a near-critical forest coercive budget.

## FCBP-01 — Critical Forest Coercivity

### Exact forcing scaling

Velocity nonlinearity:

$$
\mathcal N_\lambda
=
\lambda^3
\mathcal N(\lambda x,\lambda^2t).
$$

Vorticity forcing:

$$
\mathcal G_\lambda
=
\lambda^4
\mathcal G(\lambda x,\lambda^2t).
$$

Critical conditions:

$$
2/p=3/2-s
$$

for:

$$
\mathcal N\in L_t^p\dot H^{-s},
$$

and:

$$
2/p=5/2-s
$$

for:

$$
\mathcal G\in L_t^p\dot H^{-s}.
$$

### One-derivative gap

At:

$$
p=4/3,
$$

energy gives:

$$
\mathcal N\in H^{-1},
\qquad
\mathcal G\in H^{-2},
$$

while criticality requires:

$$
\mathcal N\in L^2,
\qquad
\mathcal G\in H^{-1}.
$$

Thus one spatial derivative is missing.

### Critical renormalization

Define:

$$
\widehat{\mathfrak B}_{-2}
=
R^{-4/3}
\mathfrak B_{-2},
$$

and:

$$
\widehat{\mathfrak K}_{2}
=
R^4
\mathfrak K_2.
$$

Then:

$$
\boxed{
\widehat{\mathfrak B}_{-2}^3
\widehat{\mathfrak K}_{2}
\ge
\sigma^4.
}
$$

The local cut relation is critical.

The global forcing bound remains weighted:

$$
\sum
R_n^{4/3}
\widehat{\mathfrak B}_{-2,n}
<
\infty.
$$

### Summable-weight no-go

A global estimate:

$$
\sum
w_nc_n<\infty
$$

with:

$$
\sum w_n<\infty
$$

cannot exclude:

$$
c_n\ge c_0
$$

at every generation.

Thus a final obstruction requires a non-summable critical lift.

### Structural cancellation modules

1. Miller strain--vorticity orthogonality.
2. Filtered positive near-field stretching absorbed by diffusion up to lower-order reservoir.
3. Pressure--flux combined work weighted finite-chain telescoping.

All provide genuine Navier--Stokes-specific coercivity.

None currently yields a universally finite non-summable forest budget.

### Critical Lift Problem

Lift:

$$
\sum
w_n\mathcal C_n
\le
B
$$

with summable:

$$
w_n
$$

to:

$$
\sum
\widetilde w_n\mathcal C_n
\le
\widetilde B
$$

with:

$$
\sum
\widetilde w_n
=
\infty.
$$

A logarithmic non-summable lift may suffice.

### FCBP obligations

$$
\boxed{
CL\mbox{-}DER
}
$$

one-derivative gap;

$$
\boxed{
CL\mbox{-}REM
}
$$

structural remainders;

$$
\boxed{
CL\mbox{-}PACK
}
$$

weighted-to-non-summable packing/telescoping.

## FCBP-02 — Filtered Stretching Critical Lift

Targets:

1. integrate filtered near-field coercivity into forest cuts;
2. attack far-field annular Carleson packing;
3. exploit fixed-annulus harmonic/affine cancellation;
4. control commutator/localization residuals;
5. seek alpha<=0 or logarithmic non-summable scale weight;
6. prove a critical-lift theorem or no-go.

## FCBP-03 — Strain Model-Cone / Pressure-Flux Lift

Targets:

1. forest version of model-cone coercivity;
2. pressure-flux signed cancellation;
3. backscatter and leakage census;
4. finite-chain to horizon-chain lift.

## Hard rules

- Critical normalization is not a global critical budget.
- A summable scale weight cannot obstruct constant dangerous cost on geometric scales.
- Generic Sobolev duality does not recover the missing derivative.
- Structural cancellation modules must keep all residuals explicit.
- External filtered/coarse-grained results are not promoted beyond their proved hypotheses.
- No regularity claim is made.
