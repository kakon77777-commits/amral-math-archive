# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Critical renormalization is not promoted to a global critical finite budget.
- The shell-localized dual scaling ledger is a scaling model, not an exact adjoint propagation theorem.
- External structural-cancellation papers are used only within their stated hypotheses.
- Summable weighted telescoping is not promoted to unweighted/critical packing.
- No Critical Lift, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
