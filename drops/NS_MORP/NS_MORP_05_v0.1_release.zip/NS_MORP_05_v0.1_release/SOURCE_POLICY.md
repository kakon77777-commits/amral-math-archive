# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Atomic escape reprofiling requires explicit inherited secondary compactness and trace tightness.
- Diffuse escape/multiplicity growth is not treated as a contradiction.
- Ancient Liouville theorems are applied only under their exact external hypotheses.
- Zero commutator stress/covariance is not treated as proof of trivial Young microstructure.
- Carrier classification is not promoted to non-tautological carrier extraction.
- Profile reprofiling is not promoted to actual infinite-branch shadowing.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
