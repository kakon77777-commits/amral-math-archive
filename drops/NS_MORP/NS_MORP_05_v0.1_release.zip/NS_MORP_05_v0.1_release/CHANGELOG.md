# CHANGELOG

## v0.1 — 2026-08-16

- Closes Cycle VII as a minimal-obstruction normal-form and partial-rigidity cycle.
- Proves atomic space-scale escape can be reprofiled into a nonzero state-visible secondary profile under inherited compactness guards.
- Proves non-reprofiled atom collapse forces divergent effective multiplicity and carrier entropy.
- Proves diffuse profile splitting retains the minimal ratio on every surviving component and does not self-close by minimality.
- Proves a bounded ancient solution with uniformly controlled L3 spatial tails along a backward sequence enters the Albritton-Barker Liouville class.
- Unifies surviving ancient and escape branches as noncompact/diffuse carrier behavior.
- Retains the filtered increment Young-profile non-injectivity warning and refuses a false zero-covariance rigidity claim.
- Refines M-XTR: carrier routes are classified but universal dangerous-to-carrier extraction remains open.
- Compresses the final MORP obstruction to a minimal zero-tax kernel-saturated diffuse carrier.
- Launches the Navier-Stokes Diffuse Carrier Rigidity Program.
