# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Return invariance is formulated on later native-separated re-root windows, not on every intermediate time.
- Profile transition and actual original-solution return realization are distinct.
- Minimality does not exclude profile splitting without a strict splitting tax, uniqueness, or equivalent rigidity.
- Ancient-solution extraction is applied only under the external Type-I hypotheses.
- Defect-measure homogeneity is conditional on a pure-scaling fixed transition.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
