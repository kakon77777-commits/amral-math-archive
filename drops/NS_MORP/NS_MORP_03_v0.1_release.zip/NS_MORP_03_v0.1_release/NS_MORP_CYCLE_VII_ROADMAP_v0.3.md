---
title: "Navier–Stokes Minimal Obstruction Rigidity Program：Cycle-VII Roadmap"
version: "v0.3"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-MORP Cycle-VII Roadmap v0.3

## MORP-01

Defined the normalized native obstruction slice and proved the abstract compactness/minimality/transition-rigidity compiler.

## MORP-02

Built a defect-completed compactness topology:

- strong local velocity;
- strong active/harmonic-quotient pressure;
- weak harmonic tail;
- dissipation defect measure;
- selected trace/trace defect;
- relative-scale/spatial defect measures;
- weak transition residual.

Ordinary local state/active-pressure compactness is substantially closed under standard bounds.

The main extraction gap remains terminal-time danger versus trace/thickened carrier.

## MORP-03 — Return Dynamics / Rigidity Entry

### Return transition

The correct transition is:

$$
T_{\rm ret}
=
N_{\rm norm}
\circ
\text{later native-separated re-root}.
$$

It does not require every intermediate window to remain dangerous.

### Minimal return rigidity

If:

$$
J(T_{\rm ret}D)+\Delta_{\rm ret}(D)\le J(D),
\qquad
\Delta_{\rm ret}\ge0,
$$

then a minimizer satisfies:

$$
\boxed{
\Delta_{\rm ret}(D_\ast)=0
}
$$

and returns to the minimal level set.

### Profile splitting

Introduce a homogeneous native carrier:

$$
a(D).
$$

For a normalized minimizing profile decomposition:

$$
1
=
\sum_j a_j+a_{\rm rem},
$$

with cost decoupling, every nonzero surviving profile must itself attain the minimal ratio:

$$
\boxed{
J(D^{(j)})=q_\ast a_j.
}
$$

Thus minimality does not automatically eliminate profile splitting.

A positive strict splitting tax excludes genuine dichotomy.

### State-visible Type-I route

Under external Type-I rescaling hypotheses, a nontrivial state-visible singular profile may produce a bounded mild ancient solution.

If the recurrent minimizer is unique modulo symmetry, the state becomes a discrete renormalization fixed point / ancient renormalized-periodic normal form.

### Defect-only route

A pure-scaling return-fixed dissipation defect satisfies:

$$
\boxed{
\nu(\Phi_\lambda E)
=
\lambda\nu(E).
}
$$

Hence:

$$
\boxed{
\nu(Q_{\lambda r})
=
\lambda\nu(Q_r).
}
$$

In particular:

$$
\boxed{
\nu(\{0\})=0.
}
$$

Thus a defect-only fixed obstruction must be scale-extended rather than a point atom.

### Transition alternatives

A recurrent minimal sequence is reduced, conditionally, to:

- single minimal return carrier;
- minimal equality splitting;
- Type-I ancient state normal form;
- degree-one parabolic defect normal form.

## MORP-04 — Equality-Manifold Rigidity

Targets:

1. ancient-state PFET/model-cone/increment kernel intersection;
2. Liouville/backward-uniqueness input for state-visible branch;
3. degree-one defect-measure classification;
4. zero filtered-increment rigidity;
5. strict splitting tax / uniqueness;
6. minimal obstruction exclusion audit.

## Current obligations

$$
M\mbox{-}XTR:
\mathrm{OPEN}.
$$

$$
M\mbox{-}COM:
\mathrm{PARTIAL/SUBSTANTIAL}.
$$

$$
M\mbox{-}TR:
\mathrm{OPEN/PARTIAL}.
$$

$$
M\mbox{-}RIG:
\mathrm{ENTERED/OPEN}.
$$

## Hard rules

- Transition invariance means legal native re-root/return invariance, not danger at every intermediate time.
- Profile transition and actual original-solution transition remain distinct.
- Minimality alone does not imply one profile; equality splitting is allowed unless strict subadditivity/tax is proved.
- Ancient velocity profiles do not automatically inherit MORP detector/kernel coordinates.
- Defect-measure scaling is conditional on a pure-scaling fixed transition.
- No regularity claim is made.
