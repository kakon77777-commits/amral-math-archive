# CHANGELOG

## v0.1 — 2026-08-16

- Replaces fixed-step transition invariance by a normalized native return/re-root transition.
- Separates profile transition from actual original-solution transition realization.
- Proves minimal recurrent obstructions have zero net return depletion.
- Introduces a homogeneous native carrier and obstruction ratio for profile-splitting analysis.
- Proves Minimal Profile Splitting Saturation: every surviving component of a minimizing split is itself minimal.
- Proves a positive strict splitting tax excludes genuine minimal dichotomy.
- Defines minimal equality splitting when the splitting tax vanishes.
- Adds the conditional Type-I state-visible route to bounded mild ancient solutions.
- Shows uniqueness modulo symmetry forces a discrete renormalization fixed point.
- Computes the Navier-Stokes scaling law for dissipation defect measures.
- Proves a pure-scaling defect fixed point is parabolically degree-one homogeneous.
- Proves such a defect cannot be a point atom at the scaling center.
- Reduces recurrent minimal dynamics to single carrier, equality splitting, ancient state, or degree-one defect normal forms under stated hypotheses.
- Moves the next paper to direct equality-manifold rigidity.
