# CHANGELOG

## v0.1 — 2026-08-16

- Begins direct exclusion of MORP equality-manifold normal forms.
- Defines the distributional local-energy slack as a native nonnegative rigidity channel.
- Proves the dissipation defect is dominated by limiting local-energy slack.
- Proves zero local-energy slack forces zero dissipation defect.
- Excludes state-trivial pure interior dissipation-defect profiles.
- Removes the pure degree-one dissipation-defect fixed point from the zero-cost kernel-saturated branch.
- Imports Type-I ancient-solution and backward-sequence L3 Liouville rigidity.
- Splits the ancient branch into known Liouville-excluded subclasses and the general surviving ancient kernel.
- Adds self-similar, asymptotically DSS, Morrey/Lorentz, and 2026 rotated Type-I Liouville calibrations.
- Proves model-cone equality rigidity under finite-H1 equal-return assumptions.
- Proves zero-tax minimal splitting can carry mass only in surviving kernel subclasses.
- Defines the escape-only kernel after local state/pressure/dissipation collapse.
- Compresses the surviving equality manifold to ancient-kernel, escape-kernel, and splitting supported on those kernels.
- Moves the next paper to escape re-profiling and ancient-kernel intersection.
