---
title: "Navier–Stokes Minimal Obstruction Rigidity Program：Cycle-VII Roadmap"
version: "v0.4"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-MORP Cycle-VII Roadmap v0.4

## MORP-01

Defined minimal native obstruction slices, compactness/minimality dichotomy, and abstract transition rigidity.

## MORP-02

Built a defect-completed compactness topology and reduced extraction to trace/thickened/escape carriers.

## MORP-03

Introduced native return transitions, minimal equality splitting, Type-I ancient state routes, and degree-one dissipation-defect fixed points.

## MORP-04 — Equality-Manifold Rigidity Audit

### Local-energy slack kills pure dissipation defect

If:

$$
u_n\to u_\ast
\quad
\text{strong }L^3_{\rm loc},
$$

$$
p_n\rightharpoonup p_\ast
\quad
\text{weak }L^{3/2}_{\rm loc},
$$

and:

$$
|\nabla u_n|^2dxdt
\stackrel{\ast}{\rightharpoonup}
|\nabla u_\ast|^2dxdt+\nu_{\rm diss},
$$

then:

$$
\boxed{
2\nu
\int\phi\,d\nu_{\rm diss}
\le
\mathscr S_{\rm LEI}(u_\ast,p_\ast;\phi).
}
$$

Therefore zero local-energy slack implies:

$$
\boxed{
\nu_{\rm diss}=0.
}
$$

If:

$$
u_\ast=0,
$$

the pressure is spatial gauge only and the slack is zero.

Hence:

$$
\boxed{
\text{pure interior dissipation-defect profile}
:
\mathrm{EXCLUDED}.
}
$$

### Ancient Liouville cuts

Under Albritton--Barker:

- Type-I singularity can produce a nontrivial bounded mild ancient solution with Type-I decay;
- a bounded ancient solution with uniformly bounded:
  $$
  L^3
  $$
  norm along a backward sequence is trivial.

Thus a surviving ancient MORP state must escape that backward-sequence:

$$
L^3
$$

class.

Known self-similar/DSS Liouville results further remove selected integrable, periodic, Morrey/Lorentz, and recent rotated Type-I subclasses.

The general bounded ancient kernel remains open.

### Model-cone equality

If on a finite-H1 return interval:

$$
\chi_{SV}\le1
$$

and endpoint:

$$
\dot H^1
$$

strain norms agree, then:

$$
\boxed{
\mathcal R_{SV}=\Delta S
}
$$

where:

$$
-\Delta S\neq0,
$$

and the strain dynamics lie on an exact equality manifold.

### Zero-tax splitting support

Every positive carrier in a zero-cost minimal split is itself kernel-saturated.

Any profile belonging to a rigidity-excluded kernel subclass has zero carrier mass.

Therefore equality splitting can only be supported on surviving ancient or escape-only kernel profiles.

### Surviving classes

$$
\boxed{
\text{A-KERNEL}
}
$$

general ancient mechanism-kernel intersection outside known Liouville subbranches;

$$
\boxed{
\text{E-KERNEL}
}
$$

state-trivial trace/scale/spatial/transition escape;

$$
\boxed{
\text{S-KERNEL}
}
$$

zero-tax splitting composed entirely of A-KERNEL/E-KERNEL carriers.

## MORP-05 — Escape / Ancient Kernel / Cycle-VII Audit

Targets:

1. reprofile-or-tax theorem for trace/scale/spatial escape;
2. selected-time trace recurrence and scale-recentering;
3. ancient PFET/model-cone/increment kernel intersection;
4. derive known Liouville hypotheses from native minimality where possible;
5. zero-tax splitting after reprofile;
6. M-XTR trace-or-thickening closure;
7. Cycle-VII final minimal-obstruction audit.

## Current obligations

$$
M\mbox{-}XTR:
\mathrm{OPEN}.
$$

$$
M\mbox{-}COM:
\mathrm{PARTIAL/SUBSTANTIAL}.
$$

$$
M\mbox{-}TR:
\mathrm{OPEN/PARTIAL}.
$$

$$
M\mbox{-}RIG:
\mathrm{PARTIALLY\ CLOSED/OPEN}.
$$

## Hard rules

- Dissipation defect is controlled by local-energy slack; do not keep a pure dissipation-defect branch after imposing zero slack.
- CKN singular-set dimension is not identified with the MORP defect measure.
- Bounded ancient solutions are not generally classified in three dimensions.
- External self-similar/DSS Liouville theorems apply only under their stated hypotheses.
- Model-cone equality rigidity requires finite H1 and endpoint equality in the same normalized chart.
- Filtered increment zero-set rigidity is not currently proved.
- No Navier-Stokes regularity claim is made.
