# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- The MORP dissipation defect is not identified with the CKN singular-set measure.
- Ancient Liouville results are applied only under their exact boundedness/integrability/self-similarity/rotation hypotheses.
- General bounded ancient 3D Navier-Stokes solutions are not declared trivial.
- Model-cone equality rigidity is conditional on finite H1 control and equal endpoint strain H1 norm.
- Filtered critical increment zero is not declared to imply triviality.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
