---
title: "Navier–Stokes Minimal Obstruction Rigidity Program：Cycle-VII Roadmap"
version: "v0.1"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-MORP Cycle-VII Roadmap v0.1

## Starting point

FCBP Cycle VI reduced the unresolved coercive problem to:

$$
XTR
\vee
UNI
\vee
RIG
\vee
SIGN.
$$

The structural audit literature independently identifies minimal obstruction rigidity as a long-term compactness-rigidity target.

MORP changes the question from:

> which additional observable should be added?

to:

> if all current coercive channels fail, what is the smallest nonzero NS-realizable obstruction and what transition law does minimality force?

## MORP-01 — Minimal Obstruction Normal Form

### Native slice

Define:

$$
\mathscr O_1
=
\{
D:
d_{\rm nat}(D)\ge1,
\ \mathcal N_{\rm pkg}(D)\le C_\ast
\}
$$

inside the symmetry-normalized closure of NS-generated packages.

Nonemptiness requires non-tautological extraction.

### Obstruction cost

$$
\mathfrak J
=
O_{\rm PFET}
+
M_{SV}
+
\widetilde S^{(3)}
+
\mathsf{Paid}
+
R_{\rm nat}.
$$

### Compactness dichotomy

If:

$$
\mathscr O_1
$$

is compact and:

$$
\mathfrak J
$$

is lower semicontinuous, then:

$$
\boxed{
m_\ast>0
}
$$

or there exists:

$$
\boxed{
D_\ast
\in
\mathscr O_1
\cap
\ker O_{\rm PFET}
\cap
\ker M_{SV}
\cap
\ker\widetilde S^{(3)}
\cap
\ker\mathsf{Paid}
\cap
\ker R_{\rm nat}.
}
$$

### Transition rigidity

If:

$$
T(\mathscr O_1)\subset\mathscr O_1
$$

and:

$$
\mathfrak J(TD)+\Delta(D)
\le
\mathfrak J(D),
\qquad
\Delta\ge0,
$$

then every minimizer satisfies:

$$
\boxed{
\Delta(D_\ast)=0
}
$$

and:

$$
\boxed{
TD_\ast\in\mathscr M_\ast.
}
$$

A unique minimizer modulo symmetry is transition-fixed modulo symmetry.

### Strict rigidity

If the compact minimal set has:

$$
\Delta>0
$$

everywhere, it cannot exist.

Thus the rigidity target is the equality manifold:

$$
\boxed{
\mathscr O_1
\cap
\mathcal K_{\rm ext}
\cap
\{\Delta=0\}.
}
$$

### No-go safeguards

- infimum does not imply minimizer without compactness;
- translation/scale/profile splitting must be normalized or compactified;
- copied dangerous coordinates are not native extraction;
- quotient/profile minimality is not actual-branch realization.

## MORP-02 — Native Defect Extraction / Compactness

Targets:

1. choose a non-tautological native topology;
2. use suitable-weak and profile compactness;
3. control pressure/harmonic tails;
4. distinguish state-visible and defect-only limits;
5. fix translation/scale gauges;
6. prove sequential compactness of:
   $$
   \mathscr O_1;
   $$
7. construct a genuine minimal profile if possible.

## MORP-03 — Transition Rigidity

Targets:

1. prove normalized transition invariance;
2. extract a transition law from recursive audit/causal evolution;
3. identify strict depletion taxes;
4. classify equality cases;
5. test scale-stationary, ancient, self-similar, monotone-defect normal forms.

## MORP-04 — Rigidity / Exclusion Audit

Targets:

1. intersect PFET kernel with model-cone and filtered-increment kernels;
2. classify defect-only recurrent profiles;
3. import ancient-solution/Liouville theorems where applicable;
4. decide whether a nonzero minimal obstruction can survive.

## Current obligations

$$
\boxed{
M\mbox{-}XTR
}
$$

non-tautological extraction,

$$
\boxed{
M\mbox{-}COM
}
$$

compactness modulo symmetries,

$$
\boxed{
M\mbox{-}TR
}
$$

transition invariance,

$$
\boxed{
M\mbox{-}RIG
}
$$

kernel/equality-manifold rigidity.

## Hard rules

- No dangerous mark may be copied into a detector and used to prove native separation.
- No minimizer may be claimed without an attainment/compactness theorem.
- Compactness must handle translation, scaling, harmonic pressure, and profile splitting.
- A profile-limit obstruction is not an actual original-solution infinite branch.
- Minimality is useful only after a strict transition/depletion law is proved.
- No Navier-Stokes regularity claim is made.
