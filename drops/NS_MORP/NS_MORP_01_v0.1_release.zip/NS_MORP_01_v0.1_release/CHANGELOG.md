# CHANGELOG

## v0.1 — 2026-08-16

- Launches the Navier-Stokes Minimal Obstruction Rigidity Program.
- Defines a native normalized obstruction slice that forbids copied dangerous detector coordinates.
- Defines an extended observation/mechanism/paid-side obstruction cost.
- Proves a compact coercive-gap versus minimal-invisible-profile dichotomy.
- Shows a zero-cost minimizer saturates the kernels of every included nonnegative channel.
- Proves infimum alone does not yield a minimizer without compactness.
- Defines a normalized transition map and proves minimal transition rigidity under a nonnegative depletion law.
- Defines the compact minimal set and proves transition invariance/equality-tax saturation.
- Proves a strict-rigidity exclusion criterion.
- Separates unique-minimizer scale-stationarity from compact minimal-set dynamics.
- Distinguishes state-visible and defect-only minimal profiles.
- Proves a finite-component native separation carrier lemma.
- Reasserts the profile-to-actual shadowing gap.
- Calibrates the program against classical Navier-Stokes critical-element and Type-I ancient-solution theory.
- Moves the next frontier to non-tautological native extraction and quotient compactness.
