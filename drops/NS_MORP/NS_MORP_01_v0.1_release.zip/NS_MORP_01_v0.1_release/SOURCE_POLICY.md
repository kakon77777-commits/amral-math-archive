# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- A minimal obstruction is not claimed without non-tautological extraction and compactness/attainment.
- Critical-element and ancient-solution papers are calibration, not automatic realizations of the MORP obstruction.
- Quotient/profile compactness is not promoted to actual original-solution shadowing.
- Transition rigidity is conditional on normalized class invariance and a nonnegative depletion law.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
