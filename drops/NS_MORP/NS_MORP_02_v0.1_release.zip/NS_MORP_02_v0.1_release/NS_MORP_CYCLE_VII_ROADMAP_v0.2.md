---
title: "Navier–Stokes Minimal Obstruction Rigidity Program：Cycle-VII Roadmap"
version: "v0.2"
date: "2026-08-16"
status: "Active research roadmap"
---

# NS-MORP Cycle-VII Roadmap v0.2

## MORP-01 — Minimal Obstruction Normal Form

Established the abstract compiler:

$$
\text{native extraction}
\to
\text{compactness}
\to
\text{minimal profile}
\to
\text{transition rigidity}.
$$

The key dichotomy is:

$$
\boxed{
\text{positive native coercive gap}
\vee
\text{minimal kernel-saturated obstruction}.
}
$$

## MORP-02 — Native Extraction / Compactness

### Local state compactness

Under uniform local suitable-weak bounds:

$$
u_n
\to
u_\ast
\quad
\text{strong in }
L^3_{\rm loc}.
$$

### Pressure

Local decomposition:

$$
p_n
=
p_n^{act}
+
h_n.
$$

Strong velocity convergence gives:

$$
p_n^{act}
\to
p_\ast^{act}
\quad
\text{strong in }
L^{3/2}_{\rm loc}.
$$

Therefore:

$$
\boxed{
[p_n]_{\mathcal H}
\to
[p_\ast]_{\mathcal H}
}
$$

strongly in the harmonic-pressure quotient.

The physical harmonic tail remains a separate weak carrier.

### Dissipation defect

$$
|\nabla u_n|^2dxdt
\stackrel{\ast}{\rightharpoonup}
|\nabla u_\ast|^2dxdt
+
\nu_{\rm diss},
$$

with:

$$
\nu_{\rm diss}\ge0.
$$

### Time-slice barrier

A terminal-time lower bound need not survive in a spacetime topology.

Thus extraction requires:

$$
\boxed{
\text{TRACE-CARRIER}
\vee
\text{THICKENED-DEFECT-CARRIER}.
}
$$

### Thickened carrier

If:

$$
\int
\chi
|\nabla u_n|^2
\ge
\eta,
$$

then the limit has:

$$
\boxed{
\text{state dissipation}\ge\eta/2
\vee
\text{dissipation defect}\ge\eta/2.
}
$$

### Trace compactness

Fixed relative-frequency band + global trace L2 bound + spatial tightness gives strong:

$$
L^2
$$

trace compactness and a nonzero selected-time limit.

### Scale compactification

Relative-shell energy shares define probability measures on:

$$
\mathbb N_0\cup\{\infty\}.
$$

The limit separates:

$$
\boxed{
\text{finite-relative-frequency carrier}
}
$$

from:

$$
\boxed{
\text{relative-frequency escape}.
}
$$

### Defect-completed package

The compactness package contains:

- strong velocity state;
- strong harmonic-quotient pressure;
- weak harmonic tail;
- dissipation defect measure;
- scale/spatial defect measures;
- selected-time trace/trace defect;
- weak transition residual.

Under explicit guards this package is sequentially compact.

### Conditional minimal-profile existence

If M-XTR supplies a nonempty native-separated sequence and the native slice is sequentially closed, then lower-semicontinuous obstruction cost attains its minimum in the defect-completed package closure.

### Current M-COM status

Local state/active-pressure sector:

$$
\boxed{
\mathrm{SUBSTANTIALLY\ CLOSED}.
}
$$

Full profile-splitting/trace sector:

$$
\boxed{
\mathrm{OPEN}.
}
$$

## MORP-03 — Transition Invariance / Profile Carrier Selection

Targets:

1. define the normalized transition map on defect-completed packages;
2. prove preservation of native separation;
3. treat finite versus diffuse profile splitting;
4. test whether minimality eliminates multi-profile dichotomy;
5. connect Type-I state-visible minimizers to ancient solutions;
6. derive transition laws for defect-only minimizers;
7. classify the first equality-manifold normal forms.

## Current obligations

$$
M\mbox{-}XTR:
\mathrm{OPEN}.
$$

$$
M\mbox{-}COM:
\mathrm{PARTIAL/SUBSTANTIAL}.
$$

$$
M\mbox{-}TR:
\mathrm{OPEN}.
$$

$$
M\mbox{-}RIG:
\mathrm{OPEN}.
$$

## Hard rules

- A selected-time dangerous mark is not a spacetime defect without a persistence/thickening theorem.
- Harmonic pressure must be quotiented for strong pressure compactness or retained as a separate weak carrier.
- Strong velocity convergence does not erase dissipation defect measures.
- Fixed-band trace compactness requires explicit frequency and spatial tightness.
- Scale/profile escape must be retained as a defect coordinate rather than silently discarded.
- Minimal profile existence in the closure is not actual original-solution branch realization.
- No Navier-Stokes regularity claim is made.
