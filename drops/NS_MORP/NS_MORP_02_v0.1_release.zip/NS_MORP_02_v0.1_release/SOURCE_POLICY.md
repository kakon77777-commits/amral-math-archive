# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- A terminal-time dangerous mark is not promoted to a spacetime defect without an explicit persistence/thickening theorem.
- Harmonic pressure is quotiented only for the strong pressure coordinate and is retained separately when physically observable.
- Relative-frequency/spatial escape is retained as a defect coordinate rather than discarded.
- Minimal-profile attainment is conditional on native extraction, defect-completed tightness, slice closure, and lower semicontinuity.
- Profile-limit existence is not promoted to actual original-solution branch realization.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
