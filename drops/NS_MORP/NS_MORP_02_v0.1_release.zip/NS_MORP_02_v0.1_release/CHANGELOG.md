# CHANGELOG

## v0.1 — 2026-08-16

- Builds an explicit defect-completed compactness topology for MORP.
- Proves strong local L3 velocity compactness under standard local suitable-weak bounds.
- Splits pressure into active Calderon-Zygmund and spatially harmonic parts.
- Proves strong active-pressure and harmonic-quotient pressure compactness.
- Retains the physical harmonic pressure as a separate weak/tail coordinate.
- Constructs a nonnegative dissipation defect measure.
- Proves the Time-Slice Extraction Barrier.
- Splits M-XTR into selected-trace and thickened-defect carrier routes.
- Proves a thickened state-versus-defect carrier theorem.
- Proves fixed-band spatially tight trace compactness.
- Compactifies relative-frequency shell distributions by a probability measure on N_0 union infinity.
- Defines the defect-completed native package and proves conditional sequential compactness.
- Proves conditional minimal-profile existence by the direct method.
- Reduces M-COM to terminal trace/profile splitting and transition-compatible compactness rather than ordinary local state/pressure compactness.
