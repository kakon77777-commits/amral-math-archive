# CHANGELOG

## v0.1 — 2026-08-15

- Inserts ANP-00 as the foundational semantic/causal specification before Source-Core Provenance.
- Defines the entire causal domain strictly before the candidate singular time.
- Separates forward PDE causality from backward inferential/provenance reasoning.
- Introduces the 15-field Causal Atom.
- Makes spacetime, relation, existence, definition, judgment, dynamics and numericalization mandatory.
- Makes continuity, discreteness, coupling, legality, phase-like transition, causality, predictability and interpretability mandatory structural attributes.
- Introduces multi-level existence and legality matrices.
- Adds scale-invariant numerical coordinates for parabolic geometry, frequency-radius coupling, viscous age, source relevance, core stock, model-cone ratio and dissipation offset.
- Introduces hybrid continuous-PDE/discrete-graph legality.
- Defines phase-like regime crossings without identifying them with blow-up.
- Defines C0-C3 causal levels and P0-P3 predictability levels.
- Defines a seven-component causal interpretability mask.
- Recompiles ANP-01 Source-Core Provenance as a fully typed causal theorem obligation.
