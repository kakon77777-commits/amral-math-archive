# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- All physical causal edges are pre-singularity and forward in time.
- Backward theorem/inference arrows are not labeled backward causation.
- Operational phase transitions are regime transitions, not thermodynamic claims.
- Precursors are not labeled singularity predictors without a forward theorem or empirical validation.
- No Chain Necessity, Finite Obstruction, or Navier-Stokes regularity claim is made.
