---
title: "Navier–Stokes Ancestry Necessity Program：Cycle-IV Roadmap"
version: "v0.1"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-ANP Cycle-IV Roadmap v0.1

## ANP-00 — Pre-Singularity Causal Relation Domain

Establishes the formal causal ontology.

### Seven primary coordinates

$$
\boxed{
\text{時空間},
\text{關係},
\text{存在},
\text{定義},
\text{判定},
\text{動力},
\text{數值化}.
}
$$

### Eight structural attributes

$$
\boxed{
\text{連續性},
\text{離散性},
\text{偶合性},
\text{合法性},
\text{相變性},
\text{因果性},
\text{預判性},
\text{解讀性}.
}
$$

### Core rule

$$
\boxed{
t_{\rm cause}
<
t_{\rm effect}
<
T_\ast.
}
$$

All physical causal edges are pre-singularity and forward-time.

Backward concentration/formation analysis belongs to an inferential/provenance graph.

### Causal Atom

$$
\boxed{
\mathfrak A(E)
=
(
\mathsf{ST},
\mathsf{REL},
\mathsf{EX},
\mathsf{DEF},
\mathsf{JUD},
\mathsf{DYN},
\mathsf{NUM};
\mathsf{CONT},
\mathsf{DISC},
\mathsf{COUP},
\mathsf{LEGAL},
\mathsf{PHASE},
\mathsf{CAUSE},
\mathsf{PRED},
\mathsf{INTERP}
).
}
$$

### Quantitative coordinates

Includes:

- time-to-singularity ratio;
- parabolic radius ratio;
- frequency-radius coupling:
  $$
  2^J R;
  $$
- viscous age:
  $$
  \nu2^{2J}\Delta t;
  $$
- source contribution ratio;
- absolute core stock;
- Miller model-cone ratio;
- dissipation offset:
  $$
  J-Q(t);
  $$
- spatial overlap;
- error/commutator ratio.

## ANP-01 — Source--Core Provenance Bridge

Target a C3 causal edge:

$$
K_i
\overset{\rm C3}{\longrightarrow}
K_j
$$

with:

1. same-core/localized provenance;
2. quantitative Duhamel relevance;
3. compatible frequency and spatial scales;
4. controlled errors;
5. recursive parent legality.

## ANP-02 — Recursive Edge Compatibility

Build one node/edge category stable under repeated parent selection.

Prevent silent representation switching.

## ANP-03 — Non-Type-I Entry

Treat:

$$
\sup_{t<T_\ast}
\|u(t)\|_{L^{3,\infty}}
=
\infty.
$$

Construct a pre-singularity causal ancestry entry theorem without Type-I core assumptions.

## ANP-04 — Arbitrary-Depth Causal Paths

Prove compatible finite causal paths of arbitrary depth.

Then use finite branching only after the causal tree has one stable semantics.

## ANP-05 — Infinite Ancestry Extraction

Target:

$$
\boxed{
\operatorname{Blowup}(T_\ast)
\Longrightarrow
\exists
\Gamma_\infty^{NS}.
}
$$

## ANP-06 — Finite Obstruction Retest

Only after Chain Necessity, test whether every legal infinite causal ancestry encounters finite-stage dynamical impossibility.

## Hard rules

- Backward inference is not backward causation.
- Every physical causal edge lies strictly before the singular horizon.
- Discrete ancestry nodes must embed in continuous PDE bridges.
- Node, edge, and chain existence are different quantifier levels.
- Phase-like regime crossings are not singularity proofs.
- Precursors are not automatically predictors.
- Correlation is not causality.
- Every claimed causal edge must be interpretable in time, space, scale, variable, mechanism, amplitude, and legality.
