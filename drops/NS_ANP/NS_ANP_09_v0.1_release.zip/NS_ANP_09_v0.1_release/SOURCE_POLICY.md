# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Nonzero high-frequency tails are not treated as dangerous certificates.
- CN_Forest is not promoted to CN3_Atomic.
- Profile compactness is not promoted to actual multi-gate prefix compactness or surjective extension.
- D_FJUMP is reclassified only relative to LP support geometry and the prior DRC dissipation-range architecture.
- No Finite Obstruction or Navier-Stokes regularity claim is made.
