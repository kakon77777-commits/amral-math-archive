---
title: "Navier–Stokes Ancestry Necessity Program：Cycle-IV Roadmap"
version: "v1.0"
date: "2026-08-15"
status: "Cycle-IV closed as a causal-necessity research cycle; atomic CN3 remains open"
---

# NS-ANP Cycle-IV Roadmap v1.0

## Completed papers

1. ANP-00 — Pre-Singularity Causal Relation Domain
2. ANP-01 — Weighted Source--Core Provenance
3. ANP-02 — Recursive Footprint Compatibility
4. ANP-03 — Source-Parent Recapture / weighted C3
5. ANP-04 — Type-I / non-Type-I Universal Entry
6. ANP-05 — Arbitrary Finite-Depth C3 Paths
7. ANP-06 — Dual-Propagator Correction / Horizon Audit
8. ANP-07 — Horizon Persistence / Edge Closure
9. ANP-08 — Horizon Transmission / Fresh-Source Cascade
10. ANP-09 — Causal Forest / Inverse-Limit Final Audit

## Final semantic correction

Positive high-frequency state is not automatically a dangerous mark.

Strong horizon recurrence now uses certified gates:

$$
\widehat{\mathcal H}_q
$$

based on:

- Type-I absolute UV core certificates; or
- non-Type-I adaptive Lorentz/UV seed certificates.

Intermediate parents need not remain uniformly dangerous.

## Universal actual result

Define:

$$
\mathscr G_H
$$

as the union of all actual finite corrected C3 histories ending at dangerous-certified horizon nodes.

Then under hypothetical blow-up:

$$
\boxed{
CN_{\rm Forest}
:
\text{Horizon Causal Forest Necessity}
=
\mathrm{PROVED}
}
$$

relative to the ANP definitions.

The forest has:

- actual original-solution nodes;
- strictly pre-singularity C3 edges;
- dangerous terminals arbitrarily close to:
  $$
  T_\ast;
  $$
- unbounded terminal singular scale;
- arbitrary finite-depth ancestry behind each terminal.

## Atomic lineage

Define:

$$
CN3_{\rm Atomic}
$$

as one actual infinite C3 chain with a cofinal dangerous-certified subsequence.

Status:

$$
\boxed{
CN3_{\rm Atomic}
:
\mathrm{OPEN}.
}
$$

## Scale/time residual updates

### Zeno temporal nonprogress

Reclassified through the corrected dual cut:

$$
\text{no propagated influence across shrinking cut}
\Longrightarrow
\text{fresh-source renewal rate}.
$$

### Large frequency jumps

A nonzero large parent/output jump is balanced high--high down-transfer.

Relative to DRC:

$$
D_{\rm FJUMP}
\subset
\text{viscous absorption}
\vee
\text{large dissipation span/driver debt}.
$$

Thus D_FJUMP is not primitive.

### Remaining profile fragmentation

$$
D_{\rm PROF}
=
D_{\rm GNORM}
\vee
D_{\rm SCALE}
\vee
D_{\rm SPACE}.
$$

Spatial scale-span failure can further split into strong-cell recapture or spatial atomization when weighted-state tightness is available.

## Actual inverse-limit criterion

Let:

$$
\mathscr P_q
$$

be compact spaces of **actual** multi-gate C3 prefixes with continuous surjective truncation maps.

Then:

$$
\boxed{
\varprojlim\mathscr P_q\neq\varnothing
}
$$

and an actual atomic CN3 chain exists.

Profile quotient compactness alone does not establish these actual prefix spaces or surjectivity.

## Final forest/atomic dichotomy

$$
\boxed{
\operatorname{Blowup}(T_\ast)
\Longrightarrow
CN3_{\rm Atomic}
\vee
D_{\rm DIFF},
}
$$

where:

$$
D_{\rm DIFF}
$$

is diffuse horizon causality: the actual horizon causal forest reaches arbitrarily high dangerous gates but has no atomic horizon end.

This is not a contradiction.

## Next program

$$
\boxed{
\textbf{
NS-CFOP —
Navier--Stokes Causal Forest Obstruction Program
}
}
$$

### CFOP-01

Diffuse Horizon Causality / Forest Obstruction / Action-Flow Cutsets / Atomic-End Criteria.

### CFOP-02

Spatial and Scale Atomization / Forest Capacity / Driver-Action Cutsets.

### CFOP-03

Finite Forest Obstruction Audit.

## Hard rules

- CN_Forest is not CN3_Atomic.
- Nonzero Fourier tails are not dangerous certificates.
- Graph depth is not physical time span.
- Profile compactness is not actual-branch extension.
- If causality is genuinely diffuse, obstruction must be formulated on forests/cutsets, not only paths.
- No Navier-Stokes regularity claim is made.
