# CHANGELOG

## v0.1 — 2026-08-15

- Replaces time/frequency-only horizon gates by dangerous-certified Type-I/non-Type-I gates.
- Corrects CN2 semantics: finite ancestry is positive C3 ancestry behind a dangerous-certified terminal, not a claim that every intermediate node remains dangerous.
- Defines and proves Horizon Causal Forest Necessity relative to the ANP architecture.
- Separates CN_Forest from CN3_Atomic.
- Reclassifies temporal Zeno nonprogress without propagated influence as fresh-source renewal.
- Proves large parent/output frequency jumps must be balanced high-high down-transfer.
- Reclassifies D_FJUMP into viscous absorption or dissipation-span/driver debt relative to DRC.
- Defines the remaining profile-fragmentation class D_PROF and spatial atomization D_SATOM.
- Defines spaces of actual marked multi-gate prefixes and proves a conditional actual inverse-limit theorem.
- Defines diffuse horizon causality D_DIFF and proves the Forest/Atomic dichotomy.
- Closes Cycle IV as a causal-necessity research cycle with CN_Forest proved and atomic CN3 open.
- Launches the Causal Forest Obstruction Program (NS-CFOP).
