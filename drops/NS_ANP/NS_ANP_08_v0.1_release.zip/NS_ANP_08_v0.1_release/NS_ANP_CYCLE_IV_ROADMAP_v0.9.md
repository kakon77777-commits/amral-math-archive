---
title: "Navier–Stokes Ancestry Necessity Program：Cycle-IV Roadmap"
version: "v0.9"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-ANP Cycle-IV Roadmap v0.9

## ANP-00--07

Established:

- pre-singularity causal ontology;
- weighted source-core provenance;
- recursive Footprint/Dual Node semantics;
- weighted C3 source-parent edges;
- Type-I and non-Type-I state entry;
- corrected arbitrary finite-depth C3 continuation;
- horizon-persistence criteria;
- local C3 edge closure on bounded normalized branches.

## ANP-08 — Horizon Transmission Rigidity

### Transmission factorization

For source-parent edges:

$$
\vartheta
\gtrsim
\eta^2/
(
\mathfrak H
\mathcal A^2
).
$$

Hence:

$$
\boxed{
D_{\rm HTRANS}
\subset
D_{\rm ATOM}
\vee
D_{\rm REROOT}
\vee
D_{\rm ACT}.
}
$$

Thus horizon transmission collapse is removed as a primitive residual.

### Atomization

For positive shell source shares with total:

$$
\Sigma\ge\sigma,
$$

$$
\boxed{
\mathfrak M^{src}
\ge
\sigma/\eta_{\max}.
}
$$

So strongest-share collapse forces effective source-parent multiplicity.

Within DRC high-parent-shell grouping this routes toward dissipation-span/driver alternatives.

### Residence

Large residence is re-cut using the corrected dual ledger:

$$
\boxed{
\text{PROPAGATED-PARENT}
\vee
\text{SHORTER FRESH SOURCE}.
}
$$

### Fresh-source packet

If propagated inheritance fraction is at most:

$$
1-\sigma,
$$

then:

$$
\boxed{
\int_I
\|F_k\|_2dt
\ge
\sigma A.
}
$$

For shrinking windows:

$$
|I|=\delta,
$$

normalized forcing rate is at least:

$$
\sigma/\delta.
$$

### Budgeted branch

Uniform bounds on:

$$
\eta^{-1},
\mathfrak H,
\mathcal A,
|\Delta k|,
G_{\rm norm},
\Xi,
A_{\rm fp}
$$

give:

- a transmission floor;
- normalized child compactness;
- C3 edge closure;
- nontrivial limit.

Given an actual HP1 node and closed reach, this yields HPC and an infinite CN3 branch.

### Actual-Branch Shadowing no-go

Profile-space compactness and profile-edge closure alone do not imply an actual infinite branch in the original graph.

Therefore:

$$
\boxed{
\Gamma_\infty^{prof}
\neq
\Gamma_\infty^{act}
}
$$

without an additional shadowing/realization theorem.

### Current residual

The genuinely noncompact actual-branch frontier is:

$$
\boxed{
HP1_{\rm fail}
\vee
ABS_{\rm fail}
\vee
D_{\rm FJUMP}
\vee
D_{\rm GNORM}
\vee
D_{\rm SCALE}
\vee
D_{\rm SPACE}
\vee
\mathfrak A_{\rm cascade}.
}
$$

CN3 remains OPEN.

## ANP-09 — Scale Fragmentation / Actual-Branch Shadowing

Targets:

1. classify large relative frequency jumps;
2. control normalized global shell blow-up;
3. control footprint/wavelength scale-span escape;
4. formulate an actual-node inverse-limit theorem;
5. seek HP1 from finite-energy/smooth-prehistory structure;
6. decide CN3 or isolate an irreducible actual-shadowing gap.

## ANP-10 — Finite Obstruction Retest

Only after CN3.

## Hard rules

- Horizon transmission collapse is a composite debt, not an independent mystery.
- Fresh-source cascade is not automatically a contradiction.
- Profile compactness is not actual-branch shadowing.
- Uniform budgeted CN3 is conditional on an actual horizon-persistent seed.
- No Finite Obstruction or regularity claim before CN3.
