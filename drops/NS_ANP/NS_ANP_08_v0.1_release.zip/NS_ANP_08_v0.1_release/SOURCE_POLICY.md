# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- D_HTRANS is reclassified only through the proved ANP parent-extraction inequality and prior DRC architecture.
- Fresh-source cascade is not treated as a contradiction.
- Profile compactness is not treated as actual-branch shadowing.
- Budgeted CN3 remains conditional on an actual horizon-persistent seed.
- No Finite Obstruction or Navier-Stokes regularity claim is made.
