# CHANGELOG

## v0.1 — 2026-08-15

- Proves horizon transmission collapse factors through carrier-share collapse, residence blow-up, or partner-action blow-up.
- Removes D_HTRANS as an independent primitive residual.
- Proves source-share atomization forces divergent effective high-parent multiplicity.
- Reconnects atomization to the prior DRC many-parent/dissipation/driver architecture.
- Proves residence blow-up can be re-cut by the corrected dual ledger into propagated inheritance or a shorter fresh-source packet.
- Proves a fresh-source L2 norm packet and inverse-window normalized forcing-rate lower bound.
- Defines the cumulative normalized fresh-source cascade count.
- Defines a seven-coordinate horizon causal budget.
- Proves uniform budget gives a transmission floor and, conditional on actual HP1/reach closure, gives HPC and CN3.
- Proves profile compactness/edge closure alone cannot imply Actual-Branch Shadowing by an abstract counterexample.
- Reduces the remaining CN3 frontier to actual HP1/shadowing plus frequency/global-norm/scale/spatial escapes and action cascades.
