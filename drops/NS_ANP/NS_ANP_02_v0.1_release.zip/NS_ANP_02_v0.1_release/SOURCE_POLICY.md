# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Type-I weak-L3 aperture control is internally derived; strong-L3 heat-kernel theory is calibration only.
- Footprint localization is not source-parent localization.
- Adjoint provenance recursion is not source-parent recursive legality.
- Pseudolocal decay does not imply remote parent gross is small.
- No C3 ancestry, Chain Necessity, Finite Obstruction, or Navier-Stokes regularity claim is made.
