---
title: "Navier–Stokes Ancestry Necessity Program：Cycle-IV Roadmap"
version: "v0.3"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-ANP Cycle-IV Roadmap v0.3

## ANP-00 — Pre-Singularity Causal Relation Domain

Defines the 15-field Causal Atom and C0--C3 causality.

## ANP-01 — Weighted Source--Core Provenance

Proves:

$$
\mathrm{SCPB\mbox{-}W}
:
\mathrm{PROVED}.
$$

Obtains a weighted C2 forward PDE source-core edge.

## ANP-02 — Recursive Footprint Compatibility

### Aperture

Under:

$$
\|u\|_{L_t^\infty L_x^{3,\infty}}\le M,
$$

$$
I'
\lesssim
M m^{1/6}I^{1/2}+m.
$$

Thus for:

$$
\tau\le\vartheta R^2,
$$

$$
\boxed{
A_\chi(\tau)
\le
A_\ast(M,\vartheta,\phi).
}
$$

### Footprint recapture

Almost all adjoint mass lies in a controlled enlargement of the same core.

### No-go

Footprint mass localization alone does not imply nonlinear source localization.

### Recursive provenance

$$
\boxed{
\mathsf A_{r,s}\mathsf A_{s,t}
=
\mathsf A_{r,t}.
}
$$

Terminal-core provenance is stable under repeated backward propagation.

### Canonical Footprint Node

Stores:

- adjoint weight;
- full vorticity state;
- full weighted dyadic spectrum;
- provenance id.

Shellwise source identities are exact.

The square tail:

$$
\mathcal E_{>J}^{sq}
=
\sum_{k>J}e_k^\chi
$$

is monotone under threshold lowering.

Therefore:

$$
\boxed{
\mathrm{REC\mbox{-}F}
:
\mathrm{PROVED}.
}
$$

### Parent locality

At parabolic frequency:

$$
\boxed{
\text{LOCAL-PARENT}
\vee
R_{\rm PLEAK}.
}
$$

Remote influence must survive Schwartz kernel decay.

Exclusion of:

$$
R_{\rm PLEAK}
$$

is open.

### Causal status

$$
\boxed{
C2+\mathrm{REC\mbox{-}F}.
}
$$

Full C3 requires source-parent recapture.

## ANP-03 — Source-Parent Recapture

Targets:

1. adjoint-weighted signed parent ledger;
2. local-parent versus remote leakage;
3. finite weighted parent-state carrier extraction;
4. source-parent recursive node semantics;
5. C3 causal upgrade.

## ANP-04 — Non-Type-I Entry

Treat:

$$
\sup_{t<T_\ast}
\|u(t)\|_{L^{3,\infty}}
=
\infty.
$$

## ANP-05 — Arbitrary-Depth Compatible Paths

Build finite C3 paths of arbitrary depth.

## ANP-06 — Infinite Ancestry Extraction

Target:

$$
\operatorname{Blowup}(T_\ast)
\Longrightarrow
\exists\Gamma_\infty^{NS}.
$$

## ANP-07 — Finite Obstruction Retest

Only after Chain Necessity.

## Hard rules

- Controlled footprint aperture is not source-parent localization.
- Weight provenance is not automatically nonlinear parent provenance.
- Footprint recursion REC-F is distinct from source-parent recursion REC-S.
- Pseudolocal decay does not imply remote parent gross is small.
- Full C3 ancestry remains open until source-parent recapture closes.
