# CHANGELOG

## v0.1 — 2026-08-15

- Proves the exact second-moment evolution of the terminal-core adjoint footprint.
- Derives a Type-I weak-L3 aperture differential inequality and a finite aperture bound over parabolic windows.
- Upgrades centroid control to quantitative same-center footprint-mass recapture.
- Proves a no-go: footprint mass concentration alone does not localize arbitrary weighted source density.
- Proves exact adjoint semigroup provenance.
- Defines a canonical Footprint Node with stable provenance and full weighted dyadic spectrum.
- Proves exact shellwise footprint source identities and monotone square-tail representation.
- Closes the footprint/state representation component of Recursive Edge Compatibility (REC-F).
- Reduces geometric parent localization to LOCAL-PARENT or pseudolocal parent leakage R_PLEAK.
- Leaves source-parent recursive recapture (REC-S) open.
- Moves Source-Parent Recapture to ANP-03.
