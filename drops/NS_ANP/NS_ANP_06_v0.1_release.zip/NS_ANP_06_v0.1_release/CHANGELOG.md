# CHANGELOG

## v0.1 — 2026-08-15

- Audits and corrects the ANP-05 inheritance criterion.
- Replaces earlier weighted-state positivity by an exact homogeneous transport-diffusion propagated contribution measured through a terminal dual witness.
- Proves the exact dual causal Duhamel ledger and propagated-inheritance/source dichotomy.
- Re-establishes corrected finite-depth continuation in a Dual/Footprint causal node class.
- Separates trivial full-solution causal spines from strong marked/source-provenance formation ancestry.
- Gives an abstract counterexample showing arbitrary finite depth need not imply an infinite branch under infinite branching.
- Defines singular-horizon gates, horizon reach, horizon-persistent nodes and the Horizon-Persistent Child property.
- Proves horizon persistence plus recursive persistent-child selection is sufficient for a horizon-directed infinite marked C3 chain.
- Distinguishes renormalized profile-limit ancestry from an actual ancestry chain in the original solution.
- Defines Causal Edge Closure and Nontrivial Limit obligations.
- Refines the final Chain-Necessity frontier to HP1-HP4.
- Moves Finite Obstruction to ANP-08.
