---
title: "Navier–Stokes Ancestry Necessity Program：Cycle-IV Roadmap"
version: "v0.7"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-ANP Cycle-IV Roadmap v0.7

## ANP-00

Pre-Singularity Causal Relation Domain.

## ANP-01

Weighted terminal-core C2 provenance.

## ANP-02

Footprint recursion REC-F.

## ANP-03

Weighted source-parent C3_W edges.

## ANP-04

Universal Type-I / non-Type-I causal-state entry.

## ANP-05

Arbitrary finite-depth marked C3 realizability.

### Correction

Earlier weighted state positivity alone is not a causal inheritance criterion.

The corrected inheritance condition is a positive homogeneous propagated contribution measured by a terminal dual witness.

See:

`NS_ANP_05_CausalCorrection_v0.2.md`.

## ANP-06 — Singular-Horizon Extraction Audit

### Correct dual causal ledger

$$
A_c
=
\langle
\omega_k(a),\Phi(a)
\rangle
+
\int_a^{t_c}
\langle
F_k,\Phi
\rangle.
$$

Thus:

$$
\boxed{
\text{PROPAGATED-INHERITANCE}
\vee
\text{POSITIVE-SOURCE}.
}
$$

Corrected finite-depth continuation remains valid.

### Chain hierarchy

$$
\boxed{
CN0
:
\text{full-solution causal spine}
}
$$

is trivial and is not the target.

$$
\boxed{
CN1
:
\text{universal dangerous-state entry}
}
$$

is proved.

$$
\boxed{
CN2
:
\text{arbitrary finite-depth marked C3 ancestry}
}
$$

is proved after correction.

$$
\boxed{
CN3
:
\text{one horizon-directed infinite marked C3 chain}
}
$$

is open.

### Horizon persistence

Define:

$$
\mathfrak R_H(P)
=
\sup
\{
t(C):
P\leadsto C
\text{ with dangerous marked C3 descendants}
\}.
$$

A node is horizon-persistent if:

$$
\mathfrak R_H(P)=T_\ast.
$$

The key missing theorem is:

$$
\boxed{
\text{HPC — Horizon-Persistent Child}.
}
$$

### Compactness route

Critical profile decompositions may organize translation/scaling defects, but ANP additionally needs:

- HP1 horizon-persistent seed;
- HP2 horizon-persistent child;
- HP3 nonlinear C3 edge closure;
- HP4 nontrivial marked limit.

## ANP-07 — Horizon-Persistent Branch Extraction

Targets:

1. construct HP1 from late entry seeds;
2. prove HPC;
3. develop critical profile/branch compactness;
4. prove Causal Edge Closure;
5. preserve nontrivial marked state;
6. test strong Chain Necessity.

## ANP-08 — Finite Obstruction Retest

Only after CN3.

## Hard rules

- Earlier state existence is not propagated causal contribution.
- CN0 full-state evolution may not be used to trivialize marked formation ancestry.
- Arbitrary finite depth does not imply an infinite branch in an infinitely branching graph.
- A profile-limit chain is not automatically an actual chain in the original solution.
- Weak state convergence is insufficient unless nonlinear C3 source edges are closed.
