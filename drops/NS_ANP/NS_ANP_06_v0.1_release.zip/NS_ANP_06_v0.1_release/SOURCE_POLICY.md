# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Earlier state existence is not treated as propagated causal contribution.
- Full-state solution evolution is not used to trivialize marked formation ancestry.
- Arbitrary finite depth is not promoted to an infinite branch without horizon persistence/compactness.
- Profile-limit chains are not promoted to actual chains without a realization theorem.
- No CN3 Chain Necessity, Finite Obstruction, or Navier-Stokes regularity claim is made.
