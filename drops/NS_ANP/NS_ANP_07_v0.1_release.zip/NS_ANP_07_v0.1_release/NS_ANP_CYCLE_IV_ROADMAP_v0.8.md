---
title: "Navier–Stokes Ancestry Necessity Program：Cycle-IV Roadmap"
version: "v0.8"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-ANP Cycle-IV Roadmap v0.8

## ANP-00--06

Established:

- causal ontology;
- weighted source-core provenance;
- recursive footprint semantics;
- weighted C3 source-parent edges;
- Type-I/non-Type-I entry;
- corrected arbitrary finite-depth continuation;
- horizon-persistence formulation.

## ANP-07 — Horizon-Persistent Branch Extraction

### Horizon gates

$$
\mathcal H_q
=
\{
T_\ast-2^{-q}<t<T_\ast,
\quad
k\ge q
\}.
$$

### Finite/compact child criteria

HPC is proved if:

- admissible relevant children are finite; or
- a strong-child family is compact and fixed-gate reach is closed.

### Threshold-finite branching

Define:

$$
\mathcal C_\eta(P)
=
\{
C:
\vartheta(P\to C)\ge\eta
\}.
$$

Under TFB:

$$
|\mathcal C_\eta(P)|<\infty.
$$

If:

$$
\Theta_q(P)
$$

does not collapse along the horizon, HPC follows.

Thus failure of HPC under TFB forces:

$$
\boxed{
D_{\rm HTRANS}
:
\Theta_q(P)\to0.
}
$$

### Horizon renewal-rate theorem

For terminal window width:

$$
\delta_n\to0,
$$

if propagated inheritance fraction is at most:

$$
1-\sigma,
$$

then:

$$
\boxed{
\mathfrak R_{\rm fresh,n}
\ge
\sigma/\delta_n
\to\infty.
}
$$

Thus late causal state is either persistently propagated or increasingly freshly generated.

### Local C3 Edge Closure

For normalized source-parent edges with:

- bounded relative shell offsets;
- bounded normalized dyadic L2 states;
- controlled kernel-inflated footprints;
- transmission floor:

$$
\vartheta\ge\vartheta_0>0,
$$

band-limited compactness gives strong local convergence.

Then the weighted bilinear source contribution is closed under the limit.

Thus HP3/HP4 are proved on this bounded normalized strong branch.

### Remaining escapes

$$
D_{\rm HTRANS},
\quad
D_{\rm FJUMP},
\quad
D_{\rm GNORM},
\quad
D_{\rm SPACE}.
$$

### Current CN3 status

Still OPEN.

The remaining issue is actual-branch causal fragmentation, not generic node existence.

## ANP-08 — Horizon Transmission Rigidity / Actual-Branch Shadowing

Targets:

1. quantify repeated horizon transmission collapse;
2. connect fresh-source rate to known coercive actions;
3. make fresh-source parents themselves horizon persistent or isolate a terminal action branch;
4. control relative frequency/global-norm/spatial escapes;
5. attempt actual-branch shadowing;
6. decide strong CN3.

## ANP-09 — Finite Obstruction Retest

Only after CN3.

## Hard rules

- Causal flux across horizon cuts is weaker than one persistent causal lineage.
- Profile/ancient limits are not actual branches unless shadowing is proved.
- Compactness of nodes is insufficient unless the nonlinear C3 edge is closed.
- Horizon transmission collapse is a causal fragmentation mechanism, not automatic contradiction.
- No Finite Obstruction or regularity claim before CN3.
