# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Profile/ancient limits are not treated as actual branches without shadowing.
- Local C3 edge closure is conditional on B1-B4 and is not promoted beyond that branch.
- Horizon causal flux is not identified with one persistent lineage.
- No CN3 Chain Necessity, Finite Obstruction, or Navier-Stokes regularity claim is made.
