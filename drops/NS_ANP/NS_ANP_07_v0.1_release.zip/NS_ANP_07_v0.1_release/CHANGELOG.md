# CHANGELOG

## v0.1 — 2026-08-15

- Defines horizon reach and immediate marked child sets.
- Proves finite-child and compact-child Horizon-Persistent Child criteria.
- Introduces threshold-finite branching and best horizon first-edge transmission Theta_q.
- Proves HPC failure under TFB forces horizon transmission collapse.
- Proves the horizon renewal-rate theorem from the corrected dual causal ledger.
- Introduces a horizon causal-flux lower bound separating persistent propagation from fresh source renewal.
- Proves band-limited local node compactness under bounded normalized relative-scale and L2 hypotheses.
- Proves local nonlinear C3_W source-edge closure under B1-B4.
- Proves nontrivial parent limit under a transmission floor.
- Reduces compactness failure to transmission, frequency-jump, global-shell-norm, or spatial-footprint escapes.
- Distinguishes profile/ancient solution persistence from actual ancestry branch persistence.
- Moves the frontier to horizon transmission rigidity and actual-branch shadowing.
