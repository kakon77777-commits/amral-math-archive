---
title: "Navier–Stokes Ancestry Necessity Program：Cycle-IV Roadmap"
version: "v0.6"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-ANP Cycle-IV Roadmap v0.6

## ANP-00 — Pre-Singularity Causal Relation Domain

Defines Causal Atoms and C0--C3 legality.

## ANP-01 — Weighted Source--Core Provenance

Proves weighted C2 terminal-core source provenance.

## ANP-02 — Recursive Footprint Compatibility

Proves:

$$
\mathrm{REC\mbox{-}F}.
$$

## ANP-03 — Source-Parent Recapture

Proves weighted pseudolocal:

$$
C3_W
$$

parent edges for positive/strong source atoms.

## ANP-04 — Universal Causal-State Entry

Proves:

- Type-I entry;
- non-Type-I adaptive UV entry.

Thus both weak-L3 branches enter the same Footprint Node ontology.

## ANP-05 — Arbitrary-Depth Compatible C3 Paths

### No-Terminal-Node

For any positive weighted shell node:

$$
E_c=e_k^\chi(t_c)>0,
$$

and any earlier anchor:

$$
a<t_c,
$$

either:

$$
e_k^\chi(a)>0
$$

and a C3 inheritance parent exists,

or the exact source ledger is positive and contains a positive dyadic source atom, yielding a C3_W source parent.

Therefore:

$$
\boxed{
\text{No-Terminal-Node}
:
\mathrm{PROVED}.
}
$$

### Adaptive generation

At each node choose:

$$
\Delta_m
=
\min
\left\{
t_m/2,
\delta_m^0,
\vartheta R_m^2/(1+\overline M_m)
\right\}
>0.
$$

Each edge remains pre-singularity and has controlled footprint geometry.

### Finite transmission

Every edge has:

$$
\vartheta_m>0
$$

with:

$$
E_{m-1}\ge\vartheta_mE_m.
$$

For finite depth:

$$
\Theta_N
=
\prod_{m=1}^{N}\vartheta_m
>0.
$$

No uniform lower bound as:

$$
N\to\infty
$$

is proved.

### Arbitrary finite depth

$$
\boxed{
\forall N
\quad
\exists
\text{ a compatible C3 path of depth }N.
}
$$

Moreover terminal nodes can satisfy:

$$
t_N\uparrow T_\ast,
\qquad
k_N\to\infty
$$

across the entry sequence.

### Remaining compactness defects

Potential limit-level defects:

$$
D_{\rm TRANS},
\quad
D_{\rm STEP},
\quad
D_{\rm FJUMP},
\quad
D_{\rm SPACE}.
$$

They do not block finite paths.

They may block a singular-horizon limit path.

## ANP-06 — Singular-Horizon Infinite Ancestry Extraction

Target:

$$
\boxed{
\forall N\,\exists\Gamma_N
\Longrightarrow
\exists\Gamma_\infty^{NS}.
}
$$

Tasks:

1. construct one horizon-coherent family of finite paths;
2. define legal translation/scaling normalization;
3. prove node compactness;
4. prove nonlinear C3 edge closure under the chosen convergence;
5. prevent a trivial/zero limit;
6. decide Full Chain Necessity.

## ANP-07 — Finite Obstruction Retest

Only after Chain Necessity.

## Hard rules

- Finite positive transmission does not imply a positive infinite transmission product.
- Arbitrary finite-depth realizability does not by itself give one infinite singular-horizon chain.
- Ordinary weak compactness is insufficient if nonlinear source provenance is not closed.
- A finite mechanism taxonomy is not the same as a compact branch space.
- No Finite Obstruction or regularity claim before Chain Necessity is actually closed.
