# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Every finite C3 edge is strictly pre-singularity.
- Positive finite-depth transmission is not promoted to a uniform infinite-depth bound.
- Arbitrary finite-depth path existence is not promoted to one horizon-coherent infinite path.
- Weak state compactness is not assumed to preserve nonlinear C3 source provenance.
- No Full Chain Necessity, Finite Obstruction, or Navier-Stokes regularity claim is made.
