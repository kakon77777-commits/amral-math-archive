# CHANGELOG

## v0.1 — 2026-08-15

- Proves a C3 inheritance edge for any positive earlier weighted shell state with the same adjoint provenance.
- Uses the exact shellwise source ledger to show that if the earlier state vanishes, some realized dyadic source atom is positive.
- Applies ANP-03 to convert any positive smooth source atom into a legal weighted C3 parent.
- Proves the No-Terminal-Node theorem for positive canonical shell Footprint Nodes.
- Introduces adaptive generation windows that remain strictly pre-singularity and retain controlled footprint geometry.
- Defines per-edge transmission coefficients and proves every finite transmission product is positive.
- Proves compatible C3 paths of arbitrary finite depth.
- Proves these finite paths can terminate arbitrarily close to the singular horizon and at arbitrarily high frequency.
- Isolates transmission, time-step, frequency-jump, and spatial compactness degeneration coordinates.
- Defines the horizon-compactness obligations HC1-HC4.
- Moves the frontier from finite-depth realizability to singular-horizon infinite path extraction.
