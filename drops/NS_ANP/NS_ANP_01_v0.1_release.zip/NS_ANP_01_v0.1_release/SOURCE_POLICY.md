# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- All physical causal relations are forward and pre-singularity.
- Backward adjoint construction is a provenance/inference device, not backward physical causation.
- Weighted output-local provenance is not silently promoted to compact parent-source localization.
- High-pass commutator terms are retained as real scale-transfer dynamics.
- No C3 ancestry, Chain Necessity, Finite Obstruction, or regularity claim is made.
