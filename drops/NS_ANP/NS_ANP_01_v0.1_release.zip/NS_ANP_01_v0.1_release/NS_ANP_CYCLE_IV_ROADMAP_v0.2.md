---
title: "Navier–Stokes Ancestry Necessity Program：Cycle-IV Roadmap"
version: "v0.2"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-ANP Cycle-IV Roadmap v0.2

## ANP-00 — Pre-Singularity Causal Relation Domain

Defines the Causal Atom and separates:

$$
\mathcal G_{\rm causal}^{+}
$$

from:

$$
\mathcal G_{\rm infer}^{-}.
$$

All physical causal edges satisfy:

$$
t_{\rm cause}<t_{\rm effect}<T_\ast.
$$

## ANP-01 — Source--Core Provenance

### Pressure-free causal representation

Use:

$$
\partial_t\omega
+
u\cdot\nabla\omega
=
S\omega+\nu\Delta\omega.
$$

For a terminal Type-I core cutoff:

$$
\chi(t_j)=\chi_j,
$$

solve:

$$
\partial_s\chi
+
u\cdot\nabla\chi
+
\nu\Delta\chi
=
0.
$$

### Exact full-core provenance

$$
\boxed{
E_\chi(t_j)
=
E_\chi(t_i)
+
\int\chi\omega\cdot S\omega
-
\nu\int\chi|\nabla\omega|^2.
}
$$

### Exact UV provenance

For:

$$
\omega_H=P_{>J}\omega,
$$

$$
\boxed{
E_{\chi,H}(t_j)
=
E_{\chi,H}(t_i)
+
\mathcal S^{str}
+
\mathcal S^{tr}
-
\mathcal D.
}
$$

The nonlinear scale-transfer channel is:

$$
-[P_{>J},u\cdot\nabla]\omega.
$$

### Source/inheritance dichotomy

For every:

$$
0<\theta<1,
$$

a later core is either mostly inherited from the earlier weighted state or the intervening source supplies a fixed normalized debt.

### Adjoint causal footprint geometry

Proved:

- mass conservation:
  $$
  m_\chi\asymp R^3;
  $$
- high-influence volume:
  $$
  |\{\chi\ge\alpha\}|
  \lesssim
  \alpha^{-1}R^3;
  $$
- Type-I centroid control over:
  $$
  \Delta t\lesssim R^2:
  $$
  $$
  |c_\chi(s)-x_\ast|
  \lesssim
  M
  \Delta t/R.
  $$

### Proven provenance level

$$
\boxed{
\text{SCPB-W}
:
\text{weighted output-local provenance}
=
\mathrm{PROVED}.
}
$$

The resulting source-core edge reaches:

$$
\boxed{
C2
}
$$

causality.

### Remaining provenance gaps

$$
\boxed{
\text{SCPB-G}
:
\text{geometric same-core parent localization}
=
\mathrm{OPEN}.
}
$$

$$
\boxed{
\text{SCPB-R}
:
\text{recursive core recapture}
=
\mathrm{OPEN}.
}
$$

## ANP-02 — Recursive Edge Compatibility

Targets:

1. adjoint footprint aperture;
2. diffuse-tail source leakage;
3. parent-field spatial locality;
4. canonical recapture of an earlier weighted state as a core/high-pass node;
5. stable representation transition;
6. C2 to C3 upgrade.

## ANP-03 — Non-Type-I Entry

Treat the branch:

$$
\sup_{t<T_\ast}
\|u(t)\|_{L^{3,\infty}}
=
\infty.
$$

## ANP-04 — Arbitrary-Depth Compatible Paths

Build one stable causal node/edge category and prove finite paths of arbitrary depth.

## ANP-05 — Infinite Ancestry Extraction

Target:

$$
\operatorname{Blowup}(T_\ast)
\Longrightarrow
\exists
\Gamma_\infty^{NS}.
$$

## ANP-06 — Finite Obstruction Retest

Only after Chain Necessity, test for finite-stage dynamical impossibility.

## Hard rules

- Terminal-core adjoint weighting establishes output provenance, not automatically parent locality.
- High-pass scale transfer commutators are physical scale-coupling terms, not discarded errors.
- Centroid control does not imply bounded footprint aperture.
- C2 source relevance is not C3 recursive ancestry.
- No regularity claim is allowed before Chain Necessity and Finite Obstruction are actually closed.
