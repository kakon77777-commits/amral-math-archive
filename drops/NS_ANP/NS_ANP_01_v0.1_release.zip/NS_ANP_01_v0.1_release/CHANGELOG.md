# CHANGELOG

## v0.1 — 2026-08-15

- Opens ANP-01 with a pressure-free vorticity causal representation.
- Introduces a terminal-core backward adjoint cutoff as the causal footprint of a later Type-I core observable.
- Proves the exact weighted local enstrophy provenance identity.
- Proves a stretching-source versus inherited-state dichotomy.
- Derives the exact high-pass vorticity equation including the nonlinear scale-transfer commutator.
- Proves the exact high-pass adjoint provenance identity and UV source/inheritance dichotomy.
- Proves adjoint mass conservation and core-scale high-influence volume.
- Uses the Type-I weak-L3 bound to prove O_M(R) centroid drift over one parabolic time.
- Defines adjoint aperture, high-influence tube, diffuse-tail ledger, and parent-locality ledger.
- Proves weighted output-local Source-Core Provenance (SCPB-W) and assigns the edge causal level C2.
- Decomposes full Source-Core Provenance into SCPB-W, SCPB-G, and SCPB-R.
- Leaves geometric parent localization and recursive core recapture open for ANP-02.
