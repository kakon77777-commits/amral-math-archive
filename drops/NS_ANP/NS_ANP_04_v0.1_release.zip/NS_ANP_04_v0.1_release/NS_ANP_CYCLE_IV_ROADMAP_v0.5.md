---
title: "Navier–Stokes Ancestry Necessity Program：Cycle-IV Roadmap"
version: "v0.5"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-ANP Cycle-IV Roadmap v0.5

## ANP-00 — Pre-Singularity Causal Relation Domain

Defines causal legality and C0--C3 semantics.

## ANP-01 — Weighted Source--Core Provenance

Establishes terminal-core weighted C2 source provenance.

## ANP-02 — Recursive Footprint Compatibility

Proves:

$$
\mathrm{REC\mbox{-}F}.
$$

## ANP-03 — Source-Parent Recapture

Proves weighted:

$$
C3_W
$$

source-parent edges for strong source atoms with quantitative guards.

## ANP-04 — Non-Type-I Ancestry Entry

### Non-Type-I branch

$$
\sup_{t<T_\ast}
\|u(t)\|_{L^{3,\infty}}
=
\infty.
$$

Choose:

$$
M_n
=
\|u(t_n)\|_{L^{3,\infty}}
\to\infty.
$$

Then:

$$
t_n\uparrow T_\ast.
$$

### Adaptive Lorentz atom

There exist:

$$
\lambda_n>0,
\qquad
E_n=\{|u(t_n)|>\lambda_n\},
\qquad
r_n=|E_n|^{1/3},
$$

with:

$$
\lambda_nr_n
\ge
M_n/2.
$$

Finite energy gives:

$$
\boxed{
\lambda_n
\gtrsim
M_n^3/E_2^2,
}
$$

and:

$$
\boxed{
r_n
\lesssim
E_2^2/M_n^2.
}
$$

### Adaptive UV threshold

Choose:

$$
2^{J_n}
\asymp
(\lambda_n/E_2)^{2/3}.
$$

Then:

$$
J_n\to\infty,
$$

and low frequencies cannot explain the Lorentz superlevel amplitude.

### UV vorticity seed

$$
\boxed{
\sum_{k>J_n-C}
\|\omega_k(t_n)\|_2^2
\gtrsim
M_n^4/E_2^2.
}
$$

### Canonical seed footprint

Choose a finite ball capturing a fixed fraction of the UV square-function density and initialize a canonical Footprint Node:

$$
\mathsf F_n^{seed}.
$$

Define spatial fragmentation coordinate:

$$
\Xi_n=2^{J_n-C}R_n^{seed}\ge1.
$$

No boundedness of:

$$
\Xi_n
$$

is required for node existence.

### Adaptive causal time step

On a short pre-singularity interval define:

$$
\overline M_n
=
\sup
\|u\|_{L^{3,\infty}}
<\infty.
$$

Choose:

$$
\boxed{
\Delta_n
\le
\frac{
\vartheta
(R_n^{seed})^2
}{
1+\overline M_n
}.
}
$$

Then the ANP-02 aperture bound remains uniform after adaptive time renormalization.

### Entry result

$$
\boxed{
\text{Non-Type-I causal-state entry}
:
\mathrm{PROVED}.
}
$$

### Universal entry

Combining the Type-I core entry and non-Type-I adaptive entry:

$$
\boxed{
\text{universal causal-state entry}
:
\mathrm{PROVED\ RELATIVE\ TO\ ANP\ DEFINITIONS}.
}
$$

This is not Chain Necessity.

## ANP-05 — Arbitrary-Depth Compatible C3 Paths

Targets:

1. generation-wise source/state/action budgets;
2. adaptive step renormalization;
3. no-terminal-node or explicit terminal-escape theorem;
4. compatible finite C3 paths of arbitrary depth;
5. Type-I/non-Type-I branch merger at the Footprint Node layer.

## ANP-06 — Infinite Ancestry Extraction

Target:

$$
\operatorname{Blowup}(T_\ast)
\Longrightarrow
\exists
\Gamma_\infty^{NS}.
$$

Only after arbitrary-depth compatible paths are proved.

## ANP-07 — Finite Obstruction Retest

Only after Chain Necessity.

## Hard rules

- Effective-volume compression is not hard-ball spatial concentration.
- Non-Type-I entry centers need not already be the final singular center.
- Adaptive causal time steps may shrink with the local weak-L3 bound.
- Entry-node existence is not arbitrary-depth path existence.
- Universal state entry is not Full Chain Necessity.
