# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Effective-volume compression is not identified with hard-ball concentration.
- Finite-q Lorentz and axisymmetric weak-L3 results are calibration only where stated.
- Adaptive entry-node existence is not arbitrary-depth path existence.
- Universal causal-state entry is not Full Chain Necessity.
- No Finite Obstruction or Navier-Stokes regularity claim is made.
