# CHANGELOG

## v0.1 — 2026-08-15

- Opens the non-Type-I branch where the weak-L3 norm is unbounded.
- Extracts adaptive Lorentz superlevel atoms with amplitude inflation and effective-volume compression.
- Proves finite energy forces lambda_n >= c M_n^3/E_2^2 and r_n <= C E_2^2/M_n^2.
- Uses low-frequency Bernstein exclusion to produce dyadic thresholds J_n -> infinity.
- Proves a scale-invariant UV velocity seed on the Lorentz superlevel set.
- Converts the velocity seed into a global UV vorticity square-tail lower bound of order M_n^4/E_2^2.
- Builds a canonical weighted Footprint Seed from a ball capturing fixed UV square-tail mass.
- Introduces the spatial fragmentation coordinate Xi_n=2^{J_n}R_n.
- Introduces adaptive causal time steps Delta_n ~ R_n^2/(1+Mbar_n).
- Proves ANP-02 aperture control remains uniform after adaptive time renormalization.
- Proves non-Type-I causal-state entry and combines it with the Type-I entry into a universal two-branch state-entry theorem.
- Moves the frontier to arbitrary-depth compatible C3 paths.
