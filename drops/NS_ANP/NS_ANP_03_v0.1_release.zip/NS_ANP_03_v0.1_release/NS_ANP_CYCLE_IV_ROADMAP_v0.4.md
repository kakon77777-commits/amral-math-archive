---
title: "Navier–Stokes Ancestry Necessity Program：Cycle-IV Roadmap"
version: "v0.4"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-ANP Cycle-IV Roadmap v0.4

## ANP-00 — Pre-Singularity Causal Relation Domain

Defines the Causal Atom and C0--C3 semantics.

## ANP-01 — Weighted Source--Core Provenance

Proves a terminal-core weighted C2 causal source relation.

## ANP-02 — Recursive Footprint Compatibility

Proves:

$$
\mathrm{REC\mbox{-}F}
:
\mathrm{PROVED}.
$$

Also proves controlled Type-I footprint aperture and recapture.

Leaves source-parent recursion open.

## ANP-03 — Source-Parent Recapture / C3 Upgrade

### Kernel-inflated parent footprint

For a dyadic output:

$$
\Delta_k,
$$

define:

$$
\boxed{
\chi^{[k]}
=
\kappa_k*\chi
}
$$

using a positive even Schwartz envelope of the LP kernel.

Then:

- mass is preserved;
- centroid is preserved;
- aperture satisfies:
  $$
  A_{\chi^{[k]}}^2
  =
  A_\chi^2
  +
  O((2^kR)^{-2}).
  $$

Thus LP nonlocality is absorbed into a controlled causal footprint.

### Projected source inequality

$$
\boxed{
\left|
\int
\chi\omega_k\cdot\Delta_kF
\right|
\lesssim
\sqrt{
e_k^\chi
}
\left(
\int
\chi^{[k]}|F|^2
\right)^{1/2}.
}
$$

### Parent-state extraction

For a strong source atom:

$$
|\Lambda|
\ge
\eta E_c,
$$

define child residence:

$$
\mathfrak H_c
=
\operatorname*{ess\,sup}
e_k^\chi/E_c,
$$

and partner action:

$$
\mathcal A_{p,q}
=
\int L_{p,q}dt.
$$

Then some earlier time:

$$
s_p
$$

has a weighted high-parent state:

$$
\boxed{
E_h^\psi(s_p)
\ge
c
\frac{
\eta^2
}{
\mathfrak H_c
\mathcal A_{p,q}^2
}
E_c.
}
$$

### Recursive source-parent node

The parent weight:

$$
\psi
=
\mathsf I_h
\mathsf I_k[\chi]
$$

has controlled aperture and explicit provenance.

It can be used as terminal data for the next adjoint recursion.

Thus:

$$
\boxed{
\mathrm{REC\mbox{-}S}^{W}
:
\mathrm{PROVED}
}
$$

for strong selected source atoms.

### C3 upgrade

$$
\boxed{
C3_W
:
\text{weighted pseudolocal source-parent ancestry}
=
\mathrm{PROVED}
}
$$

for strong source atoms with bounded residence/action parameters.

Hard-ball:

$$
C3_B
$$

remains optional/open.

### Action branch

Large partner action is routed to already tracked driver/dissipation actions rather than classified as provenance failure.

### Cross-cycle compiler

DRC finite source carrier plus ANP kernel-inflated recapture yields a weighted C3 parent edge.

## ANP-04 — Non-Type-I Entry

Treat:

$$
\sup_{t<T_\ast}
\|u(t)\|_{L^{3,\infty}}
=
\infty.
$$

Construct adaptive causal-state initialization without one fixed Type-I constant.

## ANP-05 — Arbitrary-Depth Compatible C3 Paths

Combine Type-I C3_W edges and non-Type-I entry.

Prove compatible finite paths of arbitrary depth.

## ANP-06 — Infinite Ancestry Extraction

Target:

$$
\operatorname{Blowup}(T_\ast)
\Longrightarrow
\exists\Gamma_\infty^{NS}.
$$

## ANP-07 — Finite Obstruction Retest

Only after Chain Necessity.

## Hard rules

- Kernel-inflated weighted locality is not hard-ball compact support.
- Large partner-amplitude action is an action branch, not a provenance failure.
- C3_W is a genuine recursive causal edge only when the quantitative parent state is nontrivial.
- Strong-source atom selection still relies on the existing DRC finite-carrier/action classification.
- Non-Type-I entry remains necessary for universal Chain Necessity.
