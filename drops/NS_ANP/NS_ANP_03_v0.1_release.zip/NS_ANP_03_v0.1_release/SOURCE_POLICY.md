# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Kernel-inflated weighted locality is not hard-ball compact support.
- Strong-source atom selection is relative to the DRC finite-carrier/action classification.
- C3_W is proved only when the extracted parent state has a quantitative lower bound.
- No arbitrary-depth C3 path, Chain Necessity, Finite Obstruction, or Navier-Stokes regularity claim is made.
