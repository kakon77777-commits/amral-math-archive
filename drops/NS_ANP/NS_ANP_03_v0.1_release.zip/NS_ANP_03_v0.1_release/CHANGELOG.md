# CHANGELOG

## v0.1 — 2026-08-15

- Replaces hard-ball parent locality by an explicit kernel-inflated causal footprint adapted to the dyadic projector.
- Proves kernel inflation preserves mass and centroid and adds only O(2^{-2k}) to the second moment.
- Proves a projected-source inequality controlled by child weighted shell energy and parent-product energy in the inflated footprint.
- Converts bilinear source relevance into a quantitative earlier high-parent state under bounded child residence and partner-action parameters.
- Defines a legal Parent Footprint Node with explicit provenance-preserving kernel-inflation maps.
- Proves weighted source-parent recursion REC-S^W for strong source atoms.
- Upgrades such edges to weighted pseudolocal C3 causality.
- Removes R_PLEAK as an independent representation/provenance obstruction.
- Separates hard-ball C3_B from weighted C3_W; hard-ball containment remains optional/open.
- Compiles DRC finite-carrier selection with ANP parent recapture into a C3 compiler theorem.
- Moves the next frontier to non-Type-I ancestry entry and arbitrary-depth compatible C3 paths.
