# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Type-I external theorems retain their original hypotheses.
- Reservoir closure is not Chain Necessity.
- Node-wise source ancestry is not source-core provenance.
- Necessary action divergence is not Finite Obstruction.
- No Navier-Stokes regularity claim is made.
