# CHANGELOG

## v0.1 — 2026-08-15

- Closes NS-DRC Cycle III as a research cycle.
- Recompiles DRC-01 through DRC-06 into a unified Type-I reservoir/state/source architecture.
- Proves absolute local Type-I UV core stock injects into a nontrivial global high-pass strain Hdot1 state.
- States the strongest Type-I state-ancestry skeleton currently supported.
- Isolates Source-Core Provenance Bridge as the missing localization/provenance theorem.
- Isolates Recursive Edge Compatibility as the missing recursive source-tree theorem.
- Records the quantifier gap between node-wise/arbitrary-depth statements and one compatible infinite ancestry chain.
- Separates Type-I and non-Type-I critical-Lorentz branches.
- Audits Candidate Dynamic Cover v3 and confirms Finite Obstruction remains open.
- Produces Cycle-III standard-PDE recompilation, handoff, roadmap, and closure schema.
- Launches the provisional NS-ANP Cycle IV focused on Chain Necessity.
