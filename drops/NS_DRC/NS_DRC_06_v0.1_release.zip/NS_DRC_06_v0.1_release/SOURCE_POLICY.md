# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Barker-Prange Type-I hypotheses are retained for all imported concentration results.
- Absolute local core stock is not normalized by global enstrophy unless a global-accounting statement explicitly requires it.
- Reclassifying R_DIL does not exclude Type-I singularity.
- Non-Type-I singularities remain outside this closure.
- No Chain Necessity, Finite Obstruction, or Navier-Stokes regularity claim is made.
