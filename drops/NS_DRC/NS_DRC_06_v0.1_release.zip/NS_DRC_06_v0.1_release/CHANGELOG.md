# CHANGELOG

## v0.1 — 2026-08-15

- Replaces globally normalized Type-I core-shell carriers with the absolute scale-invariant Barker-Prange enstrophy core.
- Re-derives the CSP-02 parabolic-frequency UV extraction in absolute local form.
- Introduces the absolute UV core stock R_I ||P_{>J_I} omega||_{L2(B_RI)}^2.
- Uses Barker-Prange backward propagation to build a geometric same-center nested core-reuse chain.
- Shows the parabolic UV frequency changes by only a fixed dyadic increment along a geometric backward chain.
- Defines a total-core global dilution ratio and preserves its weighted energy budget as a secondary diagnostic.
- Proves local core ancestry is invariant under arbitrary global dilution values.
- Imports Barker-Prange's finite Type-I singular-point count as a finite spatial-center branching theorem.
- Reclassifies R_DIL from a principal dynamic reservoir escape to a global-normalization/certificate issue.
- Records that the Type-I reservoir residual core is empty only relative to the DRC mechanism classification.
- Leaves non-Type-I coverage, Chain Necessity, Finite Obstruction and Navier-Stokes regularity open.
