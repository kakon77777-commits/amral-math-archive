# CHANGELOG

## v0.1 — 2026-08-15

- Opens Cycle III: Dynamic Reservoir Closure Program.
- Refines the preload variable to the actual high-frequency tail required by the later middle-strain spike.
- Proves a post-escape replenishment versus exponentially inflated actual high-tail dichotomy.
- Proves fixed smooth initial data cannot provide the exponentially inflated high tail by source-free heat survival.
- Derives a quantitative prehistory Duhamel source debt.
- Introduces fixed viscous-age slabs.
- Proves every source-free slab forces factor-two backward high-tail inflation.
- Proves a prehistory renewal source packet must appear before reaching the smooth initial regime.
- Splits prehistory renewal into strain-vorticity residual forcing or quadratic-vorticity forcing.
- Proves the quadratic-vorticity branch requires a genuine high-frequency parent state.
- Adds source-age localization: avoiding recent renewal requires exponentially large historical source gross.
- Absorbs R_EXP into the generalized source-renewal residual.
- Reduces the Cycle-III residual core to R_DISS, R_DIL, and R_SRC_star.
