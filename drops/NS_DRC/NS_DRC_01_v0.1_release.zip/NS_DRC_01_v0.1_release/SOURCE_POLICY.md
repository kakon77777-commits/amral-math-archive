# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- External quantitative propagation papers are used only for calibration unless explicitly imported as a theorem.
- EXP-PRELOAD absorption is relative to sufficiently high dangerous events and fixed smooth initial data.
- High-parent support is not promoted to a fixed-share parent carrier.
- No Navier-Stokes regularity claim is made.
