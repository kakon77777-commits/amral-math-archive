---
title: "Navier–Stokes Dynamic Reservoir Closure Program：Cycle-III Roadmap"
version: "v0.1"
date: "2026-08-15"
status: "Active research roadmap"
---

# NS-DRC Cycle-III Roadmap v0.1

## Starting residual core

Cycle II ended with:

$$
R_{\rm EXP},
\quad
R_{\rm DISS},
\quad
R_{\rm DIL},
\quad
R_{\rm SRC}.
$$

## DRC-01 — Exponential Preload / Prehistory Renewal

Refines preload to the actual high-frequency strain tail needed by the later middle-strain spike.

Proves:

$$
\boxed{
\text{post-escape replenishment}
\vee
\text{exponentially inflated actual high-tail preload}.
}
$$

Then proves fixed smooth initial data cannot support the latter as a source-free heat remnant.

Therefore:

$$
\boxed{
R_{\rm EXP}
\subset
R_{\rm SRC}^{pre}.
}
$$

A viscous-age slab theorem gives:

$$
\boxed{
\text{source packet}
\vee
\text{backward stock inflation}.
}
$$

Repeating to the smooth initial regime forces a prehistory source-renewal packet.

Prehistory forcing splits into:

$$
\boxed{
\text{PRE-SV}
\vee
\text{PRE-VORT}.
}
$$

PRE-VORT requires genuine high-frequency vorticity parent state.

The residual core becomes:

$$
\boxed{
R_{\rm DISS},
\quad
R_{\rm DIL},
\quad
R_{\rm SRC}^{\ast}.
}
$$

## DRC-02 — Source-to-State Efficiency

Target:

$$
R_{\rm SRC}^{\ast}.
$$

Tasks:

1. define parent-state shares for pre/post renewal packets;
2. define source/state amplification ratios;
3. prove finite parent-state capture or amplification escape;
4. quantify cancellation;
5. create a renewal-chain finite-branching theorem;
6. test whether large source amplification forces spectral dispersion or model-cone residual growth.

## DRC-03 — Dissipation-Range Replenishment

Target:

$$
R_{\rm DISS}.
$$

Tasks:

1. compare high-frequency source debt with viscosity absorption;
2. couple low-mode driver action to high-shell replenishment;
3. use Cheskidov--Shvydkoy and Cheskidov--Dai criteria at forcing level;
4. seek a dissipation-range source coercivity theorem.

## DRC-04 — Persistent Core Dilution

Target:

$$
R_{\rm DIL}.
$$

Tasks:

1. combine Barker--Prange backward core persistence with the dilution-profile budget;
2. quantify overlap of core shells across separated times;
3. test whether repeated dilution forces global enstrophy exhaustion or multiplicity escape.

## DRC-05 — Unified Dynamic Reservoir Cover

Recombine the surviving source, dissipation and dilution mechanisms.

Retest finite obstruction.

## Hard rules

- EXP-PRELOAD is no longer an independent residual once actual high-tail prehistory is tracked.
- Prehistory source renewal is not itself a contradiction.
- High-parent support does not imply one fixed-share parent state.
- Source-age localization must preserve the heat weight.
- No regularity claim is allowed until all remaining forcing-level residuals close.
