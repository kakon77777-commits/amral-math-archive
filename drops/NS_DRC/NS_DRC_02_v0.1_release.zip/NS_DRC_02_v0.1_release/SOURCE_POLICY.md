# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- External triadic/turbulence papers are used only as calibration unless explicitly marked otherwise.
- Parent-state envelope share is not identified with actual enstrophy share without the amplification ratio.
- Low source utilization is not promoted to a dangerous mechanism.
- No Navier-Stokes regularity claim is made.
