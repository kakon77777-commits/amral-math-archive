# CHANGELOG

## v0.1 — 2026-08-15

- Upgrades the quadratic-vorticity renewal branch from support-only ancestry to an exact signed net-source parent ledger.
- Introduces a deterministic bilinear parent-state envelope.
- Separates signed cancellation from state-envelope utilization.
- Defines canonical high-parent source and state-envelope marginals.
- Proves a finite parent-envelope carrier theorem.
- Introduces time-weighted high-parent enstrophy shares and a source-to-enstrophy amplification ratio.
- Proves a genuine enstrophy-carrier upgrade under bounded amplification.
- Compresses source-to-state failure into cancellation, utilization collapse, parent multiplicity, or source-to-state amplification.
- Proves a conditional finite-branching renewal-chain theorem under uniform source/utilization/amplification thresholds.
- Updates the Cycle-III residual core to R_DISS, R_DIL, R_CAN, R_UTIL, R_MULT, and R_AMP.
