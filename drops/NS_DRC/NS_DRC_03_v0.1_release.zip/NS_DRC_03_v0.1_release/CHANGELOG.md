# CHANGELOG

## v0.1 — 2026-08-15

- Corrects the DRC-02 source-amplification baseline by extracting the deterministic 2^{5h/2} scale weight of local Hdot1 vorticity forcing.
- Defines a scale-corrected finite parent-cluster state stock.
- Proves local source envelopes are controlled by that stock.
- Splits far high-low forcing relative to the Cheskidov-Shvydkoy dissipation wavenumber into low-driver, transition, and viscosity-absorbable sectors.
- Absorbs R_AMP into scale-corrected local state support or R_DISS.
- Refines utilization with P <= G <= H <= Q and exact factorization U=(P/G)(G/H)(H/Q).
- Gives a translated-parent construction showing geometric utilization can collapse while parent global norms remain fixed.
- Reclassifies generic R_UTIL as depletion/certificate geometry rather than a primitive dangerous source mechanism.
- Updates the residual core to R_DISS, R_DIL, R_CAN, R_MULT, and localized source-alignment geometry.
