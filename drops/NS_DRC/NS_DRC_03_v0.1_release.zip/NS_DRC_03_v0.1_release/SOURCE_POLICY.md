# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- External turbulence/locality papers are used only as calibration unless explicitly imported.
- Unweighted enstrophy share is not used as the sole amplification baseline for Hdot1 vorticity forcing.
- Utilization collapse is not promoted to a dangerous mechanism.
- No Navier-Stokes regularity claim is made.
