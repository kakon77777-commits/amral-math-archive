# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Cheskidov-Shvydkoy and Cheskidov-Dai results retain their original hypotheses.
- The strong driver Omega_Q is stronger than the sharp Besov driver and is used for direct forcing estimates.
- Absorbing R_DISS does not mean proving driver-action finiteness.
- No Navier-Stokes regularity claim is made.
