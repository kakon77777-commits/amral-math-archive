# CHANGELOG

## v0.1 — 2026-08-15

- Recompiles the dissipation residual around a strong low-mode forcing driver Omega_Q.
- Proves Omega_Q >= c 2^{2Q} from the dissipation-boundary shell.
- Uses DRC-03/04 deep-dissipation absorption to isolate the remaining active quadratic-vorticity forcing.
- Proves active forcing is bounded by Omega_Q times the high-frequency strain-gradient stock.
- Defines strong active renewal nodes and a high-state residence ratio.
- Proves every strong node pays a low-mode driver packet or must be re-rooted to a larger earlier state.
- Proves repeated re-rooting cannot reach a fixed smooth early-time region at sufficiently high fixed frequency; a driver ancestor must occur.
- Introduces the dissipation-boundary height-residence quantity and proves an exponential height-residence tradeoff.
- Absorbs R_DISS as an independent reservoir mechanism into low-mode driver/model-cone action genealogy.
- Reduces the principal unexplained dynamic reservoir residual core to R_DIL.
