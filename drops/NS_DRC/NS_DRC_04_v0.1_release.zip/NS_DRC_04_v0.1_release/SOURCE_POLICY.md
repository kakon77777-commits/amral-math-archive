# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- External turbulence/locality papers are used only as structural calibration unless explicitly marked otherwise.
- Signed cancellation is not assumed small.
- R_MULT absorption retains DRIVER and viscosity-absorbable sectors explicitly.
- No Navier-Stokes regularity claim is made.
