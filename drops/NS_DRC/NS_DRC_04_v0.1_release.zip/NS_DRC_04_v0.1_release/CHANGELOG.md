# CHANGELOG

## v0.1 — 2026-08-15

- Changes cancellation strategy from bounding signed gross to grouping the exact net renewal by canonical high-parent shell.
- Completes DRC-03 dissipation geometry with a deep scale-local high-high viscous absorption theorem.
- Proves non-driver, non-absorbable transition parents occupy only a finite shell interval controlled by Q_I^+-J.
- Proves parent multiplicity is bounded by dissipation-span width.
- Absorbs R_MULT into R_DISS.
- Proves a cancellation-robust net-shell carrier theorem: finite shell support gives a positive net shell carrier regardless of arbitrarily large positive/negative gross.
- Backs the net shell carrier by a DRC-03 scale-corrected parent-cluster state stock.
- Removes R_CAN as an independent ancestry obstruction without claiming cancellation is small.
- Adds an exact intra/inter cancellation-coherence factorization for diagnostics.
- Proves a conditional finite-branching renewal criterion with no cancellation-ratio hypothesis.
- Reduces the principal dynamic residual core to R_DISS and R_DIL.
