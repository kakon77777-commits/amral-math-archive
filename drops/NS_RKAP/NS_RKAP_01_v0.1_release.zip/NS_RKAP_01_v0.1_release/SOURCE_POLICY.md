# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Sign-changing residual stress is kept distinct from actual positive Reynolds covariance.
- Covariance-transport transversality uses the existing linearized local-energy term `dot R U`; it is not a new copied detector.
- Two-sided lift tax uses actual positive package coordinates when available; spectral positive/negative decomposition alone is not claimed NS-realizable.
- A positive lift cost is not automatically a telescoping or finite global budget.
- Residual-direction rigidity and physical amplitude Critical Lift remain separate.
- No Forest Coercive Budget, Finite Forest Obstruction, or Navier-Stokes regularity claim is made.
