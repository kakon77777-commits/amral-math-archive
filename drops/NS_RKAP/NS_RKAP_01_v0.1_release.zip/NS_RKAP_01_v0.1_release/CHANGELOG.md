# CHANGELOG

## v0.1 — 2026-08-16

- Launches the Navier-Stokes Residual Kernel and Amplitude Program.
- Identifies the covariance-transport vector H u as an existing native linearized energy-balance channel.
- Proves quantitative injectivity of H -> H u on the hyperbolic mismatch fiber.
- Defines transport-separating energy windows and proves a compact finite-window transport gap.
- Gives a conditional native hyperbolic energy-transport visibility compiler.
- Introduces the two-sided positive-semidefinite lift tax.
- Proves the exact minimum positive lift cost equals the nuclear norm of the signed stress.
- Computes the hyperbolic lift cost as 2|u||w|=sqrt(2)||H||_F.
- Proves any positive two-package realization carries covariance energy at least equal to the lift tax.
- Identifies a linear-in-amplitude q=1 lift route for Critical Lift.
- Proves the corresponding logarithmic power threshold s<=1/3 for rho_n~n^-2/3.
- Proves pointwise lift cost alone does not give a global packing/telescoping budget.
- Moves the next frontier to transport-gap stability, positive-lift realizability, and two-package lift-energy packing.
