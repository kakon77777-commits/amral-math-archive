# CHANGELOG

## v0.1 — 2026-08-15

- Connects CSP stale-floor events to Miller's strain-vorticity regular-model cone.
- Proves B^{-1/2}_{infty,infty} amplitude controls a persistent Hdot1 strain-gradient floor on stale intervals.
- Derives the exact full-Navier-Stokes Hdot1 model-cone balance from the projected strain equation and Miller orthogonality.
- Proves chi_SV<1 is Hdot1-depleting.
- Defines a dimensionless stale preload ratio.
- Proves non-preloaded middle-strain spikes pay logarithmic strain-vorticity residual action and cross chi_SV>=1.
- Defines PRELOAD as the complementary pre-existing strain-gradient reservoir branch.
- Proves excess PRELOAD forces Hdot1 stock to ultraviolet depth above the Bradshaw-Grujic lower endpoint.
- Proves band-passed pseudolocal equivalence between local strain and vorticity concentration at one shell.
- Removes same-shell Riesz nonlocality from the core-alignment defect.
- Replaces D_ALIGN by shell-index mismatch and core dilution.
- Moves the frontier to transport/replenishment of preloaded ultraviolet reservoirs and source-state synchronization.
