# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Miller strain-vorticity model theorems retain their original hypotheses.
- Model-cone departure is not a contradiction.
- PRELOAD is not promoted to a blow-up mechanism.
- Same-shell band-passed alignment does not imply shell-index alignment.
- No Navier-Stokes regularity claim is made.
