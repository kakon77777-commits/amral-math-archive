# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Miller, Cheskidov-Shvydkoy, Cheskidov-Dai, and Barker-Prange theorem hypotheses are retained.
- Replenishment debt is not promoted to contradiction.
- Type-I dilution claims are conditional on the stated local shell concentration hypothesis.
- No Navier-Stokes regularity claim is made.
