# CHANGELOG

## v0.1 — 2026-08-15

- Converts PRELOAD from a static reservoir label into a transport/survival problem.
- Extracts a final high-frequency Hdot1 strain tail from a middle-strain spike.
- Defines the viscous preload age and old-stock survival factor.
- Proves the preload survival/replenishment dichotomy.
- Shows old stock surviving many viscous ages requires exponential preload inflation.
- Splits replenishment into strain-vorticity model residual forcing and quadratic-vorticity forcing.
- Proves high-frequency vorticity replenishment requires genuine high-frequency parent-state participation.
- Reinterprets super-parabolic micro-packing as fast viscous turnover/replenishment geometry.
- Proves a Type-I core-dilution weighted energy budget.
- Reduces PRELOAD to EXP-PRELOAD, SV-REP, or VORT-REP.
- Moves the final Cycle-II frontier to a unified reservoir/alignment cover.
