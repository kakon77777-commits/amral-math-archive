# CHANGELOG

## v0.1 — 2026-08-15

- Specializes the Bradshaw-Grujic moving window to epsilon=1/2.
- Records exact formulas 2^{J_low} ~ B/E2 and 2^{J_high} ~ B^2.
- Extracts from their proof the active-escape-interval domination Phi_{1/2} >= B/2.
- Proves a window-free same-time synchronization theorem: any wavelength-localized middle-strain carrier anywhere in frequency forces moving-window action on active escape intervals.
- Replaces generic window mismatch by an escape-gap temporal mismatch.
- Shows terminal-coverage escape geometry removes the temporal gap branch near the singular time.
- Proves fixed endpoint padding remains a valid stronger frequency-window regularity criterion and absorbs D_EDGE.
- Compares the Cheskidov-Shvydkoy dissipation wavenumber to the Bradshaw-Grujic upper endpoint: Q <= J_high + O(1).
- Reclassifies high exterior activity as dissipation-range overshoot.
- Adds a conditional Type-I singular-core window-free synchronizer.
- Moves the main frontier from frequency placement to temporal escape-gap synchronization.
