# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Bradshaw-Grujic and Cheskidov-Shvydkoy theorem hypotheses are retained.
- Frequencies in the viscous-dominated range are not declared dynamically impossible.
- Escape-gap mismatch is explicitly left open.
- No Navier-Stokes regularity claim is made.
