# CHANGELOG

## v0.1 — 2026-08-15

- Adds Fourier-projection monotonicity for the approximate-Laplacian-eigenfunction residual.
- Proves an explicit two-cluster spectral-separation lower bound.
- Defines disjoint sharp dyadic spectral shell probabilities.
- Proves a bounded-log-band atom floor.
- Proves severe shell atomization forces separated spectral quartiles.
- Proves a universal eigen-residual lower bound when the sharp shell atom is at most 1/8.
- Proves same-time middle-strain / eigen-residual synchronization when an atomized spectral component captures a fixed share of the middle-strain spike.
- Introduces padded moving-window bookkeeping to connect smooth LP shells with sharp spectral bins.
- Compresses the global shell defect into eigen-residual synchronization or finite window-edge leakage.
- Splits local Type-I shell atomization into global spectral atomization, shell/core misalignment, or window-edge leakage.
- Connects simultaneous resonant high-high/low state occupancy to spectral-dispersion cost.
- Moves the primary frontier to moving-window capture and dissipation-wavenumber geometry.
