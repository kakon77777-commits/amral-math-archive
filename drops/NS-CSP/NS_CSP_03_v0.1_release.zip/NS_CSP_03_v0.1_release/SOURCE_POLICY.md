# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Miller approximate-eigenfunction results are external theorem inputs.
- Smooth Littlewood-Paley shell claims are converted to sharp spectral-bin claims only through fixed bounded-overlap padding.
- Resonant source geometry is not promoted to simultaneous state occupancy.
- No Navier-Stokes regularity claim is made.
