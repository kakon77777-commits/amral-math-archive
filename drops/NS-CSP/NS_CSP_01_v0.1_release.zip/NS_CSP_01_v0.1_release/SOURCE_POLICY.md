# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- External concentration theorems retain their original hypotheses.
- Local velocity concentration is not silently promoted to dyadic strain-shell concentration.
- No Navier-Stokes regularity claim is made.
