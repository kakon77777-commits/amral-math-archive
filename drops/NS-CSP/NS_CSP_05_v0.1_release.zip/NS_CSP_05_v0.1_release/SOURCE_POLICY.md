# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Bradshaw-Grujic escape-time and local-wellposedness results retain their original hypotheses.
- Bounded normalized lag is not promoted to same-time synchronization.
- Large stale lag is cumulative-action debt, not a contradiction.
- No Navier-Stokes regularity claim is made.
