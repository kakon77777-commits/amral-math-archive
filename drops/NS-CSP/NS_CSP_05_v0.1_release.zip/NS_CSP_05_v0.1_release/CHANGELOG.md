# CHANGELOG

## v0.1 — 2026-08-15

- Introduces a continuous Besov escape-level calculus.
- Proves each sufficiently large level L has an escape time tau(L) with B(tau(L))=L and B>=L thereafter.
- Attaches the Bradshaw-Grujic intrinsic recovery interval to every level.
- Proves every level recovery interval carries a universal Phi_{1/2}^4 action packet.
- Defines the scale-invariant half-level recovery lag B(t)^4 dist(t,I_{B(t)/2}).
- Splits gap times into startup and post-recovery stale geometry.
- Proves startup times are automatically bounded-lag and pay a rapid Besov-evolution debt.
- Proves large stale lag forces large cumulative critical Besov action before the middle-strain spike.
- Proves a temporal gap rigidity alternative: bounded parabolic-lag synchronization or stale-floor action separation.
- Adds a scale-critical weighted gap-measure debt.
- Replaces generic D_GAP by the narrower D_STALE frontier.
