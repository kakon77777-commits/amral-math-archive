# CHANGELOG

## v0.1 — 2026-08-15

- Closes NS-CSP Cycle II as a research cycle.
- Absorbs large core/carrier shell-index mismatch into approximate-eigenfunction synchronization or core dilution.
- Proves a general Type-I dilution-profile sparsity theorem.
- Adds the Cheskidov-Shvydkoy low-mode dissipation-wavenumber driver action.
- Adds the Cheskidov-Dai terminal high-shell vorticity activity criterion.
- Combines them into a two-sided dissipation-range necessity filter.
- Proves a functional-analytic no-go showing finite energy and bounded instantaneous critical Besov amplitude cannot upper-bound strain Hdot1 preload.
- Audits residual source/state multiplicity and cancellation.
- Defines Candidate Dynamical Cover v2.
- Reduces the Cycle-II frontier to four mechanisms: R_EXP, R_DISS, R_DIL, R_SRC.
- Produces a standard-PDE recompilation, Cycle-II handoff, and next-cycle roadmap.
- Explicitly records that Finite Obstruction and Navier-Stokes regularity remain open.
