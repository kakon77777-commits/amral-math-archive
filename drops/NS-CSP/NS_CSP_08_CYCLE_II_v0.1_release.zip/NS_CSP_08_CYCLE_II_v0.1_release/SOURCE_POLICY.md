# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- External regularity theorems retain their original hypotheses.
- The static preload no-go is not a Navier-Stokes solution example.
- Candidate Dynamical Cover v2 is explicitly incomplete.
- No Navier-Stokes regularity claim is made.
