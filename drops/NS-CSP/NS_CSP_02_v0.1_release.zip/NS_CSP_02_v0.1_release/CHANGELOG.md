# CHANGELOG

## v0.1 — 2026-08-15

- Rewrites the spatial defect using vorticity shells, which are naturally compatible with Type-I enstrophy concentration.
- Proves a two-sided wavelength-cell spatial-atom equivalence:
  $2^{-j/2}\|u_j\|_\infty \asymp_A \sqrt{a_\omega^A}\|\omega_j\|_2$.
- Identifies spatial atomization as the canonical fixed-shell L2-to-Linfinity defect.
- Imports Barker-Prange Type-I enstrophy concentration.
- Uses Lorentz-Bernstein estimates to exclude frequencies far below the parabolic core scale.
- Proves Type-I singular-core ultraviolet vorticity extraction.
- Introduces local core-window capture and local core-shell atomization.
- Proves a parabolic wavelength packing lemma.
- Proves a conditional Type-I core synchronizer with a $1/(T^*-t)$ frequency-action density lower bound.
- Proves a logarithmic-measure Type-I spatial-core alternative.
- Proves the atom/concentration-radius packing inequality.
- Isolates singular-core-to-carrier-shell alignment as the remaining spatial bridge.
- Refines D_space into D_ALIGN, core-window mismatch, core-shell atomization, and super-parabolic micro-packing.
