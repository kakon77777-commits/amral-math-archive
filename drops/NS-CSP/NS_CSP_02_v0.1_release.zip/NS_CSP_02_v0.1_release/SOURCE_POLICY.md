# SOURCE_POLICY

- Canonical source: UTF-8 Markdown.
- Canonical math delimiters: `$...$` and `$$...$$`.
- No Unicode-math round trip or `unicode_escape` transformation.
- Source-level validation is recorded in `validation.json`.
- Render-level validation is not claimed.
- Barker-Prange Type-I results retain their original Type-I hypotheses.
- Total vorticity-core concentration is not silently promoted to one carrier-shell concentration.
- Global strain/vorticity shell equivalence is not promoted to local core alignment.
- No Navier-Stokes regularity claim is made.
