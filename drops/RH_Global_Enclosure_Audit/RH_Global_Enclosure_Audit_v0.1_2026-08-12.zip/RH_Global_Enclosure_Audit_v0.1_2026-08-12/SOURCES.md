# Sources

## Internal framework documents

- Neo.K, `數學猜想難度矩陣_MCDM_v0.1.md`
- Neo.K, `Faithful_Global_Quantifier_Compression_Proof_Route_v0.1.1.md`
- Neo.K, `層化零點障礙與局部全域提升_從有理矩形證書到全臨界帶判定_v0.1_內部稿.md`
- Neo.K, `04_第四輪_局部全域障礙與表示逃逸.md`

## External mathematical sources

- Claude, *More Than Two Thirds of the Zeros of the Riemann Zeta Function Lie on the Critical Line* (2026-08-10).
- Baluyot, Goldston, Suriajaya, Turnage-Butterbaugh, *An unconditional Montgomery Theorem for Pair Correlation of Zeros of the Riemann Zeta Function*, arXiv:2306.04799.
- Goldston, Lee, Schettler, Suriajaya, *Pair Correlation Conjecture for the zeros of the Riemann zeta-function I: simple and critical zeros*, arXiv:2503.15449.
- Chirre, Gonçalves, de Laat, *Pair Correlation Estimates for the Zeros of the Zeta Function via Semidefinite Programming*, arXiv:1810.08843.
- Conrey, Farmer, Kwan, Lin, Turnage-Butterbaugh, *Short mollifiers of the Riemann zeta-function*, arXiv:2508.11108.
- Goldston, Suriajaya, *Zeta Zeros in a Narrow Vertical Box*, arXiv:2603.28104.
- Goldston, Lee, Schettler, Suriajaya, *Pair Correlation Conjecture II: The Alternative Hypothesis*, arXiv:2507.06823.
