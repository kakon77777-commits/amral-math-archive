# 06｜子審計 F：反方與 No-Go 裁決

## No-Go 1：比例升高不代表接近 RH

$$
q\to1
$$

不排除 isolated or zero-density exceptions。

## No-Go 2：等價 functional 不代表更容易

定義：

$$
\mathfrak Z=0\iff\mathrm{RH}
$$

若沒有估計 $\mathfrak Z$ 的新方法，只是改寫。

## No-Go 3：強假設可能偷渡目標

例如 narrow-box assumption 已包含大部分 horizontal conclusion。

## No-Go 4：局部成功可能是 representation artifact

另一表示可能直接壓縮障礙。

## No-Go 5：更多 Agent 不能製造缺失定理

若缺口是：

$$
\sigma>1
\Rightarrow
\text{unknown prime-pair theorem},
$$

增加搜索只能更精確描述依賴，不能把猜想變成已證。

## No-Go 6：全局包圍也可能循環

若「全局包圍」被定義為：

> 收集所有能證 RH 的條件，

它只是把 RH 藏進定義。

所以全局包圍必須輸出：

- 可被反例推翻的中間命題；
- 較低複雜度的 global summary；
- 明確的新 inequality；
- 可度量的 tail/decay。

否則應立即停止。
