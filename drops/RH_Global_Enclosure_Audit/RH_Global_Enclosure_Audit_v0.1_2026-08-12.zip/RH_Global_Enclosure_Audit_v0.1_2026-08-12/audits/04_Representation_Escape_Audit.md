# 04｜子審計 D：表示逃逸

## 原則

局部—全域落差本身不代表真正困難。

Tseitin 在 CNF/resolution中很難，但改寫成：

$$
Ax=b\pmod2
$$

後，高斯消去或總 parity立即給出全域矛盾。

因此對 RH 候選障礙，至少測試：

1. zero divisor / argument principle；
2. Weil explicit formula；
3. Hermitian compression / inertia；
4. pair statistics；
5. mollifier / zero detection；
6. SDP / Fourier majorant；
7. operator/spectral representation；
8. local certificate / globalizer。

## 淘汰規則

若障礙只在某一表示出現，另一標準表示可低成本壓縮：

$$
\boxed{
\text{淘汰為全域瓶頸候選。}
}
$$

## 對目前 CPL 的判決

- bandwidth-one ceiling是真正的「方法相對障礙」；
- 不是跨所有表示的 RH 障礙；
- MMIP正是在測試 tail-sign表示是否能逃離 two-trace ceiling；
- mollifier與horizontal multiplicity是其他逃逸表示。
