# 01｜子審計 A：量詞與例外忠實性

## 任務

不問方法有多漂亮，只問：

$$
\text{它的最強輸出是否仍保留 RH 的 }\forall\rho\text{？}
$$

## 判決

| 路線 | 自然輸出 | 是否忠實於 RH 全稱量詞 |
|---|---|---|
| Claude 比例 | $\liminf N_0^s/N\ge q$ | 否 |
| support ladder | $q(\sigma)$ | 否 |
| full PCC | density $1$ simple+critical | 否 |
| higher moments | 更高比例 | 否 |
| mollifier | critical-line proportion | 否 |
| narrow box | 條件式比例 | 否 |
| atomic off-axis mass | $\mathfrak Z=0\iff\mathrm{RH}$ | 是 |

## 致命測試

只要存在：

$$
1\le\#\{\rho:\Re\rho\ne1/2\}=o(N(T)),
$$

所有 density-one summary 仍可成立，但 RH 為假。

因此任何比例路線都必須預先標記：

```text
Local/statistical theorem
≠
Global RH closure
```

## Globalizer 限制

Faithful Globalizer只完成：

$$
\text{quantifier compression}.
$$

沒有 decay theorem時：

$$
\mathfrak Z=0
$$

仍與原命題同樣困難。
