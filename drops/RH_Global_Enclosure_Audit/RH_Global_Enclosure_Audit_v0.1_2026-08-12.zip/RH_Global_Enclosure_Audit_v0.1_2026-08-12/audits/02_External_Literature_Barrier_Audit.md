# 02｜子審計 B：外部文獻與方法上限

## Pair correlation

- BGSTB 建立 unconditional Montgomery 型 form factor；
- Claude 把 bandwidth-one two-trace/inertia 推到 $67.25\%$；
- 同一資訊域有約 $68.185\%$ configuration-wise ceiling；
- support $>1$ 需要 off-diagonal prime-pair資訊。

判決：

```text
無新 prime-pair theorem
→ 不應再以同一路線承諾無條件 70%
```

## Full PCC

Goldston–Lee–Schettler–Suriajaya 證明 PCC 不需 RH 即可推出 density-one simple and critical zeros。

判決：

```text
重要條件式終點
但仍不等於 RH
```

## CGdL SDP

CGdL 使用 Fourier tail sign與 SDP改善 multiplicity bounds；published scalar zero-side argument依賴 RH。

BGSTB 現在提供 unconditional form-factor nonnegativity，但不能直接搬走 CGdL 的 RH zero-side lower bound。

判決：

```text
CGdL + Claude inertia 是合理的新合成問題
不是既有 theorem 的直接 corollary
```

## Mollifier

最新 short-mollifier工作顯示最佳化導數組合本身很有力量，但自然輸出仍是臨界線比例。

判決：

```text
沒有 joint bridge 前，對 CPL simultaneous simple-critical objective 邊際效益低
```

## Narrow box

若所有零點已在寬度 $b/\log T$、$b\to0$ 的盒中，可推出至少 $2/3$ simple+critical。

判決：

```text
它是穩定性定理，不是取得 narrow-box input 的方法
```
