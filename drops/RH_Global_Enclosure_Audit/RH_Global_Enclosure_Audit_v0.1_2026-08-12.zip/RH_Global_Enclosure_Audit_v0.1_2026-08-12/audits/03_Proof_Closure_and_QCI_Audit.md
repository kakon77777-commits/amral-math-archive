# 03｜子審計 C：證明閉合與 QCI

## 三層區分

### 層一：等價重述

$$
\mathrm{RH}\iff\mathfrak Z=0.
$$

### 層二：局部／有限控制

$$
\mathfrak Z_{\le T}\le \varepsilon_T.
$$

### 層三：全域閉合

需要 uniform tail：

$$
\sup_{U\ge T}\mathfrak Z_{(T,U]}
\to0,
$$

或 coercive inequality：

$$
\mathfrak Z
\le
C\mathcal E,
\qquad
\mathcal E=0.
$$

只有第三層能關閉全局量詞。

## QCI 必填項

每一條路都必須回答：

1. 對象是否合法進入 explicit formula？
2. 積分／求和／極限換序是否合法？
3. 誤差是否 uniform？
4. strict sign 是否有 margin？
5. finite certificate如何提升到無界高度？
6. 例外是否可能逃到 tail？

若其中一項沒有 theorem，只能標：

```text
Open proof obligation
```

不能以 numerical confidence 取代。
