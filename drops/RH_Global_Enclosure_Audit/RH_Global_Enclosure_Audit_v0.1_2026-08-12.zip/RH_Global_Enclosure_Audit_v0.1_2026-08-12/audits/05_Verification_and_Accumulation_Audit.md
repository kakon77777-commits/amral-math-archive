# 05｜子審計 E：驗證、形式化與累積性

## 目前 CPL 的優勢

CPL v1–v11 已累積：

- 原論文與前置文獻；
- $67.25\%$ 常數重算；
- bandwidth-one adversarial law；
- small-$N$ LP；
- exact-rational Bernstein certificates；
- support ladder；
- arithmetic kernel；
- barrier audit。

因此它屬於高累積性：

$$
P4
$$

而不是重複生成。

## 但驗證不改變作用域

Lean／exact certificate只能保證：

> 在指定 definition、domain、assumption 中命題正確。

它不能自動完成：

$$
\text{toy}
\to
\text{zeta},
$$

$$
\text{finite}
\to
\text{global},
$$

$$
\text{density}
\to
\text{empty exception set}.
$$

## 強制紀錄

每個結果必須同時保存：

```text
Statement
Domain
Assumptions
Quantifier type
Exception fidelity
Uniformity range
Certificate type
Missing lift
```
